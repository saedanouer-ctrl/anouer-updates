/* ANOUER — «استوديو الإيصال الذكي» (2026)
   مربع جديد في شريط «المعاينة» (Preview) يفتح نافذة تصميم إيصال/فاتورة الكاشير بمقاسها الحقيقي (80 / 58 مم):
   • أقسام تُشغَّل وتُطفأ وتُرتَّب بالسحب: الرأس، العنوان، الأصناف، الإجماليات، المبلغ بالحروف، الملاحظات، نصوص، فواصل، باركود.
   • الأصناف: جدول بأعمدة قابلة للتشغيل/الترتيب/العرض — أو «اسم طويل + أسطر حسابية» تُبنى بالرموز × + − / =
     مثل: القطعة 1 × عدد القطع داخل الوحدة الكبرى = سعر الوحدة الكبرى. إضافة / حذف الأسطر بحرية.
   • صور فوق الإيصال (شعار، QR، ملصقات) تُسحب وتُكبَّر في أي مكان.
   • «استعمل هذا التصميم في الطباعة» ← طباعة الفواتير مباشرة به. */
(function () {
  "use strict";
  if (window.__RCS) return;
  const E = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const G = id => document.getElementById(id);
  const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (_) { return false; } } };
  const say = (m, k) => { try { toast(m, k || "i"); } catch (_) { } };
  const RM = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
  const PX = 96 / 25.4, r1 = v => Math.round(v * 10) / 10;
  const N2 = v => (Math.round((+v || 0) * 100) / 100).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const NQ = v => { v = Math.round((+v || 0) * 1000) / 1000; return v.toLocaleString("en-US", { maximumFractionDigits: 3 }); };
  const PRODS = () => { try { return window.products || (typeof products !== "undefined" ? products : []); } catch (e) { return []; } };
  const uid = () => Math.random().toString(36).slice(2, 9);
  let CO = null;

  function mk(C) {
  const G = id => (OV && OV.querySelector("#" + id)) || document.getElementById(id);
  const FL = "__" + C.K;

  /* ---------------- الرموز (الأعمدة / أسطر الحساب) ---------------- */
  const TOK = {
    name: "اسم الصنف", qty: "الكمية", unit: "الوحدة", price: "السعر", total: "الإجمالي", code: "الكود", disc: "الخصم", net: "صافى السعر",
    one: "1", factor: "عدد القطع (الوحدة الكبرى)", bigp: "سعر الوحدة الكبرى", bigu: "الوحدة الكبرى", pcs: "سعر القطعة", idx: "م", pb: "قبل الخصم", pa: "بعد الخصم"
  };
  const OPS = ["×", "+", "−", "/", "="];
  function prodOf(it) {
    const c = String(it["Item Code"] || ""), b = String(it.Barcode || "");
    return PRODS().find(p => (c && String(p.code) === c) || (b && ((p._u || []).some(u => String(u.bc) === b || (u.xb || []).includes(b)) || String(p.code) === b))) || PRODS().find(p => p.name === it["Item Name"]) || null;
  }
  function bigOf(p) { const us = (p && p._u) || []; return us.length ? us.reduce((m, u) => (+u.factor || 1) > (+m.factor || 1) ? u : m, us[0]) : null; }
  function tokVal(k, it, i) {
    const p = prodOf(it), big = bigOf(p), u = p && (p._u || []).find(x => x.name === it.Unite), f = u ? (+u.factor || 1) : 1;
    switch (k) {
      case "name": return it["Item Name"] || ""; case "qty": return NQ(it.Qty); case "unit": return it.Unite || ""; case "price": return N2(it.Price);
      case "total": return N2(it.Total); case "code": return it["Item Code"] || ""; case "disc": return N2(it["Item Discount"] || 0); case "net": return N2(it["Net Price"] != null ? it["Net Price"] : it.Price);
      case "one": return "1"; case "factor": return big ? NQ(+big.factor || 1) : "1"; case "bigp": return big ? N2(big.price) : N2(it.Price); case "bigu": return big ? big.name : (it.Unite || "");
      case "pcs": return N2((+it.Price || 0) / (f || 1)); case "idx": return String(i + 1);
      case "pb": return N2(pbpa(it).b); case "pa": { const q = pbpa(it); return q.kind === "same" ? "لم يتغيّر سعره" : N2(q.a); }
      default: return "";
    }
  }
  /* ✦ خصم الصنف داخل الإيصال: السعر الحقيقي مشطوب وجنبه سعر القطعة بعد الخصم + نسبة الخصم
     (أبيض/أسود فقط — يطبع واضح على الطابعة الحرارية) */
  function dscOf(it) {
    const p = +it.Price || 0, q = +it.Qty || 0;
    let n = it["Net Price"] != null ? +it["Net Price"] : p;
    if (!(n < p - 0.004) && q && (+it["Item Discount"] || 0) > 0.004) n = p - (+it["Item Discount"] || 0) / q;
    if (!(p > 0) || !(n < p - 0.004)) return null;
    return { p, n, per: p - n, pct: (p - n) / p * 100, all: (p - n) * q };
  }
  function dscPrice(it, i) {
    const d = dscOf(it); if (!d) return `<span class="tk t-price">${E(tokVal("price", it, i))}</span>`;
    return `<span class="tk t-price rr-dsp"><s>${E(N2(d.p))}</s><b>${E(N2(d.n))}</b></span>`;
  }
  /* «سعر تعريفي» وسط سطر الحساب — حسب ما دخل في الفاتورة:
     • بِيع بوحدة كبرى (كرتونة / فاردو / باطة مسجّلة بعدد قطع) ← السعر ÷ عدد القطع المسجّل لها
         KooL Break كرتونة (6 علب) 8,622 ← القطعة 1,437 · LIYA 24P كرتونة (6) 1,170 ← القطعة 195
     • بِيع بالقطعة (الوحدة الأساسية) ← السعر ÷ عدد القطع في اسم الصنف (25pies · 24P · 30 Unites …)
         KooL Break Maxy 25pies 1,490 ← القطعة 59.60 · LIYA 24P 240 ← القطعة 10
     • صنف بوحدة واحدة عددها في اسمها (كرتونة 48Units · كرتونة 5Bouat) ← السعر ÷ ذلك العدد */
  const PCW = "pi[eè]ces?|pies|pise|pcs?|pc|p|unit[eé]?s?|u|sach[ie]t?s?|sashi|حبة|حبات|حبه|قطعة|قطع|وحدة|وحدات|ساشي";
  const BXW = "bouat|boites?|bo[iî]tes?|batte|packs?|باطة|باطات|علبة|علب";
  function cnt(str, kw) {
    const t = " " + String(str || "").replace(/[٠-٩]/g, c => c.charCodeAt(0) - 1632) + " ";
    if (new RegExp("\\d\\s*\\+\\s*\\d+\\s*(?:" + kw + ")", "i").test(t)) return 0;   /* «24+48pies» علبة مختلطة: لا نخمّن */
    const m = t.match(new RegExp("(?:^|[^\\d.,])(\\d{1,4})\\s*(?:" + kw + ")(?![a-z\\u0600-\\u06ff])", "i")) || t.match(new RegExp("(?:^|[^a-z\\u0600-\\u06ff])(?:" + kw + ")\\s*(\\d{1,4})(?![\\d.,])", "i"));
    const n = m ? +m[1] : 0; return n > 1 && n <= 5000 ? n : 0;
  }
  function pcInfo(it) {
    const p = prodOf(it), us = (p && p._u) || [], u = us.find(x => x.name === it.Unite) || (us.length === 1 ? us[0] : null);
    const f = u ? +u.factor || 1 : 1, un = it.Unite || (u && u.name) || "", nm = it["Item Name"] || (p && p.name) || "";
    if (f > 1) return f;                                            /* وحدة كبرى: عدد قطعها المسجّل */
    const nu = us.length <= 1 ? (cnt(un, PCW) || cnt(un, BXW)) : 0; /* وحدة وحيدة عددها في اسمها */
    if (nu > 1) return nu;
    const nn = cnt(nm, PCW);                                        /* بالقطعة: العدد من اسم الصنف */
    return nn > 1 ? nn : 0;
  }
  function pcMid(it) {
    const n = pcInfo(it); if (!n) return "";
    const pr = it["Net Price"] != null && it["Net Price"] !== "" ? +it["Net Price"] : +it.Price || 0; if (!(pr > 0)) return "";
    return `<span class="rr-pc" title="سعر القطعة (${n} قطعة)"><em>القطعة</em><b>${E(N2(pr / n))}</b></span>`;
  }
  /* «قبل الخصم / بعد الخصم» الذكي:
     • صنف بوحدتين أو أكثر ← قبل = سعر القطعة المباعة بالقطعة، بعد = سعر القطعة داخل الكرتونة / الفاردو (سعر الكبرى ÷ عدد القطع)
     • صنف بوحدة واحدة ← قبل = سعره، بعد = سعر «5 ومافوق» (أو السعر الخاص المباع به) — وإن لم يتغيّر: «لم يتغيّر سعره» */
  function pbpa(it) {
    const p = prodOf(it), us = p && p._u && p._u.length ? p._u : null, sold = +it.Price || 0, F = u => +u.factor || 1;
    if (us && us.length > 1) {
      const pc = us.reduce((m, u) => F(u) < F(m) ? u : m, us[0]), su = us.find(x => x.name === it.Unite);
      const bg = su && F(su) > F(pc) ? su : bigOf(p), pf = F(pc), bf = F(bg) || 1;
      const b = (su === pc ? sold : +pc.price || 0), a = (su === bg ? sold : +bg.price || 0) / bf * pf;
      return { kind: "u", b, a, hb: "سعر " + (pc.name || "القطعة"), ha: "داخل " + (bg.name || "الكرتونة") + " (" + NQ(bf / pf) + ")", pct: b > 0 ? (1 - a / b) * 100 : 0 };
    }
    const u = us ? us[0] : null, base = +(u && u.price) || +(p && p.price) || sold, p5 = +(u && u.p5) || +(p && p.q5) || 0;
    if (sold && Math.abs(sold - base) > .004) return { kind: "x", b: base, a: sold, hb: "سعر القطعة", ha: p5 && Math.abs(sold - p5) < .005 ? "5 ومافوق" : "سعر خاص", pct: base > 0 ? (1 - sold / base) * 100 : 0 };
    if (p5 > 0 && Math.abs(p5 - base) > .004) return { kind: "q", b: base, a: p5, hb: "سعر القطعة", ha: "5 ومافوق", pct: base > 0 ? (1 - p5 / base) * 100 : 0 };
    return { kind: "same", b: base, a: base, hb: "", ha: "", pct: 0 };
  }
  /* ---------------- الإجماليات ---------------- */
  const TOT = [["count", "عدد القطع", h => NQ(h["Qty Total"])], ["items", "عدد الأصناف", h => String(h["Item Count"] || 0)], ["before", "الحساب", h => N2(h["Before Discount"] || h["Net Amount"])],
    ["disc", "الخصم", h => N2(h.Discount)], ["extra", "الإضافى", h => N2(h.Extra)], ["tax", "الضرائب", h => N2(h.Taxes)], ["net", "الصافى", h => N2(h["Net Amount"])],
    ["paid", "المدفوع", h => N2(h.Paid)], ["remain", "الباقي", h => N2(h.Remain)], ["prev", "الرصيد السابق", h => N2(h["Previous Balance"])], ["cur", "الرصيد الحالي", h => N2(h["Current Balance"])]];
  const logoSrc = (b, co) => { let s = (b && b.lg) || (co && co["Company Logo"]) || ""; s = String(s || "").trim(); if (s && !/^(data:|https?:|blob:|\/|\.)/i.test(s) && /^[A-Za-z0-9+/=\s]{40,}$/.test(s)) s = "data:image/" + (s.startsWith("/9j/") ? "jpeg" : "png") + ";base64," + s.replace(/\s+/g, ""); return s; };
  const HEADF = [["logo", "الشعار"], ["name", "اسم الشركة"], ["act", "النشاط"], ["phone", "الهاتف"], ["mobile", "الجوال"], ["addr", "العنوان"], ["nif", "NIF / RC"]];
  const TITF = [["tx", "نوع الفاتورة"], ["no", "رقم الفاتورة"], ["date", "التاريخ"], ["time", "الوقت"], ["cust", "العميل"], ["cphone", "هاتف العميل"], ["user", "المستخدم"], ["pay", "طريقة الدفع"]];
  const BLK = { sign: "التوقيع والختم", head: "رأس الإيصال", title: "بيانات الفاتورة", items: "الأصناف", totals: "الإجماليات", words: "المبلغ بالحروف", notes: "الملاحظات", text: "سطر نص", sep: "فاصل", code: "باركود الفاتورة", foot: "التذييل" };
  if (C.a4) Object.assign(BLK, { head: "رأس الفاتورة", info: "بطاقة الفاتورة · العميل + Total Sales" });
  Object.assign(BLK, { pay: "سطر الدفع · الخزينة + سياسة التعامل", pfoot: "تذييل الصفحة · الشعار + باركود + رقم الصفحة" });
  const PAYF = [["amt", "المبلغ"], ["cur", "العملة DZD"], ["type", "نقدي / آجل"], ["tre", "الخزينة"], ["pol", "سياسة التعامل"], ["t2", "نص إضافي"]];
  const SOC = { note: ["TikTok", '<path d="M14 3v10.5a3.5 3.5 0 1 1-3.5-3.5" /><path d="M14 3c.6 2.6 2.4 4.3 5 4.6"/>'], cam: ["Instagram", '<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r=".9" fill="currentColor"/>'], fb: ["Facebook", '<path d="M14.5 21v-7.5H17l.5-3h-3V8.6c0-.9.3-1.6 1.6-1.6h1.5V4.3c-.3 0-1.2-.1-2.3-.1-2.3 0-3.8 1.4-3.8 3.9v2.4H9v3h2.5V21"/>'], chat: ["WhatsApp", '<path d="M20 11.6a8 8 0 0 1-11.8 7L4 20l1.4-4A8 8 0 1 1 20 11.6z"/>'], web: ["Web", '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.6 2.6 2.6 14.4 0 17M12 3.5c-2.6 2.6-2.6 14.4 0 17"/>'], tel: ["هاتف", '<path d="M5 4h3.5l1.6 4-2.2 1.4a11 11 0 0 0 4.7 4.7l1.4-2.2 4 1.6V19a1.5 1.5 0 0 1-1.6 1.5A15.5 15.5 0 0 1 3.5 5.6 1.5 1.5 0 0 1 5 4z"/>'], none: ["بدون", ""] };
  const socSvg = (k, px) => { const v = SOC[k] || SOC.note; return v[1] ? `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"${px ? ` width="${px}" height="${px}"` : ""} fill="none" stroke="#000" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round">${v[1]}</svg>` : ""; };
  const pfH = d => d.w < 180 ? 11 : 13;
  const pfOn = d => d.a4 && (d.blocks || []).some(b => b.t === "pfoot" && b.on);
  const padB = d => pfOn(d) ? d.pad + pfH(d) : d.pad;
  function pfBar(b, h, co) {
    const no = String(h.Number || "0"), bc = b.code !== 0 && window.__BCP && __BCP.linSvg ? __BCP.linSvg(no) : "";
    return `<span class="pf-br">${E(b.brand == null ? "ANOUER" : b.brand)}</span>${bc ? `<span class="pf-bc">${bc}<i>${E(no)}</i></span>` : ""}<span class="pf-rt">${b.pg !== 0 ? '<b class="pf-pg">1/1</b>' : ""}${b.soc !== "none" && (b.handle || "") !== "" ? `<span class="pf-so">${socSvg(b.soc)}<em>${E(b.handle)}</em></span>` : ""}</span>`;
  }
  /* تذييل الصفحة عند الطباعة: «صناديق الهامش» (@page) — يتكرّر أسفل كل صفحة مع رقمها 1/2 … */
  function pfPageCSS(d, h) {
    const b = (d.blocks || []).find(x => x.t === "pfoot" && x.on); if (!b) return "";
    const q = t => '"' + String(t || "").replace(/\\/g, "").replace(/"/g, "'").replace(/[\r\n]+/g, " ") + '"';
    const u = svg => `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
    const no = String(h.Number || "0"); let bc = "";
    if (b.code !== 0 && window.__BCP && __BCP.linSvg) { const inner = __BCP.linSvg(no).replace('<svg xmlns="http://www.w3.org/2000/svg" ', '<svg x="0" y="0" width="150" height="30" '); bc = `<svg xmlns="http://www.w3.org/2000/svg" width="150" height="44">${inner}<text x="75" y="42" text-anchor="middle" font-family="Arial" font-size="11" font-weight="700">${E(no)}</text></svg>`; }
    const ic = b.soc !== "none" && b.handle ? socSvg(b.soc, 16) : "";
    const R = [b.pg !== 0 ? 'counter(page) "/" counter(pages)' : "", ic ? `"      " ${u(ic)} " " ${q(b.handle)}` : (b.handle && b.soc !== "none" ? q("      " + b.handle) : "")].filter(Boolean).join(" ");
    return `@bottom-left{content:${q(b.brand == null ? "ANOUER" : b.brand)};font:900 10pt Arial,sans-serif;vertical-align:middle;direction:ltr}${bc ? `@bottom-center{content:${u(bc)};vertical-align:middle}` : ""}${R ? `@bottom-right{content:${R};font:700 9pt Arial,sans-serif;vertical-align:middle;direction:ltr}` : ""}`;
  }
  const INFF = [["tx", "نوع الفاتورة"], ["cust", "اسم العميل"], ["cphone", "هاتف العميل"], ["no", "رقم الفاتورة"], ["date", "التاريخ"], ["time", "الوقت"], ["user", "المستخدم"], ["prev", "الرصيد السابق"], ["total", "Total Sales"], ["qr", "رمز QR"]];

  /* ---------------- التصميم ---------------- */
  const seed = () => C.a4 ? seedA4() : seedR();
  const A5 = C.fmt === "A5";
  function seedR() {
    return { id: "r" + Date.now().toString(36), name: "إيصال كاشير 80 مم", w: 80, pad: 3, fs: 9, sep: "dash", use: 0,
      blocks: [
        { id: uid(), t: "head", on: 1, al: "c", fs: 15, f: { name: 1, act: 1, phone: 1, mobile: 1, addr: 0, nif: 0 } },
        { id: uid(), t: "sep", on: 1 },
        { id: uid(), t: "title", on: 1, f: { tx: 1, no: 1, date: 1, time: 1, cust: 1, cphone: 0, user: 1, pay: 0 } },
        { id: uid(), t: "items", on: 1, mode: "two", hdr: 1, zebra: 0, nameFs: 9.5,
          cols: [{ k: "name", on: 1, w: 34 }, { k: "unit", on: 1, w: 12 }, { k: "qty", on: 1, w: 10 }, { k: "price", on: 1, w: 14 }, { k: "total", on: 1, w: 16 }, { k: "code", on: 0, w: 16 }, { k: "disc", on: 0, w: 12 }],
          lines: [["qty", "×", "price", "=", "total"]] },
        { id: uid(), t: "totals", on: 1, rows: TOT.map(x => ({ k: x[0], on: ["count", "before", "disc", "net", "paid", "remain", "prev", "cur"].includes(x[0]) ? 1 : 0, b: ["net", "cur"].includes(x[0]) ? 1 : 0 })) },
        { id: uid(), t: "words", on: 0 },
        { id: uid(), t: "notes", on: 1 },
        { id: uid(), t: "code", on: 0 },
        { id: uid(), t: "foot", on: 1, text: "شكراً لزيارتكم — تأكد من السلعة قبل المغادرة" }],
      imgs: [] };
  }
  function seedA4() {
    const col = (k, w, on) => ({ k, on: on == null ? 1 : on, w });
    return { id: "a" + Date.now().toString(36), name: A5 ? "فاتورة A5" : "فاتورة A4", a4: 1, w: A5 ? 148 : 210, h: A5 ? 210 : 297, pad: A5 ? 6 : 9, fs: A5 ? 8 : 10, sep: "solid", acc: "#c2410c", use: 0,
      blocks: [
        { id: uid(), t: "head", on: 1, al: "r", fs: A5 ? 19 : 26, f: { name: 1, act: 1, phone: 1, mobile: 1, addr: 1, nif: 1 } },
        { id: uid(), t: "info", on: 1, f: { tx: 1, cust: 1, cphone: 1, no: 1, date: 1, time: 1, user: 0, prev: 1, total: 1, qr: 1 } },
        { id: uid(), t: "items", on: 1, mode: "table", hdr: 1, zebra: 0, pblk: 1, hint: 1, nameFs: A5 ? 8.5 : 10.5,
          cols: [col("idx", 4), col("name", 30), col("qty", 7), col("unit", 9), col("price", 9), col("pb", 11), col("pa", 11), col("total", 11), col("code", 10, 0), col("disc", 8, 0)],
          lines: [["qty", "×", "price", "=", "total"]] },
        { id: uid(), t: "totals", on: 1, rows: TOT.map(x => ({ k: x[0], on: ["count", "before", "disc", "net", "paid", "remain", "prev", "cur"].includes(x[0]) ? 1 : 0, b: x[0] === "net" ? 1 : 0 })) },
        { id: uid(), t: "words", on: 1 },
        payBlk(),
        { id: uid(), t: "notes", on: 1 },
        { id: uid(), t: "sign", on: 1, mode: "two", lab1: "توقيع وختم البائع", lab2: "توقيع العميل", date: 1, stamp: 1 },
        { id: uid(), t: "foot", on: 0, text: "شكراً لثقتكم — تسعدنا زيارتكم" },
        pfBlk()],
      imgs: [], mig1: 1 };
  }
  function payBlk() { return { id: uid(), t: "pay", on: 1, f: { amt: 1, cur: 1, type: 1, tre: 1, pol: 1, t2: 1 }, t2: "تسعدنا زيارتكم" }; }
  function pfBlk() { return { id: uid(), t: "pfoot", on: 1, brand: "ANOUER", code: 1, pg: 1, soc: "note", handle: "" }; }
  let DS = LS.get(C.K + ".designs", null); if (!Array.isArray(DS) || !DS.length) DS = [seed()];
  if (C.a4) DS.forEach(d => { if (d.mig1) return; d.mig1 = 1; if (!d.blocks.some(b => b.t === "pay")) { const i = d.blocks.findIndex(b => b.t === "notes" || b.t === "sign"); d.blocks.splice(i >= 0 ? i : d.blocks.length, 0, payBlk()); } if (!d.blocks.some(b => b.t === "pfoot")) d.blocks.push(pfBlk()); });
  let D = DS.find(x => x.id === LS.get(C.K + ".cur", "")) || DS[0], DATA = null, OV = null, zoom = LS.get(C.K + ".zoom", C.z), open1 = null, selImg = null, saveT = 0;
  const persist = () => { clearTimeout(saveT); saveT = setTimeout(() => { if (!LS.set(C.K + ".designs", DS)) say("مساحة الحفظ ممتلئة — صغّر الصور أو احذف بعضها", "w"); LS.set(C.K + ".cur", D.id); }, 250); };

  /* ---------------- بيانات المعاينة ---------------- */
  function sample() {
    const L = PRODS().slice(0, C.a4 ? (A5 ? 6 : 9) : 3), now = new Date();
    const items = (L.length ? L : [{ name: "CAPRICE 140P باطة (زيقومار كرميل شوكو+طوفي)", code: "CP140", price: 620 }, { name: "SICOGE 200P علك باطة", code: "SG200", price: 500 }])
      .map((p, i) => { const u = (p._u && (p._u.find(x => x.def) || p._u[0])) || { name: p.unit || "قطعة" }; const pr = +u.price || +p.price || 0, q = i + 1; return { "Item Code": p.code, Barcode: u.bc || p.code, "Item Name": p.name, Unite: u.name, Qty: q, Price: pr, "Net Price": pr, "Item Discount": 0, Total: pr * q, Index: i + 1 }; });
    const net = items.reduce((s, x) => s + x.Total, 0);
    return { company: { "Company Name": "ANOUER", "Company Phone": "", "Company Mobile": "", "Company Address": "", Activity: "بيع بالجملة والتجزئة" },
      header: { Number: "77846", Transaction: "مبيعات", Date: now.toISOString().slice(0, 10), Time: now.toTimeString().slice(0, 8), "Customer Name": "عميل نقدي", WrittenBy: "ANOUER 4", "Payment Method": "نقدى",
        "Before Discount": net, Discount: 0, Extra: 0, Taxes: 0, "Net Amount": net, Paid: net, Remain: 0, "Previous Balance": 0.5, "Current Balance": 0.5, "Qty Total": items.reduce((s, x) => s + x.Qty, 0), "Item Count": items.length, "Amount In Words": "", Notes: "" }, items };
  }
  const dataNow = () => DATA || (() => { try { if (window.ANOUER_RD && ANOUER_RD.dataFromCurrentSale && (window.rows || (typeof rows !== "undefined" ? rows : [])).some(r => r && r.pid)) { const d = ANOUER_RD.dataFromCurrentSale(); d.company = d.company || CO; return d; } } catch (e) { } return sample(); })();
  function loadCo() { try { if (window.ANOUER_RD && ANOUER_RD.company) ANOUER_RD.company().then(c => { CO = c; if (OV && OV.classList.contains("show")) draw(); }).catch(() => { }); } catch (e) { } }

  /* ---------------- رسم الإيصال (للمعاينة وللطباعة) ---------------- */
  /* ✦ «الخصائص ← الفواتير ← تصميم الفاتورة»: مفاتيح عامة فوق كل التصاميم (الإيصال و A4) — بدون تعديل التصميم المحفوظ */
  function invDesign() { let v = {}; try { v = (window.ANOUER_PROPS && ANOUER_PROPS.get("inv.design", {})) || {}; } catch (e) { } const on = k => v[k] !== false;
    return { tafqit: on("tafqit"), payWay: on("payWay"), serials: on("serials"), qr: on("qr"), thanks: on("thanks"), donMsg: on("donMsg"), policy: on("policy"), coAddr: on("coAddr"), coPhone: on("coPhone"), coTax: on("coTax"),
      thanksTxt: v.thanksTxt !== undefined ? String(v.thanksTxt) : "شكراً لزيارتكم", donTxt: String(v.donTxt || ""), polTxt: v.polTxt !== undefined ? String(v.polTxt) : "البضاعة المباعة لا ترد ولا تستبدل" }; }
  function applyInv(d, data) {
    const P = invDesign(); d = JSON.parse(JSON.stringify(d)); data = Object.assign({}, data);
    d.blocks.forEach(b => { const f = b.f = b.f || {};
      if (b.t === "words" && !P.tafqit) b.on = 0;
      if (b.t === "head") { if (!P.coAddr) f.addr = 0; if (!P.coPhone) { f.phone = 0; f.mobile = 0; } if (!P.coTax) f.nif = 0; }
      if (b.t === "title" && !P.payWay) f.pay = 0;
      if (b.t === "pay") { if (!P.payWay) f.type = 0; if (!P.policy) f.pol = 0; }
      if (b.t === "info" && !P.qr) f.qr = 0;
      if (b.t === "foot" && !P.thanks) b.on = 0; });
    d.__noSqr = !P.qr;
    /* الأرقام التسلسلية تحت اسم الصنف */
    data.items = (data.items || []).map(it => it && it.Serials ? Object.assign({}, it, { "Item Name": P.serials ? it["Item Name"] + "  ·  S/N: " + it.Serials : it["Item Name"] }) : it);
    /* أسطر الرسائل: الشكر (إن لم يكن في التصميم تذييل) ، التبرعات ، سياسة التعامل */
    const L = [];
    if (P.thanks && P.thanksTxt.trim() && !d.blocks.some(b => b.on && b.t === "foot")) L.push(["thx", P.thanksTxt]);
    if (P.donMsg && P.donTxt.trim()) L.push(["don", P.donTxt]);
    if (P.policy && P.polTxt.trim()) L.push(["pol", P.polTxt]);
    d.__msgs = L;
    return [d, data];
  }
  function receiptHTML(d, data, edit) {
    if (!edit && !d.__inv) { const a = applyInv(d, data); d = a[0]; data = a[1]; d.__inv = 1; }
    const h = data.header || {}, co = Object.assign({}, sample().company, CO || {}, data.company || {}), its = data.items || [];
    const sepCls = d.sep === "solid" ? "s" : d.sep === "dot" ? "o" : "d";
    /* مكان العلامة المائية في الإيصال: مع الإجماليات (افتراضي — تبقى في الأسفل مهما طالت الفاتورة) / أسفل / وسط / أعلى */
    const wmA = !d.a4 && d.wm && d.wm.on && !d.wm.rep ? (d.wm.anc || "tot") : "c";
    const wmIn = wmA === "tot" && d.blocks.some(x => x.t === "totals" && x.on);
    const blk = b => {
      if (!b.on) return "";
      const wrap = inner => `<section class="rr-b t-${b.t}"${edit ? ` data-b="${b.id}"` : ""}>${wmIn && b.t === "totals" ? wmHTML(d, h, co, its.length, edit, "in") : ""}${inner}</section>`;
      switch (b.t) {
        case "head": { const f = b.f || {}, L = [], lg = f.logo !== 0 ? logoSrc(b, co) : "", lpos = b.lgPos || (d.a4 ? "l" : "top");
          if (f.name) L.push(`<div class="rr-co" style="font-size:${b.fs || 15}pt">${E(co["Company Name"])}</div>`);
          if (f.act && co.Activity) L.push(`<div class="rr-sm">${E(co.Activity)}</div>`);
          const ph = [f.phone && co["Company Phone"], f.mobile && co["Company Mobile"]].filter(Boolean);
          if (ph.length) L.push(`<div class="rr-ph">${ph.map(x => `<span>☎ ${E(x)}</span>`).join("")}</div>`);
          if (f.addr && co["Company Address"]) L.push(`<div class="rr-sm">${E(co["Company Address"])}</div>`);
          if (f.nif && (co.NIF || co.RC)) L.push(`<div class="rr-sm">${co.NIF ? "NIF: " + E(co.NIF) : ""} ${co.RC ? "RC: " + E(co.RC) : ""}</div>`);
          const ta = `text-align:${b.al === "r" ? "right" : b.al === "l" ? "left" : "center"}`;
          const lgH = +b.lgH || (d.a4 ? 22 : 16), img = lg ? `<img class="rr-lg${b.lgBw === 0 || (b.lgBw == null && d.a4) ? "" : " bw"}" src="${E(lg)}" alt="" style="max-height:${lgH}mm">`
            : (edit && f.logo !== 0 ? `<div class="rr-lg0" style="height:${Math.min(lgH, 14)}mm"><span>＋ الشعار</span></div>` : "");
          if (img && lpos !== "top") return wrap(`<div class="rr-head rr-hs ${lpos === "r" ? "lg-r" : "lg-l"} al-${b.al || "c"}"><div class="rr-lgw">${img}</div><div class="rr-ht" style="${ta}">${L.join("")}</div></div>`);
          return wrap(`<div class="rr-head al-${b.al || "c"}" style="${ta}">${img ? `<div class="rr-lgw top">${img}</div>` : ""}${L.join("")}</div>`); }
        case "title": { const f = b.f || {}, kv = [];
          if (f.date) kv.push(["التاريخ", h.Date]); if (f.time) kv.push(["الوقت", h.Time]); if (f.no) kv.push(["رقم الفاتورة", h.Number]);
          if (f.cust) kv.push(["العميل", h["Customer Name"]]); if (f.cphone && h["Customer Phone"]) kv.push(["هاتف العميل", h["Customer Phone"]]); if (f.user) kv.push(["المستخدم", h.WrittenBy]); if (f.pay) kv.push(["الدفع", h["Payment Method"]]);
          return wrap(`${f.tx ? `<div class="rr-tx">${E(h.Transaction || "فاتورة")}</div>` : ""}<div class="rr-kv">${kv.map(x => `<div><span>${E(x[0])}</span><b>${E(x[1] || "")}</b></div>`).join("")}</div>`); }
        case "items": {
          const cols = (b.cols || []).filter(c => c.on), tw = cols.reduce((s, c) => s + (+c.w || 10), 0) || 1;
          const gt = cols.map(c => ((+c.w || 10) / tw * 100).toFixed(2) + "%").join(" ");
          if (b.mode === "table" && d.a4) return wrap(a4Table(b, cols, tw, its));
          if (b.mode === "table") {
            return wrap(`<div class="rr-tb">${b.hdr ? `<div class="rr-tr rr-th" style="grid-template-columns:${gt}">${cols.map(c => `<div class="c-${c.k}">${E(TOK[c.k])}</div>`).join("")}</div>` : ""}
              ${its.map((it, i) => `<div class="rr-tr${b.zebra && i % 2 ? " z" : ""}" style="grid-template-columns:${gt}">${cols.map(c => `<div class="c-${c.k}">${c.k === "price" && b.dsc !== 0 && dscOf(it) ? dscPrice(it, i) : E(tokVal(c.k, it, i))}</div>`).join("")}</div>`).join("")}</div>`);
          }
          const lines = (b.lines || []).filter(l => l && l.length);
          return wrap(`<div class="rr-two">${b.hdr ? `<div class="rr-th2"><span>الصنف</span><span>الحساب</span></div>` : ""}${its.map((it, i) => `<div class="rr-it${b.zebra && i % 2 ? " z" : ""}"><div class="rr-nm" style="font-size:${b.nameFs || 9.5}pt">${E(it["Item Name"])}${b.dsc !== 0 && dscOf(it) ? `<span class="rr-dtg">خصم ${E(N2(dscOf(it).all))}${dscOf(it).pct >= 0.5 ? ` · <bdi dir="ltr">−${Math.round(dscOf(it).pct)}%</bdi>` : ""}</span>` : ""}</div>${lines.map(l => { const pc = b.pcm !== 0 && l.includes("total") ? pcMid(it) : ""; return `<div class="rr-ln">${l.map(t => (t === "total" ? pc : "") + (OPS.includes(t) ? `<i class="op">${E(t)}</i>` : (t === "price" && b.dsc !== 0 ? dscPrice(it, i) : TOK[t] ? `<span class="tk t-${t}">${E(tokVal(t, it, i))}</span>` : `<span class="lt">${E(String(t).replace(/^"|"$/g, ""))}</span>`))).join("")}</div>`; }).join("")}</div>`).join("")}</div>`);
        }
        case "totals": return wrap(`<div class="rr-tot">${(b.rows || []).filter(r => r.on).map(r => { const x = TOT.find(z => z[0] === r.k); return x ? `<div class="${r.b ? "bd" : ""}"><span>${E(x[1])}</span><b>${E(x[2](h))}</b></div>` : ""; }).join("")}</div>`);
        case "words": { const w = String(h["Amount In Words"] || ""); return d.a4 ? wrap(`<div class="rr-words"><span>فقط</span>${w ? E(w.replace(/^فقط\s*:?\s*/, "")) : (edit ? '<i class="rr-ph0">المبلغ بالحروف يظهر هنا</i>' : "")}</div>`) : wrap(`<div class="rr-words">${E(w)}</div>`); }
        case "pay": {
          const f = b.f || {}; let x = h; try { if (window.ANOUER_RD && ANOUER_RD.dexData) x = ANOUER_RD.dexData({ header: h, company: co, items: [] }).header || h; } catch (e) { }
          const amt = x["Amount Short"] || N2(h["Net Amount"]), typ = x["Payment Type"] || ((+h.Remain || 0) > .004 ? "آجل" : "نقدي");
          const c = [f.tre && `<span class="py-tr">${E(x.Treasury || "الخزينة الرئيسية")}</span>`, f.type && `<span class="py-ty">${E(typ)}</span>`, f.cur && `<b class="py-cu">${E(x["Currency Code"] || "DZD")}</b>`, f.amt && `<b class="py-am">${E(amt)}</b>`].filter(Boolean).join("");
          const t = [f.pol && `<span>${E(x["Payment Policy Line"] || ("سياسة التعامل " + (x["Payment Policy"] || (typ === "آجل" ? "آجل" : "كاش بدون احراج"))))}</span>`, f.t2 && b.t2 && `<span>${E(b.t2)}</span>`].filter(Boolean).join("");
          return wrap(`${c ? `<div class="rr-py">${c}</div>` : ""}${t ? `<div class="rr-pyt">${t}</div>` : ""}`);
        }
        case "pfoot": return d.a4 ? "" : wrap(`<div class="rr-pf inl">${pfBar(b, h, co)}</div>`);
        case "info": {
          const f = b.f || {}, tr = (k, v) => `<tr><th>${E(k)}</th><td>${E(v == null ? "" : v)}</td></tr>`;
          const cu = [f.cust && tr("السيد", h["Customer Name"] || "عميل نقدي"), f.cphone && tr("التليفون", h["Customer Phone"] || "")].filter(Boolean).join("");
          const iv = [f.no && tr("رقم الفاتورة", h.Number), f.date && tr("التاريخ", h.Date), f.time && tr("الوقت", h.Time), f.user && tr("المستخدم", h.WrittenBy)].filter(Boolean).join("");
          /* ✦ QR = رابط المتجر الإلكتروني (من «ربط المتجر») — وإلا بيانات الفاتورة كما كان */
          const su = String(co["Store Url"] || "").trim(), sh = su.replace(/^https?:\/\//i, "").replace(/\/+$/, "");
          const qr = f.qr && window.__BCP && __BCP.qrSvg ? __BCP.qrSvg(su || `${co["Company Name"] || "ANOUER"} | ${h.Number || ""} | ${h.Date || ""} | ${N2(h["Net Amount"])}`) : "";
          return wrap(`<div class="rai">
            <div class="ai-r">${cu ? `<table class="ai-t">${cu}</table>` : ""}${iv ? `<table class="ai-t">${iv}</table>` : ""}</div>
            <div class="ai-m">${f.tx ? `<div class="ai-tx">${E(h.Transaction || "فاتورة")}</div>` : ""}${f.prev ? `<div class="ai-pb"><span>الرصيد السابق<small>Previous Balance</small></span><b>${N2(h["Previous Balance"])}</b></div>` : ""}${f.total ? `<div class="ai-ts"><small>Total Sales · إجمالي الفاتورة</small><b>${N2(h["Net Amount"])}</b></div>` : ""}</div>
            ${qr ? (su ? `<div class="ai-q ai-qs">${qr}<small>امسح وتسوّق</small><i dir="ltr">${E(sh)}</i></div>` : `<div class="ai-q">${qr}<small>${E(h.Number || "")}</small></div>`) : ""}</div>`);
        }
        case "notes": return h.Notes || h["Customer Address"] ? wrap(`<div class="rr-notes">${h.Notes ? `<div>ملاحظات: ${E(h.Notes)}</div>` : ""}${h["Customer Address"] ? `<div>العنوان: ${E(h["Customer Address"])}</div>` : ""}</div>`) : (edit ? wrap('<div class="rr-notes rr-ph0">الملاحظات / العنوان (تظهر عند وجودها)</div>') : "");
        case "text": return wrap(`<div class="rr-text" style="text-align:${b.al === "r" ? "right" : b.al === "l" ? "left" : "center"};font-size:${b.fs || 9}pt;font-weight:${b.b ? 800 : 400}">${E(b.text || "")}</div>`);
        case "sep": return wrap(`<hr class="rr-sep ${sepCls}">`);
        case "code": { const s = window.__BCP && __BCP.linSvg ? __BCP.linSvg(String(h.Number || "0")) : ""; return wrap(`<div class="rr-code">${s}<div>${E(h.Number)}</div></div>`); }
        case "foot": return wrap(`<div class="rr-foot">${E(b.text || "")}</div>`);
        case "sign": {
          const cell = (side, lab, src) => `<div class="rr-sg ${side}">${src ? `<img class="sgi" src="${src}" alt="">` : '<i class="sgs"></i>'}<div class="sgl"></div><div class="sgt">${E(lab || "")}</div>${side === "s" && b.date ? `<div class="sgd">${E(h.Date || "")} ${E(String(h.Time || "").slice(0, 5))}</div>` : ""}${side === "s" && b.stamp ? stampSvg(b, co) : ""}</div>`;
          return wrap(`<div class="rr-sgw${b.mode === "one" ? " one" : ""}">${cell("s", b.lab1 || "توقيع البائع", b.src)}${b.mode === "one" ? "" : cell("c", b.lab2 || "توقيع العميل", "")}</div>`);
        }
      }
      return "";
    };
    /* ✦ QR المتجر الإلكتروني في آخر كل إيصال/فاتورة (إن لم يكن ظاهراً في مربع المعلومات) */
    const sUrl = String(co["Store Url"] || "").trim(), sHost = sUrl.replace(/^https?:\/\//i, "").replace(/\/+$/, "");
    const infoQr = d.blocks.some(x => x.on && x.t === "info" && x.f && x.f.qr);
    const sqr = sUrl && !infoQr && !d.__noSqr && window.__BCP && __BCP.qrSvg ? `<section class="rr-b t-sqr"><div class="rr-sqr">${__BCP.qrSvg(sUrl)}<div class="sq-t"><b>امسح وتسوّق أونلاين</b><span>اطلب من الموبايل · التوصيل لـ 58 ولاية</span><i dir="ltr">${E(sHost)}</i></div></div></section>` : "";
    const msgs = (d.__msgs || []).length ? `<section class="rr-b t-msgs">${d.__msgs.map(m => `<div class="rr-msg m-${m[0]}">${E(m[1])}</div>`).join("")}</section>` : "";
    /* ✦ (2026-11-22) شريط «تابعونا» — فيسبوك · يوتيوب · تيك توك (من «إعدادات النظام» Ctrl+O) في آخر كل إيصال */
    let soc = ""; try { const so = window.ANOUER_RD && ANOUER_RD.socialHTML && d.social !== 0 ? ANOUER_RD.socialHTML(co, { wide: !!d.a4, cw: (+d.w || 80) - 2 * (+d.pad || 0) }) : null; if (so) soc = `<section class="rr-b t-soc" style="margin-top:2mm">${so.html}</section>`; } catch (e) { }
    const imgs = (d.imgs || []).map(m => `<img class="rr-img${edit && m.id === selImg ? " sel" : ""}"${edit ? ` data-img="${m.id}"` : ""} src="${m.src}" alt="" style="left:${m.x}mm;top:${m.y}mm;width:${m.w}mm;opacity:${m.op == null ? 1 : m.op}" draggable="false">`).join("");
    return `<div class="rr${d.a4 ? " a4" + (d.w < 180 ? " a5" : "") : ""}" style="width:${d.w}mm;${d.a4 ? `min-height:${d.h || 297}mm;--acc:${d.acc || "#c2410c"};` : ""}padding:${d.pad}mm ${d.pad}mm ${padB(d)}mm;font-size:${d.fs}pt">${wmIn ? "" : wmHTML(d, h, co, its.length, edit, wmA === "tot" ? "bot" : wmA)}${d.a4 ? `<div class="rr-in">${d.blocks.map(blk).join("")}${msgs}${sqr}${soc}${imgs}</div>` : d.blocks.map(blk).join("") + msgs + sqr + soc + imgs}${pfOn(d) ? (() => { const b = d.blocks.find(x => x.t === "pfoot" && x.on); return `<div class="rr-pf scr"${edit ? ` data-b="${b.id}"` : ""} style="left:${d.pad}mm;right:${d.pad}mm;bottom:${r1(d.pad / 2)}mm;height:${pfH(d)}mm">${pfBar(b, h, co)}</div>`; })() : ""}</div>`;
  }
  /* جدول أصناف A4 (جدول حقيقي: عناوينه تتكرر في كل صفحة عند الطباعة) */
  function a4Table(b, cols, tw, its) {
    const cg = cols.map(c => `<col style="width:${((+c.w || 10) / tw * 100).toFixed(2)}%">`).join("");
    const cell = (k, it, i, q) => {
      if (k === "pb") return `${N2(q.b)}${b.hint && q.hb ? `<small>${E(q.hb)}</small>` : ""}`;
      if (k === "pa") return q.kind === "same" ? '<span class="rsame">لم يتغيّر سعره</span>' : `${N2(q.a)}${b.hint && q.ha ? `<small>${E(q.ha)}</small>` : ""}${q.pct >= .5 ? `<em class="rsv" dir="ltr">−${Math.round(q.pct)}%</em>` : ""}`;
      if (k === "price" && b.dsc !== 0 && dscOf(it)) return dscPrice(it, i);
      return E(tokVal(k, it, i));
    };
    const body = its.map((it, i) => {
      const q = pbpa(it); let r = "";
      for (let j = 0; j < cols.length; j++) {
        const k = cols[j].k, nx = cols[j + 1] && cols[j + 1].k;
        if (q.kind === "same" && ((k === "pb" && nx === "pa") || (k === "pa" && nx === "pb"))) { r += `<td colspan="2" class="c-same"><span class="rsame">✓ لم يتغيّر سعره</span></td>`; j++; continue; }
        r += `<td class="c-${k}"${k === "name" ? ` style="font-size:${b.nameFs || 10.5}pt"` : ""}>${cell(k, it, i, q)}</td>`;
      }
      return `<tr>${r}</tr>`;
    }).join("");
    return `<table class="rr-at${b.zebra ? " rz" : ""}${b.pblk ? " rblk" : ""}"><colgroup>${cg}</colgroup>${b.hdr ? `<thead><tr>${cols.map(c => `<th class="c-${c.k}">${E(c.lab || TOK[c.k])}</th>`).join("")}</tr></thead>` : ""}<tbody>${body}</tbody></table>`;
  }
  /* ---------------- الختم الإلكتروني (SVG) ---------------- */
  function stampSvg(b, co) {
    const c = b.stc || "#1d4ed8", t = E((b.stt || co["Company Name"] || "ANOUER").toUpperCase()), id = "stp" + Math.random().toString(36).slice(2, 7), mid = E(b.stm || "مختوم");
    return `<svg class="rr-stamp" viewBox="0 0 120 120" style="transform:rotate(${b.str == null ? -14 : b.str}deg)"><defs><path id="${id}" d="M60 60m-43 0a43 43 0 1 1 86 0a43 43 0 1 1 -86 0"/></defs>
      <circle cx="60" cy="60" r="56" fill="none" stroke="${c}" stroke-width="4"/><circle cx="60" cy="60" r="49" fill="none" stroke="${c}" stroke-width="1.5"/><circle cx="60" cy="60" r="31" fill="none" stroke="${c}" stroke-width="1.5"/>
      <text font-size="12.5" font-weight="900" fill="${c}" font-family="Arial Black,Arial,sans-serif" letter-spacing="1.5"><textPath href="#${id}" startOffset="50%" text-anchor="middle">★ ${t} ★ ${t} ★</textPath></text>
      <text x="60" y="58" font-size="13" font-weight="900" fill="${c}" text-anchor="middle" font-family="Droid Arabic Kufi,Arial,sans-serif">${mid}</text>
      <text x="60" y="74" font-size="8.5" font-weight="700" fill="${c}" text-anchor="middle" font-family="Arial,sans-serif">${E(new Date().toISOString().slice(0, 10))}</text></svg>`;
  }
  /* ---------------- العلامة المائية ---------------- */
  const WM_PICK = ["مدفوع", "غير مدفوع", "نسخة", "COPY", "أصلي", "مرتجع", "ANOUER"];
  const wmDef = () => ({ on: 0, type: "text", text: "", smart: 0, fs: 30, rot: -30, op: .12, rep: 0, front: 0, color: "#000", src: "", w: 60, ff: "Droid Arabic Kufi", fw: 900, ls: .5, it: 0, sty: "fill", sk: .25, sc: "#000" });
  function wmText(wm, h, co) {
    if (wm.smart) { const tx = String(h.Transaction || ""); if (/مرتجع/.test(tx)) return "مرتجع"; return (+h.Remain || 0) > 0.004 ? "غير مدفوع" : "مدفوع"; }
    return wm.text || co["Company Name"] || "ANOUER";
  }
  /* العلامة المائية: حرية الحركة (x / y بالملّيمتر من المنتصف) + الحجم + الزاوية — في المحرّر: اسحب / الدائرة الوردية للحجم / العلوية للتدوير */
  /* ✍️ خطوط العلامة المائية (تُعرض فقط الخطوط المثبّتة فعلاً على الجهاز) */
  const WM_FONTS = [["Droid Arabic Kufi", "كوفي"], ["Tahoma", "Tahoma"], ["Segoe UI", "Segoe"], ["Arial", "Arial"], ["Arial Black", "Arial Black"], ["Times New Roman", "Times"], ["Traditional Arabic", "تقليدي"], ["Simplified Arabic", "مبسّط"], ["Sakkal Majalla", "مجلّة"], ["Arabic Typesetting", "نسخ"], ["Calibri", "Calibri"], ["Impact", "Impact"], ["Georgia", "Georgia"], ["Courier New", "Courier"]];
  let FOK = null;
  const fontsOK = () => {
    if (FOK) return FOK;
    try {
      const g = document.createElement("canvas").getContext("2d"), t = "أبجد هوز ANOUER 0123", w = f => { g.font = "40px " + f; return g.measureText(t).width; };
      const bm = w("monospace"), bs = w("serif"), bn = w("sans-serif");
      FOK = WM_FONTS.filter(([f]) => w(`'${f}',monospace`) !== bm || w(`'${f}',serif`) !== bs || w(`'${f}',sans-serif`) !== bn);
    } catch (e) { FOK = WM_FONTS.slice(); }
    if (!FOK.some(f => f[0] === WM_FONTS[0][0])) FOK.unshift(WM_FONTS[0]);   // خط البرنامج الافتراضي دائماً
    return FOK;
  };
  const WM_COLORS = ["#000000", "#4b5563", "#9ca3af", "#b91c1c", "#ea580c", "#b8860b", "#15803d", "#0e7490", "#1d4ed8", "#6d28d9", "#be185d"];
  /* نمط نص العلامة: الخط · السماكة · التباعد · مائل · ممتلئ / مفرّغ / بحدّ */
  function wmTS(wm) {
    const ff = `'${String(wm.ff || "Droid Arabic Kufi").replace(/['"<>;]/g, "")}','Droid Arabic Kufi','Arial Black',sans-serif`;
    const fw = Math.max(100, Math.min(900, +wm.fw || 900)), ls = r1(wm.ls == null ? .5 : +wm.ls), col = wm.color || "#000", sk = Math.max(0, +wm.sk || 0);
    let s = `font-family:${ff};font-weight:${fw};letter-spacing:${ls}mm;font-style:${wm.it ? "italic" : "normal"};`;
    if (wm.sty === "line") s += `color:transparent;-webkit-text-stroke:${r1(Math.max(.1, sk || .25) * 100) / 100}mm ${col};`;
    else { s += `color:${col};`; if (wm.sty === "both") s += `-webkit-text-stroke:${r1(Math.max(.05, sk || .2) * 100) / 100}mm ${wm.sc || "#000"};paint-order:stroke fill;`; }
    return s;
  }
  /* الشفافية على المحتوى نفسه (وليس على الإطار) ← المقابض تبقى واضحة أثناء التحرير، والقيمة تُطبّق كما هي */
  /* pos: "in" داخل قسم الإجماليات · "bot" أسفل الإيصال · "top" أعلاه · غير ذلك = الوسط */
  function wmHTML(d, h, co, n, edit, pos) {
    const wm = d.wm; if (!wm || !wm.on) return "";
    const pc = pos === "in" || pos === "bot" || pos === "top" ? " " + pos : "";
    const z = wm.front ? 3 : (pos === "in" ? -1 : 0), op = Math.max(.02, Math.min(1, +wm.op || .12)), x = r1(+wm.x || 0), y = r1(+wm.y || 0), rot = +wm.rot || 0;
    const dv = edit ? ' data-wmv="1"' : "", H = edit ? '<i class="wmh r" data-wmh="r" title="تدوير"></i><i class="wmh s" data-wmh="s" title="تكبير / تصغير"></i>' : "";
    const tr = `translate(${x}mm,${y}mm) rotate(${rot}deg)`;
    if (wm.type === "img" && wm.src) {
      if (!wm.rep) return `<div class="rr-wm c${pc}" style="z-index:${z}"><div class="wmb"${dv} style="width:${wm.w || 60}%;transform:${tr}"><img src="${wm.src}" alt="" style="opacity:${op}">${H}</div></div>`;
      const rows = Math.max(4, Math.ceil((d.a4 ? Math.max(d.h || 297, 140 + n * 11) : 60 + n * 14) / 30)), one = `<img src="${wm.src}" alt="" style="transform:rotate(${rot}deg)">`;
      return `<div class="rr-wm r" style="z-index:${z}"><div class="wmp"${dv} style="transform:translate(${x}mm,${y}mm)">${Array.from({ length: rows }, (_, i) => `<div class="rw${i % 2 ? " o" : ""}" style="opacity:${op}">${one}${one}</div>`).join("")}</div></div>`;
    }
    const t = E(wmText(wm, h, co)), ts = wmTS(wm);
    if (!wm.rep) return `<div class="rr-wm c${pc}" style="z-index:${z}"><div class="wmb"${dv} style="transform:${tr}"><span style="font-size:${wm.fs || 30}pt;${ts}opacity:${op}">${t}</span>${H}</div></div>`;
    const rows = Math.max(6, Math.ceil((d.a4 ? Math.max(d.h || 297, 140 + n * 11) : 60 + n * 14) / Math.max(8, (wm.fs || 30) * .55)));
    return `<div class="rr-wm r" style="z-index:${z}"><div class="rt"${dv} style="transform:${tr}">${Array.from({ length: rows }, (_, i) => `<div class="rw${i % 2 ? " o" : ""}" style="font-size:${Math.max(6, (wm.fs || 30) * .5)}pt;${ts}opacity:${op}">${Array(6).fill(`<span>${t}</span>`).join("")}</div>`).join("")}</div></div>`;
  }
  const RR_CSS = `.rr{-webkit-print-color-adjust:exact;print-color-adjust:exact;overflow:hidden}
.rr-wm{position:absolute;inset:0;pointer-events:none;overflow:hidden}
.rr-sgw{display:grid;grid-template-columns:1fr 1fr;gap:4mm;margin-top:2mm}.rr-sgw.one{grid-template-columns:1fr;padding:0 12%}
.rr-sg{position:relative;display:flex;flex-direction:column;align-items:center;min-height:16mm;justify-content:flex-end}
.rr-sg .sgi{max-width:100%;max-height:13mm;object-fit:contain;margin-bottom:-1.5mm;position:relative;z-index:2}.rr-sg .sgs{display:block;height:11mm}
.rr-sg .sgl{width:100%;border-top:.3mm solid #000}.rr-sg .sgt{font-size:.85em;font-weight:800;margin-top:.6mm}.rr-sg .sgd{font:600 .75em Arial,sans-serif;color:#333}
.rr-stamp{position:absolute;width:19mm;height:19mm;left:-2mm;top:-4mm;opacity:.82;z-index:1;mix-blend-mode:multiply}.rr>.rr-b{z-index:1}
.rr-wm.c{display:flex;align-items:center;justify-content:center}.rr-wm.c.in{inset:-2mm 0;overflow:visible}.rr-wm.c.bot{align-items:flex-end;padding-bottom:14mm}.rr-wm.c.top{align-items:flex-start;padding-top:14mm}.rr-wm.c span{font-weight:900;white-space:nowrap;letter-spacing:.5mm;font-family:"Droid Arabic Kufi","Arial Black",sans-serif}
.rr-wm.c img{max-width:100%;filter:grayscale(1)}.rr-wm .wmb{position:relative;display:inline-block;line-height:1;flex:none}.rr-wm.c .wmb img{width:100%;max-width:none;display:block}.rr-wm .wmp{position:absolute;inset:0}.rr-wm .wmh{display:none}
.rr-wm.r .rt{position:absolute;left:-40%;top:-10%;width:180%;height:120%;display:flex;flex-direction:column;justify-content:space-around}
.rr-wm.r .rw{display:flex;gap:6mm;white-space:nowrap;font-weight:900;font-family:"Droid Arabic Kufi","Arial Black",sans-serif}.rr-wm.r .rw.o{margin-inline-start:12mm}
.rr-wm.r>.rw{display:flex;justify-content:space-around;margin:4mm 0}.rr-wm.r>.rw img{width:40%;filter:grayscale(1)}
.rr.a4{line-height:1.4}.rr.a4 .rr-in>.rr-b+.rr-b{margin-top:3.2mm}.rr-in{display:flow-root}
.a4 .rr-head{position:relative;padding-bottom:2.2mm;border-bottom:.7mm solid var(--acc);margin-bottom:1.2mm}.a4 .rr-head::after{content:"";position:absolute;left:0;right:0;bottom:-1.5mm;border-bottom:.25mm solid var(--acc)}
.a4 .rr-co{color:var(--acc);font-family:"Arial Black","Droid Arabic Kufi",sans-serif;letter-spacing:.6mm;line-height:1.15}.a4 .rr-sm{font-size:.92em}
.a4 .rr-ph{direction:rtl;justify-content:flex-start;gap:2.5mm;margin:1mm 0}.a4 .al-c .rr-ph{justify-content:center}.a4 .al-l .rr-ph{justify-content:flex-end}
.a4 .rr-ph span{border:.3mm solid #000;border-radius:1mm;padding:.2mm 2.2mm;direction:ltr}
.rai{display:grid;grid-template-columns:1.15fr 1.25fr auto;gap:3.5mm;align-items:stretch}
.ai-r{display:flex;flex-direction:column;gap:2mm}.ai-t{width:100%;border-collapse:collapse}
.ai-t th{background:#000;color:#fff;font-weight:800;text-align:right;white-space:nowrap;width:1%;padding:1.1mm 2.4mm;border:.3mm solid #000}
.ai-t td{border:.3mm solid #000;padding:1.1mm 2.4mm;font-weight:700;font-family:Arial,"Droid Arabic Kufi",sans-serif;text-align:center}
.ai-m{display:flex;flex-direction:column;gap:2mm}
.ai-tx{text-align:center;font-weight:900;font-size:1.25em;border:.45mm solid var(--acc);color:var(--acc);border-radius:2mm;padding:.8mm 2mm}
.ai-pb{display:flex;justify-content:space-between;align-items:center;gap:3mm;border:.45mm solid #000;border-radius:1.6mm;padding:1mm 3mm}
.ai-pb span{font-weight:800;line-height:1.1}.ai-pb small{display:block;font:700 .72em Arial,sans-serif;letter-spacing:.2mm;color:#444}.ai-pb b{font:900 1.35em Arial,sans-serif}
.ai-ts{flex:1;min-height:17mm;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#000;color:#fff;border-radius:2.2mm;padding:1.5mm 3mm;position:relative;overflow:hidden}
.ai-ts::before{content:"";position:absolute;inset:0;background:linear-gradient(115deg,transparent 40%,rgba(255,255,255,.16) 50%,transparent 60%)}
.ai-ts small{font:800 .9em Arial,"Droid Arabic Kufi",sans-serif;letter-spacing:.3mm;opacity:.92}.ai-ts b{font:900 2.5em/1.1 Arial,sans-serif;letter-spacing:.3mm}
.ai-q{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.6mm;border:.3mm solid #000;border-radius:1.6mm;padding:1.5mm}
.ai-q svg{width:24mm;height:24mm}.ai-q small{font:700 .75em Arial,sans-serif;letter-spacing:.3mm}
.ai-qs small{font:800 .78em Tahoma,Arial,sans-serif;letter-spacing:0;white-space:nowrap}.ai-qs i{font:600 .5em/1.15 Arial,sans-serif;font-style:normal;max-width:26mm;text-align:center;word-break:break-all;opacity:.85}
.rr-at{width:100%;border-collapse:collapse;table-layout:fixed}.rr-at thead{display:table-header-group}.rr-at tr{break-inside:avoid;page-break-inside:avoid}
.rr-at th{background:#000;color:#fff;font-weight:800;font-size:.92em;padding:1.5mm .8mm;border:.3mm solid #000}
.rr-at td{border:.3mm solid #000;padding:1.3mm .8mm;text-align:center;vertical-align:middle;font-family:Arial,"Droid Arabic Kufi",sans-serif;font-weight:700;word-break:break-word;line-height:1.25}
.rr-at td.c-name{text-align:right;font-family:"Droid Arabic Kufi",Arial,sans-serif;font-weight:800;padding-inline:1.6mm}.rr-at td.c-unit{font-family:"Droid Arabic Kufi",Arial,sans-serif}
.rr-at td.c-total{font-weight:900}.rr-at td.c-idx{font-weight:600;color:#333}
.rr-at.rz tbody tr:nth-child(even) td{background:#f2f2f2}
.rr-at td.c-pb{border-style:solid dashed}.rr-at.rblk td.c-pa{background:#000;color:#fff;border-color:#000}
.rr-at td small{display:block;font:600 .66em "Droid Arabic Kufi",Arial,sans-serif;opacity:.72;margin-top:.2mm}
.rr-at td .rsv{display:inline-block;font:800 .64em Arial,sans-serif;font-style:normal;background:#15803d;color:#fff;border-radius:1mm;padding:0 1.1mm;margin-top:.3mm}.rr-at.rblk td.c-pa .rsv{background:#fff;color:#000}
.rr-at td.c-same{background:repeating-linear-gradient(135deg,#fff 0 1.6mm,#f0f0f0 1.6mm 3.2mm)!important;color:#000!important}
.rr-at .rsame{display:inline-block;font:800 .86em "Droid Arabic Kufi",Arial,sans-serif;border:.3mm dashed currentColor;border-radius:4mm;padding:.3mm 2.6mm;white-space:nowrap;background:#fff;color:#000}
.a4 .rr-tot{display:grid;grid-template-columns:repeat(3,1fr);gap:1.6mm}.a4 .rr-tot div{display:grid;grid-template-columns:auto 1fr;align-items:stretch;padding:0;border:.3mm solid #000;border-radius:1mm;overflow:hidden}
.a4 .rr-tot span{background:#000;color:#fff;font-weight:800;padding:1.1mm 2.4mm;white-space:nowrap}.a4 .rr-tot b{text-align:center;padding:1.1mm 2mm;align-self:center}
.a4 .rr-tot .bd{border:.55mm solid var(--acc);font-size:1.12em}.a4 .rr-tot .bd span{background:var(--acc)}
.a4 .rr-words{text-align:right;border:.3mm solid #000;border-radius:1mm;padding:1.3mm 3mm;display:flex;gap:2.5mm;align-items:center}.a4 .rr-words>span{font-weight:900;color:var(--acc)}
.a4 .rr-sgw{gap:24mm;padding:0 8mm;margin-top:4mm}.a4 .rr-sg{min-height:31mm}.a4 .rr-sg .sgi{max-height:21mm}.a4 .rr-sg .sgs{height:19mm}.a4 .rr-stamp{width:29mm;height:29mm;left:-4mm;top:0}
.a4 .rr-in>.rr-b:not(.t-items){break-inside:avoid;page-break-inside:avoid}
.rr-py{display:flex;align-items:center;gap:4mm;padding:1mm 2mm;font-weight:700}.rr-py>*{flex:1;text-align:center}.rr-py .py-tr{flex:1.6;text-align:right}.rr-py .py-cu{font:900 1em Arial,sans-serif;letter-spacing:.3mm}.rr-py .py-am{font:900 1.08em Arial,sans-serif;text-align:left}
.rr-pyt{display:flex;justify-content:space-between;gap:4mm;padding:.6mm 2mm;font-weight:700;font-size:.95em}.rr-pyt span:only-child{margin:0 auto}
.rr-pf{display:flex;align-items:center;justify-content:space-between;gap:3mm;direction:ltr;font-family:Arial,sans-serif}.rr-pf.scr{position:absolute;z-index:2}.rr-pf.inl{padding:1mm 0;border-top:.2mm dashed #000}
.rr-pf .pf-br{font-weight:900;font-size:1.05em;letter-spacing:.2mm;flex:1}.rr-pf .pf-bc{display:flex;flex-direction:column;align-items:center;flex:none}.rr-pf .pf-bc svg{width:34mm;height:6.5mm}.rr-pf .pf-bc i{font:700 .82em Arial,sans-serif;font-style:normal;line-height:1}
.rr-pf .pf-rt{flex:1;display:flex;justify-content:flex-end;align-items:center;gap:6mm}.rr-pf .pf-pg{font-weight:700;font-size:.9em}.rr-pf .pf-so{display:flex;align-items:center;gap:1.2mm;font-weight:700;font-size:.9em}.rr-pf .pf-so svg{width:4.2mm;height:4.2mm}.rr-pf .pf-so em{font-style:normal}
.a5 .rr-pf .pf-bc svg{width:27mm;height:5.5mm}.a5 .rr-py{gap:2.5mm;padding:.6mm 1.2mm}
.rr.a5 .rr-in>.rr-b+.rr-b{margin-top:2.2mm}.a5 .rr-head{padding-bottom:1.4mm}.a5 .rr-ph{gap:1.6mm;margin:.6mm 0}.a5 .rr-ph span{padding:.1mm 1.5mm}
.a5 .rai{grid-template-columns:1.1fr 1.2fr auto;gap:2.2mm}.a5 .ai-r,.a5 .ai-m{gap:1.3mm}.a5 .ai-t th,.a5 .ai-t td{padding:.6mm 1.5mm}
.a5 .ai-tx{padding:.4mm 1.5mm;font-size:1.15em}.a5 .ai-pb{padding:.6mm 2mm}.a5 .ai-ts{min-height:11mm;padding:1mm 2mm}.a5 .ai-ts b{font-size:2.15em}
.a5 .ai-q{padding:1mm}.a5 .ai-q svg{width:17mm;height:17mm}
.a5 .rr-at th{padding:1mm .4mm;font-size:.88em}.a5 .rr-at td{padding:.8mm .4mm}.a5 .rr-at td.c-name{padding-inline:1mm}.a5 .rr-at .rsame{padding:.2mm 1.6mm;font-size:.8em}
.a5 .rr-tot{gap:1.1mm}.a5 .rr-tot span{padding:.7mm 1.5mm}.a5 .rr-tot b{padding:.7mm 1.2mm}.a5 .rr-words{padding:.9mm 2mm}
.a5 .rr-sgw{gap:12mm;padding:0 3mm;margin-top:2.5mm}.a5 .rr-sg{min-height:23mm}.a5 .rr-sg .sgi{max-height:15mm}.a5 .rr-sg .sgs{height:13mm}.a5 .rr-stamp{width:21mm;height:21mm;left:-3mm}
.a5 .rr-foot{margin-top:2.5mm;padding-top:1mm}
.a4 .rr-foot{border-top:.45mm solid var(--acc);margin-top:4mm;padding-top:1.6mm}
`;
  const RR_CSS0 = `.rr{position:relative;background:#fff;color:#000;direction:rtl;font-family:"Droid Arabic Kufi","Segoe UI",Tahoma,Arial,sans-serif;line-height:1.35;box-sizing:border-box}
.rr *{box-sizing:border-box}.rr-b{position:relative}.rr-b+.rr-b{margin-top:1.2mm}
.rr-lgw{display:flex;justify-content:center;line-height:0}.rr-lgw.top{margin-bottom:1.2mm}.al-r>.rr-lgw.top{justify-content:flex-start}.al-l>.rr-lgw.top{justify-content:flex-end}.rr-lg{display:block;max-width:100%;width:auto;height:auto;object-fit:contain}.rr-lg.bw{filter:grayscale(1) contrast(1.35)}.rr-hs{display:flex;align-items:center;gap:2.5mm;direction:ltr}.rr-hs.lg-r{flex-direction:row-reverse}.rr-hs>.rr-ht{direction:rtl}.rr:not(.a4) .rr-hs .rr-ph{flex-direction:column;gap:.2mm;align-items:center}.rr:not(.a4) .rr-hs.al-r .rr-ph{align-items:flex-start}.rr:not(.a4) .rr-hs.al-l .rr-ph{align-items:flex-end}.a4 .rr-hs .rr-ph{flex-wrap:wrap}.rr-hs .rr-ph span{white-space:nowrap}.rr-hs>.rr-lgw{flex:0 0 auto;max-width:42%}.rr-hs>.rr-ht{flex:1 1 auto;min-width:0}.rr-lg0{display:flex;align-items:center;justify-content:center;margin:0 auto 1.2mm;width:60%;border:.3mm dashed #9aa4b2;border-radius:1.5mm;color:#8a94a3;font-size:8pt;line-height:1;background:repeating-linear-gradient(45deg,#f6f7f9 0 2mm,#fff 2mm 4mm)}.rr-hs .rr-lg0{margin:0;width:16mm}.rr-co{font-weight:900;letter-spacing:.2mm}.rr-sm{font-size:.85em;color:#222}.rr-ph{display:flex;justify-content:space-between;gap:2mm;font-weight:700;direction:ltr;font-family:Arial,sans-serif}
.rr-tx{text-align:center;font-weight:900;font-size:1.15em;background:#000;color:#fff;border-radius:1mm;padding:.6mm 0;margin-bottom:1mm}
.rr-kv{display:grid;grid-template-columns:1fr 1fr;gap:.4mm 2mm}.rr-kv div{display:flex;gap:1mm;justify-content:space-between;border-bottom:.15mm dotted #999}.rr-kv span{color:#333}.rr-kv b{font-family:Arial,"Droid Arabic Kufi",sans-serif}
.rr-tb{border-top:.3mm solid #000}.rr-tr{display:grid;align-items:center;border-bottom:.15mm dashed #999;min-height:5mm}.rr-tr>div{padding:.4mm .5mm;overflow:hidden;text-align:center;word-break:break-word}
.rr-tr .c-name{text-align:right;font-weight:700}.rr-th{background:#000;color:#fff;font-weight:800;border:0}.rr-tr.z{background:#f1f1f1}
.rr-two{border-top:.3mm solid #000}.rr-th2{display:flex;justify-content:space-between;background:#000;color:#fff;font-weight:800;padding:.5mm 1mm}
.rr-it{padding:.8mm .5mm;border-bottom:.15mm dashed #888}.rr-it.z{background:#f1f1f1}.rr-nm{font-weight:800;line-height:1.25}
.rr-ln{display:flex;align-items:center;justify-content:flex-start;gap:1.2mm;direction:ltr;font-family:Arial,"Droid Arabic Kufi",sans-serif;margin-top:.3mm}
.rr-ln .op{font-style:normal;font-weight:900;color:#000;min-width:2.5mm;text-align:center}.rr-ln .tk{font-weight:700}.rr-ln .t-total,.rr-ln .t-bigp{margin-left:auto;font-weight:900;background:#000;color:#fff;padding:0 1.2mm;border-radius:.8mm}.rr-ln .t-unit,.rr-ln .t-bigu,.rr-ln .lt{font-family:"Droid Arabic Kufi",sans-serif;font-weight:600}
.rr-ln .rr-pc{margin-left:auto;display:inline-flex;align-items:center;gap:.8mm;direction:rtl;border:.2mm dashed #000;border-radius:3mm;padding:0 1.6mm;line-height:1.35;white-space:nowrap}
.rr-dsp{display:inline-flex;align-items:center;gap:.9mm;direction:ltr;white-space:nowrap}.rr-dsp s{font-weight:600;color:#555;text-decoration-thickness:.25mm;font-size:.88em}.rr-dsp b{font-weight:900}.rr-dsp em{font-style:normal;font-weight:900;font-size:.78em;line-height:1.2;padding:0 .8mm;border:.25mm solid #000;border-radius:.8mm}
.rr-ln{flex-wrap:wrap;row-gap:.4mm}
.rr-dtg{display:inline-block;margin-inline-start:1.4mm;padding:0 1.2mm;border-radius:.8mm;background:#000;color:#fff;font-size:.72em;font-weight:800;line-height:1.45;vertical-align:.15em;white-space:nowrap}
.rr-at .rr-dsp,.rr-tr .rr-dsp{justify-content:center;flex-wrap:wrap;gap:.4mm .9mm}
.rr-ln .rr-pc em{font-style:normal;font-family:"Droid Arabic Kufi",sans-serif;font-size:.78em;font-weight:600;color:#222}.rr-ln .rr-pc b{font-family:Arial,sans-serif;font-weight:800;font-size:.95em}
.rr-tot{display:flex;flex-direction:column;gap:.3mm}.rr-tot div{display:flex;justify-content:space-between;padding:.3mm 0;border-bottom:.15mm dotted #bbb}.rr-tot b{font-family:Arial,sans-serif;font-weight:800}
.rr-tot .bd{font-size:1.2em;font-weight:900;border:.3mm solid #000;border-radius:1mm;padding:.6mm 1mm}
.rr-words{font-size:.9em;font-weight:700;text-align:center;border:.2mm dashed #000;padding:.8mm;border-radius:1mm}.rr-notes{font-size:.9em}.rr-ph0{color:#999;text-align:center;font-style:italic}
.rr-text{white-space:pre-wrap}.rr-sep{border:0;border-top:.3mm dashed #000;margin:.6mm 0}.rr-sep.s{border-top-style:solid}.rr-sep.o{border-top-style:dotted;border-top-width:.5mm}
.t-msgs{margin-top:1.6mm;text-align:center}.rr-msg{font-size:.86em;font-weight:700;padding:.5mm 0}.rr-msg.m-pol{border-top:.25mm dashed #000;padding-top:1.2mm;margin-top:.8mm}.rr-msg.m-don{font-style:italic}
.rr-sqr{display:flex;align-items:center;justify-content:center;gap:2.6mm;margin-top:2mm;padding:1.6mm 2mm;border:.3mm solid #000;border-radius:2mm}
.rr-sqr svg{width:22mm;height:22mm;flex:none}.rr-sqr .sq-t{display:flex;flex-direction:column;gap:.5mm;text-align:right;min-width:0}
.rr-sqr b{font:800 1.05em Tahoma,Arial,sans-serif}.rr-sqr span{font-size:.78em}.rr-sqr i{font:600 .72em Arial,sans-serif;font-style:normal;word-break:break-all;direction:ltr;text-align:right}
.a4 .rr-sqr{justify-content:flex-start;width:max-content;margin-top:3mm}
.rr-code{text-align:center}.rr-code svg{width:70%;height:9mm}.rr-code div{font:700 8pt Arial,sans-serif;letter-spacing:.4mm}
.rr-foot{text-align:center;font-weight:700;border-top:.3mm dashed #000;padding-top:1mm;white-space:pre-wrap}
.rr-img{position:absolute;height:auto;z-index:2}`;

  /* ---------------- الطباعة ---------------- */
  const FITMIN = .7;
  function printHTML(d, data, title) {
    const a4 = d.a4 ? `@media print{@page{size:${d.w}mm ${d.h || 297}mm;margin:${d.pad}mm ${d.pad}mm ${padB(d)}mm;${pfPageCSS(d, data.header || {})}}.rr{width:auto!important;min-height:0!important;padding:0!important}.rr-img{transform:translate(-${d.pad}mm,-${d.pad}mm)}.rr-pf.scr{display:none!important}.rr-at tr{break-inside:avoid;page-break-inside:avoid}.rr-at thead{display:table-header-group}}` : "";
    /* ملاءمة صفحة واحدة: محتوى يزيد قليلاً عن الصفحة (حتى 30%) يُصغَّر ليخرج في ورقة واحدة بمقاسها — بدل صفحة ثانية شبه فارغة */
    const pgs = d.a4 ? `<script>(function(){function go(){var r=document.querySelector(".rr"),i=r&&r.querySelector(".rr-in");if(!i)return;var k=96/25.4,ph=${(d.h || 297) - d.pad - padB(d)}*k,s=1;i.style.zoom="";var H=i.offsetHeight;if(${d.fit === 0 ? 0 : 1}&&H>ph+2&&ph/H>=${FITMIN}){s=Math.floor(ph/H*1000)/1000-.004;i.style.zoom=s;}var n=Math.max(1,Math.ceil((H*s-2)/ph)),f=r.querySelector(".rr-pf.scr .pf-pg");if(f)f.textContent=n>1?"1/"+n+" … "+n+"/"+n:"1/1";r.style.minHeight=(n*${d.h || 297})+"mm";}if(document.readyState==="complete")go();else addEventListener("load",go);})()<\/script>` : "";
    return `<!doctype html><html dir="rtl" lang="ar"><meta charset="utf-8"><title>${E(title || d.name)}</title><style>${d.a4 ? "" : `@page{size:${d.w}mm auto;margin:0}`}body{margin:0;background:#888}${RR_CSS + RR_CSS0}
.rr{margin:8px auto;box-shadow:0 4px 18px rgba(0,0,0,.4)}@media print{body{background:#fff}.rr{margin:0;box-shadow:none}}${a4}</style><body>${receiptHTML(d, data, false)}${pgs}</body></html>`;
  }
  /* ---------------- الطباعة من البرنامج: نافذة الطباعة الصغيرة (مثل DEXEF) — الورقة بمقاسها بالضبط ----------------
     الإيصال: ورقة واحدة بعرض الإيصال وطول محتواه الحقيقي (بلا ورق طويل فارغ).
     A4 / A5: صفحات بمقاسها، والتقطيع بين الأسطر (لا يُقسم سطر صنف) مع تكرار عناوين الجدول وتذييل كل صفحة برقمها. */
  const HOSTP = () => !!(window.Anouer && Anouer.available && Anouer.call && window.ANOUER_RD && ANOUER_RD.hostPrintDialog);
  async function hostRes(d, data) {
    if (!G("rcsCss")) { const st = document.createElement("style"); st.id = "rcsCss"; st.setAttribute("data-dk-skip", ""); st.textContent = RR_CSS + RR_CSS0; document.head.appendChild(st); }
    /* القياس في إطار معزول بنفس CSS الطباعة بالضبط (مثل RD.rasterize) — لا تؤثر عليه أنماط الصفحة الرئيسية
       (إعادة ضبط الهوامش ، الوضع الداكن …) فتقع نقاط القطع بين الأسطر تماماً ولا ينقسم صنف بين ورقتين */
    const fr = document.createElement("iframe"); fr.setAttribute("data-dk-skip", ""); fr.setAttribute("aria-hidden", "true"); fr.tabIndex = -1;
    fr.style.cssText = "position:fixed;left:-30000px;top:0;width:1800px;height:1400px;border:0;visibility:hidden;pointer-events:none";
    document.body.appendChild(fr);
    const fd = fr.contentDocument; fd.open();
    fd.write(`<!doctype html><html><head><meta charset="utf-8"><style>*{-webkit-print-color-adjust:exact;print-color-adjust:exact;box-sizing:border-box}table{border-collapse:collapse}html,body{margin:0;padding:0;background:#fff}</style><style>${RR_CSS + RR_CSS0}.rr{margin:0!important;box-shadow:none!important}</style></head><body>${receiptHTML(d, data, false)}</body></html>`);
    fd.close();
    const host = fd.body;
    try {
      await Promise.all([...host.querySelectorAll("img")].map(im => im.decode ? im.decode().catch(() => { }) : null));
      try { if (fd.fonts && fd.fonts.ready) await fd.fonts.ready; } catch (e) { }
      const rr = host.firstElementChild, CSS0 = `<style>${RR_CSS + RR_CSS0}.rr{margin:0!important;box-shadow:none!important}</style>`;
      if (!d.a4) { const hmm = Math.ceil(rr.offsetHeight / PX * 10) / 10 + 1; rr.style.height = hmm + "mm"; return { pages: [{ w: d.w, h: hmm, html: CSS0 + rr.outerHTML }], w: d.w, h: hmm, roll: true }; }
      const H0 = d.h || 297, ph = H0 - d.pad - padB(d), php = ph * PX, inn = rr.querySelector(".rr-in");
      let H = inn.offsetHeight, sc = 1;
      if (d.fit !== 0 && H > php + 2 && php / H >= FITMIN) { sc = Math.floor(php / H * 1000) / 1000 - .004; inn.style.zoom = sc; }
      const pp = rr.querySelector(".rr-pf.scr .pf-pg");
      if (H * sc <= php + 2) { if (pp) pp.textContent = "1/1"; rr.style.minHeight = "0"; rr.style.height = H0 + "mm"; return { pages: [{ w: d.w, h: H0, html: CSS0 + rr.outerHTML }], w: d.w, h: H0, roll: false }; }
      /* صفحات متعددة (2026): كل ورقة تُبنى بأسطرها الكاملة فقط (لا قصّ بالبكسل) — نقاط القطع = نهايات الأقسام وأسطر الأصناف
         التي لا تقطع أي سطر ، مع هامش أمان 3 مم ؛ فلا ينقسم صنف بين ورقتين حتى لو اختلف قياس الخط قليلاً عند الطباعة */
      const W0 = fr.contentWindow, top0 = inn.getBoundingClientRect().top;
      const R = el => { const r = el.getBoundingClientRect(); return [r.top - top0, r.bottom - top0]; };
      const isAbs = el => { try { const ps = W0.getComputedStyle(el).position; return ps === "absolute" || ps === "fixed"; } catch (e) { return false; } };
      const ROWQ = ".rr-at tbody tr, .rr-tr:not(.rr-th), .rr-it";
      const kids = [...inn.children].map(el => ({ el, abs: isAbs(el), box: R(el) }));
      const rowBox = [...inn.querySelectorAll(ROWQ)].map(R);
      const straddle = v => rowBox.some(([t, b]) => t < v - 1 && b > v + 1);
      const cand = [...new Set(kids.filter(k => !k.abs).map(k => k.box[1]).concat(rowBox.map(x => x[1])).map(v => Math.round(v * 10) / 10))].filter(v => !straddle(v)).sort((a, b) => a - b);
      const tb = inn.querySelector("table.rr-at");
      const hd = (tb && tb.tHead) || inn.querySelector(".rr-th,.rr-th2");
      const th = hd ? hd.getBoundingClientRect().height : 0;
      const tArea = hd ? (hd.closest(".rr-in > *") || hd) : null, tBox = tArea ? R(tArea) : [0, 0];
      const SL = 3 * PX;   /* هامش أمان لاختلاف القياس عند الطباعة */
      const cuts = []; let st = 0;
      while (st < H - 1 && cuts.length < 60) {
        const cont = !!hd && st > tBox[0] + 1 && st < tBox[1] - 1, lim = st + php - (cont ? th : 0) - SL;
        let c = 0; cand.forEach(v => { if (v > st + 1 && v <= lim) c = v; });
        if (!c) c = cand.find(v => v > st + 1) || H;   /* قسم أطول من الورقة: يأخذ ورقته كاملة */
        cuts.push({ st, c, cont }); st = c;
      }
      /* محتوى ورقة: الأقسام التي يقع وسطها داخلها ، وجدول الأصناف بأسطره التي تقع داخلها فقط (رأس الجدول يتكرّر) */
      const pageInner = (a, b) => {
        const box = fd.createElement("div");
        kids.forEach(k => {
          const [t, bt] = k.box, mid = (t + bt) / 2;
          if (k.abs) { if ((t >= a - 1 && t < b - 1) || (a === 0 && t < 0)) { const z = k.el.cloneNode(true); if (a) z.style.top = Math.round((t - a) * 10) / 10 + "px"; box.appendChild(z); } return; }
          const rows = [...k.el.querySelectorAll(ROWQ)];
          if (rows.length && t < b - 1 && bt > a + 1 && !(t >= a - 1 && bt <= b + 1)) {
            const z = k.el.cloneNode(true), zr = [...z.querySelectorAll(ROWQ)]; let keep = 0;
            rows.forEach((r, i) => { const [rt, rb] = R(r), m = (rt + rb) / 2; if (m > a && m < b) keep++; else if (zr[i]) zr[i].remove(); });
            if (keep) box.appendChild(z);
            return;
          }
          if (mid >= a && mid < b) box.appendChild(k.el.cloneNode(true));
        });
        return box.innerHTML;
      };
      const n = cuts.length, wm = wmHTML(d, data.header || {}, Object.assign({}, sample().company, CO || {}, data.company || {}), (data.items || []).length);
      const pf = rr.querySelector(".rr-pf.scr");
      const pages = cuts.map((x, k) => { let foot = ""; if (pf) { const f = pf.cloneNode(true), g = f.querySelector(".pf-pg"); if (g) g.textContent = (k + 1) + "/" + n; foot = f.outerHTML; }
        return { w: d.w, h: H0, html: CSS0 + `<div class="${rr.className}" style="width:${d.w}mm;height:${H0}mm;min-height:0;padding:0;margin:0;--acc:${d.acc || "#c2410c"};font-size:${d.fs}pt;position:relative;overflow:hidden">${wm}`
          + `<div style="position:absolute;left:${d.pad}mm;right:${d.pad}mm;top:${d.pad}mm"><div class="rr-in" style="position:relative">${pageInner(x.st, x.c)}</div></div>${foot}</div>` }; });
      return { pages, w: d.w, h: H0, roll: false };
    } finally { fr.remove(); }
  }
  /* طابعة الإيصال: آخر طابعة اختارها المستخدم في نافذة الطباعة (تُحفظ تلقائياً) — وإلا الطابعة الافتراضية في Windows */
  const RCP = "anouer.rcPrinter." + C.K;
  const rcPrn = () => { try { return localStorage.getItem(RCP) || ""; } catch (e) { return ""; } };
  const rcPrnSet = v => { try { if (v) localStorage.setItem(RCP, v); } catch (e) { } };
  /* direct = بعد الحفظ (F4 / F6 «الطباعة مباشرة»): مباشرة على الطابعة بدون نافذة Print */
  function doPrint(d, data, preview, title, direct) {
    const html = printHTML(d, data, title);
    if (preview) { window.__rcsPV = dlg => doPrint(d, data, false, title, !dlg);   /* «طباعة» مباشرة على طابعة التصميم ، «الطابعة…» نافذة الطباعة */ pvShow(html); return Promise.resolve({ ok: true, preview: true }); }
    if (HOSTP() && direct && ANOUER_RD.printResult) {
      const t = title || d.name, cp = Math.max(1, +d.copies || 1);
      return hostRes(d, data).then(res => {
        const prn = rcPrn();
        return ANOUER_RD.printResult(res, { printer: prn, copies: cp, title: t }).catch(e => {
          /* الطابعة المحفوظة لم تعد موجودة → الطابعة الافتراضية */
          if (prn && /غير موجودة|not found|غير متاحة/i.test((e && e.message) || "")) { try { localStorage.removeItem(RCP); } catch (x) { } return ANOUER_RD.printResult(res, { printer: "", copies: cp, title: t }); }
          throw e;
        });
      }).catch(e => { say("تعذّرت الطباعة: " + ((e && e.message) || e), "e"); return { ok: false }; });
    }
    if (HOSTP()) return hostRes(d, data).then(res => ANOUER_RD.hostPrintDialog(res, { title: title || d.name, printer: rcPrn() || undefined, onPick: rcPrnSet })).catch(e => { say("تعذّرت الطباعة: " + ((e && e.message) || e), "e"); return { ok: false }; });
    return new Promise(res => {
      let f = G("rcsPf"); if (f) f.remove(); f = document.createElement("iframe"); f.id = "rcsPf"; f.style.cssText = "position:fixed;width:0;height:0;border:0;right:0;bottom:0"; document.body.appendChild(f);
      f.onload = () => { try { f.contentWindow.focus(); f.contentWindow.print(); res({ ok: true }); } catch (_) { say("تعذّرت الطباعة", "e"); res({ ok: false }); } }; f.srcdoc = html;
    });
  }
  function pvShow(html) {
    let p = G("rcsPvG"); if (!p) { p = document.createElement("div"); p.id = "rcsPvG"; p.className = "rcs-pvg"; p.setAttribute("data-dk-skip", ""); p.innerHTML = `<div class="rcs-pvb"><div class="rcs-pvh"><b>معاينة</b><span class="sp"></span><button type="button" data-p="dlg" title="نافذة الطباعة: اختيار طابعة أخرى ، عدد النسخ ، الوجهين …">🖨 الطابعة…</button><button type="button" data-p="print" title="طباعة مباشرة على طابعة هذا التصميم">طباعة</button><button type="button" data-p="x">✕</button></div><iframe title="معاينة"></iframe></div>`; document.body.appendChild(p);
      p.addEventListener("click", e => { const b = e.target.closest("[data-p]"); if (!b && e.target !== p) return; if (!b || b.dataset.p === "x") p.classList.remove("show"); else if (HOSTP() && window.__rcsPV) { p.classList.remove("show"); window.__rcsPV(b.dataset.p === "dlg"); } else { try { p.querySelector("iframe").contentWindow.print(); } catch (_) { } } }); }
    p.querySelector("iframe").srcdoc = html; p.classList.add("show");
  }

  /* ---------------- النافذة ---------------- */
  const IC = { a4: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6.5A1.5 1.5 0 0 0 5 3.5v17A1.5 1.5 0 0 0 6.5 22h11a1.5 1.5 0 0 0 1.5-1.5V7z"/><path d="M14 2v5h5"/><path d="M8 11h8M8 14.5h8M8 18h5"/><path d="M20.5 13.5l.6 1.2 1.2.6-1.2.6-.6 1.2-.6-1.2-1.2-.6 1.2-.6z" fill="currentColor" stroke="none"/></svg>',
    magic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2h12v20l-3-2-3 2-3-2-3 2z"/><path d="M9 7h6M9 11h6M9 15h4"/><path d="M19.5 3.5l.7 1.3 1.3.7-1.3.7-.7 1.3-.7-1.3-1.3-.7 1.3-.7z" fill="currentColor"/></svg>',
    x: '<svg viewBox="0 0 16 16"><path d="M3 3l10 10M13 3 3 13" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    grip: '<svg viewBox="0 0 12 16"><g fill="currentColor"><circle cx="3" cy="3" r="1.3"/><circle cx="9" cy="3" r="1.3"/><circle cx="3" cy="8" r="1.3"/><circle cx="9" cy="8" r="1.3"/><circle cx="3" cy="13" r="1.3"/><circle cx="9" cy="13" r="1.3"/></g></svg>',
    img: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/></svg>' };
  function build() {
    if (OV) return OV;
    if (!G("rcsCss")) { const st = document.createElement("style"); st.id = "rcsCss"; st.setAttribute("data-dk-skip", ""); st.textContent = RR_CSS + RR_CSS0; document.head.appendChild(st); }
    OV = document.createElement("div"); OV.className = "rcs-ov"; OV.setAttribute("data-dk-skip", "");
    OV.innerHTML = `<div class="rcs" role="dialog" aria-modal="true" aria-label="${C.title}"><div class="bcs-aur"><i></i><i></i><i></i></div>
      <header class="rcs-h"><span class="rcs-logo">${IC.magic}</span><div class="rcs-ht"><b>${C.title}</b><small>${C.sub}</small></div>
        <div class="rcs-ds"><span class="rcs-rdi" id="rcsRdi" title="${C.a4 ? "اكتب كود الفاتورة السابقة (مثل 50) ثم Enter لتعديلها" : "اكتب كود الإيصال السابق (مثل 19) ثم Enter لتعديله"}"></span><select id="rcsSel" aria-label="التصميم"></select><button type="button" data-a="new">＋ جديد</button><button type="button" data-a="ren" title="إعادة تسمية">✎</button><button type="button" data-a="del" title="حذف">🗑</button></div>
        <button type="button" class="rcs-x" data-a="close" aria-label="إغلاق">${IC.x}</button></header>
      <div class="rcs-bd">
        <aside class="rcs-side"><div class="rcs-st">الأقسام <small>اسحب ⋮⋮ لإعادة الترتيب</small></div><div class="rcs-bl" id="rcsBl"></div>
          <div class="rcs-addb"><span>إضافة:</span><button type="button" data-a="add" data-t="text">سطر نص</button><button type="button" data-a="add" data-t="sep">فاصل</button><button type="button" data-a="add" data-t="code">باركود</button><button type="button" data-a="add" data-t="sign">✍ توقيع</button>${C.a4 ? '<button type="button" data-a="add" data-t="pay">سطر الدفع</button><button type="button" data-a="add" data-t="pfoot">تذييل الصفحة</button>' : ""}<button type="button" data-a="img">${IC.img} صورة</button><input type="file" id="rcsFile" accept="image/*" hidden multiple></div></aside>
        <main class="rcs-main">
          <div class="rcs-tb"><label>العرض<select id="rcsW">${C.widths}</select></label>
            <label>الخط<select id="rcsFs">${C.fsz.map(v => `<option value="${v}">${v}pt</option>`).join("")}</select></label>
            <label>الفواصل<select id="rcsSep"><option value="dash">متقطع</option><option value="solid">متصل</option><option value="dot">نقاط</option></select></label>
            <span class="rcs-zm"><button type="button" data-a="zo">−</button><b id="rcsZv"></b><button type="button" data-a="zi">+</button><button type="button" data-a="z1">1:1</button></span>
            <button type="button" class="rcs-wmb" data-a="wm" title="العلامة المائية">💧 العلامة المائية</button>
            ${C.a4 ? '<label class="rcs-use rcs-fit" title="إذا زاد المحتوى قليلاً عن الورقة يُصغَّر تلقائياً ليخرج في ورقة واحدة بمقاسها"><input type="checkbox" id="rcsFit"><i></i><span>📐 ملاءمة صفحة واحدة</span></label>' : ""}
            <label class="rcs-use"><input type="checkbox" id="rcsUse"><i></i><span>استعمل هذا التصميم في طباعة الفواتير</span></label><span class="rcs-keys" id="rcsKeys"></span></div>
          <div class="rcs-cw" id="rcsCw"><div class="rcs-sz" id="rcsSz"><div class="rcs-pg" id="rcsPg"></div></div></div>
          <div class="rcs-it" id="rcsIt" hidden></div>
          <div class="rcs-wm" id="rcsWm" hidden></div>
        </main>
      </div>
      <footer class="rcs-f"><button type="button" class="pr" data-a="print">طباعة</button><button type="button" class="pv" data-a="prev">معاينة</button><button type="button" class="sv" data-a="save">حفظ</button><span class="sp"></span><span class="rcs-src" id="rcsSrc"></span><button type="button" data-a="close">إغلاق</button></footer>
    </div>`;
    document.body.appendChild(OV);
    OV.addEventListener("click", onClick);
    OV.addEventListener("change", onChange);
    OV.addEventListener("input", onInput);
    G("rcsSel").addEventListener("change", e => { const d = DS.find(x => x.id === e.target.value); if (d) { D = d; open1 = null; selImg = null; persist(); drawAll(); } });
    G("rcsFile").addEventListener("change", e => { [...e.target.files].forEach(addImg); e.target.value = ""; });
    const cw = G("rcsCw");
    cw.addEventListener("dragover", e => { if (e.dataTransfer && [...e.dataTransfer.items].some(i => i.kind === "file")) { e.preventDefault(); cw.classList.add("drop"); } });
    cw.addEventListener("dragleave", () => cw.classList.remove("drop"));
    cw.addEventListener("drop", e => { cw.classList.remove("drop"); const fs = [...(e.dataTransfer.files || [])].filter(f => /^image\//.test(f.type)); if (fs.length) { e.preventDefault(); fs.forEach(addImg); } });
    G("rcsPg").addEventListener("pointerdown", onWmDown, true);
    G("rcsPg").addEventListener("dblclick", e => { if (OV.classList.contains("wmedit") && e.target.closest("[data-wmv]")) { wmSet({ x: 0, y: 0 }); drawWm(); say("العلامة في المنتصف", "i"); } }, true);
    G("rcsPg").addEventListener("pointerdown", onImgDown);
    G("rcsPg").addEventListener("click", e => { const s = e.target.closest("[data-b]"); if (s && !e.target.closest("[data-img]")) { open1 = open1 === s.dataset.b ? null : s.dataset.b; drawSide(); const c = G("rcsBl").querySelector(`[data-id="${s.dataset.b}"]`); if (c) c.scrollIntoView({ block: "nearest", behavior: "smooth" }); } });
    cw.addEventListener("pointerdown", e => { if (!e.target.closest("[data-img]") && !e.target.closest(".rcs-it")) { selImg = null; drawPage(); drawImgTools(); } });
    sideDnD();
    try { if (window.__RDI) __RDI.mount(G("rcsRdi"), { kind: "tx", ph: C.a4 ? "كود الفاتورة السابقة…" : "كود الإيصال السابق…", onPick: importRd }); } catch (e) { }
    return OV;
  }

  /* ---------------- القائمة الجانبية: الأقسام ---------------- */
  const chk = (key, on, label) => `<label class="rcs-sw2"><input type="checkbox" data-k="${key}"${on ? " checked" : ""}><i></i><span>${E(label)}</span></label>`;
  function blockBody(b) {
    if (b.t === "head") return `<div class="rcs-opts">${HEADF.map(x => chk("f." + x[0], x[0] === "logo" ? !(b.f && b.f.logo === 0) : b.f && b.f[x[0]], x[1])).join("")}</div>${alignRow(b)}${logoUI(b)}<div class="rcs-row"><span>حجم اسم الشركة</span><input type="range" min="9" max="${C.a4 ? 40 : 26}" step="1" data-k="fs" value="${b.fs || 15}"><b>${b.fs || 15}pt</b></div>${C.a4 ? `<div class="rcs-row"><span>لون الفاتورة</span></div><div class="rcs-wmc">${ACC.map(c => `<button type="button" data-a="acc" data-v="${c}" style="--c:${c}" class="${(D.acc || "#c2410c") === c ? "on" : ""}"></button>`).join("")}</div>` : ""}`;
    if (b.t === "pay") return `<div class="rcs-opts">${PAYF.map(x => chk("f." + x[0], b.f && b.f[x[0]], x[1])).join("")}</div><div class="rcs-sgf"><label>النص الإضافي<input data-k="t2" value="${E(b.t2 || "")}" placeholder="تسعدنا زيارتكم"></label></div><div class="rcs-tip">المبلغ والعملة ونوع الدفع والخزينة وسياسة التعامل تُملأ تلقائياً من الفاتورة (سياسة التعامل من إعدادات الشركة).</div>`;
    if (b.t === "pfoot") return `<div class="rcs-sgf"><label>الاسم (يسار)<input data-k="brand" value="${E(b.brand == null ? "ANOUER" : b.brand)}"></label><label>الحساب (يمين)<input data-k="handle" value="${E(b.handle || "")}" placeholder=""></label></div>
      <div class="rcs-row"><span>أيقونة الحساب</span></div><div class="rcs-soc">${Object.keys(SOC).map(k => `<button type="button" data-a="soc" data-v="${k}" class="${(b.soc || "note") === k ? "on" : ""}" title="${E(SOC[k][0])}">${SOC[k][1] ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${SOC[k][1]}</svg>` : "✕"}<small>${E(SOC[k][0])}</small></button>`).join("")}</div>
      <div class="rcs-opts">${chk("code", b.code !== 0, "باركود رقم الفاتورة (الوسط)")}${chk("pg", b.pg !== 0, "رقم الصفحة 1/2")}</div><div class="rcs-tip">يُطبع أسفل <b>كل صفحة</b> تلقائياً مع رقمها.</div>`;
    if (b.t === "info") return `<div class="rcs-opts">${INFF.map(x => chk("f." + x[0], b.f && b.f[x[0]], x[1])).join("")}</div>`;
    if (b.t === "title") return `<div class="rcs-opts">${TITF.map(x => chk("f." + x[0], b.f && b.f[x[0]], x[1])).join("")}</div>`;
    if (b.t === "items") {
      b.cols = b.cols || []; [["pb", 11], ["pa", 11], ["idx", 4]].forEach(x => { if (!b.cols.some(c => c.k === x[0])) b.cols.push({ k: x[0], on: 0, w: x[1] }); });
      return `<div class="rcs-seg"><button type="button" data-a="mode" data-v="two" class="${b.mode !== "table" ? "on" : ""}">اسم طويل + أسطر حساب</button><button type="button" data-a="mode" data-v="table" class="${b.mode === "table" ? "on" : ""}">جدول أعمدة</button></div>
        <div class="rcs-opts">${chk("hdr", b.hdr, "شريط العناوين الأسود")}${chk("zebra", b.zebra, "تظليل متناوب")}${chk("dsc", b.dsc !== 0, "إظهار خصم الصنف (السعر قبل/بعد)")}${b.mode !== "table" ? chk("pcm", b.pcm !== 0, "سعر القطعة داخل الكرتونة/الفاردو (وسط السطر)") : ""}${C.a4 ? chk("pblk", b.pblk, "عمود «بعد الخصم» أسود") + chk("hint", b.hint, "تلميح تحت السعر") : ""}</div>
        ${C.a4 && b.mode === "table" ? '<div class="rcs-tip"><b>قبل / بعد الخصم الذكي:</b> صنف بوحدتين ← قبل = سعر القطعة، بعد = سعرها داخل الكرتونة/الفاردو · صنف بوحدة واحدة ← سعر «5 ومافوق»، وإن لم يتغيّر يُكتب «لم يتغيّر سعره»</div>' : ""}
        ${b.mode === "table" ? `<div class="rcs-cols">${(b.cols || []).map((c, i) => `<div class="rcs-col${c.on ? " on" : ""}" data-ci="${i}"><button type="button" data-a="cmv" data-d="-1" data-ci="${i}" title="يمين">‹</button><label class="rcs-sw2 sm"><input type="checkbox" data-k="col.${i}"${c.on ? " checked" : ""}><i></i><span>${E(TOK[c.k])}</span></label><input type="range" min="6" max="50" data-k="colw.${i}" value="${c.w}" title="العرض"><button type="button" data-a="cmv" data-d="1" data-ci="${i}" title="يسار">›</button></div>`).join("")}</div>`
        : `<div class="rcs-row"><span>حجم اسم الصنف</span><input type="range" min="7" max="16" step=".5" data-k="nameFs" value="${b.nameFs || 9.5}"><b>${b.nameFs || 9.5}pt</b></div>
          <div class="rcs-lines">${(b.lines || []).map((l, li) => `<div class="rcs-line" data-li="${li}"><span class="no">سطر ${li + 1}</span><div class="rcs-toks">${l.map((t, ti) => `<button type="button" class="tk${OPS.includes(t) ? " op" : TOK[t] ? "" : " lt"}" data-a="tdel" data-li="${li}" data-ti="${ti}" title="انقر للحذف">${E(OPS.includes(t) ? t : TOK[t] || String(t).replace(/^"|"$/g, ""))}</button>`).join("") || '<i class="emp">فارغ — أضف رموزاً من الأسفل</i>'}</div><button type="button" class="rm" data-a="ldel" data-li="${li}" title="حذف السطر">✕</button></div>`).join("")}</div>
          <div class="rcs-pal" data-li="${Math.max(0, (b.lines || []).length - 1)}">${["qty", "unit", "price", "total", "one", "factor", "bigp", "bigu", "pcs", "pb", "pa", "code", "disc", "idx"].map(k => `<button type="button" data-a="tadd" data-v="${k}">${E(TOK[k])}</button>`).join("")}${OPS.map(o => `<button type="button" class="op" data-a="tadd" data-v="${o}">${o}</button>`).join("")}<button type="button" class="lt" data-a="tlit">“نص”</button></div>
          <div class="rcs-lb"><button type="button" data-a="ladd">＋ سطر حساب</button><button type="button" data-a="lpre" data-v="1">الكمية × السعر = الإجمالي</button><button type="button" data-a="lpre" data-v="2">1 × عدد القطع = سعر الكبرى</button><button type="button" data-a="lpre" data-v="3">الوحدة: الكمية × السعر</button></div>`}`;
    }
    if (b.t === "totals") return `<div class="rcs-trs">${(b.rows || []).map((r, i) => { const x = TOT.find(z => z[0] === r.k) || [r.k, r.k]; return `<div class="rcs-tr${r.on ? " on" : ""}"><button type="button" data-a="tmv" data-d="-1" data-ri="${i}">▲</button><button type="button" data-a="tmv" data-d="1" data-ri="${i}">▼</button>${chk("row." + i, r.on, x[1])}<label class="rcs-b"><input type="checkbox" data-k="rowb.${i}"${r.b ? " checked" : ""}><span>إطار</span></label></div>`; }).join("")}</div>`;
    if (b.t === "sign") return `<div class="rcs-seg sm"><button type="button" data-a="sgm" data-v="two" class="${b.mode !== "one" ? "on" : ""}">البائع + العميل</button><button type="button" data-a="sgm" data-v="one" class="${b.mode === "one" ? "on" : ""}">توقيع واحد</button></div>
      <div class="rcs-sgf"><label>العنوان 1<input data-k="lab1" value="${E(b.lab1 || "توقيع البائع")}"></label>${b.mode === "one" ? "" : `<label>العنوان 2<input data-k="lab2" value="${E(b.lab2 || "توقيع العميل")}"></label>`}</div>
      <div class="rcs-sgp">${b.src ? `<img src="${b.src}" alt="التوقيع">` : '<i>لا يوجد توقيع بعد</i>'}<div><button type="button" class="pri" data-a="sgdraw">✍ ارسم التوقيع</button><button type="button" data-a="sgtype">Aa اكتب اسمك</button><button type="button" data-a="sgup">رفع صورة</button>${b.src ? '<button type="button" class="rm" data-a="sgclr">حذف</button>' : ""}</div></div>
      <div class="rcs-opts">${chk("date", b.date, "تاريخ ووقت التوقيع")}${chk("stamp", b.stamp, "الختم الإلكتروني")}</div>
      ${b.stamp ? `<div class="rcs-sgf"><label>نص الختم<input data-k="stt" value="${E(b.stt || "")}" placeholder="اسم الشركة"></label><label>وسط الختم<input data-k="stm" value="${E(b.stm || "مختوم")}"></label></div>
        <div class="rcs-wmc">${["#1d4ed8", "#b91c1c", "#15803d", "#6d28d9", "#000"].map(c => `<button type="button" data-a="stc" data-v="${c}" style="--c:${c}" class="${(b.stc || "#1d4ed8") === c ? "on" : ""}"></button>`).join("")}</div>
        <div class="rcs-row"><span>ميلان الختم</span><input type="range" min="-45" max="45" data-k="str" value="${b.str == null ? -14 : b.str}"><b>${b.str == null ? -14 : b.str}°</b></div>` : ""}`;
    if (b.t === "text" || b.t === "foot") return `<textarea data-k="text" rows="2" placeholder="اكتب النص…">${E(b.text || "")}</textarea>${b.t === "text" ? alignRow(b) + `<div class="rcs-row"><span>الحجم</span><input type="range" min="6" max="24" data-k="fs" value="${b.fs || 9}"><b>${b.fs || 9}pt</b></div>${chk("b", b.b, "عريض")}` : ""}`;
    return "";
  }
  const ACC = ["#c2410c", "#b91c1c", "#1d4ed8", "#0f766e", "#6d28d9", "#000"];
  function logoUI(b) {
    if (b.f && b.f.logo === 0) return "";
    const own = !!b.lg, src = logoSrc(b, CO || {}), pos = b.lgPos || (C.a4 ? "l" : "top"), h = +b.lgH || (C.a4 ? 22 : 16), bw = !(b.lgBw === 0 || (b.lgBw == null && C.a4));
    return `<div class="rcs-lgx">
      <div class="rcs-lgp${src ? "" : " empty"}">${src ? `<img src="${E(src)}" alt=""${bw ? ' class="bw"' : ""}>` : `<span>لا يوجد شعار</span>`}</div>
      <div class="rcs-lgi"><b>${own ? "شعار خاص بهذا التصميم" : src ? "شعار الشركة (من الإعدادات)" : "ارفع شعار الشركة"}</b>
        <div class="rcs-lgb"><button type="button" data-a="lgup">${src ? "تغيير…" : "＋ رفع شعار"}</button>${own ? `<button type="button" data-a="lgclr" title="الرجوع لشعار الشركة">✕ إزالة</button>` : ""}</div></div></div>
      <div class="rcs-row"><span>مكان الشعار</span></div><div class="rcs-seg sm">${[["top", "فوق الاسم"], ["r", "يمين"], ["l", "يسار"]].map(a => `<button type="button" data-a="lgpos" data-v="${a[0]}" class="${pos === a[0] ? "on" : ""}">${a[1]}</button>`).join("")}</div>
      <div class="rcs-row"><span>ارتفاع الشعار</span><input type="range" min="6" max="${C.a4 ? 45 : 32}" step="1" data-k="lgH" value="${h}"><b>${h}مم</b></div>
      <div class="rcs-opts">${chk("lgBw", bw, "أبيض وأسود (للحرارية)")}</div>`;
  }
  const alignRow = b => `<div class="rcs-seg sm">${[["r", "يمين"], ["c", "وسط"], ["l", "يسار"]].map(a => `<button type="button" data-a="al" data-v="${a[0]}" class="${(b.al || "c") === a[0] ? "on" : ""}">${a[1]}</button>`).join("")}</div>`;
  function drawSide() {
    G("rcsBl").innerHTML = D.blocks.map((b, i) => `<div class="rcs-card${b.on ? " on" : ""}${open1 === b.id ? " open" : ""}" data-id="${b.id}" style="--i:${i}">
      <div class="rcs-ch"><span class="g" draggable="true" title="اسحب لإعادة الترتيب">${IC.grip}</span><label class="rcs-sw"><input type="checkbox" data-k="on"${b.on ? " checked" : ""}><i class="kn"></i></label>
        <span class="nm" data-a="open">${E(b.t === "text" ? (b.text || "سطر نص").slice(0, 22) : BLK[b.t])}</span>
        <button type="button" class="mv" data-a="up" title="لأعلى">▲</button><button type="button" class="mv" data-a="down" title="لأسفل">▼</button>${["text", "sep", "code", "sign", "pay", "pfoot"].includes(b.t) ? `<button type="button" class="mv rm" data-a="bdel" title="حذف القسم">✕</button>` : ""}
        ${blockBody(b) ? `<button type="button" class="ex" data-a="open" title="الإعدادات">⌄</button>` : ""}</div>
      ${open1 === b.id ? `<div class="rcs-cb">${blockBody(b)}</div>` : ""}</div>`).join("");
  }
  function sideDnD() {
    const L = G("rcsBl"); let drag = null;
    L.addEventListener("dragstart", e => { const g = e.target.closest(".g"); if (!g) { e.preventDefault(); return; } drag = g.closest(".rcs-card"); drag.classList.add("drag"); e.dataTransfer.effectAllowed = "move"; try { e.dataTransfer.setData("text/plain", drag.dataset.id); } catch (_) { } });
    L.addEventListener("dragover", e => { if (!drag) return; e.preventDefault(); const c = e.target.closest(".rcs-card"); if (!c || c === drag) return; const r = c.getBoundingClientRect(); if (e.clientY < r.top + r.height / 2) c.before(drag); else c.after(drag); });
    L.addEventListener("dragend", () => { if (!drag) return; drag.classList.remove("drag"); const ids = [...L.querySelectorAll(".rcs-card")].map(c => c.dataset.id); D.blocks.sort((a, b) => ids.indexOf(a.id) - ids.indexOf(b.id)); drag = null; persist(); drawPage(true); });
  }
  const blockOf = el => { const c = el.closest(".rcs-card"); return c ? D.blocks.find(b => b.id === c.dataset.id) : null; };

  /* ---------------- الأحداث ---------------- */
  function onClick(e) {
    const a = e.target.closest("[data-a]"); if (!a) return; const k = a.dataset.a, b = blockOf(a);
    if (k === "close") return close();
    if (k === "new") { const d = seed(); d.name = C.nm + " " + (DS.length + 1); DS.push(d); D = d; open1 = null; persist(); drawAll(); say("تصميم جديد: " + d.name, "i"); return; }
    if (k === "ren") { const n = prompt("اسم التصميم", D.name); if (n && n.trim()) { D.name = n.trim().slice(0, 40); persist(); drawSel(); } return; }
    if (k === "del") { if (DS.length < 2) { say("لا يمكن حذف التصميم الوحيد", "w"); return; } const go = () => { DS = DS.filter(x => x !== D); D = DS[0]; persist(); drawAll(); }; try { askConfirm("حذف التصميم «" + D.name + "» ؟", go); } catch (_) { if (confirm("حذف؟")) go(); } return; }
    if (k === "kf4" || k === "kf6") {
      const PR = KPR(); if (!PR) return; const p = PR.get("مبيعات"), id = KID();
      if (k === "kf6") { const on = p.f6 !== id; PR.set("مبيعات", { f6: on ? id : "" }); say(on ? "⚡ حفظ سريع F6 يطبع دائماً بـ «" + D.name + "»" : "أُلغي F6 من «" + D.name + "» — يرجع للإيصال 80 مم التلقائى", on ? "s" : "i"); drawKeys(6); return; }
      let f = p.fav.filter(x => x !== id); const on = f.length === p.fav.length;
      if (on) { f.push(id); if (f.length > 2) { const out = f.shift(); say("F4 تصميمان فقط — أُزيل «" + rcxName(out) + "»", "i"); } }
      PR.set("مبيعات", { fav: f });
      if (on) say("F4 «حفظ وطباعة» يعرض: " + f.map(rcxName).join(" + "), "s"); else say("أُزيل «" + D.name + "» من F4", "i");
      drawKeys(4); return;
    }
    if (k === "zi" || k === "zo" || k === "z1") { zoom = k === "z1" ? 1 : Math.max(.6, Math.min(3, r1(zoom + (k === "zi" ? .15 : -.15)))); LS.set(C.K + ".zoom", zoom); drawPage(); return; }
    if (k === "save") { LS.set(C.K + ".designs", DS); LS.set(C.K + ".cur", D.id); say("تم حفظ «" + D.name + "»", "s"); const w = OV.querySelector(".rcs"); w.classList.remove("saved"); void w.offsetWidth; w.classList.add("saved"); return; }
    if (k === "prev") return void doPrint(D, dataNow(), true);
    if (k === "print") return void doPrint(D, dataNow(), false);
    if (k === "img") return G("rcsFile").click();
    if (k === "wm") { const p = G("rcsWm"); p.hidden = !p.hidden; if (!p.hidden) drawWm(); a.classList.toggle("on", !p.hidden); OV.classList.toggle("wmedit", !p.hidden); return; }
    if (k === "wmx") { G("rcsWm").hidden = true; OV.classList.remove("wmedit"); const bb = OV.querySelector(".rcs-wmb"); if (bb) bb.classList.remove("on"); return; }
    if (k === "wmc0") { wmSet({ x: 0, y: 0, rot: 0 }); drawWm(); return; }
    if (k === "wmt") { wmSet({ type: a.dataset.v }); drawWm(); return; }
    if (k === "wmp") { wmSet({ text: a.dataset.v, smart: 0, on: 1 }); drawWm(); return; }
    if (k === "wmr") { wmSet({ rep: +a.dataset.v }); drawWm(); return; }
    if (k === "wmanc") { wmSet({ anc: a.dataset.v, x: 0, y: 0, on: 1 }); drawWm(); return; }
    if (k === "wml") { wmSet({ front: +a.dataset.v }); drawWm(); return; }
    if (k === "wmc") { wmSet({ color: a.dataset.v }); drawWm(); return; }
    if (k === "wmff") { wmSet({ ff: a.dataset.v, on: 1 }); drawWm(); return; }
    if (k === "wmsty") { wmSet({ sty: a.dataset.v, on: 1 }); drawWm(); return; }
    if (k === "wmsc") { wmSet({ sc: a.dataset.v }); drawWm(); return; }
    if (k === "wmf0") { const z = wmDef(); wmSet({ ff: z.ff, fw: z.fw, ls: z.ls, it: 0, sty: "fill", sk: z.sk, sc: z.sc, color: z.color }); drawWm(); say("رجع تنسيق الكتابة للافتراضي", "i"); return; }
    if (k === "wmimg") { const f = document.createElement("input"); f.type = "file"; f.accept = "image/*"; f.onchange = () => { const fl = f.files[0]; if (fl) imgData(fl, src => { wmSet({ src, type: "img", on: 1 }); drawWm(); }); }; f.click(); return; }
    if (k === "wmuse") { const m = D.imgs.find(x => x.id === a.dataset.v); if (m) { wmSet({ src: m.src, type: "img", on: 1 }); drawWm(); } return; }
    if (k === "add") { const t = a.dataset.t, nb = { id: uid(), t, on: 1 }; if (t === "text") { nb.text = "اكتب نصك هنا"; nb.al = "c"; nb.fs = 10; nb.b = 1; } if (t === "pay" || t === "pfoot") { const ex = D.blocks.find(x => x.t === t); if (ex) { ex.on = 1; open1 = ex.id; persist(); drawSide(); drawPage(true); return; } Object.assign(nb, t === "pay" ? payBlk() : pfBlk()); nb.id = uid(); if (t === "pfoot") { D.blocks.push(nb); open1 = nb.id; persist(); drawSide(); drawPage(true); return; } }
      if (t === "sign") { if (D.blocks.some(x => x.t === "sign")) { const ex = D.blocks.find(x => x.t === "sign"); ex.on = 1; open1 = ex.id; persist(); drawSide(); drawPage(true); return; } Object.assign(nb, { mode: "two", lab1: "توقيع البائع", lab2: "توقيع العميل", date: 1, stamp: 1 }); } const fi = D.blocks.findIndex(x => x.t === "foot"); D.blocks.splice(fi >= 0 ? fi : D.blocks.length, 0, nb); open1 = t === "text" || t === "sign" ? nb.id : null; persist(); drawSide(); drawPage(true); return; }
    if (k === "imgdel") { D.imgs = D.imgs.filter(m => m.id !== selImg); selImg = null; persist(); drawPage(); drawImgTools(); return; }
    if (k === "acc") { D.acc = a.dataset.v; persist(); drawSide(); drawPage(); return; }
    if (!b) return;
    if (k === "open") { open1 = open1 === b.id ? null : b.id; drawSide(); return; }
    if (k === "up" || k === "down") { const i = D.blocks.indexOf(b), j = i + (k === "up" ? -1 : 1); if (j < 0 || j >= D.blocks.length) return; D.blocks.splice(i, 1); D.blocks.splice(j, 0, b); persist(); drawSide(); drawPage(true); return; }
    if (k === "bdel") { D.blocks = D.blocks.filter(x => x !== b); persist(); drawSide(); drawPage(); return; }
    if (k === "sgm") b.mode = a.dataset.v;
    else if (k === "stc") b.stc = a.dataset.v;
    else if (k === "soc") b.soc = a.dataset.v;
    else if (k === "sgclr") b.src = "";
    else if (k === "lgup") { pickLogo(b); return; }
    else if (k === "lgclr") delete b.lg;
    else if (k === "lgpos") b.lgPos = a.dataset.v;
    else if (k === "sgdraw") { sigPad(b, "draw"); return; }
    else if (k === "sgtype") { sigPad(b, "type"); return; }
    else if (k === "sgup") { const f = document.createElement("input"); f.type = "file"; f.accept = "image/*"; f.onchange = () => { const fl = f.files[0]; if (fl) imgData(fl, src => { b.src = src; persist(); drawSide(); drawPage(); }); }; f.click(); return; }
    else if (k === "mode") b.mode = a.dataset.v;
    else if (k === "al") b.al = a.dataset.v;
    else if (k === "cmv") { const i = +a.dataset.ci, j = i + (+a.dataset.d); if (j < 0 || j >= b.cols.length) return; const [c] = b.cols.splice(i, 1); b.cols.splice(j, 0, c); }
    else if (k === "tmv") { const i = +a.dataset.ri, j = i + (+a.dataset.d); if (j < 0 || j >= b.rows.length) return; const [r] = b.rows.splice(i, 1); b.rows.splice(j, 0, r); }
    else if (k === "ladd") { b.lines = b.lines || []; b.lines.push([]); }
    else if (k === "ldel") { b.lines.splice(+a.dataset.li, 1); }
    else if (k === "tdel") { b.lines[+a.dataset.li].splice(+a.dataset.ti, 1); }
    else if (k === "tadd" || k === "tlit") {
      b.lines = b.lines || []; if (!b.lines.length) b.lines.push([]);
      let v = a.dataset.v; if (k === "tlit") { const t = prompt("النص (مثال: القطعة)", ""); if (!t) return; v = '"' + t.trim() + '"'; }
      b.lines[b.lines.length - 1].push(v);
    }
    else if (k === "lpre") { const P = { 1: ["qty", "×", "price", "=", "total"], 2: ['"القطعة"', "one", "×", "factor", "=", "bigp"], 3: ["unit", '":"', "qty", "×", "price", "=", "total"] }; b.lines = b.lines || []; b.lines.push(P[a.dataset.v].slice()); }
    else return;
    persist(); drawSide(); drawPage();
  }
  function setK(b, key, v) {
    if (key === "on") b.on = v ? 1 : 0;
    else if (key.startsWith("f.")) { b.f = b.f || {}; b.f[key.slice(2)] = v ? 1 : 0; }
    else if (key.startsWith("col.")) b.cols[+key.slice(4)].on = v ? 1 : 0;
    else if (key.startsWith("colw.")) b.cols[+key.slice(5)].w = +v;
    else if (key.startsWith("row.")) b.rows[+key.slice(4)].on = v ? 1 : 0;
    else if (key.startsWith("rowb.")) b.rows[+key.slice(5)].b = v ? 1 : 0;
    else if (["hdr", "zebra", "b", "date", "stamp", "pblk", "hint", "pcm", "dsc"].includes(key)) b[key] = v ? 1 : 0;
    else if (["lab1", "lab2", "stt", "stm", "t2", "brand", "handle"].includes(key)) b[key] = v;
    else if (key === "code" || key === "pg") b[key] = v ? 1 : 0;
    else if (key === "str") b.str = +v;
    else if (["fs", "nameFs", "lgH"].includes(key)) b[key] = +v;
    else if (key === "lgBw") b.lgBw = v ? 1 : 0;
    else if (key === "text") b.text = v;
  }
  function onChange(e) {
    const t = e.target;
    if (t.dataset && t.dataset.wm) { const k = t.dataset.wm; if (t.type === "checkbox") { wmSet({ [k]: t.checked ? 1 : 0 }); if (k === "smart" || k === "on" || k === "it") drawWm(); } else if (t.type === "color") { wmSet({ color: t.value, on: 1 }); drawWm(); } else if (k === "text") wmSet({ text: t.value, on: 1 }); return; }
    if (t.id === "rcsW") { D.w = +t.value; if (D.a4) { D.h = D.w < 180 ? 210 : 297; D.pad = D.w < 180 ? 6 : 9; } persist(); drawPage(true); return; }
    if (t.id === "rcsFs") { D.fs = +t.value; persist(); drawPage(); return; }
    if (t.id === "rcsSep") { D.sep = t.value; persist(); drawPage(); return; }
    if (t.id === "rcsFit") { D.fit = t.checked ? 1 : 0; persist(); drawPage(); say(D.fit ? "ملاءمة صفحة واحدة مفعّلة" : "الصفحات تُقسَّم بدون تصغير", "i"); return; }
    if (t.id === "rcsUse") { D.use = t.checked ? 1 : 0; DS.forEach(x => { if (x !== D && D.use) x.use = 0; }); if (D.use) (window.__RCX || []).forEach(x => { if (x !== API) x.clearUse(); }); persist(); drawSel(); say(D.use ? "سيُستعمل «" + D.name + "» في طباعة فواتير المبيعات" : "رجعت الطباعة لتصاميم التقارير", D.use ? "s" : "i"); return; }
    if (t.id === "imgop") return;
    const k = t.dataset.k, b = blockOf(t); if (!k || !b) return;
    setK(b, k, t.type === "checkbox" ? t.checked : t.value);
    if (k === "on") { const c = t.closest(".rcs-card"); if (c) c.classList.toggle("on", t.checked); drawPage(true); persist(); return; }
    persist(); if (/^(col\.|row\.)/.test(k) || k === "stamp") drawSide(); drawPage();
  }
  function onInput(e) {
    const t = e.target, k = t.dataset && t.dataset.k;
    if (t.dataset && t.dataset.wm && t.type === "range") { const v = +t.value, wk = t.dataset.wm; wmSet({ [wk]: v, on: 1 }); const lb = t.nextElementSibling; if (lb) lb.textContent = wk === "op" ? Math.round(v * 100) + "%" : v + ({ fs: "pt", w: "%", rot: "°", sk: "مم", ls: "مم" }[wk] || ""); const on = G("rcsWm").querySelector('[data-wm="on"]'); if (on) on.checked = true; wmPv(); return; }
    if (t.dataset && t.dataset.wm === "color" && t.type === "color") { wmSet({ color: t.value, on: 1 }); wmPv(); const p = G("rcsWm"), cd = p.querySelector(".rcs-wmc.cl code"); if (cd) cd.textContent = t.value.toUpperCase(); p.querySelectorAll('.rcs-wmc.cl [data-a="wmc"]').forEach(b => b.classList.remove("on")); const cp = t.closest(".cp"); if (cp) cp.classList.add("on"); return; }
    if (t.dataset && t.dataset.wm === "text") { wmSet({ text: t.value, on: 1 }); const on = G("rcsWm").querySelector('[data-wm="on"]'); if (on) on.checked = true; return; }
    if (t.id === "imgw" || t.id === "imgop") { const m = D.imgs.find(x => x.id === selImg); if (!m) return; if (t.id === "imgw") m.w = +t.value; else m.op = +t.value; persist(); drawPage(); return; }
    if (!k) return; const b = blockOf(t); if (!b) return;
    if (t.tagName === "INPUT" && t.type === "text" || (t.tagName === "INPUT" && !t.type) || (t.tagName === "INPUT" && ["lab1", "lab2", "stt", "stm", "t2", "brand", "handle"].includes(k))) { if (["lab1", "lab2", "stt", "stm", "t2", "brand", "handle"].includes(k)) { setK(b, k, t.value); persist(); drawPage(); return; } }
    if (t.type === "range" || t.tagName === "TEXTAREA") { setK(b, k, t.value); const lb = t.nextElementSibling; if (lb && lb.tagName === "B") lb.textContent = t.value + (k === "str" ? "°" : k === "lgH" ? "مم" : "pt"); persist(); drawPage(); if (k === "text" && b.t === "text") { const nm = t.closest(".rcs-card").querySelector(".nm"); if (nm) nm.textContent = (t.value || "سطر نص").slice(0, 22); } }
  }

  /* ---------------- لوحة التوقيع: رسم بخط ناعم (يتأثر بالسرعة) أو كتابة الاسم بخط يدوي ---------------- */
  function sigPad(b, mode) {
    const ov = document.createElement("div"); ov.className = "rcs-sgov"; ov.setAttribute("data-dk-skip", "");
    ov.innerHTML = `<div class="rcs-sgd"><div class="rcs-sgh"><b>✍ ${mode === "type" ? "اكتب اسمك كتوقيع" : "ارسم توقيعك"}</b><span class="sp"></span><button type="button" data-s="x" class="x">${IC.x}</button></div>
      ${mode === "type" ? `<input class="rcs-sgn" placeholder="اكتب الاسم…" value="${E((CO && CO["Company Name"]) || "")}"><div class="rcs-sgfs">${["Segoe Script", "Brush Script MT", "Lucida Handwriting", "Ink Free", "Gabriola"].map((f, i) => `<button type="button" data-f="${E(f)}" class="${i ? "" : "on"}" style="font-family:'${f}',cursive">${E(f.split(" ")[0])}</button>`).join("")}</div>` : ""}
      <div class="rcs-sgc"><canvas width="900" height="320"></canvas><span class="hint">${mode === "type" ? "" : "وقّع هنا بالفأرة أو بالقلم أو بإصبعك"}</span><i class="base"></i></div>
      <div class="rcs-sgk">${["#0b1f6b", "#000", "#1d4ed8", "#7c2d12"].map((c, i) => `<button type="button" data-c="${c}" style="--c:${c}" class="${i ? "" : "on"}"></button>`).join("")}<span class="sp"></span>${mode === "type" ? "" : '<button type="button" data-s="undo">↶ تراجع</button>'}<button type="button" data-s="clr">مسح</button><button type="button" class="ok" data-s="ok">اعتماد التوقيع</button></div></div>`;
    document.body.appendChild(ov);
    const cv = ov.querySelector("canvas"), cx = cv.getContext("2d"), q = s => ov.querySelector(s);
    let col = "#0b1f6b", font = "Segoe Script", strokes = [], cur = null;
    const redraw = () => {
      cx.clearRect(0, 0, cv.width, cv.height);
      if (mode === "type") { const t = (q(".rcs-sgn").value || "").trim(); if (!t) return; cx.fillStyle = col; let fs = 150; cx.font = `${fs}px '${font}',cursive`; while (cx.measureText(t).width > cv.width - 60 && fs > 30) { fs -= 6; cx.font = `${fs}px '${font}',cursive`; } cx.textAlign = "center"; cx.textBaseline = "middle"; cx.fillText(t, cv.width / 2, cv.height / 2 + 10); return; }
      strokes.forEach(st => { cx.strokeStyle = st.c; cx.lineCap = cx.lineJoin = "round"; for (let i = 1; i < st.p.length; i++) { const a = st.p[i - 1], c = st.p[i], m = i > 1 ? st.p[i - 2] : a; cx.lineWidth = c.w; cx.beginPath(); cx.moveTo((m.x + a.x) / 2, (m.y + a.y) / 2); cx.quadraticCurveTo(a.x, a.y, (a.x + c.x) / 2, (a.y + c.y) / 2); cx.stroke(); } });
      q(".hint").style.opacity = strokes.length ? 0 : 1;
    };
    const pos = e => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * cv.width / r.width, y: (e.clientY - r.top) * cv.height / r.height, t: performance.now() }; };
    if (mode !== "type") {
      cv.addEventListener("pointerdown", e => { e.preventDefault(); cv.setPointerCapture(e.pointerId); const p = pos(e); p.w = 5; cur = { c: col, p: [p] }; strokes.push(cur); });
      cv.addEventListener("pointermove", e => { if (!cur) return; const p = pos(e), l = cur.p[cur.p.length - 1], d = Math.hypot(p.x - l.x, p.y - l.y), v = d / Math.max(1, p.t - l.t);
        const pr = e.pressure && e.pointerType === "pen" ? e.pressure : 0; p.w = Math.max(1.6, Math.min(7, (pr ? 2 + pr * 7 : 7.5 - v * 2.4) * .55 + l.w * .45)); if (d > 1.2) { cur.p.push(p); redraw(); } });
      const end = () => { cur = null; }; cv.addEventListener("pointerup", end); cv.addEventListener("pointercancel", end);
    } else { q(".rcs-sgn").addEventListener("input", redraw); q(".rcs-sgfs").addEventListener("click", e => { const f = e.target.closest("[data-f]"); if (!f) return; font = f.dataset.f; ov.querySelectorAll(".rcs-sgfs button").forEach(x => x.classList.toggle("on", x === f)); redraw(); }); setTimeout(() => { const n = q(".rcs-sgn"); n.focus(); n.select(); redraw(); }, 40); }
    q(".rcs-sgk").addEventListener("click", e => { const c = e.target.closest("[data-c]"); if (!c) return; col = c.dataset.c; ov.querySelectorAll(".rcs-sgk [data-c]").forEach(x => x.classList.toggle("on", x === c)); strokes.forEach(s => s.c = col); redraw(); });
    const close = () => { ov.remove(); document.removeEventListener("keydown", kd, true); };
    const kd = e => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); } else e.stopPropagation(); };
    document.addEventListener("keydown", kd, true);
    ov.addEventListener("click", e => {
      const s = e.target.closest("[data-s]"); if (!s) { if (e.target === ov) close(); return; }
      if (s.dataset.s === "x") close();
      else if (s.dataset.s === "undo") { strokes.pop(); redraw(); }
      else if (s.dataset.s === "clr") { strokes = []; if (mode === "type") q(".rcs-sgn").value = ""; redraw(); }
      else if (s.dataset.s === "ok") {
        /* قصّ الفراغ حول التوقيع */
        const d = cx.getImageData(0, 0, cv.width, cv.height).data; let x0 = cv.width, y0 = cv.height, x1 = 0, y1 = 0;
        for (let y = 0; y < cv.height; y += 2) for (let x = 0; x < cv.width; x += 2) if (d[(y * cv.width + x) * 4 + 3] > 20) { if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y; }
        if (x1 <= x0) { say("ارسم التوقيع أولاً", "w"); return; }
        const m = 10, w = Math.min(cv.width, x1 - x0 + 2 * m), h = Math.min(cv.height, y1 - y0 + 2 * m), o = document.createElement("canvas"); o.width = w; o.height = h;
        o.getContext("2d").drawImage(cv, Math.max(0, x0 - m), Math.max(0, y0 - m), w, h, 0, 0, w, h);
        b.src = o.toDataURL("image/png"); b.on = 1; persist(); close(); drawSide(); drawPage(true); say("تم اعتماد التوقيع ✍", "s");
      }
    });
    redraw();
  }
  /* ---------------- لوحة العلامة المائية ---------------- */
  /* سحب العلامة المائية على الورقة: تحريك / حجم / تدوير */
  function onWmDown(e) {
    if (!OV || !OV.classList.contains("wmedit")) return;
    const v = e.target.closest("[data-wmv]"); if (!v) return;
    e.preventDefault(); e.stopPropagation();
    const w0 = Object.assign(wmDef(), D.wm || {}), hd = e.target.closest("[data-wmh]"), mode = hd ? hd.dataset.wmh : "m", k = PX * zoom;
    const rc = v.getBoundingClientRect(), cx = rc.left + rc.width / 2, cy = rc.top + rc.height / 2, sx = e.clientX, sy = e.clientY;
    const d0 = Math.max(4, Math.hypot(sx - cx, sy - cy)), a0 = Math.atan2(sy - cy, sx - cx) * 180 / Math.PI, isImg = w0.type === "img", rep = !!w0.rep, sp = v.querySelector("span");
    let cur = { x: +w0.x || 0, y: +w0.y || 0, rot: +w0.rot || 0, fs: +w0.fs || 30, w: +w0.w || 60 };
    const paint = () => {
      if (rep && isImg) v.style.transform = `translate(${cur.x}mm,${cur.y}mm)`;
      else v.style.transform = `translate(${cur.x}mm,${cur.y}mm) rotate(${cur.rot}deg)`;
      if (!rep && isImg) v.style.width = cur.w + "%"; else if (!rep && sp) sp.style.fontSize = cur.fs + "pt";
    };
    v.setPointerCapture(e.pointerId); v.classList.add("drag");
    const mv = ev => {
      if (mode === "m") { cur.x = r1((+w0.x || 0) + (ev.clientX - sx) / k); cur.y = r1((+w0.y || 0) + (ev.clientY - sy) / k); }
      else if (mode === "s") { const f = Math.hypot(ev.clientX - cx, ev.clientY - cy) / d0; if (isImg) cur.w = Math.round(Math.max(8, Math.min(200, (+w0.w || 60) * f))); else cur.fs = Math.round(Math.max(6, Math.min(160, (+w0.fs || 30) * f))); }
      else { let r = Math.round((+w0.rot || 0) + Math.atan2(ev.clientY - cy, ev.clientX - cx) * 180 / Math.PI - a0); r = ((r + 540) % 360) - 180; const sn = [-90, -45, 0, 45, 90].find(q => Math.abs(q - r) <= 4); cur.rot = Math.max(-90, Math.min(90, sn != null ? sn : r)); }
      paint();
    };
    const up = () => { v.removeEventListener("pointermove", mv); v.removeEventListener("pointerup", up); v.classList.remove("drag"); const o = { x: cur.x, y: cur.y, rot: cur.rot }; if (mode === "s") { if (isImg) o.w = cur.w; else o.fs = cur.fs; } wmSet(o); drawWm(); };
    v.addEventListener("pointermove", mv); v.addEventListener("pointerup", up);
  }
  function wmPv() { const e = G("rcsWm") && G("rcsWm").querySelector("[data-wmpv]"); if (e) e.setAttribute("style", wmTS(Object.assign(wmDef(), D.wm || {}))); }
  function wmSet(o) { D.wm = Object.assign(wmDef(), D.wm || {}, o); persist(); drawPage(); }
  /* ✍️ نافذة تنسيق الكتابة: الخط · اللون · الوضوح (السماكة / الحدّ / التباعد / مائل) */
  function wmFontCard(w, rng, sw) {
    const fl = fontsOK().slice(); if (w.ff && !fl.some(f => f[0] === w.ff)) fl.unshift([w.ff, w.ff]);
    const nc = String(w.color || "#000").toLowerCase(), hex = /^#[0-9a-f]{3}$/.test(nc) ? "#" + nc.slice(1).replace(/./g, c => c + c) : nc;
    const sty = w.sty || "fill", pvT = E(wmText(w, (DATA && DATA.header) || sample().header || {}, Object.assign({}, sample().company, CO || {})));
    return `<div class="rcs-wmf">
      <div class="hd"><b>✍️ تنسيق الكتابة</b><span>الخط · اللون · الوضوح</span><button type="button" data-a="wmf0" title="رجوع للتنسيق الافتراضي">↺</button></div>
      <div class="pv"><span data-wmpv style="${wmTS(w)}">${pvT}</span></div>
      <div class="ff">${fl.map(([f, t]) => `<button type="button" data-a="wmff" data-v="${E(f)}" class="${(w.ff || "Droid Arabic Kufi") === f ? "on" : ""}" style="font-family:'${E(f)}',sans-serif" title="${E(f)}"><b>أبجد Ab</b><small>${E(t)}</small></button>`).join("")}</div>
      <div class="lb">لون الخط</div>
      <div class="rcs-wmc cl">${WM_COLORS.map(c => `<button type="button" data-a="wmc" data-v="${c}" style="--c:${c}" class="${hex === c ? "on" : ""}" title="${c}"></button>`).join("")}<label class="cp${WM_COLORS.includes(hex) ? "" : " on"}" title="لون مخصّص"><input type="color" data-wm="color" value="${/^#[0-9a-f]{6}$/.test(hex) ? hex : "#000000"}"></label><code dir="ltr">${E(hex.toUpperCase())}</code></div>
      <div class="lb">وضوح الخط</div>
      <div class="rcs-seg sm">${[["fill", "ممتلئ"], ["both", "ممتلئ بحدّ"], ["line", "مفرّغ"]].map(([v, t]) => `<button type="button" data-a="wmsty" data-v="${v}" class="${sty === v ? "on" : ""}">${t}</button>`).join("")}</div>
      ${rng("fw", 300, 900, 100, w.fw || 900, "السماكة")}
      ${sty !== "fill" ? rng("sk", .05, 1.2, .05, w.sk || .25, "سُمك الحدّ", "مم") : ""}
      ${sty === "both" ? `<div class="rcs-wmc sm"><span>لون الحدّ</span>${["#000000", "#ffffff", "#b91c1c", "#1d4ed8", "#b8860b"].map(c => `<button type="button" data-a="wmsc" data-v="${c}" style="--c:${c}" class="${(w.sc || "#000000").toLowerCase().replace(/^#000$/, "#000000") === c ? "on" : ""}"></button>`).join("")}</div>` : ""}
      ${rng("ls", -.5, 4, .1, w.ls == null ? .5 : w.ls, "التباعد", "مم")}
      <div class="tg">${sw("it", w.it, "مائل")}</div>
    </div>`;
  }
  function drawWm() {
    const p = G("rcsWm"), w = Object.assign(wmDef(), D.wm || {});
    const sw = (k, on, t) => `<label class="rcs-sw2"><input type="checkbox" data-wm="${k}"${on ? " checked" : ""}><i></i><span>${t}</span></label>`;
    const rng = (k, mn, mx, st, v, t, u) => `<label class="rcs-wr"><span>${t}</span><input type="range" data-wm="${k}" min="${mn}" max="${mx}" step="${st}" value="${v}"><b>${k === "op" ? Math.round(v * 100) + "%" : v + (u || "")}</b></label>`;
    p.innerHTML = `<div class="rcs-wmh"><b>💧 العلامة المائية</b>${sw("on", w.on, "تفعيل")}<span class="sp"></span><button type="button" data-a="wmx" class="x">${IC.x}</button></div>
      <div class="rcs-wmtip">✥ <b>اسحب العلامة على الورقة</b> لتحريكها · الدائرة الوردية <b>للحجم</b> · العلوية <b>للتدوير</b> · نقرتان للتوسيط <button type="button" data-a="wmc0">↺ توسيط</button></div>
      <div class="rcs-seg sm"><button type="button" data-a="wmt" data-v="text" class="${w.type !== "img" ? "on" : ""}">نص</button><button type="button" data-a="wmt" data-v="img" class="${w.type === "img" ? "on" : ""}">صورة</button></div>
      ${w.type !== "img" ? `<div class="rcs-wmg"><input data-wm="text" value="${E(w.text)}" placeholder="اكتب نص العلامة (افتراضي: اسم الشركة)"${w.smart ? " disabled" : ""}>${sw("smart", w.smart, "ذكية: مدفوع / غير مدفوع / مرتجع تلقائياً")}</div>
        <div class="rcs-wmp">${WM_PICK.map(t => `<button type="button" data-a="wmp" data-v="${E(t)}" class="${!w.smart && w.text === t ? "on" : ""}">${E(t)}</button>`).join("")}</div>
        ${wmFontCard(w, rng, sw)}`
      : `<div class="rcs-wmi">${w.src ? `<img src="${w.src}" alt="">` : '<i>لا توجد صورة</i>'}<button type="button" data-a="wmimg">اختيار صورة…</button>${D.imgs.length ? `<span>أو من صور الإيصال:</span>${D.imgs.map(m => `<button type="button" class="th" data-a="wmuse" data-v="${m.id}"><img src="${m.src}" alt=""></button>`).join("")}` : ""}</div>`}
      ${w.type !== "img" ? rng("fs", 8, 72, 1, w.fs, "الحجم", "pt") : rng("w", 15, 100, 1, w.w, "الحجم", "%")}
      ${rng("rot", -90, 90, 1, w.rot, "الزاوية", "°")}${rng("op", .03, 1, .01, w.op, "الشفافية")}
      <div class="rcs-seg sm"><button type="button" data-a="wmr" data-v="0" class="${!w.rep ? "on" : ""}">في الوسط</button><button type="button" data-a="wmr" data-v="1" class="${w.rep ? "on" : ""}">متكررة على الإيصال كله</button></div>
      ${!C.a4 && !w.rep ? `<div class="rcs-wmanc"><span>مكان العلامة في الإيصال</span><div class="rcs-seg sm">${[["tot", "مع الإجماليات"], ["bot", "الأسفل"], ["c", "الوسط"], ["top", "الأعلى"]].map(x => `<button type="button" data-a="wmanc" data-v="${x[0]}" class="${(w.anc || "tot") === x[0] ? "on" : ""}">${x[1]}</button>`).join("")}</div><small>«مع الإجماليات»: تبقى فوق المدفوع والصافي في أسفل الإيصال مهما طالت الفاتورة</small></div>` : ""}
      <div class="rcs-seg sm"><button type="button" data-a="wml" data-v="0" class="${!w.front ? "on" : ""}">خلف النص</button><button type="button" data-a="wml" data-v="1" class="${w.front ? "on" : ""}">فوق النص</button></div>`;
  }
  function pickLogo(b) {
    const f = document.createElement("input"); f.type = "file"; f.accept = "image/*";
    f.onchange = () => { const fl = f.files[0]; if (!fl || !/^image\//.test(fl.type)) return; logoData(fl, src => { b.lg = src; b.f = b.f || {}; b.f.logo = 1; persist(); drawSide(); drawPage(); }); };
    f.click();
  }
  /* الشعار: نحافظ على الشفافية (PNG) ونقصّ الحواف البيضاء/الفارغة حتى يلتصق بالنص */
  function logoData(file, cb) {
    const rd = new FileReader(); rd.onload = () => { const im = new Image(); im.onload = () => {
      const k = Math.min(1, 700 / Math.max(im.naturalWidth, im.naturalHeight)), W = Math.max(1, Math.round(im.naturalWidth * k)), H = Math.max(1, Math.round(im.naturalHeight * k));
      const c = document.createElement("canvas"); c.width = W; c.height = H; const g = c.getContext("2d"); g.drawImage(im, 0, 0, W, H);
      try { const px = g.getImageData(0, 0, W, H).data; let x0 = W, y0 = H, x1 = -1, y1 = -1;
        for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const i = (y * W + x) * 4; if (px[i + 3] > 16 && (px[i] < 245 || px[i + 1] < 245 || px[i + 2] < 245)) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; } }
        if (x1 >= x0 && y1 >= y0 && (x1 - x0 + 1 < W - 2 || y1 - y0 + 1 < H - 2)) { const p = 2, cx = Math.max(0, x0 - p), cy = Math.max(0, y0 - p), cw = Math.min(W, x1 + p + 1) - cx, ch = Math.min(H, y1 + p + 1) - cy, c2 = document.createElement("canvas"); c2.width = cw; c2.height = ch; c2.getContext("2d").drawImage(c, cx, cy, cw, ch, 0, 0, cw, ch); cb(c2.toDataURL("image/png")); return; }
      } catch (e) { }
      cb(c.toDataURL("image/png")); }; im.src = rd.result; }; rd.readAsDataURL(file);
  }
  function imgData(file, cb) {
    const rd = new FileReader(); rd.onload = () => { const im = new Image(); im.onload = () => { const k = Math.min(1, 520 / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement("canvas"); c.width = Math.round(im.naturalWidth * k); c.height = Math.round(im.naturalHeight * k); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); cb(c.toDataURL("image/png")); }; im.src = rd.result; }; rd.readAsDataURL(file);
  }
  /* ---------------- الصور ---------------- */
  function addImg(file) {
    if (!/^image\//.test(file.type)) return;
    const rd = new FileReader();
    rd.onload = () => { const im = new Image(); im.onload = () => {
      const k = Math.min(1, 520 / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement("canvas"); c.width = Math.round(im.naturalWidth * k); c.height = Math.round(im.naturalHeight * k);
      c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
      const src = /png|gif|webp|svg/.test(file.type) ? c.toDataURL("image/png") : c.toDataURL("image/jpeg", .88);
      const w = Math.min(30, D.w * .4), m = { id: "i" + uid(), src, x: r1((D.w - w) / 2), y: 2, w, op: 1 };
      D.imgs.push(m); selImg = m.id; persist(); drawPage(); drawImgTools(); say("أُضيفت الصورة — اسحبها لأي مكان", "s");
    }; im.src = rd.result; };
    rd.readAsDataURL(file);
  }
  function onImgDown(e) {
    const n = e.target.closest("[data-img]"); if (!n) return; e.preventDefault(); e.stopPropagation();
    const m = D.imgs.find(x => x.id === n.dataset.img); if (!m) return;
    selImg = m.id; G("rcsPg").querySelectorAll("[data-img]").forEach(x => x.classList.toggle("sel", x === n)); drawImgTools();
    const k = PX * zoom, sx = e.clientX, sy = e.clientY, ox = m.x, oy = m.y, rz = e.shiftKey || e.altKey;
    n.setPointerCapture(e.pointerId);
    const mv = ev => { const dx = (ev.clientX - sx) / k, dy = (ev.clientY - sy) / k; if (rz) m.w = r1(Math.max(5, m.w + dx / 6)); else { m.x = r1(Math.max(-10, Math.min(D.w - 3, ox + dx))); m.y = r1(Math.max(-5, oy + dy)); } n.style.left = m.x + "mm"; n.style.top = m.y + "mm"; n.style.width = m.w + "mm"; };
    const up = () => { n.removeEventListener("pointermove", mv); n.removeEventListener("pointerup", up); persist(); };
    n.addEventListener("pointermove", mv); n.addEventListener("pointerup", up);
  }
  function drawImgTools() {
    const t = G("rcsIt"), m = D.imgs.find(x => x.id === selImg);
    if (!m) { t.hidden = true; return; }
    t.hidden = false;
    t.innerHTML = `${IC.img}<span>الصورة</span><label>الحجم<input type="range" id="imgw" min="5" max="${D.w}" step=".5" value="${m.w}"></label><label>الشفافية<input type="range" id="imgop" min=".1" max="1" step=".05" value="${m.op == null ? 1 : m.op}"></label><button type="button" data-a="imgdel">حذف الصورة</button><small>اسحب الصورة لتحريكها</small>`;
  }

  /* ---------------- الرسم ---------------- */
  /* ✦ أزرار المبيعات: F4 «حفظ وطباعة» (حتى تصميمين يظهران وحدهما) و ⚡F6 «حفظ سريع» (تصميم واحد مباشرة) */
  const KID = () => "rcx:" + C.K + ":" + (D.id || D.name);
  const KPR = () => window.ANOUER_RD && ANOUER_RD.rcptPref;
  function rcxName(id) {
    let n = ""; (window.__RCX || []).forEach(A => { try { (A.list() || []).forEach(d => { if ("rcx:" + A.K + ":" + (d.id || d.name) === id) n = d.name; }); } catch (e) { } });
    if (!n && window.ANOUER_RD && ANOUER_RD.idx) { try { const it = (ANOUER_RD.idx().items || []).find(x => x.id === id); if (it) n = it.name; } catch (e) { } }
    return n || "تصميم آخر";
  }
  function drawKeys(pop) {
    const el = G("rcsKeys"); if (!el) return; const PR = KPR(); if (!PR) { el.hidden = true; return; }
    const p = PR.get("مبيعات"), id = KID(), f4 = p.fav.indexOf(id) >= 0, f6 = p.f6 === id;
    const other4 = p.fav.filter(x => x !== id).map(rcxName);
    el.hidden = false;
    el.innerHTML = `<button type="button" class="rcs-kb k4${f4 ? " on" : ""}${pop === 4 ? " pop" : ""}" data-a="kf4" title="${E(f4 ? "مُضاف لـ F4 — اضغط للإزالة" : "أضفه لـ F4: يظهر في نافذة «اختيار الوصل» عند الضغط على F4 (حتى تصميمين)")}${other4.length ? E(" — معه: " + other4.join(" + ")) : ""}"><b>F4</b><span>حفظ وطباعة</span><i>${f4 ? "✓" : "+"}</i></button>`
      + `<button type="button" class="rcs-kb k6${f6 ? " on" : ""}${pop === 6 ? " pop" : ""}" data-a="kf6" title="${E(f6 ? "هذا تصميم «حفظ سريع F6» — يطبع مباشرة بدون نافذة" : "اجعله تصميم «حفظ سريع F6»" + (p.f6 ? " (بدل «" + rcxName(p.f6) + "»)" : ""))}"><b>⚡F6</b><span>حفظ سريع</span><i>${f6 ? "✓" : "+"}</i></button>`;
  }
  function drawSel() { G("rcsSel").innerHTML = DS.map(d => `<option value="${E(d.id)}"${d === D ? " selected" : ""}>${E(d.name)}${d.use ? " ✔" : ""}</option>`).join(""); }
  function drawPage(anim) {
    const pg = G("rcsPg"); pg.innerHTML = receiptHTML(D, dataNow(), true);
    const rr = pg.firstElementChild; pg.style.transform = `scale(${zoom})`;
    requestAnimationFrame(() => { const h = rr.offsetHeight;
      let hh = h;
      if (D.a4) { const ph = (D.h || 297) - D.pad - padB(D), inn = rr.querySelector(".rr-in"); let sc = 1; const H = inn ? inn.offsetHeight : 0, php = ph * PX;
        if (inn && D.fit !== 0 && H > php + 2 && php / H >= FITMIN) { sc = Math.floor(php / H * 1000) / 1000 - .004; inn.style.zoom = sc; const fb = document.createElement("div"); fb.className = "rr-fitb"; fb.innerHTML = "📐 صفحة واحدة — " + Math.round(sc * 100) + "%"; fb.title = "المحتوى أطول قليلاً من الورقة فصُغّر ليخرج في ورقة واحدة بمقاسها (أوقفه من «ملاءمة صفحة واحدة»)"; rr.appendChild(fb); }
        const hm = D.pad + (H * sc) / PX + .5; let n = 1; for (let k = 1; D.pad + k * ph < hm - 1 && k < 30; k++) { n = k + 1; const m = document.createElement("div"); m.className = "rr-pgb"; m.style.top = (D.pad + k * ph) + "mm"; m.innerHTML = `<span>صفحة ${k + 1}</span>`; rr.appendChild(m); }
        rr.style.minHeight = (n * (D.h || 297)) + "mm"; hh = rr.offsetHeight; const pp = rr.querySelector(".rr-pf.scr .pf-pg"); if (pp) pp.textContent = n + "/" + n; }
      G("rcsSz").style.width = (D.w * PX * zoom) + "px"; G("rcsSz").style.height = (hh * zoom) + "px"; });
    G("rcsZv").textContent = Math.round(zoom * 100) + "%";
    if (anim && !RM()) { pg.classList.remove("pop"); void pg.offsetWidth; pg.classList.add("pop"); }
    if (open1) { const s = pg.querySelector(`[data-b="${open1}"]`); if (s) s.classList.add("hl"); }
  }
  function drawAll() {
    drawSel(); drawKeys(); G("rcsW").value = String(D.w); G("rcsFs").value = String(D.fs); G("rcsSep").value = D.sep || "dash"; G("rcsUse").checked = !!D.use; if (G("rcsFit")) G("rcsFit").checked = D.fit !== 0;
    G("rcsSrc").textContent = DATA ? "المعاينة: الفاتورة المعروضة" : "المعاينة: بيانات تجريبية / الفاتورة الحالية";
    drawSide(); drawPage(true); drawImgTools(); if (!G("rcsWm").hidden) drawWm();
  }
  function key(e) {
    if (!OV || !OV.classList.contains("show")) return;
    const pv = G("rcsPvG");
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); if (pv && pv.classList.contains("show")) pv.classList.remove("show"); else if (selImg) { selImg = null; drawPage(); drawImgTools(); } else close(); return; }
    if (selImg && (e.key === "Delete") && !/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) { e.preventDefault(); e.stopPropagation(); D.imgs = D.imgs.filter(m => m.id !== selImg); selImg = null; persist(); drawPage(); drawImgTools(); return; }
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || /^F\d+$/.test(e.key) || e.ctrlKey || e.altKey) e.stopPropagation();
  }
  function open(data) {
    build(); DATA = data || null; loadCo(); OV.classList.toggle("wmedit", !G("rcsWm").hidden); drawAll();
    OV.classList.add("show"); document.addEventListener("keydown", key, true);
  }
  function close() { if (!OV) return; OV.classList.remove("show"); document.removeEventListener("keydown", key, true); LS.set(C.K + ".designs", DS); LS.set(C.K + ".cur", D.id); }

  /* ---------------- الربط: مربع في شريط المعاينة + الطباعة بالتصميم ---------------- */
  function tileIn(ov, data) {
    const rb = ov && ov.querySelector(".rdp-rb"); if (!rb || rb.querySelector(`[data-st="${C.K}"]`)) return;
    const g = document.createElement("div"); g.className = "rdr-g rcs-g";
    g.innerHTML = `<div class="rdr-gi"><button type="button" class="rcs-tile${C.cls ? " " + C.cls : ""}" data-st="${C.K}" title="${C.title} — ${C.tip}">${C.a4 ? IC.a4 : IC.magic}<span>${C.tile.replace(" ", "<br>")}</span><em>${C.badge || "جديد"}</em></button></div><div class="rdr-gt">${C.badge || "Studio"}</div>`;
    const prv = C.after && rb.querySelector(`[data-st="${C.after}"]`); if (prv) prv.closest(".rdr-g").after(g); else rb.insertBefore(g, rb.firstChild);
    g.querySelector("button").addEventListener("click", e => { e.stopPropagation(); open(data); });
  }
  function hook() {
    if (!window.ANOUER_RDP || !ANOUER_RDP.open || ANOUER_RDP.open[FL]) return !!(window.ANOUER_RDP && ANOUER_RDP.open && ANOUER_RDP.open[FL]);
    const _o = ANOUER_RDP.open;
    ANOUER_RDP.open = function (design, data, o) { const r = _o.apply(this, arguments); try { const ovs = document.querySelectorAll(".rdp-ov"); tileIn(ovs[ovs.length - 1], data); } catch (e) { } return r; };
    ANOUER_RDP.open[FL] = 1;
    const RD = window.ANOUER_RD;
    /* طباعة فواتير المبيعات (F4 / F6 / مراجعة المبيعات): غلاف واحد لكل الاستوديوهات
       • «استعمل هذا التصميم في طباعة الفواتير» مفعّل = هو الافتراضى ✔ ← يطبع به مباشرة بدون نافذة
       • بدون تصميم مستعمل ولا افتراضى في «تصميم التقارير» ← نافذة «اختيار التصميم» الخضراء (مثل DEXEF) فيها تصاميم الاستوديو + التقارير
       • «اجعله الافتراضى» في النافذة: تصميم استوديو ← يُفعَّل عليه «استعمل…» ، تصميم تقارير ← ✔ في «تصميم التقارير» */
    if (RD && RD.printTx && !RD.printTx.__rcAll) {
      const _p = RD.printTx;
      RD.printTx = function (o) {
        o = o || {};
        const tx = o.tx || (o.data && o.data.header && o.data.header.Transaction) || "";
        if (o.item || (o.kind || "tx") !== "tx" || !/مبيعات/.test(tx) || !o.data || !o.data.items) return _p.apply(this, arguments);
        const st = [];
        (window.__RCX || []).forEach(A => { try { (A.list() || []).forEach(d => st.push({ id: "rcx:" + A.K + ":" + (d.id || d.name), name: d.name || A.nm, tx, kind: "tx", virtual: 1, use: !!d.use,
          paper: A.nm + (A.a4 ? "" : " " + (d.w || 80) + " مم"), printer: "", copies: 1, _A: A, _d: d })); } catch (e) { } });
        const inUse = st.find(x => x.use), self = this;
        const run = (it, mode) => {
          if (!it) return { ok: false, cancelled: true };
          if (!it.virtual) return _p.call(self, Object.assign({}, o, { item: it, mode: mode || o.mode }));
          return (RD.company ? RD.company().catch(() => null) : Promise.resolve(null)).then(co => {
            const data = Object.assign({ company: co || {} }, o.data);
            return it._A.print(it._d, data, (mode || o.mode) === "preview", o.title, (mode || o.mode) !== "dialog", co);
          });
        };
        if (inUse && !o.choose && !o.f6) return Promise.resolve(run(inUse));                    /* التصميم المستعمل = الافتراضى (إلا «اختيار الوصل») */
        return (RD.candidates ? RD.candidates(tx, "tx", RD.branchName && RD.branchName()).catch(() => []) : Promise.resolve([])).then(rd => {
          rd = rd || [];
          const list = st.concat(rd);
          /* ✦ F6 (حفظ سريع): دائماً بتصميم الـ 80 مم ⚡ مباشرة */
          if (o.f6 && list.length && RD.f6Item) return run(RD.f6Item(list, tx), "direct");
          const def = rd.find(x => x.def); if (def && !o.choose) return run(def);
          if (!list.length) return _p.apply(self, [o]);
          if ((list.length === 1 && !o.choose) || typeof RD.chooseDesign !== "function") return run(list[0]);
          return RD.chooseDesign(list, { tx, data: o.data, title: o.title, choose: o.choose, summary: o.summary, review: o.review,
            onDefault: it => { if (it && it.virtual) { it._A.setUse(it._d); return true; } (window.__RCX || []).forEach(A => { try { A.clearUse(); } catch (e) { } }); return false; } })
            .then(pk => pk && !pk.cancel ? run(pk.item, pk.mode) : { ok: false, cancelled: true });
        });
      };
      RD.printTx.__rcAll = 1; RD.printTx[FL] = 1;
    }
    return true;
  }
  if (!hook()) { let n = 0; const t = setInterval(() => { if (hook() || ++n > 60) clearInterval(t); }, 300); }
  /* مربع «استوديو الإيصال» أيضاً في الشريط الرمادي لنافذة «طباعة الباركود» (تحت «استوديو الملصق») */
  function navTile() {
    const nav = G("bcpNav"); if (!nav || nav.querySelector(`[data-st="${C.K}"]`)) return;
    const t = document.createElement("div"); t.className = "bcs-tile rcs-ntile" + (C.cls ? " " + C.cls + "-ntile" : ""); t.dataset.st = C.K; t.tabIndex = 0; t.setAttribute("role", "button"); t.title = C.title + " — " + C.tip;
    t.innerHTML = `<span class="rcs-ni">${C.a4 ? IC.a4 : IC.magic}</span><span>${C.tile}</span><em>${C.badge || "جديد"}</em>`;
    const after = (C.after && nav.querySelector(`[data-st="${C.after}"]`)) || nav.querySelector(".bcs-tile:not(.rcs-ntile)") || [...nav.querySelectorAll(".bcp-t")].pop();
    if (after) after.after(t); else nav.appendChild(t);
    t.addEventListener("click", () => open(null));
    t.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(null); } });
  }
  (function hookNav() {
    if (typeof window.bcpOpen === "function" && !window.bcpOpen[FL]) { const _o = window.bcpOpen; window.bcpOpen = function () { const r = _o.apply(this, arguments); try { navTile(); } catch (e) { } return r; }; window.bcpOpen[FL] = 1; }
    else if (typeof window.bcpOpen !== "function") setTimeout(hookNav, 400);
  })();
  new MutationObserver(() => { const nav = G("bcpNav"); if (nav && !nav.querySelector(`[data-st="${C.K}"]`) && nav.querySelector(".bcs-tile")) navTile(); }).observe(document.body, { childList: true, subtree: false });
  /* ---------------- فتح تصميم فاتورة DEXEF سابق (ReportDesign) للتعديل — استيراد ذكي ---------------- */
  const lastK = v => String(v || "").replace(/^\[|\]$/g, "").split(".").pop().trim().toLowerCase();
  const COLK = { index: "idx", rownumber: "idx", "item name": "name", itemname: "name", qty: "qty", dealingqty: "qty", unite: "unit", dealingunite: "unit", price: "price", dealingprice: "price",
    saleprice: "pb", netprice: "pa", total: "total", amount: "total", "item code": "code", itemcode: "code", "item barcode": "code", barcode: "code", totaldiscount: "disc", "item discount": "disc" };
  const TOTK = { footer_amount: "before", "before discount": "before", footer_discount: "disc", discount: "disc", totaldiscount: "disc", footer_extra: "extra", extra: "extra", totalextra: "extra", taxes: "tax", billtax: "tax",
    footer_net_amount: "net", "net amount": "net", footer_payment: "paid", paid: "paid", totalpay: "paid", footer_remain: "remain", remain: "remain", "previous balance": "prev", "customer balance at invoice time": "prev",
    "current balance": "cur", "customer balance": "cur", accountbalance: "cur", "qty total": "count", "item count": "items" };
  function shrink(src) {
    return new Promise(res => { try { const im = new Image(); im.onload = () => { const k = Math.min(1, 520 / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement("canvas"); c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k)); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); res({ src: c.toDataURL("image/png"), w: c.width, h: c.height }); }; im.onerror = () => res(null); im.src = src; } catch (e) { res(null); } });
  }
  async function fromRdInv(d, it) {
    const nd = seedA4(), num = +(it.dexId || it.num) || 0, pg = d.page || {};
    nd.id = "i" + Date.now().toString(36); nd.name = ("#" + num + " — " + (d.name || it.name || "فاتورة")).slice(0, 60); nd.src = { dexId: num, id: it.id }; nd.mig1 = 1;
    const pw = +pg.w || 0, a5 = pw >= 130 && pw < 180 ? true : pw >= 180 ? false : A5; nd.w = a5 ? 148 : 210; nd.h = a5 ? 210 : 297; nd.pad = a5 ? 6 : 9; nd.fs = a5 ? 8 : 10;
    const bands = d.bands || [], all = [], ex = new Set(), texts = [];
    const walk = (bd, c) => { all.push({ bd, c }); if (c.expr) ex.add(lastK(c.expr)); if (!c.expr && c.text) texts.push({ bd, c, t: String(c.text).trim() }); (c.rows || []).forEach(r => (r.cells || []).forEach(cl => { if (cl.expr) ex.add(lastK(cl.expr)); else if (cl.text) texts.push({ bd, c: cl, t: String(cl.text).trim() }); })); };
    bands.forEach(bd => (bd.ctrls || []).forEach(c => walk(bd, c)));
    const has = (...k) => k.some(x => ex.has(x)), B = t => nd.blocks.find(b => b.t === t);
    /* الرأس + بطاقة الفاتورة */
    Object.assign(B("head").f, { name: +has("company name", "name"), act: +has("activity", "field", "description"), phone: +has("company phone", "phone1", "phone no.1"), mobile: +has("company mobile", "phone2", "phone no.2"), addr: +has("company address", "street"), nif: +has("nif", "tax id", "tax_number", "rc", "trade_register") });
    if (a5) B("head").fs = 19;
    const hdrTxt = texts.filter(x => /ReportHeader|PageHeader/i.test(x.bd.type)).map(x => x.t).join(" | ");
    Object.assign(B("info").f, { tx: +has("transaction"), cust: +has("customer name", "party name", "accountname", "customer"), cphone: +has("customer phone"), no: +has("number"), date: +has("date", "dt"), time: +has("time"), user: +has("writtenby", "user name", "username"),
      prev: +(has("customer balance at invoice time", "previous balance") || /previous balance|الرصيد السابق/i.test(hdrTxt)), total: +(/total sales|الاجمالي|الإجمالي/i.test(hdrTxt) || bands.some(bd => /Header/i.test(bd.type) && (bd.ctrls || []).some(c => lastK(c.expr) === "footer_net_amount"))),
      qr: +all.some(x => x.c.t === "barcode" && /qr/i.test(x.c.sym || "") && !/BottomMargin/i.test(x.bd.type)) });
    if (!Object.values(B("info").f).some(Boolean)) B("info").on = 0;
    /* الأصناف: أعمدة جدول Detail بنفس ترتيبها وعرضها وعناوينها */
    const det = bands.find(bd => /Detail/i.test(bd.type)), it0 = B("items");
    if (det) {
      let cells = [];
      const tb = (det.ctrls || []).find(c => c.t === "table");
      if (tb && tb.rows && tb.rows[0]) cells = (tb.rows[0].cells || []).map(cl => ({ k: COLK[lastK(cl.expr)], w: +cl.w || 10 }));
      else cells = (det.ctrls || []).filter(c => c.t === "label" && c.expr).sort((a, b) => (d.rtl === false ? (b.x - a.x) : (b.x - a.x))).map(c => ({ k: COLK[lastK(c.expr)], w: +c.w || 10 }));
      const n = cells.length, heads = bands.filter(bd => /Header/i.test(bd.type)).flatMap(bd => (bd.ctrls || []).filter(c => c.t === "table" && c.rows && c.rows[0] && (c.rows[0].cells || []).length === n && (c.rows[0].cells || []).every(cl => !cl.expr)));
      const caps = heads.length ? heads[heads.length - 1].rows[0].cells.map(cl => String(cl.text || "").trim()) : [];
      const used = [], cols = [];
      cells.forEach((x, i) => { if (!x.k || used.includes(x.k)) return; used.push(x.k); const o = { k: x.k, on: 1, w: Math.max(4, Math.round(x.w)) }; if (caps[i] && caps[i] !== TOK[x.k]) o.lab = caps[i]; cols.push(o); });
      if (cols.length >= 2) { it0.cols = cols.concat(it0.cols.filter(c => !used.includes(c.k)).map(c => Object.assign({}, c, { on: 0 }))); }
    }
    /* الإجماليات */
    const tk = new Set(); ex.forEach(k => { if (TOTK[k]) tk.add(TOTK[k]); });
    if (tk.size) { const T = B("totals"); T.rows.forEach(r => { r.on = tk.has(r.k) ? 1 : 0; r.b = r.k === "net" && tk.has("net") ? 1 : 0; }); }
    B("words").on = +has("amount words", "amount in words", "horoffield");
    B("notes").on = +has("note", "notes");
    /* سطر الدفع + النص الإضافي (تسعدنا زيارتكم …) */
    const P = B("pay"), ftT = texts.filter(x => /ReportFooter|PageFooter/i.test(x.bd.type) && x.t.length > 3 && !/^(label|xrlabel|tablecell)\d*$/i.test(x.t));
    P.on = +(has("payment policy line", "payment policy", "treasury", "payment type", "amount short", "currency code") || ftT.length > 0);
    P.f = { amt: +has("amount short", "footer_payment", "paid"), cur: +has("currency code", "currency"), type: +has("payment type", "paymentindex", "payment method"), tre: +has("treasury"), pol: +has("payment policy line", "payment policy"), t2: ftT.length ? 1 : 0 };
    if (ftT.length) P.t2 = (ftT.find(x => /زيارت|شكر|نشكر/.test(x.t)) || ftT[0]).t;
    B("sign").on = +texts.some(x => /توقيع|امضاء|إمضاء|الختم/.test(x.t));
    /* تذييل الصفحة (BottomMargin): الاسم يسار ، الحساب يمين ، الباركود ، رقم الصفحة */
    const bm = bands.find(bd => /BottomMargin|PageFooter/i.test(bd.type) && (bd.ctrls || []).length), F = B("pfoot");
    if (bm) { const lb = (bm.ctrls || []).filter(c => c.t === "label" && !c.expr && String(c.text || "").trim()).sort((a, b) => a.x - b.x);
      F.on = 1; F.brand = lb.length ? String(lb[0].text).trim() : ""; F.handle = lb.length > 1 ? String(lb[lb.length - 1].text).trim() : ""; F.code = +(bm.ctrls || []).some(c => c.t === "barcode"); F.pg = +(bm.ctrls || []).some(c => c.t === "pageinfo"); F.soc = F.handle ? "note" : "none"; }
    else F.on = 0;
    /* صورك في رأس الفاتورة (ملصقات، QR، أيقونات…) ← مرتّبة في يسار الرأس (الفارغ) لتسحبها حيث تريد.
       صورة «شعار الشركة» الافتراضية في تصاميم DEXEF لا تُنقل: شعارك تضيفه بنفسك */
    const pics = all.filter(x => x.c.t === "pic" && x.c.src && !x.c.expr && /ReportHeader|PageHeader/i.test(x.bd.type)).slice(0, 6);
    const mh = a5 ? 13 : 17, lim = nd.w * .46; let cx = nd.pad, cy = nd.pad;
    for (const x of pics) { const im = await shrink(x.c.src); if (!im || !im.src) continue; const w = r1(Math.min(a5 ? 30 : 40, Math.max(6, mh * im.w / Math.max(1, im.h))));
      if (cx + w > lim && cx > nd.pad) { cx = nd.pad; cy = r1(cy + mh + 2); }
      nd.imgs.push({ id: "i" + uid(), src: im.src, x: r1(cx), y: r1(cy), w, op: 1 }); cx = r1(cx + w + 2); }
    return nd;
  }
  /* إيصال كاشير DEXEF سابق ← تصميم «استوديو الإيصال» (80 / 72 / 58 مم) */
  function fromRdRcpt(d, it) {
    const nd = seedR(), num = +(it.dexId || it.num) || 0, pg = d.page || {}, pw = +pg.w || 80;
    nd.id = "r" + Date.now().toString(36); nd.name = ("#" + num + " — " + (d.name || it.name || "إيصال")).slice(0, 60); nd.src = { dexId: num, id: it.id };
    nd.w = [80, 72, 58].reduce((m, w) => Math.abs(w - pw) < Math.abs(m - pw) ? w : m, 80);
    const bands = d.bands || [], all = [], ex = new Set(), texts = [];
    const walk = (bd, c) => { all.push({ bd, c }); if (c.expr) ex.add(lastK(c.expr)); if (!c.expr && c.text) texts.push({ bd, c, t: String(c.text).trim() }); (c.rows || []).forEach(r => (r.cells || []).forEach(cl => { if (cl.expr) ex.add(lastK(cl.expr)); else if (cl.text) texts.push({ bd, c: cl, t: String(cl.text).trim() }); })); };
    bands.forEach(bd => (bd.ctrls || []).forEach(c => walk(bd, c)));
    const has = (...k) => k.some(x => ex.has(x)), B = t => nd.blocks.find(b => b.t === t);
    Object.assign(B("head").f, { name: +has("company name", "name"), act: +has("activity", "field", "description"), phone: +has("company phone", "phone1", "phone no.1"), mobile: +has("company mobile", "phone2", "phone no.2"), addr: +has("company address", "street"), nif: +has("nif", "tax id", "tax_number", "rc", "trade_register") });
    if (!Object.values(B("head").f).some(Boolean)) B("head").f.name = 1;
    Object.assign(B("title").f, { tx: +has("transaction"), no: +has("number"), date: +has("date", "dt"), time: +has("time"), cust: +has("customer name", "party name", "accountname"), cphone: +has("customer phone"), user: +has("writtenby", "user name", "username"), pay: +has("payment method", "payment type", "paymentindex") });
    if (!Object.values(B("title").f).some(Boolean)) Object.assign(B("title").f, { no: 1, date: 1 });
    /* الأصناف: أعمدة جدول Detail بنفس ترتيبها وعرضها */
    const det = bands.find(bd => /Detail/i.test(bd.type)), I = B("items");
    if (det) {
      const tb = (det.ctrls || []).find(c => c.t === "table");
      const cells = tb && tb.rows && tb.rows[0] ? (tb.rows[0].cells || []).map(cl => ({ k: COLK[lastK(cl.expr)], w: +cl.w || 10 })) : (det.ctrls || []).filter(c => c.t === "label" && c.expr).sort((a, b) => b.x - a.x).map(c => ({ k: COLK[lastK(c.expr)], w: +c.w || 10 }));
      const used = [], cols = [];
      cells.forEach(x => { if (!x.k || used.includes(x.k)) return; used.push(x.k); cols.push({ k: x.k, on: 1, w: Math.max(6, Math.round(x.w)) }); });
      if (cols.length >= 3) { I.mode = "table"; I.cols = cols.concat(I.cols.filter(c => !used.includes(c.k)).map(c => Object.assign({}, c, { on: 0 }))); }
    }
    const tk = new Set(); ex.forEach(k => { if (TOTK[k]) tk.add(TOTK[k]); });
    if (tk.size) B("totals").rows.forEach(r => { r.on = tk.has(r.k) ? 1 : 0; r.b = r.k === "net" && tk.has("net") ? 1 : 0; });
    B("words").on = +has("amount words", "amount in words", "horoffield");
    B("notes").on = +has("note", "notes");
    B("code").on = +all.some(x => x.c.t === "barcode" && lastK(x.c.expr) === "number");
    const ft = texts.filter(x => /ReportFooter|PageFooter|BottomMargin/i.test(x.bd.type) && x.t.length > 3 && !/^(label|xrlabel|tablecell)\d*$/i.test(x.t));
    if (ft.length) B("foot").text = ft.map(x => x.t).filter((t, i, a) => a.indexOf(t) === i).slice(0, 3).join("\n");
    if (has("payment policy line", "payment policy", "treasury", "amount short")) { const pb = payBlk(); pb.f.t2 = 0; const fi = nd.blocks.findIndex(b => b.t === "foot"); nd.blocks.splice(fi >= 0 ? fi : nd.blocks.length, 0, pb); }
    return nd;
  }
  async function importRd(d, it) {
    const num = +(it.dexId || it.num) || 0, ex = DS.find(x => x.src && x.src.dexId === num && num);
    if (ex) { D = ex; open1 = null; selImg = null; persist(); drawAll(); say("الفاتورة #" + num + " موجودة في الاستوديو — تم فتحها للتعديل", "i"); return; }
    const nd = C.a4 ? await fromRdInv(d, it) : fromRdRcpt(d, it);
    DS.push(nd); D = nd; open1 = null; selImg = null; persist(); drawAll();
    const ic = (nd.blocks.find(b => b.t === "items").cols || []).filter(c => c.on).length;
    say((C.a4 ? "تم فتح الفاتورة #" : "تم فتح الإيصال #") + num + " «" + (d.name || "") + "» (" + (!C.a4 ? nd.w + " مم" : nd.w < 180 ? "A5" : "A4") + ") للتعديل — " + ic + " عمود" + (nd.imgs.length ? " + " + nd.imgs.length + " صورة" : ""), "s");
  }
  const API = { K: C.K, nm: C.nm, a4: !!C.a4, list: () => DS, print: (d, data, preview, title, direct, co) => { if (co) CO = co; return doPrint(d, data, preview, title, direct); },
    open, close, importRd, hostRes: (d, data) => hostRes(d || D, data || dataNow()), get design() { return D; }, html: (d, data) => printHTML(d || D, data || dataNow()), clearUse() { DS.forEach(x => x.use = 0); LS.set(C.K + ".designs", DS); if (OV) { drawSel(); G("rcsUse").checked = false; } },
    /* «اجعله الافتراضى» من نافذة الاختيار لتصميم استوديو = تفعيل «استعمل هذا التصميم» عليه */
    setUse(d) { DS.forEach(x => x.use = x === d ? 1 : 0); LS.set(C.K + ".designs", DS); (window.__RCX || []).forEach(x => { if (x !== API) x.clearUse(); }); if (OV) { drawSel(); G("rcsUse").checked = !!(D && D.use); } },
    save() { LS.set(C.K + ".designs", DS); if (OV) { try { drawAll(); } catch (e) { } } } };
  (window.__RCX = window.__RCX || []).push(API);
  window[C.api] = API;
  return API;
  }

  mk({ K: "rcs", api: "__RCS", z: 1.3, title: "استوديو الإيصال الذكي", tile: "استوديو الإيصال", nm: "إيصال", tip: "صمّم إيصال الكاشير بنفسك",
    sub: "شغّل الأقسام، رتّبها بالسحب، ابنِ أسطر الحساب بالرموز × + − / = وضع صورك في أي مكان",
    widths: '<option value="80">80 مم</option><option value="72">72 مم</option><option value="58">58 مم</option><option value="148">A5 — 148 مم</option>', fsz: [7, 8, 9, 10, 11] });
  mk({ K: "rca", api: "__RCA", a4: 1, fmt: "A4", cls: "rca", badge: "A4", after: "rcs", z: 1, title: "استوديو الفاتورة A4", tile: "استوديو الفاتورة", nm: "فاتورة A4", tip: "فاتورة بمقاسها الحقيقي مع قبل/بعد الخصم الذكي",
    sub: "صفحة A4 بمقاسها الحقيقي — «قبل الخصم» سعر القطعة و«بعد الخصم» سعرها داخل الكرتونة/الفاردو، أو «لم يتغيّر سعره» تلقائياً",
    widths: '<option value="210">A4 — 210 مم</option><option value="148">A5 — 148 مم</option>', fsz: [8, 9, 10, 11, 12, 13] });
  mk({ K: "rc5", api: "__RC5", a4: 1, fmt: "A5", cls: "rc5", badge: "A5", after: "rca", z: 1.2, title: "استوديو الفاتورة A5", tile: "استوديو الفاتورة", nm: "فاتورة A5", tip: "فاتورة A5 بمقاسها الحقيقي مع قبل/بعد الخصم الذكي",
    sub: "صفحة A5 (148×210 مم) بمقاسها الحقيقي — «قبل الخصم» سعر القطعة و«بعد الخصم» سعرها داخل الكرتونة/الفاردو، أو «لم يتغيّر سعره» تلقائياً",
    widths: '<option value="148">A5 — 148 مم</option><option value="210">A4 — 210 مم</option>', fsz: [7, 7.5, 8, 8.5, 9, 10, 11] });

  /* ✦ (طلب المستخدم 2026-11-10) F4 «حفظ وطباعة»: الإيصال الأسود من «استوديو الإيصال» باسم «كاشير 2» وحده
     — يُخرج التصميم القديم «كاشير 2» (تصميم التقارير) من F4 ويُعاد تسميته «كاشير 2 (القديم)» بدون حذفه. مرة واحدة على الجهاز. */
  (function k2Mig() {
    const FLAG = "anouer.mig.k2v1", FLAG2 = "anouer.mig.k2v2";
    try { if (localStorage.getItem(FLAG)) return; } catch (e) { return; }
    let n = 0;
    const go = () => {
      const RD = window.ANOUER_RD, A = window.__RCS;
      if (!RD || !RD.rcptPref || !RD.load || !A || !A.list) { if (++n < 80) setTimeout(go, 400); return; }
      RD.load().then(() => {
        const DS = A.list() || [], rc = DS.filter(d => !d.a4 && (+d.w || 80) < 100);
        if (!rc.length) return;
        const pref = RD.rcptPref.get("مبيعات"), idOf = d => "rcx:" + A.K + ":" + (d.id || d.name);
        const d = rc.find(x => idOf(x) === pref.f6) || rc.find(x => x.use) || rc.find(x => /80/.test(x.name || "") || +x.w === 80) || rc[0];
        const idx = RD.idx && RD.idx(); let ren = 0;
        if (idx && idx.items) idx.items.forEach(it => { if ((it.kind || "tx") === "tx" && String(it.name || "").replace(/\s+/g, "") === "كاشير2") { it.name = "كاشير 2 (القديم)"; ren++; } });
        if (ren && RD.saveIdx) RD.saveIdx().catch(() => { });
        d.name = "كاشير 2"; if (A.save) A.save();
        /* يُستبدل القديم فقط — المفضّل الآخر (فاتورة A5) يبقى في F4 */
        const keep = (pref.fav || []).filter(id => id !== idOf(d) && !(idx && idx.items || []).some(it => it.id === id && /كاشير 2 \(القديم\)/.test(it.name || "")));
        RD.rcptPref.set("مبيعات", { fav: [idOf(d)].concat(keep).slice(0, 2) });
        try { localStorage.setItem(FLAG, "1"); localStorage.setItem(FLAG2, "1"); } catch (e) { }
      }).catch(() => { if (++n < 80) setTimeout(go, 1500); });
    };
    setTimeout(go, 1200);
  })();
  /* ✦ إصلاح (2026-11-10): النسخة الأولى من التحويل أخرجت «فاتورة A5» من F4 — تُرجَع بجانب «كاشير 2» */
  (function k2Fix() {
    const FLAG = "anouer.mig.k2v1", FLAG2 = "anouer.mig.k2v2";
    try { if (!localStorage.getItem(FLAG) || localStorage.getItem(FLAG2)) return; } catch (e) { return; }
    let n = 0;
    const go = () => {
      const RD = window.ANOUER_RD, A = window.__RCS;
      if (!RD || !RD.rcptPref || !RD.load || !A || !A.list) { if (++n < 80) setTimeout(go, 400); return; }
      RD.load().then(() => {
        const pref = RD.rcptPref.get("مبيعات"), k2 = (A.list() || []).find(d => d.name === "كاشير 2");
        const k2id = k2 ? "rcx:" + A.K + ":" + (k2.id || k2.name) : (pref.fav[0] || "");
        let a5 = "";
        const S5 = window.__RC5; if (S5 && S5.list) { const L = S5.list() || []; const d = L.find(x => x.use) || L.find(x => /A5/i.test(x.name || "")) || L[0]; if (d) a5 = "rcx:" + S5.K + ":" + (d.id || d.name); }
        if (!a5) { const idx = RD.idx && RD.idx(); const it = idx && (idx.items || []).find(x => (x.kind || "tx") === "tx" && /مبيعات/.test(x.tx || "مبيعات") && /A5|اي ?فايف|إي ?فايف/i.test((x.name || "") + " " + (x.paper || ""))); if (it) a5 = it.id; }
        if (a5 && k2id) RD.rcptPref.set("مبيعات", { fav: [k2id, a5] });
        try { localStorage.setItem(FLAG2, "1"); } catch (e) { }
      }).catch(() => { if (++n < 80) setTimeout(go, 1500); });
    };
    setTimeout(go, 1500);
  })();
})();
