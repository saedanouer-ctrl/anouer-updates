/* ANOUER — «ربط البرنامج بالموبايل» 2026
   DEXEF: نافذة صغيرة «ربط البرنامج بالموبايل» فيها «Please Scan Qrcode From DEXEF Mobile App» + رمز QR كبير + الشعار.
   هنا: الرمز يظهر فوراً (الربط يشتغل وحده عند فتح النافذة) ويفتح على الموبايل لوحة متابعة حيّة (مبيعات اليوم ، الخزينة ، المستحقات ، النواقص)
   عبر واي فاي المحل بدون إنترنت.
   لمستي: شعار ANOUER داخل الرمز ، اختيار الشبكة إن كان للجهاز أكثر من عنوان ، الأجهزة المتصلة مباشرة (نوع الموبايل + منذ متى) مع تنبيه عند ربط موبايل جديد ،
     «رمز جديد» يُبطل الروابط القديمة فوراً ، نسخ / فتح الرابط ، تشغيل الربط تلقائياً مع البرنامج ، المنفذ في الإعدادات المتقدمة ، وحالة الربط بنبض حيّ. */
(function () {
  "use strict";
  if (window.ANOUER_MOBILE) return;
  /* ترخيص «ربط الموبايل» (MOBILE): مقفول بدون تجربة حتى يُدخل العميل كود التفعيل الذي تصدره من ANOUER-Keygen
     (6 أشهر / 3 أشهر / سنة / دائم / تاريخ محدد) — عند انتهاء الصلاحية يتوقف الربط تلقائياً */
  const MOD = "mobile";
  const LIC = () => reg();
  let REG = false;   /* modules-lic.js يُحمَّل بعد هذا الملف ⇒ التسجيل عند أول استعمال */
  const reg = () => { const L = window.ANOUER_LIC; if (!REG && L && L.register) { REG = true; L.register(MOD, { t: "ربط البرنامج بالموبايل", tag: "MOBILE", c: "#1f6fd1", days: 0, noTrial: true,
    desc: "تطبيق ANOUER POS على الهاتف عبر واي فاي المحل: البيع من الهاتف بالكاميرا والباركود، صور الأصناف، العملاء والديون — كل فاتورة تُسجَّل مباشرة في البرنامج. يُفعَّل بكود تطلبه من صاحب البرنامج لمدة تختارها." }); } return L; };
  const licOk = () => { try { return !!LIC() && LIC().ok(MOD); } catch (e) { return false; } };
  const licInfo = () => { try { const L = LIC() && LIC().status(MOD); if (!L) return null;
    if (L.state !== "lic") return { cls: "no", t: L.licExp ? "انتهى الترخيص (" + L.licExp + ")" : "غير مفعّل" };
    if (!L.exp) return { cls: "ok", t: "مفعّل — ترخيص دائم" };
    const t0 = new Date(); t0.setHours(0, 0, 0, 0); const left = Math.round((new Date(L.exp + "T00:00:00") - t0) / 864e5);
    return { cls: left <= 15 ? "warn" : "ok", t: "مفعّل حتى " + L.exp + " · متبقي " + left + " يوم", left }; } catch (e) { return null; } };
  const X = () => window.__FMX;
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const snd = k => { try { if (window.ANOUER_SOUND) ANOUER_SOUND(k); } catch (e) { } };
  const I = {
    mob: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="2.5" width="12" height="19" rx="2.5"/><path d="M10.5 18.5h3"/></svg>',
    wifi: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M2.5 9a14 14 0 0 1 19 0M5.5 12.5a9.5 9.5 0 0 1 13 0M8.8 16a5 5 0 0 1 6.4 0"/><circle cx="12" cy="19.3" r="1.1" fill="currentColor"/></svg>',
    cam: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h3l2-2.5h6L17 8h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>',
    scan: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 8V5.5A1.5 1.5 0 0 1 5.5 4H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16M4 12h16"/></svg>',
    home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11l8-6.5 8 6.5V20H4z"/><path d="M10 20v-5h4v5"/></svg>',
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5.5A1.5 1.5 0 0 0 14.5 4h-9A1.5 1.5 0 0 0 4 5.5v9A1.5 1.5 0 0 0 5.5 16H8"/></svg>',
    open: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
    key: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="15" r="4"/><path d="M11 12l8-8M16 7l2.5 2.5M14 9l2 2"/></svg>',
    gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
    android: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 9h10v8a1.5 1.5 0 0 1-1.5 1.5H15V21h-2v-2.5h-2V21H9v-2.5h-.5A1.5 1.5 0 0 1 7 17zM4.5 9.5a1 1 0 0 1 2 0v5a1 1 0 0 1-2 0zm13 0a1 1 0 0 1 2 0v5a1 1 0 0 1-2 0zM7.3 8a4.8 4.8 0 0 1 9.4 0zM9.5 5.5l-1-1.6M14.5 5.5l1-1.6" stroke="currentColor" stroke-width=".8"/></svg>',
    apple: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16.4 12.6c0-2.3 1.9-3.4 2-3.5-1.1-1.6-2.8-1.8-3.4-1.8-1.4-.2-2.8.8-3.5.8s-1.8-.8-3-.8C7 7.3 5.6 8.2 4.8 9.6c-1.7 2.9-.4 7.2 1.2 9.5.8 1.1 1.7 2.4 2.9 2.4 1.2-.1 1.6-.8 3-.8s1.8.8 3 .7c1.3 0 2.1-1.1 2.8-2.3.9-1.3 1.3-2.6 1.3-2.7-.1 0-2.6-1-2.6-3.8zM14.1 5.8c.6-.8 1.1-1.8 1-2.8-.9 0-2 .6-2.6 1.4-.6.7-1.1 1.7-1 2.7 1 .1 2-.5 2.6-1.3z"/></svg>'
  };
  I.cloud = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"><path d="M7.5 18.5h9.8a4.2 4.2 0 0 0 .6-8.4 6 6 0 0 0-11.5 1.6 3.4 3.4 0 0 0 1.1 6.8Z"/></svg>';
  I.sync = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 0 0-14.3-4.5L4 8.5M4 4v4.5h4.5M4 13a8 8 0 0 0 14.3 4.5l1.7-2M20 20v-4.5h-4.5"/></svg>';
  I.globe = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.6 2.4 3.8 5.2 3.8 8.5s-1.2 6.1-3.8 8.5c-2.6-2.4-3.8-5.2-3.8-8.5s1.2-6.1 3.8-8.5Z"/></svg>';
  I.bolt = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13 2 4.5 13.5H11L10 22l8.5-11.5H12z"/></svg>';
  I.lock = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"><rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8.5 10.5V7.8a3.5 3.5 0 0 1 7 0v2.7"/></svg>';
  const agoTxt = s => s < 8 ? "الآن" : s < 60 ? "منذ " + s + " ث" : s < 3600 ? "منذ " + Math.round(s / 60) + " د" : "منذ " + Math.round(s / 3600) + " سا";
  const upTxt = s => s < 60 ? "أقل من دقيقة" : s < 3600 ? Math.round(s / 60) + " د" : Math.floor(s / 3600) + " سا " + Math.round((s % 3600) / 60) + " د";

  let OPEN = null;
  function open() {
    const L = LIC();
    if (L && L.gate) { L.gate(MOD, open0); return; }
    open0();
  }
  function open0() {
    const F = X(); if (!F) return;
    if (!HOST()) { F.T("ربط الموبايل متاح داخل برنامج ANOUER فقط", "w"); return; }
    if (OPEN) { OPEN.el.querySelector(".fm-win").focus(); return; }
    const { win, call, T, esc, fail, IC } = F;
    const S = { st: null, ip: "", auto: false, port: 8787, known: null, timer: 0, starting: false, cs: null, view: (() => { try { return localStorage.getItem("ml.view") || ""; } catch (e) { return ""; } })(), cbusy: false, cerr: "" };
    const w = win({ title: "ربط البرنامج بالموبايل", icon: IC.mob || I.mob, width: 760, body: '<div class="ml-tabs" role="tablist"><button type="button" role="tab" data-v="lan">' + I.wifi + '<span><b>شبكة المحل</b><small>Wi-Fi · بدون إنترنت</small></span></button><button type="button" role="tab" data-v="cloud">' + I.cloud + '<span><b>عبر الإنترنت</b><small>من أي مكان · حتى والجهاز مقفول</small></span><em>جديد</em></button><i class="ml-tk"></i></div><div class="ml"><div class="ml-load"><i></i>جارٍ تشغيل الربط …</div></div>', buttons: [], onClose: () => { clearInterval(S.timer); clearInterval(S.ctimer); OPEN = null; } });
    w.el.classList.add("ml-ov"); OPEN = w;
    const B = w.$(".ml");
    function url() { const st = S.st || {}; const u = (st.urls || []).find(x => x.indexOf("//" + S.ip + ":") > 0) || (st.urls || [])[0] || ""; return u; }
    function tabs() {
      w.el.querySelectorAll(".ml-tabs [data-v]").forEach(b => { const on = b.dataset.v === S.view; b.classList.toggle("on", on); b.setAttribute("aria-selected", on ? "true" : "false"); });
      const tb = w.el.querySelector(".ml-tabs"); if (tb) tb.dataset.on = S.view;
      const cb = w.el.querySelector('.ml-tabs [data-v="cloud"]'); if (cb) cb.classList.toggle("live", !!(S.cs && S.cs.on));
    }
    function render() { tabs(); if (S.view === "cloud") renderCloud(); else renderLan(); }
    /* ================= عبر الإنترنت (خادم المتجر) ================= */
    function cloudState(cs) { return !cs || !cs.on ? "off" : cs.live ? "live" : cs.err ? "err" : "wait"; }
    function renderCloud() {
      const cs = S.cs || {};
      if (!cs.on) {
        const needStore = /المتجر/.test(S.cerr || "");
        B.innerHTML = `<div class="mlc-hero"><div class="mlc-orb">${I.cloud}<i></i><i></i></div>
          <h3>هاتفك يبيع من أي مكان<br><em>حتى والجهاز مقفول.</em></h3>
          <div class="mlc-how">
            <div><span>${I.bolt}</span><b>الجهاز شغّال</b><small>كل عملية من الهاتف تصل ANOUER مباشرة عبر الإنترنت — نفس الأسعار والخصومات والمخزون.</small></div>
            <div><span>${I.cloud}</span><b>الجهاز مقفول</b><small>الهاتف يواصل البيع من نسخة الأصناف والعملاء ، والفواتير تُحفظ في السحابة وتُسجَّل وحدها عند تشغيل ANOUER.</small></div>
            <div><span>${I.mob}</span><b>الهاتف بدون إنترنت</b><small>التطبيق يفتح ويبيع ويحفظ في الهاتف ، ويرسل كل شيء عند عودة الاتصال — بدون تكرار.</small></div>
          </div>
          ${S.cerr ? `<div class="ml-err">${esc(S.cerr)}</div>` : ""}
          <div class="mlc-acts"><button type="button" class="ml-go mlc-go" data-a="cstart"${S.cbusy ? " disabled" : ""}>${S.cbusy ? '<i class="mlc-sp"></i>جارٍ التشغيل …' : I.cloud + "تشغيل الربط عبر الإنترنت"}</button>
          ${needStore ? `<button type="button" class="mlc-ln" data-a="store">${I.globe}ربط المتجر أولاً</button>` : ""}</div>
          <p class="mlc-ft">${I.lock}يمر عبر خادم متجرك (https) برمز سري — نفس اسم المستخدم والرقم السري في ANOUER. ${licChip()}</p></div>`;
        w.setButtons([{ t: "إغلاق", cls: "no", fn: w => w.close() }]);
        return;
      }
      const u = cs.url || "", stt = cloudState(cs);
      let qr = ""; try { qr = window.ANOUER_QR ? ANOUER_QR.svg(u, 250, "H") : ""; } catch (e) { }
      const host = (() => { try { return new URL(u).host; } catch (e) { return ""; } })();
      const lbl = { live: "مباشر — الجهاز متصل بالسحابة", wait: "جارٍ الاتصال بالسحابة …", err: "السحابة غير متاحة الآن" }[stt];
      B.innerHTML = `<div class="ml-grid mlc"><div class="ml-qrc"><p class="ml-sc">Scan once · Sell anywhere</p>
          <div class="ml-qr">${qr || '<div class="ml-err">QR</div>'}<span class="ml-lg mlc-lg">${I.cloud}</span><i class="ml-scan"></i></div>
          <p class="ml-cap">${I.cam}امسح بأي هاتف — Wi-Fi أو 4G ، داخل المحل أو خارجه</p>
          <div class="mlc-host" dir="ltr">${I.lock}<span>${esc(host)}</span></div></div>
        <div class="ml-side">
          <div class="ml-live mlc-st ${stt}"><span class="ml-dot"></span><b>${lbl}</b><small data-cs>${cs.live ? "منذ " + upTxt(cs.since || 0) : esc(cs.err || "…")}</small>${licChip()}</div>
          <div class="mlc-kp"><div><b data-k="relays">${cs.relays || 0}</b><small>طلب مباشر</small></div><div><b data-k="jobs">${cs.jobs || 0}</b><small>فاتورة من السحابة</small></div><div><b data-k="pushed">${esc(cs.pushed || "—")}</b><small>آخر رفع للبيانات</small></div></div>
          <ol class="ml-steps"><li>${I.scan}<span><b>امسح الرمز مرة واحدة</b><small>يفتح <b>ANOUER POS</b> برابط آمن https — سجّل الدخول والجهاز شغّال (أول مرة فقط)</small></span></li>
            <li>${I.home}<span><b>ثبّته كتطبيق</b><small>Chrome ← «تثبيت التطبيق» · iPhone ← «إضافة إلى الشاشة الرئيسية» — يفتح حتى بدون إنترنت</small></span></li>
            <li>${I.cloud}<span><b>بِع في أي وقت</b><small>الجهاز مقفول؟ الفاتورة تنتظر في السحابة وتُسجَّل عند التشغيل (مرة واحدة)</small></span></li></ol>
          <div class="ml-dv"><div class="ml-dh">${I.mob}<b>هواتف عبر الإنترنت</b><em data-cn></em></div><div class="ml-dl" data-cdl></div></div>
          <div class="ml-url"><input readonly dir="ltr" value="${esc(u)}" aria-label="رابط الإنترنت"><button type="button" data-a="ccopy" title="نسخ الرابط">${I.copy}</button><button type="button" data-a="copen" title="فتح الرابط">${I.open}</button></div>
          <p class="ml-sec">🔒 «رمز جديد» يُبطل الرابط القديم فوراً. يبقى الربط يعمل تلقائياً مع البرنامج. البيانات تمر عبر خادم متجرك وتُحفظ في قاعدة بياناته.</p>
        </div></div>`;
      cdev();
      w.setButtons([{ t: "رمز جديد", cls: "ml-new", fn: () => cstart(true) }, { t: "تحديث البيانات الآن", cls: "mlc-push", fn: cpush }, { t: "إيقاف", cls: "del", fn: cstop }, "|", { t: "إغلاق", cls: "no", fn: w => w.close() }]);
    }
    function cdev() {
      const dl = B.querySelector("[data-cdl]"); if (!dl) return;
      const cl = (S.cs && S.cs.clients) || [];
      B.querySelector("[data-cn]").textContent = cl.length ? cl.length : "";
      dl.innerHTML = cl.length ? cl.map(c => `<div class="ml-d${c.ago < 60 ? " on" : ""}"><span class="ic">${/iPhone|iPad|Mac/.test(c.dev) ? I.apple : /Android/.test(c.dev) ? I.android : I.mob}</span><span class="nm"><b>${esc(c.dev)}</b><small>عبر الإنترنت · ${c.hits} طلب</small></span><span class="t">${agoTxt(c.ago)}</span></div>`).join("")
        : '<div class="ml-wait"><i></i><span>في انتظار أول هاتف عبر الإنترنت …</span></div>';
    }
    function cupd(cs) {
      const prev = S.cs; S.cs = cs || {};
      if (S.view !== "cloud") { tabs(); return; }
      if (!prev || !!prev.on !== !!S.cs.on || cloudState(prev) !== cloudState(S.cs) || (prev.url || "") !== (S.cs.url || "")) { render(); return; }
      const sm = B.querySelector("[data-cs]"); if (sm) sm.textContent = S.cs.live ? "منذ " + upTxt(S.cs.since || 0) : (S.cs.err || "…");
      ["relays", "jobs", "pushed"].forEach(k => { const e = B.querySelector('[data-k="' + k + '"]'); if (e) e.textContent = S.cs[k] || (k === "pushed" ? "—" : 0); });
      cdev();
    }
    function cstart(fresh) {
      if (S.cbusy) return; if (!licOk()) { w.close(); open(); return; }
      S.cbusy = true; S.cerr = ""; if (!S.cs || !S.cs.on) render();
      call("fm.mobile.cloud.start", { fresh: !!fresh }).then(cs => { S.cbusy = false; S.cs = cs; render(); snd("ok");
        T(fresh ? "✔ رمز جديد — الرابط القديم لم يعد يعمل" : "☁ الربط عبر الإنترنت يعمل — امسح الرمز بالهاتف", "s");
        if (fresh) { const q = B.querySelector(".ml-qr"); if (q) q.classList.add("flip"); } })
        .catch(e => { S.cbusy = false; S.cerr = (e && e.message) || String(e); render(); });
    }
    function cstop() { call("fm.mobile.cloud.stop").then(cs => { S.cs = cs; render(); T("تم إيقاف الربط عبر الإنترنت", "i"); }).catch(fail); }
    function cpush() { call("fm.mobile.cloud.push").then(() => T("⏫ يتم رفع الأصناف والعملاء الآن …", "s")).catch(fail); }
    function renderLan() {
      const st = S.st || {};
      if (!st.running) {
        B.innerHTML = `<div class="ml-off"><span class="ml-oi">${I.wifi}</span><b>الربط متوقف</b><p>شغّل الربط لمتابعة المبيعات والخزينة من الموبايل عبر شبكة المحل (Wi-Fi) بدون إنترنت.</p>
          ${st.error ? `<div class="ml-err">${esc(st.error)}</div>` : ""}${!(st.ips || []).length ? '<div class="ml-err">لم يتم العثور على اتصال شبكة محلية في هذا الجهاز — اربطه بالواي فاي أو بالكابل.</div>' : ""}
          <button type="button" class="ml-go" data-a="start">${I.wifi}تشغيل الربط</button>${licChip()}</div>` + settings();
        w.setButtons([{ t: "إغلاق", cls: "no", fn: w => w.close() }]);
        return;
      }
      if (!S.ip || !(st.ips || []).includes(S.ip)) S.ip = (st.ips || [])[0] || "";
      const u = url();
      let qr = ""; try { qr = window.ANOUER_QR ? ANOUER_QR.svg(u, 250, "H") : ""; } catch (e) { }
      B.innerHTML = `<div class="ml-grid">
        <div class="ml-qrc"><p class="ml-sc">Please Scan Qrcode From ANOUER Mobile</p>
          <div class="ml-qr">${qr || '<div class="ml-err">QR</div>'}<span class="ml-lg">A</span><i class="ml-scan"></i></div>
          <p class="ml-cap">${I.cam}امسح بكاميرا موبايل متصل بنفس الواي فاي</p>
          ${(st.ips || []).length > 1 ? `<div class="ml-nets" role="radiogroup" aria-label="الشبكة">${st.ips.map(ip => `<button type="button" role="radio" data-ip="${esc(ip)}" class="${ip === S.ip ? "on" : ""}" aria-checked="${ip === S.ip}">${I.wifi}${esc(ip)}</button>`).join("")}</div>` : ""}
        </div>
        <div class="ml-side">
          <div class="ml-live"><span class="ml-dot"></span><b>الربط يعمل</b><small>منذ ${upTxt(st.since || 0)} · ${esc(st.machine || "")} · المنفذ ${st.port}</small>${licChip()}</div>
          <ol class="ml-steps"><li>${I.cam}<span><b>افتح كاميرا الموبايل</b><small>Android أو iPhone — بدون تثبيت أي تطبيق</small></span></li>
            <li>${I.scan}<span><b>امسح الرمز</b><small>يفتح تطبيق <b>ANOUER POS</b>: سجّل الدخول بنفس اسم المستخدم والرقم السري وابدأ البيع من الهاتف</small></span></li>
            <li>${I.home}<span><b>ثبّته على الشاشة الرئيسية</b><small>من قائمة المتصفح ← «إضافة إلى الشاشة الرئيسية» ليفتح كتطبيق</small></span></li></ol>
          <div class="ml-dv"><div class="ml-dh">${I.mob}<b>الأجهزة المتصلة</b><em data-n></em></div><div class="ml-dl" data-dl></div></div>
          <div class="ml-url"><input readonly dir="ltr" value="${esc(u)}" aria-label="رابط الربط"><button type="button" data-a="copy" title="نسخ الرابط">${I.copy}</button><button type="button" data-a="openu" title="فتح الرابط على هذا الجهاز">${I.open}</button></div>
          <p class="ml-sec">🔒 الرابط فيه رمز سري — «رمز جديد» يُبطل كل الروابط القديمة فوراً. كل فاتورة من الهاتف تُسجَّل باسم البائع (المخزون ، الخزينة ، حساب العميل).</p>
        </div></div>` + settings();
      devices();
      w.setButtons([{ t: "رمز جديد", cls: "ml-new", fn: () => start(true) }, { t: "إيقاف الربط", cls: "del", fn: stop }, "|", { t: "إغلاق", cls: "no", fn: w => w.close() }]);
    }
    function licChip() { const li = licInfo(); if (!li) return "";
      return `<button type="button" class="ml-lic ${li.cls}" data-a="lic" title="الترخيص — اضغط لعرض الرقم السري أو إدخال كود تجديد">${I.key}<span>${esc(li.t)}</span>${li.cls === "warn" ? "<b>تجديد</b>" : ""}</button>`; }
    function settings() {
      return `<details class="ml-set"${S.setOpen ? " open" : ""}><summary>${I.gear}الإعدادات</summary><div class="ml-sr">
        <label class="ml-tg"><input type="checkbox" data-a="auto"${S.auto ? " checked" : ""}><i></i><span><b>تشغيل الربط تلقائياً عند فتح البرنامج</b><small>الموبايل يبقى مربوطاً بدون فتح هذه النافذة</small></span></label>
        <label class="ml-port">المنفذ (Port)<input type="text" inputmode="numeric" data-a="port" value="${S.port}" maxlength="5"><small>8787 افتراضياً — عند أول تشغيل اختر «السماح» في جدار حماية ويندوز للشبكات الخاصة</small></label></div></details>`;
    }
    function devices() {
      const dl = B.querySelector("[data-dl]"); if (!dl) return;
      const cl = (S.st && S.st.clients) || [];
      B.querySelector("[data-n]").textContent = cl.length ? cl.length : "";
      dl.innerHTML = cl.length ? cl.map(c => `<div class="ml-d${c.ago < 45 ? " on" : ""}"><span class="ic">${/iPhone|iPad|Mac/.test(c.dev) ? I.apple : /Android/.test(c.dev) ? I.android : I.mob}</span><span class="nm"><b>${esc(c.dev)}</b><small dir="ltr">${esc(c.ip)}</small></span><span class="t">${c.ago < 45 ? '<i></i>متصل' : agoTxt(c.ago)}</span></div>`).join("")
        : '<div class="ml-wait"><i></i><span>في انتظار أول موبايل …</span></div>';
    }
    function apply(st, quiet) {
      const prev = S.known; S.st = st || {};
      const ips = (S.st.clients || []).map(c => c.ip);
      if (prev && !quiet) ips.filter(ip => !prev.includes(ip)).forEach(ip => { const c = S.st.clients.find(x => x.ip === ip); T("📱 تم ربط موبايل: " + (c ? c.dev : ip), "s"); snd("ok"); });
      S.known = ips;
    }
    function start(fresh) {
      if (S.starting) return; S.starting = true;
      const p = Math.max(1024, Math.min(65535, +S.port || 8787));
      return call("fm.mobile.start", { port: p, fresh: !!fresh }).then(st => { S.starting = false; S.known = null; apply(st, true); render(); if (fresh) { T("✔ تم إنشاء رمز جديد — الروابط القديمة لم تعد تعمل", "s"); const q = B.querySelector(".ml-qr"); if (q) { q.classList.remove("flip"); void q.offsetWidth; q.classList.add("flip"); } } })
        .catch(e => { S.starting = false; S.st = Object.assign({}, S.st || {}, { running: false, error: (e && e.message) || String(e) }); render(); });
    }
    function stop() { call("fm.mobile.stop").then(st => { apply(st, true); render(); T("تم إيقاف الربط بالموبايل", "i"); }).catch(fail); }
    B.addEventListener("click", e => {
      const b = e.target.closest("[data-a],[data-ip]"); if (!b) return;
      if (b.dataset.ip) { S.ip = b.dataset.ip; render(); return; }
      const a = b.dataset.a;
      if (a === "lic") { if (LIC()) LIC().dialog(MOD, () => render()); return; }
      if (a === "cstart") { cstart(false); return; }
      if (a === "store") { try { window.ANOUER_STORE && ANOUER_STORE.open(); } catch (x) { } return; }
      if (a === "ccopy") { try { navigator.clipboard.writeText((S.cs || {}).url || "").then(() => T("تم نسخ الرابط", "s")); } catch (x) { } return; }
      if (a === "copen") { try { window.open((S.cs || {}).url || "", "_blank"); } catch (x) { } return; }
      if (a === "start") { if (!licOk()) { w.close(); open(); return; } start(); }
      else if (a === "copy") { const u = url(); try { navigator.clipboard.writeText(u).then(() => T("تم نسخ الرابط", "s")); } catch (x) { } }
      else if (a === "openu") { try { window.open(url().replace("//" + S.ip + ":", "//127.0.0.1:"), "_blank"); } catch (x) { } }
    });
    w.el.querySelector(".ml-tabs").addEventListener("click", e => {
      const b = e.target.closest("[data-v]"); if (!b || b.dataset.v === S.view) return;
      S.view = b.dataset.v; try { localStorage.setItem("ml.view", S.view); } catch (x) { }
      render(); if (S.view === "cloud") call("fm.mobile.cloud.status").then(cupd).catch(() => { });
    });
    B.addEventListener("toggle", e => { if (e.target.classList && e.target.classList.contains("ml-set")) S.setOpen = e.target.open; }, true);
    B.addEventListener("change", e => {
      const a = e.target.dataset && e.target.dataset.a;
      if (a === "auto") { S.auto = e.target.checked; call("fm.settings.set", { values: { "Mobile.Auto": S.auto ? "1" : "0" } }).then(() => T(S.auto ? "سيشتغل الربط تلقائياً عند فتح البرنامج" : "تم إلغاء التشغيل التلقائي", "s")).catch(fail); }
      else if (a === "port") { const p = parseInt(e.target.value, 10); if (!(p >= 1024 && p <= 65535)) { T("المنفذ بين 1024 و 65535", "w"); e.target.value = S.port; return; } if (p !== S.port) { S.port = p; if (S.st && S.st.running) start(); } }
    });
    Promise.all([call("fm.mobile.status"), call("fm.settings.get", { prefix: "Mobile." }).catch(() => ({})), call("fm.mobile.cloud.status").catch(() => null)]).then(([st, set, cs]) => {
      set = set || {}; S.cs = cs || {};
      if (S.view !== "lan" && S.view !== "cloud") S.view = S.cs.on ? "cloud" : "lan"; S.auto = set["Mobile.Auto"] === "1"; S.port = +set["Mobile.Port"] || st.port || 8787;
      apply(st, true);
      if (!st.running && (st.ips || []).length) start(); else render();   /* مثل DEXEF: الرمز يظهر فوراً */
      S.ctimer = setInterval(() => { if (!OPEN) return; call("fm.mobile.cloud.status").then(cupd).catch(() => { }); }, 2500);
      S.timer = setInterval(() => { if (!OPEN) return; if (S.view === "cloud") return; call("fm.mobile.status").then(s => { const was = S.st && S.st.running; apply(s); if (!!s.running !== !!was) render(); else { devices(); const lv = B.querySelector(".ml-live small"); if (lv && s.running) lv.textContent = "منذ " + upTxt(s.since || 0) + " · " + (s.machine || "") + " · المنفذ " + s.port; } }).catch(() => { }); }, 3000);
    }).catch(e => { w.close(); fail(e); });
  }

  /* تشغيل تلقائي مع البرنامج (الإعداد Mobile.Auto) */
  const licGuard = () => { if (!HOST() || licOk()) return; Anouer.call("fm.mobile.cloud.status", {}).then(cs => { if (cs && cs.on) return Anouer.call("fm.mobile.cloud.stop", {}); }).catch(() => { }); Anouer.call("fm.mobile.status", {}).then(st => { if (st && st.running) return Anouer.call("fm.mobile.stop", {}).then(() => { try { const F = X(); F && F.T("⛔ انتهت صلاحية ترخيص «ربط الموبايل» — تم إيقاف الربط. أدخل كود تجديد من «ربط البرنامج بالموبايل».", "w"); } catch (e) { } }); }).catch(() => { }); };
  setInterval(licGuard, 30 * 60000);
  /* ✦ بيع / شراء / تحصيل من الهاتف ← أرصدة العملاء والموردين والخزائن في شاشات البرنامج تتحدّث فوراً (بدون إعادة فتح) */
  let REV = null, revBusy = false, NEWSEQ = 0;
  setInterval(() => {
    if (revBusy || !HOST() || document.hidden) return; revBusy = true;
    Anouer.call("fm.mobile.rev", {}).then(r => {
      revBusy = false; r = +r || 0;
      if (REV !== null && r !== REV) {
        try { const A = window.__AC; if (A) { delete A.PC.cu; delete A.PC.su; delete A.AC.tr; A.invalidate && A.invalidate(); } } catch (e) { }
        try { const K = window.__anouerLink; if (K && K.loadCustomers) K.loadCustomers().catch(() => { }); } catch (e) { }
        /* ✦ أرصدة المخزون: بيع/شراء من الهاتف ينقّص/يزيد الرصيد في شاشات البرنامج فوراً */
        try { const K = window.__anouerLink; if (K && K.loadProducts) K.loadProducts().then(() => { if (window.ANOUER_WH && ANOUER_WH.load) return ANOUER_WH.load(true); }).catch(() => { }); } catch (e) { }
        try { if (window.ANOUER_SUPPLIERS && ANOUER_SUPPLIERS.reload) ANOUER_SUPPLIERS.reload(); } catch (e) { }
        ["anouer:customers", "anouer:products", "anouer:mobile"].forEach(n => { try { window.dispatchEvent(new Event(n)); } catch (e) { } });
        /* ✦ صنف جديد من الهاتف: مصغّرة صورته تظهر في شاشات البرنامج فوراً */
        Anouer.call("fm.mobile.newItems", { since: NEWSEQ }).then(x => { if (!x) return; const m = {}; (x.items || []).forEach(it => { if (it && it.th) m[it.id] = it.th; }); NEWSEQ = +x.seq || NEWSEQ; if (Object.keys(m).length && window.__pimgSetMany) __pimgSetMany(m); }).catch(() => { });
      }
      REV = r;
    }, () => { revBusy = false; });
  }, 3000);
  setTimeout(() => {
    if (!HOST()) return;
    const L = LIC(); (L && L.init ? L.init() : Promise.resolve()).then(() => { if (!licOk()) { licGuard(); return; }
    Anouer.call("fm.settings.get", { prefix: "Mobile." }).then(s => {
      /* الربط عبر الإنترنت يبقى يعمل مع كل تشغيل للبرنامج */
      if (s && s["Mobile.Cloud"] === "1") Anouer.call("fm.mobile.cloud.status", {}).then(cs => { if (!cs || !cs.on) return Anouer.call("fm.mobile.cloud.start", {}); }).catch(e => { try { const F = X(); F && F.T("☁ تعذّر تشغيل الربط عبر الإنترنت: " + ((e && e.message) || e), "w"); } catch (x) { } });
      if (!s || s["Mobile.Auto"] !== "1") return;
      return Anouer.call("fm.mobile.status", {}).then(st => { if (!st.running) return Anouer.call("fm.mobile.start", { port: +s["Mobile.Port"] || 8787 }); });
    }).catch(() => { });
    }).catch(() => { });
  }, 5000);

  window.ANOUER_MOBILE = { open };
})();
