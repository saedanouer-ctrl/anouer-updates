/* ANOUER — «مراجعة الأصناف»: كل أعمدة DEXEF ONE (الافتراضية + نافذة Customization) وكل أيقونات الشريط تعمل
   ─ الأعمدة (31 مثل تصدير DEXEF): الاسم، الكود، الوحدة، عدد القطع، سعر البيع، الرصيد، سعر 5ومافوق،
     اجمالي التكلفة، اخر تاريخ توريد، أخر تاريخ صرف، اخيارات، التجزئة، الجملة، الحد الأدنى، الحد الأقصى، المجموعة،
     المورد، الوصف، تكلفة الوحده، رصيد، سعر استطلاع، سعر الشراء، طلبية الشراء، عابر سبيل، م، مطلوب للتحويل،
     مكان التخزين 1/2/3، نوع الصنف، نشط
   ─ Customization: سحب عمود من النافذة إلى العناوين يُظهره ، وسحب عنوان إليها يخفيه ، وسحب العناوين يعيد ترتيبها
   ─ الشريط: جديد · تعديل · حذف▾ · رفع (استيراد إكسيل DEXEF) · نسخ · تحديث · طباعة▾ · تصدير Excel▾ · Mail▾ · تكرار ·
     المرفقات · طريقة العرض▾ · اختيار الحقول · عرض للطباعة
   البيانات: الأصناف (products) + fm.items.review (النوع، حقول البطاقة، آخر مورد، الطلبيات، التواريخ، سعر الشراء) */
(function () {
  "use strict";
  if (window.__IRX) return;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const r2 = n => Math.round((+n || 0) * 100) / 100;
  let DEC = 2;   // «تقريب الأرقام الى أقرب» (خصائص التصميم)
  const F = n => { n = +n || 0; const p = Math.pow(10, DEC); return (Math.round(n * p) / p).toLocaleString("en-US", { maximumFractionDigits: DEC }); };
  const say = (m, t) => { try { toast(m, t || "i"); } catch (e) { } };
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
  const lsSet = (k, v) => { try { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const unknown = e => /غير معروف|unknown|mock:/i.test(String(e && e.message || e));
  const PRODS = () => { try { return products; } catch (e) { return []; } };
  const today = () => { const d = new Date(), p = n => String(n).padStart(2, "0"); return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()); };
  const NUM = v => { const n = parseFloat(String(v == null ? "" : v).replace(/[,\s]/g, "")); return isFinite(n) ? n : null; };

  /* ---------------- بيانات الأعمدة الإضافية ---------------- */
  const TYN = { stock: "مخزون", group: "مجموعة", made: "منتج تام", service: "خدمة", serial: "مخزون بسيريال", expiry: "مخزون بصلاحية", consign: "بضاعة أمانة", apparel: "ملابس و أحذية", scale: "ميزان" };
  const TYK = Object.keys(TYN).reduce((o, k) => { o[TYN[k]] = k; return o; }, {});
  const K = { max: "acc|التنبيهات|الحد الأقصى|0", min: "acc|التنبيهات|الحد الادنى|0", l1: "props|أماكن التخزين|المكان الأول|0", l2: "props|أماكن التخزين|المكان الثانى|0", l3: "props|أماكن التخزين|المكان الثالث|0" };
  const M = { by: {}, buy: {}, dates: {}, mins: {}, ok: false, busy: null };
  function parseX(s) { if (!s) return {}; if (typeof s === "object") return s; try { return JSON.parse(s) || {}; } catch (e) { return {}; } }
  function loadMeta(force) {
    if (M.busy && !force) return M.busy;
    if (!HOST()) { M.ok = true; return (M.busy = Promise.resolve()); }
    const a = Anouer.call("fm.items.review").then(r => {
      M.by = {}; (r && r.items || []).forEach(it => { M.by[it.id] = { type: it.type, x: parseX(it.extra), sup: it.sup || "", po: +it.po || 0, tr: +it.tr || 0, min: +it.min || 0, lastIn: it.lastIn || "", lastOut: it.lastOut || "" }; });
      M.buy = {}; (r && r.units || []).forEach(u => { M.buy[u.puid] = +u.buy || 0; });
      M.full = true;
    }).catch(e => {
      M.full = false;
      if (!unknown(e)) console.warn(e);
      /* البرنامج قبل إعادة البناء: الحد الأدنى + التواريخ من الإحصائيات */
      return Promise.all([
        Anouer.call("fm.items.extra").then(l => { M.mins = {}; (l || []).forEach(x => { M.mins[x.id] = +x.min || 0; }); }).catch(() => { }),
        Anouer.call("fm.items.stats", { from: today(), to: today() }).then(s => { M.dates = {}; (s && s.rows || []).forEach(x => { M.dates[x.pid] = { lastIn: x.lastBuy || "", lastOut: x.lastSale || "" }; }); }).catch(() => { })
      ]);
    });
    M.busy = a.then(() => { M.ok = true; rerender(); });
    return M.busy;
  }
  const info = p => M.by[p.id] || null;
  const X = p => { const i = info(p); return i ? i.x || {} : {}; };
  const XF = (p, k) => { const f = X(p).f || {}; const v = f[K[k]]; return v == null ? "" : v; };
  function typeOf(p) { const i = info(p); return (i && i.type) || (window.__ITYPE || {})[p.id] || p.type || "stock"; }
  function supOf(p) { const i = info(p); if (i && i.sup) return i.sup; const s = X(p).supplier; return s ? (typeof s === "object" ? s.name || "" : String(s)) : ""; }
  function minOf(p) { const i = info(p); if (i) return i.min; if (M.mins[p.id] != null) return M.mins[p.id]; return +p._min || +p.min || 0; }
  function datesOf(p) { const i = info(p); return i ? { lastIn: i.lastIn, lastOut: i.lastOut } : (M.dates[p.id] || {}); }
  const u_ = r => r._u || {};
  const costB = r => +((r._p || {}).cost) || 0;

  /* ---------------- تعريف كل الأعمدة (بنفس أسماء DEXEF) ---------------- */
  const n2 = v => v ? F(v) : "0";
  const dateF = s => { if (!s) return ""; const m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}))?/.exec(String(s)); if (!m) return String(s); const f = SET().dfmt || "yyyy-MM-dd HH:mm";
    return f.replace("yyyy", m[1]).replace("MM", m[2]).replace("dd", m[3]).replace("HH", m[4] || "00").replace("mm", m[5] || "00").replace(/ 00:00$/, m[4] ? " 00:00" : ""); };
  const ALL = [
    { id: "name", t: "الاسم", w: "minmax(220px,1fr)", f: r => r.name, txt: 1, fix: 1, agg: "cnt" },
    { id: "code", t: "الكود", w: "170px", f: r => r.code },
    { id: "color", t: "اللون", w: "110px", f: r => r.color || "", txt: 1, only: "style" },
    { id: "size", t: "المقاس", w: "90px", f: r => r.size || "", only: "style" },
    { id: "unit", t: "الوحدة", w: "120px", f: r => r.unit },
    { id: "factor", t: "عدد القطع", w: "78px", f: r => r.factor, v: r => +r.factor || 0 },
    { id: "price", t: "سعر البيع", w: "96px", f: r => F(r.price), v: r => +r.price || 0 },
    { id: "stock", t: "الرصيد", w: "86px", f: r => F(r.stock), v: r => +r.stock || 0, agg: "row" },
    { id: "q5", t: "سعر 5ومافوق", w: "100px", f: r => n2(r.q5), v: r => +r.q5 || 0 },
    { id: "tcost", t: "اجمالي التكلفة", w: "110px", tip: "قيمة رصيد الصنف بالتكلفة (الرصيد بالقطعة × متوسط التكلفة)", f: r => n2(r2((+r.wq || 0) * costB(r))), v: r => (+r.wq || 0) * costB(r), agg: "item" },
    { id: "lastIn", t: "اخر تاريخ توريد", w: "142px", f: r => dateF(datesOf(r._p || {}).lastIn), v: r => datesOf(r._p || {}).lastIn || "" },
    { id: "lastOut", t: "أخر تاريخ صرف", w: "142px", f: r => dateF(datesOf(r._p || {}).lastOut), v: r => datesOf(r._p || {}).lastOut || "" },
    { id: "opt", t: "اخيارات", w: "80px", f: r => X(r._p || {}).opt || "" },
    { id: "retail", t: "التجزئة", w: "86px", f: r => n2(u_(r).rp), v: r => +u_(r).rp || 0 },
    { id: "whole", t: "الجملة", w: "86px", f: r => n2(u_(r).wp), v: r => +u_(r).wp || 0 },
    { id: "min", t: "الحد الأدنى", w: "84px", f: r => F(minOf(r._p || {})), v: r => minOf(r._p || {}) },
    { id: "max", t: "الحد الأقصى", w: "84px", f: r => F(+XF(r._p || {}, "max") || 0), v: r => +XF(r._p || {}, "max") || 0 },
    { id: "grp", t: "المجموعة", w: "150px", f: r => (r._p || {}).cat || "", txt: 1 },
    { id: "sup", t: "المورد", w: "140px", f: r => supOf(r._p || {}), txt: 1 },
    { id: "desc", t: "الوصف", w: "140px", f: r => X(r._p || {}).desc || "", txt: 1 },
    { id: "ucost", t: "تكلفة الوحده", w: "96px", tip: "متوسط تكلفة الوحدة = تكلفة القطعة × عدد القطع", f: r => n2(r2(costB(r) * (+r.factor || 1))), v: r => costB(r) * (+r.factor || 1) },
    { id: "bal", t: "رصيد", w: "80px", tip: "الرصيد بالوحدة الصغرى (القطعة)", f: r => F(r.wq), v: r => +r.wq || 0, agg: "item" },
    { id: "survey", t: "سعر استطلاع", w: "90px", f: r => n2(u_(r).sp), v: r => +u_(r).sp || 0 },
    { id: "buy", t: "سعر الشراء", w: "90px", tip: "سعر الشراء المسجّل للوحدة (أو آخر سعر شراء)", f: r => n2(buyOf(r)), v: r => buyOf(r) },
    { id: "po", t: "طلبية الشراء", w: "90px", tip: "كمية طلبيات الشراء المفتوحة بهذه الوحدة", f: r => n2(perUnit(r, "po")), v: r => perUnit(r, "po"), agg: "row" },
    { id: "passer", t: "عابر سبيل", w: "86px", f: r => n2(u_(r).pp), v: r => +u_(r).pp || 0 },
    { id: "pid", t: "م", w: "60px", tip: "رقم الصنف", f: r => r.id, v: r => +r.id || 0 },
    { id: "tr", t: "مطلوب للتحويل", w: "100px", tip: "كمية طلبات التحويل المفتوحة بهذه الوحدة", f: r => n2(perUnit(r, "tr")), v: r => perUnit(r, "tr"), agg: "row" },
    { id: "loc1", t: "مكان التخزين", w: "120px", f: r => XF(r._p || {}, "l1"), txt: 1 },
    { id: "loc2", t: "مكان التخزين 2", w: "120px", f: r => XF(r._p || {}, "l2"), txt: 1 },
    { id: "loc3", t: "مكان التخزين 3", w: "120px", f: r => XF(r._p || {}, "l3"), txt: 1 },
    { id: "type", t: "نوع الصنف", w: "96px", f: r => TYN[typeOf(r._p || {})] || "مخزون" },
    { id: "active", t: "نشط", w: "50px", f: r => r.active === false ? 0 : 1, v: r => r.active !== false, h: r => `<input type="checkbox"${r.active === false ? "" : " checked"} style="accent-color:#2b7de0;pointer-events:none" tabindex="-1">` }
  ];
  function buyOf(r) { const u = u_(r); if (u.puid && M.buy[u.puid]) return M.buy[u.puid]; const p = r._p || {}; return r2((+p.lastBuy || 0) * (+r.factor || 1)); }
  function perUnit(r, k) { const i = info(r._p || {}); const q = i ? +i[k] || 0 : 0; return q ? r2(q / (+r.factor || 1)) : 0; }

  /* ---------------- الأعمدة المحسوبة («اضافة عمود») ---------------- */
  const CALC = () => lsGet("irev.calc", []);
  const CALC_TPL = [
    ["الربح", "[سعر البيع]-[تكلفة الوحده]"], ["نسبة الربح %", "([سعر البيع]-[تكلفة الوحده])/[تكلفة الوحده]*100"],
    ["قيمة الرصيد بسعر البيع", "[رصيد]*[سعر البيع]/[عدد القطع]"], ["الربح المتوقع للرصيد", "[رصيد]/[عدد القطع]*([سعر البيع]-[تكلفة الوحده])"],
    ["المطلوب للوصول للحد الأقصى", "[الحد الأقصى]-[رصيد]"], ["فرق التجزئة عن البيع", "[التجزئة]-[سعر البيع]"]];
  function calcFn(expr) {
    /* آمن: لا يُقبل إلا أرقام وعمليات حسابية وأقواس وأسماء أعمدة بين [ ] */
    const refs = []; const body = String(expr || "").replace(/\[([^\]]+)\]/g, (m, n) => { refs.push(n.trim()); return "v[" + (refs.length - 1) + "]"; });
    if (!/^[\d\s+\-*/().v\[\]%]*$/.test(body.replace(/v\[\d+\]/g, ""))) return null;
    const cs = refs.map(n => ALL.find(c => c.t === n || c.id === n));
    if (cs.some(c => !c || !c.v && !c.f)) return null;
    let fn; try { fn = new Function("v", "return (" + (body.trim() || "0") + ");"); } catch (e) { return null; }
    return r => { const v = cs.map(c => +(c.v ? c.v(r) : NUM(c.f(r))) || 0); let x; try { x = fn(v); } catch (e) { x = NaN; } return isFinite(x) ? x : 0; };
  }
  function calcCols() { return CALC().map(c => { const fn = calcFn(c.expr); return fn ? { id: "x:" + c.id, t: c.t, w: (c.w || 100) + "px", tip: "عمود محسوب: " + c.expr, f: r => F(fn(r)), v: fn, agg: c.sum ? "row" : null, calc: c } : null; }).filter(Boolean); }
  const allCols = () => ALL.concat(calcCols());
  const byId = id => allCols().find(c => c.id === id);

  /* ---------------- طرق العرض (DEXEF FrmItemTree: CmbView) ---------------- */
  const MODES = [["general", "عام", "نظرة عامة: سطر واحد لكل صنف"], ["tree", "شجري", "الأصناف داخل مجموعاتها (شجرة)"], ["units", "وحدات القياس", "سطر لكل وحدة وكل باركود"], ["style", "الملابس و الأحذية", "الأصناف بالألوان والمقاسات"]];
  const MODE_IC = {
    general: '<svg viewBox="0 0 18 18"><path d="M3 7h12l-1.2 7.5H4.2z" fill="#8a95a5"/><path d="M6 7V5a3 3 0 0 1 6 0v2" fill="none" stroke="#8a95a5" stroke-width="1.6"/></svg>',
    tree: '<svg viewBox="0 0 18 18"><rect x="2" y="2.5" width="14" height="13" rx="2" fill="#555"/><rect x="5" y="6" width="8" height="2" fill="#fff"/><rect x="5" y="10" width="8" height="2" fill="#fff"/></svg>',
    units: '<svg viewBox="0 0 18 18"><path d="M2 3.5h6l1 1v10l-1-1H2zM16 3.5h-6l-1 1v10l1-1h6z" fill="#2f6fb5"/></svg>',
    style: '<svg viewBox="0 0 18 18"><path d="M6 2.5L2 5l1.6 3 1.4-.8V15.5h8V7.2l1.4.8L16 5l-4-2.5c-.4 1.3-1.6 2-3 2s-2.6-.7-3-2z" fill="#2f86e8"/></svg>'
  };
  let MODE = lsGet("irev.mode", "units"); if (!MODES.some(m => m[0] === MODE)) MODE = "units";
  const modeName = m => (MODES.find(x => x[0] === (m || MODE)) || MODES[2])[1];

  /* ---------------- حالة العرض لكل طريقة: الأعمدة ، العرض ، العناوين ، الخصائص ---------------- */
  const DEF_SET = { fit: false, filterRow: true, tot: true, colMenu: true, dec: 2, dfmt: "yyyy-MM-dd HH:mm", title: "مراجعة الأصناف", density: "",
    font: "", fsize: 14, bold: false, italic: false, fg: "", bg: "", oddUse: false, oddBg: "#f7f9fc", oddFg: "", evenUse: false, evenBg: "#ffffff", evenFg: "",
    vUse: true, vColor: "#eef0f3", hUse: true, hColor: "#f1f1f1" };
  const DEF_COLS = {
    general: ALL.filter(c => !c.only && c.id !== "factor").map(c => c.id),
    units: ALL.filter(c => !c.only).map(c => c.id),
    tree: ["name", "code", "unit", "buy", "price", "retail", "whole", "q5", "bal", "tcost", "loc1", "active"],
    style: ["name", "code", "color", "size", "unit", "price", "stock", "bal", "tcost", "grp", "active"]
  };
  function LAY(m) {
    m = m || MODE; const all = lsGet("irev.lay", {});
    if (!all[m]) {
      const old = m === "units" ? lsGet("irev.cols", null) : null;   // ترقية التصميم السابق
      all[m] = { cols: Array.isArray(old) && old.length ? old : DEF_COLS[m].slice(), w: m === "units" ? lsGet("irev.w", {}) || {} : {}, cap: {}, set: Object.assign({}, DEF_SET, m === "units" ? { density: lsGet("irev.view", "") || "" } : {}) };
      lsSet("irev.lay", all);
    }
    const L = all[m]; L.w = L.w || {}; L.cap = L.cap || {}; L.set = Object.assign({}, DEF_SET, L.set || {});
    return L;
  }
  function saveLay(L, m) { const all = lsGet("irev.lay", {}); all[m || MODE] = L; lsSet("irev.lay", all); DIRTY = true; }
  const SET = () => LAY().set;
  let DIRTY = false;
  const avail = c => !c.only || c.only === MODE;
  function visIds() { const ids = LAY().cols.filter(id => { const c = byId(id); return c && avail(c); }); if (!ids.includes("name")) ids.unshift("name"); return ids; }
  function setVis(ids, noRender) { const L = LAY(); L.cols = ids; saveLay(L); if (IRS && !noRender) { IRS.setCols(cols()); SIG = ""; paintHead(); } }
  function cols() {
    const L = LAY();
    return [{ k: "rn", w: "46px" }].concat(visIds().map(id => {
      const c = byId(id), cap = L.cap[id];
      const o = Object.assign({}, c, { w: L.w[id] ? L.w[id] + "px" : c.w, t: cap || c.t, t0: c.t });
      /* أسطر المجموعات (العرض الشجري) */
      const f0 = c.f, h0 = c.h;
      o.f = r => r && r._grp ? grpVal(c, r) : f0(r);
      if (h0) o.h = r => r && r._grp ? "" : h0(r);
      return o;
    })).concat([{ k: "ic", w: "40px" }]);
  }

  /* ---------------- بيانات كل طريقة عرض ---------------- */
  function pickRow(rows) {   // الوحدة الافتراضية للبيع ثم القطعة ثم الأولى
    return rows.find(r => r._u && r._u.def && String(r.code) === String(r._p.code)) || rows.find(r => (+r.factor || 1) === 1 && String(r.code) === String(r._p.code)) || rows.find(r => String(r.code) === String(r._p.code)) || rows[0];
  }
  function byProd(o) { const m = new Map(); o.forEach(r => { const k = r._p || r; if (!m.has(k)) m.set(k, []); m.get(k).push(r); }); return m; }
  const listOf = v => (Array.isArray(v) ? v : []).map(x => typeof x === "object" ? (x.name || x.t || x.v || "") : String(x)).filter(Boolean);
  function data(o) {
    if (MODE === "units") return o;
    const m = byProd(o), out = [];
    if (MODE === "general" || MODE === "tree") { m.forEach(rows => out.push(pickRow(rows))); return out; }
    /* الملابس و الأحذية: سطر لكل لون × مقاس */
    m.forEach((rows, p) => {
      if (typeOf(p) !== "apparel") return;
      const b = pickRow(rows), x = X(p), cs = listOf(x.colors), ss = listOf(x.sizes);
      if (!cs.length && !ss.length) { out.push(b); return; }
      (cs.length ? cs : [""]).forEach(c => (ss.length ? ss : [""]).forEach(s => out.push(Object.assign(Object.create(b), { color: c, size: s, _k: p.id + "|" + c + "|" + s }))));
    });
    return out;
  }

  /* ---------------- العرض الشجري: المجموعات (الفهرس ← مجموعات الأصناف) ---------------- */
  const GR = { list: null, busy: null };
  function loadGroups() {
    if (GR.busy) return GR.busy;
    const H = window.__FH;
    GR.busy = (H && H.DB ? H.DB.list("igrp").catch(() => []) : Promise.resolve([])).then(l => { GR.list = (l || []).map(g => ({ id: g.id, name: String(g.name || "").trim(), parentId: g.parentId || 0 })); if (MODE === "tree") rerender(); });
    return GR.busy;
  }
  const TCOL = () => new Set(lsGet("irev.tcol", []));
  function postList(l) {
    if (MODE !== "tree") return l;
    const gl = GR.list || [], byName = {}, byGid = {};
    gl.forEach(g => { byName[g.name] = g; byGid[g.id] = g; });
    const NONE = "بدون مجموعة";
    const nodes = {};   // name → {name, parent, items:[], kids:Set}
    const node = (name, parent) => nodes[name] || (nodes[name] = { name, parent, items: [], kids: new Set() });
    l.forEach(r => {
      const cat = ((r._p || {}).cat || "").trim() || NONE; node(cat).items.push(r);
      /* سلسلة الآباء من شجرة المجموعات */
      let g = byName[cat], child = cat, guard = 0;
      while (g && g.parentId && byGid[g.parentId] && guard++ < 20) { const pn = byGid[g.parentId].name; node(pn).kids.add(child); nodes[child].parent = pn; child = pn; g = byGid[g.parentId]; }
    });
    const col = TCOL(), q = !!(IRS && IRS.q), out = []; let NO = 0;
    const tot = n => { let c = n.items.length, v = 0, b = 0; n.items.forEach(r => { v += (+r.wq || 0) * costB(r); b += +r.wq || 0; }); n.kids.forEach(k => { const t = tot(nodes[k]); c += t.c; v += t.v; b += t.b; }); return { c, v, b }; };
    const emit = (n, depth) => {
      const t = tot(n), open = q || !col.has(n.name);
      out.push({ _grp: 1, _name: n.name, _depth: depth, _open: open, _cnt: t.c, _v: t.v, _b: t.b, id: "g:" + n.name, name: n.name });
      if (!open) return;
      Array.from(n.kids).sort((a, b) => a.localeCompare(b, "ar")).forEach(k => emit(nodes[k], depth + 1));
      n.items.forEach(r => out.push(Object.assign(Object.create(r), { _depth: depth + 1, _n: ++NO })));
    };
    Object.values(nodes).filter(n => !n.parent).sort((a, b) => a.name === NONE ? 1 : b.name === NONE ? -1 : a.name.localeCompare(b.name, "ar")).forEach(n => emit(n, 0));
    return out;
  }
  const IND = d => " ".repeat(Math.max(0, d || 0));
  function grpVal(c, r) {
    if (c.id === "name") return IND(r._depth) + (r._open ? "▾ " : "◂ ") + r._name + "  (" + r._cnt + ")";
    if (c.id === "tcost") return F(r._v);
    if (c.id === "bal") return F(r._b);
    return "";
  }
  function toggleGroup(r, force) { const s = TCOL(); const open = force != null ? force : s.has(r._name); if (open) s.delete(r._name); else s.add(r._name); lsSet("irev.tcol", Array.from(s)); rerender(); }
  function treeAll(open) { if (open) lsSet("irev.tcol", []); else { const names = new Set(); shownAll().forEach(r => { if (r._grp) names.add(r._name); }); (GR.list || []).forEach(g => names.add(g.name)); names.add("بدون مجموعة"); lsSet("irev.tcol", Array.from(names)); } rerender(); }

  /* ---------------- البحث (Find Panel مثل DEXEF + لمسات) ----------------
     • كل كلمة يجب أن توجد في أي عمود (جزء من الكلمة يكفي) — بترتيب أي
     • "عبارة كاملة" بين علامتي تنصيص ، و -كلمة لاستبعادها ، و العمود:قيمة للبحث في عمود محدد (مثال: الكود:613)
     • يتجاهل الهمزات والتاء المربوطة والألف المقصورة والتشكيل ، ويظلل الجزء المطابق */
  const AN = s => String(s == null ? "" : s).toLowerCase().replace(/[أإآٱ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/ؤ/g, "و").replace(/ئ/g, "ي").replace(/[ً-ْـ]/g, "");
  function parseQ(q) {
    const out = []; const re = /(-?)(?:([^\s:"]+):)?(?:"([^"]+)"|(\S+))/g; let m;
    while ((m = re.exec(q))) { const t = AN(m[3] || m[4] || ""); if (!t) continue; out.push({ neg: m[1] === "-", col: m[2] ? AN(m[2]) : "", t }); }
    return out;
  }
  function colMatch(cs, key) { return cs.filter(c => c.f && !c.h && AN(c.t).startsWith(key)); }
  function findFilter(l, q, cs) {
    const tk = parseQ(q); if (!tk.length) return l;
    const tc = cs.filter(c => c.f && !c.h);
    return l.filter(r => {
      if (r._grp) return true;
      const vals = tc.map(c => AN(c.f(r)));
      return tk.every(k => {
        let hit;
        if (k.col) { const cc = colMatch(tc, k.col); hit = cc.some(c => AN(c.f(r)).includes(k.t)); }
        else hit = vals.some(v => v.includes(k.t));
        return k.neg ? !hit : hit;
      });
    });
  }
  function findHl(v, q, c) {
    const s = String(v == null ? "" : v), tk = parseQ(q).filter(k => !k.neg && (!k.col || AN(c.t).startsWith(k.col)));
    if (!tk.length) return esc(s);
    /* خريطة الأحرف بعد التطبيع ← مواضعها في النص الأصلي */
    let n = "", map = [];
    for (let i = 0; i < s.length; i++) { const a = AN(s[i]); for (let j = 0; j < a.length; j++) { n += a[j]; map.push(i); } }
    const mark = new Array(s.length).fill(false);
    tk.forEach(k => { let p = n.indexOf(k.t); while (p >= 0 && k.t) { for (let j = p; j < p + k.t.length; j++) mark[map[j]] = true; p = n.indexOf(k.t, p + k.t.length); } });
    let h = "", on = false;
    for (let i = 0; i < s.length; i++) { if (mark[i] !== on) { h += mark[i] ? '<mark class="irf">' : "</mark>"; on = mark[i]; } h += esc(s[i]); }
    return h + (on ? "</mark>" : "");
  }

  /* ---------------- سطر الإجمالي ---------------- */
  function totRow(l, cs) {
    const it = l.filter(r => !r._grp), prods = new Set(it.map(r => r._p || r)).size;
    return cs.map(c => {
      if (c.k === "rn" || c.k === "ic") return "<div></div>";
      if (c.agg === "cnt") return `<div title="عدد الأسطر / عدد الأصناف">${it.length} سطر · ${prods} صنف</div>`;
      if (c.agg === "row") return `<div>${F(it.reduce((s, r) => s + (+(c.v ? c.v(r) : NUM(c.f(r))) || 0), 0))}</div>`;
      if (c.agg === "item") { const seen = new Set(); let s = 0; it.forEach(r => { const p = r._p || r; if (seen.has(p)) return; seen.add(p); s += +(c.v ? c.v(r) : NUM(c.f(r))) || 0; }); return `<div title="مجموع الأصناف (بدون تكرار الوحدات)">${F(s)}</div>`; }
      return "<div></div>";
    }).join("");
  }

  /* ---------------- خيارات الشبكة (تُدمج في إعداد Review) ---------------- */
  function cfgx() {
    return {
      totals: 1, findFilter, findHl, postList, totRow,
      rowCls: (r, i) => r && r._grp ? "irt-g irt-d" + Math.min(5, r._depth || 0) : (i % 2 ? "ire" : "iro"),
      rnTxt: (r, i) => r && r._grp ? "" : (r && r._n) || i + 1,
      noSort: () => MODE === "tree"
    };
  }

  /* ---------------- ربط الشاشة ---------------- */
  let IRS = null, EL = null, SIG = "";
  function rerender() { try { if (IRS) IRS.render(); } catch (e) { console.error(e); } }
  function attach(S, el) {
    IRS = S; EL = el; el.classList.add("irx");
    loadMeta(); loadGroups(); loadUser();
    /* أسطر المجموعات: النقر يطوي/يفتح ، والنقر المزدوج لا يفتح بطاقة */
    const o1 = S.cfg.onOpen, o2 = S.cfg.onIcon;
    S.cfg.onOpen = r => { if (r && r._grp) { toggleGroup(r); return; } o1 && o1(r); };
    S.cfg.onIcon = r => { if (r && r._grp) return; o2 && o2(r); };
    el.querySelector(".rv-rows").addEventListener("click", e => { const d = e.target.closest(".rv-d.irt-g"); if (!d) return; const r = (S.cur || [])[+d.dataset.i]; if (r && r._grp) toggleGroup(r); });
    buildHead(el); wireHead(el); wireSearch(el);
    applyLayout(true);
    applyUserDefault();
    window.addEventListener("anouer:products", () => { loadMeta(true); });
  }
  /* تطبيق حالة العرض الحالية على الشاشة: الأعمدة + الخصائص + الكثافة */
  function applyLayout(first) {
    const s = SET();
    try { riView(s.density || ""); } catch (e) { }
    applyStyle();
    /* إعادة بناء العناوين فقط عند تغيّر الأعمدة (حتى لا تُمسح تصفية سطر البحث مع كل تعديل) */
    const L = LAY(), sig = MODE + "|" + JSON.stringify([visIds(), L.w, L.cap, CALC()]);
    if (IRS) { if (first || sig !== SIG) IRS.setCols(cols()); else IRS.render(); }
    SIG = sig;
    if (s.fit) setTimeout(() => fitScreen(true), 0);
    paintHead();
  }

  /* ---------------- Customization (اختيار الحقول) ---------------- */
  const css = document.createElement("style");
  css.textContent = `
  .irx .rv-h>div[draggable=true]{cursor:pointer}.irx .rv-h>div.drg{opacity:.45}
  .irx .rv-h>div.ins-r{box-shadow:inset -3px 0 0 #1a6fd0}.irx .rv-h>div.ins-l{box-shadow:inset 3px 0 0 #1a6fd0}
  .irx .rv-d.msel{background:#cfe3fb!important}
  .irx .rv-d.msel>div:first-child{box-shadow:inset -3px 0 0 #1a6fd0}
  .irc{position:fixed;z-index:1600;width:230px;background:#fff;border:1px solid #c9d3df;box-shadow:0 8px 26px rgba(20,40,70,.25);border-radius:3px;font-family:"Droid Arabic Kufi","Segoe UI",Tahoma,sans-serif;font-size:11.5px;color:#222;direction:rtl;display:flex;flex-direction:column;max-height:420px}
  .irc .h{display:flex;align-items:center;justify-content:space-between;padding:8px 10px;color:#777;font-weight:700;cursor:move;user-select:none;direction:ltr}
  .irc .h b{cursor:pointer;font-size:14px;color:#555;padding:0 4px}
  .irc .q{margin:0 6px 4px;display:flex;border-bottom:1px solid #b8c4d2}.irc .q input{flex:1;border:0;outline:0;font:inherit;padding:4px 2px;direction:ltr;text-align:left}
  .irc .ls{overflow:auto;flex:1;padding:2px 6px 8px}
  .irc .it{background:#dce9fb;border-radius:4px;margin:4px 0;padding:7px 6px;text-align:center;cursor:grab;user-select:none}
  .irc .it:hover{background:#cadcf6}.irc .it.drg{opacity:.4}
  .irc .e{color:#777;text-align:center;padding:16px 8px;line-height:1.8}
  .irc.drop{outline:2px dashed #1a6fd0;outline-offset:-4px}
  .irm{position:fixed;z-index:1650;min-width:190px;background:#fff;border:1px solid #c6cfdb;box-shadow:0 6px 20px rgba(20,40,70,.22);border-radius:3px;padding:3px 0;font-family:"Droid Arabic Kufi","Segoe UI",Tahoma,sans-serif;font-size:11.5px;direction:rtl}
  .irm .i{display:flex;align-items:center;gap:8px;padding:6px 12px;cursor:pointer;white-space:nowrap;position:relative}
  .irm .i:hover{background:#e7f0fc}.irm .i.dis{color:#aaa;pointer-events:none}
  .irm .i kbd{margin-inline-start:auto;font:inherit;color:#888;direction:ltr;padding-inline-start:18px}
  .irm .i .ic{width:18px;height:18px;display:inline-flex;align-items:center;justify-content:center}.irm .i .ic svg{width:16px;height:16px}
  .irm .i .ar{margin-inline-start:auto;color:#666;font-size:9px}
  .irm .sep{height:1px;background:#e4e8ee;margin:3px 0}
  .irm .i .sw{margin-inline-start:auto;width:30px;height:14px;border-radius:8px;background:#cfd6df;position:relative}
  .irm .i .sw:after{content:"";position:absolute;top:2px;right:2px;width:10px;height:10px;border-radius:50%;background:#1a6fd0;transition:.15s}
  .irm .i .sw.on{background:#9cc6f3}.irm .i .sw.on:after{right:18px}
  .irw-ov{position:fixed;inset:0;z-index:1700;background:rgba(20,30,45,.35);display:flex;align-items:center;justify-content:center}
  .irw{width:min(880px,94vw);max-height:90vh;background:#fff;border-radius:4px;box-shadow:0 14px 44px rgba(0,0,0,.35);display:flex;flex-direction:column;font-family:"Droid Arabic Kufi","Segoe UI",Tahoma,sans-serif;font-size:12px;direction:rtl}
  .irw .t{display:flex;align-items:center;gap:8px;padding:10px 14px;background:#1a6fd0;color:#fff;font-weight:700;border-radius:4px 4px 0 0}.irw .t .sp{flex:1}.irw .t b{cursor:pointer;font-size:15px}
  .irw .b{padding:12px 14px;overflow:auto;flex:1}
  .irw .f{display:flex;gap:8px;justify-content:flex-end;padding:10px 14px;border-top:1px solid #e3e8ee}
  .irw .f button{height:30px;min-width:96px;border:1px solid #c4ceda;background:#fff;border-radius:3px;cursor:pointer;font:inherit}
  .irw .f .ok{background:#2e8b3a;border-color:#2e8b3a;color:#fff}.irw .f .ok:disabled{opacity:.5;cursor:default}
  .irw .kp{display:flex;flex-wrap:wrap;gap:10px;margin:8px 0}.irw .kp div{flex:1;min-width:130px;background:#f4f7fb;border:1px solid #e1e7ef;border-radius:4px;padding:8px 10px}
  .irw .kp b{display:block;font-size:18px;color:#1a6fd0}.irw .kp .w b{color:#c06a00}
  .irw .ops{display:flex;flex-wrap:wrap;gap:6px 16px;margin:10px 0;padding:8px 10px;border:1px solid #e1e7ef;border-radius:4px}
  .irw .ops label{display:flex;gap:5px;align-items:center;cursor:pointer}
  .irw table{border-collapse:collapse;width:100%;font-size:11px}.irw th,.irw td{border:1px solid #e1e6ed;padding:4px 6px;text-align:center}.irw th{background:#eaf1fb;position:sticky;top:0}
  .irw td.o{color:#999;text-decoration:line-through}.irw td.n{color:#0b6b2e;font-weight:700}
  .irw .note{color:#666;line-height:1.8;margin:6px 0}
  .irw .bar{height:6px;background:#e7edf5;border-radius:3px;overflow:hidden;margin:10px 0}.irw .bar i{display:block;height:100%;width:0;background:#1a6fd0;transition:width .2s}
  .irw .mv td.in{color:#0b6b2e}.irw .mv td.out{color:#b3261e}.irw .mv tfoot td{font-weight:700;background:#f6f8fb}
  .irw .att{display:flex;flex-direction:column;gap:6px}.irw .att .a{display:flex;align-items:center;gap:8px;padding:6px 8px;border:1px solid #e3e8ee;border-radius:3px}
  /* نافذة التصميمات / المستخدمين — مطابقة DEXEF */
  .dxm{position:relative;width:min(700px,94vw);height:min(650px,92vh);background:#fff;border-radius:3px;box-shadow:0 10px 40px rgba(0,0,0,.32);display:flex;flex-direction:column;font-family:"Droid Arabic Kufi","Segoe UI",Tahoma,sans-serif;font-size:12px;direction:rtl;color:#222;animation:puIn .12s ease-out}
  .dxm-x{position:absolute;left:14px;top:12px;width:26px;height:26px;border:0;background:transparent;border-radius:3px;cursor:pointer;display:flex;align-items:center;justify-content:center}
  .dxm-x:hover{background:#eef1f5}.dxm-x svg{width:13px;height:13px}
  .dxm-tabs{display:flex;gap:6px;padding:52px 24px 0 0;flex-shrink:0}
  .dxm-tabs button{height:32px;min-width:110px;padding:0 14px;border:0;border-radius:3px;background:#3d95ee;color:#fff;font:inherit;font-size:13px;cursor:pointer;transition:background .12s}
  .dxm-tabs button:hover{background:#2f86e0}.dxm-tabs button.on{background:#0b4d97;cursor:default}
  .dxm-b{flex:1;min-height:0;display:flex;flex-direction:column;padding:22px 2px 0;overflow:hidden}
  .dxm-f{height:76px;flex-shrink:0;background:#e7eaee;border-radius:0 0 3px 3px;display:flex;align-items:center;gap:8px;padding:0 18px}.dxm-f .sp{flex:1}
  .dxm-close{height:34px;width:120px;border:1px solid #0e6fb8;border-radius:3px;background:linear-gradient(#33b2f7,#1594e6);color:#fff;font:inherit;font-size:13px;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.35)}
  .dxm-close:hover{background:linear-gradient(#45bbf8,#1d9cee)}.dxm-close:active{background:#1488d6}
  .dxm-io{height:26px;border:0;background:transparent;color:#1a5fb4;font:inherit;font-size:11px;cursor:pointer;border-radius:3px;padding:0 8px}.dxm-io:hover{background:#dde3ea}
  .dxg{flex:1;min-height:0;overflow:auto;margin:0 0 0 2px}
  .dxg .dxr{display:grid;align-items:center;min-height:30px}
  .dxg-d .dxr{grid-template-columns:42px minmax(160px,1fr) 70px 70px 70px 70px}.dxg-u .dxr{grid-template-columns:42px 74px minmax(160px,1fr)}
  .dxg .dxh{position:sticky;top:0;background:#fff;z-index:1}.dxg .dxh>div{background:#e1ebff;height:28px;border-radius:5px;margin:0 1.5px;display:flex;align-items:center;justify-content:center;font-size:11px;color:#333;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .dxg .dxh>div:first-child{background:#eaf0fb}
  .dxg .dxf{position:sticky;top:28px;background:#fff;z-index:1;height:34px;border-bottom:1px solid #eef0f3}.dxg .dxf>div{display:flex;align-items:center;justify-content:center;color:#666;font-family:"Segoe UI",Arial}
  .dxg .dxf .fi{position:relative;height:100%}.dxg .dxf .fi input{width:100%;height:100%;border:0;outline:0;background:transparent;font:inherit;font-size:12px;padding:0 10px 0 34px;text-align:right}
  .dxg .dxf .fi input:focus{background:#fffbe6;box-shadow:inset 0 0 0 1px #f2c94c}
  .dxm .abc{position:absolute;left:10px;top:50%;transform:translateY(-50%);font:700 7.5px Arial;color:#2e9b48;border:1px solid #2e9b48;border-radius:2px;padding:0 1px;line-height:9px;letter-spacing:.3px;pointer-events:none}.dxm .abc b{color:#1a6fd0}
  .dxg .dxd{border-bottom:1px solid #f0f2f5;cursor:default}.dxg .dxd:hover{background:#f6f9ff}.dxg .dxd.sel{background:#eaf2ff}
  .dxg .dxd>div{display:flex;align-items:center;justify-content:center;height:30px;overflow:hidden}.dxg .dxd>div.nm{justify-content:flex-start;padding:0 10px;white-space:nowrap;text-overflow:ellipsis}
  .dxg .dxd .ind{color:#1a6fd0;font-size:13px}.dxg .dxd .nm i.on{font-style:normal;color:#2e9b48;font-size:9px;margin-inline-start:6px}.dxg .dxd .nm small{color:#8a94a0;margin-inline-start:6px}
  .dxg .dxd button{border:0;background:transparent;cursor:pointer;width:30px;height:24px;border-radius:3px;display:flex;align-items:center;justify-content:center}.dxg .dxd button:hover{background:#e6eefa}.dxg .dxd button svg{width:15px;height:15px}
  .dxg input[type=checkbox]{width:15px;height:15px;margin:0;accent-color:#5a6b80;cursor:pointer}
  .dxg .dxd .ren{width:100%;height:24px;border:1px solid #f2c94c;background:#fffbe6;outline:0;font:inherit;padding:0 6px}
  .dxg .dxe{padding:30px;text-align:center;color:#999}
  .dxu-top{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:0 24px 10px 30px;flex-shrink:0}
  .dxu-t{display:flex;flex-direction:column;gap:14px}.dxu-t b{font-size:15px;color:#111}.dxu-t span{font-size:11.5px;color:#333}.dxu-t em{font-style:normal;font-size:11px;color:#1a6fd0}
  .dxu-img{width:230px;flex-shrink:0}.dxu-img svg{width:100%;height:auto;display:block}
  .irw .att .a span{flex:1}.irw .att .a button{height:24px;border:1px solid #c4ceda;background:#fff;border-radius:3px;cursor:pointer;font:inherit;font-size:11px}
  /* طريقة العرض بجانب البحث */
  .irx .irv-mode{display:flex;align-items:center;gap:6px;border:0;border-bottom:1px solid #b8bec6;background:transparent;height:24px;padding:0 4px;font:inherit;font-size:12.5px;color:#222;cursor:pointer;border-radius:2px 2px 0 0}
  .irx .irv-mode:hover{background:#eef3fa}.irx .irv-mode svg{width:15px;height:15px}.irx .irv-mode i{font-style:normal;color:#777;font-size:10px}
  /* مربع التصاميم (الخمسية ⋯ ✓) */
  .irx .ird{cursor:default;user-select:none}.irx .ird>span{cursor:pointer;border-radius:2px;padding:0 3px}.irx .ird>span:hover{background:#e3ecf8}
  .irx .ird .ck{opacity:.45}.irx .ird .ck.on{opacity:1;font-weight:700}.irx .ird .dots{font-weight:700;color:#333;letter-spacing:1px}.irx .ird .chev{font-size:9px;color:#777}
  /* البحث */
  .irx .rv-search{position:relative}.irx .rv-search .irf-n{font-style:normal;font-size:10px;background:#1a6fd0;color:#fff;border-radius:8px;padding:0 6px;line-height:15px;font-family:"Segoe UI",Arial}
  .irx .rv-search .irf-n.z{background:#c0392b}.irx .rv-search .irf-x{cursor:pointer;color:#888;font-size:11px;font-weight:400}.irx .rv-search .irf-x:hover{color:#c0392b}
  mark.irf{background:#ffe066;color:inherit;padding:0 1px;border-radius:2px;box-shadow:0 0 0 1px #f2c94c inset}
  .irx.irx-nof .rv-f{display:none}.irx.irx-notot .rv-tot{display:none}
  .irx .rv-tot{background:#f4f7fb}.irx .rv-tot>div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:0 4px;line-height:28px;color:#1a3d6d}
  /* العرض الشجري */
  .irx .rv-d.irt-g{background:#eef3fa;cursor:pointer}.irx .rv-d.irt-g>div{font-weight:700;color:#1a3d6d}.irx .rv-d.irt-g:hover{background:#e2ebf8}
  .irx .rv-d.irt-g.irt-d1{background:#f3f7fc}.irx .rv-d.irt-g.irt-d2,.irx .rv-d.irt-g.irt-d3{background:#f7f9fd}
  .irx[data-irmode="tree"] .rv-h>div{cursor:default}
  /* نوافذ التصاميم والخصائص */
  .ird-tabs{display:flex;gap:6px;margin:-2px 0 10px}.ird-tabs .sp{flex:1}
  .ird-tabs button{height:32px;min-width:110px;border:0;border-radius:3px;background:#3d8bea;color:#fff;font:inherit;cursor:pointer}.ird-tabs button.on{background:#0f4c99}
  .ird-tabs button[data-t=exp],.ird-tabs button[data-t=imp]{min-width:70px;background:#fff;color:#1a5fb4;border:1px solid #c4d3e6}
  .ird-t{border-collapse:collapse;width:100%;font-size:12px}.ird-t th{background:#e1ebff;font-weight:400;padding:6px;border:1px solid #fff}.ird-t td{border-bottom:1px solid #eef1f4;padding:5px 6px;text-align:center}
  .ird-t td.nm{text-align:right}.ird-t td.nm small{display:block;color:#8a94a0;font-size:10px}.ird-t tr.cur{background:#f2f7ff}.ird-t tr.hl{background:#fff8d6}.ird-t .arw{color:#1a6fd0}
  .ird-t button{border:0;background:transparent;cursor:pointer;padding:3px 5px;border-radius:3px}.ird-t button:hover{background:#eef3fa}.ird-t button svg{width:15px;height:15px}
  .ird-t input.ren,.ird-t input.cap{width:100%;height:26px;border:1px solid #b9c6d6;border-radius:2px;padding:0 6px;font:inherit}
  .ird-t input.wd{width:76px;height:26px;border:1px solid #b9c6d6;border-radius:2px;padding:0 4px;font:inherit;direction:ltr}
  .ird-t select{height:26px;min-width:180px;font:inherit}.irp td.h{color:#aab;cursor:grab}
  .ird-f{display:flex;flex-direction:column;gap:10px}.ird-f label{display:flex;flex-direction:column;gap:4px}.ird-f label.ck{flex-direction:row;align-items:center;gap:6px}
  .ird-f input:not([type=checkbox]),.ird-f textarea{height:30px;border:1px solid #b9c6d6;border-radius:3px;padding:0 8px;font:inherit}.ird-f textarea{height:auto;padding:6px 8px;direction:ltr;text-align:left;font-family:Consolas,monospace}
  .ird-f .q{font-size:14px;font-weight:700;color:#1a3d6d}
  .irw-s{width:min(620px,94vw)}.irs{display:flex;flex-direction:column;gap:6px}.irs[hidden]{display:none}.irs fieldset{border:1px solid #e1e7ef;border-radius:4px;padding:6px 10px 8px;margin:0 0 6px}.irs legend{color:#1a6fd0;font-weight:700;padding:0 4px}
  .irs label{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:4px 2px;border-bottom:1px dashed #eef1f4}
  .irs select,.irs input[type=number],.irs input:not([type]){height:28px;min-width:170px;font:inherit;border:1px solid #c4ceda;border-radius:3px;padding:0 6px}
  .irs input[type=color]{width:46px;height:26px;border:1px solid #c4ceda;padding:1px;border-radius:3px;background:#fff}
  .irs .sw-r input{display:none}.irs .sw-r .sw{width:34px;height:16px;border-radius:9px;background:#cfd6df;position:relative;cursor:pointer;flex-shrink:0}
  .irs .sw-r .sw:after{content:"";position:absolute;top:2px;right:2px;width:12px;height:12px;border-radius:50%;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.3);transition:.15s}
  .irs .sw-r input:checked+.sw{background:#1a6fd0}.irs .sw-r input:checked+.sw:after{right:20px}
  .irc2 .chips{display:flex;flex-wrap:wrap;gap:4px}.irc2 .chips button,.irc2 .tpls button{height:24px;border:1px solid #c7d6ea;background:#f1f6fd;border-radius:12px;padding:0 9px;font:inherit;font-size:11px;cursor:pointer;color:#1a4d8f}
  .irc2 .chips button:hover,.irc2 .tpls button:hover{background:#dceafc}.irc2 .ops button{min-width:30px;font-family:Consolas,monospace;font-weight:700;background:#fff}
  .irc2 .tpls{display:flex;flex-wrap:wrap;gap:4px;align-items:center}.irc2 .tpls span{color:#666;font-size:11px}.irc2 .tpls button{background:#fff8e6;border-color:#f0d8a0;color:#7a5200}
  .irc2 .pv{background:#f4f7fb;border:1px solid #e1e7ef;border-radius:4px;padding:6px 10px}.irc2 .pv b{color:#0b6b2e}.irc2 .pv b.bad{color:#c0392b}
  .rcm .rcm-mi{display:inline-flex;width:16px;height:16px;vertical-align:-3px;margin-left:6px}.rcm .rcm-mi svg{width:16px;height:16px}.rcm .rcm-ok{font-style:normal;color:#1a6fd0;margin-right:10px;font-weight:700}`;
  document.head.appendChild(css);

  let CZ = null;
  function chooser(anchor) {
    if (CZ) { CZ.remove(); CZ = null; return; }
    const d = document.createElement("div"); d.className = "irc"; d.setAttribute("role", "dialog"); d.setAttribute("aria-label", "Customization");
    d.innerHTML = `<div class="h"><span>Customization</span><b title="إغلاق">✕</b></div><div class="q"><input placeholder="Search for a column..."><span>⌕</span></div><div class="ls"></div>`;
    document.body.appendChild(d); CZ = d;
    const r = (anchor || EL).getBoundingClientRect();
    d.style.left = Math.max(8, Math.min(innerWidth - 240, r.left + 10)) + "px"; d.style.top = Math.max(8, Math.min(innerHeight - 430, r.top + 40)) + "px";
    const q = d.querySelector(".q input"), ls = d.querySelector(".ls");
    const draw = () => {
      const vis = visIds(), s = q.value.trim().toLowerCase();
      const hid = allCols().filter(c => avail(c) && !vis.includes(c.id) && (!s || AN(c.t).includes(AN(s)))).sort((a, b) => a.t.localeCompare(b.t, "ar"));
      ls.innerHTML = hid.length ? hid.map(c => `<div class="it" draggable="true" data-id="${c.id}" title="اسحب إلى العناوين لإظهاره — أو انقر مرتين">${esc(c.t)}</div>`).join("") : `<div class="e">Drag and drop columns here to customize layout</div>`;
    };
    draw(); q.addEventListener("input", draw);
    d.querySelector(".h b").onclick = () => { d.remove(); CZ = null; };
    ls.addEventListener("dblclick", e => { const it = e.target.closest(".it"); if (!it) return; const v = visIds(); v.push(it.dataset.id); setVis(v); draw(); });
    ls.addEventListener("dragstart", e => { const it = e.target.closest(".it"); if (!it) return; e.dataTransfer.setData("text/irx-col", it.dataset.id); e.dataTransfer.effectAllowed = "move"; it.classList.add("drg"); DRAG = { from: "cz", id: it.dataset.id }; });
    ls.addEventListener("dragend", e => { const it = e.target.closest(".it"); if (it) it.classList.remove("drg"); DRAG = null; clearIns(); });
    /* سحب عنوان إلى النافذة ← إخفاء العمود */
    d.addEventListener("dragover", e => { if (DRAG && DRAG.from === "hd") { e.preventDefault(); d.classList.add("drop"); } });
    d.addEventListener("dragleave", () => d.classList.remove("drop"));
    d.addEventListener("drop", e => { d.classList.remove("drop"); if (!DRAG || DRAG.from !== "hd") return; e.preventDefault(); const id = DRAG.id; if (byId(id) && byId(id).fix) { say("لا يمكن إخفاء عمود الاسم", "w"); return; } setVis(visIds().filter(x => x !== id)); draw(); });
    /* تحريك النافذة */
    const hh = d.querySelector(".h"); hh.addEventListener("pointerdown", e => { if (e.target.closest("b")) return; const sx = e.clientX - d.offsetLeft, sy = e.clientY - d.offsetTop; const mv = ev => { d.style.left = (ev.clientX - sx) + "px"; d.style.top = (ev.clientY - sy) + "px"; }; const up = () => { removeEventListener("pointermove", mv); removeEventListener("pointerup", up); }; addEventListener("pointermove", mv); addEventListener("pointerup", up); });
    d.__draw = draw;
  }
  let DRAG = null;
  function clearIns() { if (EL) EL.querySelectorAll(".rv-h>div.ins-r,.rv-h>div.ins-l,.rv-h>div.drg").forEach(x => x.classList.remove("ins-r", "ins-l", "drg")); }
  function wireHead(el) {
    const h = el.querySelector(".rv-h");
    const mark = () => h.querySelectorAll("div[data-id]").forEach(x => { x.draggable = true; });
    mark(); IRS.cfg.onCols = () => { mark(); if (CZ && CZ.__draw) CZ.__draw(); };
    h.addEventListener("dragstart", e => { const c = e.target.closest("div[data-id]"); if (!c) return; DRAG = { from: "hd", id: c.dataset.id }; e.dataTransfer.setData("text/irx-col", c.dataset.id); e.dataTransfer.effectAllowed = "move"; c.classList.add("drg"); IRS.noSortClick = 1; });
    h.addEventListener("dragend", () => { DRAG = null; clearIns(); setTimeout(() => { IRS.noSortClick = 0; }, 50); });
    const side = (c, e) => { const r = c.getBoundingClientRect(); return e.clientX < r.left + r.width / 2 ? "l" : "r"; };   // RTL: «يمين» = قبل
    h.addEventListener("dragover", e => {
      if (!DRAG) return; const c = e.target.closest("div[data-id]"); e.preventDefault(); clearIns(); if (!c) return;
      if (DRAG.from === "hd" && c.dataset.id === DRAG.id) return;
      c.classList.add(side(c, e) === "r" ? "ins-r" : "ins-l");
    });
    h.addEventListener("drop", e => {
      if (!DRAG) return; e.preventDefault();
      const c = e.target.closest("div[data-id]"), id = DRAG.id; let v = visIds().filter(x => x !== id);
      if (c && c.dataset.id !== id) { let k = v.indexOf(c.dataset.id); if (side(c, e) === "l") k++; v.splice(k, 0, id); } else if (!c) v.push(id); else v = visIds();
      DRAG = null; clearIns(); setVis(v);
    });
  }

  /* ---------------- القوائم المنسدلة ---------------- */
  let MN = null;
  function closeMenu() { if (MN) { MN.remove(); MN = null; document.removeEventListener("mousedown", outMenu, true); } }
  function outMenu(e) { if (MN && !MN.contains(e.target)) closeMenu(); }
  function menu(anchor, items, at) {
    closeMenu();
    const m = document.createElement("div"); m.className = "irm"; m.setAttribute("role", "menu");
    const build = (list, host) => {
      host.innerHTML = list.map((x, i) => x === "-" ? '<div class="sep"></div>' : `<div class="i${x.dis ? " dis" : ""}" data-i="${i}" role="menuitem"${x.tip ? ` title="${esc(x.tip)}"` : ""}>${x.ic ? `<span class="ic">${x.ic}</span>` : ""}<span>${esc(x.t)}</span>${x.kb ? `<kbd>${x.kb}</kbd>` : ""}${x.sw != null ? `<span class="sw${x.sw ? " on" : ""}"></span>` : ""}${x.sub ? '<span class="ar">◀</span>' : ""}</div>`).join("");
    };
    build(items, m); document.body.appendChild(m); MN = m;
    const r = at ? { left: at.x, right: at.x, bottom: at.y, top: at.y } : anchor.getBoundingClientRect();
    let l = r.right - m.offsetWidth; if (l < 4) l = Math.min(r.left, innerWidth - m.offsetWidth - 4);
    let t = r.bottom + 2; if (t + m.offsetHeight > innerHeight - 4) t = Math.max(4, r.top - m.offsetHeight - 2);
    m.style.left = l + "px"; m.style.top = t + "px";
    let cur = items, sub = null;
    m.addEventListener("click", e => {
      const it = e.target.closest(".i"); if (!it) return;
      const list = it.parentElement === m ? items : cur, x = list[+it.dataset.i]; if (!x || x.dis) return;
      if (x.sub) { if (sub) sub.remove(); sub = document.createElement("div"); sub.className = "irm"; cur = x.sub; build(x.sub, sub); document.body.appendChild(sub);
        const rr = it.getBoundingClientRect(); let sl = rr.left - sub.offsetWidth; if (sl < 4) sl = rr.right; sub.style.left = sl + "px"; sub.style.top = Math.min(rr.top, innerHeight - sub.offsetHeight - 4) + "px";
        sub.addEventListener("click", ev => { const s2 = ev.target.closest(".i"); if (!s2) return; const y = x.sub[+s2.dataset.i]; if (!y || y.dis) return; sub.remove(); closeMenu(); y.f && y.f(); });
        const kill = ev => { if (!sub.contains(ev.target) && !m.contains(ev.target)) { sub.remove(); document.removeEventListener("mousedown", kill, true); } }; document.addEventListener("mousedown", kill, true);
        return; }
      closeMenu(); x.f && x.f();
    });
    setTimeout(() => document.addEventListener("mousedown", outMenu, true), 0);
    return m;
  }

  /* ---------------- الأسطر الظاهرة / المختارة ---------------- */
  const shownAll = () => (IRS && IRS.cur) || [];
  const shown = () => shownAll().filter(r => !r._grp);
  const curRow = () => { const r = IRS ? shownAll()[IRS.sel] : null; return r && !r._grp ? r : null; };
  const picked = () => IRS && IRS.ms && IRS.ms.size ? shown().filter(r => IRS.ms.has(r)) : null;
  const visCols = () => cols().filter(c => c.f);
  const cellTxt = (c, r) => { const v = c.f(r); return v == null ? "" : String(v); };
  const cellVal = (c, r) => { if (c.v) { const v = c.v(r); return typeof v === "number" ? r2(v) : v; } const v = c.f(r); return v == null ? "" : v; };
  const fname = () => (SET().title || "مراجعة الأصناف") + " " + today();

  /* ---------------- التصدير ---------------- */
  function ensureX() { return window.XLSX ? Promise.resolve() : new Promise((ok, no) => { const s = document.createElement("script"); s.src = "/assets/js/vendor/xlsx.full.min.js"; s.onload = ok; s.onerror = () => no(new Error("تعذّر تحميل مكتبة إكسيل")); document.head.appendChild(s); }); }
  function exportX(kind, rows) {
    rows = rows || picked() || shown(); if (!rows.length) { say("لا توجد أسطر للتصدير", "w"); return Promise.resolve(); }
    const cs = visCols();
    if (kind === "csv") {
      const q = v => { v = String(v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
      dl(new Blob(["﻿" + [cs.map(c => q(c.t)).join(",")].concat(rows.map(r => cs.map(c => q(cellVal(c, r))).join(","))).join("\r\n")], { type: "text/csv;charset=utf-8" }), fname() + ".csv");
      say("تم تصدير " + rows.length + " سطر (CSV)", "s"); return Promise.resolve();
    }
    if (kind === "html" || kind === "doc") {
      const h = htmlTable(rows, cs, true);
      dl(new Blob(["﻿" + h], { type: kind === "doc" ? "application/msword" : "text/html;charset=utf-8" }), fname() + (kind === "doc" ? ".doc" : ".html"));
      say("تم تصدير " + rows.length + " سطر (" + (kind === "doc" ? "Word" : "HTML") + ")", "s"); return Promise.resolve();
    }
    return ensureX().then(() => {
      const aoa = [cs.map(c => c.t)].concat(rows.map(r => cs.map(c => cellVal(c, r))));
      const ws = XLSX.utils.aoa_to_sheet(aoa); ws["!cols"] = cs.map(c => ({ wch: c.id === "name" ? 42 : Math.max(9, Math.min(28, c.t.length + 4)) }));
      ws["!autofilter"] = { ref: XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: aoa.length - 1, c: cs.length - 1 } }) };
      const wb = XLSX.utils.book_new(); wb.Workbook = { Views: [{ RTL: true }] }; XLSX.utils.book_append_sheet(wb, ws, "الأصناف");
      XLSX.writeFile(wb, fname() + (kind === "xls" ? ".xls" : ".xlsx"), { bookType: kind === "xls" ? "biff8" : "xlsx" });
      say("تم تصدير " + rows.length + " سطر × " + cs.length + " عمود إلى إكسيل", "s");
    }).catch(e => say(e.message || String(e), "e"));
  }
  function dl(blob, name) { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800); }
  function htmlTable(rows, cs, full) {
    const t = `<table><thead><tr><th>#</th>${cs.map(c => `<th>${esc(c.t)}</th>`).join("")}</tr></thead><tbody>${rows.map((r, i) => `<tr><td>${i + 1}</td>${cs.map(c => `<td>${esc(cellTxt(c, r))}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
    if (!full) return t;
    return `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>${esc(fname())}</title><style>@page{size:A4 landscape;margin:10mm}body{font-family:"Droid Arabic Kufi",Tahoma,Arial;font-size:10px;margin:0}h2{text-align:center;margin:4px 0 2px}.m{text-align:center;color:#555;margin-bottom:8px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #b9c3cf;padding:3px 4px;text-align:center}th{background:#e1ebff}tr:nth-child(even) td{background:#f6f8fb}</style></head><body><h2>${esc(SET().title || "مراجعة الأصناف")}</h2><div class="m">${esc(modeName())} — ${today()} — ${rows.length} سطر</div>${t}</body></html>`;
  }
  function printView(preview, rows) {
    rows = rows || picked() || shown(); if (!rows.length) { say("لا توجد أسطر للطباعة", "w"); return; }
    const w = window.open("", "_blank"); if (!w) { say("تعذّر فتح نافذة الطباعة", "w"); return; }
    w.document.write(htmlTable(rows, visCols(), true)); w.document.close(); w.focus();
    if (!preview) setTimeout(() => { try { w.print(); } catch (e) { } }, 300);
  }
  function mail(kind) {
    const rows = picked() || shown(); if (!rows.length) { say("لا توجد أسطر", "w"); return; }
    if (window.ANOUER_MAIL) { const cs = visCols().map(c => ({ t: c.t, f: r => cellVal(c, r) })); ANOUER_MAIL.table({ title: fname(), cols: cs, rows, xls: kind !== "pdf", pdf: kind === "pdf" || true }); return; }
    const go = () => { location.href = "mailto:?subject=" + encodeURIComponent(fname()) + "&body=" + encodeURIComponent("مرفق: " + fname() + (kind === "pdf" ? ".pdf" : ".xlsx") + " (" + rows.length + " صنف)"); say("أرفق الملف المحفوظ في رسالة البريد", "i"); };
    if (kind === "pdf") { printView(false, rows); say("اختر «Microsoft Print to PDF» ثم أرفق الملف في البريد", "i"); setTimeout(go, 1200); }
    else exportX("xlsx", rows).then(go);
  }

  const IC = {
    gear: '<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="5.5" fill="none" stroke="#555" stroke-width="1.6"/><circle cx="8" cy="8" r="2" fill="#555"/></svg>',
    cols: '<svg viewBox="0 0 16 16"><path d="M2 3h12M2 7h12M2 11h7" stroke="#555" stroke-width="1.6"/><path d="M11 10l2 2 2-2" fill="none" stroke="#555" stroke-width="1.4"/></svg>',
    ok: '<svg viewBox="0 0 16 16"><rect x="1.5" y="1.5" width="13" height="13" rx="2" fill="#2e8b3a"/><path d="M4.5 8.2l2.3 2.3 4.7-5" fill="none" stroke="#fff" stroke-width="1.8"/></svg>',
    add: '<svg viewBox="0 0 16 16"><rect x="2" y="2" width="12" height="12" rx="1" fill="#fff" stroke="#555"/><path d="M5 6h6M5 9h3" stroke="#555"/><path d="M12 10v5M9.5 12.5h5" stroke="#1a6fd0" stroke-width="1.6"/></svg>',
    list: '<svg viewBox="0 0 16 16"><path d="M2 4h12M2 8h12M2 12h12" stroke="#1a6fd0" stroke-width="1.6"/></svg>',
    multi: '<svg viewBox="0 0 16 16"><rect x="1.5" y="2" width="4" height="4" fill="none" stroke="#555"/><rect x="1.5" y="9" width="4" height="4" fill="none" stroke="#555"/><path d="M8 4h7M8 11h7" stroke="#555" stroke-width="1.5"/></svg>',
    del: '<svg viewBox="0 0 16 16"><path d="M3 4h10M6 4V2.5h4V4M4.5 4l.8 10h5.4l.8-10" fill="none" stroke="#555" stroke-width="1.3"/></svg>',
    delm: '<svg viewBox="0 0 16 16"><rect x="1.5" y="1.5" width="13" height="13" fill="none" stroke="#555"/><path d="M1.5 6h13M6 1.5v13" stroke="#555"/><path d="M9 9l4 4M13 9l-4 4" stroke="#c33" stroke-width="1.4"/></svg>',
    prv: '<svg viewBox="0 0 16 16"><rect x="2" y="1.5" width="10" height="13" fill="#fff" stroke="#555"/><circle cx="10.5" cy="10.5" r="3" fill="#fff" stroke="#1a6fd0" stroke-width="1.4"/><path d="M12.6 12.6l2 2" stroke="#1a6fd0" stroke-width="1.6"/></svg>',
    prt: '<svg viewBox="0 0 16 16"><rect x="4" y="1.5" width="8" height="4" fill="#fff" stroke="#555"/><rect x="1.5" y="5.5" width="13" height="6" rx="1" fill="#e6edf7" stroke="#555"/><rect x="4" y="9.5" width="8" height="5" fill="#fff" stroke="#555"/></svg>',
    bc: '<svg viewBox="0 0 16 16"><path d="M2 3v10M4 3v10M5.5 3v10M8 3v10M10 3v10M11.5 3v10M14 3v10" stroke="#333" stroke-width="1.1"/></svg>',
    xls: '<svg viewBox="0 0 16 16"><rect x="1.5" y="1.5" width="13" height="13" rx="1.5" fill="#1d7a3f"/><path d="M5 4.5l6 7M11 4.5l-6 7" stroke="#fff" stroke-width="1.6"/></svg>',
    pdf: '<svg viewBox="0 0 16 16"><path d="M3 1.5h7l3 3v10H3z" fill="#e2483d"/><path d="M5 10h6M5 12h4" stroke="#fff" stroke-width="1.2"/></svg>',
    doc: '<svg viewBox="0 0 16 16"><rect x="1.5" y="1.5" width="13" height="13" rx="1.5" fill="#2b5fb8"/><path d="M4 5l1.2 6L8 6l2.8 5L12 5" fill="none" stroke="#fff" stroke-width="1.3"/></svg>',
    html: '<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6.5" fill="#fff" stroke="#e8a317" stroke-width="1.6"/><circle cx="8" cy="8" r="3" fill="#2f86e8"/></svg>',
    csv: '<svg viewBox="0 0 16 16"><path d="M3 1.5h7l3 3v10H3z" fill="#fff" stroke="#555"/><path d="M5 7h6M5 9.5h6M5 12h6" stroke="#1d7a3f"/></svg>',
    up: '<svg viewBox="0 0 16 16"><rect x="1.5" y="1.5" width="13" height="13" rx="1.5" fill="#1d7a3f"/><path d="M8 12V5M5 7.5L8 4.5l3 3" fill="none" stroke="#fff" stroke-width="1.6"/></svg>',
    x: '<svg viewBox="0 0 14 14"><path d="M3 3l8 8M11 3l-8 8" stroke="#d33" stroke-width="2"/></svg>',
    disk: '<svg viewBox="0 0 16 16"><rect x="2" y="2" width="12" height="12" rx="1.5" fill="#8e5bd0"/><rect x="4.5" y="2" width="7" height="4.5" fill="#fff"/><rect x="4" y="9" width="8" height="5" rx=".6" fill="#e9dcfb"/></svg>',
    pen: '<svg viewBox="0 0 16 16"><path d="M3 13l.8-3.2L10.5 3l2.5 2.5-6.8 6.7z" fill="#2f6fb5"/></svg>',
    fit: '<svg viewBox="0 0 16 16"><rect x="1.5" y="2.5" width="13" height="11" rx="1" fill="#fff" stroke="#555"/><rect x="4" y="5" width="8" height="6" fill="#555"/></svg>',
    props: '<svg viewBox="0 0 16 16"><path d="M8 1.5v13M3 4.5h10M5 8h6M3 11.5h10" stroke="#555" stroke-width="1.3"/></svg>',
    plus: '<svg viewBox="0 0 16 16"><rect x="2" y="2" width="12" height="12" fill="#fff" stroke="#555"/><path d="M8 5v6M5 8h6" stroke="#555" stroke-width="1.5"/></svg>',
    mv: '<svg viewBox="0 0 16 16"><path d="M2 13h12M4 13V8M7 13V4M10 13V7M13 13V5" stroke="#1a6fd0" stroke-width="1.8"/></svg>'
  };
  /* ================= طريقة العرض / التصاميم (DEXEF CtlTopGridDesign + FrmEditReportDesign) ================= */
  let USER = "Admin";
  function loadUser() { if (!HOST() || !Anouer.authMe) return; Promise.resolve(Anouer.authMe()).then(u => { const n = u && (u.username || u.Username || u.name || u.Name); if (n) { USER = String(n); paintHead(); } }).catch(() => { }); }
  const DS = () => lsGet("irev.designs", {});
  const saveDS = d => lsSet("irev.designs", d);
  const designs = m => { const d = DS(); return d[m || MODE] || []; };
  const curId = () => (lsGet("irev.dcur", {})[MODE]) || "";
  function setCur(id) { const c = lsGet("irev.dcur", {}); c[MODE] = id; lsSet("irev.dcur", c); }
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
  const snap = () => JSON.parse(JSON.stringify(LAY()));
  function seedDesigns() {
    const d = DS(); let ch = false;
    MODES.forEach(([m]) => { if (!d[m] || !d[m].length) { d[m] = [{ id: uid(), name: m === "units" ? "الخمسية" : "افتراضي", lay: JSON.parse(JSON.stringify(LAY(m))), def: true, at: today() }]; ch = true; } });
    if (ch) saveDS(d);
  }
  function defOf(m) { const u = lsGet("irev.udef", {}); const id = (u[USER] || {})[m || MODE]; const l = designs(m); return l.find(x => x.id === id) || l.find(x => x.def) || null; }
  function applyDesign(d, quiet) {
    if (!d) return;
    const all = lsGet("irev.lay", {}); all[MODE] = JSON.parse(JSON.stringify(d.lay)); lsSet("irev.lay", all);
    setCur(d.id); DIRTY = false;
    applyLayout();
    if (d.q != null && EL) { const i = EL.querySelector(".rv-search input"); if (i) { i.value = d.q; i.dispatchEvent(new Event("input")); } }
    if (!quiet) say("التصميم: " + d.name, "i");
  }
  let UDEF_DONE = {};
  function applyUserDefault() { seedDesigns(); if (UDEF_DONE[MODE]) { paintHead(); return; } UDEF_DONE[MODE] = 1; const d = defOf(); if (d && !curId()) applyDesign(d, true); else paintHead(); }
  const isDirty = () => { const d = designs().find(x => x.id === curId()); return !d || JSON.stringify(d.lay) !== JSON.stringify(LAY()); };

  /* شريط الرأس: «طريقة العرض» بجانب البحث + مربع التصاميم (الخمسية ⋯ ✓) */
  function buildHead(el) {
    const hd = el.querySelector(".rv-hd"); if (!hd) return;
    const lbl = hd.querySelector(".rv-lbl"), dd = hd.querySelector(".rv-dd");
    if (lbl) { const b = document.createElement("button"); b.type = "button"; b.className = "irv-mode"; b.title = "طريقة العرض (عام / شجري / وحدات القياس / الملابس و الأحذية)"; lbl.replaceWith(b); b.onclick = () => modeMenu(b); }
    if (dd) {
      dd.classList.add("ird"); dd.innerHTML = `<span class="lb" data-d="list" title="التصميم الحالي — اختر تصميماً"></span><span class="dots" data-d="mgr" title="التصميمات (إدارة)">⋯</span><span class="ck" data-d="def" title="جعل هذا التصميم هو الافتراضي">✓</span><span class="chev" data-d="list">⌄</span>`;
      dd.addEventListener("click", e => { const k = (e.target.closest("[data-d]") || {}).dataset; if (!k) return; if (k.d === "list") designMenu(dd); else if (k.d === "mgr") manager(); else if (k.d === "def") setDefault(); });
    }
    const s = hd.querySelector(".rv-search");
    if (s && !s.querySelector(".irf-n")) { s.insertAdjacentHTML("beforeend", '<em class="irf-n" hidden></em><b class="irf-x" hidden title="مسح البحث (Esc)">✕</b>'); s.title = 'البحث بجزء من الكلمة في كل الأعمدة — عدة كلمات = كلها • "عبارة" • -كلمة للاستبعاد • العمود:قيمة (مثال الكود:613) • Ctrl+F'; }
  }
  function paintHead() {
    if (!EL) return;
    const b = EL.querySelector(".irv-mode"); if (b) b.innerHTML = `${MODE_IC[MODE]}<span>${esc(modeName())}</span><i>⌄</i>`;
    const lb = EL.querySelector(".ird .lb"); if (lb) { const d = designs().find(x => x.id === curId()); lb.textContent = (d ? d.name : "بدون تصميم") + (d && isDirty() ? " *" : ""); lb.title = d ? "التصميم: " + d.name + (isDirty() ? " — توجد تغييرات غير محفوظة (Ctrl+S)" : "") : "اختر تصميماً"; }
    const df = defOf(), ck = EL.querySelector(".ird .ck"); if (ck) ck.classList.toggle("on", !!(df && df.id === curId()));
    EL.classList.toggle("irx-nof", !SET().filterRow); EL.classList.toggle("irx-notot", !SET().tot);
    EL.dataset.irmode = MODE;
  }
  function modeMenu(b) { menu(b, MODES.map(([m, t, d]) => ({ t: t, ic: MODE_IC[m], kb: m === MODE ? "✓" : "", tip: d, f: () => switchMode(m) }))); }
  function switchMode(m) {
    if (m === MODE) return;
    MODE = m; lsSet("irev.mode", m);
    if (IRS) { IRS.sel = 0; IRS.ms = null; IRS.sort = null; }
    if (m === "tree") loadGroups();
    const d = !UDEF_DONE[m] ? defOf(m) : null; UDEF_DONE[m] = 1;
    if (d && !curId()) applyDesign(d, true); else applyLayout();
    say("طريقة العرض: " + modeName(), "i");
  }
  function designMenu(anchor) {
    const l = designs(), c = curId(), df = defOf();
    menu(anchor, l.map(d => ({ t: d.name, kb: (d.id === c ? "✓ " : "") + (df && df.id === d.id ? "★" : ""), f: () => applyDesign(d) }))
      .concat(["-", { t: "حفظ التصميم الحالي", ic: IC.ok, kb: "Ctrl+S", f: saveDlg }, { t: "تصميم جديد", ic: IC.add, f: () => newDesign() }, { t: "إدارة التصاميم…", ic: IC.list, f: manager }]));
  }
  function setDefault() {
    const id = curId(); if (!id) { say("اختر تصميماً أولاً", "w"); return; }
    const u = lsGet("irev.udef", {}); u[USER] = u[USER] || {}; u[USER][MODE] = id; lsSet("irev.udef", u);
    const d = DS(); (d[MODE] || []).forEach(x => { x.def = x.id === id; }); saveDS(d);
    paintHead(); say("✔ أصبح «" + (designs().find(x => x.id === id) || {}).name + "» التصميم الافتراضي لـ «" + modeName() + "»", "s");
  }
  function newDesign(name, keepQ) {
    const go = n => { n = (n || "").trim(); if (!n) return; const d = DS(); d[MODE] = d[MODE] || []; if (d[MODE].some(x => x.name === n)) { say("يوجد تصميم بنفس الاسم", "w"); return; }
      const it = { id: uid(), name: n, lay: snap(), def: false, at: today() }; if (keepQ) it.q = curQ(); d[MODE].push(it); saveDS(d); setCur(it.id); DIRTY = false; paintHead(); say("✔ تم حفظ التصميم «" + n + "»", "s"); };
    if (name) { go(name); return; }
    const w = win("تصميم جديد", `<div class="ird-f"><label>اسم التصميم<input class="nm" value="${esc("تصميم " + (designs().length + 1))}"></label><label class="ck"><input type="checkbox" class="kq"> الحفظ مع الإحتفاظ بفلتر البحث</label></div>`, [["حفظ", "ok", "ok"], ["إلغاء", "x"]]);
    const nm = w.el.querySelector(".nm"); setTimeout(() => { nm.focus(); nm.select(); }, 30);
    nm.addEventListener("keydown", e => { if (e.key === "Enter") w.el.querySelector('[data-x="ok"]').click(); });
    w.on("ok", () => { newDesign(nm.value, w.el.querySelector(".kq").checked); });
  }
  const curQ = () => { const i = EL && EL.querySelector(".rv-search input"); return i ? i.value : ""; };
  /* Ctrl+S / «حفظ التصميم» — مثل DEXEF FrmDesignSaveLayout */
  function saveDlg() {
    const d = designs().find(x => x.id === curId());
    if (!d) { newDesign(); return; }
    const w = win("حفظ التصميم", `<div class="ird-f"><div class="q">حدثت تغييرات على طريقة العرض الحالية ؟</div><div class="note">التصميم: <b>${esc(d.name)}</b> — ${esc(modeName())}</div><label class="ck"><input type="checkbox" class="kq"${d.q ? " checked" : ""}> الحفظ مع الإحتفاظ بفلتر البحث</label></div>`, [["حفظ", "save", "ok"], ["تصميم جديد", "new"], ["إلغاء", "x"]]);
    w.on("save", () => { const all = DS(); const it = (all[MODE] || []).find(x => x.id === d.id); if (it) { it.lay = snap(); it.at = today(); if (w.el.querySelector(".kq").checked) it.q = curQ(); else delete it.q; saveDS(all); } DIRTY = false; paintHead(); say("✔ تم حفظ التصميم «" + d.name + "»", "s"); });
    w.on("new", () => { const k = w.el.querySelector(".kq").checked; setTimeout(() => newDesign(null, k), 0); });
  }
  /* «⋯» — التصميمات / المستخدمين (مطابقة DEXEF FrmEditReportDesign + CtlDesignUserPermission)
     • بدون شريط عنوان: ✕ أعلى اليسار ، زرّا التبويب أعلى اليمين ، تذييل رمادي وزر «إغلاق» أزرق
     • جدول التصميمات: التصميم · حذف · حفظ · تعديل · افتراضي + سطر بحث (ABC / = / ☐)
     • المستخدمين: صورة توضيحية + «الإسناد إلى المستخدمين» + جدول (☐ تحديد الكل · الاسم) + سطر بحث
       يُسند التصميم المحدد (←) في تبويب التصميمات إلى المستخدمين المؤشَّر عليهم (يُفتح لهم تلقائياً) */
  const ILLU = `<svg viewBox="0 0 280 200" aria-hidden="true">
    <ellipse cx="146" cy="178" rx="128" ry="17" fill="#eef1f5"/>
    <rect x="22" y="14" width="168" height="108" rx="5" fill="#d9e9fa" stroke="#a9cdf2" stroke-width="2"/>
    <rect x="22" y="14" width="168" height="12" rx="5" fill="#a9cdf2"/><circle cx="31" cy="20" r="2.2" fill="#fff"/><circle cx="38" cy="20" r="2.2" fill="#fff"/>
    <rect x="34" y="36" width="40" height="40" rx="4" fill="#fff"/><circle cx="54" cy="51" r="8" fill="#8fbdee"/><path d="M41 72c3-9 23-9 26 0z" fill="#8fbdee"/>
    <rect x="34" y="84" width="40" height="5" rx="2.5" fill="#bcd8f6"/><rect x="34" y="94" width="28" height="5" rx="2.5" fill="#bcd8f6"/>
    <rect x="86" y="36" width="92" height="7" rx="3.5" fill="#bcd8f6"/><rect x="86" y="49" width="70" height="7" rx="3.5" fill="#bcd8f6"/>
    <rect x="86" y="66" width="92" height="44" rx="4" fill="#fff"/><rect x="94" y="92" width="10" height="12" fill="#8fbdee"/><rect x="109" y="84" width="10" height="20" fill="#5b9ae6"/><rect x="124" y="77" width="10" height="27" fill="#8fbdee"/><rect x="139" y="88" width="10" height="16" fill="#5b9ae6"/><rect x="154" y="72" width="10" height="32" fill="#2f6fb5"/>
    <rect x="212" y="20" width="34" height="24" rx="2" fill="#fff" stroke="#c9d6e4" stroke-width="2"/><path d="M217 39l8-8 6 5 5-4 6 7" fill="none" stroke="#a9cdf2" stroke-width="2"/>
    <rect x="216" y="52" width="26" height="18" rx="2" fill="#fff" stroke="#c9d6e4" stroke-width="2"/><path d="M220 64h18M220 59h12" stroke="#a9cdf2" stroke-width="2"/>
    <path d="M70 128h138" stroke="#3d4652" stroke-width="7" stroke-linecap="round"/><path d="M82 131l-10 44M196 131l10 44" stroke="#3d4652" stroke-width="4" stroke-linecap="round"/>
    <path d="M120 126l6-16h34l-4 16z" fill="#b8c7d8"/><path d="M124 126h40" stroke="#94a6ba" stroke-width="3" stroke-linecap="round"/>
    <rect x="206" y="88" width="30" height="46" rx="9" fill="#5b8fd6"/><path d="M196 134h38" stroke="#4a7bc0" stroke-width="7" stroke-linecap="round"/>
    <path d="M216 138v20M202 162h28" stroke="#3d4652" stroke-width="3" stroke-linecap="round"/><circle cx="202" cy="166" r="3" fill="#3d4652"/><circle cx="230" cy="166" r="3" fill="#3d4652"/>
    <path d="M196 132c-6 0-12 2-16 6l-12 14" fill="none" stroke="#27374f" stroke-width="9" stroke-linecap="round"/><path d="M168 152l-2 18" stroke="#27374f" stroke-width="8" stroke-linecap="round"/>
    <path d="M160 170h14" stroke="#f0f0f0" stroke-width="6" stroke-linecap="round"/><path d="M160 172h14" stroke="#c9d6e4" stroke-width="2"/>
    <path d="M188 92c-10 0-16 10-16 22v18h28v-22c0-10-4-18-12-18z" fill="#fff" stroke="#c9d6e4" stroke-width="1.5"/>
    <path d="M180 106c-6 6-16 10-26 12" fill="none" stroke="#f2c7a5" stroke-width="6" stroke-linecap="round"/><path d="M180 106c-6 6-16 10-26 12" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-dasharray="14 40"/>
    <circle cx="190" cy="74" r="11" fill="#f2c7a5"/><path d="M179 72c0-9 7-13 13-12 7 1 10 6 9 12-3-4-8-5-12-4-4 1-7 3-10 4z" fill="#2b2d3a"/>
    <path d="M44 176c-2-12 0-20 6-20s8 8 6 20z" fill="#d7dee8"/>
    <path d="M50 158c-12-6-16-18-12-24 7 4 11 13 12 24zM50 158c2-14 9-22 15-21 0 9-6 17-15 21zM50 160c-7-14-6-28 0-33 4 8 4 20 0 33z" fill="#9cc6ee"/>
  </svg>`;
  const DX_X = '<svg viewBox="0 0 14 14"><path d="M2 2l10 10M12 2L2 12" stroke="#555" stroke-width="1.3"/></svg>';
  const FUNNEL = '<svg viewBox="0 0 12 12" width="11" height="11"><path d="M1 1.5h10L7 6.5V11L5 10V6.5z" fill="#8a94a0"/></svg>';
  const ABC = '<span class="abc">A<b>B</b>C</span>';
  function askDx(msg, yes) {
    /* نافذة التأكيد فوق نافذة التصاميم ثم تعود لمستواها */
    const cf = document.getElementById("cfOv");
    if (cf) { cf.style.zIndex = "1800"; const mo = new MutationObserver(() => { if (!cf.classList.contains("show")) { cf.style.zIndex = ""; mo.disconnect(); } }); mo.observe(cf, { attributes: true, attributeFilter: ["class"] }); }
    try { askConfirm(msg, yes); try { if (typeof EditSound !== "undefined") EditSound.play(); } catch (e) { } } catch (e) { if (confirm(msg)) yes(); } }
  function manager(startTab) {
    const ov = document.createElement("div"); ov.className = "irw-ov dxm-ov";
    ov.innerHTML = `<div class="dxm" role="dialog" aria-label="التصميمات — ${esc(modeName())}">
      <button type="button" class="dxm-x" title="إغلاق (Esc)">${DX_X}</button>
      <div class="dxm-tabs"><button type="button" data-t="d">التصميمات</button><button type="button" data-t="u">المستخدمين</button></div>
      <div class="dxm-b"></div>
      <div class="dxm-f"><button type="button" class="dxm-io" data-io="exp" title="حفظ كل التصاميم والأعمدة المحسوبة في ملف لنقلها لجهاز آخر">تصدير التصاميم</button><button type="button" class="dxm-io" data-io="imp" title="استيراد تصاميم من ملف">استيراد</button><span class="sp"></span><button type="button" class="dxm-close">إغلاق</button></div></div>`;
    document.body.appendChild(ov);
    const body = ov.querySelector(".dxm-b"), q = { d: "", def: null, u: "" };
    let tab = startTab || "d", edit = null, sel = curId() || (designs()[0] || {}).id, usel = null;
    const close = () => { ov.remove(); keyPop(key); paintHead(); };
    const selD = () => designs().find(x => x.id === sel) || designs()[0];
    const draw = (keepFocus) => {
      const fk = keepFocus && document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.q : null;
      ov.querySelectorAll(".dxm-tabs [data-t]").forEach(b => b.classList.toggle("on", b.dataset.t === tab));
      const l = designs(), df = defOf();
      if (tab === "d") {
        const rows = l.filter(d => (!q.d || AN(d.name).includes(AN(q.d))) && (q.def == null || (df && df.id === d.id) === q.def));
        body.innerHTML = `<div class="dxg dxg-d"><div class="dxr dxh"><div></div><div>التصميم</div><div>حذف</div><div>حفظ</div><div>تعديل</div><div title="افتراضي">افتراض…</div></div>
          <div class="dxr dxf"><div>${FUNNEL}</div><div class="fi"><input data-q="d" value="${esc(q.d)}" autocomplete="off">${ABC}</div><div>=</div><div>=</div><div>=</div><div><input type="checkbox" data-q="def"${q.def ? " checked" : ""}></div></div>
          ${rows.map(d => `<div class="dxr dxd${d.id === sel ? " sel" : ""}" data-id="${d.id}" title="${esc(d.name + " — " + (d.at || "") + " — " + (d.lay && d.lay.cols ? d.lay.cols.length : 0) + " عمود" + (d.q ? " — مع فلتر البحث" : "") + (d.id === curId() ? " — المطبّق الآن" : "") + "\nنقرتان للتطبيق")}">
            <div class="ind">${d.id === sel ? "←" : ""}</div>
            <div class="nm">${edit === d.id ? `<input class="ren" value="${esc(d.name)}">` : esc(d.name) + (d.id === curId() ? ' <i class="on" title="التصميم المطبّق الآن">●</i>' : "")}</div>
            <div><button type="button" data-a="del" title="حذف">${IC.x}</button></div><div><button type="button" data-a="save" title="حفظ العرض الحالي في هذا التصميم">${IC.disk}</button></div>
            <div><button type="button" data-a="edit" title="تعديل الاسم (F2)">${IC.pen}</button></div><div><input type="checkbox" data-a="def"${df && df.id === d.id ? " checked" : ""} title="التصميم الافتراضي"></div></div>`).join("")}
          ${rows.length ? "" : '<div class="dxe">لا توجد سجلات مطابقة</div>'}</div>`;
        const ph = body.querySelector('[data-q="def"]'); if (ph && q.def == null) ph.indeterminate = true;
        const ren = body.querySelector(".ren"); if (ren) { ren.focus(); ren.select(); const ok = () => { if (!edit) return; const v = ren.value.trim(); const id = edit; edit = null; if (v) { const all = DS(); const it = (all[MODE] || []).find(x => x.id === id); if (it) it.name = v; saveDS(all); } draw(); paintHead(); }; ren.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); ok(); } else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); edit = null; draw(); } }); ren.addEventListener("blur", ok); }
      } else {
        const d = selD();
        body.innerHTML = `<div class="dxu-top"><div class="dxu-t"><b>الإسناد إلى المستخدمين</b><span>الإسناد إلى المستخدمين</span><em>${d ? "التصميم: «" + esc(d.name) + "» — " + esc(modeName()) : ""}</em></div><div class="dxu-img">${ILLU}</div></div>
          <div class="dxg dxg-u"><div class="note">جاري تحميل المستخدمين…</div></div>`;
        users().then(us => {
          if (tab !== "u") return;
          const u = lsGet("irev.udef", {}), on = n => !!(d && (u[n] || {})[MODE] === d.id);
          const rows = us.filter(n => !q.u || AN(n).includes(AN(q.u))), all = rows.length && rows.every(on), some = rows.some(on);
          if (usel == null || !rows.includes(usel)) usel = rows[0] || null;   // مثل DEXEF: المؤشر على أول سطر
          body.querySelector(".dxg-u").innerHTML = `<div class="dxr dxh"><div></div><div><input type="checkbox" data-a="all"${all ? " checked" : ""} title="تحديد الكل"></div><div>الاسم</div></div>
            <div class="dxr dxf"><div>${FUNNEL}</div><div></div><div class="fi"><input data-q="u" value="${esc(q.u)}" autocomplete="off">${ABC}</div></div>
            ${rows.map(n => `<div class="dxr dxd${n === usel ? " sel" : ""}" data-u="${esc(n)}"><div class="ind">${n === usel ? "←" : ""}</div><div><input type="checkbox" data-a="as"${on(n) ? " checked" : ""}></div><div class="nm">${esc(n)}${n === USER ? ' <small>(أنت)</small>' : ""}</div></div>`).join("")}
            ${rows.length ? "" : '<div class="dxe">لا توجد سجلات مطابقة</div>'}`;
          const ac = body.querySelector('[data-a="all"]'); if (ac && some && !all) ac.indeterminate = true;
          if (fk) { const i = body.querySelector(`[data-q="${fk}"]`); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }
        });
      }
      if (fk) { const i = body.querySelector(`[data-q="${fk}"]`); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }
    };
    const setUser = (n, v) => { const d = selD(); if (!d) return; const u = lsGet("irev.udef", {}); u[n] = u[n] || {}; if (v) u[n][MODE] = d.id; else if (u[n][MODE] === d.id) delete u[n][MODE]; lsSet("irev.udef", u); };
    const delD = id => { const all = DS(), l = all[MODE] || [], it = l.find(x => x.id === id); if (!it) return; if (l.length <= 1) { say("لا يمكن حذف التصميم الوحيد", "w"); return; }
      askDx("هل تريد حذف التصميم «" + it.name + "» ؟", () => { all[MODE] = l.filter(x => x.id !== id); if (it.def && all[MODE][0]) all[MODE][0].def = true; saveDS(all);
        const u = lsGet("irev.udef", {}); Object.keys(u).forEach(n => { if (u[n] && u[n][MODE] === id) delete u[n][MODE]; }); lsSet("irev.udef", u);
        if (curId() === id) setCur(all[MODE][0] ? all[MODE][0].id : ""); if (sel === id) sel = (all[MODE][0] || {}).id; draw(); paintHead(); try { window.DelSound && DelSound.play(); } catch (e) { } say("تم حذف التصميم", "s"); }); };
    ov.querySelector(".dxm-tabs").addEventListener("click", e => { const b = e.target.closest("[data-t]"); if (!b || b.dataset.t === tab) return; tab = b.dataset.t; edit = null; draw(); });
    ov.querySelector(".dxm-x").onclick = close; ov.querySelector(".dxm-close").onclick = close;
    ov.querySelector(".dxm-f").addEventListener("click", e => { const b = e.target.closest("[data-io]"); if (!b) return;
      if (b.dataset.io === "exp") { dl(new Blob([JSON.stringify({ anouer: "irev.designs", v: 1, designs: DS(), calc: CALC(), udef: lsGet("irev.udef", {}) }, null, 1)], { type: "application/json" }), "تصاميم مراجعة الأصناف.json"); say("✔ تم تصدير التصاميم", "s"); return; }
      const i = document.createElement("input"); i.type = "file"; i.accept = ".json"; i.onchange = () => { const f = i.files && i.files[0]; if (!f) return; f.text().then(s => { const j = JSON.parse(s); if (!j || !j.designs) throw new Error("ملف غير صالح"); const d = DS(); let n = 0; Object.keys(j.designs).forEach(m => { d[m] = d[m] || []; (j.designs[m] || []).forEach(x => { if (!d[m].some(y => y.id === x.id)) { d[m].push(Object.assign({}, x, { def: false })); n++; } }); }); saveDS(d); if (Array.isArray(j.calc)) { const c = CALC(); j.calc.forEach(x => { if (!c.some(y => y.id === x.id)) c.push(x); }); lsSet("irev.calc", c); } draw(); say("✔ تم استيراد " + n + " تصميم", "s"); }).catch(e => say("تعذّر الاستيراد: " + (e.message || e), "e")); }; i.click(); });
    body.addEventListener("input", e => { const k = e.target.dataset.q; if (k === "d" || k === "u") { q[k] = e.target.value; draw(true); } });
    body.addEventListener("click", e => {
      const ph = e.target.closest('[data-q="def"]');
      if (ph) { e.preventDefault(); q.def = q.def == null ? true : q.def ? false : null; draw(); return; }   // ☐ ← ✔ ← ■ (الكل)
      if (e.target.closest('[data-a="all"]')) { const v = e.target.checked; users().then(us => { us.filter(n => !q.u || AN(n).includes(AN(q.u))).forEach(n => setUser(n, v)); draw(); paintHead(); say(v ? "✔ أُسند التصميم «" + (selD() || {}).name + "» لكل المستخدمين" : "أُلغي الإسناد", "s"); }); return; }
      const r = e.target.closest(".dxd"); if (!r) return;
      if (r.dataset.u != null) { usel = r.dataset.u; const c = e.target.closest('[data-a="as"]'); if (c) { setUser(usel, c.checked); paintHead(); say(c.checked ? "✔ أُسند «" + (selD() || {}).name + "» إلى " + usel : "أُلغي الإسناد عن " + usel, "s"); } draw(); return; }
      const id = r.dataset.id, a = e.target.closest("[data-a]"); sel = id;
      if (!a) { if (!edit) draw(); return; }
      const all = DS(), it = (all[MODE] || []).find(x => x.id === id); if (!it) return;
      if (a.dataset.a === "del") delD(id);
      else if (a.dataset.a === "save") { it.lay = snap(); it.at = today(); saveDS(all); if (curId() === id) DIRTY = false; draw(); paintHead(); say("✔ حُفظ العرض الحالي في «" + it.name + "»", "s"); }
      else if (a.dataset.a === "edit") { edit = id; draw(); }
      else if (a.dataset.a === "def") { (all[MODE] || []).forEach(x => { x.def = a.checked && x.id === id; }); saveDS(all); const u = lsGet("irev.udef", {}); if (u[USER]) { delete u[USER][MODE]; lsSet("irev.udef", u); } draw(); paintHead(); if (a.checked) say("✔ «" + it.name + "» هو التصميم الافتراضي", "s"); }
    });
    body.addEventListener("dblclick", e => { const r = e.target.closest(".dxd[data-id]"); if (!r || e.target.closest("button,input")) return; const it = designs().find(x => x.id === r.dataset.id); if (it) { applyDesign(it); sel = it.id; draw(); } });
    const key = e => {
      if (e.key === "Escape") { if (edit) return false; e.preventDefault(); close(); return true; }
      if (e.target.tagName === "INPUT" && !e.target.dataset.a) return false;
      const l = tab === "d" ? designs().map(x => x.id) : null;
      if (tab === "d" && (e.key === "ArrowDown" || e.key === "ArrowUp")) { e.preventDefault(); let k = l.indexOf(sel) + (e.key === "ArrowDown" ? 1 : -1); k = Math.max(0, Math.min(l.length - 1, k)); sel = l[k]; draw(); return true; }
      if (tab === "d" && e.key === "Enter") { e.preventDefault(); const it = selD(); if (it) { applyDesign(it); draw(); } return true; }
      if (tab === "d" && e.key === "F2") { e.preventDefault(); edit = sel; draw(); return true; }
      if (tab === "d" && e.key === "Delete") { e.preventDefault(); delD(sel); return true; }
      return false;
    };
    keyPush(key);
    draw();
  }
  function users() {
    if (!HOST() || !Anouer.usersList) return Promise.resolve([USER]);
    return Promise.resolve(Anouer.usersList()).then(l => { const n = (l || []).map(u => u.Username || u.username || u.Name || u.name).filter(Boolean); if (!n.includes(USER)) n.unshift(USER); return n; }).catch(() => [USER]);
  }

  /* ---------------- خصائص التصميم (FrmGridDesignSettings: عام / الخط و الألوان) ---------------- */
  const FONTS = ["", "Droid Arabic Kufi", "Segoe UI", "Tahoma", "Arial", "Cairo", "Times New Roman"];
  const DFMTS = ["yyyy-MM-dd HH:mm", "yyyy-MM-dd", "dd/MM/yyyy", "dd/MM/yyyy HH:mm", "MM/dd/yyyy"];
  function settingsDlg() {
    const L = LAY(), s0 = JSON.parse(JSON.stringify(L.set)), s = L.set;
    const ck = (k, t) => `<label class="sw-r"><span>${t}</span><input type="checkbox" data-k="${k}"${s[k] ? " checked" : ""}><i class="sw"></i></label>`;
    const clr = (k, t) => `<label class="cl-r"><span>${t}</span><input type="color" data-k="${k}" value="${esc(s[k] || "#ffffff")}"></label>`;
    const w = win("خصائص التصميم — " + modeName(), `<div class="ird-tabs"><button type="button" class="on" data-t="g">عام</button><button type="button" data-t="f">الخط و الألوان</button></div>
      <div class="irs" data-p="g">
        ${ck("fit", "جعل الأعمدة بملأ الشاشة")}${ck("filterRow", "ظهور سطر البحث")}${ck("tot", "ظهور سطر الإجمالي")}${ck("colMenu", "ظهور قائمة ضبط الأعمدة")}
        <label class="sl-r"><span>تقريب الأرقام الى أقرب</span><select data-k="dec">${[0, 1, 2, 3, 4].map(n => `<option value="${n}"${+s.dec === n ? " selected" : ""}>${n ? (1 / Math.pow(10, n)).toFixed(n) : "عدد صحيح"}</option>`).join("")}</select></label>
        <label class="sl-r"><span>تنسيق التاريخ</span><select data-k="dfmt">${DFMTS.map(f => `<option${s.dfmt === f ? " selected" : ""}>${f}</option>`).join("")}</select></label>
        <label class="sl-r"><span>كثافة الأسطر</span><select data-k="density"><option value=""${!s.density ? " selected" : ""}>عادي</option><option value="rv-compact"${s.density === "rv-compact" ? " selected" : ""}>مضغوط</option><option value="rv-wide"${s.density === "rv-wide" ? " selected" : ""}>موسّع</option></select></label>
        <label class="sl-r"><span>العنوان (الطباعة والتصدير)</span><input data-k="title" value="${esc(s.title || "")}"></label>
      </div>
      <div class="irs" data-p="f" hidden>
        <fieldset><legend>تنسيق السطر</legend><label class="sl-r"><span>الخط</span><select data-k="font">${FONTS.map(f => `<option value="${esc(f)}"${s.font === f ? " selected" : ""}>${f || "الافتراضي"}</option>`).join("")}</select></label>
          <label class="sl-r"><span>الحجم</span><input type="number" min="9" max="22" data-k="fsize" value="${+s.fsize || 14}"></label>${ck("bold", "عريض")}${ck("italic", "مائل")}${clr("fg", "لون الخط")}${clr("bg", "لون الخلفية")}</fieldset>
        <fieldset><legend>الأسطر الفردية</legend>${ck("oddUse", "استخدام")}${clr("oddBg", "لون الخلفية")}${clr("oddFg", "لون الخط")}</fieldset>
        <fieldset><legend>الأسطر الزوجية</legend>${ck("evenUse", "استخدام")}${clr("evenBg", "لون الخلفيه")}${clr("evenFg", "لون الخط")}</fieldset>
        <fieldset><legend>الخطوط الرأسية</legend>${ck("vUse", "استخدام")}${clr("vColor", "اللون")}</fieldset>
        <fieldset><legend>الخطوط الأفقية</legend>${ck("hUse", "استخدام")}${clr("hColor", "اللون")}</fieldset>
      </div>`, [["حفظ", "ok", "ok"], ["الافتراضي", "rs"], ["إلغاء", "cancel"]]);
    w.el.querySelector(".irw").classList.add("irw-s");
    w.el.querySelector(".ird-tabs").addEventListener("click", e => { const b = e.target.closest("[data-t]"); if (!b) return; w.el.querySelectorAll(".ird-tabs [data-t]").forEach(x => x.classList.toggle("on", x === b)); w.el.querySelectorAll(".irs").forEach(p => { p.hidden = p.dataset.p !== b.dataset.t; }); });
    const live = e => { const i = e && e.target; if (!i || !i.dataset || !i.dataset.k) return; const k = i.dataset.k; s[k] = i.type === "checkbox" ? i.checked : i.type === "number" || k === "dec" ? +i.value : i.value; L.set = s; saveLay(L); applyLayout(); };
    w.el.addEventListener("input", live); w.el.addEventListener("change", live);
    w.on("ok", () => { say("✔ تم حفظ خصائص التصميم", "s"); });
    w.on("rs", () => { L.set = Object.assign({}, DEF_SET); saveLay(L); applyLayout(); say("تمت استعادة الخصائص الافتراضية", "i"); });
    w.on("cancel", () => { L.set = s0; saveLay(L); applyLayout(); });
  }
  let STY = null;
  function applyStyle() {
    if (!STY) { STY = document.createElement("style"); STY.id = "irxStyle"; document.head.appendChild(STY); }
    const s = SET(), R = "#vIRev.irx .rv-d";
    let c = "";
    if (s.font || s.fsize !== 14 || s.bold || s.italic || s.fg) c += `${R},${R}>div.tr{${s.font ? `font-family:"${s.font}",Tahoma,sans-serif!important;` : ""}font-size:${+s.fsize || 14}px!important;${s.bold ? "font-weight:700;" : ""}${s.italic ? "font-style:italic;" : ""}${s.fg ? `color:${s.fg};` : ""}}`;
    if (s.bg && s.bg.toLowerCase() !== "#ffffff") c += `${R}{background:${s.bg}}`;
    if (s.oddUse) c += `${R}.iro{background:${s.oddBg}}${s.oddFg ? `${R}.iro{color:${s.oddFg}}` : ""}`;
    if (s.evenUse) c += `${R}.ire{background:${s.evenBg}}${s.evenFg ? `${R}.ire{color:${s.evenFg}}` : ""}`;
    c += s.vUse ? `${R}>div{border-left:1px solid ${s.vColor}}` : "";
    c += s.hUse ? `${R}{border-bottom:1px solid ${s.hColor}}` : `${R}{border-bottom-color:transparent}`;
    STY.textContent = c;
    DEC = Math.max(0, Math.min(4, +s.dec || 0)); if (s.dec == null) DEC = 2;
    paintHead();
  }

  /* ---------------- الأعمدة: ملأ الشاشة / الخصائص / اضافة عمود ---------------- */
  function fitScreen(silent) {
    const g = EL && EL.querySelector(".rv-grid"); if (!g) return;
    const ids = visIds(), avail0 = g.clientWidth - 46 - 40 - 8, base = ids.reduce((s, id) => s + (id === "name" ? 220 : parseInt((byId(id) || {}).w, 10) || 90), 0);
    const k = Math.max(.55, Math.min(2.4, avail0 / base)), L = LAY();
    ids.forEach(id => { if (id !== "name") L.w[id] = Math.round((parseInt((byId(id) || {}).w, 10) || 90) * k); });
    saveLay(L); if (IRS) IRS.setCols(cols()); if (!silent) say("تم ملء الشاشة", "i");
  }
  function colProps(focusId) {
    const L = LAY();
    const rows = () => visIds().map(id => { const c = byId(id); return `<tr data-id="${id}"><td class="h">⋮⋮</td><td><input type="checkbox" data-a="vis" checked${c.fix ? " disabled" : ""}></td><td><small>${esc(c.t)}</small></td><td><input class="cap" value="${esc(L.cap[id] || "")}" placeholder="${esc(c.t)}"></td><td><input class="wd" type="number" min="40" max="600" value="${L.w[id] || parseInt(c.w, 10) || ""}" placeholder="تلقائي"></td><td><button type="button" data-a="up" title="لأعلى">▲</button><button type="button" data-a="dn" title="لأسفل">▼</button></td></tr>`; }).join("");
    const w = win("خصائص الأعمدة — " + modeName(), `<div class="note">غيّر عناوين الأعمدة وعرضها وترتيبها — أو أخفِ العمود. اترك العنوان فارغاً لاستعمال اسم DEXEF الأصلي.</div><table class="ird-t irp"><thead><tr><th></th><th>ظاهر</th><th>العمود</th><th>العنوان</th><th>العرض (px)</th><th>الترتيب</th></tr></thead><tbody>${rows()}</tbody></table>`, [["حفظ", "ok", "ok"], ["إعادة الأصل", "rs"], ["إلغاء", "x"]]);
    const tb = w.el.querySelector("tbody");
    tb.addEventListener("click", e => { const b = e.target.closest("button[data-a]"); if (!b) return; const tr = b.closest("tr"); if (b.dataset.a === "up" && tr.previousElementSibling) tr.parentNode.insertBefore(tr, tr.previousElementSibling); if (b.dataset.a === "dn" && tr.nextElementSibling) tr.parentNode.insertBefore(tr.nextElementSibling, tr); });
    if (focusId) setTimeout(() => { const i = tb.querySelector(`tr[data-id="${focusId}"] .cap`); if (i) { i.focus(); i.closest("tr").classList.add("hl"); } }, 40);
    w.on("ok", () => { const ids = []; tb.querySelectorAll("tr").forEach(tr => { const id = tr.dataset.id; if (tr.querySelector('[data-a="vis"]').checked) ids.push(id); const cap = tr.querySelector(".cap").value.trim(); if (cap) L.cap[id] = cap; else delete L.cap[id]; const wd = +tr.querySelector(".wd").value; if (wd >= 40) L.w[id] = wd; else delete L.w[id]; }); L.cols = ids.concat(L.cols.filter(id => !ids.includes(id) && !visIds().includes(id))); saveLay(L); applyLayout(); say("✔ تم حفظ خصائص الأعمدة", "s"); });
    w.on("rs", () => { L.cap = {}; L.w = {}; saveLay(L); applyLayout(); say("تمت إعادة العناوين والعرض الأصلي", "i"); });
  }
  function addColumn(edit) {
    const numCols = ALL.filter(c => c.v && !c.h && c.id !== "pid" && !/^(lastIn|lastOut)$/.test(c.id));
    const cur = edit ? CALC().find(x => x.id === edit) : null;
    const w = win(cur ? "تعديل عمود محسوب" : "اضافة عمود", `<div class="irc2">
      <div class="ird-f"><label>اسم العمود<input class="nm" value="${esc(cur ? cur.t : "")}" placeholder="مثال: الربح"></label>
      <label>المعادلة<textarea class="ex" rows="2" placeholder="[سعر البيع]-[تكلفة الوحده]">${esc(cur ? cur.expr : "")}</textarea></label>
      <div class="chips">${numCols.map(c => `<button type="button" data-c="${esc(c.t)}">${esc(c.t)}</button>`).join("")}</div>
      <div class="chips ops">${["+", "-", "*", "/", "(", ")", "100"].map(o => `<button type="button" data-o="${o}">${o}</button>`).join("")}</div>
      <div class="tpls"><span>قوالب جاهزة:</span>${CALC_TPL.map((t, i) => `<button type="button" data-t="${i}">${esc(t[0])}</button>`).join("")}</div>
      <label class="ck"><input type="checkbox" class="sm"${cur && cur.sum ? " checked" : ""}> إظهار مجموعه في سطر الإجمالي</label>
      <div class="pv">المعاينة (السطر المحدد): <b>—</b></div></div>
      ${CALC().length ? `<table class="ird-t"><thead><tr><th>الأعمدة المحسوبة</th><th>المعادلة</th><th></th></tr></thead><tbody>${CALC().map(c => `<tr data-id="${c.id}"><td><b>${esc(c.t)}</b></td><td style="direction:ltr">${esc(c.expr)}</td><td><button type="button" data-e="edit">${IC.pen}</button><button type="button" data-e="del">${IC.x}</button></td></tr>`).join("")}</tbody></table>` : ""}</div>`, [[cur ? "حفظ" : "اضافة", "ok", "ok"], ["إغلاق", "x"]]);
    const nm = w.el.querySelector(".nm"), ex = w.el.querySelector(".ex"), pv = w.el.querySelector(".pv b");
    const ins = t => { const a = ex.selectionStart || ex.value.length; ex.value = ex.value.slice(0, a) + t + ex.value.slice(ex.selectionEnd || a); ex.focus(); ex.selectionStart = ex.selectionEnd = a + t.length; prev(); };
    const prev = () => { const fn = calcFn(ex.value), r = curRow(); pv.textContent = !ex.value.trim() ? "—" : !fn ? "معادلة غير صحيحة" : r && !r._grp ? F(fn(r)) : "اختر سطراً لمعاينة النتيجة"; pv.classList.toggle("bad", !!ex.value.trim() && !fn); };
    ex.addEventListener("input", prev); setTimeout(() => { nm.focus(); prev(); }, 30);
    w.el.addEventListener("click", e => {
      const c = e.target.closest("[data-c]"), o = e.target.closest("[data-o]"), t = e.target.closest("[data-t]"), ed = e.target.closest("[data-e]");
      if (c) ins("[" + c.dataset.c + "]"); else if (o) ins(o.dataset.o);
      else if (t) { const tp = CALC_TPL[+t.dataset.t]; nm.value = tp[0]; ex.value = tp[1]; prev(); }
      else if (ed) { const id = ed.closest("tr").dataset.id; if (ed.dataset.e === "del") { lsSet("irev.calc", CALC().filter(x => x.id !== id)); const L = LAY(); L.cols = L.cols.filter(x => x !== "x:" + id); saveLay(L); applyLayout(); w.close(); say("تم حذف العمود المحسوب", "i"); } else { w.close(); addColumn(id); } }
    });
    w.on("ok", () => {
      const n = nm.value.trim(), fn = calcFn(ex.value); if (!n) { say("أدخل اسم العمود", "w"); nm.focus(); return false; } if (!fn) { say("المعادلة غير صحيحة — استعمل أسماء الأعمدة بين [ ] والعمليات + - * / ( )", "w"); ex.focus(); return false; }
      const l = CALC(); if (cur) { Object.assign(l.find(x => x.id === cur.id), { t: n, expr: ex.value.trim(), sum: w.el.querySelector(".sm").checked }); lsSet("irev.calc", l); }
      else { const id = uid(); l.push({ id, t: n, expr: ex.value.trim(), sum: w.el.querySelector(".sm").checked, w: 110 }); lsSet("irev.calc", l); const L = LAY(); L.cols.push("x:" + id); saveLay(L); }
      applyLayout(); say("✔ " + (cur ? "تم تعديل" : "تمت إضافة") + " العمود «" + n + "»", "s");
    });
  }
  function colsMenu(anchor, at) {
    return [{ t: "ملأ الشاشة", ic: IC.fit, f: () => fitScreen() }, { t: "الخصائص", ic: IC.props, f: () => colProps() }, { t: "اضافة عمود", ic: IC.plus, f: () => addColumn() },
      "-", { t: "اختيار الحقول (Customization)", ic: IC.cols, f: () => chooser(anchor) }, { t: "إظهار كل الأعمدة", f: () => setVis(ALL.filter(avail).map(c => c.id).concat(calcCols().map(c => c.id))) }, { t: "أعمدة DEXEF الافتراضية", f: () => setVis(DEXEF_DEF.filter(id => avail(byId(id)))) }];
  }
  const DEXEF_DEF = ["name", "code", "unit", "factor", "price", "stock", "q5"];
  function viewMenu(b) {
    menu(b, [
      { t: "خصائص التصميم", ic: IC.gear, f: settingsDlg },
      { t: "الأعمدة", ic: IC.cols, sub: colsMenu(b) },
      { t: "حفظ التصميم", ic: IC.ok, kb: "Ctrl+S", f: saveDlg },
      { t: "إضافة تصميم", ic: IC.add, f: () => newDesign() },
      "-",
      { t: "تفعيل الاختيار المتعدد", ic: IC.multi, sw: !!(IRS && IRS.ms), f: toggleMulti },
      "-",
      { t: "طريقة العرض: " + modeName(), ic: MODE_IC[MODE], sub: MODES.map(([m, t]) => ({ t, ic: MODE_IC[m], kb: m === MODE ? "✓" : "", f: () => switchMode(m) })) }
    ]);
  }
  function toggleMulti() { if (!IRS) return; IRS.ms = IRS.ms ? null : new Set(); IRS.msLast = null; IRS.paint(true); say(IRS.ms ? "تفعيل الاختيار المتعدد: انقر الأسطر لاختيارها (Shift لمدى)" : "إلغاء الاختيار المتعدد", "i"); }

  /* ---------------- البحث: عدّاد النتائج ، Enter للتالي ، Esc للمسح ---------------- */
  function wireSearch(el) {
    const s = el.querySelector(".rv-search"), i = s && s.querySelector("input"); if (!i) return;
    const n = s.querySelector(".irf-n"), x = s.querySelector(".irf-x");
    const upd = () => setTimeout(() => { const q = i.value.trim(), c = shown().length; n.hidden = !q; x.hidden = !q; n.textContent = c; n.classList.toggle("z", q && !c); n.title = c + " نتيجة"; }, 0);
    i.addEventListener("input", upd);
    x.addEventListener("click", () => { i.value = ""; i.dispatchEvent(new Event("input")); i.focus(); });
    i.addEventListener("keydown", e => {
      if (e.key === "Escape" && i.value) { e.preventDefault(); e.stopPropagation(); x.click(); }
      else if (e.key === "Enter" && IRS && IRS.cur && IRS.cur.length) { e.preventDefault(); const l = IRS.cur; let k = IRS.sel; for (let t = 0; t < l.length; t++) { k = (k + (e.shiftKey ? -1 : 1) + l.length) % l.length; if (!l[k]._grp) break; } IRS.sel = k; IRS.reveal(k); }
      else if (e.key === "ArrowDown" && IRS) { e.preventDefault(); const g = el.querySelector(".rv-grid"); if (g) g.focus(); }
    });
  }

  /* ---------------- حذف (الصنف المحدد / الأصناف المختارة) ---------------- */
  function delMenu(b, r) {
    const ms = picked();
    menu(b, [
      { t: "حذف التعامل", ic: IC.del, dis: !r, f: () => { try { riDel(r._p || r); } catch (e) { say("تعذّر الحذف", "e"); } } },
      { t: "حذف التعاملات المختاره", ic: IC.delm, dis: !(ms && ms.length), f: () => delMany(ms) }
    ]);
  }
  function delMany(rows) {
    const ps = Array.from(new Set(rows.map(r => r._p || r))); if (!ps.length) return;
    const go = () => {
      if (!HOST()) { ps.forEach(p => { const i = PRODS().indexOf(p); if (i >= 0) PRODS().splice(i, 1); }); IRS.ms = new Set(); rerender(); say("تم حذف " + ps.length + " صنف", "s"); return; }
      let ok = 0, bad = []; const step = i => { if (i >= ps.length) { done(); return; } Anouer.call("fm.item.delete", { id: ps[i].id }).then(() => { ok++; step(i + 1); }).catch(e => { bad.push(ps[i].name + ": " + (e.message || e)); step(i + 1); }); };
      const done = () => { try { window.DelSound && DelSound.play(); } catch (e) { } IRS.ms = new Set(); say("تم حذف " + ok + " صنف" + (bad.length ? " — تعذّر " + bad.length : ""), bad.length ? "w" : "s"); if (bad.length) console.warn(bad);
        const L = window.__anouerLink; (L && L.loadProducts ? L.loadProducts() : Promise.resolve()).then(() => { loadMeta(true); rerender(); }).catch(() => rerender()); };
      step(0);
    };
    const m = "هل تريد حذف " + ps.length + " صنف مختار ؟";
    try { askConfirm(m, go); try { window.EditSound && EditSound.play(); } catch (e) { } } catch (e) { if (confirm(m)) go(); }
  }
  function printMenu(b, r) {
    menu(b, [
      { t: "عرض للطباعة", ic: IC.prv, kb: "Ctrl+Shift+P", f: () => printView(true) },
      { t: "طباعة", ic: IC.prt, f: () => printView(false) },
      { t: "طباعة الباركود", ic: IC.bc, f: () => { if (window.bcpOpen) bcpOpen(); else say("شاشة طباعة الباركود غير متوفرة", "w"); } }
    ]);
  }
  function excelMenu(b) {
    menu(b, [
      { t: "Excel File (xls)", ic: IC.xls, f: () => exportX("xls") }, { t: "Excel File (xlsx)", ic: IC.xls, f: () => exportX("xlsx") },
      { t: "Doc File", ic: IC.doc, f: () => exportX("doc") }, { t: "PDF File", ic: IC.pdf, f: () => { printView(false); say("اختر «Microsoft Print to PDF» للحفظ PDF", "i"); } },
      { t: "HTML File", ic: IC.html, f: () => exportX("html") }, { t: "CSV File", ic: IC.csv, f: () => exportX("csv") }
    ]);
  }
  function copyRows(r) {
    const ms = picked();
    if (!ms && r) { try { riCopy(r._p || r); } catch (e) { } return; }
    const rows = ms || shown(), cs = visCols();
    const t = [cs.map(c => c.t).join("\t")].concat(rows.map(x => cs.map(c => cellTxt(c, x)).join("\t"))).join("\r\n");
    try { navigator.clipboard.writeText(t).then(() => say("تم نسخ " + rows.length + " سطر (الصق في إكسيل)", "s"), () => say("تعذّر النسخ", "e")); } catch (e) { say("تعذّر النسخ", "e"); }
  }

  /* ---------------- المرفقات (لكل صنف — تُحفظ على هذا الجهاز) ---------------- */
  function idb() { return new Promise((ok, no) => { const q = indexedDB.open("anouer-attach", 1); q.onupgradeneeded = () => { q.result.createObjectStore("f", { keyPath: "id", autoIncrement: true }).createIndex("pid", "pid"); }; q.onsuccess = () => ok(q.result); q.onerror = () => no(q.error); }); }
  function attList(pid) { return idb().then(db => new Promise(ok => { const out = []; const c = db.transaction("f").objectStore("f").index("pid").openCursor(IDBKeyRange.only(pid)); c.onsuccess = () => { const x = c.result; if (x) { out.push(x.value); x.continue(); } else ok(out); }; c.onerror = () => ok(out); })); }
  function attAdd(pid, file) { return idb().then(db => new Promise((ok, no) => { const t = db.transaction("f", "readwrite"); t.objectStore("f").add({ pid, name: file.name, type: file.type, size: file.size, at: new Date().toISOString().slice(0, 16).replace("T", " "), blob: file }); t.oncomplete = ok; t.onerror = () => no(t.error); })); }
  function attDel(id) { return idb().then(db => new Promise(ok => { const t = db.transaction("f", "readwrite"); t.objectStore("f").delete(id); t.oncomplete = ok; t.onerror = ok; })); }
  function attach_(r) {
    if (!r) { say("اختر صنفاً أولاً", "i"); return; }
    const p = r._p || r, w = win("المرفقات — " + p.name, `<div class="note">مستندات وصور مرتبطة بالصنف (فواتير المورد، شهادات، صور...). تُحفظ على هذا الجهاز.</div><div class="att"></div>`, [["إضافة مرفق", "add", "ok"], ["إغلاق", "x"]]);
    const box = w.el.querySelector(".att");
    const draw = () => attList(p.id).then(l => { box.innerHTML = l.length ? l.map(a => `<div class="a" data-id="${a.id}"><span>📎 ${esc(a.name)} <small style="color:#888">(${Math.max(1, Math.round(a.size / 1024))} KB — ${esc(a.at)})</small></span><button type="button" data-x="open">فتح</button><button type="button" data-x="del">حذف</button></div>`).join("") : '<div class="note" style="text-align:center">لا توجد مرفقات لهذا الصنف</div>';
      box.querySelectorAll(".a").forEach(el => { const a = l.find(z => z.id === +el.dataset.id); el.querySelector('[data-x="open"]').onclick = () => dl(a.blob, a.name); el.querySelector('[data-x="del"]').onclick = () => attDel(a.id).then(draw); }); }).catch(e => { box.innerHTML = `<div class="note">تعذّر فتح المرفقات: ${esc(e.message || e)}</div>`; });
    w.on("add", () => { const i = document.createElement("input"); i.type = "file"; i.multiple = true; i.onchange = () => { Promise.all(Array.from(i.files || []).map(f => attAdd(p.id, f))).then(() => { say("تمت إضافة المرفقات", "s"); draw(); }); }; i.click(); return false; });
    draw();
  }

  /* ---------------- حركة الصنف ---------------- */
  function moves(r) {
    if (!r) { say("اختر صنفاً أولاً", "i"); return; }
    const p = r._p || r;
    const w = win("حركة الصنف — " + p.name, `<div class="note">كل المستندات المؤثرة في رصيد الصنف (بالقطعة)</div><div class="mvb"><div class="bar"><i style="width:40%"></i></div></div>`, [["تصدير Excel", "xl"], ["إغلاق", "x"]]);
    const box = w.el.querySelector(".mvb");
    if (!HOST()) { box.innerHTML = '<div class="note">«حركة الصنف» تعمل مع قاعدة بيانات ANOUER.</div>'; return; }
    Anouer.call("fm.items.moves", { id: p.id }).then(l => {
      let bal = 0, ti = 0, to = 0;
      const rows = (l || []).map(m => { bal += (+m.inQ || 0) - (+m.outQ || 0); ti += +m.inQ || 0; to += +m.outQ || 0; return Object.assign({}, m, { bal }); });
      box.innerHTML = rows.length ? `<table class="mv"><thead><tr><th>التاريخ</th><th>المستند</th><th>الرقم</th><th>الجهة</th><th>وارد</th><th>منصرف</th><th>السعر</th><th>الرصيد</th></tr></thead><tbody>${rows.map(m => `<tr><td>${esc(m.date)}</td><td>${esc(m.type)}</td><td>${esc(m.no)}</td><td>${esc(m.party)}</td><td class="in">${m.inQ ? F(m.inQ) : ""}</td><td class="out">${m.outQ ? F(m.outQ) : ""}</td><td>${F(m.price)}</td><td><b>${F(m.bal)}</b></td></tr>`).join("")}</tbody><tfoot><tr><td colspan="4">${rows.length} حركة</td><td>${F(ti)}</td><td>${F(to)}</td><td></td><td>${F(bal)}</td></tr></tfoot></table>` : '<div class="note" style="text-align:center">لا توجد حركات لهذا الصنف</div>';
      w.on("xl", () => { ensureX().then(() => { const ws = XLSX.utils.aoa_to_sheet([["التاريخ", "المستند", "الرقم", "الجهة", "وارد", "منصرف", "السعر", "الرصيد"]].concat(rows.map(m => [m.date, m.type, m.no, m.party, +m.inQ || 0, +m.outQ || 0, r2(m.price), r2(m.bal)]))); const wb = XLSX.utils.book_new(); wb.Workbook = { Views: [{ RTL: true }] }; XLSX.utils.book_append_sheet(wb, ws, "حركة الصنف"); XLSX.writeFile(wb, "حركة الصنف " + p.name.replace(/[\\/:*?"<>|]/g, " ") + ".xlsx"); }); return false; });
    }).catch(e => { box.innerHTML = `<div class="note">${unknown(e) ? "«حركة الصنف» تحتاج إعادة بناء البرنامج (build-exe.bat)." : esc(e.message || e)}</div>`; });
  }

  /* ---------------- لوحة المفاتيح ----------------
     حاجز المفاتيح العام في الصفحة يوقف المفاتيح عندما يكون التركيز على الصفحة نفسها ، لذلك تمر مفاتيح
     نوافذنا (Esc/Enter/الأسهم) واختصارات الشاشة (Ctrl+S/Ctrl+F/Ctrl+Shift+P) عبر خطاف window.__viewKey وأيضاً مباشرة */
  const KEYS = [];
  function keyPush(f) { KEYS.push(f); }
  function keyPop(f) { const i = KEYS.lastIndexOf(f); if (i >= 0) KEYS.splice(i, 1); }
  function keyDispatch(e) {
    if (e.__irx) return !!e.__irxH; e.__irx = 1;
    if (document.getElementById("cfOv") && document.getElementById("cfOv").classList.contains("show")) return false;   // نافذة التأكيد أولاً
    const h = KEYS[KEYS.length - 1];
    if (h) { e.__irxH = !!h(e); return e.__irxH; }
    const main = document.querySelector(".main");
    if (EL && main && main.dataset.view === "irev" && e.ctrlKey && !e.altKey) {
      const c = e.code || "", k = (e.key || "").toLowerCase();
      if (!e.shiftKey && (c === "KeyS" || k === "s")) { e.preventDefault(); saveDlg(); return (e.__irxH = true); }
      if (e.shiftKey && (c === "KeyP" || k === "p")) { e.preventDefault(); printView(true); return (e.__irxH = true); }
      if (!e.shiftKey && (c === "KeyF" || k === "f")) { const i = EL.querySelector(".rv-search input"); if (i) { e.preventDefault(); i.focus(); i.select(); return (e.__irxH = true); } }
    }
    return false;
  }
  { const prevVK = window.__viewKey; window.__viewKey = function (e) { if (keyDispatch(e)) return true; return prevVK ? prevVK(e) : false; }; }
  document.addEventListener("keydown", e => { if (keyDispatch(e)) e.stopPropagation(); }, true);

  /* ---------------- نافذة عامة ---------------- */
  function win(title, body, btns) {
    const ov = document.createElement("div"); ov.className = "irw-ov";
    ov.innerHTML = `<div class="irw" role="dialog" aria-label="${esc(title)}"><div class="t"><span>${esc(title)}</span><span class="sp"></span><b data-x="x" title="إغلاق (Esc)">✕</b></div><div class="b">${body}</div><div class="f">${(btns || []).map(b => `<button type="button" data-x="${b[1]}" class="${b[2] || ""}">${esc(b[0])}</button>`).join("")}</div></div>`;
    document.body.appendChild(ov);
    const H = {}, close = () => { ov.remove(); keyPop(key); };
    const key = e => { if (e.key === "Escape") { e.preventDefault(); close(); return true; } if (e.key === "Enter" && e.target.tagName !== "TEXTAREA" && e.target.tagName !== "BUTTON" && !e.target.closest(".ren")) { const ok = ov.querySelector(".f .ok"); if (ok && e.target.tagName !== "SELECT") { e.preventDefault(); ok.click(); return true; } } return false; };
    keyPush(key);
    ov.addEventListener("click", e => { const b = e.target.closest("[data-x]"); if (!b) return; const k = b.dataset.x; if (k === "x") { close(); return; } if (H[k] && H[k]() !== false) close(); });
    return { el: ov, close, on: (k, f) => { H[k] = f; } };
  }

  /* ---------------- رفع: استيراد إكسيل DEXEF «مراجعة الأصناف» بكل الحقول ---------------- */
  const HMAP = { "الاسم": "name", "الكود": "code", "الوحدة": "unit", "عدد القطع": "factor", "سعر البيع": "sale", "سعر 5ومافوق": "p5", "التجزئة": "retail", "الجملة": "whole",
    "الحد الأدنى": "min", "الحد الأقصى": "max", "المجموعة": "group", "الوصف": "desc", "سعر استطلاع": "survey", "سعر الشراء": "buy", "عابر سبيل": "passer",
    "مكان التخزين": "loc1", "مكان التخزين 2": "loc2", "مكان التخزين 3": "loc3", "نوع الصنف": "type", "اخيارات": "opt", "م": "dxid" };
  const OPTS = [["min", "الحد الأدنى"], ["max", "الحد الأقصى"], ["group", "المجموعة"], ["type", "نوع الصنف"], ["desc", "الوصف"], ["loc", "أماكن التخزين"], ["opt", "اخيارات"], ["prices", "شرائح الأسعار (التجزئة، الجملة، عابر سبيل، استطلاع، 5ومافوق)"], ["sale", "سعر البيع"], ["buy", "سعر الشراء"]];
  const OPT_OFF = { sale: 1 };   // سعر البيع لا يُستبدل إلا إذا اختاره المستخدم
  const nrm = s => String(s == null ? "" : s).replace(/\s+/g, " ").trim();
  function importDexef() {
    const i = document.createElement("input"); i.type = "file"; i.accept = ".xlsx,.xls";
    i.onchange = () => { const f = i.files && i.files[0]; if (!f) return; say("جاري قراءة " + f.name + " …", "i");
      Promise.all([ensureX(), f.arrayBuffer()]).then(([, buf]) => { const wb = XLSX.read(buf, { type: "array", cellDates: true }); const ws = wb.Sheets[wb.SheetNames[0]]; preview(XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" }), f.name); })
        .catch(e => say("تعذّر قراءة الملف: " + (e.message || e), "e")); };
    i.click();
  }
  function plan(aoa) {
    const head = (aoa[0] || []).map(nrm), ix = {}; head.forEach((h, k) => { const key = HMAP[h]; if (key && ix[key] == null) ix[key] = k; });
    if (ix.code == null || ix.name == null) throw new Error("الملف ليس تصدير «مراجعة الأصناف» من DEXEF (لا يوجد عمودا الاسم والكود)");
    const ps = PRODS(), byCode = {}, byBc = {}, byName = {};
    ps.forEach(p => { if (p.code != null) (byCode[String(p.code).trim()] = byCode[String(p.code).trim()] || []).push(p); (p._u || []).forEach(u => { [u.bc].concat(u.xb || []).forEach(b => { if (b) byBc[String(b).trim()] = p; }); }); (byName[nrm(p.name)] = byName[nrm(p.name)] || []).push(p); });
    const get = (row, k) => ix[k] == null ? "" : row[ix[k]];
    const out = {}, miss = []; let rowsN = 0;
    aoa.slice(1).forEach(row => {
      const code = nrm(get(row, "code")), name = nrm(get(row, "name")); if (!code && !name) return; rowsN++;
      let p = byBc[code] || null; if (!p) { const c = byCode[code] || []; p = c.length === 1 ? c[0] : c.find(x => nrm(x.name) === name) || null; }
      if (!p) { const c = byName[name] || []; if (c.length === 1) p = c[0]; }
      if (!p) { miss.push({ code, name, unit: nrm(get(row, "unit")) }); return; }
      const fac = NUM(get(row, "factor")) || 1, un = nrm(get(row, "unit"));
      /* الوحدة: الاسم + عدد القطع أولاً (DEXEF يكرر كود الصنف في سطر كل وحدة)، ثم الاسم، ثم باركود خاص بالوحدة، ثم عدد القطع */
      const us = p._u || [], fr = z => (+z.factor || 1) === fac, free = z => z.puid && !(out[p.id] && out[p.id].Units[z.puid]);
      const u = us.find(z => free(z) && nrm(z.name) === un && fr(z)) || us.find(z => free(z) && nrm(z.name) === un)
        || us.find(z => free(z) && z.bc && String(z.bc).trim() === code && String(code) !== String(nrm(p.code)) && fr(z))
        || us.find(z => free(z) && fr(z) && !us.some(y => y !== z && fr(y))) || null;
      const d = out[p.id] || (out[p.id] = { p, Id: p.id, Units: {} });
      const tx = k => { const v = nrm(get(row, k)); return v; };
      if (d.Min == null && NUM(get(row, "min")) != null) d.Min = NUM(get(row, "min"));
      if (d.Max == null && NUM(get(row, "max")) != null) d.Max = NUM(get(row, "max"));
      /* DEXEF يكتب المجموعة كمسار (الأب … الابن) — ANOUER يحفظ اسم مجموعة الصنف نفسها */
      if (!d.Group && tx("group")) d.Group = nrm(String(get(row, "group")).split(/\s{2,}/).filter(s => s.trim()).pop() || "");
      if (!d.Type && tx("type")) d.Type = TYK[tx("type")] || "";
      if (!d.Desc && tx("desc")) d.Desc = tx("desc");
      if (!d.Loc1 && tx("loc1")) d.Loc1 = tx("loc1"); if (!d.Loc2 && tx("loc2")) d.Loc2 = tx("loc2"); if (!d.Loc3 && tx("loc3")) d.Loc3 = tx("loc3");
      if (!d.Opt && tx("opt")) d.Opt = tx("opt");
      if (u && u.puid && !d.Units[u.puid]) d.Units[u.puid] = { Puid: u.puid, _u: u, Sale: NUM(get(row, "sale")), Retail: NUM(get(row, "retail")), Whole: NUM(get(row, "whole")), Passer: NUM(get(row, "passer")), Survey: NUM(get(row, "survey")), Price5: NUM(get(row, "p5")), Buy: NUM(get(row, "buy")) };
    });
    const items = Object.values(out).map(d => Object.assign(d, { Units: Object.values(d.Units) }));
    return { items, miss, rowsN, cols: Object.keys(ix).length };
  }
  function preview(aoa, fileName) {
    let P; try { P = plan(aoa); } catch (e) { say(e.message, "e"); return; }
    const nu = P.items.reduce((s, d) => s + d.Units.length, 0);
    /* أمثلة على التغييرات (الحقول التي ستتغير فعلاً) */
    const ch = [];
    P.items.forEach(d => {
      const p = d.p, x = X(p), f = x.f || {};
      const add = (fld, o, n) => { if (n == null || n === "" || String(o) === String(n)) return; ch.push([p.name, fld, o, n]); };
      add("الحد الأدنى", minOf(p), d.Min); add("الحد الأقصى", f[K.max] || "", d.Max); add("المجموعة", p.cat || "", d.Group); add("نوع الصنف", TYN[typeOf(p)], TYN[d.Type] || "");
      add("الوصف", x.desc || "", d.Desc); add("مكان التخزين", f[K.l1] || "", d.Loc1); add("مكان التخزين 2", f[K.l2] || "", d.Loc2);
      d.Units.forEach(u => { const o = u._u; add("التجزئة (" + o.name + ")", o.rp || 0, u.Retail); add("الجملة (" + o.name + ")", o.wp || 0, u.Whole); add("عابر سبيل (" + o.name + ")", o.pp || 0, u.Passer); add("سعر استطلاع (" + o.name + ")", o.sp || 0, u.Survey); add("سعر البيع (" + o.name + ")", o.price || 0, u.Sale); if (u.Buy) add("سعر الشراء (" + o.name + ")", M.buy[o.puid] || 0, u.Buy); });
    });
    const saved = lsGet("irev.impOpts", null);
    const w = win("رفع — استيراد أصناف DEXEF ONE", `
      <div class="note">الملف: <b>${esc(fileName)}</b> — ${P.cols} عمود معروف. يُحدّث الاستيراد بيانات الأصناف الموجودة في ANOUER فقط (لا يُنشئ أصنافاً ولا يغيّر الأرصدة أو التكلفة)، والخانات الفارغة في الملف لا تمسح الموجود.</div>
      <div class="kp"><div><b>${P.rowsN}</b>سطر في الملف</div><div><b>${P.items.length}</b>صنف مطابق</div><div><b>${nu}</b>وحدة مطابقة</div><div class="${P.miss.length ? "w" : ""}"><b>${P.miss.length}</b>سطر غير موجود في ANOUER</div><div><b>${ch.length}</b>قيمة ستتغير</div></div>
      <div class="ops">${OPTS.map(o => `<label><input type="checkbox" data-o="${o[0]}"${saved && saved[o[0]] != null ? (saved[o[0]] ? " checked" : "") : (OPT_OFF[o[0]] ? "" : " checked")}> ${esc(o[1])}</label>`).join("")}</div>
      ${ch.length ? `<table><thead><tr><th>الصنف</th><th>الحقل</th><th>الحالي</th><th>الجديد</th></tr></thead><tbody>${ch.slice(0, 60).map(c => `<tr><td>${esc(c[0])}</td><td>${esc(c[1])}</td><td class="o">${esc(c[2])}</td><td class="n">${esc(c[3])}</td></tr>`).join("")}</tbody></table>${ch.length > 60 ? `<div class="note">… و${ch.length - 60} تغييراً آخر</div>` : ""}` : '<div class="note">البيانات مطابقة — لا توجد قيم مختلفة.</div>'}
      ${P.miss.length ? `<details style="margin-top:8px"><summary>الأسطر غير الموجودة في ANOUER (${P.miss.length})</summary><table><thead><tr><th>الكود</th><th>الاسم</th><th>الوحدة</th></tr></thead><tbody>${P.miss.slice(0, 200).map(m => `<tr><td>${esc(m.code)}</td><td>${esc(m.name)}</td><td>${esc(m.unit)}</td></tr>`).join("")}</tbody></table></details>` : ""}
      <div class="bar" hidden><i></i></div>`, [["تصدير غير الموجود", "miss"], ["استيراد", "go", "ok"], ["إلغاء", "x"]]);
    const goBtn = w.el.querySelector('[data-x="go"]'); if (!P.items.length) goBtn.disabled = true;
    w.on("miss", () => { if (!P.miss.length) { say("كل الأسطر موجودة", "i"); return false; } ensureX().then(() => { const ws = XLSX.utils.aoa_to_sheet([["الكود", "الاسم", "الوحدة"]].concat(P.miss.map(m => [m.code, m.name, m.unit]))); const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "غير موجود"); XLSX.writeFile(wb, "أصناف DEXEF غير موجودة في ANOUER.xlsx"); }); return false; });
    w.on("go", () => {
      const opts = {}; w.el.querySelectorAll("[data-o]").forEach(c => { opts[c.dataset.o] = c.checked; }); lsSet("irev.impOpts", opts);
      if (!HOST()) { say("الاستيراد يعمل مع قاعدة بيانات ANOUER (البرنامج)", "w"); return false; }
      goBtn.disabled = true; const bar = w.el.querySelector(".bar"), bi = bar.querySelector("i"); bar.hidden = false;
      const rows = P.items.map(d => ({ Id: d.Id, Min: d.Min, Max: d.Max, Group: d.Group || "", Type: d.Type || "", Desc: d.Desc || "", Loc1: d.Loc1 || "", Loc2: d.Loc2 || "", Loc3: d.Loc3 || "", Opt: d.Opt || "",
        Units: d.Units.map(u => ({ Puid: u.Puid, Sale: u.Sale, Retail: u.Retail, Whole: u.Whole, Passer: u.Passer, Survey: u.Survey, Price5: u.Price5, Buy: u.Buy })) }));
      const N = 150; let k = 0, ti = 0, tu = 0;
      const step = () => {
        if (k >= rows.length) {
          say("✔ تم الاستيراد: " + ti + " صنف ، " + tu + " وحدة", "s"); w.close();
          const L = window.__anouerLink; (L && L.loadProducts ? L.loadProducts() : Promise.resolve()).then(() => loadMeta(true)).then(rerender).catch(rerender);
          return;
        }
        Anouer.call("fm.items.importDexef", { rows: rows.slice(k, k + N), opts }).then(r => { ti += +(r && r.items) || 0; tu += +(r && r.units) || 0; k += N; bi.style.width = Math.min(100, Math.round(k / rows.length * 100)) + "%"; step(); })
          .catch(e => { goBtn.disabled = false; say(unknown(e) ? "الاستيراد يحتاج إعادة بناء البرنامج (build-exe.bat) أولاً" : "تعذّر الاستيراد: " + (e.message || e), "e"); });
      };
      step(); return false;
    });
  }

  /* ---------------- الشريط ---------------- */
  function tb(a, b, r, S) {
    const k = b.dataset.tb || a;
    switch (k) {
      case "del": delMenu(b, r); return true;
      case "up": menu(b, [
        { t: "مزامنة كاملة من DEXEF (كل الأصناف النشطة بأرقامها وباركوداتها)", ic: IC.xls, f: () => { if (window.ANOUER_DXSYNC) ANOUER_DXSYNC.pick(); else say("ملف المزامنة غير محمّل", "w"); } },
        { t: "تحديث بيانات الأصناف الموجودة فقط (أسعار ، مجموعات …)", ic: IC.xls, f: () => importDexef() }
      ]); return true;
      case "copy": copyRows(r); return true;
      case "sync": case "refresh": loadMeta(true); return false;   // ثم تحديث الشاشة (Review)
      case "print": printMenu(b, r); return true;
      case "prv": printView(true); return true;
      case "excel": excelMenu(b); return true;
      case "mail": menu(b, [{ t: "PDF File", ic: IC.pdf, f: () => mail("pdf") }, { t: "Excel File", ic: IC.xls, f: () => mail("xlsx") }]); return true;
      case "dup": if (!r) { say("اختر صنفاً أولاً", "i"); return true; } try { riDup(r._p || r); } catch (e) { } return true;
      case "clip": attach_(r); return true;
      case "view": viewMenu(b); return true;
      case "cols": chooser(b); return true;
    }
    return false;
  }
  function headMenu(c, e, S) {
    if (!SET().colMenu) return;   // «ظهور قائمة ضبط الأعمدة» معطّلة
    const id = c && c.id, cc = id && byId(id), tree = MODE === "tree";
    menu(null, [
      { t: "ترتيب تصاعدي", dis: !c || !c.f || tree, f: () => sortBy(c, 1) }, { t: "ترتيب تنازلي", dis: !c || !c.f || tree, f: () => sortBy(c, -1) },
      "-",
      { t: "Column Chooser", ic: IC.cols, f: () => chooser(EL.querySelector(".rv-h")) },
      { t: "إخفاء هذا العمود", dis: !id || (cc && cc.fix), f: () => setVis(visIds().filter(x => x !== id)) },
      { t: "خصائص العمود (العنوان والعرض)", ic: IC.props, dis: !id, f: () => colProps(id) },
      cc && cc.calc ? { t: "تعديل العمود المحسوب", ic: IC.pen, f: () => addColumn(cc.calc.id) } : { t: "اضافة عمود محسوب", ic: IC.plus, f: () => addColumn() },
      { t: "ملأ الشاشة (Best Fit)", ic: IC.fit, f: () => fitScreen() },
      { t: "إظهار كل الأعمدة", f: () => setVis(allCols().filter(avail).map(x => x.id)) },
      { t: "أعمدة DEXEF الافتراضية", f: () => setVis(DEXEF_DEF.filter(x => avail(byId(x)))) },
      tree ? "-" : null, tree ? { t: "توسيع كل المجموعات", f: () => treeAll(true) } : null, tree ? { t: "طي كل المجموعات", f: () => treeAll(false) } : null
    ].filter(Boolean), { x: e.clientX + 1, y: e.clientY + 1 });
  }
  function sortBy(c, dir) { const h = EL.querySelector(`.rv-h>div[data-id="${c.id}"]`); if (!h) return; h.click(); if (IRS.dir !== dir) h.click(); }

  /* القائمة اليمنى للأصناف: «حركة الصنف» تعمل */
  document.addEventListener("click", e => {
    const i = e.target.closest && e.target.closest("#rcm .rcm-i"); if (!i) return;
    if ((i.querySelector("b") || {}).textContent === "حركة الصنف") { e.stopPropagation(); e.preventDefault(); const m = document.getElementById("rcm"); if (m) m.classList.remove("show"); moves(curRow()); }
  }, true);

  /* القائمة اليمنى: «طريقة العرض» ← عام / شجري / وحدات القياس / الملابس و الأحذية (مثل DEXEF) */
  function patchRcm() {
    const m = document.getElementById("rcm"); if (!m || !m.classList.contains("show")) return;
    const it = Array.from(m.querySelectorAll(":scope>.rcm-i")).find(x => ((x.querySelector(":scope>b") || {}).textContent || "").trim() === "طريقة العرض"); if (!it) return;
    const sub = it.querySelector(".rcm-sub"); if (!sub) return;
    sub.innerHTML = MODES.map(([k, t]) => `<div class="rcm-i" data-irv="${k}"><span class="rcm-mi">${MODE_IC[k]}</span><b>${t}</b>${k === MODE ? '<em class="rcm-ok">✓</em>' : ""}</div>`).join("");
  }
  document.addEventListener("contextmenu", e => { if (e.target.closest && e.target.closest("#vIRev")) setTimeout(patchRcm, 0); }, true);
  document.addEventListener("click", e => {
    const i = e.target.closest && e.target.closest("#rcm [data-irv]"); if (!i) return;
    e.stopPropagation(); e.preventDefault(); const m = document.getElementById("rcm"); if (m) m.classList.remove("show"); switchMode(i.dataset.irv);
  }, true);

  window.__IRX = { cols, tb, headMenu, attach, cfgx, data, chooser: () => chooser(), importDexef, moves: r => moves(r || curRow()), exportX, loadMeta, ALL, visIds, setVis, switchMode, mode: () => MODE, designs, applyDesign, settingsDlg, colProps, addColumn, parseQ, AN };
})();
