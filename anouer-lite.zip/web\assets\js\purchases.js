/* ANOUER — المشتريات (مطابقة DEXEF ONE): فاتورة مشتريات Ctrl+U، مرتجع مشتريات Ctrl+Y، طلبيات الشراء،
   ومراجعة التعاملات. كل مستند في تبويب مستقل بحالته الكاملة؛ الحفظ عبر fm.pur.* (المخزون، متوسط التكلفة،
   رصيد المورد، الخزينة، سعر البيع) مع التعديل والحذف بعكس الأثر. */
(function () {
  "use strict";
  const RV = window.__RV;
  if (!RV) { console.warn("purchases: __RV غير متاح"); return; }
  const main = document.querySelector(".main");
  if (!main) return;
  const G = id => document.getElementById(id);
  const B = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const call = (a, p) => Anouer.call(a, p || {});
  const say = (m, t) => { try { RV.say(m, t); } catch (e) { } };
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => "&#" + c.charCodeAt(0) + ";");
  const r2 = n => Math.round((+n || 0) * 100) / 100;
  const fmt = n => r2(n).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const num = v => { const n = parseFloat(String(v == null ? "" : v).replace(/[,\s]/g, "").replace("،", ".")); return isFinite(n) ? n : 0; };
  const p2 = n => String(n).padStart(2, "0");
  const ymd = d => d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate());
  const today = () => ymd(new Date());
  const norm = s => String(s || "").toLowerCase().replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").trim();
  /* نوافذ التأكيد (هل تريد حذف هذا السطر …) تُصدر صوت نافذة الرسائل في DEXEF ONE (نغمتان) لحظة ظهورها */
  const dlgSound = () => { try { if (typeof EditSound !== "undefined") EditSound.play(); } catch (e) { } };
  const ask = (m, y) => { try { askConfirm(m, y); dlgSound(); } catch (e) { if (confirm(m)) y(); } };
  const askE = y => { try { askEdit(y); } catch (e) { if (confirm("هل تريد التعديل ؟")) y(); } };

  /* ------------------------------------------------------------------ الأنواع */
  const TY = {
    Purchase: { t: "مشتريات", tab: "مشتريات", c: "#2e8b57", rev: "مراجعة مشتريات", rv: "purrev", pay: 1 },
    PurchaseReturn: { t: "مرتجع مشتريات", tab: "مرتجع مشتريات", c: "#7a5c99", rev: "مراجعة مرتجع مشتريات", rv: "prtrev", pay: 1 },
    PurchaseOrder: { t: "طلبية شراء", tab: "طلبيات الشراء", c: "#0a7dd1", rev: "مراجعة طلبيات الشراء", rv: "pordrev", pay: 0, req: 1 },
    /* مستندات المخازن (مطابقة DEXEF): نفس قالب الفاتورة بدون مورد ولا دفع.
       dir: أثر المخزون، gla: حساب الأستاذ الافتراضي، side: تبويب «تحويل الى/طلب من»، out: يُنقص الرصيد (تنبيه تجاوز الرصيد) */
    StockIn: { t: "إذن استلام", tab: "إذن استلام", c: "#2e8b57", rev: "مراجعة إذن استلام", rv: "sinrev", pay: 0, store: 1, dir: 1 },
    StockOut: { t: "إذن صرف", tab: "إذن صرف", c: "#c0392b", rev: "مراجعة إذن صرف", rv: "soutrev", pay: 0, store: 1, dir: -1, out: 1 },
    Transfer: { t: "تحويلات المخازن", tab: "تحويل مباشر", c: "#e0622a", rev: "مراجعة التحويلات المباشرة", rv: "trrev", pay: 0, store: 1, dir: 0, out: 1, side: "to" },
    TransferReq: { t: "طلب تحويل بضاعة", tab: "طلب تحويل", c: "#0a7dd1", rev: "مراجعة طلبات التحويل", rv: "trqrev", pay: 0, store: 1, dir: 0, side: "from", req: 1 },
    Opening: { t: "مخزون أول المدة", tab: "مخزون أول المدة", c: "#1a9be6", lite: 1, deal: "مخزون أول المدة", rev: "مراجعة مخزون أول المدة", rv: "oprev", pay: 0, store: 1, dir: 1, gla: "الأرصدة الإفتتاحية" },
    Waste: { t: "هالك المخزون", tab: "هالك المخزون", c: "#138a7c", lite: 1, deal: "", rev: "مراجعة هالك مخزون", rv: "wsrev", pay: 0, store: 1, dir: -1, out: 1, gla: "تألف إنتاج تالف / بضائع مشتراة (في مرحلة البيع)" },
    Charity: { t: "الصدقات", tab: "صدقات من المخزون", c: "#8e44ad", lite: 1, deal: "", noBan: 1, rev: "مراجعة الصدقات", rv: "chrev", pay: 0, store: 1, dir: -1, out: 1, gla: "تبرعات وإعانات" },
    ReserveReq: { t: "طلب حجز بضاعة", tab: "طلب حجز البضاعة", c: "#2e8b57", rev: "مراجعة طلبات الحجز", rv: "rsqrev", pay: 0, store: 1, dir: 0, req: 1 },
    Reserve: { t: "حجز بضاعة", tab: "حجز البضاعة", c: "#0a7dd1", rev: "مراجعة حجز البضاعة", rv: "rsrev", pay: 0, store: 1, dir: 0 },
    ReserveCancel: { t: "إلغاء حجز البضاعة", tab: "إلغاء حجز البضاعة", c: "#c0392b", rev: "مراجعة الغاءات الحجز", rv: "rscrev", pay: 0, store: 1, dir: 0 },
    /* مستندات العملاء بلا أثر على المخزون أو الحسابات (مطابقة DEXEF ONE — قائمة المبيعات):
       عرض السلعة (عروض الأسعار Alt+Q) وأمر توريد (Alt+O) — بسعر البيع حسب شريحة «السعر»، وتُحوَّل لفاتورة مبيعات */
    Quotation: { t: "عرض السلعة", tab: "عرض السلعة", c: "#4c8a35", rev: "مراجعة عرض السلعة", rv: "quorev", pay: 0, req: 1, cust: 1 },
    SupplyOrder: { t: "أمر توريد", tab: "أمر توريد", c: "#4a80c2", rev: "مراجعة أوامر التوريد", rv: "sordrev", pay: 0, req: 1, cust: 1 }
  };
  /* حالات مستندات العملاء (لمستي): تتبّع العرض من الإرسال حتى التحويل لفاتورة */
  const CST = {
    Quotation: [["open", "مفتوح", "#1f7ad8"], ["sent", "تم الإرسال", "#7a5c99"], ["ok", "مقبول", "#2e8b57"], ["rej", "مرفوض", "#c0392b"], ["conv", "تم التحويل لفاتورة", "#0f766e"], ["exp", "منتهي الصلاحية", "#8a95a5"]],
    SupplyOrder: [["open", "مفتوح", "#1f7ad8"], ["prep", "قيد التجهيز", "#e08a00"], ["done", "تم التوريد", "#2e8b57"], ["conv", "تم التحويل لفاتورة", "#0f766e"], ["cancel", "ملغى", "#c0392b"]]
  };
  let CUSTSEQ = 900000;   // معرّف مؤقت ثابت لعملاء المعاينة (بلا قاعدة بيانات)
  const CUSTP = () => (window.CUSTOMERS_DATA || []).filter(c => c && c.active !== false && c.name).map(c => {
    if (c._pid == null) c._pid = +c.id || (++CUSTSEQ);
    return { id: c._pid, code: c.no || c.code || "", name: c.name, bal: +c.bal || 0, lim: +c.lim || 0, ph: c.ph || "", ph2: (c.x && c.x.ph2) || "", addr: (c.x && c.x.addr) || c.addr || "", mail: (c.x && c.x.mail) || "", note: (c.x && c.x.note) || "", cust: 1, src: c, x: c.x || {} };
  });
  Object.keys(TY).forEach(k => { const t = TY[k]; if (t.store) t.cols = (t.out || t.side === "to") && k !== "Charity" ? ["code", "name", "stock", "qty", "unit", "price", "total"] : ["code", "name", "qty", "unit", "price", "total"]; });   /* DEXEF: الصدقات بدون «الرصيد الحالي» */
  /* المخازن وأرصدتها (wh-stock.js: الفهرس ← المخازن + fm.stock.byWh) */
  const WHM = () => window.ANOUER_WH || { list: [{ id: 0, name: "المخزن الرئيسي", active: true }], qty: (pid) => { const p = prods().find(x => x.id == pid); return p ? +p.stock || 0 : 0; }, reserved: () => 0, options: () => '<option value="0">المخزن الرئيسي</option>', nameOf: () => "المخزن الرئيسي", byName: () => 0, load: () => Promise.resolve() };
  function loadWhs(force) { return Promise.resolve(WHM().load(force)).then(() => { Object.values(DOCS).forEach(d => { d.refreshMeta(); d.renderAll(); }); }).catch(() => { }); }
  window.addEventListener("anouer:whstock", () => Object.values(DOCS).forEach(d => { try { d.refreshMeta(); d.syncCols(); } catch (e) { } }));
  const MODES = ["Clean", "Simple", "Professional", "Advanced"];
  /* طرق الدفع (مطابق DEXEF): نقدي من الخزينة، تحويل بنكي، فيزا كارد، عهد الموظفين، حساب في الشجرة */
  const PAYT = [
    { k: "cash", t: "نقدي", m: "Cash", ic: '<svg viewBox="0 0 18 16"><path d="M1 2h3l2 8h9l2-6H5" fill="none" stroke="#e2402b" stroke-width="1.8"/><circle cx="7" cy="13.5" r="1.6" fill="#e2402b"/><circle cx="14" cy="13.5" r="1.6" fill="#e2402b"/></svg>' },
    { k: "bank", t: "تحويل بنكي", m: "Bank", def: "البنك الرئيسي", ic: '<svg viewBox="0 0 18 16"><path d="M9 1L1 7h2v8h12V7h2z" fill="#f2b705"/><rect x="5" y="8" width="8" height="7" fill="#3c9b46"/><rect x="8" y="10" width="2" height="5" fill="#f2b705"/></svg>' },
    { k: "card", t: "فيزا كارد", m: "Card", def: "فيزا", ic: '<svg viewBox="0 0 18 16" fill="#2a74d4"><rect x="1" y="2" width="16" height="2.4" rx=".6"/><rect x="1" y="6.8" width="16" height="2.4" rx=".6"/><rect x="1" y="11.6" width="16" height="2.4" rx=".6"/></svg>' },
    { k: "custody", t: "عهد الموظفين", m: "Cash", def: "", ic: '<svg viewBox="0 0 18 16" fill="#1d3a6b"><circle cx="9.5" cy="2.2" r="1.9"/><path d="M8 4.6l-2.6 3.2 1.2 1 1.6-2v3.4L6 15h1.8l1.8-4.2 1.6 4.2H13l-2.2-6V6.4l1.6 1.6 1.2-1.1-2.8-2.3z"/></svg>' },
    { k: "acct", t: "حساب في الشجرة", m: "Cash", def: "", ic: '<svg viewBox="0 0 18 16"><path d="M1.5 8.5L8.5 1.5H16v7.5L9 16z" fill="#3b7dd8"/><circle cx="12.5" cy="5" r="1.5" fill="#fff"/><path d="M5 9l4 4" stroke="#cfe0fb" stroke-width="1.4"/></svg>' }];
  const VAT = [["بدون", 0], ["9%", .09], ["19%", .19]];
  /* نسب إضافية من الخصائص ← الضرائب ← ضريبة القيمة المضافة (نسبة المشتريات) — تُضاف بعد الثلاث الأساسية فتبقى أرقام المستندات القديمة صحيحة */
  function extendVat() {
    try { const l = window.ANOUER_PROPS && ANOUER_PROPS.get("tax.vat", null); if (!Array.isArray(l)) return VAT;
      l.filter(x => x && x.active !== false).forEach(x => { const r = +(x.same === "لا" ? x.pur : x.sale) || +x.pur || 0; if (r > 0 && !VAT.some(v => Math.abs(v[1] - r / 100) < 1e-9)) VAT.push([String(x.name || "").trim() && !String(x.name).includes(String(r)) ? x.name + " " + r + "%" : r + "%", r / 100]); });
    } catch (e) { }
    return VAT;
  }
  const SLICES = [["", 0], ["2%", 2], ["3%", 3], ["5%", 5], ["10%", 10]];

  /* ------------------------------------------------------------------ أيقونات */
  const I = {
    plus: '<svg viewBox="0 0 16 16"><rect x="1" y="1" width="14" height="14" rx="2" fill="#1f7ad8"/><path d="M8 4v8M4 8h8" stroke="#fff" stroke-width="2"/></svg>',
    prev: '<svg viewBox="0 0 16 16"><path d="M5 2l7 6-7 6z" fill="#1f7ad8"/></svg>',
    next: '<svg viewBox="0 0 16 16"><path d="M11 2L4 8l7 6z" fill="#1f7ad8"/></svg>',
    find: '<svg viewBox="0 0 16 16"><circle cx="6.5" cy="6.5" r="4.6" fill="#7fb3f0" stroke="#1f7ad8" stroke-width="1.6"/><path d="M10 10l4.5 4.5" stroke="#1f7ad8" stroke-width="2.2" stroke-linecap="round"/></svg>',
    toSale: '<svg viewBox="0 0 16 16"><rect x="1" y="2" width="8" height="11" rx="1.2" fill="#e8f1fc" stroke="#4c8a35" stroke-width="1.2"/><path d="M3 5h4M3 7.5h4M3 10h2.5" stroke="#4c8a35" stroke-width="1.1"/><path d="M9.5 8.5h5M12.5 6l2.3 2.5-2.3 2.5" fill="none" stroke="#1f7ad8" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    draft: '<svg viewBox="0 0 16 16"><path d="M1.5 1.5h10l3 3v10h-13z" fill="#8a76c8"/><rect x="4" y="1.5" width="7" height="4" fill="#ece8f8"/><rect x="4" y="9" width="8" height="5.5" fill="#fff"/><circle cx="12.3" cy="12.3" r="3.4" fill="#2e9b48" stroke="#fff" stroke-width="1"/><path d="M10.8 12.4l1.1 1.1 1.9-2" fill="none" stroke="#fff" stroke-width="1.2"/></svg>',
    drafts: '<svg viewBox="0 0 16 16"><rect x="3.5" y="1.5" width="10" height="12" rx="1.3" fill="#c9d9f2"/><rect x="1.5" y="3" width="10" height="12" rx="1.3" fill="#fff" stroke="#3a74c4"/><path d="M3.8 6.5h5.5M3.8 9h5.5M3.8 11.5h3.3" stroke="#3a74c4" stroke-width="1.1"/></svg>',
    save: '<svg viewBox="0 0 16 16"><path d="M1.5 1.5h10l3 3v10h-13z" fill="#8a76c8"/><rect x="4" y="1.5" width="7" height="4" fill="#ece8f8"/><rect x="4" y="9" width="8" height="5.5" fill="#fff"/></svg>',
    print: '<svg viewBox="0 0 16 16"><rect x="4" y="1.5" width="8" height="4" fill="#9aa7b8"/><rect x="1.5" y="5" width="13" height="7" rx="1.2" fill="#5c6b80"/><rect x="4" y="9.5" width="8" height="5" fill="#fff" stroke="#5c6b80"/></svg>',
    mail: '<svg viewBox="0 0 16 16"><rect x="1" y="3" width="14" height="10" rx="1.2" fill="#1f7ad8"/><path d="M1.5 4l6.5 5 6.5-5" fill="none" stroke="#fff" stroke-width="1.4"/></svg>',
    ref: '<svg viewBox="0 0 16 16" fill="none" stroke="#1f7ad8" stroke-width="1.8"><path d="M13 6A5.5 5.5 0 0 0 3 5"/><path d="M3 10a5.5 5.5 0 0 0 10 1"/><path d="M2.5 1.5V5H6M13.5 14.5V11H10"/></svg>',
    xls: '<svg viewBox="0 0 16 16"><rect x="2" y="1" width="11" height="14" rx="1" fill="#1f7ad8"/><path d="M5 5l4 6M9 5l-4 6" stroke="#fff" stroke-width="1.5"/></svg>',
    load: '<svg viewBox="0 0 16 16" fill="#5c6b80"><rect x="1" y="2" width="3" height="2"/><rect x="5" y="2" width="10" height="2"/><rect x="1" y="7" width="3" height="2"/><rect x="5" y="7" width="10" height="2"/><rect x="1" y="12" width="3" height="2"/><rect x="5" y="12" width="10" height="2"/></svg>',
    copy: '<svg viewBox="0 0 16 16"><rect x="5" y="4" width="9" height="11" rx="1.4" fill="#1f7ad8"/><rect x="2" y="1" width="9" height="11" rx="1.4" fill="#7fb3f0"/></svg>',
    exp: '<svg viewBox="0 0 16 16"><rect x="1" y="3" width="10" height="10" rx="1" fill="#1f7ad8"/><path d="M8 8h7M12 5l3 3-3 3" stroke="#1f7ad8" stroke-width="1.8" fill="none"/></svg>',
    del: '<svg viewBox="0 0 16 16"><rect x="3" y="4" width="10" height="11" rx="1.4" fill="#1f7ad8"/><rect x="1.5" y="2" width="13" height="2" fill="#1f7ad8"/><path d="M6 7v6M10 7v6" stroke="#fff" stroke-width="1.3"/></svg>',
    add: '<svg viewBox="0 0 16 16"><path d="M8 1.5v13M1.5 8h13" stroke="#22a04b" stroke-width="2.6"/></svg>',
    clip: '<svg viewBox="0 0 16 16"><path d="M10.5 4L5 9.6a1.4 1.4 0 0 0 2 2L13 5.6a2.6 2.6 0 0 0-3.7-3.7L3.4 8a3.8 3.8 0 0 0 5.4 5.4L13 9" fill="none" stroke="#8a95a5" stroke-width="1.4"/></svg>',
    redist: '<svg viewBox="0 0 32 32"><path d="M18,18h12v2h-9l4,4l-4,4h9v2H18v-2l4-4l-4-4V18z" fill="#FFB115"/><path d="M2,14h6v10H2V14z M16,24V8h-6v16H16z M24,16V2h-6v14H24z" fill="#1177D7"/></svg>',
    chart: '<svg viewBox="0 0 16 16"><rect x="1" y="9" width="3" height="6" fill="#1f7ad8"/><rect x="6" y="5" width="3" height="10" fill="#1f7ad8"/><rect x="11" y="1" width="3" height="14" fill="#1f7ad8"/></svg>',
    cols: '<svg viewBox="0 0 16 16" fill="#7d8da3"><rect x="1" y="2" width="3" height="12"/><rect x="6.5" y="2" width="3" height="12" fill="#5c6b80"/><rect x="12" y="2" width="3" height="12"/></svg>',
    user: '<svg viewBox="0 0 16 16"><rect x="1" y="1" width="14" height="14" rx="2" fill="#1f7ad8"/><circle cx="8" cy="6" r="2.6" fill="#fff"/><path d="M3.5 13.5c.6-2.6 2.4-3.8 4.5-3.8s3.9 1.2 4.5 3.8z" fill="#fff"/></svg>',
    coins: '<svg viewBox="0 0 18 16"><ellipse cx="11" cy="3" rx="6" ry="2.3" fill="#1f7ad8"/><path d="M5 3v3c0 1.3 2.7 2.3 6 2.3S17 7.3 17 6V3" fill="#4f9be6"/><path d="M5 6.5v3c0 1.3 2.7 2.3 6 2.3s6-1 6-2.3v-3" fill="#1f7ad8"/><path d="M1 9.5v3c0 1.3 2.7 2.3 6 2.3s6-1 6-2.3v-3" fill="#4f9be6"/><ellipse cx="7" cy="9.5" rx="6" ry="2.3" fill="#1f7ad8"/></svg>',
    cart: '<svg viewBox="0 0 18 16"><path d="M1 2h3l2 8h9l2-6H5" fill="none" stroke="#e2402b" stroke-width="1.8"/><circle cx="7" cy="13.5" r="1.6" fill="#e2402b"/><circle cx="14" cy="13.5" r="1.6" fill="#e2402b"/></svg>',
    credit: '<svg viewBox="0 0 18 16"><circle cx="6" cy="5" r="3" fill="#1f7ad8"/><path d="M1 15c0-3.4 2.2-5.4 5-5.4s5 2 5 5.4z" fill="#1f7ad8"/><path d="M11 9l2.2 2.2L17 7" fill="none" stroke="#1f7ad8" stroke-width="1.9"/></svg>',
    info: '<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="7" fill="#1f7ad8"/><rect x="7" y="7" width="2" height="5" fill="#fff"/><circle cx="8" cy="4.6" r="1.2" fill="#fff"/></svg>',
    note: '<svg viewBox="0 0 16 16"><rect x="1.5" y="1.5" width="13" height="13" rx="1.5" fill="#1f7ad8"/><path d="M8 4.5v7M4.5 8h7" stroke="#fff" stroke-width="1.8"/></svg>',
    x: '<svg viewBox="0 0 12 12"><path d="M2 2l8 8M10 2l-8 8" stroke="#e53935" stroke-width="2.2" stroke-linecap="round"/></svg>',
    wh: '<svg viewBox="0 0 16 16" fill="none" stroke="#1f7ad8" stroke-width="1.6"><path d="M2 6l3-3 3 3M5 3v9M14 10l-3 3-3-3M11 13V4"/></svg>',
    sAdd: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#fff"/><path d="M12 6v12M6 12h12" stroke="#1d9a55" stroke-width="3"/></svg>',
    sPen: '<svg viewBox="0 0 24 24"><path d="M4 20l1.5-5L16 4.5 19.5 8 9 18.5z" fill="#fff"/><path d="M14.5 6l3.5 3.5" stroke="#4a86c5" stroke-width="1.5"/></svg>',
    sPrn: '<svg viewBox="0 0 24 24"><rect x="6" y="2.5" width="12" height="6" rx="1" fill="#fff"/><rect x="2" y="8" width="20" height="10" rx="2" fill="#fff"/><rect x="6" y="14" width="12" height="7" fill="#e9eef5"/></svg>',
    sBolt: '<svg viewBox="0 0 24 24"><path d="M14 1L5 13h6l-2 10 10-13h-6z" fill="#fff"/></svg>',
    sCut: '<svg viewBox="0 0 24 24"><rect x="9" y="9" width="14" height="10" rx="2" fill="#bcd9f7"/><circle cx="5" cy="6" r="3" fill="none" stroke="#fff" stroke-width="2"/><circle cx="5" cy="15" r="3" fill="none" stroke="#fff" stroke-width="2"/><path d="M7.5 7.5L17 13M7.5 13.5L17 8" stroke="#fff" stroke-width="2"/></svg>',
    sCalc: '<svg viewBox="0 0 24 24"><rect x="4" y="1.5" width="16" height="21" rx="2.5" fill="#fff"/><rect x="6.5" y="4" width="11" height="4" fill="#5d82a8"/><g fill="#5d82a8"><rect x="6.5" y="10" width="3" height="2.5"/><rect x="10.5" y="10" width="3" height="2.5"/><rect x="14.5" y="10" width="3" height="2.5"/><rect x="6.5" y="14" width="3" height="2.5"/><rect x="10.5" y="14" width="3" height="2.5"/><rect x="14.5" y="14" width="3" height="6.5"/><rect x="6.5" y="18" width="7" height="2.5"/></g></svg>',
    sImg: '<svg viewBox="0 0 24 24"><path d="M4 1.5h11l5 5V22H4z" fill="#fff"/><circle cx="10" cy="11" r="2" fill="#7fb3f0"/><path d="M6 19l4-5 3 3 2-2 3 4z" fill="#7fb3f0"/><circle cx="17.5" cy="18.5" r="4" fill="#4fbf6b" stroke="#fff" stroke-width="1.4"/><path d="M15.7 18.5l1.3 1.3 2.4-2.6" stroke="#fff" stroke-width="1.4" fill="none"/></svg>',
    tBars: '<svg viewBox="0 0 16 16" fill="#fff"><rect x="2" y="9" width="3" height="5"/><rect x="6.5" y="5" width="3" height="9"/><rect x="11" y="2" width="3" height="12"/></svg>',
    tUser: '<svg viewBox="0 0 16 16" fill="#fff"><circle cx="8" cy="5" r="3"/><path d="M2 15c0-3.6 2.7-5.6 6-5.6s6 2 6 5.6z"/></svg>',
    keys: '<svg viewBox="0 0 16 16"><rect x="1" y="3" width="14" height="10" rx="1.5" fill="none" stroke="#1f7ad8" stroke-width="1.4"/><g fill="#1f7ad8"><rect x="3" y="5" width="2" height="2"/><rect x="6" y="5" width="2" height="2"/><rect x="9" y="5" width="2" height="2"/><rect x="12" y="5" width="1.5" height="2"/><rect x="4" y="9" width="8" height="2"/></g></svg>',
    insRow: '<svg viewBox="0 0 16 16"><rect x="5" y="2" width="10" height="4" rx=".6" fill="#7fb3f0"/><rect x="5" y="10" width="10" height="4" rx=".6" fill="#7fb3f0"/><path d="M1 8h6M4.5 5.5L7 8l-2.5 2.5" fill="none" stroke="#1f7ad8" stroke-width="1.6"/></svg>',
    delRow: '<svg viewBox="0 0 16 16"><rect x="5" y="2" width="10" height="4" rx=".6" fill="#7fb3f0"/><rect x="5" y="10" width="10" height="4" rx=".6" fill="#7fb3f0"/><path d="M1.5 6l5 5M6.5 6l-5 5" stroke="#e53935" stroke-width="1.8"/></svg>',
    gridIc: '<svg viewBox="0 0 16 16"><rect x="1" y="2" width="14" height="12" fill="#e8eef6" stroke="#8a95a5"/><path d="M1 6h14M1 10h14M6 2v12" stroke="#8a95a5"/><rect x="1" y="2" width="5" height="4" fill="#3c9b46"/></svg>',
    binoc: '<svg viewBox="0 0 18 16" fill="#1f5fa8"><rect x="1" y="6" width="6.5" height="8" rx="2.5"/><rect x="10.5" y="6" width="6.5" height="8" rx="2.5"/><rect x="2.5" y="2" width="4" height="5" rx="1"/><rect x="11.5" y="2" width="4" height="5" rx="1"/><rect x="7" y="7" width="4" height="3"/><circle cx="4.2" cy="10.5" r="1.6" fill="#9cc3f0"/><circle cx="13.8" cy="10.5" r="1.6" fill="#9cc3f0"/></svg>',
    tInv: '<svg viewBox="0 0 16 16" fill="#fff"><rect x="1.5" y="3" width="13" height="9" rx="1"/><rect x="4" y="12" width="8" height="2" fill="#cfe2fb"/><rect x="3.5" y="5" width="9" height="2" fill="#1f5fa8"/></svg>'
  };

  /* ------------------------------------------------------------------ البيانات المرجعية */
  const META = { types: {}, treasuries: [{ id: 1, name: "الخزينة الرئيسية", bal: 0 }], branches: [{ id: 1, name: "الفرع الرئيسي" }],
    next: {} };
  Object.keys(TY).forEach(k => { META.next[k] = "1"; });
  let SUPS = [];
  const LISTS = {};   // سجلات المراجعة
  const LOCAL = { seq: {}, docs: [] }; // وضع المعاينة بلا قاعدة
  Object.keys(TY).forEach(k => { LISTS[k] = null; LOCAL.seq[k] = 0; });
  let SET = {};                     // إعدادات «نماذج الفواتير» (Pur.*)
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
  /* «حفظ التغييرات» — مخزن المسودات: قاعدة البيانات (fm.draft.*) وإلا التخزين المحلي (وضع المعاينة / نسخة قديمة) */
  const DR = {
    host: true,
    unk: e => /غير معروف|unknown|not supported/i.test(String((e && e.message) || e)),
    ls: () => lsGet("pur.drafts", []),
    lsW: l => lsSet("pur.drafts", l.slice(0, 60)),
    useHost: () => B() && DR.host,
    wrap(fn, alt) { return DR.useHost() ? fn().catch(e => { if (DR.unk(e)) { DR.host = false; return alt(); } throw e; }) : Promise.resolve().then(alt); },
    lsList: type => DR.ls().filter(x => !type || x.type === type).map(x => Object.assign({}, x, { payload: undefined })),
    isL: id => /^L\d+$/.test(String(id)),   // مسودات محلية (قبل تحديث البرنامج) تبقى ظاهرة بعد التحديث
    list: type => DR.wrap(() => call("fm.draft.list", { type: type || "" }).then(l => (l || []).concat(DR.lsList(type))), () => DR.lsList(type)),
    get: id => DR.isL(id) ? Promise.resolve().then(() => { const x = DR.ls().find(z => String(z.id) === String(id)); if (!x) throw new Error("المسودة غير موجودة"); return x; })
      : DR.wrap(() => call("fm.draft.get", { id }), () => { const x = DR.ls().find(z => String(z.id) === String(id)); if (!x) throw new Error("المسودة غير موجودة"); return x; }),
    save: o => DR.wrap(() => call("fm.draft.save", DR.isL(o.id) ? Object.assign({}, o, { id: 0 }) : o).then(r => { if (DR.isL(o.id)) DR.lsW(DR.ls().filter(z => String(z.id) !== String(o.id))); return r; }), () => {
      const l = DR.ls(), now = new Date(), st = now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0") + "-" + String(now.getDate()).padStart(2, "0") + " " + now.toTimeString().slice(0, 8);
      let x = o.id && l.find(z => String(z.id) === String(o.id));
      if (!x) { x = { id: "L" + Date.now(), created: st }; l.unshift(x); }
      Object.assign(x, { type: o.type, title: o.title, party: o.party, cnt: o.cnt, total: o.total, payload: o.payload, auto: !!o.auto, invoiceId: o.invoiceId || 0, updated: st, user: "" });
      DR.lsW(l); return { id: x.id, updated: st };
    }),
    del: id => DR.isL(id) ? Promise.resolve().then(() => { DR.lsW(DR.ls().filter(z => String(z.id) !== String(id))); return { deleted: true }; }) : DR.wrap(() => call("fm.draft.delete", { id }), () => { DR.lsW(DR.ls().filter(z => String(z.id) !== String(id))); return { deleted: true }; })
  };
  let LASTUNIT = lsGet("pur.lastUnit", {});
  let PCLIP = null;                 // سطر منسوخ (مشترك بين مستندات المشتريات)
  /* الأصناف «مخزون برقم تسلسلي» (تُفعَّل من لوحة معلومات عن الصنف) */
  const isSerial = pid => (SET.serialItems || []).includes(pid) || !!(window.__ITYPE && window.__ITYPE[pid] === "serial");
  function setSerial(pid, on) {
    const l = (SET.serialItems || []).filter(x => x !== pid); if (on) l.push(pid);
    saveSet({ serialItems: l });
  }
  function emAlert(msg, cb) { if (window.__emAlert) window.__emAlert(msg, cb); else { alert(msg); if (cb) cb(); } }   // آخر وحدة شراء لكل صنف

  function loadMeta() {
    if (!B()) return Promise.resolve();
    return call("fm.pur.meta").then(m => {
      if (!m) return;
      META.types = m.types || {};
      if (m.treasuries && m.treasuries.length) META.treasuries = m.treasuries;
      if (m.branches && m.branches.length) META.branches = m.branches;
      Object.assign(META.next, m.next || {});
      Object.values(DOCS).forEach(d => d.refreshMeta());
    }).catch(e => say("تعذّر تحميل بيانات المشتريات: " + e.message, "e"));
  }
  function loadSups() {
    if (!B()) {
      if (!SUPS.length) SUPS = [{ id: 1, code: "20000", name: "ريضا بلماري", bal: 0, ph: "" }, { id: 2, code: "20002", name: "عبد الباقي شبيس", bal: 13840, ph: "" }, { id: 3, code: "20019", name: "عبد العزيز شهرة", bal: -252240, ph: "" }];
      return Promise.resolve(SUPS);
    }
    return call("fm.suppliers.list").then(l => {
      SUPS = (l || []).filter(s => s.IsActive !== false).map(s => { let x = {}; try { x = s.Extra ? JSON.parse(s.Extra) || {} : {}; } catch (e) { }
        return { id: s.SupplierId, code: s.Code || "", name: s.Name || "", bal: +s.Balance || 0, ph: s.Phone || x.ph || "", last: s.LastDeal || "", inv: s.Invoices || 0, lim: +s.CreditLimit || 0,
          mail: x.mail || "", addr: s.Address || x.addr || [x.street, x.city, x.state].filter(Boolean).join("، "), note: x.note || "", ph2: x.ph2 || "", raw: s, x }; });
      return SUPS;
    }).catch(() => SUPS);
  }
  /* إعدادات «نماذج الفواتير»: لكل طريقة عرض (m.<Mode>.*) ، الحقول الإجبارية لكل تعامل (r.<Type>.*) ، خصائص التعامل (t.<Type>.*) */
  const DEF_M = { totals: true, currency: true, serial: false, payDefault: "cash", expenses: true, terms: false, due: true, slices: true,
    vat: true, vatDefault: 0, discTax: false, discTaxDefault: 0, extra: true, reps: false, ship: false, cc: false, active: true };
  const DEF_T = { color: "", affects: true, kind: "", stock: true, track: true, trackInv: true, serialMode: "IN", billTrans: "IN",
    showBal: true, limitWarn: true, blockLimit: false, lastPrice: true, linkSale: true, tBefore: true, tDisc: true, tExtra: true, tTax: true, tPaid: true, tRem: true };
  const gm = (mode, k) => { const v = SET["m." + mode + "." + k]; return v === undefined ? DEF_M[k] : v; };
  const gr = (type, k) => !!SET["r." + type + "." + k];
  const gt = (type, k) => { const v = SET["t." + type + "." + k]; return v === undefined ? DEF_T[k] : v; };
  function saveSet(vals) {
    Object.assign(SET, vals); lsSet("pur.settings", SET);
    if (B()) { const o = {}; Object.keys(vals).forEach(k => { o["Pur." + k] = JSON.stringify(vals[k]); }); call("fm.settings.set", { values: o }).catch(() => { }); }
    Object.values(DOCS).forEach(d => d.applySettings());
  }
  function loadSettings() {
    SET = lsGet("pur.settings", {}) || {};
    if (!B()) return Promise.resolve();
    return call("fm.settings.get", { prefix: "Pur." }).then(o => {
      Object.keys(o || {}).forEach(k => { try { SET[k.slice(4)] = JSON.parse(o[k]); } catch (e) { SET[k.slice(4)] = o[k]; } });
      lsSet("pur.settings", SET);
      Object.values(DOCS).forEach(d => d.applySettings());
    }).catch(() => { });
  }
  function prods() { try { return products || []; } catch (e) { return []; } }
  function prodById(id) { return prods().find(p => p.id == id); }
  function unitsOf(p) {
    if (p && p._u && p._u.length) return p._u;
    return [{ name: (p && p.unit) || "حبة", factor: 1, price: +(p && p.price) || 0, puid: 0, bc: (p && p.code) || "", base: true }];
  }
  function unitByName(p, n) { return unitsOf(p).find(u => u.name === n) || null; }
  function defUnit(p) {
    const us = unitsOf(p), memo = LASTUNIT[p.id];
    // DEXEF: وحدة الشراء الافتراضية — آخر وحدة استُعملت للصنف، وإلا الوحدة الأكبر (الكرتونة)
    return us.find(u => u.defBuy) || (memo && us.find(u => u.name === memo)) || us.slice().sort((a, b) => (b.factor || 1) - (a.factor || 1))[0];
  }
  /* سعر الشراء الافتراضي للوحدة: المسجّل في بطاقة الصنف / آخر سعر شراء للوحدة — وإلا التكلفة × عدد القطع */
  const costOf = (p, u) => u && +u.buy > 0 ? r2(+u.buy) : r2((+p.cost || 0) * ((u && u.factor) || 1));
  const costOfBase = costOf;
  /* نافذة «تم التغيير فى السعر للصنف» (مثل المبيعات + صوتها) — فى المشتريات: «تعديل سعر الصنف الحالى» محدد مسبقاً على «سعر الشراء» */
  const PLV = [{ k: "cost", l: "سعر الشراء" }, { k: "lastDeal", l: "سعر اخر تعامل" }, { k: "price", l: "سعر البيع", n: 1 }, { k: "retail", l: "التجزئة", n: 2 }, { k: "passer", l: "عابر سبيل", n: 3 }, { k: "survey", l: "سعر استطلاع", n: 4 }, { k: "whole", l: "الجملة", n: 5 }, { k: "q5", l: "سعر 5ومافوق", n: 6 }];
  const plvIc = (x, big) => x.n ? `<span class="lw-n">${x.n}</span>` : `<span class="lw-o${big ? " big" : ""}"></span>`;
  let PPA = null;
  /* صوت اهتزازى (طنين قصير ثلاث نبضات — مُولَّد بالمتصفح) + اهتزاز الجهاز إن وُجد — للنسخة الحمراء */
  const BUZZ = (function () {
    let ctx = null;
    return { play() {
      try { window.__sndAt = Date.now(); if (navigator.vibrate) navigator.vibrate([70, 45, 70, 45, 110]); } catch (e) { }
      try {
        const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
        ctx = ctx || new AC(); if (ctx.state === "suspended") ctx.resume();
        const t0 = ctx.currentTime + .01, out = ctx.createGain(), lp = ctx.createBiquadFilter();
        lp.type = "lowpass"; lp.frequency.value = 1400; lp.Q.value = .8; out.gain.value = .55; lp.connect(out); out.connect(ctx.destination);
        [0, .17, .34].forEach((d, k) => {
          const o = ctx.createOscillator(), o2 = ctx.createOscillator(), am = ctx.createOscillator(), amg = ctx.createGain(), g = ctx.createGain(), len = k === 2 ? .2 : .12;
          o.type = "sawtooth"; o.frequency.value = 92; o2.type = "square"; o2.frequency.value = 138;
          am.type = "sine"; am.frequency.value = 38; amg.gain.value = .35; am.connect(amg); amg.connect(g.gain);
          g.gain.setValueAtTime(.0001, t0 + d); g.gain.exponentialRampToValueAtTime(.55, t0 + d + .012); g.gain.setValueAtTime(.55, t0 + d + len - .03); g.gain.exponentialRampToValueAtTime(.0001, t0 + d + len);
          o.connect(g); o2.connect(g); g.connect(lp);
          [o, o2, am].forEach(x => { x.start(t0 + d); x.stop(t0 + d + len + .02); });
        });
      } catch (e) { }
    } };
  })();
  window.BuzzSound = BUZZ;
  /* النسخة الحمراء: لا يُسمح بسعر شراء أعلى من سعر البيع (البيع بخسارة) — أى إغلاق يُرجع السعر كما كان */
  function purPriceBlock(o) {
    const b = o.block, sale = !!b.sale0, loss = r2(sale ? b.ref - o.v : o.v - b.sale), base = sale ? b.ref : b.sale, pct = base > 0 ? Math.round(loss / base * 1000) / 10 : 0;
    const ov = document.createElement("div"); ov.className = "lw-ov show pu-lwov bad";
    ov.innerHTML = `<div class="lw" role="alertdialog" aria-modal="true" aria-label="لا يمكن البيع بأقل من سعر الشراء">
      <button type="button" class="lw-x" aria-label="إغلاق" title="إغلاق (Esc)">×</button>
      <div class="lw-p"><div class="lw-t"><i class="lwb-ic" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 3L2 20h20z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M12 9v5M12 16.6v.4" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg></i>عدم السماح بالبيع أقل من الشراء — ${sale ? "سعر البيع الجديد أقل من سعر الشراء" : "سعر الشراء الجديد أعلى من سعر البيع"}</div>
        <div class="lw-c lwb-c">
          <div class="lwb-g"><div><span>السعر الجديد</span><b class="nw">${fmt(o.v)}</b></div><div><span>${sale ? "سعر الشراء" : "سعر البيع"}</span><b>${fmt(sale ? b.ref : b.sale)}</b></div><div class="ls"><span>خسارة فى كل وحدة</span><b>${fmt(loss)}<small>${pct ? " (" + pct + "%)" : ""}</small></b></div></div>
          <div class="lwb-m">سيتم إرجاع السعر كما كان <b>${fmt(b.old)}</b> — ${sale ? "أدخل سعراً لا يقل عن سعر الشراء <b>" + fmt(b.ref) + "</b>" : "لتغييره عدّل «سعر البيع» أولاً"} ، أو فعّل للصنف «السماح بالبيع بأقل من سعر الشراء» من بطاقة الصنف</div>
          <div class="lw-bt"><button type="button" class="pu-lwok">موافق</button><button type="button" class="pu-lwcl">إغلاق</button></div></div></div></div>`;
    document.body.appendChild(ov);
    const done = () => { window.removeEventListener("keydown", key, true); ov.classList.add("out"); setTimeout(() => ov.remove(), 160); PPA = null; o.revert(); if (o.after) o.after(); };
    function key(e) { e.stopImmediatePropagation(); if (e.key === "Tab") return; e.preventDefault(); if (e.key === "Escape" || e.key === "Enter" || e.key === " ") done(); }
    ov.addEventListener("click", e => { if (e.target.closest(".pu-lwok,.pu-lwcl,.lw-x")) done(); else if (!e.target.closest(".lw")) { const l = ov.querySelector(".lw"); l.classList.remove("shk"); void l.offsetWidth; l.classList.add("shk"); } });
    window.addEventListener("keydown", key, true);
    BUZZ.play();
    PPA = { close: silent => { window.removeEventListener("keydown", key, true); ov.remove(); PPA = null; o.revert(); } };
    setTimeout(() => { const x = ov.querySelector(".pu-lwok"); if (x) x.focus(); }, 30);
  }
  /* مشتركة مع فاتورة المبيعات (openLW): {v, block:{ref:سعر الشراء, old, sale0:1}, revert, after} */
  window.__lwBlock = o => { if (PPA) PPA.close(true); purPriceBlock(o); };
  function purPriceAsk(o) {
    if (PPA) PPA.close(true);
    if (o.block) return purPriceBlock(o);
    let choice = "edit", lvl = 0, dd = false, hl = 0;
    const ov = document.createElement("div"); ov.className = "lw-ov show pu-lwov";
    ov.innerHTML = `<div class="lw" role="alertdialog" aria-modal="true" aria-label="تم التغيير فى السعر للصنف">
      <button type="button" class="lw-x" aria-label="إغلاق" title="إغلاق (Esc)">×</button>
      <div class="lw-p"><div class="lw-t">تم التغيير فى السعر للصنف . و لا يوجد اسعار مشابهه له فى قاعدة البيانات</div>
        <div class="lw-c"><div class="lw-np">السعر الجديد =<b title="${esc(o.name || "")}">${fmt(o.v)}</b></div>
          <div class="lw-rw" role="radiogroup" aria-label="الإجراء">
            <div class="lw-rd" data-k="ignore" role="radio" tabindex="0"><i></i>عدم الاهتمام</div>
            <div class="lw-rd" data-k="edit" role="radio" tabindex="0"><i></i>تعديل سعر الصنف الحالى</div>
            <div class="lw-dd"><div class="lw-dd-b" tabindex="0" role="combobox" aria-expanded="false" aria-label="السعر المراد تعديله"><span class="lw-dd-v"></span><span class="lw-dd-a"></span></div><div class="lw-dl" role="listbox"></div></div>
          </div>
          <div class="lw-bt"><button type="button" class="pu-lwok">موافق</button><button type="button" class="pu-lwcl">إغلاق</button></div></div></div></div>`;
    document.body.appendChild(ov);
    const Q = s2 => ov.querySelector(s2), dl = Q(".lw-dl"), ddb = Q(".lw-dd-b");
    const setLvl = k => { lvl = k; Q(".lw-dd-v").innerHTML = plvIc(PLV[k], true) + `<span>${PLV[k].l}</span>`; };
    const sel = k => { choice = k; ov.querySelectorAll(".lw-rd").forEach(x => { const on = x.dataset.k === k; x.classList.toggle("on", on); x.setAttribute("aria-checked", on ? "true" : "false"); }); if (k !== "edit") ddClose(); };
    const list = () => { dl.innerHTML = PLV.map((x, k) => `<div class="lw-di${k === 0 ? " first" : ""}${k === hl ? " hl" : ""}" data-k="${k}" role="option" aria-selected="${k === lvl}" title="القيمة الحالية: ${fmt(o.cur ? o.cur(x.k) : 0)}">${plvIc(x)}<span>${x.l}</span></div>`).join(""); };
    const ddOpen = () => { dd = true; hl = lvl; list(); dl.classList.add("show"); ddb.setAttribute("aria-expanded", "true"); };
    function ddClose() { dd = false; dl.classList.remove("show"); ddb.setAttribute("aria-expanded", "false"); }
    const pick = k => { setLvl(k); sel("edit"); ddClose(); ddb.focus(); };
    function close(silent) { window.removeEventListener("keydown", key, true); ov.remove(); PPA = null; if (!silent && o.after) o.after(); }
    function ok() { const c = choice, k = PLV[lvl].k, l = PLV[lvl].l; close(true); if (c === "edit") o.apply(k, l); else say("تم اعتماد السعر " + fmt(o.v) + " لهذا السطر", "i"); if (o.after) o.after(); }
    function key(e) {
      const k = e.key, t = e.target, n = PLV.length;
      if (dd) { e.preventDefault(); e.stopImmediatePropagation();
        if (k === "ArrowDown" || k === "ArrowUp") { hl = (hl + (k === "ArrowDown" ? 1 : n - 1)) % n; list(); }
        else if (k === "Enter" || k === " ") pick(hl); else if (k === "Escape") { ddClose(); ddb.focus(); } else if (/^[0-6]$/.test(k)) { const j = PLV.findIndex(x => x.n === +k); if (j >= 0) pick(j); } else if (k === "Tab") ddClose();
        return; }
      if (k === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); say("تم إلغاء تعديل السعر", "i"); close(); return; }
      if (t === ddb && (k === "Enter" || k === " " || k === "ArrowDown" || k === "F4")) { e.preventDefault(); e.stopImmediatePropagation(); sel("edit"); ddOpen(); return; }
      if (t.classList && t.classList.contains("lw-rd") && (k === "Enter" || k === " ")) { e.preventDefault(); e.stopImmediatePropagation(); sel(t.dataset.k); return; }
      if (k === "ArrowLeft" || k === "ArrowRight") { if (t.classList && t.classList.contains("lw-rd")) { e.preventDefault(); e.stopImmediatePropagation(); const nk = choice === "edit" ? "ignore" : "edit"; sel(nk); Q(`.lw-rd[data-k="${nk}"]`).focus(); } return; }
      if (k === "Enter" && t.tagName !== "BUTTON") { e.preventDefault(); e.stopImmediatePropagation(); ok(); return; }
      if (k === "Tab" || k === "Enter" || k === " ") { e.stopImmediatePropagation(); return; }
      e.preventDefault(); e.stopImmediatePropagation();
    }
    ov.addEventListener("click", e => {
      const rd = e.target.closest(".lw-rd"); if (rd) { sel(rd.dataset.k); if (rd.dataset.k === "edit") ddOpen(); return; }
      const di = e.target.closest(".lw-di"); if (di) { pick(+di.dataset.k); return; }
      if (e.target.closest(".lw-dd-b")) { sel("edit"); if (dd) ddClose(); else ddOpen(); return; }
      if (e.target.closest(".pu-lwok")) { ok(); return; }
      if (e.target.closest(".pu-lwcl") || e.target.closest(".lw-x")) { say("تم إلغاء تعديل السعر", "i"); close(); return; }
      if (dd && !e.target.closest(".lw-dd")) ddClose();
    });
    dl.addEventListener("mousedown", e => e.preventDefault());
    dl.addEventListener("mousemove", e => { const di = e.target.closest(".lw-di"); if (di && +di.dataset.k !== hl) { hl = +di.dataset.k; dl.querySelectorAll(".lw-di").forEach(x => x.classList.toggle("hl", +x.dataset.k === hl)); } });
    window.addEventListener("keydown", key, true);
    setLvl(0); sel("edit");
    try { if (typeof LossSound !== "undefined") LossSound.play(); } catch (e) { }
    PPA = { close };
    setTimeout(() => { const b = Q(".pu-lwok"); if (b) b.focus(); }, 30);
  }
  /* سعر البيع حسب الشريحة (price-levels.js): سعر الوحدة للمستوى، وإلا سعر الصنف للمستوى × المعامل، وإلا سعر البيع */
  function lvPrice(p, u, lv) {
    const PL = window.ANOUER_PL, d = PL && PL.DEF.find(x => x.id === String(lv || "1"));
    const f = (u && u.factor) || 1;
    if (d && d.u && u && +u[d.u] > 0) return r2(+u[d.u]);
    if (d && d.p && d.id !== "1" && +p[d.p] > 0) return r2(+p[d.p] * f);
    return r2(+((u && u.price) || 0) || (+p.price || 0) * f);
  }

  /* ------------------------------------------------------------------ أدوات عامة: مؤقت التكّة للإجمالي الكبير */
  function fitBig(el) {
    if (!el || !el.offsetParent) return;
    const t = el.textContent; if (el.dataset.v) el.textContent = el.dataset.v;
    el.style.fontSize = ""; let fs = parseFloat(getComputedStyle(el).fontSize) || 56;
    while (el.scrollWidth > el.clientWidth + 1 && fs > 16) { fs -= 2; el.style.fontSize = fs + "px"; }
    el.textContent = t;
  }
  function counter(el) {
    if (window.__mkCounter) { const c = window.__mkCounter(() => el, () => fitBig(el)); return { to: v => { el.dataset.v = fmt(v); fitBig(el); c.to(v); } }; }
    return { to: v => { el.textContent = fmt(v); fitBig(el); } };
  }

  /* ------------------------------------------------------------------ المصروفات (مطابقة DEXEF ONE — CtlExtraGrid) */
  const EXP_ALLOC = [["AmountDiv", "يوزع على القيمه"], ["QtyDiv", "يوزع على الكميه"]];
  const EXP_PAY = [["Customer", "يضاف على الفاتورة"], ["Cash", "مصروف نقدي"], ["Company", "مصروف تتحمله الشركة"], ["OtherCustomer", "يقدم بشركة وسيطة"]];
  const EXP_TAX = [["No", "لا"], ["Yes", "نعم"], ["Invoice", "كما بالفاتورة"]];
  const EXC = [
    { k: "name", t: "المصروف", w: "minmax(170px,1.4fr)", def: 1 }, { k: "amt", t: "القيمة", w: "104px", def: 1 },
    { k: "alloc", t: "طريقة التوزيع", w: "128px", def: 1 }, { k: "pay", t: "نوع المصروف", w: "150px", def: 1 },
    { k: "acct", t: "جهة الصرف", w: "minmax(150px,1fr)", def: 1 }, { k: "items", t: "الأصناف", w: "150px" },
    { k: "cur", t: "العملة", w: "74px" }, { k: "rate", t: "المعامل", w: "70px" }, { k: "inv", t: "القيمه بعمله الفاتوره", w: "118px" },
    { k: "taxable", t: "يخضع للضريبة", w: "112px" }, { k: "taxPerc", t: "فئه الضريبه", w: "84px" }, { k: "tax", t: "قيمة الضريبة", w: "96px" },
    { k: "net", t: "الاجمالي", w: "100px" }, { k: "cc", t: "مركز التكلفة", w: "120px" }, { k: "notes", t: "الملاحظات", w: "minmax(140px,1fr)" }];
  const EXPDEF = lsGet("pur.expDefs", {});      // آخر إعدادات لكل اسم مصروف (تُقترح تلقائياً)
  function expCols() { const v = lsGet("pur.expCols", null); return Array.isArray(v) && v.length ? EXC.filter(c => c.k === "name" || v.includes(c.k)) : EXC.filter(c => c.def); }
  const COA_EXP = (() => { try { return (window.__FH_COA || []).filter(a => /^3/.test(a[0]) && !(window.__FH_COA || []).some(b => b[0] !== a[0] && b[0].indexOf(a[0]) === 0)).map(a => a[1]); } catch (e) { return []; } })();

  /* ------------------------------------------------------------------ نافذة منبثقة عامة (قائمة/شبكة) */
  let POP = null;
  function closePop() { if (POP) { try { POP.onClose && POP.onClose(); } catch (e) { } POP.el.remove(); POP = null; } }
  function openPop(anchor, html, cls, opt) {
    closePop();
    const el = document.createElement("div");
    el.className = "pu-pop " + (cls || "");
    el.innerHTML = html;
    document.body.appendChild(el);
    const r = anchor.getBoundingClientRect(), w = el.offsetWidth, h = el.offsetHeight;
    let x = (opt && opt.alignLeft) ? r.left : r.right - w;
    x = Math.max(4, Math.min(x, innerWidth - w - 4));
    let y = r.bottom + 1;
    if (y + h > innerHeight - 4) y = Math.max(4, r.top - h - 1);
    el.style.left = x + "px"; el.style.top = y + "px";
    POP = { el, anchor, onClose: opt && opt.onClose };
    return el;
  }
  document.addEventListener("mousedown", e => { if (POP && !POP.el.contains(e.target) && !(POP.anchor && POP.anchor.contains(e.target)) && !(e.target.closest && e.target.closest(".pu-dd,#ipkMenu,#ipkChooser,#ipkFE"))) closePop(); }, true);
  addEventListener("resize", closePop);

  /* ------------------------------------------------------------------ الآلة الحاسبة (مطابقة DEXEF + لمسة 2026)
     نفس ترتيب أزرار DEXEF: C · CE · Back · ✓ / sqrt / 9 8 7 MC / % * 6 5 4 MR / x/1 - 3 2 1 MS / = + . -/+ 0 +M
     • سطر العملية فوق النتيجة (1140 × 1.05 =) • القيمة الأصلية وفرق التغيير • لوحة المفاتيح كاملة
     • Enter = موافق (يحسب العملية المعلّقة) — Esc = إلغاء */
  function calcPop(anchor, start, onOk, opt) {
    opt = opt || {};
    const SYM = { "+": "+", "-": "−", "*": "×", "/": "÷" };
    const keys = [["sqrt", "/", "9", "8", "7", "MC"], ["%", "*", "6", "5", "4", "MR"], ["x/1", "-", "3", "2", "1", "MS"], ["=", "+", ".", "-/+", "0", "+M"]];
    const kc = k => /^[0-9.]$/.test(k) ? "d" : "+-*/".includes(k) || k === "=" ? "o" : /^M|\+M/.test(k) ? "m" : "f";
    const lbl = { "/": "÷", "*": "×", "-": "−", sqrt: "√", "x/1": "1/x", "-/+": "±" };
    const v0 = r2(+start || 0);
    const el = openPop(anchor, `<div class="pu-calc" dir="ltr"><div class="cdsp"><div class="cx"></div><div class="cv"></div><div class="cm"><span class="mm" title="الذاكرة"></span><span class="df"></span></div></div>
      <div class="r1"><button data-k="C" class="f">C</button><button data-k="CE" class="f">CE</button><button data-k="Back" class="f" title="Backspace">Back</button><button data-k="OK" class="pu-ok" title="موافق (Enter)"><svg viewBox="0 0 16 16" width="14" height="14"><path d="M3 8.5l3.2 3.2L13 4.8" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>
      <div class="ck">${keys.map(r => r.map(k => `<button data-k="${k}" class="${kc(k)}" title="${k}">${lbl[k] || k}</button>`).join("")).join("")}</div>
      ${opt.title ? `<div class="ct">${esc(opt.title)}</div>` : ""}</div>`, "pu-calcpop", { onClose: opt.onClose });
    let cur = String(v0), acc = null, op = null, fresh = true, expr = "", mem = lsGet("pur.calcMem", 0);
    const cv = el.querySelector(".cv"), cx = el.querySelector(".cx"), mm = el.querySelector(".mm"), df = el.querySelector(".df");
    const nf = v => { const n = +v; return isFinite(n) ? (Math.round(n * 1e6) / 1e6).toLocaleString("fr-FR", { maximumFractionDigits: 6 }) : "0"; };
    const show = () => {
      cv.textContent = /\.$/.test(cur) ? nf(cur) + "," : nf(cur); cx.textContent = expr || "\u00a0";
      mm.textContent = mem ? "M " + nf(mem) : "";
      const d = r2((parseFloat(cur) || 0) - v0);
      df.textContent = v0 && d && fresh !== null ? (d > 0 ? "▲ +" : "▼ ") + nf(d) + " (" + (d > 0 ? "+" : "") + nf(r2(d / v0 * 100)) + "%)" : "";
      df.className = "df" + (d > 0 ? " up" : d < 0 ? " dn" : "");
    };
    const ev = () => { const b = parseFloat(cur) || 0; if (op == null || acc == null) return b;
      return op === "+" ? acc + b : op === "-" ? acc - b : op === "*" ? acc * b : op === "/" ? (b ? acc / b : 0) : b; };
    const flash = k => { const b = el.querySelector(`button[data-k="${CSS.escape(k)}"]`); if (b) { b.classList.remove("hit"); void b.offsetWidth; b.classList.add("hit"); } };
    function press(k) {
      flash(k);
      if (/^[0-9]$/.test(k)) { cur = fresh || cur === "0" ? k : (cur.replace(/[^0-9]/g, "").length < 15 ? cur + k : cur); fresh = false; }
      else if (k === ".") { if (fresh) { cur = "0."; fresh = false; } else if (!cur.includes(".")) cur += "."; }
      else if (k === "C") { cur = "0"; acc = null; op = null; fresh = true; expr = ""; }
      else if (k === "CE") { cur = "0"; fresh = true; }
      else if (k === "Back") { if (!fresh) cur = cur.length > 1 && cur !== "-0" ? cur.slice(0, -1).replace(/^-$/, "0") : "0"; }
      else if ("+-*/".includes(k)) { if (!(fresh && op != null)) acc = ev(); op = k; cur = String(Math.round(acc * 1e6) / 1e6); fresh = true; expr = nf(acc) + " " + SYM[k]; }
      else if (k === "=") { if (op != null) { expr = nf(acc) + " " + SYM[op] + " " + nf(cur) + " ="; } cur = String(Math.round(ev() * 1e6) / 1e6); acc = null; op = null; fresh = true; }
      else if (k === "sqrt") { expr = "√(" + nf(cur) + ")"; cur = String(Math.round(Math.sqrt(Math.max(0, parseFloat(cur) || 0)) * 1e6) / 1e6); fresh = true; }
      else if (k === "%") { const b = parseFloat(cur) || 0; cur = String(Math.round((acc != null ? acc * b / 100 : b / 100) * 1e6) / 1e6); fresh = true; }
      else if (k === "x/1") { const b = parseFloat(cur) || 0; expr = "1/(" + nf(b) + ")"; cur = b ? String(Math.round(1 / b * 1e6) / 1e6) : "0"; fresh = true; }
      else if (k === "-/+") { cur = cur.startsWith("-") ? cur.slice(1) : (cur === "0" ? cur : "-" + cur); }
      else if (k === "MC") mem = 0; else if (k === "MR") { cur = String(mem); fresh = true; }
      else if (k === "MS") mem = parseFloat(cur) || 0; else if (k === "+M") mem = r2(mem + (parseFloat(cur) || 0));
      else if (k === "OK") { const v = ev(); closePop(); onOk && onOk(Math.round(v * 100) / 100); return; }
      lsSet("pur.calcMem", mem); show();
    }
    el.addEventListener("mousedown", e => e.preventDefault());
    el.addEventListener("click", e => { const b = e.target.closest("button"); if (b) press(b.dataset.k); });
    POP.key = e => {
      const k = e.key;
      if (/^[0-9.+\-*/]$/.test(k)) press(k); else if (k === ",") press(".");
      else if (k === "Enter") press("OK"); else if (k === "=") press("=");
      else if (k === "Backspace") press("Back"); else if (k === "Delete") press("CE");
      else if (k === "Escape") closePop(); else if (k === "%") press("%");
      else if (e.ctrlKey || e.altKey || k.length > 1) return false;
      return true;
    };
    show();
    return el;
  }
  /* زر ▾ داخل الخلية الرقمية في الشبكة (مثل DEXEF): يظهر على الخلية النشطة ويفتح الآلة الحاسبة — Alt+↓ من لوحة المفاتيح (F4 يبقى «حفظ وطباعة») */
  const CB = (() => {
    const b = document.createElement("button");
    b.type = "button"; b.className = "pu-cbtn"; b.tabIndex = -1; b.hidden = true; b.title = "الآلة الحاسبة (Alt+↓)";
    b.innerHTML = '<svg viewBox="0 0 10 6" width="9" height="6"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    const S0 = { inp: null, open: null };
    b.addEventListener("mousedown", e => { e.preventDefault(); e.stopPropagation(); });
    b.addEventListener("click", e => { e.preventDefault(); if (S0.inp && S0.open) S0.open(S0.inp); });
    const place = () => {
      const t = S0.inp;
      if (!t || !t.isConnected || !t.offsetParent || document.activeElement !== t) { b.hidden = true; return; }
      const r = t.getBoundingClientRect(), g = t.closest(".pu-gwrap") || t.closest(".pu-doc"), gr = g ? g.getBoundingClientRect() : null;
      if (gr && (r.bottom < gr.top + 2 || r.top > gr.bottom - 2)) { b.hidden = true; return; }
      const h = Math.min(r.height - 2, 20); b.style.height = h + "px"; b.style.top = (r.top + (r.height - h) / 2) + "px"; b.style.left = (r.left + 1) + "px"; b.hidden = false;
    };
    const ready = () => { if (!b.isConnected && document.body) document.body.appendChild(b); };
    addEventListener("resize", place); document.addEventListener("scroll", place, true);
    return {
      show(inp, open) { ready(); S0.inp = inp; S0.open = open; place(); },
      hide(inp) { if (!inp || S0.inp === inp) { b.hidden = true; } },
      place, el: b, cur: () => S0.inp
    };
  })();
  window.addEventListener("keydown", e => { if (POP && POP.key && POP.key(e)) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);

  /* ------------------------------------------------------------------ قالب المستند */
  function docHTML(type) {
    const ty = TY[type];
    const rb = (a, ic, t, dd, cls) => `<button type="button" class="pu-rb${dd ? " dd" : ""}${cls ? " " + cls : ""}" data-a="${a}" title="${esc(t || "")}">${I[ic] || ""}${t ? `<span>${t}</span>` : ""}${dd ? '<i class="car">▾</i>' : ""}</button>`;
    const sideBtn = (a, ic, t, c) => `<button type="button" class="pu-sb" data-s="${a}" style="--c:${c}">${I[ic]}<span>${t}</span></button>`;
    return `
<div class="pu-rib">
  <div class="pu-rtabs"><span class="pu-rt on" data-rt="gen">عام</span><span class="pu-rt" data-rt="fmt">تنسيق الفاتورة</span><span class="pu-rt" data-rt="prop">الخصائص</span><span class="pu-rsp"></span><span class="pu-rico" title="تصغير الشريط">▣</span></div>
  <div class="pu-tb" data-pane="gen">
    ${rb("new", "plus", "", 0, "ic")}${rb("prev", "prev", "", 0, "ic")}${rb("next", "next", "", 0, "ic")}${rb("find", "find", "بحث")}
    ${rb("save", "save", "حفظ", 1)}${rb("print", "print", "طباعة", 1)}${rb("mail", "mail", "Email")}${rb("refresh", "ref", "تحديث البيانات")}
    ${rb("xlsin", "xls", "إستيراد من إكسيل")}${rb("loadinv", "load", "تحميل الفاتورة")}${rb("copyto", "copy", "نسخ التعامل", 1)}${ty.cust ? rb("toSale", "toSale", "تحويل لفاتورة", 0, "pu-tosale") : ""}
    ${rb("xlsout", "exp", "تصدير إلى Xls", 1)}${rb("del", "del", "حذف")}${rb("additem", "add", "إضافة صنف")}${rb("att", "clip", "المرفقات", 0, "mut")}<button type="button" class="pu-rb ic" data-a="redist" title="إعادة التوزيع">${I.redist}</button>
    <span class="pu-tsp"></span>${rb("cols", "cols", "إختيار الحقول")}<button type="button" class="pu-rb ic" data-a="collapse" title="طي">▴</button>
  </div>
  <div class="pu-tb" data-pane="fmt" hidden>
    ${rb("fmtKeys", "keys", "إختصارات", 1)}${rb("fmtIns", "insRow", "إدخال سطر")}${rb("fmtDel", "delRow", "حذف سطر")}
    <span class="pu-fs"><span class="lb">بحث</span><span class="pu-fsi"><input data-f="gfind" placeholder="Enter text to search..." autocomplete="off" title="Enter: التالي — Shift+Enter: السابق — Esc: مسح"><em class="fcnt"></em><button type="button" class="fbt" data-a="fPrev" title="السابق (Shift+Enter)" tabindex="-1">▲</button><button type="button" class="fbt" data-a="fNext" title="التالي (Enter)" tabindex="-1">▼</button><button type="button" class="fbt ff" data-a="fFilter" title="إظهار الأسطر المطابقة فقط" tabindex="-1">${'<svg viewBox="0 0 12 12" width="10" height="10"><path d="M1 1.5h10L7 6.5V11L5 10V6.5z" fill="currentColor"/></svg>'}</button><button type="button" class="fbt fx" data-a="fClear" title="مسح (Esc)" tabindex="-1">✕</button><i>${'<svg viewBox="0 0 12 12" width="11" height="11"><circle cx="5" cy="5" r="3.6" fill="none" stroke="#555" stroke-width="1.3"/><path d="M7.7 7.7L11 11" stroke="#555" stroke-width="1.4"/></svg>'}</i></span></span>
    ${rb("fmtGrid", "gridIc", "", 0, "ic")}${rb("fmtEntry", "", "سطر الإدخال", 1)}${rb("fmtSerFind", "binoc", "البحث عن سيريال")}${rb("fmtSerFill", "", "تعبئة ارقام السيريال")}${rb("fmtExpAdd", "", "اضافة تاريخ صلاحية")}${rb("fmtExpShow", "", "عرض تواريخ الصلاحية")}
    <span hidden><select data-f="paper"><option value="A4">A4</option><option value="A5">A5</option><option value="80">80</option></select><input type="checkbox" data-f="pLogo" checked><input type="checkbox" data-f="pBal" checked><input type="checkbox" data-f="pSale"></span>
  </div>
  <div class="pu-tb" data-pane="prop" hidden>${rb("props", "cols", "نماذج الفواتير")}<span class="pu-hint">خصائص وإعدادات «${ty.t}» — الحقول الإجبارية وطريقة الدفع الافتراضية والضريبة</span></div>
</div>
<div class="pu-body">
  <div class="pu-side">
    <button type="button" class="pu-sclp" title="طي">‹</button>
    <div class="pu-stabs"><button type="button" class="on" data-st="acts" title="الفاتورة">${I.tInv}</button>${ty.side ? `<button type="button" data-st="tr" title="${ty.side === "to" ? "تحويل الى" : "طلب من"}">${I.wh}</button>` : ""}<button type="button" data-st="sup" title="${ty.cust ? "بيانات العميل" : "بيانات المورد"}">${I.tUser}</button><button type="button" data-st="stats" title="بيانات الصنف">${I.tBars}</button></div>
    <div class="pu-spane" data-sp="acts">
      <div class="pu-sh">الأصناف</div>
      ${sideBtn("newItem", "sAdd", "إضافة صنف جديد", "#1d9a55")}${sideBtn("prices", "sPen", "تعديل أسعار الصنف", "#4a86c5")}${sideBtn("barcode", "sPrn", "طباعة باركود الصنف", "#7c7c7c")}
      <div class="pu-sh">الفاتورة</div>${sideBtn("quick", "sBolt", "إضافة سريعة", "#4a86c5")}
      <div class="pu-sh">أخرى</div>${sideBtn("coupon", "sCut", "كوبون الخصم", "#4a86c5")}${sideBtn("calc", "sCalc", "الآلة الحاسبة", "#6b6b6b")}${sideBtn("images", "sImg", "صور الصنف", "#5ba5a0")}
    </div>
    <div class="pu-spane" data-sp="stats" hidden></div>
    <div class="pu-spane" data-sp="sup" hidden></div>
    ${ty.side ? `<div class="pu-spane pu-trp" data-sp="tr" hidden><div class="pu-sh">${ty.side === "to" ? "تحويل الى" : "طلب من"}</div>
      <label class="pu-f"><span class="lb">فرع التحويل</span><span class="pu-in"><select data-f="trBr"></select></span></label>
      <label class="pu-f"><span class="lb">مخزن التحويل <i class="req">*</i></span><span class="pu-in"><select data-f="trWh"></select></span></label>
      <div class="pu-trn">${ty.side === "to" ? "تُنقل الكميات من «اسم المخزن» إلى «مخزن التحويل» دون التأثير على إجمالي رصيد الصنف." : "يُرسل الطلب إلى «مخزن التحويل» لتجهيز البضاعة ثم يُحوَّل بتحويل مباشر."}</div></div>` : ""}
  </div>
  <div class="pu-split" title="اسحب لتغيير العرض">⋮</div>
  <div class="pu-main">
    <div class="pu-hd">
      <div class="pu-r1">
        ${ty.gla ? `<label class="pu-f w-gla"><span class="lb">حساب الأستاذ <i class="req">*</i></span><span class="pu-in"><input data-f="gla" value="${esc(ty.gla)}" list="puGlaList" autocomplete="off"><button type="button" class="dd" data-a="glaDd" tabindex="-1">▾</button></span></label>` : ""}
        ${ty.store ? (ty.lite ? `<label class="pu-f w-stt"><span class="lb">التعامل <i class="req">*</i></span><span class="pu-in"><input data-f="deal" list="puDeal_${type}" value="${esc(ty.deal || "")}" autocomplete="off" placeholder="${type === "Waste" ? "مثال: تلف بسبب الرطوبة" : type === "Charity" ? "مثال: صدقة رمضان" : ""}"><datalist id="puDeal_${type}"></datalist></span></label>` : `<label class="pu-f w-stt"><span class="lb">التعامل <i class="req">*</i></span><span class="pu-in"><select data-f="deal"><option>${esc(ty.t)}</option></select></span></label>`) : ""}
        <label class="pu-f w-sup"><span class="lb">الاسم</span><span class="pu-in"><input data-f="supName" placeholder="تعامل نقدي" autocomplete="off"><button type="button" class="dd" data-a="supdd" tabindex="-1">▾</button><button type="button" class="ib" data-a="supnew" title="${ty.cust ? "عميل جديد" : "مورد جديد"}" tabindex="-1">${I.user}</button></span></label>
        <label class="pu-f w-code"><span class="lb">الرقم</span><span class="pu-in"><input data-f="supCode" autocomplete="off"></span></label>
        ${ty.cust ? `<label class="pu-f w-plv"><span class="lb">السعر</span><span class="pu-in pu-plv"><i class="plv-o" title="شريحة السعر — تُطبَّق على الأصناف الجديدة وعلى الأسطر التي لم يُعدَّل سعرها"></i><select data-f="plv"></select></span></label>` : ""}
        <label class="pu-f w-deal"><span class="lb">التعامل</span><span class="pu-in pu-deal"><button type="button" class="ib" data-a="deal" title="كاش / أجل">${I.coins}</button><button type="button" class="dd" data-a="deal" tabindex="-1">▾</button></span></label>
        <span class="pu-gap"></span>
        <label class="pu-f w-mode"><span class="lb">طريقة العرض</span><span class="pu-in pu-modef"><input data-f="mode" value="Simple" readonly tabindex="0"><b class="pu-ok" title="طريقة العرض الافتراضية لهذا التعامل" data-a="modeDef">✓</b><button type="button" class="pu-mdots" data-a="props" title="نماذج الفواتير — خصائص طريقة العرض" tabindex="-1">⋯</button><button type="button" class="dd" data-a="modeDd" tabindex="-1">▾</button></span></label>
        <label class="pu-f w-ref"><span class="lb">رقم المرجع #</span><span class="pu-in"><input data-f="ref" autocomplete="off" title="رقم المرجع — F4 للبحث عن تعامل"><button type="button" class="pu-refs" data-a="txs" tabindex="-1" title="البحث عن تعامل (F4)"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round"><circle cx="8.5" cy="8.5" r="5.5"/><path d="M12.6 12.6L17.5 17.5"/></svg></button></span></label>
        <label class="pu-f w-br"><span class="lb">اسم الفرع <i class="req">*</i></span><span class="pu-in"><select data-f="branch"></select></span></label>
      </div>
      <div class="pu-r2">
        <div class="pu-bal" data-f="balInfo"></div>
        <div class="pu-banner" style="--bc:${ty.c}"><button type="button" class="pu-scan" data-a="scanDoc" title="قراءة فاتورة ورقية بالكاميرا / الهاتف / صورة (Ctrl+Shift+Q)" tabindex="-1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><path d="M7 8h10M7 12h10M7 16h6"/></svg><i></i></button><span data-f="title">${ty.t}</span><em data-f="editTag"></em></div>
        <div class="pu-lblk">
          <div class="pu-lrow">
            <label class="pu-f w-pre"><span class="lb">تبدا ب</span><span class="pu-in"><input data-f="prefix" autocomplete="off"></span></label>
            <label class="pu-f w-no"><span class="lb">الرقم</span><span class="pu-in"><input data-f="no" autocomplete="off" inputmode="numeric"></span></label>
            <label class="pu-f w-date"><span class="lb">التاريخ <i class="req">*</i></span><span class="pu-in"><input type="date" data-f="date"></span></label>
          </div>
          <div class="pu-lrow">
            <label class="pu-f w-st"><span class="lb">الحالة</span><span class="pu-in"><select data-f="status"></select></span></label>
            <label class="pu-f w-wh"><span class="lb">اسم المخزن <i class="req">*</i></span><span class="pu-in"><select data-f="wh"><option>المخزن الرئيسي</option></select><b class="pu-ok">✓</b><i class="whi">${I.wh}</i></span></label>
          </div>
        </div>
      </div>
    </div>
    <div class="pu-tabsrow">
      <div class="pu-gtabs"><button type="button" class="on" data-g="items">الأصناف</button><button type="button" data-g="exps">المصروفات</button></div>
      <label class="pu-f s w-tot"><span class="lb">الاجماليات</span><button type="button" class="pu-dots" data-a="sum">⋯</button></label>
      <label class="pu-f s w-vat"><span class="lb">الضريبة (VAT)</span><span class="pu-in"><select data-f="vat">${extendVat().map((v, i) => `<option value="${i}">${v[0]}</option>`).join("")}</select></span></label>
      <label class="pu-f s w-due"><span class="lb">تاريخ الاستحقاق</span><span class="pu-in"><input type="date" data-f="due"></span></label>
      <label class="pu-f s w-desc"><span class="lb">الوصف</span><button type="button" class="pu-ib2" data-a="desc" title="وصف الفاتورة">${I.note}</button></label>
      <label class="pu-f s w-sl"><span class="lb">شرائح الخصم</span><span class="pu-in"><select data-f="slice">${SLICES.map((v, i) => `<option value="${i}">${v[0]}</option>`).join("")}</select></span></label>
      <label class="pu-f s w-cur"><span class="lb">العملة</span><span class="pu-in"><select data-f="cur"><option>DZD</option><option>EUR</option><option>USD</option></select></span></label>
      <label class="pu-f s w-rate"><span class="lb">المعامل <i class="req">*</i></span><span class="pu-in"><input type="number" data-f="rate" value="1" min="0" step="0.01"></span></label>
    </div>
    <div class="pu-gwrap" data-g="items"><div class="pu-grid" tabindex="-1"></div></div>
    <div class="pu-gwrap" data-g="exps" hidden><div class="pu-exps"></div></div>
    <div class="pu-gsum"></div>
    <div class="pu-ft">
      <div class="pu-pay">
        <div class="pu-pr"><span class="pl">طريقة الدفع</span>
          <label class="pu-f"><span class="lb">النوع</span><span class="pu-in pu-ptype"><input type="hidden" data-f="ptype" value="cash"><button type="button" class="pt-ic" data-a="ptype" title="نقدي">${PAYT[0].ic}</button><button type="button" class="dd" data-a="ptype" tabindex="-1">⌵</button></span></label>
          <label class="pu-f w-acc"><span class="lb">اسم الحساب <i class="req">*</i></span><span class="pu-in"><select data-f="treas"></select><input data-f="acct" autocomplete="off" hidden><datalist></datalist></span></label>
          <label class="pu-f w-amt"><span class="lb">المبلغ <i class="req">*</i></span><span class="pu-in"><input data-f="paid" inputmode="decimal" autocomplete="off"><button type="button" class="dd" data-a="calcPaid" tabindex="-1">▾</button><button type="button" class="pu-okb" data-a="payDlg" title="شاشة الدفع (F7)" tabindex="-1">✓</button></span></label>
        </div>
        <div class="pu-pr"><span class="pl">الخصم</span>
          <label class="pu-f w-dt"><span class="pu-in"><select data-f="dtype"><option value="p">%</option><option value="v">قيمة</option></select></span></label>
          <label class="pu-f w-dv"><span class="pu-in"><input data-f="dval" inputmode="decimal" autocomplete="off" placeholder="0"><button type="button" class="dd" data-a="calcDisc" tabindex="-1">▾</button></span></label>
          <span class="pu-gap"></span>
        </div>
        <div class="pu-pr"><span class="pl">الملاحظات</span><label class="pu-f w-notes"><span class="pu-in"><input data-f="notes" autocomplete="off"></span></label></div>
        <div class="pu-btns">
          <button type="button" class="pu-bt g" data-a="saveNew">حفظ و جديد</button>
          <button type="button" class="pu-bt b" data-a="savePrint">حفظ وطباعة</button>
          <button type="button" class="pu-bt b car" data-a="saveMenu">▾</button>
          <button type="button" class="pu-bt b" data-a="saveClose">حفظ و إغلاق</button>
        </div>
      </div>
      <div class="pu-tots">
        ${ty.lite ? `<div class="pu-lk"><span data-lk="n" title="عدد الأصناف"></span><span data-lk="q" title="اجمالي الكمية"></span><span data-lk="fx" title="الأثر على المخزون"></span></div>` : ""}
        <div class="pu-big" data-f="big">0</div>
        <div class="pu-tl"><span>الاجمالى:</span><b data-t="before">0</b></div>
        <div class="pu-tl"><span>الخصم :</span><b data-t="disc">0</b></div>
        <div class="pu-tl"><span>الاضافى :</span><b data-t="extra">0</b></div>
        <div class="pu-tl"><span>الضرائب :</span><b data-t="tax">0</b></div>
        <div class="pu-tl g"><span>المدفوع :</span><b data-t="paid">0</b></div>
        <div class="pu-tl r"><span>الباقى :</span><b data-t="rem">0</b></div>
      </div>
    </div>
  </div>
</div>`;
  }

  /* ------------------------------------------------------------------ أعمدة الشبكة حسب طريقة العرض */
  const COLS = [
    { k: "code", t: "الكود", w: "100px", ed: "txt", m: "SPA" },
    { k: "name", t: "اسم الصنف", w: "minmax(150px,1fr)", ed: "txt", m: "CSPA" },
    { k: "qty", t: "الكميه", w: "92px", ed: "num", m: "CSPA" },
    { k: "stock", t: "الرصيد الحالي", w: "70px", m: "SPA" },
    { k: "tax", t: "يخضع للضريبة", w: "64px", ed: "chk", m: "SPA" },
    { k: "unit", t: "الوحده", w: "150px", ed: "unit", m: "CSPA" },
    { k: "price", t: "السعر", w: "86px", ed: "num", m: "CSPA" },
    { k: "dp", t: "% خصم الصنف", w: "70px", ed: "num", m: "PA" },
    { k: "disc", t: "خصم الصنف", w: "76px", ed: "num", m: "PA" },
    { k: "net", t: "صافى السعر", w: "84px", m: "PA" },
    { k: "piece", t: "سعر القطعة", w: "80px", m: "A" },
    { k: "sale", t: "سعر البيع", w: "84px", ed: "num", m: "SPA" },
    { k: "margin", t: "هامش الربح", w: "74px", m: "A" },
    { k: "total", t: "اجمالى", w: "104px", m: "CSPA" },
    { k: "notes", t: "ملاحظات", w: "130px", ed: "txt", m: "A" }
  ];
  /* أعمدة إضافية (Customization — مطابقة DEXEF): محسوبة (ro) أو تُدخل وتُحفظ مع الفاتورة (x) */
  const XC = (k, t, x, w) => ({ k, t, w: w || "92px", m: "", x });
  COLS.push(
    XC("lname", "الاسم", "ro", "160px"), XC("qtyb", "إجمالي الكميه", "ro"), XC("units", "عدد الوحدات", "ro", "78px"), XC("factor", "معامل التحويل", "ro", "78px"),
    XC("discAll", "اجمالي الخصم", "ro"), XC("discInv", "خصم الفاتورة", "ro"), XC("cashDisc", "الخصم النقدى", "ro"), XC("cumDisc", "خصم تراكمي", "ro"),
    XC("isPct", "خصم الصنف بالنسبه ؟", "ro", "100px"), XC("afterTrade", "الاجمالي بعد الخصم التجاري", "ro", "120px"), XC("extraAll", "اجمالي الاضافى", "ro"),
    XC("addCost", "تكلفة اضافية", "ro"), XC("exps", "مصروفات", "ro"), XC("landed", "التكلفه", "ro"), XC("priceTax", "السعر شامل الضريبه", "chk", "110px"),
    XC("vatVal", "قيمة ضريبة (VAT)", "ro", "100px"), XC("vatCat", "فئة ضريبة (VAT)", "ro", "96px"), XC("taxAcc", "حساب الضريبة", "ro", "120px"), XC("netAll", "الصافى", "ro"),
    XC("cashCat", "فئه الخصم النقدى", "num", "100px"), XC("wh", "المخزن", "ro", "120px"), XC("ptype", "نوع الصنف", "ro", "80px"), XC("minq", "الحد الادنى", "ro", "80px"),
    XC("laborAll", "اجمالي المصنعيه", "ro", "100px"), XC("ptsAll", "مجموع نقاط الولاء", "ro", "104px"),
    XC("labor", "مصنعيه الوحده", "num"), XC("batch", "Batch Number", "txt", "110px"), XC("lot", "رقم التشغيلة", "txt", "110px"), XC("warranty", "مدة الضمان (شهر)", "num", "100px"), XC("opts", "اخيارات", "txt", "110px"),
    XC("bonus", "البونص", "num", "74px"), XC("free", "مجانى", "chk", "70px"), XC("freeVal", "قيمة خصم المجانى", "ro", "104px"), XC("desc", "الشرح", "txt", "150px"),
    XC("color", "اللون", "txt", "90px"), XC("size", "المقاس", "txt", "80px"), XC("rep", "المندوب", "txt", "110px"), XC("supDate", "تاريخ التوريد", "date", "124px"),
    XC("expDate", "تاريخ الصلاحيه", "date", "124px"), XC("insDisc", "خصم التأمين", "num"), XC("insPct", "نسبة التأمين", "num", "84px"), XC("insSub", "يخضع للتأمين", "chk", "80px"),
    XC("qtyDisc", "خصم الكميه", "num"), XC("dtaxCat", "فئه ضريبة الخصم", "num", "104px"), XC("dtaxVal", "قيمة ضريبة الخصم", "ro", "104px"), XC("dtaxType", "نوع ضريبة الخصم", "txt", "104px"),
    XC("dtaxSub", "يخضع لضريبة الخصم", "chk", "110px"), XC("ship", "قيمه الشحن", "num", "84px"), XC("shipPct", "نسبه الشحن", "num", "80px"), XC("pts", "نقاط الولاء", "num", "80px"),
    XC("trWh", "مخزن التحويل", "txt", "110px"), XC("cc", "مركز التكلفه", "txt", "110px"), XC("subCash", "يخضع للخصم النقدى", "chk", "110px"),
    XC("hq2", "الوحدة الثانية", "num", "96px"), XC("hq3", "الوحدة الثالثة", "num", "96px"),
    XC("f1", "حقل1", "txt"), XC("f2", "حقل2", "txt"), XC("f3", "حقل3", "txt"), XC("f4", "حقل4", "txt"), XC("f5", "حقل5", "txt"), XC("f6", "حقل6", "txt"), XC("f7", "حقل7", "txt"), XC("f8", "حقل8", "txt"));
  const CMAP = {}; COLS.forEach(c => { CMAP[c.k] = c; });
  /* الوحدات الغير متجانسة (homo-units.js): اسم العمود = اسم الوحدة من «الخصائص»، ويظهر افتراضياً عند تفعيلها */
  ["hq2", "hq3"].forEach((k, i) => { const c = CMAP[k], n = i + 2;
    Object.defineProperty(c, "t", { get: () => { const H = window.ANOUER_HOMO; return (H && H.label(n)) || (n === 2 ? "الوحدة الثانية" : "الوحدة الثالثة"); } }); });
  /* ترتيب/عرض/ظهور الأعمدة لكل طريقة عرض (سحب وإفلات + تغيير العرض بالفأرة) */
  const LAYOUT = lsGet("pur.layout", {});
  function saveLayout(mode, lay) { LAYOUT[mode] = lay; lsSet("pur.layout", LAYOUT); Object.values(DOCS).forEach(d => d.syncCols()); }
  const MODE_CH = { Clean: "C", Simple: "S", Professional: "P", Advanced: "A" };

  /* ------------------------------------------------------------------ متحكم المستند */
  const DOCS = {};
  let tabSeq = 1;
  const host = document.createElement("div");
  host.className = "vw"; host.id = "vPur"; host.setAttribute("aria-label", "المشتريات");
  main.appendChild(host);

  /* «تحديد الاصناف» (مطابق DEXEF) — مشترك: الفاتورة (إضافة سريعة) وشاشات الإضافات (خصومات/بونص/تكاليف)
     o = { title, onPick(list, close) → false لإبقاء النافذة، onClose } */
  function pickItemsDlg(o) {
    closePop();
    const all = prods();
    const uniq = a => Array.from(new Set(a.filter(x => x != null && String(x).trim() !== "").map(x => String(x).trim()))).sort((x, y) => x.localeCompare(y, "ar"));
    const saleOf = p => +((defUnit(p) || {}).price) || +p.price || 0;
    const C = [
      { k: "grp", t: "المجموعة", ty: "list", opts: () => uniq(all.map(p => p.cat)), test: (p, v) => v.includes(String(p.cat || "").trim()) },
      { k: "item", t: "الصنف", ty: "list", opts: () => uniq(all.map(p => p.name)), test: (p, v) => v.includes(String(p.name || "").trim()) },
      { k: "codes", t: "أكود الأصناف", ty: "text", ph: "أكواد مفصولة بفاصلة أو مدى مثل 100-200", test: (p, v) => {
          const code = String(p.code || ""), bcs = unitsOf(p).map(u => [u.bc].concat(u.xb || []).filter(Boolean).join(" "));
          return v.split(/[,،;\s]+/).filter(Boolean).some(tok => { const m = tok.match(/^(\d+)-(\d+)$/); if (m) { const n = +code; return /^\d+$/.test(code) && n >= +m[1] && n <= +m[2]; }
            return code === tok || bcs.includes(tok) || (tok.endsWith("*") && code.startsWith(tok.slice(0, -1))); }); } },
      { k: "buy", t: "سعر الشراء", ty: "range", val: p => costOf(p, defUnit(p)) },
      { k: "bdisc", t: "خصم الشراء", ty: "na" },
      { k: "sdisc", t: "خصم البيع", ty: "na" },
      { k: "opt", t: "اخيارات", ty: "list", opts: () => ["الأصناف النشطة فقط", "رصيد صفر", "رصيد سالب", "رصيد أقل من 5", "رصيد موجب", "بدون سعر شراء", "بدون سعر بيع"],
        test: (p, v) => v.every(o => { const st = +p.stock || 0;
          return o === "الأصناف النشطة فقط" ? p.active !== false : o === "رصيد صفر" ? st === 0 : o === "رصيد سالب" ? st < 0 : o === "رصيد أقل من 5" ? st < 5 : o === "رصيد موجب" ? st > 0 : o === "بدون سعر شراء" ? !(+p.cost > 0) : o === "بدون سعر بيع" ? !(saleOf(p) > 0) : true; }) },
      { k: "maker", t: "الشركة المنتجة", ty: "na" },
      { k: "sup", t: "المورد المفضل", ty: "na" },
      { k: "kind", t: "نوع الصنف", ty: "list", opts: () => ["مخزون"], test: () => true },
      { k: "cost", t: "تكلفة الصنف", ty: "range", val: p => +p.cost || 0 },
      { k: "sale", t: "سعر البيع", ty: "range", val: p => saleOf(p) }
    ];
    const V = {};          // قيم المعايير المحددة
    let act = null;
    const ov = document.createElement("div"); ov.className = "pu-ov pu-tsov";
    ov.innerHTML = `<div class="pu-ts" role="dialog" aria-label="تحديد الاصناف" tabindex="-1">
      <div class="ts-x"><button type="button" data-x="1" aria-label="إغلاق">✕</button></div>
      <div class="ts-t">${esc(o.title || "تحديد الاصناف")}</div>
      <div class="ts-top"><label><span>اسم الفرع <i>*</i></span><span class="ts-sel"><select>${META.branches.map(b => `<option>${esc(b.name)}</option>`).join("")}</select><b>▾</b></span></label>
        <label><span>اسم المخزن <i>*</i></span><span class="ts-sel"><select><option>المخزن الرئيسي</option></select><b>▾</b></span></label></div>
      <div class="ts-hint">يمكنك استخدام الخصائص التالية للحصول على النتيجة المرغوبة</div>
      <div class="ts-mid"><div class="ts-crit">${C.map(c => `<button type="button" class="ts-c" data-c="${c.k}">${c.t}</button>`).join("")}</div><div class="ts-pane"></div></div>
      <div class="ts-ft"><button type="button" class="ts-b" data-a="go">بحث</button><button type="button" class="ts-b" data-x="1">إغلاق</button></div></div>`;
    document.body.appendChild(ov);
    const box = ov.querySelector(".pu-ts"), pane = ov.querySelector(".ts-pane");
    const crit = k => C.find(c => c.k === k);
    const has = c => { const v = V[c.k]; return v != null && (Array.isArray(v) ? v.length > 0 : typeof v === "object" ? (v.from !== "" || v.to !== "") : String(v).trim() !== ""); };
    const summary = c => { const v = V[c.k]; if (!has(c)) return ""; return Array.isArray(v) ? (v.length > 3 ? v.slice(0, 3).join(", ") + " … (+" + (v.length - 3) + ")" : v.join(", ")) : String(v); };
    function showPane() {
      const c = crit(act);
      box.querySelectorAll(".ts-c").forEach(b => { const cc = crit(b.dataset.c); b.classList.toggle("on", b.dataset.c === act); b.classList.toggle("set", has(cc)); });
      if (!c) { pane.innerHTML = ""; return; }
      if (c.ty === "list") pane.innerHTML = `<div class="ts-cb"><button type="button" class="ts-dd" data-a="dd">▾</button><input class="ts-val" readonly value="${esc(summary(c))}" title="${esc(summary(c))}"></div>`;
      else if (c.ty === "text") pane.innerHTML = `<div class="ts-cb wide"><input class="ts-val ed" data-a="txt" value="${esc(V[c.k] || "")}" placeholder="${esc(c.ph)}"></div>`;
      else if (c.ty === "range") { const v = V[c.k] || { from: "", to: "" }; pane.innerHTML = `<div class="ts-rg"><label>من<input class="ts-val ed" data-a="from" inputmode="decimal" value="${esc(v.from)}"></label><label>إلى<input class="ts-val ed" data-a="to" inputmode="decimal" value="${esc(v.to)}"></label></div>`; }
      else pane.innerHTML = `<div class="ts-na">لا توجد بيانات «${esc(c.t)}» مسجّلة للأصناف بعد</div>`;
      const f = pane.querySelector(".ed"); if (f) setTimeout(() => f.focus(), 0);
    }
    function listDrop(anchor, c) {
      const opts = c.opts(), sel = new Set(V[c.k] || []);
      const el = openPop(anchor, `<div class="ts-dl"><input class="ts-q" placeholder="بحث..." autocomplete="off"><div class="ts-items"></div><div class="ts-dft"><i>⋰</i><button type="button" data-a="cancel">Cancel</button><button type="button" data-a="ok">OK</button></div></div>`, "pu-tsdrop", { alignLeft: true });
      el.style.width = Math.max(anchor.offsetWidth, 220) + "px";
      const q = el.querySelector(".ts-q"), it = el.querySelector(".ts-items");
      const draw = () => {
        const f = norm(q.value), l = opts.filter(o => !f || norm(o).includes(f)).slice(0, 500);
        const allOn = l.length && l.every(o => sel.has(o));
        it.innerHTML = `<label class="ts-i all"><span>{All}</span><input type="checkbox" data-all="1"${allOn ? " checked" : ""}></label>` +
          l.map(o => `<label class="ts-i"><span>${esc(o)}</span><input type="checkbox" data-o="${esc(o)}"${sel.has(o) ? " checked" : ""}></label>`).join("") +
          (opts.length ? "" : '<div class="pq-empty">لا توجد قيم</div>');
      };
      q.addEventListener("input", draw);
      it.addEventListener("change", e => {
        const t = e.target;
        if (t.dataset.all) { const f = norm(q.value); opts.filter(o => !f || norm(o).includes(f)).forEach(o => t.checked ? sel.add(o) : sel.delete(o)); draw(); }
        else if (t.dataset.o != null) { t.checked ? sel.add(t.dataset.o) : sel.delete(t.dataset.o); }
      });
      el.addEventListener("click", e => {
        const b = e.target.closest("button"); if (!b) return;
        if (b.dataset.a === "ok") { V[c.k] = Array.from(sel); closePop(); showPane(); }
        else if (b.dataset.a === "cancel") closePop();
      });
      POP.key = e => { if (e.key === "Escape") { closePop(); return true; } if (e.key === "Enter" && !e.target.closest(".ts-items")) { V[c.k] = Array.from(sel); closePop(); showPane(); return true; } return false; };
      draw(); setTimeout(() => q.focus(), 0);
    }
    function results() {
      const act = C.filter(has);
      return all.filter(p => act.every(c => {
        const v = V[c.k];
        if (c.ty === "range") { const x = c.val(p), f = v.from === "" ? -Infinity : num(v.from), t = v.to === "" ? Infinity : num(v.to); return x >= f && x <= t; }
        return c.test(p, v);
      }));
    }
    const close = () => { ov.remove(); if (o.onClose) o.onClose(); };
    function go() {
      if (!C.some(has)) { say("اختر معياراً واحداً على الأقل (المجموعة، الصنف، الأكواد…)", "w"); return; }
      const l = results();
      if (!l.length) { say("لا توجد أصناف مطابقة", "w"); return; }
      if (o.onPick(l, () => ov.remove()) !== false) ov.remove();
    }
    pane.addEventListener("input", e => {
      const t = e.target, c = crit(act);
      if (t.dataset.a === "txt") V[c.k] = t.value;
      else if (t.dataset.a === "from" || t.dataset.a === "to") { V[c.k] = V[c.k] || { from: "", to: "" }; V[c.k][t.dataset.a] = t.value; }
      box.querySelectorAll(".ts-c").forEach(b => b.classList.toggle("set", has(crit(b.dataset.c))));
    });
    ov.addEventListener("click", e => {
      const b = e.target.closest("button,input.ts-val[readonly]"); if (!b) return;
      if (b.dataset.x) close();
      else if (b.dataset.c) { act = b.dataset.c; showPane(); }
      else if (b.dataset.a === "dd" || (b.matches && b.matches("input.ts-val[readonly]"))) listDrop(pane.querySelector(".ts-cb"), crit(act));
      else if (b.dataset.a === "go") go();
    });
    box.addEventListener("keydown", e => {
      if (POP) return;
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); }
      else if (e.key === "Enter" && !e.target.closest("button")) { e.preventDefault(); e.stopPropagation(); go(); }
      else if (e.key === "F4" || (e.altKey && e.key === "ArrowDown")) { const c = crit(act); if (c.ty === "list") { e.preventDefault(); listDrop(pane.querySelector(".ts-cb"), c); } }
      else if ((e.key === "ArrowDown" || e.key === "ArrowUp") && e.target.closest(".ts-crit")) {
        e.preventDefault(); const i = (act ? C.findIndex(c => c.k === act) : -1) + (e.key === "ArrowDown" ? 1 : -1); if (C[i]) { act = C[i].k; showPane(); box.querySelector(`.ts-c[data-c="${act}"]`).focus(); }
      }
    });
    showPane();
    setTimeout(() => box.querySelector(".ts-c").focus(), 0);
  }

  function Doc(key, type) {
    const ty = TY[type];
    /* مستندات العملاء: الطرف = العملاء، والسعر الافتراضي = سعر البيع حسب «السعر» (الشريحة) بدل التكلفة */
    /* «إمكانية التعامل مع الموردين خلال كل الفروع» (خصائص العملاء و الموردين) = لا ← الموردون المربوطون بفرع آخر لا يظهرون */
    const CG = () => { try { return (window.ANOUER_PROPS && ANOUER_PROPS.get("cust.gen", {})) || {}; } catch (e) { return {}; } };
    const supBrOk = sp => { if (CG().supAllBr !== false) return true; const b = sp && sp.x && String(sp.x.branch || "").trim(); if (!b) return true; const br = F("branch"), o = br && br.selectedOptions && br.selectedOptions[0]; const cur = o ? o.textContent.trim() : ""; return !cur || cur === b; };
    const SUPV = () => SUPS.filter(supBrOk);
    const PARTY = () => ty.cust ? CUSTP() : SUPV();
    const WHO = ty.cust ? "العميل" : "المورد";
    const plv = () => { const e = root.querySelector('[data-f="plv"]'); return (e && e.value) || "1"; };
    /* «تحويل الاصناف بين المخازن بسعر» (الخصائص ← الفواتير ← المرتجعات والتحويلات): التكلفة / الشراء / البيع */
    /* خصائص «فواتير المشتريات» (inv.pur) — تُطبَّق على فاتورة / مرتجع / طلبية الشراء */
    const PURDOC = type === "Purchase" || type === "PurchaseReturn" || type === "PurchaseOrder";
    const PURP = () => { try { return (PURDOC && window.ANOUER_PROPS && ANOUER_PROPS.get("inv.pur", {})) || {}; } catch (e) { return {}; } };
    const OFFD = () => { try { const v = window.ANOUER_PROPS && ANOUER_PROPS.get("inv.sale", {}); const n = v && v.offerDays != null && v.offerDays !== "" ? +v.offerDays : 10; return isFinite(n) && n >= 0 ? Math.round(n) : 10; } catch (e) { return 10; } };
    function offerDue(force) {
      const dt = F("date").value, du = F("due"); if (!dt || !du) return;
      if (!force && du.value && du.value !== du.dataset.auto) return;   /* غيّره المستخدم ← لا نلمسه */
      const n = OFFD(); if (!n) { if (force) { du.value = ""; du.dataset.auto = ""; } return; }
      const d = new Date(dt + "T12:00:00"); d.setDate(d.getDate() + n);
      const v = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
      du.value = v; du.dataset.auto = v;
    }
    if (type === "Quotation") setTimeout(() => { try { F("date").addEventListener("change", () => offerDue(false)); } catch (e) { } }, 0);
    const RETP = () => { try { return (window.ANOUER_PROPS && ANOUER_PROPS.get("inv.ret", {})) || {}; } catch (e) { return {}; } };
    const trCost = (p, u) => { const m = RETP().trPrice || "سعر التكلفة", f = (u && u.factor) || 1;
      if (m === "سعر البيع") return r2((u && +u.price) || (+p.price || 0) * f);
      if (m === "سعر الشراء") return costOfBase(p, u);
      return r2((+p.cost || 0) * f) || costOfBase(p, u); };
    const costOf = (p, u) => ty.cust ? lvPrice(p, u, plv()) : (type === "Transfer" || type === "TransferReq") ? trCost(p, u) : costOfBase(p, u);
    const root = document.createElement("div");
    root.className = "pu-doc t-" + type + (ty.cust ? " is-cust" : "") + (ty.lite ? " lite" : "") + (ty.noBan ? " no-ban" : ""); root.dataset.key = key; root.tabIndex = -1;
    root.innerHTML = docHTML(type);
    host.appendChild(root);
    const $ = s => root.querySelector(s), $$ = s => Array.from(root.querySelectorAll(s));
    const F = n => root.querySelector(`[data-f="${n}"]`);
    setTimeout(() => { try { if (window.__cfDoc) __cfDoc.mount(root, (TY[type] && TY[type].t) || "المستند"); } catch (e) { } }, 0);
    setTimeout(() => { try { if (window.__WHT && /^Purchase(Return)?$/.test(type)) { __WHT.PUR.mount(root, () => M("discTax"), () => M("discTaxDefault")); root.__whtTot = () => { const t = totals(); return { total: t.total * (CX.rate || 1), tax: t.tax * (CX.rate || 1) }; }; } } catch (e) { } }, 0);   // ضريبة الخصم والإضافة   // ✦ الحقول الإضافية فى رأس المستند
    const M = k => gm((F("mode") && F("mode").value) || "Simple", k);
    const grid = $(".pu-grid");
    const big = counter(F("big"));
    /* «حساب الأستاذ» من شجرة الحسابات الحيّة (منتقي DEXEF TreeListLookUpEdit) — يبقى data-f="gla" لباقي الكود */
    let GTP = null;
    if (ty.gla) try {
      if (window.__AC && __AC.treePicker) { const h = F("gla").parentNode; GTP = __AC.treePicker(h, { key: "gla", value: ty.gla, ph: "اختر الحساب من شجرة الحسابات" }); GTP.input.setAttribute("data-f", "gla"); h.classList.add("pu-tp"); GTP.input.addEventListener("change", () => { try { markDirty(); } catch (e) { } }); }
    } catch (e) { GTP = null; }
    function glaSet(v) { if (GTP) GTP.set(v); else if (F("gla")) F("gla").value = v; }
    /* «التعامل» (مستندات أخرى): اقتراحات من التعاملات السابقة لنفس النوع (لمستي) */
    function dealList() {
      const dl = root.querySelector(`#puDeal_${type}`); if (!dl) return;
      const seen = new Set([ty.deal || ""].filter(Boolean));
      try { (LISTS[type] || []).forEach(r => { let m = {}; try { m = r.meta ? JSON.parse(r.meta) : {}; } catch (e) { } if (m.deal) seen.add(m.deal); }); } catch (e) { }
      (type === "Waste" ? ["تلف", "انتهاء الصلاحية", "كسر أثناء النقل", "سرقة / فقدان"] : type === "Charity" ? ["صدقة", "زكاة", "تبرع لجمعية"] : []).forEach(x => seen.add(x));
      dl.innerHTML = Array.from(seen).map(x => `<option value="${esc(x)}">`).join("");
    }
    /* ---------- العملة: أسعار المستند بعملة الفاتورة (سعر البنك افتراضياً — fx-rates.js) والحفظ بالدينار ---------- */
    const CX = { code: "DZD", rate: 1 };
    const FXM = () => window.ANOUER_FX;
    function cxOpts() { const s = F("cur"); if (!s) return; const v = CX.code, l = FXM() ? FXM().codes() : ["DZD", "EUR", "USD"]; s.innerHTML = l.map(c => `<option value="${c}">${c}</option>`).join(""); s.value = l.includes(v) ? v : "DZD"; }
    function cxPaint() {
      const on = CX.code !== "DZD", bg = F("big"), s = F("cur"), fx = FXM();
      if (bg) { if (on) bg.dataset.cur = fx ? fx.symOf(CX.code) : CX.code; else delete bg.dataset.cur; }
      if (s) s.classList.toggle("cx-on", on);
      let n = root.querySelector(".pu-cxn"); const w = root.querySelector(".w-rate");
      if (!n && w) { n = document.createElement("span"); n.className = "pu-cxn"; w.appendChild(n); }
      if (n) { n.textContent = on ? (fx ? ({ official: "سعر البنك", buy: "السكوار شراء", sell: "السكوار بيع" })[fx.cfg().purSrc] || "" : "") : ""; n.title = on ? "1 " + CX.code + " = " + CX.rate + " دج" : ""; }
    }
    function cxSet(code, rate, quiet) {
      code = String(code || "DZD").toUpperCase(); const fx = FXM();
      rate = +rate > 0 ? +rate : (fx ? fx.docRate(code, "pur") : 1);
      const old = CX.rate, k = old / rate;
      if (S) S.rows.forEach(r => {
        const edited = r._cxp == null || Math.abs((+r.price || 0) - r._cxp) > .0001;
        if (edited || r._bp == null) r._bp = (+r.price || 0) * old;
        if (r._blc == null) r._blc = (+r.lastCost || 0) * old;
        r.price = rate === 1 ? r2(r._bp) : r2(r._bp / rate); r._cxp = r.price; r.lastCost = r2(r._blc / rate);
        if (r.dp) applyDp(r); else if (+r.disc) r.disc = r2(r.disc * k);
      });
      const pd = F("paid"); if (pd && num(pd.value)) pd.value = r2(num(pd.value) * k);
      CX.code = code; CX.rate = rate; F("cur").value = code; F("rate").value = rate;
      if (S) { S.dirty = S.dirty || !!S.rows.length; renderAll(); }
      cxPaint();
      if (!quiet) say(code === "DZD" ? "المستند بالدينار الجزائري" : `المستند بـ ${fx ? fx.nameOf(code) : code} — 1 ${code} = ${rate} دج`, "s");
    }
    F("cur").addEventListener("change", () => cxSet(F("cur").value));
    F("rate").addEventListener("change", () => { const v = num(F("rate").value); if (v > 0 && CX.code !== "DZD") cxSet(CX.code, v, true); else F("rate").value = CX.rate; });
    window.addEventListener("anouer:props", e => { if (e.detail && e.detail.key === "sys.currencies") cxOpts(); });
    let S;          // حالة المستند
    let hidden = lsGet("pur.hiddenCols", {});
    const D = { key, type, root };
    const curWh = () => { const v = F("wh") && F("wh").value; return v === "" || v == null ? (+WHM().main || 0) : +v || 0; };
    const whName = () => { const o = F("wh") && F("wh").selectedOptions[0]; return o ? o.textContent : WHM().nameOf(curWh()); };
    const whQty = pid => WHM().qty(pid, curWh());

    function blank() {
      return { id: 0, no: "", rows: [], sel: -1, supId: 0, credit: false, paidTouched: false, exps: [],
        parentId: 0, dirty: false, loadedAt: null };
    }
    function reset(keepFocus) {
      closePop();
      F("mode").value = lsGet("pur.mode." + type, "Simple");
      S = blank(); D.itemCard = 0;
      if (D.draftId) { if (!D.draftManual) DR.del(D.draftId).catch(() => { }); D.draftId = 0; D.draftManual = false; clearTimeout(D._drT); D._drP = 0; paintDraft(null); }
      F("supName").value = ""; F("supCode").value = ""; F("ref").value = ""; F("prefix").value = ""; F("no").value = ""; if (window.__cfDoc) __cfDoc.reset(root); if (window.__WHT) __WHT.PUR.reset(root);
      F("date").value = today(); F("due").value = ""; F("notes").value = ""; F("dval").value = ""; F("dtype").value = "p";
      /* عرض السعر: «صالح حتى» = التاريخ + «فترة سريان عرض السعر» (خصائص ← فواتير المبيعات) — يتحرك مع التاريخ ما لم يُغيَّر يدوياً */
      if (type === "Quotation") offerDue(true);
      F("paid").value = ""; F("slice").value = "0"; CX.code = "DZD"; CX.rate = 1; cxOpts(); F("cur").value = "DZD"; F("rate").value = "1"; cxPaint();
      F("vat").value = String(Math.max(0, VAT.findIndex(v => v[1] === +M("vatDefault"))));
      setCredit(false, true);
      setPType("cash", true);
      D.desc = ""; D.pend = null;
      if (ty.gla) glaSet(ty.gla);
      if (ty.lite && F("deal")) { F("deal").value = ty.deal || ""; dealList(); }
      if (ty.side) F("trWh").value = "";
      refreshMeta(); renderAll();
      if (!keepFocus) setTimeout(focusFirst, 0);
      applyDefSup();
    }
    /* «المورد الافتراضى عند فتح الفاتورة» (خصائص العملاء و الموردين) — فاتورة/مرتجع/طلبية الشراء فقط */
    function applyDefSup() {
      if (ty.cust || !/^(Purchase|PurchaseReturn|PurchaseOrder)$/.test(type)) return;
      const nm = String(CG().defSup || "").trim(); if (!nm || nm === "عميل نقدى") return;
      const put = () => { if (S.supId || F("supName").value) return; const sp = SUPV().find(x => norm(x.name) === norm(nm)); if (sp) setSupplier(sp, true); };
      if (SUPS.length) put(); else loadSups().then(put).catch(() => { });
    }
    function focusFirst() { const n = grid.querySelector(".pu-new [data-c=name]"); if (n && root.offsetParent) n.focus(); }

    function refreshMeta() {
      const br = F("branch"), cb = br.value;
      br.innerHTML = META.branches.map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join("");
      if (cb) br.value = cb;
      const tr = F("treas"), ct = tr.value;
      tr.innerHTML = META.treasuries.map(t => `<option value="${t.id}">${esc(t.name)}</option>`).join("");
      if (ct) tr.value = ct;
      const st = F("status"), cs = st.value;
      st.innerHTML = ty.cust ? CST[type].map(x => `<option value="${x[0]}">${x[1]}</option>`).join("") : ty.req ? `<option value="open">مفتوحة</option><option value="done">${ty.store ? "تم التنفيذ" : "تم الاستلام"}</option><option value="cancel">ملغاة</option>`
        : '<option value=""></option><option value="ok">معتمدة</option><option value="review">تحت المراجعة</option>';
      if (cs) st.value = cs;
      const wh = F("wh"), cw = wh.value || (D.whId != null ? String(D.whId) : "");
      wh.innerHTML = WHM().options(cw); if (cw !== "" && wh.querySelector(`option[value="${cw}"]`)) wh.value = cw;
      if (ty.side) {
        const tw = F("trWh"), ctw = tw.value || (D.toWhId ? String(D.toWhId) : ""), tb = F("trBr"), ctb = tb.value;
        tw.innerHTML = WHM().options(ctw, true); if (ctw && tw.querySelector(`option[value="${ctw}"]`)) tw.value = ctw;
        tb.innerHTML = META.branches.map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join(""); if (ctb) tb.value = ctb;
      }
      F("no").placeholder = S && S.id ? "" : (META.next[type] || "1");
    }
    function applySettings() {
      try { if (window.__WHT) __WHT.PUR.refresh(root); } catch (e) { }
      root.classList.toggle("no-exp", !M("expenses"));
      root.classList.toggle("no-due", !M("due"));
      root.classList.toggle("no-sl", !M("slices"));
      root.classList.toggle("no-vat", !M("vat"));
      root.classList.toggle("no-cur", !M("currency"));
      root.classList.toggle("no-tot", !M("totals"));
      root.classList.toggle("no-track", !gt(type, "track"));
      const col = gt(type, "color") || ty.c;
      root.style.setProperty("--tc", col);
      const bn = root.querySelector(".pu-banner"); if (bn) bn.style.setProperty("--bc", col);
      [["before", "tBefore"], ["disc", "tDisc"], ["extra", "tExtra"], ["tax", "tTax"], ["paid", "tPaid"], ["rem", "tRem"]].forEach(x => {
        const e = root.querySelector(`[data-t="${x[0]}"]`); if (e) e.parentElement.classList.toggle("off", !gt(type, x[1])); });
      root.classList.toggle("no-pay", !ty.pay);
      root.classList.toggle("is-store", !!ty.store);
      root.classList.toggle("st-light", !!ty.store && type !== "StockIn" && type !== "StockOut");
      renderAll();
    }

    /* ---------- الحساب ---------- */
    function vatRate() { return (VAT[+F("vat").value] || VAT[0])[1]; }
    /* ===== حساب السطر مطابق DEXEF ONE (CtlGrid.FinalGridCalc) =====
       • السعر شامل الضريبه ✔ ← يُستخرج منه جزء الضريبة: السعر الصافي = السعر ÷ (1 + النسبة)
       • خصم الصنف + خصم الكميه + الخصم النقدى (فئه الخصم النقدى % × الصافي قبله ، إن كان «يخضع للخصم النقدى»)
       • مجانى ✔ ← كل الخصومات صفر وقيمة السطر كلها «قيمة خصم المجانى»
       • الاضافى على السطر: اجمالى المصنعيه (الكمية × مصنعيه الوحده) + قيمه الشحن (أو نسبه الشحن % من الاجمالي) */
    const xn = (r, k) => num((r.x || {})[k]);
    const isFree = r => !!(r.x && r.x.free);
    /* نسبة ضريبة السطر: نسبة الصنف الخاصة («نعم» في بطاقة الصنف ← الحسابات) أو نسبة الفاتورة */
    const IA = () => window.ANOUER_IACC, BUY = !ty.cust;
    function rateOf(r) { const v = vatRate(); return r.pid && IA() && v > 0 ? IA().rate(r.pid, v, BUY) || v : v; }
    function vatOf(r) { return r.tax ? rateOf(r) : 0; }
    function effPrice(r) { const pr = +r.price || 0, t = vatOf(r); return r.x && r.x.priceTax && t > 0 ? pr / (1 + t) : pr; }
    function lineGross(r) { return (+r.qty || 0) * effPrice(r); }
    /* خصم تراكمي = نسبة «شرائح الخصم» × (الاجمالي − خصم الصنف − خصم الكميه) */
    function slicePct() { const e = F("slice"); return e ? (SLICES[+e.value] || SLICES[0])[1] || 0 : 0; }
    function groupOf(r) { if (isFree(r)) return 0; const pc = slicePct(); return pc ? r2(Math.max(0, lineGross(r) - r2(r.disc || 0) - xn(r, "qtyDisc")) * pc / 100) : 0; }
    function cashDiscOf(r) { if (isFree(r)) return 0; const x = r.x || {}, pc = num(x.cashCat); if (!pc || x.subCash === false) return 0; return r2(Math.max(0, lineGross(r) - r2(r.disc || 0) - xn(r, "qtyDisc") - groupOf(r)) * pc / 100); }
    function lineDisc(r) { return isFree(r) ? r2(lineGross(r)) : r2((r.disc || 0) + xn(r, "qtyDisc") + groupOf(r) + cashDiscOf(r)); }
    /* ضريبة الخصم (DAT) = فئه ضريبة الخصم % × (الاجمالي − اجمالي الخصم) لكل سطر «يخضع لضريبة الخصم» — تُطرح من إجمالي الفاتورة */
    function datOf(r, k) { const x = r.x || {}; if (isFree(r) || !x.dtaxSub) return 0; const pc = num(x.dtaxCat); return pc ? r2((lineGross(r) - lineDisc(r)) * (k == null ? headFactor() : k) * pc / 100) : 0; }
    function shipOf(r) { const pc = xn(r, "shipPct"); return pc ? r2(lineGross(r) * pc / 100) : xn(r, "ship"); }
    function laborOf(r) { return r2((+r.qty || 0) * xn(r, "labor")); }
    function rowExtra(r) { return isFree(r) ? 0 : r2(laborOf(r) + shipOf(r)); }
    /* إجمالى الكميه بالوحدة الصغرى (الكمية + البونص) × عدد الوحدات */
    function totQty(r) { return ((+r.qty || 0) + xn(r, "bonus")) * (r.factor || 1); }
    /* ===== المصروفات (DEXEF CtlExtraGrid):
       القيمه بعمله الفاتوره = القيمة × المعامل ، الضريبة = فئه الضريبه % × القيمة (أو ضريبة الفاتورة «كما بالفاتورة») ، الاجمالي = القيمة + الضريبة
       كل مصروف يُوزَّع على الأصناف (كلها أو أصناف محددة) بالقيمة أو بالكمية ← عمود «مصروفات» ويدخل تكلفة الصنف ،
       ونوع «يضاف على الفاتورة» فقط يزيد فاتورة المورد (الاضافى + ضريبته) */
    function expN(x) { x = x || {}; return { name: x.name || "", amt: +x.amt || 0, alloc: x.alloc || "AmountDiv", pay: x.pay || "Customer", acct: x.acct == null ? "" : String(x.acct), all: x.all !== false, items: Array.isArray(x.items) ? x.items.map(String) : [], cur: x.cur || "", rate: +x.rate || 1, taxable: x.taxable || "No", taxPerc: +x.taxPerc || 0, notes: x.notes || "", cc: x.cc || "" }; }
    const expInv = x => r2((+x.amt || 0) * (+x.rate || 1));
    const expPc = x => x.taxable === "Yes" ? (+x.taxPerc || 0) : x.taxable === "Invoice" ? r2(vatRate() * 100) : 0;
    const expTax = x => r2(expInv(x) * expPc(x) / 100);
    const expNet = x => r2(expInv(x) + expTax(x));
    const isInvExp = x => (x.pay || "Customer") === "Customer";
    let EA = null;
    function expAlloc() {
      if (EA && EA.n === S.rows.length && EA.e === S.exps) return EA;
      const n = S.rows.length, all = new Array(n).fill(0), inv = new Array(n).fill(0);
      const hk = headFactor();
      S.exps.forEach(x => {
        const a = expInv(x); if (!a) return;
        const el = []; S.rows.forEach((r, i) => { if (x.all !== false || (x.items || []).includes(String(r.code))) el.push(i); });
        const w = el.map(i => x.alloc === "QtyDiv" ? totQty(S.rows[i]) : Math.max(0, lineTotal(S.rows[i]) * hk + rowExtra(S.rows[i])));
        const tw = w.reduce((s2, v) => s2 + v, 0); if (!(tw > 0)) return;
        el.forEach((i, k) => { const sh = a * w[k] / tw; all[i] += sh; if (isInvExp(x)) inv[i] += sh; });
      });
      EA = { n, e: S.exps, all: all.map(r2), inv: inv.map(r2) };
      return EA;
    }
    const expShare = (r, onlyInv) => { const i = S.rows.indexOf(r), a = expAlloc(); return i < 0 ? 0 : (onlyInv ? a.inv[i] : a.all[i]) || 0; };
    /* صافي تكلفة السطر (DEXEF NetTotal) = الاجمالي − كل الخصومات + الاضافى + المصروفات الموزعة */
    function rowNetCost(r) { if (isFree(r)) return 0; return r2(lineTotal(r) * headFactor() + rowExtra(r) + expShare(r)); }
    /* الضريبة بعد خصم الفاتورة (موزّعاً بنسبة صافي كل سطر) */
    function headFactor() {
      let base = 0; S.rows.forEach(x => { base += lineGross(x) - lineDisc(x); });
      if (base <= 0) return 1;
      const dv = num(F("dval").value), hd = F("dtype").value === "p" ? base * Math.min(100, Math.max(0, dv)) / 100 : Math.max(0, dv);
      return Math.max(0, (base - hd) / base);
    }
    function lineTax(r, k) { return r.tax ? r2((lineGross(r) - lineDisc(r)) * rateOf(r) * (k == null ? headFactor() : k)) : 0; }
    function lineTotal(r) { return r2(lineGross(r) - lineDisc(r)); }
    function totals() {
      let before = 0, ld = 0, tx = 0, q = 0, dat = 0;
      const hk = headFactor();
      S.rows.forEach(r => { before += lineGross(r); ld += lineDisc(r); tx += lineTax(r, hk); dat += datOf(r, hk); q += +r.qty || 0; });
      dat = r2(dat);
      const exps = r2(S.exps.reduce((s, x) => s + (isInvExp(x) ? expInv(x) : 0), 0)), etax = r2(S.exps.reduce((s, x) => s + (isInvExp(x) ? expTax(x) : 0), 0));
      const expAll = r2(S.exps.reduce((s, x) => s + expInv(x), 0)), extra = r2(exps + S.rows.reduce((s, x) => s + rowExtra(x), 0));
      const dv = num(F("dval").value), base = before - ld;
      const hd = r2(F("dtype").value === "p" ? base * Math.min(100, Math.max(0, dv)) / 100 : Math.max(0, dv));
      const total = r2(before - ld - hd + extra + tx + etax - dat);
      let paid = 0;
      if (ty.pay) paid = S.credit ? Math.min(Math.max(0, num(F("paid").value)), Math.max(0, total)) : total;
      return { before: r2(before), ld: r2(ld), hd, dat, disc: r2(ld + hd + dat), extra, exps, expAll, etax, tax: r2(tx + etax), total, paid: r2(paid), rem: r2(total - paid), q: r2(q) };
    }
    function updTotals() {
      EA = null;
      const t = totals();
      if (ty.pay && !S.credit) F("paid").value = fmt(t.total);
      Object.keys(t).forEach(k => { const e = root.querySelector(`[data-t="${k}"]`); if (e) e.textContent = fmt(t[k]); });
      big.to(t.total);
      const gs = $(".pu-gsum");
      const vis = visCols();
      gs.style.gridTemplateColumns = gridTpl(vis);
      gs.innerHTML = `<div></div>` + vis.map(c => `<div>${c.k === "qty" ? fmt(t.q) : c.k === "total" ? fmt(t.before) : c.k === "name" ? (S.rows.length ? S.rows.length + " صنف" : "") : ""}</div>`).join("") + `<div></div>`;
      root.querySelector('[data-a="sum"]').title = `الاجمالى ${fmt(t.before)} — الخصم ${fmt(t.disc)}${t.dat ? " (منها ضريبة الخصم " + fmt(t.dat) + ")" : ""} — الاضافى ${fmt(t.extra)} — الضرائب ${fmt(t.tax)} — الصافي ${fmt(t.total)}`;
      updBal(t);
      if (ty.lite) {   /* لمستي: عدد الأصناف + الكمية + الأثر على المخزون */
        const n = S.rows.filter(r => r.pid).length, q = r2(t.q || 0), sg = ty.dir > 0 ? "+" : ty.dir < 0 ? "−" : "";
        const L = k => root.querySelector(`[data-lk="${k}"]`);
        if (L("n")) { L("n").innerHTML = `<i>الأصناف</i><b>${n}</b>`; L("q").innerHTML = `<i>الكمية</i><b>${fmt(q)}</b>`; L("fx").innerHTML = `<i>المخزون</i><b class="${ty.dir < 0 ? "dn" : "up"}">${q ? sg + fmt(q) : "0"}</b>`; }
      }
      try { if (window.updTabBadges) updTabBadges(); } catch (e) { }
      return t;
    }
    /* «إعادة التوزيع» (DEXEF FrmBill › BtnResum → ClsBeforeSaveGrid.StartCalc):
       1) خصم الفاتورة يُعاد توزيعه على الأصناف بنسبة صافي كل سطر (DiscountTrade)
       2) المصروفات تُنفَّذ من جديد على الأصناف (ExcuteExpenses → ExtraPormotion)
       3) الشحن يُعاد حسابه من نسبته (calcShippingValue) — ثم تُحدَّث الأعمدة والإجماليات */
    function redistribute(btn) {
      if (!S.rows.length) { say("لا توجد أصناف لإعادة التوزيع", "i"); return; }
      EA = null;
      S.rows.forEach((r, j) => renderRow(j));
      const t = updTotals();
      try { if (!$(".pu-exps").closest("[hidden]")) renderExps(); } catch (e) { }
      const a = expAlloc(), n = S.rows.length;
      const ship = S.rows.reduce((s, r) => s + shipOf(r), 0);
      say("تمت إعادة التوزيع على " + n + " صنف" + (t.hd ? " — خصم الفاتورة " + fmt(t.hd) : "") + (t.expAll ? " — المصروفات " + fmt(r2(a.all.reduce((s, v) => s + v, 0))) : "") + (ship ? " — الشحن " + fmt(r2(ship)) : ""), "s");
      const g = $(".pu-grid"); if (g) { g.classList.remove("pu-flash"); void g.offsetWidth; g.classList.add("pu-flash"); }
      if (btn) { btn.classList.remove("pu-flash"); void btn.offsetWidth; btn.classList.add("pu-flash"); }
    }
    function supById(id) { return PARTY().find(s => s.id == id); }
    function updBal(t) {
      const s = supById(S.supId), el = F("balInfo");
      if (ty.store || !s || !gt(type, "showBal")) { el.innerHTML = ""; return; }
      const after = s.bal + (type === "Purchase" ? t.rem : type === "PurchaseReturn" ? -t.rem : 0);
      el.innerHTML = `<span>رصيد ${WHO}</span><b class="${s.bal < 0 ? "neg" : ""}">${fmt(s.bal)}</b>${ty.pay ? `<span>بعد الفاتورة</span><b class="${after < 0 ? "neg" : ""}">${fmt(after)}</b>` : ""}${gt(type, "limitWarn") && s.lim && after > s.lim ? '<em title="تجاوز حد الإئتمان">⚠ تجاوز حد الإئتمان</em>' : ""}`;
    }

    /* ---------- الشبكة ---------- */
    const layId = () => ty.store ? "st." + type : ty.cust ? "q." + F("mode").value : F("mode").value;
    const CUST_HIDE = { stock: 1, tax: 1, sale: 1, margin: 1 };   // عرض السلعة / أمر توريد (مطابق DEXEF): بلا الرصيد وسعر البيع وهامش الربح
    function layKeys() {
      const mode = F("mode").value, ch = MODE_CH[mode] || "S", lay = LAYOUT[layId()];
      let keys = lay && lay.order ? lay.order.filter(k => CMAP[k]) : ty.store ? ty.cols.slice() : COLS.filter(c => c.m.includes(ch) && !hidden[c.k] && !(ty.cust && CUST_HIDE[c.k])).map(c => c.k);
      if (!keys.includes("name")) keys.unshift("name");
      /* الوحدات الغير متجانسة: تظهر بعد «الكميه» أول مرة تُفعَّل (ولو كان للمستخدم ترتيب محفوظ) — وإن أخفاها بعدها تبقى مخفية */
      try { const H = window.ANOUER_HOMO; if (H && !ty.store) ["hq3", "hq2"].forEach((k, j) => { const n = 3 - j; if (!H.on(n) || keys.includes(k) || hidden[k]) return;
        if (lay && lay.order) { lay.homoSeen = lay.homoSeen || {}; if (lay.homoSeen[k]) return; lay.homoSeen[k] = 1; lay.order.splice(Math.max(0, lay.order.indexOf("qty") + 1), 0, k); lsSet("pur.layout", LAYOUT); }
        keys.splice(Math.max(0, keys.indexOf("qty") + 1), 0, k); }); } catch (e) { }
      return keys;
    }
    function visCols() {
      const lay = LAYOUT[layId()] || {}, w = lay.w || {};
      return layKeys().filter(k => !(k === "tax" && !M("vat"))).map(k => w[k] ? Object.assign({}, CMAP[k], { w: w[k] + "px" }) : CMAP[k]);
    }
    function setLayout(keys, widths) {
      const mode = layId(), cur = LAYOUT[mode] || {};
      saveLayout(mode, { order: keys, w: Object.assign({}, cur.w || {}, widths || {}) });
    }
    /* الأعمدة تتقاسم عرض الشبكة بالنسبة (مثل DEXEF): إضافة عمود تُصغّر البقية بدل ظهور شريط أفقي وإطار أبيض */
    function fitW(w) {
      w = String(w || "80px"); let m = /^minmax\((\d+)px,\s*1fr\)$/.exec(w);
      if (m) return `minmax(${Math.round(+m[1] * .55)}px,${+m[1] + 60}fr)`;
      m = /^(\d+(?:\.\d+)?)px$/.exec(w);
      if (m) { const px = +m[1]; return `minmax(${Math.min(px, Math.max(30, Math.round(px * .42)))}px,${px}fr)`; }
      return w;
    }
    function gridTpl(vis) { return "44px " + vis.map(c => fitW(c.w)).join(" ") + " 34px"; }
    /* قيم الأعمدة المحسوبة: حصة السطر من خصم الفاتورة والمصروفات */
    function shares() {
      let base = 0; S.rows.forEach(x => { base += lineTotal(x); });
      const t = totals();
      return { base, hd: t.hd, extra: t.exps };
    }
    function xCell(c, r) {
      const x = r.x || {}, v = x[c.k];
      if ((c.k === "hq2" || c.k === "hq3") && r.pid && !(window.ANOUER_HOMO && ANOUER_HOMO.isHomo(r.pid))) return `<input data-c="x:${c.k}" class="n hq-off" value="" disabled placeholder="—" tabindex="-1" title="الصنف بوحدات متجانسة">`;
      if (c.k === "hq2" || c.k === "hq3") { const ph = window.ANOUER_HOMO ? ANOUER_HOMO.ph(r.pid, c.k === "hq2" ? 2 : 3) : ""; return `<input data-c="x:${c.k}" class="n hq-on" value="${v ? esc(v) : ""}" inputmode="decimal" autocomplete="off" placeholder="${esc(ph)}" title="${esc(ph)}">`; }
      if (c.x === "txt") return `<input data-c="x:${c.k}" value="${esc(v == null ? "" : v)}" autocomplete="off">`;
      if (c.k === "ship" && xn(r, "shipPct")) return `<input data-c="x:ship" class="n" value="${esc(fmt(shipOf(r)))}" readonly tabindex="-1" title="محسوبة من نسبه الشحن">`;
      if (c.x === "num") return `<input data-c="x:${c.k}" class="n" value="${v ? esc(v) : ""}" inputmode="decimal" autocomplete="off">`;
      if (c.x === "date") return `<input data-c="x:${c.k}" type="date" value="${esc(v || "")}">`;
      if (c.x === "chk") { const on = v == null ? c.k === "subCash" : !!v; return `<input type="checkbox" data-c="x:${c.k}"${on ? " checked" : ""}>`; }
      const sh = shares(), lt = lineTotal(r), part = sh.base > 0 ? lt / sh.base : 0, q = +r.qty || 0, f = r.factor || 1;
      const hd = r2(sh.hd * part), ex = expShare(r), exInv = expShare(r, true), tx = lineTax(r), g = lineGross(r), free = isFree(r);
      const ro = (val, cls) => `<span class="pu-ro${cls ? " " + cls : ""}">${val}</span>`;
      const nz = v => v ? fmt(v) : "0";
      switch (c.k) {
        case "lname": return ro(esc(r.name), "u");
        case "qtyb": return ro(fmt(totQty(r)));                                   // TotalQty = عدد الوحدات × (الكميه + البونص)
        case "units": return ro(fmt(f));                                           // UniteQty
        case "factor": return ro(fmt(num(F("rate").value) || 1));                  // Rate = معامل تحويل العملة
        case "discInv": return ro(nz(hd));                                         // DiscountTrade
        case "cashDisc": return ro(nz(cashDiscOf(r)));                             // DiscountCash
        case "cumDisc": return ro(nz(groupOf(r)));                                 // DiscountGroup (شرائح الخصم)
        case "discAll": return ro(nz(free ? 0 : r2(lineDisc(r) + hd)));            // TotalDiscount
        case "isPct": return ro(r.dp > 0 ? "نعم" : "لا", "u");
        case "afterTrade": return ro(fmt(free ? g : r2(g - groupOf(r) - (+r.disc || 0) - hd - cashDiscOf(r))));   // PriceAfterDiscount
        case "extraAll": return ro(nz(r2(rowExtra(r) + ex)));                      // المصنعيه + الشحن + المصروفات
        case "addCost": return ro(nz(exInv));                                     // BillExtra (المصروفات المضافة على الفاتورة)
        case "exps": return ro(nz(ex));                                            // ExtraPormotion (كل المصروفات الموزعة)
        case "landed": return ro(fmt(r.lastCost || 0));                            // ItemCost: تكلفة الوحدة في كارت الصنف
        case "vatVal": return ro(nz(tx));
        case "vatCat": return ro(r.tax && vatRate() ? fmt(vatRate() * 100) + "%" : "0");
        case "taxAcc": return ro(r.tax && vatRate() ? "ضريبة القيمة المضافة" : "", "u");
        case "netAll": return ro(fmt(free ? 0 : r2(lt - hd + rowExtra(r) + ex)), "b");  // NetTotal (بدون الضريبة مثل DEXEF)
        case "freeVal": return ro(nz(free ? r2(g) : 0));                            // FreeDiscount
        case "dtaxVal": return ro(nz(datOf(r)));                                   // DAT
        case "wh": return ro(esc(whName()), "u");
        case "ptype": return ro("مخزون", "u");
        case "minq": { const inf = INFO[r.pid], pp = prodById(r.pid); return ro(fmt((inf && inf.data && +inf.data.reorder) || (pp && +pp.min) || 0)); }
        case "laborAll": return ro(nz(laborOf(r)));                                // ExtraCost
        case "ptsAll": return ro(nz(r2(totQty(r) * xn(r, "pts"))));                // RewardPoints = TotalQty × ItemPoints
      }
      return "";
    }
    function cellHTML(c, r, i) {
      const p = prodById(r.pid), u = p ? unitByName(p, r.unit) : null, f = (u && u.factor) || r.factor || 1;
      switch (c.k) {
        case "code": return `<div class="hlw"><span class="hlb"></span><input data-c="code" value="${esc(r.code)}" autocomplete="off"></div>`;
        case "name": { const dn = window.ANOUER_UNAME && r.pid ? ANOUER_UNAME.forLine(r.name, r.unit, r.pid) : r.name; return `<div class="hlw"><span class="hlb"></span><input data-c="name" value="${esc(dn)}" autocomplete="off" title="${esc(dn)}"><button type="button" class="pu-dd rdd" data-a="rdd" tabindex="-1" title="تبديل الصنف (F4)"><svg viewBox="0 0 10 6" width="9" height="6"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.4"/></svg></button></div>`; }
        case "qty": {
          const warn = (type === "PurchaseReturn" || ty.out) && p && (+r.qty || 0) * f > whQty(p.id);
          return `<input data-c="qty" class="n${warn ? " warn" : ""}" value="${esc(r.qty)}" inputmode="decimal" autocomplete="off"${warn ? ' title="الكمية أكبر من رصيد المخزون"' : ""}>`;
        }
        case "stock": { const s = p ? whQty(p.id) : 0, rs = p ? WHM().reserved(p.id, curWh()) : 0; return `<span class="pu-ro${s < 0 ? " neg" : ""}" title="${p ? "رصيد «" + esc(whName()) + "»" + (f > 1 ? " = " + fmt(s / f) + " " + esc(r.unit) : "") + (rs ? " — المحجوز " + fmt(rs) : "") + " — الرصيد الكلي " + fmt(+p.stock || 0) : ""}">${p ? fmt(s) : ""}</span>`; }
        case "tax": return `<input type="checkbox" data-c="tax"${r.tax ? " checked" : ""}>`;
        case "unit": {
          const us = p ? unitsOf(p) : [];
          return us.length > 1 ? `<select data-c="unit">${us.map(x => `<option${x.name === r.unit ? " selected" : ""}>${esc(x.name)}</option>`).join("")}</select>`
            : `<span class="pu-ro u">${esc(r.unit || "")}</span>`;
        }
        case "price": {
          const last = r.lastCost || 0, up = last && r.price > last + .001, dn = last && r.price < last - .001;
          return `<input data-c="price" class="n${up ? " up" : dn ? " dn" : ""}" value="${esc(r.price)}" inputmode="decimal" autocomplete="off" title="${last ? "آخر تكلفة: " + fmt(last) + (f > 1 ? " — القطعة: " + fmt(r.price / f) : "") : ""}">`;
        }
        case "dp": return `<input data-c="dp" class="n" value="${r.dp ? esc(r.dp) : ""}" inputmode="decimal" autocomplete="off">`;
        case "disc": return `<input data-c="disc" class="n" value="${r.disc ? esc(r2(r.disc)) : ""}" inputmode="decimal" autocomplete="off">`;
        case "net": {   // صافى السعر = (الاجمالي − الخصومات + الاضافى) ÷ إجمالى الكميه ← سعر القطعة الصافي داخل الوحدة الكبرى (مثل DEXEF)
          const sh = shares(), lt = lineTotal(r), part = sh.base > 0 ? lt / sh.base : 0, tq = totQty(r);
          const nt = isFree(r) ? 0 : lt - sh.hd * part + rowExtra(r) + expShare(r);
          return `<span class="pu-ro" title="${tq ? esc(fmt(nt)) + " ÷ " + esc(fmt(tq)) : ""}">${fmt(tq ? nt / tq : effPrice(r) / f)}</span>`;
        }
        case "piece": return `<span class="pu-ro">${fmt((r.qty ? lineTotal(r) / r.qty : r.price) / f)}</span>`;
        case "sale": {
          const net = r.qty ? lineTotal(r) / r.qty : +r.price || 0, loss = r.sale > 0 && r.sale < net - .001;
          /* «هل تريد التعديل على سعر البيع أثناء فاتورة المشتريات؟ = لا» ← عرض فقط */
          if (PURP().editSale === false) return `<span class="pu-ro${loss ? " neg" : ""}" title="${esc(loss ? "سعر البيع أقل من سعر الشراء!" : "تعديل سعر البيع من الفاتورة مقفول (الخصائص ← فواتير المشتريات)")}">${r.sale ? fmt(r.sale) : ""}</span>`;
          return `<input data-c="sale" class="n${loss ? " loss" : ""}${r.sale !== r.sale0 ? " chg" : ""}" value="${esc(r.sale || "")}" inputmode="decimal" autocomplete="off" title="${esc([loss ? "سعر البيع أقل من سعر الشراء!" : r.sale !== r.sale0 ? "سيُحدَّث سعر البيع عند الحفظ (كان " + fmt(r.sale0) + ")" : "", linkedTxt(r)].filter(Boolean).join(" — "))}">`;
        }
        case "margin": { const net = r.qty ? lineTotal(r) / r.qty : +r.price || 0; const m = net > 0 && r.sale ? (r.sale - net) / net * 100 : 0; return `<span class="pu-ro${m < 0 ? " neg" : ""}">${net && r.sale ? fmt(m) + "%" : ""}</span>`; }
        case "total": return `<span class="pu-ro b" title="${r.disc || lineDisc(r) ? "بعد الخصم: " + esc(fmt(lineTotal(r))) : ""}">${fmt(lineGross(r))}</span>`;   // Total = السعر × الكميه
        case "notes": return `<input data-c="notes" value="${esc(r.notes || "")}" autocomplete="off">`;
      }
      return c.x ? xCell(c, r) : "";
    }
    function renderGrid() {
      EA = null;
      const vis = visCols(), tpl = gridTpl(vis);
      const head = `<div class="pu-gr pu-gh" style="grid-template-columns:${tpl}"><div></div>${vis.map(c => `<div class="hc" data-k="${c.k}" draggable="true" title="${esc(c.t)} — اسحب لتغيير الترتيب أو لإخفاء العمود">${esc(c.t)}<i class="rz" title="اسحب لتغيير عرض العمود"></i></div>`).join("")}<div></div></div>`;
      const nw = `<div class="pu-gr pu-new" style="grid-template-columns:${tpl}"><div class="ind">✱</div>${vis.map(c => `<div data-k="${c.k}">${c.k === "name" ? '<input data-c="name" placeholder="Click here to add a new row" autocomplete="off"><button type="button" class="pu-dd" data-a="pkdd" tabindex="-1" title="قائمة الأصناف (F4)"><svg viewBox="0 0 10 6" width="9" height="6"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.4"/></svg></button>' : c.k === "code" ? '<input data-c="code" autocomplete="off">' : ""}</div>`).join("")}<div></div></div>`;
      const body = S.rows.map((r, i) => `<div class="pu-gr pu-d${i === S.sel ? " sel" : ""}${i % 2 ? " alt" : ""}" data-i="${i}" style="grid-template-columns:${tpl}"><div class="ind" title="اسحب الرقم لنقل السطر لأعلى أو لأسفل (Ctrl+Shift+↑/↓)"><span class="rn">${i + 1}</span><button type="button" class="pi" data-a="rinfo" tabindex="-1" title="بيانات الصنف">${I.info}</button></div>${vis.map(c => `<div data-k="${c.k}">${cellHTML(c, r, i)}</div>`).join("")}<div><button type="button" class="rx" data-a="rdel" tabindex="-1" title="حذف السطر (Ctrl+Delete)">${I.x}</button></div></div>`).join("");
      const fill = Array.from({ length: Math.max(0, 9 - S.rows.length) }, (_, k) => `<div class="pu-gr pu-fill${(S.rows.length + k) % 2 ? " alt" : ""}" style="grid-template-columns:${tpl}"></div>`).join("");
      grid.innerHTML = ENTRY === "bottom" ? head + body + nw + fill : head + nw + body + fill;
      grid.classList.toggle("ent-bottom", ENTRY === "bottom");
      { const gh = grid.querySelector(".pu-gh"); if (gh && gh.offsetHeight) grid.style.setProperty("--ghh", gh.offsetHeight + "px"); }
      if (D.insAt != null) { const at = grid.querySelector(`.pu-d[data-i="${D.insAt - 1}"]`); if (at) at.classList.add("ins-after"); }
      if (D.filter) applyFilter();
      if (D.pend) showPend();
      syncFill();
    }
    /* الأسطر الفارغة المخططة تملأ ارتفاع الشبكة فقط (بدون شريط تمرير زائف ولا فراغ أبيض) — تتكيّف مع حجم الشاشة */
    function syncFill() {
      const w = grid.parentElement; if (!w || !w.clientHeight) return;
      { const gs = root.querySelector(".pu-gsum"), sb = Math.max(0, w.offsetWidth - w.clientWidth - 2); if (gs) gs.style.paddingLeft = sb + "px"; }   // محاذاة سطر الإجماليات مع شريط التمرير العمودي
      const fills = [...grid.querySelectorAll(".pu-fill")], fh = fills.reduce((a, f) => a + f.offsetHeight, 0);
      const rowH = (fills[0] && fills[0].offsetHeight) || 27, n = Math.max(0, Math.floor((w.clientHeight - (grid.offsetHeight - fh)) / rowH));
      if (n === fills.length) return;
      if (n < fills.length) { fills.slice(n).forEach(f => f.remove()); return; }
      const tpl = (grid.querySelector(".pu-gh") || {}).style ? grid.querySelector(".pu-gh").style.gridTemplateColumns : "", hid = D.filter && D.fOnly ? " pu-hid" : "";
      let h = ""; for (let k = fills.length; k < n; k++) h += `<div class="pu-gr pu-fill${(S.rows.length + k) % 2 ? " alt" : ""}${hid}" style="grid-template-columns:${tpl}"></div>`;
      grid.insertAdjacentHTML("beforeend", h);
    }
    try { new ResizeObserver(() => syncFill()).observe(grid.parentElement); } catch (e) { }
    function renderRow(i) {
      const el = grid.querySelector(`.pu-d[data-i="${i}"]`), r = S.rows[i];
      if (!el || !r) return renderGrid();
      if (D.filter) setTimeout(() => { const w = fWords(); markRow(el, r, w, w.length && w.every(x => rowText(r).includes(x))); }, 0);
      const vis = visCols();
      vis.forEach(c => {
        const cell = el.querySelector(`[data-k="${c.k}"]`);
        if (!cell) return;
        const a = document.activeElement;
        if (a && cell.contains(a)) {   // لا نكتب فوق ما يكتبه المستخدم ولا نُفقده التركيز
          if (a.tagName === "INPUT" && a.type !== "checkbox") {
            const tmp = document.createElement("div"); tmp.innerHTML = cellHTML(c, r, i);
            const n = tmp.firstElementChild; if (n) { a.className = n.className; a.title = n.title; }
          }
          return;
        }
        cell.innerHTML = cellHTML(c, r, i);
      });
    }
    function renderAll() { if (!S) return; renderGrid(); renderExps(); updTotals(); renderSide(); updTitle(); }
    function updTitle() {
      F("title").textContent = ty.t;
      F("editTag").textContent = S.id ? "تعديل رقم " + S.no : "";
      root.classList.toggle("editing", !!S.id);
      F("no").readOnly = false;
    }
    function markDirty() { S.dirty = true; EA = null; autoKick(); }
    /* حقول إضافية تغيّر الحساب: يُعاد حساب السطر (والفاتورة لأن حصص خصم الفاتورة والمصروفات تتغيّر) */
    const CALC_X = { bonus: 1, free: 1, qtyDisc: 1, cashCat: 1, subCash: 1, ship: 1, shipPct: 1, priceTax: 1, labor: 1, pts: 1, dtaxCat: 1, dtaxSub: 1 };
    let xT = 0;
    function xChanged(i, k) {
      const r = S.rows[i]; if (!r) return;
      if (k === "priceTax" || k === "free") applyDp(r);
      clearTimeout(xT);
      xT = setTimeout(() => { const a = document.activeElement, ac = a && a.dataset ? a.dataset.c : null, ar = a && a.closest ? a.closest(".pu-d") : null;
        if (k === "bonus" || k === "pts" || k === "labor" || k === "dtaxCat" || k === "dtaxSub") renderRow(i); else S.rows.forEach((x, j) => renderRow(j));
        updTotals(); if (ac && ar && !document.activeElement.closest(".pu-d")) try { focusCell(+ar.dataset.i, ac); } catch (e) { } }, 60);
    }
    function select(i) {
      if (i === S.sel) return;
      const o = grid.querySelector(".pu-d.sel"); if (o) o.classList.remove("sel");
      S.sel = i; const n = grid.querySelector(`.pu-d[data-i="${i}"]`); if (n) n.classList.add("sel");
      infoPid = null;
      renderSide();
    }

    /* ---------- إضافة صنف للسطر ---------- */
    function rowFromProduct(p, u, qty) {
      u = u || defUnit(p);
      const c = costOf(p, u), sale = +u.price || 0;
      const k = CX.rate || 1, pc = k === 1 ? (c || 0) : r2((c || 0) / k);
      const r0 = { pid: p.id, code: p.code || "", name: p.name || "", unit: u.name, puid: u.puid || 0, factor: u.factor || 1,
        qty: qty || 1, price: pc, lastCost: k === 1 ? c : r2(c / k), sale, sale0: sale, tax: vatRate() > 0, dp: 0, disc: 0, notes: "",
        _bp: c || 0, _blc: c || 0, _cxp: pc };
      itemAcc(r0);
      return r0;
    }
    /* إعدادات بطاقة الصنف ← الحسابات: الضريبة / خصم المشتريات (أو المبيعات لعروض العملاء) / الخصم النقدى / ضريبة الخصم */
    function itemAcc(r) {
      const c = IA() && IA().cfg(r.pid); if (!c) return;
      if (c.vat === "no") r.tax = false;
      const d = BUY ? c.pDisc : c.sDisc;
      if (d > 0) { if (c.meth === "v") r._dv = r2(d * (r.factor || 1)); else r.dp = Math.min(100, d); }
      if (!c.cash) r.x = Object.assign({}, r.x, { subCash: false });
      if (BUY && c.dtax === "yes") r.x = Object.assign({}, r.x, { dtaxSub: true }, c.dRate > 0 ? { dtaxCat: c.dRate } : {});
      else if (BUY && c.dtax === "no") r.x = Object.assign({}, r.x, { dtaxSub: false });
    }
    function applyDp(r) { if (r.dp) r.disc = r2(lineGross(r) * r.dp / 100); else if (r._dv) r.disc = r2(r._dv * (+r.qty || 0)); }
    function addProduct(p, u, qty, atRow, noFocus) {
      if (!p) return;
      u = u || defUnit(p);
      // صنف موجود بنفس الوحدة → زيادة الكمية (إدخال ذكي بالباركود)
      const EXPI = isExpRow({ pid: p.id });
      /* «هل أسمح بتكرار نفس الصنف؟ = لا» ← تُزاد الكمية دائماً ، «نعم» + «زيادة الكمية = لا» ← سطر جديد */
      const pp = PURP(), merge = pp.dup === false || pp.dupQty !== false;
      if (atRow == null && !EXPI && merge) {
        const ex = S.rows.findIndex(r => r.pid === p.id && r.unit === u.name);
        if (ex >= 0) {
          const r = S.rows[ex]; r.qty = r2((+r.qty || 0) + (qty || 1)); applyDp(r);
          try { if (typeof QtySound !== "undefined") QtySound.play(); } catch (e) { }
          S.sel = ex; markDirty(); renderGrid(); updTotals(); renderSide(); flash(ex); if (!noFocus) focusCell(ex, "qty");
          say("«" + p.name + "» موجود بالفاتورة — زادت الكمية إلى " + fmt(r.qty), "i");
          return;
        }
      }
      const r = rowFromProduct(p, u, qty); applyDp(r);
      if (atRow != null && S.rows[atRow]) { S.rows[atRow] = r; S.sel = atRow; }
      else if (D.insAt != null && D.insAt <= S.rows.length) { S.rows.splice(D.insAt, 0, r); S.sel = D.insAt; D.insAt = null; }
      else { S.rows.push(r); S.sel = S.rows.length - 1; }
      markDirty(); renderGrid(); updTotals(); renderSide(); flash(S.sel); if (!noFocus) focusCell(S.sel, "qty");
      if (EXPI) { const i0 = S.sel; setTimeout(() => batchPop(i0), 60); }
    }
    /* ---------- «إضافة صنف»: نافذة البحث عن الأصناف (مطابقة DEXEF) ---------- */
    function itemSearch() {
      if (!window.ITEM_SEARCH) { sideAct("newItem"); return; }
      ITEM_SEARCH.open({ stock: p => whQty(p.id), defUnit: p => defUnit(p), priceOf: (p, u) => { const uu = unitByName(p, u.name) || u; return costOf(p, uu); },
        onPick: (list, q, meta) => { list.forEach((p, j) => { const m = meta && meta[p.id], u = (m && m.unit && unitByName(p, m.unit.name)) || defUnit(p); addProduct(p, u, m ? m.qty : q, null, j < list.length - 1); }); if (list.length > 1) say("تمت إضافة " + list.length + " أصناف", "s"); } });
    }
    /* ---------- مخزون بصلاحية: كل سطر = دفعة (تاريخ صلاحية + رقم تشغيلة) في المستندات الواردة ---------- */
    const EXP_IN = type === "Opening" || type === "Purchase" || type === "StockIn";
    function isExpRow(r) { return EXP_IN && !!r && ((window.__ITYPE || {})[r.pid] === "expiry"); }
    const ixtra = pid => (window.__IXTRA || {})[pid] || {};
    const lotReq = pid => /التشغيلة/.test(ixtra(pid).track || "برقم التشغيلة");
    const minDays = pid => Math.max(0, parseInt(ixtra(pid).minShelf, 10) || 0);
    const dDays = (a, b) => Math.round((new Date(a) - new Date(b)) / 864e5);
    function showExpCols(withLot) {
      const k = layKeys(); let ch = false; const at = () => { const t = k.indexOf("total"); return t >= 0 ? t : k.length; };
      if (!k.includes("expDate")) { k.splice(at(), 0, "expDate"); ch = true; }
      if (withLot && !k.includes("lot")) { k.splice(at(), 0, "lot"); ch = true; }
      if (ch) setLayout(k); return ch;
    }
    function batchCheck(r, docDate) {
      const x = r.x || {};
      if (!x.expDate) return { m: "أدخل تاريخ الصلاحية", hard: 1 };
      if (lotReq(r.pid) && !(x.lot || "").trim()) return { m: "أدخل رقم التشغيلة", hard: 1, lot: 1 };
      const d = dDays(x.expDate, docDate || F("date").value || today());
      if (d < 0) return { m: "منتهي الصلاحية منذ " + (-d) + " يوم", hard: type !== "Opening" };
      if (d < minDays(r.pid)) return { m: "مدة الصلاحية " + d + " يوم أقل من أقل مدة يمكن قبولها (" + minDays(r.pid) + " يوم)", hard: type !== "Opening" };
      return null;
    }
    /* نافذة الدفعة: تاريخ الصلاحية + رقم التشغيلة + المتبقي، واقتراح آخر دفعة لنفس الصنف */
    function batchPop(i) {
      const r = S.rows[i]; if (!r) return;
      const cell = grid.querySelector(`.pu-d[data-i="${i}"] [data-k="name"]`) || grid.querySelector(`.pu-d[data-i="${i}"]`) || grid;
      const prev = S.rows.slice().reverse().find(z => z !== r && z.pid === r.pid && z.x && z.x.expDate);
      const x0 = r.x || {}, exp0 = x0.expDate || (prev ? prev.x.expDate : ""), lot0 = x0.lot != null ? x0.lot : (prev ? prev.x.lot || "" : ""), lr = lotReq(r.pid), md = minDays(r.pid);
      const el = openPop(cell, `<div class="pu-desc pu-batch"><div class="hd">دفعة صلاحية — ${esc(r.name)}</div>
        <div class="bg"><label>تاريخ الصلاحية <i>*</i></label><input type="date" class="ed" data-f="exp" value="${esc(exp0)}">
        <label>رقم التشغيلة ${lr ? "<i>*</i>" : ""}</label><input class="ed" data-f="lot" value="${esc(lot0)}" autocomplete="off" style="direction:ltr"></div>
        <div class="inf"></div>
        <div class="ft"><span class="hn">${md ? "أقل مدة صلاحية: " + md + " يوم" : ""}</span><button type="button" class="pu-bt g">حفظ</button></div></div>`, "pu-descpop");
      const e = el.querySelector('[data-f="exp"]'), l = el.querySelector('[data-f="lot"]'), inf = el.querySelector(".inf");
      const upd = () => { if (!e.value) { inf.textContent = ""; inf.className = "inf"; return; } const d = dDays(e.value, F("date").value || today()); inf.textContent = d < 0 ? "منتهي الصلاحية منذ " + (-d) + " يوم" : "المتبقي على الانتهاء: " + d + " يوم"; inf.className = "inf" + (d < 0 ? " ex" : d < Math.max(md, 1) ? " sn" : " ok"); };
      e.addEventListener("input", upd); upd();
      setTimeout(() => { e.focus(); }, 0);
      const ok = () => {
        if (!e.value) { say("أدخل تاريخ الصلاحية", "w"); e.focus(); return; }
        if (lr && !l.value.trim()) { say("أدخل رقم التشغيلة (طريقة تتبع الصنف)", "w"); l.focus(); return; }
        r.x = r.x || {}; r.x.expDate = e.value; r.x.lot = l.value.trim(); closePop(); markDirty();
        // نفس الدفعة (الصنف + الوحدة + التاريخ + التشغيلة) موجودة → دمج الكمية
        const j = S.rows.findIndex(z => z !== r && z.pid === r.pid && z.unit === r.unit && z.x && z.x.expDate === r.x.expDate && (z.x.lot || "") === r.x.lot);
        if (j >= 0) { S.rows[j].qty = r2((+S.rows[j].qty || 0) + (+r.qty || 0)); applyDp(S.rows[j]); S.rows.splice(S.rows.indexOf(r), 1); S.sel = j > S.rows.length - 1 ? S.rows.length - 1 : (j > i ? j - 1 : j); try { if (typeof QtySound !== "undefined") QtySound.play(); } catch (x2) { }
          say("نفس الدفعة موجودة — زادت الكمية إلى " + fmt(S.rows[S.sel].qty), "i"); renderGrid(); updTotals(); renderSide(); flash(S.sel); focusCell(S.sel, "qty"); return; }
        const c = batchCheck(r); if (c) say("«" + r.name + "»: " + c.m, "w");
        if (!showExpCols(lr || !!r.x.lot)) renderRow(i); focusCell(S.rows.indexOf(r), "qty");
      };
      el.querySelector("button").addEventListener("click", ok);
      el.addEventListener("keydown", ev => { if (ev.key === "Enter") { ev.preventDefault(); if (ev.target === e) { l.focus(); l.select(); } else ok(); } });
    }
    /* ---------- السطر الجديد: الصنف المختار ينتظر في خانة الاسم (مطابق DEXEF) ----------
       الاختيار من القائمة يضع الصنف في خانة «اسم الصنف» فقط؛ Enter أو Tab ينزله في الفاتورة وينقلك للكمية،
       والضغط بالفأرة/باللمس في أي مكان داخل الفاتورة ينزله فوراً. */
    function newName() { return grid.querySelector(".pu-new [data-c=name]"); }
    function showPend() {
      const nw = grid.querySelector(".pu-new"); if (!nw || !D.pend) return;
      nw.classList.add("pend");
      const n = nw.querySelector("[data-c=name]"), c = nw.querySelector("[data-c=code]");
      if (n) n.value = D.pend.p.name || ""; if (c) c.value = D.pend.p.code || "";
    }
    function setPend(p, u) {
      D.pend = { p, u: u || null };
      showPend();
      try { if (typeof QtySound !== "undefined") QtySound.play(); } catch (e) { }
      const n = newName(); if (n) setTimeout(() => { n.focus(); try { n.select(); } catch (e) { } }, 0);
    }
    function clearPend(keepText) {
      D.pend = null;
      const nw = grid.querySelector(".pu-new"); if (!nw) return;
      nw.classList.remove("pend");
      if (!keepText) { const n = nw.querySelector("[data-c=name]"); if (n) n.value = ""; }
      const c = nw.querySelector("[data-c=code]"); if (c) c.value = "";
    }
    function commitPend(noFocus) {
      const pd = D.pend; if (!pd) return false;
      clearPend();
      addProduct(pd.p, pd.u, null, null, noFocus);
      return true;
    }
    // ضغطة فأرة أو لمسة داخل الفاتورة خارج خانة الاسم → ينزل الصنف فوراً ويبقى ما ضغطت عليه هو الفعّال
    document.addEventListener("pointerdown", e => {
      if (!D.pend || !root.contains(e.target) || !root.offsetParent) return;
      if (e.target.closest(".pu-new [data-k=name]") || (POP && POP.el.contains(e.target))) return;
      const cell = e.target.closest("[data-c]"), rowEl = e.target.closest(".pu-d");
      const ref = rowEl ? S.rows[+rowEl.dataset.i] : null, ck = cell && cell.dataset.c;
      const onGrid = grid.contains(e.target);
      commitPend(true);
      if (onGrid) {
        e.preventDefault();
        const j = ref ? S.rows.indexOf(ref) : -1;
        if (j >= 0) { select(j); if (ck) focusCell(j, ck); }
        else if (cell && cell.closest(".pu-new")) focusCell(-1, ck);
        else focusCell(S.sel, "qty");
      }
    }, true);
    function flash(i) { const el = grid.querySelector(`.pu-d[data-i="${i}"]`); if (el) { el.classList.remove("fl"); void el.offsetWidth; el.classList.add("fl"); revealRow(el); } }
    /* آخر صنف مُضاف يبقى ظاهراً: تمرير الشبكة (فقط) حتى يظهر السطر كاملاً تحت العناوين الثابتة — وسطر الإدخال معه عند الإدخال من الأسفل */
    function revealRow(el) {
      const w = grid.parentElement; if (!w || !el || !w.clientHeight) return;
      const nw = grid.querySelector(".pu-new"); if (el === nw) return;   // سطر الإدخال ثابت (sticky) دائماً ظاهر
      const hh = (grid.querySelector(".pu-gh") || {}).offsetHeight || 0, nh = nw ? nw.offsetHeight : 0, wr = w.getBoundingClientRect(), r = el.getBoundingClientRect();
      const top = r.top - wr.top - w.clientTop, bot = r.bottom - wr.top - w.clientTop;
      const topBar = hh + (ENTRY === "bottom" ? 0 : nh), botBar = ENTRY === "bottom" ? nh : 0;
      let d = 0;
      if (top < topBar) d = top - topBar - 2; else if (bot > w.clientHeight - botBar) d = bot - (w.clientHeight - botBar) + 2;
      if (d) w.scrollBy({ top: d, behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
    }
    function focusCell(i, k) {
      setTimeout(() => {
        const el = i < 0 ? grid.querySelector(`.pu-new [data-c="${k}"]`) : grid.querySelector(`.pu-d[data-i="${i}"] [data-c="${k}"]`);
        if (el) { el.focus({ preventScroll: true }); if (el.select) try { el.select(); } catch (e) { } const row = el.closest(".pu-gr"); if (row) revealRow(row); }
      }, 0);
    }
    function delRow(i) {
      if (!S.rows[i]) return;
      S.rows.splice(i, 1);
      try { if (typeof DelSound !== "undefined") DelSound.play(); } catch (e) { }
      S.sel = Math.min(i, S.rows.length - 1); markDirty(); renderGrid(); updTotals(); renderSide();
      if (S.sel >= 0) focusCell(S.sel, "qty"); else focusCell(-1, "name");
    }

    /* ---------- نافذة اختيار الصنف (Find / Clear) ---------- */
    let PK = null;
    /* المورد المفضل لكل صنف (Extra.supplier في بطاقة الصنف) — يُحمَّل مرة ويُحدَّث كل دقيقتين */
    let PREF = null, prefAt = 0;
    function prefMap() {
      if (PREF && Date.now() - prefAt < 120000) return PREF;
      if (!PREF || Date.now() - prefAt >= 120000) { prefAt = Date.now();
        (B() ? call("fm.items.extra") : Promise.resolve([])).then(l => { const m = {}; (l || []).forEach(x => { let e = x.extra; try { e = typeof e === "string" ? (e ? JSON.parse(e) : {}) : (e || {}); } catch (z) { e = {}; } const sp = e && e.supplier; const id = sp && (sp.id != null ? sp.id : sp.SupplierId); if (id != null && id !== "") m[x.id] = id; }); PREF = m; if (PK && PK.draw) PK.draw(); }).catch(() => { PREF = PREF || {}; }); }
      return PREF;
    }
    function searchProducts(q) {
      q = norm(q);
      let all = prods().filter(p => p.active !== false);   /* الأصناف غير النشطة لا تظهر (تُنشَّط من «تعديل الأسعار») */
      /* «ظهور الأصناف التي يتعامل بها المورد المفضل فقط»: المورد المفضل في بطاقة الصنف = مورد الفاتورة
         (إذا لم يُحدَّد هذا المورد كمورد مفضل لأي صنف ← كل الأصناف، حتى لا تبقى القائمة فارغة) */
      if (PURP().prefSup === true && S.supId) { const M2 = prefMap(); if (M2) { const mine = all.filter(p => M2[p.id] != null && String(M2[p.id]) === String(S.supId)); if (mine.length) { all = mine; D.prefOn = mine.length; } else D.prefOn = 0; } }
      else D.prefOn = 0;
      if (!q) return all.slice(0, 200);
      const words = q.split(/\s+/).filter(Boolean);
      const out = [];
      for (const p of all) {
        const hay = norm(p.name) + " " + norm(p.code) + " " + norm(p.barcode || "");
        if (words.every(w => hay.includes(w))) out.push(p);
        if (out.length >= 300) break;
      }
      // الأقرب أولاً: يبدأ بالنص ثم يحتوي
      out.sort((a, b) => (norm(a.name).startsWith(q) ? 0 : 1) - (norm(b.name).startsWith(q) ? 0 : 1));
      return out;
    }
    function hl(s, q) {
      s = String(s || ""); q = String(q || "").trim();
      if (!q) return esc(s);
      const words = q.split(/\s+/).filter(Boolean).map(w => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
      try { return esc(s).replace(new RegExp("(" + words.join("|") + ")", "gi"), "<mark>$1</mark>"); } catch (e) { return esc(s); }
    }
    /* ---------- أعمدة نافذة اختيار الصنف + أدوات الجدول (نفس قائمة رأس العمود: Sort / Group / Column Chooser / Best Fit / Filter Editor / Auto Filter Row) ---------- */
    const PQC = [
      { k: "name", t: "الاسم", w: "minmax(200px,1fr)", txt: 1, f: p => p.name || "" },
      { k: "code", t: "الكود", w: "170px", txt: 1, f: p => p.code || "" },
      { k: "cost", t: "السعر", w: "70px", f: p => +p.cost || 0 },
      { k: "stock", t: "الرصيد", w: "70px", f: p => +p.stock || 0 },
      { k: "price", t: "سعر البيع", w: "80px", f: p => +p.price || 0 },
      { k: "unit", t: "الوحدة", w: "80px", txt: 1, f: p => (p._d && p._d.name) || "" },
      { k: "cat", t: "المجموعة", w: "110px", txt: 1, f: p => p.cat || "" }
    ];
    const PQS = (() => { let o = {}; try { o = JSON.parse(localStorage.getItem("pu.pk.grid") || "{}") || {}; } catch (e) { }
      return Object.assign({ off: ["price", "unit", "cat"], auto: true, w: {}, sort: null, group: null, gbox: false }, o, { adv: [], af: {}, coll: new Set() }); })();
    const pqSave = () => { try { const o = Object.assign({}, PQS); delete o.adv; delete o.af; delete o.coll; localStorage.setItem("pu.pk.grid", JSON.stringify(o)); } catch (e) { } };
    (function () { if (document.getElementById("pqGridCss")) return; const st = document.createElement("style"); st.id = "pqGridCss";
      st.textContent = `.pu-pk .pq-h,.pu-pk .pq-f,.pu-pk .pq-r{grid-template-columns:var(--pq-c,minmax(200px,1fr) 170px 70px 70px)}
.pu-pk .pq-h>div{position:relative;cursor:pointer;user-select:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:4px 12px}
.pu-pk .pq-h>div:hover{background:#cfe0f8}.pu-pk .pq-h>div.drag{opacity:.45}.pu-pk .pq-h.drop{outline:2px dashed #1a6fd0;outline-offset:-2px}
.pu-pk .pq-h>div i{position:absolute;left:4px;top:50%;transform:translateY(-50%);font-style:normal;font-size:9px;color:#1f6fd6}
.pu-pk .pq-f>div{padding:1px 2px}
.pu-pk .pq-f input{width:100%;height:18px;border:1px solid transparent;border-radius:2px;background:transparent;text-align:center;font:inherit;font-size:10px;color:#333;outline:0}
.pu-pk .pq-f input::placeholder{color:#999}.pu-pk .pq-f input:focus{border-color:#93b8ea;background:#fff}
.pu-pk .pq-gh{position:sticky;top:0;z-index:1;display:flex;align-items:center;gap:8px;min-height:24px;padding:0 10px;background:#eef3fa;border-bottom:1px solid #d9e3f0;color:#1d3d6b;font-weight:700;cursor:pointer;user-select:none;font-size:11.5px}
.pu-pk .pq-gh i{font-style:normal;width:12px;color:#1a6fd0}.pu-pk .pq-gh small{color:#6b7a90;font-weight:400}
.pu-pk .cgb{flex:none}`; document.head.appendChild(st); })();

    function openPicker(input, rowIdx, all) {
      const pend = (rowIdx == null && D.pend && input.closest(".pu-new")) ? D.pend.p : null;
      const q = all || pend ? "" : input.value;
      const repl = rowIdx != null && rowIdx >= 0 && S.rows[rowIdx] ? S.rows[rowIdx] : null;
      const el = openPop(input, `<div class="pu-pk${repl ? " rep" : ""}">${repl ? `<div class="pq-rep"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3l4 4-4 4"/><path d="M3 11V9a2 2 0 0 1 2-2h16"/><path d="M7 21l-4-4 4-4"/><path d="M21 13v2a2 2 0 0 1-2 2H3"/></svg><span>تبديل «<b>${esc(repl.name)}</b>» — الكمية <b>${fmt(repl.qty)}</b> تبقى كما هي</span></div>` : ""}<div class="pq-top"><input class="pq-q" value="${esc(q)}" placeholder="بحث بالاسم أو الكود أو الباركود" autocomplete="off"><button type="button" class="pq-b" data-a="find">Find</button></div>
        <div class="cgb" style="display:none"></div><div class="pq-h"></div><div class="pq-f"></div><div class="pq-l"></div>
        <div class="pq-ft"><button type="button" class="pq-b" data-a="clear">Clear</button><span class="pq-n"></span></div></div>`, "pu-pkpop", { onClose: () => { PK = null; const cc = document.getElementById("ipkChooser"); if (cc) cc.remove(); if (window.ANOUER_IPICK) ANOUER_IPICK.grid.closeMenu(); } });
      PK = { el, input, rowIdx, list: [], i: 0 };
      const qi = el.querySelector(".pq-q"), GT = window.ANOUER_IPICK && ANOUER_IPICK.grid;
      PQS.adv = []; PQS.coll = new Set(); for (const k in PQS.af) delete PQS.af[k];
      const vcols = () => PQC.filter(c => PQS.off.indexOf(c.k) < 0);
      const head = () => {
        const vc = vcols(), pk = el.querySelector(".pu-pk") || el;
        pk.style.setProperty("--pq-c", vc.map(c => PQS.w[c.k] ? PQS.w[c.k] + "px" : c.w).join(" "));
        el.querySelector(".pq-h").innerHTML = vc.map(c => `<div data-k="${c.k}" draggable="true" title="نقرة: ترتيب · زر يمين: القائمة">${c.t}${PQS.sort && PQS.sort.k === c.k ? `<i>${PQS.sort.d > 0 ? "▲" : "▼"}</i>` : ""}</div>`).join("");
        const f = el.querySelector(".pq-f"); f.style.display = PQS.auto ? "" : "none";
        f.innerHTML = vc.map(c => `<div><input data-af="${c.k}" value="${esc(PQS.af[c.k] || "")}" placeholder="${c.txt ? "ᴀʙc" : "="}" autocomplete="off"></div>`).join("");
        const gb = el.querySelector(".cgb"), gc = PQS.group && PQC.find(x => x.k === PQS.group);
        gb.style.display = PQS.gbox || gc ? "" : "none";
        gb.innerHTML = gc ? `<span class="chip">${esc(gc.t)}<b data-a="ungroup" title="إلغاء التجميع">✕</b></span>` : "اسحب عنوان عمود هنا للتجميع حسب هذا العمود";
        if (GT) GT.chooserRefresh(PK.G);
      };
      const draw = () => {
        PK.list = searchProducts(qi.value);
        if (GT) { PK.list = GT.applyAuto(PK.list, PQS.af, PQC); PK.list = GT.applyAdv(PK.list, PQS.adv, PQC); }
        if (repl && !qi.value.trim() && !PQS.sort) {   // لمسة: الأصناف المشابهة (نفس الماركة/الكلمات) أولاً ثم البقية
          const tk = t => norm(t).split(/[\s()\[\]\-_/]+/).filter(w => w.length >= 3 && !/^\d+[a-z]*$/i.test(w));
          const base = new Set(tk(repl.name));
          PK.list = PK.list.map((p, k) => ({ p, k, sc: p.id === repl.pid ? 1e3 : tk(p.name).filter(w => base.has(w)).length })).sort((a, b) => b.sc - a.sc || a.k - b.k).map(x => { x.p._sim = x.sc > 0 && x.sc < 1e3; return x.p; });
        } else PK.list.forEach(p => { p._sim = false; });
        if (GT && PQS.sort) PK.list = GT.sortBy(PK.list, PQS, PQC);
        const G = GT && PQS.group ? GT.groupBy(PK.list, PQS, PQC) : null;
        if (G) { PK.list = []; G.groups.forEach(([key, items]) => { if (!PQS.coll.has(key)) PK.list.push(...items); }); }
        PK.i = Math.min(PK.i, Math.max(0, PK.list.length - 1));
        const vc = vcols(), qv = qi.value;
        const rowH = (p, i) => `<div class="pq-r${i === PK.i ? " on" : ""}${repl && p.id === repl.pid ? " cur" : ""}" data-i="${i}">` + vc.map(c => {
          if (c.k === "name") return `<div>${hl(p.name, qv)}${repl && p.id === repl.pid ? '<em class="pq-cur">الحالي</em>' : p._sim ? '<em class="pq-sim">مشابه</em>' : ""}</div>`;
          if (c.k === "code") return `<div>${hl(p.code, qv)}</div>`;
          if (c.k === "stock") return `<div class="${(+p.stock || 0) <= 0 ? "neg" : ""}">${fmt(+p.stock || 0)}</div>`;
          if (c.txt) return `<div>${esc(c.f(p))}</div>`;
          return `<div>${fmt(c.f(p))}</div>`;
        }).join("") + `</div>`;
        let html = "";
        if (G) { let i = 0; for (const [key, items] of G.groups) { if (i >= 200) break; const cl = PQS.coll.has(key);
            html += `<div class="pq-gh" data-g="${esc(key)}"><i>${cl ? "▸" : "▾"}</i>${esc(G.col.t)}: ${esc(key)} <small>(${items.length})</small></div>`;
            if (!cl) items.forEach(p => { if (i < 200) html += rowH(p, i); i++; }); } }
        else html = PK.list.slice(0, 200).map(rowH).join("");
        el.querySelector(".pq-l").innerHTML = html || `<div class="pq-empty">لا توجد أصناف مطابقة${PQS.adv.length ? " — راجع Filter Editor" : ""}</div>`;
        el.querySelector(".pq-n").textContent = (PK.list.length ? PK.list.length + " صنف" : "") + (D.prefOn ? " · أصناف المورد المفضل فقط" : "");
        const on = el.querySelector(".pq-r.on"); if (on) on.scrollIntoView({ block: "nearest" });
      };
      PK.draw = draw;
      PK.G = { cols: PQC, st: PQS, save: pqSave, redraw: () => { head(); draw(); }, rows: () => PK.list, el };
      head();
      qi.addEventListener("input", () => { PK.i = 0; draw(); });
      el.addEventListener("input", e => { const a = e.target.dataset && e.target.dataset.af; if (a == null) return; PQS.af[a] = e.target.value; PK.i = 0; draw(); });
      el.addEventListener("mousedown", e => { if (!e.target.closest(".pq-q,.pq-f input")) e.preventDefault(); });
      el.addEventListener("contextmenu", e => { const h = e.target.closest(".pq-h>div[data-k]"); if (!h || !GT) return; e.preventDefault(); GT.menu(e.clientX, e.clientY, h.dataset.k, PK.G); });
      /* سحب عنوان عمود: لمربع التجميع = تجميع ؛ من Customization للعناوين = إظهار ؛ للـ Customization = إخفاء */
      el.addEventListener("dragstart", e => { const h = e.target.closest(".pq-h>div[data-k]"); if (!h) return; e.dataTransfer.setData("text/ipk-col", h.dataset.k); e.dataTransfer.effectAllowed = "move"; h.classList.add("drag"); });
      el.addEventListener("dragend", e => { const h = e.target.closest(".pq-h>div"); if (h) h.classList.remove("drag"); el.querySelectorAll(".over,.drop").forEach(x => x.classList.remove("over", "drop")); });
      el.addEventListener("dragover", e => { const t = e.target.closest(".cgb,.pq-h"); if (t) { e.preventDefault(); t.classList.add(t.classList.contains("cgb") ? "over" : "drop"); } });
      el.addEventListener("dragleave", e => { const t = e.target.closest(".cgb,.pq-h"); if (t) t.classList.remove("over", "drop"); });
      el.addEventListener("drop", e => { const t = e.target.closest(".cgb,.pq-h"); if (!t) return; e.preventDefault(); el.querySelectorAll(".over,.drop").forEach(x => x.classList.remove("over", "drop"));
        const k = e.dataTransfer.getData("text/ipk-col"), sh = e.dataTransfer.getData("text/ipk-show");
        if (t.classList.contains("cgb") && k) { PQS.group = k; PQS.coll.clear(); }
        else if (sh) { const i = PQS.off.indexOf(sh); if (i >= 0) PQS.off.splice(i, 1); }
        pqSave(); head(); draw(); });
      el.addEventListener("click", e => {
        const r = e.target.closest(".pq-r"); if (r) { PK.i = +r.dataset.i; choose(); return; }
        const g = e.target.closest(".pq-gh"); if (g) { const k = g.dataset.g; PQS.coll.has(k) ? PQS.coll.delete(k) : PQS.coll.add(k); draw(); return; }
        const h = e.target.closest(".pq-h>div[data-k]"); if (h) { const k = h.dataset.k; PQS.sort = PQS.sort && PQS.sort.k === k ? (PQS.sort.d > 0 ? { k, d: -1 } : null) : { k, d: 1 }; pqSave(); head(); draw(); return; }
        const b = e.target.closest("[data-a]"); if (!b) return;
        if (b.dataset.a === "ungroup") { PQS.group = null; PQS.coll.clear(); pqSave(); head(); draw(); return; }
        if (b.dataset.a === "clear") { qi.value = ""; PK.i = 0; draw(); qi.focus(); } else { draw(); qi.focus(); }
      });
      el.addEventListener("dblclick", e => { if (e.target.closest(".pq-r")) choose(); });
      POP.key = e => {
        if (!PK) return false;
        if (document.getElementById("ipkFE")) return false;   // Filter Editor مفتوح ← المفاتيح ليه
        if (document.getElementById("ipkMenu") && e.key === "Escape") { GT && GT.closeMenu(); return true; }
        const k = e.key;
        if (k === "ArrowDown") { PK.i = Math.min(PK.list.length - 1, PK.i + 1); draw(); }
        else if (k === "ArrowUp") { PK.i = Math.max(0, PK.i - 1); draw(); }
        else if (k === "PageDown") { PK.i = Math.min(PK.list.length - 1, PK.i + 10); draw(); }
        else if (k === "PageUp") { PK.i = Math.max(0, PK.i - 10); draw(); }
        else if (k === "Enter") { choose(); }
        else if (k === "Escape") { closePop(); input.focus(); }
        else return false;
        return true;
      };
      draw();
      if (pend) { const k = PK.list.findIndex(x => x.id === pend.id); if (k >= 0) { PK.i = k; draw(); } }
      if (repl && PK.list.length > 1 && PK.list[0].id === repl.pid) { PK.i = 1; draw(); }   // أول بديل مقترح جاهز للاختيار
      setTimeout(() => { qi.focus(); const v = qi.value; qi.setSelectionRange(v.length, v.length); }, 0);
      function choose() {
        const p = PK && PK.list[PK.i]; if (!p) return;
        closePop();
        if (rowIdx != null && rowIdx >= 0) {
          const old = S.rows[rowIdx]; const keepQ = old ? old.qty : 1;
          if (old && old.pid === p.id) { input.focus(); return; }
          addProduct(p, null, keepQ, rowIdx);
          if (old) say("تم تبديل «" + old.name + "» بـ «" + p.name + "» — الكمية " + fmt(keepQ), "s");
        } else if (input && input.closest && input.closest(".pu-new")) setPend(p);
        else addProduct(p);
      }
    }
    /* إدخال الكود/الباركود مباشرة: مطابقة تامة → إضافة فورية */
    function exactCode(v) {
      v = String(v || "").trim(); if (!v) return null;
      // باركود الوحدة أولاً (يحدد الوحدة: قطعة/كرتونة)، ثم كود الصنف (وحدة الشراء الافتراضية)
      const off = prods().find(p => p.active === false && (String(p.code) === v || (p._u || []).some(u => u.bc && String(u.bc) === v || (u.xb || []).includes(v))));
      if (off) say("الصنف «" + off.name + "» غير نشط — عدّل سعره من «تعديل الأسعار» لتنشيطه", "w");
      for (const p of prods()) { if (p.active === false) continue; for (const u of (p._u || [])) if (u.bc && String(u.bc) === v || (u.xb || []).includes(v)) return { p, u }; }
      for (const p of prods()) { if (p.active === false) continue;
        if (String(p.code) === v) return { p, u: defUnit(p) };
        if (!p._u && p.barcode && String(p.barcode).split(/\s+/).includes(v)) return { p, u: defUnit(p) };
      }
      return null;
    }

    /* ---------- المصروفات ---------- */
    function renderExps() {
      const box = $(".pu-exps"), cols = expCols(), tpl = "34px " + cols.map(c => c.w).join(" ") + " 34px";
      // الحفاظ على مكان المؤشر عند إعادة الرسم
      const ae = document.activeElement, er0 = ae && box.contains(ae) ? ae.closest(".pu-er") : null;
      const keep = er0 ? { i: er0.dataset.i, nw: er0.classList.contains("pu-enew"), e: ae.dataset.e, ss: ae.selectionStart } : null;
      const opt = (L, v) => L.map(o => `<option value="${o[0]}"${o[0] === v ? " selected" : ""}>${esc(o[1])}</option>`).join("");
      const curs = Array.from(F("cur").options).map(o => o.value || o.textContent);
      const cell = (c, x, i) => {
        switch (c.k) {
          case "name": return `<input data-e="name" value="${esc(x.name)}" list="puExpList" autocomplete="off" placeholder="اختر أو اكتب اسم المصروف">`;
          case "amt": return `<input data-e="amt" class="n" value="${x.amt ? esc(x.amt) : ""}" inputmode="decimal" autocomplete="off">`;
          case "alloc": return `<select data-e="alloc">${opt(EXP_ALLOC, x.alloc)}</select>`;
          case "pay": return `<select data-e="pay" class="pay-${x.pay}">${opt(EXP_PAY, x.pay)}</select>`;
          case "acct":
            if (x.pay === "Cash") return `<select data-e="acct"><option value=""></option>${META.treasuries.map(t => `<option value="${t.id}"${String(t.id) === x.acct ? " selected" : ""}>${esc(t.name)}</option>`).join("")}</select>`;
            if (x.pay === "OtherCustomer") return `<select data-e="acct"><option value=""></option>${SUPS.filter(sp => sp.id != S.supId).map(sp => `<option value="${sp.id}"${String(sp.id) === x.acct ? " selected" : ""}>${esc(sp.name)}</option>`).join("")}</select>`;
            if (x.pay === "Company") return `<input data-e="acct" value="${esc(x.acct)}" list="puCoaExp" autocomplete="off" placeholder="حساب المصروف">`;
            return `<span class="pu-ro u dim" title="يُضاف على فاتورة المورد">${esc(F("supName").value || "المورد")}</span>`;
          case "items": return `<div class="exi"><select data-e="all"><option value="1"${x.all ? " selected" : ""}>كل الأصناف</option><option value="0"${!x.all ? " selected" : ""}>أصناف محددة</option></select>${x.all ? "" : `<button type="button" class="exb" data-a="expItems" title="اختيار الأصناف">${x.items.length || "…"}</button>`}</div>`;
          case "cur": return `<select data-e="cur">${curs.map(cc => `<option${cc === (x.cur || F("cur").value) ? " selected" : ""}>${esc(cc)}</option>`).join("")}</select>`;
          case "rate": return `<input data-e="rate" class="n" value="${esc(x.rate || 1)}" inputmode="decimal" autocomplete="off">`;
          case "inv": return `<span class="pu-ro">${fmt(expInv(x))}</span>`;
          case "taxable": return `<select data-e="taxable">${opt(EXP_TAX, x.taxable)}</select>`;
          case "taxPerc": return x.taxable === "Yes" ? `<input data-e="taxPerc" class="n" value="${x.taxPerc ? esc(x.taxPerc) : ""}" inputmode="decimal" autocomplete="off">` : `<span class="pu-ro dim">${x.taxable === "Invoice" ? fmt(expPc(x)) + "%" : ""}</span>`;
          case "tax": return `<span class="pu-ro">${expTax(x) ? fmt(expTax(x)) : ""}</span>`;
          case "net": return `<span class="pu-ro b">${fmt(expNet(x))}</span>`;
          case "cc": return `<input data-e="cc" value="${esc(x.cc)}" autocomplete="off">`;
          case "notes": return `<input data-e="notes" value="${esc(x.notes)}" autocomplete="off">`;
        }
        return "";
      };
      const sum = k => S.exps.reduce((s2, x) => s2 + (k === "amt" ? expInv(x) : k === "tax" ? expTax(x) : k === "net" ? expNet(x) : 0), 0);
      const t = totals();
      box.innerHTML = `<div class="pu-ex2">
        <div class="pu-er pu-eh" style="grid-template-columns:${tpl}" title="زر أيمن ← اختيار الأعمدة"><div></div>${cols.map(c => `<div data-k="${c.k}">${esc(c.t)}</div>`).join("")}<div></div></div>
        ${S.exps.map((x, i) => `<div class="pu-er${i === D.expSel ? " sel" : ""}" data-i="${i}" style="grid-template-columns:${tpl}" title="${esc(expTip(x))}"><div class="ind">${i === D.expSel ? '<span class="arw">←</span>' : i + 1}</div>${cols.map(c => `<div data-k="${c.k}">${cell(c, x, i)}</div>`).join("")}<div><button type="button" class="rx" data-a="edel" tabindex="-1" title="حذف">${I.x}</button></div></div>`).join("")}
        <div class="pu-er pu-enew" style="grid-template-columns:${tpl}"><div class="ind">✱</div><div><input data-e="newName" placeholder="Click here to add a new row" list="puExpList" autocomplete="off"></div>${cols.slice(1).map(() => "<div></div>").join("")}<div></div></div>
        <div class="pu-er pu-esum" style="grid-template-columns:${tpl}"><div></div>${cols.map(c => `<div>${c.k === "amt" || c.k === "inv" ? fmt(sum("amt")) : c.k === "tax" ? fmt(sum("tax")) : c.k === "net" ? fmt(sum("net")) : c.k === "name" && S.exps.length ? S.exps.length + " مصروف" : ""}</div>`).join("")}<div></div></div></div>
        <div class="pu-ehint">${S.exps.length ? `<b>على فاتورة المورد:</b> ${fmt(t.exps)}${t.etax ? " + ضريبة " + fmt(t.etax) : ""} &nbsp;·&nbsp; <b>كل المصروفات (تدخل تكلفة الأصناف):</b> ${fmt(t.expAll)}` : "كل مصروف يُوزَّع على الأصناف (بالقيمة أو بالكمية) ويدخل في تكلفتها — «يضاف على الفاتورة» يزيد فاتورة المورد ، والنقدي يُصرف من الخزينة ، و«يقدم بشركة وسيطة» يصبح مستحقاً للجهة الوسيطة."}</div>`;
      const tb = root.querySelector('[data-g="exps"]'); if (tb && tb.tagName === "BUTTON") tb.textContent = S.exps.length ? "المصروفات (" + S.exps.length + ")" : "المصروفات";
      if (keep && keep.e) { const el = box.querySelector(keep.nw ? '.pu-enew [data-e="newName"]' : `.pu-er[data-i="${keep.i}"] [data-e="${keep.e}"]`); if (el) { el.focus(); try { if (keep.ss != null && el.setSelectionRange) el.setSelectionRange(keep.ss, keep.ss); } catch (x) { } } }
    }
    /* تلميح السطر: كيف وُزّع المصروف على الأصناف */
    function expTip(x) {
      const a = expInv(x); if (!a || !S.rows.length) return "";
      const hk = headFactor(), el = S.rows.filter(r => x.all !== false || (x.items || []).includes(String(r.code)));
      const w = el.map(r => x.alloc === "QtyDiv" ? totQty(r) : Math.max(0, lineTotal(r) * hk + rowExtra(r))), tw = w.reduce((s2, v) => s2 + v, 0);
      if (!(tw > 0)) return "";
      return "التوزيع على الأصناف (" + (x.alloc === "QtyDiv" ? "بالكمية" : "بالقيمة") + "):\n" + el.slice(0, 12).map((r, k) => "• " + r.name + ": " + fmt(r2(a * w[k] / tw))).join("\n") + (el.length > 12 ? "\n…" : "");
    }

    /* ---------- اللوحة الجانبية ---------- */
    function renderSide() {
      const st = $('.pu-spane[data-sp="stats"]'), sp = $('.pu-spane[data-sp="sup"]');
      const r = S.rows[S.sel], p = r && prodById(r.pid);
      if (!st.hidden) renderItemPane(st, r, p);
      if (!sp.hidden) renderSupPane(sp);
    }
    /* لوحة «معلومات عن الصنف» (مطابق DEXEF + تحليل شراء ذكي) */
    const INFO = {};
    let infoPid = null;          // صنف معروض يدوياً عبر 🔍 (وإلا صنف السطر المحدد)
    function renderItemPane(st, r, p) {
      if (infoPid && prodById(infoPid)) { p = prodById(infoPid); r = S.rows.find(x => x.pid === p.id) || null; }
      const u = p ? (r ? unitByName(p, r.unit) : defUnit(p)) || unitsOf(p)[0] : null, f = (u && u.factor) || 1;
      const inf = p && INFO[p.id], d = inf && inf.data;
      const row = (l, v, cls, tip) => `<div class="sp-r"><span class="sp-l">${l}</span><span class="sp-v rt${cls ? " " + cls : ""}" title="${esc(tip || String(v).replace(/<[^>]+>/g, ""))}">${v}</span></div>`;
      const unitTxt = "";
      const N = v => `<bdi>${fmt(v)}</bdi>`;
      let html = `<div class="sp-top"><div class="sp-btns"><button type="button" class="sp-ib" data-ip="find" title="بحث عن صنف">${'<svg viewBox="0 0 20 20" width="16" height="16"><circle cx="8.5" cy="8.5" r="5.2" fill="none" stroke="#1b2733" stroke-width="2.2"/><path d="M12.5 12.5L17 17" stroke="#1b2733" stroke-width="2.6" stroke-linecap="round"/></svg>'}</button><button type="button" class="sp-ib" data-ip="edit" title="بطاقة الصنف">${'<svg viewBox="0 0 20 20" width="18" height="18"><rect x="2" y="3" width="13" height="15" rx="1.5" fill="#fff" stroke="#3a6ea5" stroke-width="1.3"/><path d="M4.5 7h8M4.5 10h8M4.5 13h5" stroke="#3a6ea5" stroke-width="1.2"/><path d="M11.5 15.5l1-3 5-5 2 2-5 5z" fill="#e8a33d"/></svg>'}</button></div><div class="sp-ttl">معلومات عن الصنف</div></div>`;
      if (!p) { st.innerHTML = html + `<div class="sp-e">اختر سطراً من الفاتورة أو اضغط 🔍 لعرض معلومات أي صنف</div>`; return; }
      const stock = window.ANOUER_WH && ANOUER_WH.ready ? whQty(p.id) : d ? +d.stock : +p.stock || 0, cost = d ? +d.cost : +p.cost || 0;   // رصيد المخزن المختار
      const buyU = r ? +r.price || 0 : costOf(p, u), saleU = r ? +r.sale || 0 : +u.price || 0;
      const reorder = d ? +d.reorder || 0 : 0;
      const ls = d && d.lastSale, lb = d && d.lastBuy;
      const IO = PURDOC ? PURP() : {}, oSt = IO.iStock !== false, oPr = IO.iPrices !== false;   /* «ما الذي تريده في شاشة معلومات عن الصنف» */
      html += `<div class="sp-pn" title="${esc(p.code)}">${esc(p.name)}</div>${u ? `<div class="sp-un">الأسعار للوحدة: <b>${esc(u.name)}</b>${f > 1 ? ` <small>(×${fmt(f)})</small>` : ""}</div>` : ""}
        ${oSt ? row("الرصيد", `<b class="${stock <= 0 ? "neg" : reorder && stock <= reorder ? "warn" : ""}">${N(stock)}</b>${f > 1 ? ` <small>= <bdi>${fmt(stock / f)}</bdi></small>` : ""}`, "", fmt(stock)) : ""}
        ${oPr ? `${row("سعر الشراء", N(buyU) + unitTxt)}
        ${row("سعر التكلفة", N(cost * f) + unitTxt, "", "متوسط التكلفة المرجّح")}
        ${row("سعر البيع", N(saleU) + unitTxt, saleU && saleU < buyU ? "neg" : "")}
        ${row("اخر سعر بيع", ls ? N(ls.price * (ls.factor ? f / ls.factor : 1)) : d ? "—" : "…")}
        ${row("اخر تاريخ بيع", ls ? esc(ls.date) : d ? "—" : "…")}
        ${row("أخر سعر شراء", lb ? N(lb.price * (lb.factor ? f / lb.factor : 1)) : d ? "—" : "…", lb && r && Math.abs(lb.price / (lb.factor || 1) * f - buyU) > .005 ? (lb.price / (lb.factor || 1) * f < buyU ? "neg" : "pos") : "")}
        ${row("أخر تاريخ شراء", lb ? esc(lb.date) : d ? "—" : "…")}` : ""}
        ${row("حد الطلب", reorder ? fmt(reorder) : "—")}
        ${row("مكان التخزين", esc(whName()))}
        <div class="sp-r"><span class="sp-l">مخزون برقم تسلسلي</span><label class="sp-sw" title="تفعيل تتبع الأرقام التسلسلية لهذا الصنف"><input type="checkbox" data-ip="serial" data-pid="${p.id}"${isSerial(p.id) ? " checked" : ""}><i></i><b>${isSerial(p.id) ? "نعم" : "لا"}</b></label></div>`;
      // تحليل ذكي: هامش الربح، معدل البيع، وكم يكفي المخزون
      if (d) {
        const margin = buyU > 0 && saleU > 0 ? (saleU - buyU) / buyU * 100 : null, perDay = (+d.sold30 || 0) / 30;
        const after = stock + (type === "Purchase" ? 1 : type === "PurchaseReturn" ? -1 : ty.dir || 0) * (r ? (+r.qty || 0) * f : 0);
        const days = perDay > 0 ? Math.floor(after / perDay) : null;
        html += `<div class="sp-an"><div class="sp-ah">تحليل الشراء</div>
          ${margin != null ? `<div><span>هامش الربح</span><b class="${margin < 0 ? "neg" : margin < 10 ? "warn" : "pos"}">${fmt(margin)}%</b></div>` : ""}
          <div><span>مبيعات آخر 30 يوم</span><b>${fmt(d.sold30)}</b></div>
          <div><span>مشتريات آخر 90 يوم</span><b>${fmt(d.bought90)}</b></div>
          ${r ? `<div><span>الرصيد بعد الفاتورة</span><b class="${after < 0 ? "neg" : ""}">${fmt(after)}</b></div>` : ""}
          ${days != null ? `<div><span>يكفي لمدة</span><b class="${days < 7 ? "neg" : days < 30 ? "warn" : "pos"}">${days > 999 ? "+999" : days} يوم</b></div>` : `<div><span>يكفي لمدة</span><b>—</b></div>`}
          ${perDay > 0 && type === "Purchase" ? `<div class="sp-sug">مقترح لشهر: <b><bdi>${fmt(Math.max(0, Math.ceil((perDay * 30 - stock) / f)))}</bdi></b> <bdi>${esc(u.name)}</bdi></div>` : ""}</div>`;
        if (d.hist && d.hist.length) html += `<div class="sp-ah">آخر المشتريات</div><div class="sp-g"><div class="sp-gh h4"><span>التاريخ</span><span>المورد</span><span>الكمية</span><span>السعر</span></div><div class="sp-gb">${d.hist.map(h => `<div class="sp-gr h4"><span>${esc(h.date)}</span><span title="${esc(h.sup || "تعامل نقدي")}">${esc(h.sup || "نقدي")}</span><span title="${esc(h.unit)}">${fmt(h.qty)}</span><span>${fmt(h.price)}</span></div>`).join("")}</div></div>`;
      } else if (inf && inf.err) html += `<div class="sp-e">${esc(inf.err)}</div>`;
      /* الأصناف البديلة: نفس المجموعة (كانت دائماً «لا توجد») */
      const alts = IO.iAlt === false ? [] : prods().filter(x => x.id !== p.id && x.active !== false && x.cat && x.cat === p.cat).slice(0, 6);
      if (IO.iAlt !== false) html += `<div class="sp-sec">الأصناف البديلة لهذا الصنف</div>${alts.length ? alts.map(x => `<div class="sp-wh" title="${esc(x.code || "")}"><span>${esc(x.name)}</span><b class="${(window.ANOUER_WH && ANOUER_WH.ready ? whQty(x.id) : +x.stock || 0) <= 0 ? "neg" : ""}">${fmt(window.ANOUER_WH && ANOUER_WH.ready ? whQty(x.id) : +x.stock || 0)}</b></div>`).join("") : '<div class="sp-e sm">لا توجد أصناف بديلة (نفس المجموعة)</div>'}`;
      if (IO.iAllWh !== false) html += `
        <div class="sp-sec ln">رصيد الصنف فى جميع المخازن</div>${(window.ANOUER_WH ? ANOUER_WH.all(p.id).filter(w => w.qty || w.res || w.id === curWh()) : [{ name: "المخزن الرئيسي", qty: stock, res: 0 }]).map(w => `<div class="sp-wh${w.id === curWh() ? " on" : ""}"><span>${esc(w.name)}${w.res ? ` <small title="المحجوز">(محجوز ${fmt(w.res)})</small>` : ""}</span><b class="${w.qty <= 0 ? "neg" : ""}">${fmt(w.qty)}</b></div>`).join("")}`;
      st.innerHTML = html;
      if (!inf) loadInfo(p.id);
    }
    function loadInfo(pid) {
      if (!B()) { INFO[pid] = { data: { stock: (prodById(pid) || {}).stock || 0, cost: (prodById(pid) || {}).cost || 0, reorder: 0, sold30: 0, bought90: 0, hist: [] } }; renderSide(); return; }
      INFO[pid] = { loading: true };
      call("fm.pur.itemInfo", { id: pid }).then(d => { INFO[pid] = { data: d }; renderSide(); })
        .catch(e => { INFO[pid] = { err: /غير معروف/.test(e.message) ? "التحليل يحتاج إعادة بناء البرنامج (build-exe)" : e.message }; renderSide(); });
    }
    function itemPaneAct(a, b) {
      const r = S.rows[S.sel], p = infoPid ? prodById(infoPid) : r && prodById(r.pid);
      if (a === "find") {
        const el = openPop(b, `<div class="pu-find"><div class="hd">معلومات عن صنف</div><input class="fq" placeholder="الاسم أو الكود أو الباركود" autocomplete="off"><div class="fl"></div></div>`, "pu-findpop", { alignLeft: true });
        const q = el.querySelector(".fq"), fl = el.querySelector(".fl"); let list = [], ix = 0;
        const draw = () => { list = q.value.trim() ? searchProducts(q.value).slice(0, 50) : []; ix = Math.min(ix, Math.max(0, list.length - 1));
          fl.innerHTML = list.map((x, i) => `<div class="fr${i === ix ? " on" : ""}" data-i="${i}" style="grid-template-columns:1fr 90px"><span>${hl(x.name, q.value)}</span><i>${fmt(x.stock)}</i></div>`).join("") || '<div class="pq-empty">اكتب للبحث</div>'; };
        const pick = () => { const x = list[ix]; if (!x) return; closePop(); infoPid = x.id; delete INFO[x.id]; renderSide(); };
        q.addEventListener("input", () => { ix = 0; draw(); });
        el.addEventListener("click", e => { const rr = e.target.closest(".fr"); if (rr) { ix = +rr.dataset.i; pick(); } });
        POP.key = e => { if (e.key === "ArrowDown") { ix = Math.min(list.length - 1, ix + 1); draw(); } else if (e.key === "ArrowUp") { ix = Math.max(0, ix - 1); draw(); } else if (e.key === "Enter") pick(); else if (e.key === "Escape") closePop(); else return false; return true; };
        draw(); setTimeout(() => q.focus(), 0);
      } else if (a === "edit") {
        if (!p) { say("اختر صنفاً أولاً", "w"); return; }
        try { if (typeof itLoad === "function") { itLoad(p); openTab("item", "إضافة صنف", "item"); } else say("بطاقة الصنف غير متاحة", "w"); } catch (e) { say("بطاقة الصنف غير متاحة", "w"); }
      }
    }

    /* لوحة المورد (مطابق DEXEF): التليفون، البريد، حد الإئتمان، الرصيد، العنوان، أخر التعاملات منذ N يوم، الملاحظات */
    const DEALS = {};
    let dealDays = lsGet("pur.dealDays", 365);
    function renderSupPane(sp) {
      const s = supById(S.supId);
      const row = (l, v, cls) => `<div class="sp-r"><span class="sp-l">${l}</span><span class="sp-v${cls ? " " + cls : ""}" title="${esc(v)}">${esc(v)}</span></div>`;
      const dl = s && DEALS[s.id];
      const since = new Date(Date.now() - dealDays * 864e5).toISOString().slice(0, 10);
      const deals = dl && dl.lines ? dl.lines.filter(x => String(x.Date) >= since) : null;
      const CO = PURDOC ? PURP() : {}, oBal = CO.cBal !== false, oLim = CO.cLimit !== false, oLast = CO.cLast !== false, oPer = CO.cPers !== false;   /* «ما الذي تريده في شاشة معلومات عن المورد» */
      sp.innerHTML = `<div class="sp-top"><button type="button" class="sp-ib" data-sp="edit" title="${s ? "بيانات " + WHO : WHO.slice(2) + " جديد"}"><svg viewBox="0 0 20 20" width="18" height="18"><rect x="2" y="3" width="13" height="15" rx="1.5" fill="#fff" stroke="#3a6ea5" stroke-width="1.3"/><circle cx="7" cy="8" r="2" fill="#3a6ea5"/><path d="M4 13c.5-1.8 1.6-2.6 3-2.6s2.5.8 3 2.6" fill="#3a6ea5"/><path d="M11.5 15.5l1-3 5-5 2 2-5 5z" fill="#e8a33d"/></svg></button>
          <div class="sp-nm">${s ? esc(s.name) : ""}</div></div>
        ${oPer ? row("التليفون", s ? [s.ph, s.ph2].filter(Boolean).join(" / ") : "") + '<div class="sp-gap"></div>' + row("البريد", s ? s.mail : "") : ""}
        ${oLim ? row("حد الإئتمان", s && s.lim ? fmt(s.lim) : "") : ""}
        ${oBal ? row("الرصيد", s ? fmt(s.bal) : "", s && s.bal < 0 ? "neg" : s && s.lim && s.bal > s.lim ? "warn" : "") : ""}
        ${oPer ? row("العنوان", s ? s.addr : "") : ""}
        ${oLast ? `<div class="sp-deal"><span class="sp-l">أخر التعاملات</span><span class="sp-since">منذ <input class="sp-days" value="${dealDays}" inputmode="numeric" title="عدد الأيام"> يوم</span><button type="button" class="sp-ib" data-sp="deals" title="عرض التعاملات"><svg viewBox="0 0 20 20" width="16" height="16"><circle cx="8.5" cy="8.5" r="5.2" fill="none" stroke="#1b2733" stroke-width="2.2"/><path d="M12.5 12.5L17 17" stroke="#1b2733" stroke-width="2.6" stroke-linecap="round"/></svg></button></div>
        <div class="sp-g"><div class="sp-gh"><span>التاريخ</span><span>التعامل</span><span>القيمة</span></div><div class="sp-gb">${!s ? "" : !dl ? '<div class="sp-e">اضغط 🔍 لعرض التعاملات</div>' : dl.loading ? '<div class="sp-e">جارٍ التحميل…</div>' : dl.err ? `<div class="sp-e neg">${esc(dl.err)}</div>` :
          deals.length ? deals.slice().reverse().map(x => { const v = (+x.Credit || 0) - (+x.Debit || 0); return `<div class="sp-gr"><span>${esc(String(x.Date).slice(0, 10))}</span><span title="${esc(x.Type + " " + (x.No || ""))}">${esc(x.Type)}${x.No ? " " + esc(x.No) : ""}</span><span class="${v < 0 ? "neg" : ""}">${fmt(Math.abs(v))}</span></div>`; }).join("") : '<div class="sp-e">لا توجد تعاملات في هذه المدة</div>'}</div></div>
` : ""}
        ${oPer ? `<div class="sp-notes"><span class="sp-l">الملاحظات</span><button type="button" class="sp-ib" data-sp="note" title="تعديل الملاحظات"><svg viewBox="0 0 20 20" width="18" height="18"><path d="M3 3h14v9l-5 5H3z" fill="#f7c948" stroke="#c99a10"/><path d="M12 17v-5h5" fill="#e0ad22" stroke="#c99a10"/><path d="M14 2l3 3" stroke="#3b7dd8" stroke-width="2"/></svg></button></div>
        <div class="sp-nv" title="${esc(s ? s.note : "")}">${s ? esc(s.note) : ""}</div>` : ""}`;
      if (s && !dl && B() && oLast) loadDeals(s.id);
    }
    function loadDeals(id) {
      if (ty.cust) {   // تعاملات العميل: عروضه/أوامره السابقة من نفس النوع (بلا أثر مالي)
        const sh = l => { DEALS[id] = { lines: l.filter(d => d.supId == id).map(d => ({ Date: d.date, Type: ty.t, No: d.no, Credit: +d.total || 0, Debit: 0 })) }; renderSide(); };
        if (!B()) { sh(LOCAL.docs.filter(d => d.type === type)); return; }
        DEALS[id] = { loading: true }; renderSide();
        call("fm.pur.list", { type, from: "2000-01-01", to: today() }).then(l => sh(l || [])).catch(e => { DEALS[id] = { err: e.message }; renderSide(); });
        return;
      }
      if (!B()) { DEALS[id] = { lines: LOCAL.docs.filter(d => d.supId === id).map(d => ({ Date: d.date, Type: TY[d.type].t, No: d.no, Credit: d.type === "Purchase" ? d.total : 0, Debit: d.type === "PurchaseReturn" ? d.total : 0 })) }; renderSide(); return; }
      DEALS[id] = { loading: true }; renderSide();
      call("fm.suppliers.statement", { id }).then(d => { DEALS[id] = { lines: (d && d.lines) || [] }; renderSide(); })
        .catch(e => { DEALS[id] = { err: e.message }; renderSide(); });
    }
    function supPaneAct(a, b) {
      const s = supById(S.supId);
      if (a === "edit") {
        if (!s) { newSupplier(); return; }
        if (ty.cust) { try { if (window.__CRV && __CRV.edit) __CRV.edit(s.src || s); else openTab("crev", "مراجعة العملاء", "crev"); } catch (e) { say("شاشة العملاء غير متاحة", "w"); } return; }
        if (window.ANOUER_SUPPLIERS && ANOUER_SUPPLIERS.edit) ANOUER_SUPPLIERS.edit(s.id); else say("شاشة الموردين غير متاحة", "w");
      } else if (a === "deals") {
        if (!s) { say(ty.cust ? "اختر عميلاً أولاً" : "اختر مورداً أولاً", "w"); return; }
        const d = root.querySelector(".sp-days"); dealDays = Math.max(1, Math.min(9999, parseInt(d && d.value) || 365)); lsSet("pur.dealDays", dealDays);
        loadDeals(s.id);
      } else if (a === "note") {
        if (!s) { say("اختر مورداً أولاً", "w"); return; }
        const el = openPop(b, `<div class="pu-desc"><div class="hd">ملاحظات — ${esc(s.name)}</div><textarea rows="5">${esc(s.note || "")}</textarea><div class="ft"><button type="button" class="pu-bt g">حفظ</button></div></div>`, "pu-descpop", { alignLeft: true });
        const ta = el.querySelector("textarea"); setTimeout(() => ta.focus(), 0);
        el.querySelector("button").addEventListener("click", () => {
          const note = ta.value.trim(); closePop();
          if (!B() || !s.raw) { s.note = note; if (s.src) { s.src.x = Object.assign({}, s.src.x || {}, { note }); } renderSide(); return; }
          const x = Object.assign({}, s.x || {}, { note });
          call("fm.suppliers.save", Object.assign({}, s.raw, { Extra: JSON.stringify(x) })).then(() => { s.note = note; s.x = x; s.raw.Extra = JSON.stringify(x); renderSide(); say("تم حفظ ملاحظات المورد", "s");
            try { if (window.ANOUER_SUPPLIERS && ANOUER_SUPPLIERS.reload) ANOUER_SUPPLIERS.reload(); } catch (e) { } }).catch(e => say("لم تُحفظ الملاحظات: " + e.message, "e"));
        });
      }
    }

    /* ---------- المورد ---------- */
    /* لمسة: إشارة «تلقائي» عند تغيّر التعامل حسب بطاقة الطرف */
    function dealFlash(btn, txt, credit) {
      try { if (!btn) return; const host = btn.closest("label,.pu-f,.ih-f,div") || btn.parentElement; btn.classList.remove("deal-auto"); void btn.offsetWidth; btn.classList.add("deal-auto");
        document.querySelectorAll(".deal-chip").forEach(x => x.remove());
        const c = document.createElement("span"); c.className = "deal-chip" + (credit ? " cr" : ""); c.innerHTML = `<i>${credit ? "⏳" : "💵"}</i><b>${txt}</b><small>تلقائي</small>`;
        document.body.appendChild(c); const r = btn.getBoundingClientRect(); c.style.left = Math.max(6, r.left + r.width / 2 - c.offsetWidth / 2) + "px"; c.style.top = (r.bottom + 6) + "px";
        setTimeout(() => { c.classList.add("out"); setTimeout(() => c.remove(), 350); }, 2600); setTimeout(() => btn.classList.remove("deal-auto"), 1600); } catch (e) { }
    }
    function setSupplier(s, silent) {
      S.supId = s ? s.id : 0;
      F("supName").value = s ? s.name : "";
      F("supCode").value = s ? s.code : "";
      if (!s && S.credit) setCredit(false, true);
      /* التعامل الافتراضي في بطاقة المورد/العميل (أجل / كاش) يطبَّق تلقائياً على المستند الجديد — وإلا الافتراضي العام */
      const tm = s && s.x && String(s.x.terms || "").trim();
      if (s && ty.pay && !S.id && tm) { const want = /^[أاآإ]جل$/.test(tm); if (want !== !!S.credit) { setCredit(want, true); if (!!S.credit === want) dealFlash(root.querySelector(".pu-deal .ib"), want ? "أجل" : "كاش", want); } }
      else if (s && ty.pay && !S.credit && !S.id && (M("payDefault") === "credit" || PURP().cash === false)) setCredit(true, true);   // طريقة الدفع الافتراضية: أجل («التعاملات الكاش دائماً = لا»)
      if (!silent) markDirty();
      updTotals(); renderSide();
    }
    function supPicker(anchorInput, q) {
      const el = openPop(anchorInput.closest(".pu-in"), `<div class="pu-spk"><div class="sk-h"><div></div><div>الكود</div><div>الاسم</div><div>الرصيد</div><div></div></div><div class="sk-f"><div>⏷</div><div>ᴀʙc</div><div>ᴀʙc</div><div>=</div><div></div></div><div class="sk-l"></div><div class="sk-ft"><button type="button" class="sk-x" data-a="none" title="تعامل نقدي">✕</button><span class="sk-n"></span></div></div>`, "pu-skpop");
      let list = [], ix = 0;
      const draw = () => {
        const qq = norm(anchorInput.value === (supById(S.supId) || {}).name ? "" : anchorInput.value);
        list = PARTY().filter(s => !qq || norm(s.name).includes(qq) || norm(s.code).includes(qq) || (ty.cust && s.ph && String(s.ph).includes(qq)));
        ix = Math.min(ix, Math.max(0, list.length - 1));
        el.querySelector(".sk-l").innerHTML = list.length ? list.map((s, i) => `<div class="sk-r${i === ix ? " on" : ""}${s.id === S.supId ? " cur" : ""}" data-i="${i}"><div></div><div>${esc(s.code)}</div><div>${esc(s.name)}</div><div class="${s.bal < 0 ? "neg" : ""}">${s.bal < 0 ? "[" + fmt(-s.bal) + "]" : fmt(s.bal)}</div><div class="cur">DZD</div></div>`).join("")
          : `<div class="pq-empty">${ty.cust ? "لا يوجد عملاء" : "لا يوجد موردون"}${B() ? "" : " (معاينة)"} — اضغط ${I.user} لإضافة ${ty.cust ? "عميل" : "مورد"}</div>`;
        el.querySelector(".sk-n").textContent = list.length + (ty.cust ? " عميل" : " مورد");
        const on = el.querySelector(".sk-r.on"); if (on) on.scrollIntoView({ block: "nearest" });
      };
      el.addEventListener("mousedown", e => e.preventDefault());
      el.addEventListener("click", e => {
        const r = e.target.closest(".sk-r"); if (r) { ix = +r.dataset.i; pick(); return; }
        if (e.target.closest('[data-a="none"]')) { closePop(); setSupplier(null); }
      });
      const pick = () => { const s = list[ix]; if (!s) return; closePop(); setSupplier(s); focusCell(-1, "name"); };
      POP.key = e => {
        const k = e.key;
        if (k === "ArrowDown") { ix = Math.min(list.length - 1, ix + 1); draw(); }
        else if (k === "ArrowUp") { ix = Math.max(0, ix - 1); draw(); }
        else if (k === "Enter") {
          /* اسم غير موجود + Enter → «إضافة مورد سريع» (مثل DEXEF) */
          if (!list.length && anchorInput.value.trim()) { closePop(); newSupplier(); } else pick();
        }
        else if (k === "Escape") { closePop(); const s = supById(S.supId); anchorInput.value = s ? s.name : ""; }
        else return false;
        return true;
      };
      D.supDraw = draw;
      draw();
    }
    function setCredit(v, silent) {
      if (v && !S.supId) { say("التعامل الآجل يتطلب اختيار مورد", "w"); v = false; }
      S.credit = !!v; S.paidTouched = false;
      const b = root.querySelector(".pu-deal .ib");
      b.innerHTML = S.credit ? I.credit : I.coins; b.title = S.credit ? "أجل" : "كاش";
      root.classList.toggle("is-credit", S.credit);
      if (S.credit) F("paid").value = "0";
      if (!silent) markDirty();
      updTotals();
    }

    /* ---------- الأحداث: الشبكة ---------- */
    grid.addEventListener("focusin", e => {
      const row = e.target.closest(".pu-d"); if (row) select(+row.dataset.i);
      if (e.target.matches("input[data-c]") && e.target.select) try { e.target.select(); } catch (x) { }
    });
    let ddWasOpen = false;
    grid.addEventListener("mousedown", e => { if (e.target.closest("[data-a=pkdd]")) { e.preventDefault(); ddWasOpen = !!(PK && PK.input === newName()); } if (e.target.closest("[data-a=rdd]")) e.preventDefault(); }, true);
    grid.addEventListener("mousedown", e => { const row = e.target.closest(".pu-d"); if (row && !e.target.closest("input,select,button")) { select(+row.dataset.i); } });
    /* ---------- نقل السطر لأعلى / لأسفل بسحب رقمه (مثل DEXEF ONE) — Esc للإلغاء ، Ctrl+Shift+↑/↓ من لوحة المفاتيح ---------- */
    (function rowDrag() {
      if (!document.getElementById("pu-rdg-css")) {
        const st = document.createElement("style"); st.id = "pu-rdg-css";
        st.textContent = `.pu-d .ind{touch-action:none;user-select:none;-webkit-user-select:none;cursor:pointer}
        .pu-rdg-ghost{position:fixed;z-index:12000;pointer-events:none;overflow:hidden;background:#fff;border:1px solid #9dbbe0;box-shadow:0 6px 18px rgba(20,60,120,.25);direction:ltr}
        .pu-rdg-ghost>.pu-gr{position:absolute;top:0;left:0;direction:rtl;background:#dbe9fb!important}
        .pu-rdg-line{position:fixed;z-index:11999;pointer-events:none;height:4px;margin-top:-2px;background:#a9d8f7;border-top:1px solid #4aa8e6;border-bottom:1px solid #4aa8e6}
        .pu-rdg-line:before,.pu-rdg-line:after{content:"";position:absolute;top:-5px;width:0;height:0;border:6px solid transparent}
        .pu-rdg-line:before{right:-1px;border-right-color:#1a7fd0}.pu-rdg-line:after{left:-1px;border-left-color:#1a7fd0}
        body.pu-rdg-on,body.pu-rdg-on *{cursor:move!important}
        .pu-d.pu-rdg-src{opacity:.5}`;
        document.head.appendChild(st);
      }
      const wrap = () => grid.closest(".pu-gwrap") || grid.parentElement || grid;
      const vis = () => Array.from(grid.querySelectorAll(".pu-d[data-i]")).filter(el => el.offsetParent !== null);
      function moveRow(from, to) {
        if (from === to || from < 0 || to < 0 || from >= S.rows.length || to >= S.rows.length) return false;
        const r = S.rows.splice(from, 1)[0]; S.rows.splice(to, 0, r);
        S.sel = to; D.insAt = null; markDirty(); renderGrid(); updTotals(); renderSide(); flash(to);
        const el = grid.querySelector(`.pu-d[data-i="${to}"]`); if (el) try { el.scrollIntoView({ block: "nearest" }); } catch (x) { }
        return true;
      }
      let G = null;
      const gap = y => {
        const els = vis(); if (!els.length) return null;
        for (const el of els) { const r = el.getBoundingClientRect(); if (y < r.top + r.height / 2) return { p: +el.dataset.i, y: r.top }; }
        const l = els[els.length - 1]; return { p: +l.dataset.i + 1, y: l.getBoundingClientRect().bottom };
      };
      function place(e) {
        const w = wrap(), wr = w.getBoundingClientRect();
        G.ghost.style.left = (e.clientX + 2) + "px"; G.ghost.style.top = (e.clientY - 10) + "px";
        const g = gap(Math.max(wr.top, Math.min(wr.bottom, e.clientY))); if (!g) return;
        G.to = g.p > G.from ? g.p - 1 : g.p;
        G.line.style.display = G.to === G.from ? "none" : "block";
        G.line.style.left = wr.left + "px"; G.line.style.width = w.clientWidth + "px";
        G.line.style.top = Math.max(wr.top, Math.min(wr.bottom, g.y)) + "px";
        G.vy = e.clientY < wr.top + 34 ? -1 : e.clientY > wr.bottom - 26 ? 1 : 0;
      }
      function begin() {
        const src = grid.querySelector(`.pu-d[data-i="${G.from}"]`); if (!src) return false;
        const r = src.getBoundingClientRect(), gh = document.createElement("div"); gh.className = "pu-rdg-ghost";
        gh.style.width = Math.min(430, r.width) + "px"; gh.style.height = Math.max(26, Math.min(r.height, 30)) + "px";
        const cl = src.cloneNode(true); cl.classList.remove("sel"); cl.style.width = r.width + "px";
        const si = src.querySelectorAll("input,select"); cl.querySelectorAll("input,select").forEach((x, k) => { x.tabIndex = -1; if (si[k]) x.value = si[k].value; });
        gh.appendChild(cl); document.body.appendChild(gh);
        const ln = document.createElement("div"); ln.className = "pu-rdg-line"; ln.style.display = "none"; document.body.appendChild(ln);
        src.classList.add("pu-rdg-src"); document.body.classList.add("pu-rdg-on");
        G.ghost = gh; G.line = ln; G.on = true;
        G.timer = setInterval(() => { if (G && G.vy) { wrap().scrollTop += G.vy * 14; if (G.last) place(G.last); } }, 30);
        try { const a = document.activeElement; if (a && grid.contains(a)) a.blur(); } catch (x) { }
        return true;
      }
      const eat = e => { e.stopPropagation(); e.preventDefault(); };
      function finish(drop) {
        if (!G) return; const g = G; G = null;
        window.removeEventListener("pointermove", mv, true); window.removeEventListener("pointerup", up, true);
        window.removeEventListener("pointercancel", cancel, true); window.removeEventListener("keydown", esc, true);
        if (g.timer) clearInterval(g.timer); if (g.ghost) g.ghost.remove(); if (g.line) g.line.remove();
        document.body.classList.remove("pu-rdg-on");
        const s0 = grid.querySelector(".pu-rdg-src"); if (s0) s0.classList.remove("pu-rdg-src");
        if (drop && g.on && g.to != null && g.to !== g.from) moveRow(g.from, g.to);
        if (g.on) setTimeout(() => window.removeEventListener("click", eat, true), 0);
      }
      function mv(e) {
        if (!G) return; G.last = e;
        if (!G.on) { if (Math.abs(e.clientY - G.y0) < 5 && Math.abs(e.clientX - G.x0) < 8) return; if (!begin()) { finish(false); return; } window.addEventListener("click", eat, true); }
        e.preventDefault(); place(e);
      }
      function up(e) { if (G && G.on) e.preventDefault(); finish(true); }
      function cancel() { finish(false); }
      function esc(e) { if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); finish(false); } }
      grid.addEventListener("pointerdown", e => {
        if (e.button !== 0 || G) return;
        const ind = e.target.closest(".ind"), row = ind && ind.closest(".pu-d");
        if (!row || e.target.closest("button")) return;
        const i = +row.dataset.i; if (!(i >= 0) || i >= S.rows.length) return;
        e.preventDefault(); select(i);
        G = { from: i, to: null, x0: e.clientX, y0: e.clientY, on: false };
        window.addEventListener("pointermove", mv, true); window.addEventListener("pointerup", up, true);
        window.addEventListener("pointercancel", cancel, true); window.addEventListener("keydown", esc, true);
      }, true);
      root.addEventListener("keydown", e => {
        if (!e.ctrlKey || !e.shiftKey || e.altKey || (e.key !== "ArrowUp" && e.key !== "ArrowDown")) return;
        if (!grid.contains(e.target) && e.target !== grid && !root.contains(e.target)) return;
        const s0 = S.sel; if (!(s0 >= 0) || !S.rows[s0]) return;
        const to = s0 + (e.key === "ArrowUp" ? -1 : 1); if (to < 0 || to >= S.rows.length) return;
        e.preventDefault(); e.stopPropagation();
        const k = e.target && e.target.dataset ? e.target.dataset.c : null;
        moveRow(s0, to);
        if (k) try { focusCell(to, k); } catch (x) { }
      }, true);
    })();
    /* سعر البيع لوحدة السطر + ربط الوحدات (إعداد «ربط سعر البيع بين وحدات الصنف»):
       سعر القطعة × عدد القطع في الوحدة — القطعة 250 ⇒ الكرتونة (20) = 5000 ، وسعر الكرتونة يمكن تعديله يدوياً بعدها
       الأسعار المعدّلة لكل وحدة تُحفظ في r.sx وتُرسل عند الحفظ (UnitSales) */
    /* «الخصائص ← فواتير المشتريات ← ربط الأسعار بين وحدات الصنف» */
    const linkOn = () => { try { const v = window.ANOUER_PROPS && ANOUER_PROPS.get("inv.pur", {}); return !(v && v.linkUnits === false); } catch (e) { return true; } };
    function setSale(r, v) {
      r.sale = v; r.sx = r.sx || {}; r.sx[r.unit] = v;
      const p = prodById(r.pid), us = p ? unitsOf(p) : [];
      if (us.length < 2 || !linkOn()) return;
      const cu = unitByName(p, r.unit); if (!cu) return;
      const fu = +cu.factor || 1;
      /* الربط من الوحدة الصغرى إلى الأكبر فقط: القطعة ← الكرتونة تلقائياً.
         تعديل الكرتونة يدوياً يبقى كما كتبته (لا يغيّر القطعة) ولا يمسحه تعديل القطعة بعده */
      r.sxm = r.sxm || {};
      if (us.some(w => (+w.factor || 1) < fu)) r.sxm[r.unit] = 1;
      us.forEach(w => { const fw = +w.factor || 1; if (w.name === r.unit || fw <= fu || r.sxm[w.name]) return; const ow = +w.price || 0;
        if (!(v > 0) || v === r.sale0) { delete r.sx[w.name]; return; }          /* رجوع للسعر الأصلي ← الوحدات الأكبر كما هي */
        const nv = r2(v / fu * fw); if (nv > 0 && Math.abs(nv - ow) > .004) r.sx[w.name] = nv; else delete r.sx[w.name]; });
    }
    /* «كرتونة 6Bouat ← 1,200» للوحدات الأخرى المعدّلة */
    function linkedTxt(r) {
      const p = prodById(r.pid); if (!p || !r.sx) return "";
      return unitsOf(p).filter(w => w.name !== r.unit && r.sx[w.name] > 0 && Math.abs(r.sx[w.name] - (+w.price || 0)) > .004).map(w => w.name + " ← " + fmt(r.sx[w.name]) + (r.sxm && r.sxm[w.name] ? " يدوي" : "") + " (كان " + fmt(+w.price || 0) + ")").join(" · ");
    }
    /* أسعار البيع الجديدة لوحدات الصنف الأخرى (غير وحدة السطر) للحفظ */
    /* سعر الشراء + ربط الوحدات (نفس إعداد «ربط … بين وحدات الصنف»): القطعة × عدد القطع للوحدات الأكبر ، والكبرى يدوياً تبقى كما كتبتها */
    function setBuy(r, v) {
      r.price = v; r.px = r.px || {}; r.px[r.unit] = v;
      const p = prodById(r.pid), us = p ? unitsOf(p) : [];
      if (us.length < 2 || !linkOn()) return;
      const cu = unitByName(p, r.unit); if (!cu) return;
      const fu = +cu.factor || 1; r.pxm = r.pxm || {};
      if (us.some(w => (+w.factor || 1) < fu)) r.pxm[r.unit] = 1;
      us.forEach(w => { const fw = +w.factor || 1; if (w.name === r.unit || fw <= fu || r.pxm[w.name]) return;
        if (!(v > 0)) { delete r.px[w.name]; return; }
        r.px[w.name] = r2(v / fu * fw); });
    }
    function linkedBuyTxt(r) {
      const p = prodById(r.pid); if (!p || !r.px) return "";
      return unitsOf(p).filter(w => w.name !== r.unit && r.px[w.name] > 0).map(w => w.name + " ← " + fmt(r.px[w.name]) + (r.pxm && r.pxm[w.name] ? " يدوي" : "")).join(" · ");
    }
    /* أسعار الشراء الجديدة لوحدات الصنف الأخرى (تُسجّل في البطاقة كآخر سعر شراء) */
    function unitBuys(r) {
      const p = prodById(r.pid); if (!p || !r.px) return [];
      return unitsOf(p).filter(w => w.name !== r.unit && w.puid && r.px[w.name] > 0 && Math.abs(r.px[w.name] - (+w.buy || 0)) > .004).map(w => ({ ProductUnitId: w.puid, Price: r.px[w.name] }));
    }
    function unitSales(r) {
      const p = prodById(r.pid); if (!p || !r.sx) return [];
      return unitsOf(p).filter(w => w.name !== r.unit && w.puid && r.sx[w.name] > 0 && Math.abs(r.sx[w.name] - (+w.price || 0)) > .004).map(w => ({ ProductUnitId: w.puid, Sale: r.sx[w.name] }));
    }
    /* تغيير سعر الشراء عن سعر الصنف الحالى ← نافذة «تم التغيير فى السعر للصنف» (سعر الشراء محدد) */
    function askPrice(i) {
      const r = S.rows[i]; if (!r || !r.pid) return;
      const v = r2(+r.price || 0), base = r2(+r.lastCost || 0), old = r._pOld == null ? base : r2(r._pOld); delete r._pOld;
      if (!(v > 0) || Math.abs(v - base) < .005 || r._pa === v) return;
      const p = prodById(r.pid), f = r.factor || 1, u = p ? unitByName(p, r.unit) : null;
      /* عدم السماح بالبيع أقل من الشراء: سعر الشراء الجديد أعلى من سعر البيع ← النافذة تتحول للأحمر ويرجع السعر كما كان */
      const saleU = r2(+r.sale > 0 ? +r.sale : u ? +u.price || 0 : (p ? +p.price || 0 : 0) * f), allow = window.ANOUER_IACC ? ANOUER_IACC.loss(p) : !!(p && (p.allowLoss || +p.salesDisc > 0));
      if (!allow && saleU > 0 && v > saleU + .004) {
        purPriceAsk({ v, name: r.name, block: { sale: saleU, old },
          revert: () => { setBuy(r, old); r._pa = undefined; applyDp(r); markDirty(); renderRow(i); updTotals(); say("لا يمكن البيع بأقل من سعر الشراء — تم إرجاع السعر إلى " + fmt(old), "e"); },
          after: () => setTimeout(() => focusCell(i, "price"), 0) });
        return;
      }
      r._pa = v;
      purPriceAsk({ v, name: r.name,
        cur: k => !p ? 0 : k === "cost" ? costOfBase(p, u) : k === "price" ? (u ? +u.price || 0 : +p.price || 0) * (u ? 1 : f) : r2((+p[k] || 0) * f),
        apply: (k, l) => {
          if (p) {
            if (k === "cost") { p.cost = r2(v / f); r.lastCost = v; if (u) u.buy = v; }
            else if (k === "price") { r.sale = v; if (u) u.price = v; else p.price = r2(v / f); }
            else p[k] = r2(v / f);
          }
          markDirty(); renderRow(i); updTotals(); say("تم تعديل «" + l + "» للصنف إلى " + fmt(v), "s");
        },
        after: () => setTimeout(() => focusCell(i, "price"), 0) });
    }
    grid.addEventListener("input", e => {
      const t = e.target, c = t.dataset.c; if (!c) return;
      const nw = t.closest(".pu-new"), row = t.closest(".pu-d"), i = row ? +row.dataset.i : -1;
      if (nw || ((c === "name") && row)) {
        if (c === "name" && D.pend && nw) clearPend(true);
        if (c === "name") { if (t.value.trim()) { if (!PK || PK.input !== t) openPicker(t, nw ? null : i); else { PK.el.querySelector(".pq-q").value = t.value; PK.draw(); } } }
        return;
      }
      if (!row) return;
      const r = S.rows[i]; if (!r) return;
      if (c.startsWith("x:")) { const k = c.slice(2), def = CMAP[k]; r.x = r.x || {}; r.x[k] = t.type === "checkbox" ? t.checked : def && def.x === "num" ? num(t.value) : t.value; markDirty();
        if (CALC_X[k]) xChanged(i, k); return; }
      if (c === "qty" || c === "price" || c === "dp" || c === "disc" || c === "sale") {
        const v = num(t.value);
        if (c === "qty") { r.qty = v; applyDp(r); }
        else if (c === "price") { if (r._pOld == null) r._pOld = +r.price || 0; setBuy(r, v); applyDp(r); }
        else if (c === "dp") { r.dp = Math.min(100, Math.max(0, v)); r.disc = r2(lineGross(r) * r.dp / 100); }
        else if (c === "disc") { r.disc = Math.min(Math.max(0, v), lineGross(r)); r.dp = lineGross(r) ? r2(r.disc / lineGross(r) * 100) : 0; }
        else if (c === "sale") { if (PURP().editSale !== false) setSale(r, v); }
        markDirty(); renderRow(i); updTotals();
      } else if (c === "notes") { r.notes = t.value; markDirty(); }
      else if (c === "code") { /* يُعالج عند Enter */ }
    });
    grid.addEventListener("change", e => {
      const t = e.target, c = t.dataset.c, row = t.closest(".pu-d"); if (!row) return;
      const i = +row.dataset.i, r = S.rows[i]; if (!r) return;
      if (c === "unit") {
        const p = prodById(r.pid), u = p && unitByName(p, t.value); if (!u) return;
        const oldF = r.factor || 1, perBase = (+r.price || 0) / oldF;
        if (r.sale > 0 && r.sale !== r.sale0) { r.sx = r.sx || {}; r.sx[r.unit] = r.sale; }
        const untouched = Math.abs((+r.price || 0) - (r.lastCost || 0)) < .005;
        if (!untouched && r.price > 0) { r.px = r.px || {}; r.px[r.unit] = r.price; }
        r.unit = u.name; r.puid = u.puid || 0; r.factor = u.factor || 1;
        r.lastCost = costOf(p, u);
        /* سعر الشراء لكل وحدة محفوظ في السطر (r.px): القطعة 77 ⇒ الكرتونة (25) = 1925 تلقائياً ، أو ما كتبته يدوياً للكرتونة
           وإلا: سعر لم يعدّله المستخدم → تكلفة الوحدة الجديدة؛ سعر معدّل → نفس سعر القطعة × عدد القطع */
        r.price = r.px && r.px[u.name] > 0 ? r.px[u.name] : untouched || !linkOn() ? r.lastCost : (r2(perBase * r.factor) || r.lastCost);
        /* سعر البيع لكل وحدة يبقى محفوظاً في السطر (r.sx) — تعديل القطعة لا يضيع عند التبديل للكرتونة والعكس */
        r.sale = r.sx && r.sx[u.name] > 0 ? r.sx[u.name] : +u.price || 0; r.sale0 = +u.price || 0; applyDp(r);
        LASTUNIT[p.id] = u.name; lsSet("pur.lastUnit", LASTUNIT);
        markDirty(); renderRow(i); updTotals(); renderSide(); focusCell(i, "qty");
      } else if (c === "price" && type === "Purchase") { const l = linkedBuyTxt(S.rows[i]); if (l) say("ربط الوحدات (الشراء) — " + l, "s"); askPrice(i); }
      else if (c === "sale") { const l = linkedTxt(r); if (l) say("ربط الوحدات — " + l, "s"); }
      else if (c === "tax") { r.tax = t.checked; markDirty(); updTotals(); }
      else if (c && c.startsWith("x:") && t.type === "checkbox") { const k = c.slice(2); r.x = r.x || {}; r.x[k] = t.checked; markDirty(); if (CALC_X[k]) xChanged(i, k); }
    });
    grid.addEventListener("click", e => {
      const b = e.target.closest("[data-a]"); if (!b) return;
      const row = b.closest(".pu-d"), i = row ? +row.dataset.i : -1;
      if (b.dataset.a === "pkdd") {
        const n = newName(); if (!n) return;
        if (ddWasOpen) { ddWasOpen = false; closePop(); n.focus(); return; }
        n.focus(); openPicker(n, null, true); return;
      }
      if (b.dataset.a === "rdd" && row) {   // تبديل صنف السطر بصنف آخر (الكمية تبقى)
        if (PK && PK.rowIdx === i) { closePop(); return; }
        select(i); const inp = row.querySelector('[data-c="name"]'); if (inp) { inp.focus({ preventScroll: true }); openPicker(inp, i, true); } return;
      }
      if (b.dataset.a === "rdel") ask("هل تريد حذف هذا السطر", () => delRow(i));
      else if (b.dataset.a === "rinfo") { select(i); showSide("stats"); }
    });
    /* قائمة الزر الأيمن للشبكة (مطابق DEXEF) */
    const CI = {
      copy: '<svg viewBox="0 0 18 18"><rect x="6" y="5" width="9" height="11" rx="1" fill="#fff" stroke="#6d7785" stroke-width="1.2"/><path d="M4 13V3a1 1 0 0 1 1-1h7" fill="none" stroke="#6d7785" stroke-width="1.2"/><path d="M8 8.5h5M8 11h5M8 13.5h3" stroke="#9aa3ae"/></svg>',
      paste: '<svg viewBox="0 0 18 18"><rect x="2.5" y="3" width="10" height="13" rx="1" fill="#e8a33d"/><rect x="5" y="1.5" width="5" height="3" rx=".8" fill="#6d7785"/><rect x="7" y="7" width="8.5" height="9.5" rx="1" fill="#fff" stroke="#6d7785"/><path d="M9 10h4.5M9 12.5h4.5" stroke="#9aa3ae"/></svg>',
      del: '<svg viewBox="0 0 18 18"><rect x="9" y="3" width="7" height="12" fill="#fff" stroke="#7a8796"/><path d="M10.5 6h4M10.5 9h4M10.5 12h4" stroke="#e53935" stroke-width="1.4"/><path d="M1.5 9h6M4.5 6l-3 3 3 3" fill="none" stroke="#1f7ad8" stroke-width="1.6"/></svg>',
      find: '<svg viewBox="0 0 18 18" fill="none"><circle cx="7.5" cy="7.5" r="4.8" stroke="#1f7ad8" stroke-width="2"/><path d="M11 11l5 5" stroke="#1f7ad8" stroke-width="2.4" stroke-linecap="round"/></svg>',
      cols: '<svg viewBox="0 0 18 18" fill="#7d8da3"><rect x="1.5" y="1.5" width="4.5" height="4.5"/><rect x="6.8" y="1.5" width="4.5" height="4.5"/><rect x="12" y="1.5" width="4.5" height="4.5"/><rect x="1.5" y="6.8" width="4.5" height="4.5"/><rect x="6.8" y="6.8" width="4.5" height="4.5"/><rect x="12" y="6.8" width="4.5" height="4.5"/><rect x="1.5" y="12" width="4.5" height="4.5"/><rect x="6.8" y="12" width="4.5" height="4.5"/><rect x="12" y="12" width="4.5" height="4.5"/></svg>',
      pen: '<svg viewBox="0 0 18 18"><path d="M3 15l1-4 8-8 3 3-8 8z" fill="#d5d9df" stroke="#a7aeb8"/></svg>'
    };
    function copyRow(i) {
      const r = S.rows[i]; if (!r) { say("اختر سطراً أولاً", "w"); return; }
      PCLIP = JSON.parse(JSON.stringify(r));
      try { navigator.clipboard.writeText([r.code, r.name, r.unit, r.qty, r.price, lineTotal(r)].join("\t")).catch(() => { }); } catch (e) { }
      say("تم نسخ السطر: " + r.name, "s");
    }
    function pasteRow() {
      if (!PCLIP) { say("لا يوجد سطر منسوخ", "w"); return; }
      const n = JSON.parse(JSON.stringify(PCLIP)), p = prodById(n.pid);
      if (p) { const u = unitByName(p, n.unit); if (u) { n.lastCost = costOf(p, u); n.puid = u.puid || n.puid; n.factor = u.factor || n.factor; } }
      const ex = S.rows.findIndex(r => r.pid === n.pid && r.unit === n.unit);
      if (ex >= 0) {   // نفس الصنف والوحدة → دمج الكمية
        const r = S.rows[ex]; r.qty = r2((+r.qty || 0) + (+n.qty || 0)); applyDp(r); S.sel = ex;
        markDirty(); renderGrid(); updTotals(); renderSide(); flash(ex); focusCell(ex, "qty");
        say("تم اللصق — دُمج مع سطر «" + r.name + "» (الكمية " + fmt(r.qty) + ")", "s");
      } else {
        const at = S.sel >= 0 && S.sel < S.rows.length ? S.sel + 1 : S.rows.length;
        S.rows.splice(at, 0, n); S.sel = at; markDirty(); renderGrid(); updTotals(); renderSide(); flash(at); focusCell(at, "qty");
        say("تم لصق السطر: " + n.name, "s");
      }
      try { if (typeof QtySound !== "undefined") QtySound.play(); } catch (e) { }
    }
    grid.addEventListener("contextmenu", e => {
      e.preventDefault();
      const row = e.target.closest(".pu-d"), i = row ? +row.dataset.i : -1;
      if (row) select(i);
      const x = e.clientX, y = e.clientY;
      const at = { getBoundingClientRect: () => ({ left: x, right: x, top: y, bottom: y, width: 0, height: 0 }), contains: () => false, closest: () => null };
      const has = i >= 0 && !!S.rows[i];
      menuPop(at, [
        { t: "نسخ", k: "Ctrl+C", ic: CI.copy, dis: !has, f: () => copyRow(i) },
        { t: "لصق", k: "Ctrl+V", ic: CI.paste, dis: !PCLIP, f: pasteRow },
        { t: "حذف السطر", k: "Del", ic: CI.del, dis: !has, f: () => ask("هل تريد حذف هذا السطر", () => delRow(i)) },
        { t: "بحث", ic: CI.find, f: () => { const t = has ? grid.querySelector(`.pu-d[data-i="${i}"] [data-c=name]`) : grid.querySelector(".pu-new [data-c=name]"); if (t) openPicker(t, has ? i : null); } },
        { t: "إختيار الحقول", ic: CI.cols, f: () => colsPop(root.querySelector('[data-a="cols"]')) },
        { t: "الأرقام التسلسلية", ic: CI.pen, dis: !(has && isSerial(S.rows[i].pid)), f: () => serialFill() },
        { t: "أرقام التشغيلة", ic: CI.pen, dis: !(has && isSerial(S.rows[i].pid)), f: () => lotPop(i) }
      ]);
      POP.el.classList.add("pu-ctx");
    });
    grid.addEventListener("dblclick", e => { const t = e.target; if (t.dataset && t.dataset.c === "name" && t.closest(".pu-d")) openPicker(t, +t.closest(".pu-d").dataset.i); });
    grid.addEventListener("keydown", e => {
      const t = e.target, c = t.dataset && t.dataset.c; if (!c) return;
      const nw = t.closest(".pu-new"), row = t.closest(".pu-d"), i = row ? +row.dataset.i : -1;
      if (nw && D.pend && c === "name" && (e.key === "Enter" || (e.key === "Tab" && !e.shiftKey))) { e.preventDefault(); commitPend(); return; }
      if (nw && D.pend && e.key === "Escape") { e.preventDefault(); clearPend(); return; }
      if (e.key === "Enter") {
        e.preventDefault();
        if (nw || (row && (c === "name" || c === "code") && !S.rows[i])) {
          const v = t.value.trim(); if (!v) { if (S.rows.length) focusCell(S.rows.length - 1, "qty"); return; }
          const ex = c === "code" || /^\d{4,}$/.test(v) ? exactCode(v) : null;
          if (ex) { t.value = ""; addProduct(ex.p, ex.u); return; }
          openPicker(t, null); return;
        }
        if (row && c === "code") {
          const ex = exactCode(t.value); if (ex) { addProduct(ex.p, ex.u, S.rows[i].qty, i); return; }
          openPicker(t, i); return;
        }
        // Enter: الخلية التالية القابلة للتحرير؛ بعد آخر خلية → سطر جديد
        const fs = Array.from(row.querySelectorAll("input[data-c]:not([type=checkbox]),select[data-c]")).filter(x => x.dataset.c !== "code" && x.dataset.c !== "name");
        const k = fs.indexOf(t);
        if (k >= 0 && k < fs.length - 1) { fs[k + 1].focus(); if (fs[k + 1].select) try { fs[k + 1].select(); } catch (x) { } }
        else { if (i < S.rows.length - 1) focusCell(i + 1, "qty"); else focusCell(-1, "name"); }
      } else if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        if (t.tagName === "SELECT") return;
        e.preventDefault();
        const d = e.key === "ArrowDown" ? 1 : -1;
        if (nw) { if (d > 0 && S.rows.length) focusCell(0, c === "code" ? "code" : "name"); return; }
        const j = i + d;
        if (j < 0) focusCell(-1, c === "code" ? "code" : "name"); else if (j < S.rows.length) focusCell(j, c);
      } else if (e.ctrlKey && !e.shiftKey && !e.altKey && e.code === "KeyC" && row) {
        // كل الخلية محددة (الافتراضي عند التركيز) → نسخ السطر؛ تحديد جزئي → نسخ النص عادياً
        const whole = t.type === "checkbox" || t.tagName === "SELECT" || t.selectionStart == null || (t.selectionStart === 0 && t.selectionEnd === String(t.value).length);
        if (whole) { e.preventDefault(); copyRow(i); }
      } else if (e.ctrlKey && !e.shiftKey && !e.altKey && e.code === "KeyV" && PCLIP && (t.tagName === "SELECT" || t.type === "checkbox" || (nw && !t.value))) {
        e.preventDefault(); pasteRow();
      } else if ((e.key === "Delete" && e.ctrlKey) || (e.key === "Delete" && t.tagName === "SELECT")) {
        if (row) { e.preventDefault(); ask("هل تريد حذف هذا السطر", () => delRow(i)); }
      } else if (e.key === "F3" || (e.key === "F4" && (c === "name" || c === "code")) || (e.altKey && e.key === "ArrowDown" && c === "name" && !nw)) {
        e.preventDefault(); openPicker(t, nw ? null : i, !nw && e.key !== "F3");
      } else if (e.key === "+" && c === "qty" && row) {
        e.preventDefault(); const r = S.rows[i]; r.qty = r2((+r.qty || 0) + 1); applyDp(r); renderRow(i); updTotals(); t.value = r.qty; markDirty();
      } else if (e.key === "-" && c === "qty" && row && (+S.rows[i].qty || 0) > 1 && !t.value.includes("-") && t.selectionStart === t.value.length) {
        e.preventDefault(); const r = S.rows[i]; r.qty = r2(r.qty - 1); applyDp(r); renderRow(i); updTotals(); t.value = r.qty; markDirty();
      }
    });
    grid.addEventListener("focusout", e => {
      const t = e.target, c = t.dataset && t.dataset.c, row = t.closest && t.closest(".pu-d");
      if (row && (c === "name" || c === "code")) {      // إعادة الاسم/الكود إن عدّله المستخدم دون اختيار
        const r = S.rows[+row.dataset.i];
        setTimeout(() => { if (r && !PK && document.activeElement !== t) t.value = c === "name" ? r.name : r.code; }, 120);
      }
      if (row && ["qty", "price", "dp", "disc", "sale"].includes(c)) { const i = +row.dataset.i; setTimeout(() => { if (S.rows[i]) renderRow(i); }, 0); }
    });
    /* ---------- الآلة الحاسبة داخل الخلايا الرقمية (▾ مثل DEXEF) ---------- */
    const isNumCell = t => t && t.tagName === "INPUT" && t.classList.contains("n") && !t.readOnly && t.dataset.c && t.closest(".pu-d");
    const CTITLE = { qty: "الكميه", price: "السعر", dp: "نسبة الخصم %", disc: "قيمة الخصم", sale: "سعر البيع" };
    function cellCalc(t) {
      const row = t.closest(".pu-d"); if (!row) return;
      const i = +row.dataset.i, c = t.dataset.c, r = S.rows[i]; if (!r) return;
      if (POP && POP.el.classList.contains("pu-calcpop") && POP.cell === t) { closePop(); return; }
      CB.hide();
      const col = (visCols().find(x => x.k === c || "x:" + x.k === c) || {}).t || CTITLE[c] || "";
      calcPop(t.closest("[data-k]") || t, num(t.value), v => {
        const el = grid.querySelector(`.pu-d[data-i="${i}"] [data-c="${c}"]`) || t;
        el.value = String(v);
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        focusCell(i, c);
        const nm = (S.rows[i] && S.rows[i].name) || "";
        say((col ? col + " ← " : "") + fmt(v) + (nm ? " — " + nm : ""), "s");
      }, { title: (col ? col + " — " : "") + (r.name || ""), onClose: () => setTimeout(() => { const a = document.activeElement; if (isNumCell(a)) CB.show(a, cellCalc); }, 0) });
      if (POP) POP.cell = t;
    }
    grid.addEventListener("focusin", e => { if (isNumCell(e.target)) CB.show(e.target, cellCalc); else CB.hide(); });
    grid.addEventListener("focusout", e => { const t = e.target; setTimeout(() => { if (document.activeElement !== t && !isNumCell(document.activeElement)) CB.hide(t); }, 0); });
    grid.addEventListener("input", () => setTimeout(() => { const a = document.activeElement; if (isNumCell(a)) CB.show(a, cellCalc); }, 0));
    grid.addEventListener("keydown", e => {
      if (!isNumCell(e.target)) return;
      if (e.altKey && e.key === "ArrowDown") { e.preventDefault(); e.stopPropagation(); cellCalc(e.target); }
    }, true);

    /* ---------- الأحداث: المصروفات (مطابقة DEXEF) ---------- */
    const ex = $(".pu-exps");
    D.expSel = -1;
    const expRecalc = () => { EA = null; markDirty(); updTotals(); S.rows.forEach((r, j) => renderRow(j)); };
    function expApplyDef(x) { const d = EXPDEF[(x.name || "").trim()]; if (!d) return false; Object.assign(x, { alloc: d.alloc || x.alloc, pay: d.pay || x.pay, acct: d.acct != null ? String(d.acct) : x.acct, all: d.all !== false, taxable: d.taxable || x.taxable, taxPerc: +d.taxPerc || 0 }); if (!x.amt && +d.amt) x.amt = +d.amt; return true; }
    function expRemember(x) { const n = (x.name || "").trim(); if (!n) return; EXPDEF[n] = { alloc: x.alloc, pay: x.pay, acct: x.acct, all: x.all, taxable: x.taxable, taxPerc: x.taxPerc, amt: x.amt }; lsSet("pur.expDefs", EXPDEF); }
    function expFocus(i, k) { const el = ex.querySelector(`.pu-er[data-i="${i}"] [data-e="${k}"]`); if (el) { el.focus(); if (el.select) try { el.select(); } catch (e) { } } }
    ex.addEventListener("input", e => {
      const t = e.target, k = t.dataset.e; if (!k) return;
      if (k === "newName") {
        if (!t.value.trim()) return;
        const x = expN({ name: t.value, cur: F("cur").value }); expApplyDef(x); S.exps.push(x); D.expSel = S.exps.length - 1;
        renderExps(); markDirty();
        const n = ex.querySelector(`.pu-er[data-i="${S.exps.length - 1}"] [data-e="name"]`); if (n) { n.focus(); n.setSelectionRange(n.value.length, n.value.length); } return;
      }
      const er = t.closest(".pu-er"), i = +er.dataset.i, x = S.exps[i]; if (!x) return;
      if (k === "amt" || k === "rate" || k === "taxPerc") {
        x[k] = k === "rate" ? (num(t.value) || 1) : num(t.value);
        expRecalc();
        er.querySelectorAll('[data-k="inv"],[data-k="tax"],[data-k="net"]').forEach(c => { const cc = EXC.find(z => z.k === c.dataset.k); c.innerHTML = c.dataset.k === "inv" ? `<span class="pu-ro">${fmt(expInv(x))}</span>` : c.dataset.k === "tax" ? `<span class="pu-ro">${expTax(x) ? fmt(expTax(x)) : ""}</span>` : `<span class="pu-ro b">${fmt(expNet(x))}</span>`; });
      } else if (k === "name" || k === "notes" || k === "cc" || (k === "acct" && t.tagName === "INPUT")) { x[k] = t.value; markDirty(); }
    });
    ex.addEventListener("change", e => {
      const t = e.target, k = t.dataset.e; if (!k || k === "newName") return;
      const er = t.closest(".pu-er"), i = er ? +er.dataset.i : -1, x = S.exps[i]; if (!x) return;
      if (k === "name") { const fresh = !x.amt; x.name = t.value; if (fresh && expApplyDef(x)) { setTimeout(() => { renderExps(); expRecalc(); }, 0); } return; }
      if (k === "pay") { x.pay = t.value; x.acct = ""; }               // DEXEF: تغيير النوع يمسح جهة الصرف
      else if (k === "all") { x.all = t.value === "1"; if (x.all) x.items = []; }
      else if (k === "alloc" || k === "taxable" || k === "cur" || k === "acct") x[k] = t.value;
      else if (k === "amt" || k === "rate" || k === "taxPerc") { expRemember(x); setTimeout(renderExps, 0); return; }
      expRemember(x); expRecalc(); setTimeout(() => { renderExps();
      if (k === "pay" && x.pay !== "Customer") expFocus(i, "acct");
      if (k === "all" && !x.all) { const b = ex.querySelector(`.pu-er[data-i="${i}"] [data-a="expItems"]`); if (b) b.click(); } }, 0);
    });
    ex.addEventListener("focusin", e => { const er = e.target.closest(".pu-er[data-i]"); if (!er) return; const i = +er.dataset.i; if (i === D.expSel) return; D.expSel = i;
      ex.querySelectorAll(".pu-er[data-i]").forEach(r => { const on = +r.dataset.i === i; r.classList.toggle("sel", on); const ind = r.querySelector(".ind"); if (ind) ind.innerHTML = on ? '<span class="arw">←</span>' : (+r.dataset.i + 1); }); });
    ex.addEventListener("click", e => {
      const b = e.target.closest('[data-a="edel"]');
      if (b) { const i = +b.closest(".pu-er").dataset.i; ask("هل تريد حذف هذا المصروف", () => { S.exps.splice(i, 1); D.expSel = -1; renderExps(); expRecalc(); }); return; }
      const bi = e.target.closest('[data-a="expItems"]');
      if (bi) {   // اختيار الأصناف التي يُوزَّع عليها المصروف
        const i = +bi.closest(".pu-er").dataset.i, x = S.exps[i]; if (!x) return;
        const its = []; S.rows.forEach(r => { if (r.code && !its.some(z => z.code === String(r.code))) its.push({ code: String(r.code), name: r.name }); });
        const el = openPop(bi, `<div class="pu-exsel"><div class="hd">الأصناف التي يُوزَّع عليها «${esc(x.name || "المصروف")}»</div>
          <label class="all"><input type="checkbox" data-x="all"> تحديد الكل</label>
          <div class="ls">${its.length ? its.map(z => `<label><input type="checkbox" value="${esc(z.code)}"${x.items.includes(z.code) ? " checked" : ""}> <span>${esc(z.name)}</span><small>${esc(z.code)}</small></label>`).join("") : '<div class="e">أضف أصنافاً للفاتورة أولاً</div>'}</div>
          <div class="ft"><button type="button" class="ok">موافق</button></div></div>`, "pu-expop");
        const boxes = () => Array.from(el.querySelectorAll('.ls input[type="checkbox"]'));
        el.querySelector('[data-x="all"]').onchange = ev => boxes().forEach(c => { c.checked = ev.target.checked; });
        el.querySelector(".ok").onclick = () => { x.items = boxes().filter(c => c.checked).map(c => c.value); closePop(); renderExps(); expRecalc(); };
        return;
      }
    });
    ex.addEventListener("keydown", e => {
      if (e.key !== "Enter") return; e.preventDefault();
      const t = e.target, er = t.closest(".pu-er"); if (!er) return;
      if (er.classList.contains("pu-enew")) return;
      const fs = Array.from(er.querySelectorAll("input:not([readonly]),select")), k = fs.indexOf(t);
      if (k >= 0 && k < fs.length - 1) fs[k + 1].focus(); else { const n = ex.querySelector('[data-e="newName"]'); if (n) n.focus(); }
    });
    // زر أيمن على العناوين ← اختيار الأعمدة (مثل Customization في DEXEF)
    ex.addEventListener("contextmenu", e => {
      const h = e.target.closest(".pu-eh"); if (!h) return; e.preventDefault();
      const cur = expCols().map(c => c.k);
      const el = openPop(h, `<div class="pu-exsel"><div class="hd">أعمدة المصروفات</div><div class="ls">${EXC.map(c => `<label><input type="checkbox" value="${c.k}"${cur.includes(c.k) ? " checked" : ""}${c.k === "name" ? " disabled" : ""}> <span>${esc(c.t)}</span></label>`).join("")}</div>
        <div class="ft"><button type="button" class="rs">الافتراضي</button><button type="button" class="ok">موافق</button></div></div>`, "pu-expop", { alignLeft: false });
      el.style.left = Math.max(4, Math.min(e.clientX - el.offsetWidth / 2, innerWidth - el.offsetWidth - 4)) + "px";
      el.querySelector(".ok").onclick = () => { lsSet("pur.expCols", Array.from(el.querySelectorAll("input:checked")).map(c => c.value)); closePop(); Object.values(DOCS).forEach(d => { try { d.renderExps && d.renderExps(); } catch (x) { } }); renderExps(); };
      el.querySelector(".rs").onclick = () => { lsSet("pur.expCols", null); closePop(); renderExps(); };
    });

    /* ---------- الأحداث: الرأس والتذييل ---------- */
    const sn = F("supName");
    sn.addEventListener("input", () => { if (!POP || !D.supDraw || !POP.el.classList.contains("pu-skpop")) supPicker(sn); else D.supDraw(); });
    sn.addEventListener("keydown", e => {
      if (e.key === "Enter" && !(POP && POP.el.classList.contains("pu-skpop"))) { e.preventDefault(); if (sn.value.trim() && !S.supId) supPicker(sn); else focusCell(-1, "name"); }
      if (e.key === "F4" || (e.altKey && e.key === "ArrowDown")) { e.preventDefault(); supPicker(sn); }
    });
    sn.addEventListener("blur", () => setTimeout(() => {
      if (POP && POP.el.classList.contains("pu-skpop")) return;
      const s = supById(S.supId);
      if (!sn.value.trim()) { if (s) setSupplier(null); } else if (!s || s.name !== sn.value) {
        const m = PARTY().filter(x => norm(x.name) === norm(sn.value));
        if (m.length === 1) setSupplier(m[0]); else sn.value = s ? s.name : "";
      }
    }, 150));
    const sc = F("supCode");
    sc.addEventListener("keydown", e => {
      if (e.key !== "Enter") return; e.preventDefault();
      const v = sc.value.trim(); if (!v) { setSupplier(null); return; }
      const s = PARTY().find(x => String(x.code) === v);
      if (s) { setSupplier(s); focusCell(-1, "name"); } else say("لا يوجد " + WHO.slice(2) + " بالرقم " + v, "w");
    });
    /* «السعر» (عرض السلعة / أمر توريد): شرائح الأسعار المشتركة — تغييرها يعيد تسعير الأسطر التي لم يُعدَّل سعرها يدوياً */
    if (ty.cust) {
      const pl = F("plv");
      const fillPlv = () => {
        const v = pl.value || lsGet("pur.plv." + type, "1");
        const L = window.ANOUER_PL ? ANOUER_PL.visible(v).filter(x => x.id !== "last") : [{ id: "1", name: "سعر البيع" }];
        pl.innerHTML = L.map(x => `<option value="${x.id}">${esc(x.name)}</option>`).join("");
        pl.value = L.some(x => x.id === v) ? v : "1";
      };
      fillPlv(); try { if (window.ANOUER_PL && ANOUER_PL.on) ANOUER_PL.on(fillPlv); } catch (e) { }
      pl.addEventListener("change", () => {
        lsSet("pur.plv." + type, pl.value);
        let n = 0; const k = CX.rate || 1;
        (S ? S.rows : []).forEach(r => {
          const p = prodById(r.pid), u = p && unitByName(p, r.unit); if (!u) return;
          if (Math.abs((+r.price || 0) - (+r.lastCost || 0)) > .005) return;   // سعر عدّله المستخدم → يبقى
          const c = costOf(p, u); r.price = k === 1 ? c : r2(c / k); r.lastCost = r.price; r._bp = c; r._blc = c; r._cxp = r.price; applyDp(r); n++;
        });
        if (n) { markDirty(); renderGrid(); updTotals(); }
        root.querySelector(".pu-plv").classList.remove("pu-flash"); void root.offsetWidth; root.querySelector(".pu-plv").classList.add("pu-flash");
        say("السعر: «" + ((pl.selectedOptions[0] || {}).textContent || "") + "»" + (n ? " — أُعيد تسعير " + n + " سطر" : ""), "s");
      });
    }
    F("mode").addEventListener("change", () => { lsSet("pur.mode." + type, F("mode").value); applySettings(); if (CUST && CUST.draw) CUST.draw(); });
    F("mode").addEventListener("keydown", e => { if (e.key === "F4" || (e.altKey && e.key === "ArrowDown") || e.key === "Enter") { e.preventDefault(); modeMenu(); } });
    F("mode").addEventListener("click", () => modeMenu());
    function setMode(m) { if (!MODES.includes(m)) return; F("mode").value = m; F("mode").dispatchEvent(new Event("change")); }
    function modeMenu() {
      const anchor = root.querySelector(".pu-modef");
      const mw = Math.max(300, anchor.offsetWidth + 120);
      const el = openPop(anchor, `<div class="pu-mlist" style="width:${mw}px">${MODES.map(m => `<div class="mo${m === F("mode").value ? " on" : ""}" data-m="${m}">${m}</div>`).join("")}<div class="mft"><button type="button" class="mx" title="إغلاق">✕</button><i>⋰</i></div></div>`, "pu-mlpop");
      let ix = Math.max(0, MODES.indexOf(F("mode").value));
      const hl = () => el.querySelectorAll(".mo").forEach((x, i) => x.classList.toggle("on", i === ix));
      el.addEventListener("mousedown", e => e.preventDefault());
      el.addEventListener("mousemove", e => { const o = e.target.closest(".mo"); if (o) { ix = MODES.indexOf(o.dataset.m); hl(); } });
      el.addEventListener("click", e => { const o = e.target.closest(".mo"); if (o) { closePop(); setMode(o.dataset.m); } else if (e.target.closest(".mx")) closePop(); });
      POP.key = e => { if (e.key === "ArrowDown") { ix = Math.min(MODES.length - 1, ix + 1); hl(); } else if (e.key === "ArrowUp") { ix = Math.max(0, ix - 1); hl(); } else if (e.key === "Enter") { closePop(); setMode(MODES[ix]); } else if (e.key === "Escape") closePop(); else return false; return true; };
    }
    F("vat").addEventListener("change", () => { const on = vatRate() > 0; if (on && !S.rows.some(r => r.tax)) S.rows.forEach(r => { const c = r.pid && IA() && IA().cfg(r.pid); r.tax = !(c && c.vat === "no"); }); markDirty(); renderGrid(); updTotals(); });
    /* شرائح الخصم ← «خصم تراكمي» على كل سطر (DiscountGroup في DEXEF) — لا تغيّر % خصم الصنف */
    F("slice").addEventListener("change", () => { markDirty(); renderGrid(); updTotals(); });
    ["dval", "dtype"].forEach(n => F(n).addEventListener("input", () => { markDirty(); updTotals(); }));
    F("dtype").addEventListener("change", () => { markDirty(); updTotals(); });
    F("paid").addEventListener("input", () => {
      if (!S.credit) {
        if (ty.pay && S.supId) { const v = F("paid").value; setCredit(true, true); F("paid").value = v; }   // دفع جزئي = أجل تلقائياً
        else { if (!D._payWarn) { D._payWarn = 1; say("الدفع الجزئي يتطلب اختيار مورد (تعامل أجل)", "w"); } updTotals(); return; }
      }
      S.paidTouched = true; markDirty(); updTotals();
    });
    F("paid").addEventListener("blur", () => { const t = totals(); if (S.credit) F("paid").value = fmt(t.paid); });
    ["ref", "notes", "prefix", "no", "date", "due", "branch", "treas", "acct", "status", "wh", "cur", "rate", "gla", "trWh", "trBr"].forEach(n => { const el = F(n); if (el) el.addEventListener("input", markDirty); });
    F("wh").addEventListener("focus", () => { F("wh").dataset.prev = F("wh").value; });
    F("wh").addEventListener("change", () => {
      /* «السماح بإجراء تعاملات في أكثر من مخزن في نفس الفاتورة = لا» */
      try { const g = window.ANOUER_PROPS ? ANOUER_PROPS.get("inv.gen", {}) : {}; if (g.multiWh === false && S.rows.length && F("wh").dataset.prev != null) { F("wh").value = F("wh").dataset.prev; say("لا يمكن تغيير المخزن بعد إضافة أصناف (الخصائص ← خصائص عامة)", "w"); return; } } catch (e) { }
      D.whId = curWh(); markDirty(); renderGrid(); updTotals(); renderSide(); });
    F("no").addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); const v = F("no").value.trim(); if (v && !S.id) openByNo(v); } });

    root.addEventListener("click", e => {
      const b = e.target.closest("[data-a]"); if (!b || !root.contains(b) || b.closest(".pu-grid,.pu-exps")) return;
      const a = b.dataset.a;
      /* زر مقسوم (مثل DEXEF): السهم الصغير يفتح القائمة، وبقية الزر ينفّذ الأمر */
      if (e.target.closest(".car") && b.classList.contains("pu-rb")) { if (a === "save") { saveMenu(b); return; } }
      switch (a) {
        case "txs": txOpen(); break;
        case "drafts": draftsDlg(); break;
        case "supdd": supPicker(sn); sn.focus(); break;
        case "glaDd": { const g = F("gla"); g.focus(); try { g.showPicker(); } catch (x) { g.select(); } break; }
        case "modeDd": modeMenu(); break;
        case "modeDef": lsSet("pur.mode." + type, F("mode").value); say("«" + F("mode").value + "» هي طريقة العرض الافتراضية لـ " + ty.t, "s"); break;
        case "supnew": newSupplier(); break;
        case "deal": dealMenu(b); break;
        case "calcPaid": calcPop(b.closest(".pu-in"), num(F("paid").value), v => { if (!S.credit && S.supId) setCredit(true, true); if (!S.credit) { say("الدفع الجزئي يتطلب «أجل» ومورداً", "w"); return; } F("paid").value = v; S.paidTouched = true; markDirty(); updTotals(); }); break;
        case "calcDisc": calcPop(b.closest(".pu-in"), num(F("dval").value), v => { F("dval").value = v; markDirty(); updTotals(); }); break;
        case "sum": sumPop(b); break;
        case "payDlg": payDlg(); break;
        case "ptype": ptypeMenu(); break;
        case "desc": descPop(b); break;
        case "saveNew": save("new"); break;
        case "savePrint": save("print"); break;
        case "saveClose": save("close"); break;
        case "saveMenu": saveMenu(b); break;
        default: ribbon(a, b);
      }
    });
    $$(".pu-rt").forEach(t => t.addEventListener("click", () => {
      $$(".pu-rt").forEach(x => x.classList.toggle("on", x === t));
      $$(".pu-tb").forEach(p => { p.hidden = p.dataset.pane !== t.dataset.rt; });
      if (t.dataset.rt === "prop") propsDialog();
    }));
    $(".pu-rico").addEventListener("click", () => root.classList.toggle("rib-min"));
    function showExpTab() { const b = root.querySelector('.pu-gtabs [data-g="exps"]'); if (b && !b.classList.contains("on")) b.click(); }
    $$(".pu-gtabs button").forEach(b => b.addEventListener("click", () => {
      $$(".pu-gtabs button").forEach(x => x.classList.toggle("on", x === b));
      $$(".pu-gwrap").forEach(w => { w.hidden = w.dataset.g !== b.dataset.g; });
      $(".pu-gsum").hidden = b.dataset.g !== "items";
      if (b.dataset.g === "exps") { const n = $('[data-e="newName"]'); if (n) n.focus(); } else focusCell(-1, "name");
    }));
    $$(".pu-stabs button").forEach(b => b.addEventListener("click", () => showSide(b.dataset.st)));
    function showSide(k) {
      $$(".pu-stabs button").forEach(x => x.classList.toggle("on", x.dataset.st === k));
      $$(".pu-spane").forEach(p => { p.hidden = p.dataset.sp !== k; });
      root.classList.remove("side-min");
      renderSide();
    }
    $(".pu-sclp").addEventListener("click", () => root.classList.toggle("side-min"));
    $(".pu-side").addEventListener("click", e => { const p = e.target.closest("[data-sp]"); if (p && p.tagName === "BUTTON") { supPaneAct(p.dataset.sp, p); return; } const ip = e.target.closest("[data-ip]"); if (ip) { itemPaneAct(ip.dataset.ip, ip); return; } const b = e.target.closest("[data-s]"); if (b) sideAct(b.dataset.s, b); });
    $(".pu-side").addEventListener("change", e => { const t = e.target; if (t.dataset && t.dataset.ip === "serial") { setSerial(+t.dataset.pid, t.checked); say(t.checked ? "تم تفعيل الأرقام التسلسلية لهذا الصنف" : "تم إلغاء الأرقام التسلسلية لهذا الصنف", "s"); renderSide(); } });
    $(".pu-side").addEventListener("keydown", e => { if (e.target.classList.contains("sp-days") && e.key === "Enter") { e.preventDefault(); supPaneAct("deals"); } });
    // مقبض تغيير عرض اللوحة الجانبية
    (function () {
      const sp = $(".pu-split"), side = $(".pu-side");
      let x0 = 0, w0 = 0;
      sp.addEventListener("pointerdown", e => { x0 = e.clientX; w0 = side.offsetWidth; sp.setPointerCapture(e.pointerId); sp.classList.add("drag"); });
      sp.addEventListener("pointermove", e => { if (!sp.classList.contains("drag")) return; const w = Math.max(150, Math.min(360, w0 + (e.clientX - x0))); side.style.width = w + "px"; });
      sp.addEventListener("pointerup", () => sp.classList.remove("drag"));
    })();

    /* ---------- قوائم صغيرة ---------- */
    function menuPop(anchor, items) {
      const el = openPop(anchor, `<div class="pu-menu">${items.map((it, i) => it === "-" ? '<div class="sep"></div>' : `<div class="mi${it.dis ? " dis" : ""}" data-i="${i}">${it.ic ? `<i>${it.ic}</i>` : "<i></i>"}<span>${esc(it.t)}</span>${it.k ? `<em>${it.k}</em>` : ""}</div>`).join("")}</div>`, "pu-menupop");
      el.addEventListener("mousedown", e => e.preventDefault());
      el.addEventListener("click", e => { const m = e.target.closest(".mi"); if (!m || m.classList.contains("dis")) return; const it = items[+m.dataset.i]; closePop(); it.f(); });
      return el;
    }
    function dealMenu(b) {
      menuPop(b.closest(".pu-in"), [{ t: "كاش", ic: I.coins, f: () => setCredit(false) }, { t: "أجل", ic: I.credit, f: () => setCredit(true) }]);
      const on = POP.el.querySelectorAll(".mi")[S.credit ? 1 : 0]; if (on) on.classList.add("on");
    }
    function saveMenu(b) {
      menuPop(b, [{ t: "حفظ التغييرات", k: "Ctrl+Shift+S", ic: I.draft, f: () => saveDraft(false) }, { t: "المسودات المحفوظة…", ic: I.drafts, f: () => draftsDlg() }, "-",
        { t: "حفظ", k: "Ctrl+S", ic: I.save, f: () => save("stay") }, { t: "حفظ و جديد", k: "F2", f: () => save("new") }, { t: "حفظ وطباعة", k: "F4", ic: I.print, f: () => save("print") }, { t: "حفظ و إغلاق", f: () => save("close") }]);
    }
    function sumPop(b) {
      const t = totals();
      const el = openPop(b, `<div class="pu-sum"><div class="hd">الاجماليات</div>${[["عدد الأصناف", S.rows.length], ["إجمالي الكميات", fmt(t.q)], ["الاجمالى", fmt(t.before)], ["خصم الأصناف", fmt(t.ld)], ["خصم الفاتورة", fmt(t.hd)], ["الاضافى (المصروفات)", fmt(t.extra)], ["الضرائب", fmt(t.tax)], ["الصافي", fmt(t.total)], ["المدفوع", fmt(t.paid)], ["الباقى", fmt(t.rem)]].map(x => `<div><span>${x[0]}</span><b>${x[1]}</b></div>`).join("")}</div>`, "pu-sumpop");
      el.addEventListener("mousedown", e => e.preventDefault());
    }
    function descPop(b) {
      const el = openPop(b, `<div class="pu-desc"><div class="hd">وصف الفاتورة</div><textarea rows="5">${esc(D.desc || "")}</textarea><div class="ft"><button type="button" class="pu-bt g">موافق</button></div></div>`, "pu-descpop", { alignLeft: false });
      const ta = el.querySelector("textarea"); setTimeout(() => ta.focus(), 0);
      el.querySelector("button").addEventListener("click", () => { D.desc = ta.value; markDirty(); closePop(); b.classList.toggle("has", !!D.desc.trim()); });
    }

    /* ---------- أزرار الشريط ---------- */
    function ribbon(a, b) {
      switch (a) {
        case "new": newDoc(); break;
        case "prev": nav(-1); break;
        case "next": nav(1); break;
        case "find": findDialog(); break;
        case "save": save("stay"); break;
        case "print": printMenu(b); break;
        case "fmtKeys": keysMenu(b); break;
        case "fmtIns": insertRow(); break;
        case "fmtDel": if (S.rows[S.sel]) ask("هل تريد حذف هذا السطر", () => delRow(S.sel)); else say("اختر سطراً أولاً", "w"); break;
        case "fmtGrid": colsPop(); break;
        case "fmtEntry": entryMenu(b); break;
        case "fmtSerFind": serialFind(); break;
        case "fmtSerFill": serialFill(); break;
        case "fmtExpAdd": expAdd(b); break;
        case "fmtExpShow": expShow(); break;
        case "preview": if (S.rows.length) printDoc(true); else say("لا توجد أصناف للطباعة", "w"); break;
        case "mail": if (!S.rows.length) say("لا توجد أصناف للإرسال", "w"); else if (window.ANOUER_MAIL) ANOUER_MAIL.viaPrint(() => printDoc(true), { party: (supById(S.supId) || {}).name || "" }); else say("البريد غير متاح", "w"); break;
        case "refresh": refreshData(true); break;
        case "xlsin": importXls(); break;
        case "loadinv": if (window.ANOUER_TX) loadOpen(); else loadFromDialog(); break;
        case "copyto": copyMenu(b); break;
        case "toSale": if (!S.rows.length) say("لا توجد أصناف للتحويل", "w"); else copyToSale(false); break;
        case "xlsout": exportXls(); break;
        case "del": delDoc(); break;
        case "additem": itemSearch(); break;
        case "att": say("المرفقات غير متوفرة في هذا النموذج", "i"); break;
        case "stats": showSide("stats"); break;
        case "redist": redistribute(b); break;
        case "cols": colsPop(b); break;
        case "collapse": root.classList.toggle("rib-min"); break;
        case "props": propsDialog(); break;
      }
    }
    function sideAct(a, b) {
      const r = S.rows[S.sel], p = r && prodById(r.pid);
      switch (a) {
        case "newItem":
          try { if (typeof itReset === "function") itReset(); openTab("item", "إضافة صنف", "item"); say("بعد حفظ الصنف عُد للفاتورة واضغط «تحديث البيانات»", "i"); } catch (e) { say("شاشة الأصناف غير متاحة", "w"); }
          break;
        case "prices": if (!p) { say("اختر صنفاً من الفاتورة أولاً", "w"); return; } pricesDialog(S.sel); break;
        case "barcode": if (!p) { say("اختر صنفاً من الفاتورة أولاً", "w"); return; } barcodeDialog(S.sel); break;
        case "quick": quickAdd(); break;
        case "coupon": say("كوبونات الخصم تخصّ فواتير المبيعات", "i"); break;
        case "calc": calcPop(b || $('[data-s="calc"]'), 0, v => { try { navigator.clipboard.writeText(String(v)).catch(() => { }); say("النتيجة " + fmt(v) + " — نُسخت", "s"); } catch (e) { say("النتيجة " + fmt(v), "s"); } }); break;
        case "images": say(p ? "لا توجد صور مسجّلة للصنف «" + p.name + "»" : "اختر صنفاً من الفاتورة أولاً", "i"); break;
        case "supStmt": { const s = supById(S.supId); if (s && window.ANOUER_SUPPLIERS && ANOUER_SUPPLIERS.statement) ANOUER_SUPPLIERS.statement({ id: s.id, name: s.name }); else say("كشف الحساب متاح من شاشة مراجعة الموردين", "i"); break; }
      }
    }
    /* Customization (مطابق DEXEF): لوحة عائمة بالأعمدة المخفية — اسحب عموداً إلى رأس الجدول لإظهاره، أو رأس عمود إلى اللوحة لإخفائه */
    let CUST = null;
    function colsPop() {
      if (CUST) { CUST.el.remove(); CUST = null; return; }
      const el = document.createElement("div"); el.className = "pu-cust"; el.setAttribute("role", "dialog"); el.setAttribute("aria-label", "Customization");
      el.innerHTML = `<div class="cu-h"><span>Customization</span><button type="button" class="cu-x" aria-label="إغلاق">✕</button></div>
        <div class="cu-s"><input placeholder="Search for a column..." autocomplete="off"><i>${'<svg viewBox="0 0 12 12" width="11" height="11"><circle cx="5" cy="5" r="3.6" fill="none" stroke="#555" stroke-width="1.3"/><path d="M7.7 7.7L11 11" stroke="#555" stroke-width="1.4"/></svg>'}</i></div>
        <div class="cu-l"></div><div class="cu-f"><button type="button" class="cu-r">استعادة الافتراضي</button><span class="cu-n"></span></div>`;
      document.body.appendChild(el);
      const r = grid.getBoundingClientRect();
      el.style.left = Math.max(8, r.left + 12) + "px"; el.style.top = Math.max(60, Math.min(innerHeight - 470, r.top + 60)) + "px";
      CUST = { el, draw: null };
      const q = el.querySelector(".cu-s input"), list = el.querySelector(".cu-l");
      const draw = () => {
        const vis = new Set(layKeys()), f = norm(q.value);
        const hid = COLS.filter(c => !vis.has(c.k) && (!f || norm(c.t).includes(f))).sort((a, b) => a.t.localeCompare(b.t, "ar"));
        list.innerHTML = hid.length ? hid.map(c => `<div class="cu-i" draggable="true" data-k="${c.k}" title="اسحب إلى رأس الجدول — أو نقرة مزدوجة للإضافة">${esc(c.t)}</div>`).join("") : '<div class="cu-e">كل الأعمدة ظاهرة</div>';
        el.querySelector(".cu-n").textContent = hid.length + " عمود";
      };
      CUST.draw = draw;
      q.addEventListener("input", draw);
      el.querySelector(".cu-x").addEventListener("click", () => { el.remove(); CUST = null; });
      el.querySelector(".cu-r").addEventListener("click", () => { const m = F("mode").value; delete LAYOUT[layId()]; lsSet("pur.layout", LAYOUT); hidden = {}; lsSet("pur.hiddenCols", hidden); Object.values(DOCS).forEach(d => d.syncCols()); say("تمت استعادة أعمدة «" + m + "» الافتراضية", "s"); });
      list.addEventListener("dblclick", e => { const it = e.target.closest(".cu-i"); if (!it) return; const keys = layKeys(); keys.push(it.dataset.k); setLayout(keys); });
      list.addEventListener("dragstart", e => { const it = e.target.closest(".cu-i"); if (!it) return; DRAG = { k: it.dataset.k, src: "c" }; e.dataTransfer.setData("text/plain", it.dataset.k); e.dataTransfer.effectAllowed = "move"; it.classList.add("dg"); });
      list.addEventListener("dragend", e => { const it = e.target.closest(".cu-i"); if (it) it.classList.remove("dg"); DRAG = null; hideInd(); });
      // إفلات رأس عمود على اللوحة = إخفاؤه
      el.addEventListener("dragover", e => { if (DRAG && DRAG.src === "h") { e.preventDefault(); el.classList.add("over"); } });
      el.addEventListener("dragleave", () => el.classList.remove("over"));
      el.addEventListener("drop", e => { el.classList.remove("over"); if (!DRAG || DRAG.src !== "h") return; e.preventDefault(); DRAG.done = true; hideCol(DRAG.k); });
      // سحب اللوحة من عنوانها
      const h = el.querySelector(".cu-h"); let ox = 0, oy = 0;
      h.addEventListener("pointerdown", e => { if (e.target.closest(".cu-x")) return; ox = e.clientX - el.offsetLeft; oy = e.clientY - el.offsetTop; h.setPointerCapture(e.pointerId); h.classList.add("mv"); });
      h.addEventListener("pointermove", e => { if (!h.classList.contains("mv")) return; el.style.left = Math.max(0, Math.min(innerWidth - el.offsetWidth, e.clientX - ox)) + "px"; el.style.top = Math.max(0, Math.min(innerHeight - 40, e.clientY - oy)) + "px"; });
      h.addEventListener("pointerup", () => h.classList.remove("mv"));
      draw(); setTimeout(() => q.focus(), 0);
    }
    function hideCol(k) {
      if (k === "name") { say("لا يمكن إخفاء عمود اسم الصنف", "w"); return; }
      setLayout(layKeys().filter(x => x !== k)); say("تم إخفاء العمود «" + CMAP[k].t + "»", "i");
    }
    /* سحب رؤوس الأعمدة لإعادة الترتيب + مؤشر الإفلات + تغيير العرض */
    let DRAG = null;
    const ind = document.createElement("div"); ind.className = "pu-dind"; ind.innerHTML = "<b>▼</b><b>▲</b>"; ind.hidden = true; document.body.appendChild(ind);
    function hideInd() { ind.hidden = true; }
    function dropIndex(x) {
      const hs = Array.from(grid.querySelectorAll(".pu-gh .hc"));
      let best = { i: hs.length, d: Infinity, x: 0 };
      hs.forEach((h, i) => { const r = h.getBoundingClientRect();
        [[r.right, i], [r.left, i + 1]].forEach(([bx, at]) => { const d = Math.abs(x - bx); if (d < best.d) best = { i: at, d, x: bx }; }); });   // RTL: يمين الخلية قبلها، يسارها بعدها
      return best;
    }
    grid.addEventListener("dragstart", e => {
      const h = e.target.closest && e.target.closest(".pu-gh .hc"); if (!h) return;
      if (D._resizing) { e.preventDefault(); return; }
      DRAG = { k: h.dataset.k, src: "h", y0: e.clientY }; e.dataTransfer.setData("text/plain", h.dataset.k); e.dataTransfer.effectAllowed = "move";
      h.classList.add("dg");
      if (!CUST) { /* تلميح: تظهر اللوحة لاستقبال العمود المخفي */ }
    });
    grid.addEventListener("dragover", e => {
      if (!DRAG) return;
      const gh = grid.querySelector(".pu-gh"), r = gh.getBoundingClientRect();
      if (e.clientY < r.top - 30 || e.clientY > r.bottom + 30) { hideInd(); return; }
      e.preventDefault(); e.dataTransfer.dropEffect = "move";
      const b = dropIndex(e.clientX); ind.hidden = false; ind.style.left = (b.x - 6) + "px"; ind.style.top = (r.top - 12) + "px"; ind.style.height = (r.height + 24) + "px";
    });
    grid.addEventListener("drop", e => {
      if (!DRAG) return; e.preventDefault(); hideInd();
      const keys = layKeys(), b = dropIndex(e.clientX), k = DRAG.k; DRAG.done = true;
      let at = b.i; const from = keys.indexOf(k);
      if (from >= 0) { keys.splice(from, 1); if (from < at) at--; }
      keys.splice(Math.max(0, Math.min(at, keys.length)), 0, k);
      setLayout(keys);
      if (DRAG.src === "c") say("تمت إضافة العمود «" + CMAP[k].t + "»", "s");
    });
    grid.addEventListener("dragend", e => {
      const h = grid.querySelector(".pu-gh .hc.dg"); if (h) h.classList.remove("dg");
      hideInd();
      // سحب الرأس بعيداً عن الجدول ثم الإفلات = إخفاء العمود (كما DEXEF)
      if (DRAG && DRAG.src === "h" && !DRAG.done) { const r = grid.querySelector(".pu-gh").getBoundingClientRect(); if (e.clientY && (e.clientY > r.bottom + 60 || e.clientY < r.top - 60)) hideCol(DRAG.k); }
      DRAG = null;
    });
    grid.addEventListener("pointerdown", e => {
      const z = e.target.closest(".pu-gh .rz"); if (!z) return;
      e.preventDefault(); e.stopPropagation();
      const hc = z.parentElement, k = hc.dataset.k, x0 = e.clientX, w0 = hc.getBoundingClientRect().width;
      D._resizing = true; hc.draggable = false; z.setPointerCapture(e.pointerId); document.body.classList.add("pu-colrs");
      const vis = visCols(), idx = vis.findIndex(c => c.k === k);
      const mv = ev => { const w = Math.max(40, Math.round(w0 + (x0 - ev.clientX))); vis[idx] = Object.assign({}, vis[idx], { w: w + "px" }); const tpl = gridTpl(vis);
        grid.querySelectorAll(".pu-gr").forEach(rw => { rw.style.gridTemplateColumns = tpl; }); const gs = root.querySelector(".pu-gsum"); if (gs) gs.style.gridTemplateColumns = tpl; D._w = w; };
      const up = () => { z.removeEventListener("pointermove", mv); z.removeEventListener("pointerup", up); document.body.classList.remove("pu-colrs"); hc.draggable = true;
        setTimeout(() => { D._resizing = false; }, 0); if (D._w) { setLayout(layKeys(), { [k]: D._w }); D._w = 0; } };
      z.addEventListener("pointermove", mv); z.addEventListener("pointerup", up);
    });
    grid.addEventListener("dblclick", e => { const z = e.target.closest(".pu-gh .rz"); if (!z) return; const k = z.parentElement.dataset.k, m = layId(), lay = LAYOUT[m]; if (lay && lay.w) { delete lay.w[k]; saveLayout(m, lay); } });
    /* ---------- تنسيق الفاتورة (مطابق DEXEF) ---------- */
    let ENTRY = lsGet("pur.entryRow", "top");
    D.insAt = null; D.filter = "";
    function keysMenu(b) {
      const K = [["F2", "حفظ و جديد", () => save("new")], ["F4", "حفظ وطباعة", () => save("print")], ["Ctrl+S", "حفظ", () => save("stay")], ["F3", "بحث عن صنف", () => openPicker(grid.querySelector(".pu-new [data-c=name]"), null)],
        ["F5", "تحديث البيانات", () => refreshData(true)], ["F6", "اختيار المورد", () => { F("supName").focus(); supPicker(F("supName")); }], ["F7", "شاشة الدفع", () => payDlg()], ["F8", "كاش / أجل", () => setCredit(!S.credit)],
        ["Insert", "سطر جديد", () => focusCell(-1, "name")], ["Ctrl+C", "نسخ السطر", () => copyRow(S.sel)], ["Ctrl+V", "لصق السطر", pasteRow], ["Ctrl+Delete", "حذف السطر", () => { if (S.rows[S.sel]) ask("هل تريد حذف هذا السطر", () => delRow(S.sel)); }],
        ["Alt+→", "المستند السابق", () => nav(-1)], ["Alt+←", "المستند التالي", () => nav(1)], ["Ctrl+N", "مستند جديد", () => openDoc(type, { forceNew: S.rows.length > 0 })]];
      menuPop(b, K.map(k => ({ t: k[1], k: k[0], f: k[2] })));
    }
    function insertRow() {
      if (S.sel < 0 || !S.rows.length) { focusCell(-1, "name"); return; }
      D.insAt = S.sel + 1;
      say("سيتم إدخال الصنف التالي بعد السطر " + (S.sel + 1), "i");
      renderGrid(); focusCell(-1, "name");
    }
    function entryMenu(b) {
      menuPop(b, [{ t: "أعلى الجدول", f: () => setEntry("top") }, { t: "أسفل الجدول", f: () => setEntry("bottom") }]);
      POP.el.querySelectorAll(".mi")[ENTRY === "bottom" ? 1 : 0].classList.add("on");
    }
    function setEntry(v) { ENTRY = v; lsSet("pur.entryRow", v); Object.values(DOCS).forEach(d => d.syncCols()); focusCell(-1, "name"); }
    function printMenu(b) {
      const pp = F("paper"), ck = n => F(n).checked;
      const set = (n, v) => { const e = F(n); if (e.type === "checkbox") e.checked = v; else e.value = v; lsSet("pur.print", { paper: F("paper").value, logo: ck("pLogo"), bal: ck("pBal"), sale: ck("pSale") }); };
      menuPop(b, [
        { t: "طباعة", k: "Ctrl+P", ic: I.print, dis: !S.rows.length, f: () => printDoc() },
        { t: "معاينة الطباعة", dis: !S.rows.length, f: () => printDoc(true) }, "-",
        { t: (pp.value === "A4" ? "✓ " : "") + "ورق A4", f: () => set("paper", "A4") }, { t: (pp.value === "A5" ? "✓ " : "") + "ورق A5", f: () => set("paper", "A5") }, { t: (pp.value === "80" ? "✓ " : "") + "إيصال 80mm", f: () => set("paper", "80") }, "-",
        { t: (ck("pLogo") ? "✓ " : "") + "شعار الشركة", f: () => set("pLogo", !ck("pLogo")) }, { t: (ck("pBal") ? "✓ " : "") + "رصيد المورد", f: () => set("pBal", !ck("pBal")) }, { t: (ck("pSale") ? "✓ " : "") + "عمود سعر البيع", f: () => set("pSale", !ck("pSale")) }]);
    }
    { const pr = lsGet("pur.print", null); if (pr) { F("paper").value = pr.paper || "A4"; F("pLogo").checked = pr.logo !== false; F("pBal").checked = pr.bal !== false; F("pSale").checked = !!pr.sale; } }
    /* بحث متقدم داخل الفاتورة (مطابق DEXEF + تطوير): تلوين المطابقة بالأصفر، الانتقال بين النتائج، عدّاد، وتصفية اختيارية */
    D.hits = []; D.hitIx = -1; D.fOnly = false;
    const fWords = () => norm(D.filter).split(/\s+/).filter(Boolean);
    function rowText(r) {
      const x = r.x || {}, p = prodById(r.pid);
      return norm([r.code, r.name, r.unit, r.notes, x.batch, x.lot, (x.serials || []).join(" "), x.desc, p ? unitsOf(p).map(u => [u.bc].concat(u.xb || []).join(" ")).join(" ") : "", fmt(r.qty), fmt(r.price), fmt(lineTotal(r))].join(" "));
    }
    // تلوين النص مع تجاهل فروق الهمزات والتاء المربوطة والألف المقصورة وحالة الأحرف
    function markHTML(text, words) {
      text = String(text || ""); if (!words.length) return esc(text);
      const nt = text.toLowerCase().replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي"), ranges = [];
      if (nt.length !== text.length) return esc(text);
      words.forEach(w => { let k = 0; while ((k = nt.indexOf(w, k)) >= 0) { ranges.push([k, k + w.length]); k += w.length || 1; } });
      if (!ranges.length) return esc(text);
      ranges.sort((a, b) => a[0] - b[0]);
      let out = "", at = 0;
      ranges.forEach(([a, b]) => { if (b <= at) return; a = Math.max(a, at); out += esc(text.slice(at, a)) + "<mark>" + esc(text.slice(a, b)) + "</mark>"; at = b; });
      return out + esc(text.slice(at));
    }
    function markRow(el, r, words, on) {
      el.querySelectorAll(".hlw").forEach(w => { const inp = w.querySelector("input"), b = w.querySelector(".hlb"); if (!inp || !b) return; b.innerHTML = on ? markHTML(inp.value, words) : ""; });
    }
    function applyFilter(jump) {
      const words = fWords(), f = words.length > 0;
      D.hits = [];
      grid.querySelectorAll(".pu-d").forEach(el => {
        const i = +el.dataset.i, r = S.rows[i]; if (!r) return;
        const t = rowText(r), ok = f && words.every(w => t.includes(w));
        if (ok) D.hits.push(i);
        el.classList.toggle("hit", ok);
        el.classList.toggle("pu-hid", f && D.fOnly && !ok);
        markRow(el, r, words, ok);
      });
      grid.querySelectorAll(".pu-fill").forEach(el => el.classList.toggle("pu-hid", f && D.fOnly));
      if (!f) D.hitIx = -1;
      else if (jump || D.hitIx < 0 || D.hitIx >= D.hits.length) D.hitIx = D.hits.length ? 0 : -1;
      showHit(jump);
    }
    function showHit(scroll) {
      const box = F("gfind").parentElement, cnt = box.querySelector(".fcnt"), f = fWords().length > 0;
      grid.querySelectorAll(".pu-d.hitcur").forEach(e => e.classList.remove("hitcur"));
      box.classList.toggle("on", f); box.classList.toggle("none", f && !D.hits.length); box.classList.toggle("only", D.fOnly);
      cnt.textContent = f ? (D.hits.length ? (D.hitIx + 1) + "/" + D.hits.length : "0/0") : "";
      if (!f || D.hitIx < 0) return;
      const i = D.hits[D.hitIx], el = grid.querySelector(`.pu-d[data-i="${i}"]`);
      if (el) { el.classList.add("hitcur"); if (scroll) el.scrollIntoView({ block: "nearest" }); }
      if (S.sel !== i) select(i);
    }
    function stepHit(d) { if (!D.hits.length) return; D.hitIx = (D.hitIx + d + D.hits.length) % D.hits.length; showHit(true); }
    function clearFind() { F("gfind").value = ""; D.filter = ""; D.fOnly = false; applyFilter(); }
    let fT = 0;
    F("gfind").addEventListener("input", () => { clearTimeout(fT); fT = setTimeout(() => { D.filter = F("gfind").value.trim(); applyFilter(true); }, 80); });
    F("gfind").addEventListener("keydown", e => {
      if (e.key === "Escape") { e.preventDefault(); clearFind(); }
      else if (e.key === "Enter" && e.ctrlKey) { e.preventDefault(); if (D.hitIx >= 0) focusCell(D.hits[D.hitIx], "qty"); }   // Ctrl+Enter: تعديل السطر المطابق
      else if (e.key === "Enter" || e.key === "F3") { e.preventDefault(); stepHit(e.shiftKey ? -1 : 1); }
      else if (e.key === "ArrowDown") { e.preventDefault(); stepHit(1); }
      else if (e.key === "ArrowUp") { e.preventDefault(); stepHit(-1); }
    });
    F("gfind").parentElement.addEventListener("mousedown", e => { if (e.target.closest(".fbt")) e.preventDefault(); });
    F("gfind").parentElement.addEventListener("click", e => {
      const b = e.target.closest(".fbt"); if (!b) { F("gfind").focus(); return; }
      if (b.dataset.a === "fNext") stepHit(1); else if (b.dataset.a === "fPrev") stepHit(-1);
      else if (b.dataset.a === "fClear") { clearFind(); F("gfind").focus(); }
      else if (b.dataset.a === "fFilter") { D.fOnly = !D.fOnly; applyFilter(); }
    });
    function selRowOrWarn() { const r = S.rows[S.sel]; if (!r) say("اختر سطراً من الفاتورة أولاً", "w"); return r; }
    /* بحث برقم السيريال (مطابق DEXEF): في كل مستندات المشتريات المحفوظة + المستندات المفتوحة */
    function serialFind() {
      const ov = document.createElement("div"); ov.className = "pu-ov pu-snov";
      ov.innerHTML = `<div class="pu-sn" role="dialog" aria-label="بحث برقم السيريال" tabindex="-1">
        <div class="sn-bar"><span class="sn-ic">${'<svg viewBox="0 0 16 16" width="14" height="14"><rect x="1" y="1" width="14" height="14" rx="2" fill="#2b7de0"/><path d="M4 8h8M8 4v8" stroke="#fff" stroke-width="1.6"/></svg>'}</span><span class="sp"></span><button type="button" data-w="min" title="تصغير">—</button><button type="button" data-w="max" title="تكبير">☐</button><button type="button" data-x="1" title="إغلاق">✕</button></div>
        <div class="sn-t">بحث برقم السيريال</div>
        <div class="sn-d"><span>تستخدم هذه الصفحة للبحث عن رقم السيريال .. للتأكد من أن العميل تم تعامله مع هذه السيريال</span><button type="button" class="sn-pr" data-a="print" title="طباعة">${'<svg viewBox="0 0 32 32" width="30" height="30"><rect x="3" y="3" width="26" height="26" rx="3" fill="#3f8ae0"/><rect x="9" y="5" width="14" height="8" fill="#fff"/><rect x="7" y="16" width="18" height="10" rx="1" fill="#e9f1fc"/><rect x="10" y="19" width="12" height="2" fill="#3f8ae0"/></svg>'}</button></div>
        <div class="sn-p">
          <div class="sn-q"><span>أدخل الرقم</span><input class="sn-in" autocomplete="off"><button type="button" class="sn-go" data-a="go">بحث</button></div>
          <div class="sn-info"><div class="c1"><div><b>الكود</b><span class="v-code"></span></div><div><b>الصنف</b><span class="v-name"></span></div></div>
            <div class="c2"><div><b>مدة الضمان</b><span class="v-war"></span><i>شهر</i></div><div><b>الايام المتبقية</b><span class="v-rem"></span><i>يوم</i></div></div></div>
        </div>
        <div class="sn-g"><div class="sn-h"><span></span><span>الاسم</span><span>رقم الفاتورة</span><span>حالة التعامل</span><span>التعامل</span><span>الوقت</span><span>التاريخ</span></div><div class="sn-b"></div></div></div>`;
      document.body.appendChild(ov);
      const box = ov.querySelector(".pu-sn"), inp = ov.querySelector(".sn-in"), gb = ov.querySelector(".sn-b");
      const ST = { Posted: "معتمدة", Open: "مفتوحة", Draft: "مسودة", Paid: "مدفوعة", Void: "ملغاة" };
      let last = [];
      const close = () => ov.remove();
      const match = (list, q) => (list || []).some(z => String(z).toLowerCase() === q) ;
      function localHits(q) {
        const out = [];
        Object.values(DOCS).forEach(d => { const st = d.state; if (!st) return;
          st.rows.forEach(r => { const x = r.x || {}; if (match(x.serials, q) || String(x.batch || "").toLowerCase() === q || String(x.lot || "").toLowerCase() === q)
            out.push({ local: 1, key: d.key, id: st.id, no: st.id ? st.no : "(غير محفوظة)", date: today(), time: "", status: st.id ? "معدّلة — غير محفوظة" : "غير محفوظة", typeName: TY[d.type].t, type: d.type,
              party: (supById(st.supId) || {}).name || "تعامل نقدي", code: r.code, name: r.name, warranty: num(x.warranty) }); }); });
        return out;
      }
      function draw(hits) {
        last = hits;
        gb.innerHTML = hits.length ? hits.map((h, i) => `<div class="sn-r${h.local ? " lc" : ""}" data-i="${i}"><span>${h.type === "PurchaseReturn" ? "↩" : h.type === "PurchaseOrder" ? "◷" : "⬇"}</span><span>${esc(h.party || "تعامل نقدي")}</span><span>${esc(h.no)}</span><span>${esc(ST[h.status] || h.status || "")}</span><span>${esc(h.typeName)}</span><span>${esc(h.time)}</span><span>${esc(h.date)}</span></div>`).join("")
          : `<div class="sn-e">${inp.value.trim() ? "لم يتم العثور على هذا السيريال في أي تعامل" : ""}</div>`;
        const f = hits.find(h => h.type === "Purchase") || hits[0];
        ov.querySelector(".v-code").textContent = f ? f.code : ""; ov.querySelector(".v-name").textContent = f ? f.name : "";
        ov.querySelector(".v-war").textContent = f && f.warranty ? fmt(f.warranty) : "";
        let rem = "";
        if (f && f.warranty && f.date) { const end = new Date(f.date); end.setMonth(end.getMonth() + Math.round(f.warranty)); const d = Math.ceil((end - new Date(today())) / 864e5); rem = d < 0 ? "منتهي" : String(d); }
        const rv = ov.querySelector(".v-rem"); rv.textContent = rem; rv.classList.toggle("neg", rem === "منتهي");
      }
      function go() {
        const q = inp.value.trim().toLowerCase(); if (!q) { inp.focus(); return; }
        const loc = localHits(q);
        if (!B()) { draw(loc.concat(LOCAL.docs.flatMap(d => (d.doc.rows || []).filter(r => r.x && (match(r.x.serials, q) || String(r.x.lot || "").toLowerCase() === q)).map(r => ({ id: d.id, no: d.no, date: d.date, time: d.time, status: "Posted", typeName: TY[d.type].t, type: d.type, party: d.sup, code: r.code, name: r.name, warranty: num(r.x.warranty) }))))); return; }
        gb.innerHTML = '<div class="sn-e">جارٍ البحث…</div>';
        call("fm.pur.serial", { q: inp.value.trim() }).then(list => {
          const hits = [];
          (list || []).forEach(h => { let m = {}; try { m = h.meta ? JSON.parse(h.meta) : {}; } catch (e) { }
            (m.lx || []).forEach((x, i) => { if (!x) return; if (match(x.serials, q) || String(x.batch || "").toLowerCase() === q || String(x.lot || "").toLowerCase() === q) {
              const it = (h.items || [])[i] || {}; hits.push({ id: h.id, no: h.no, date: h.date, time: h.time, status: h.status, typeName: h.typeName, type: h.type, party: h.party, code: it.code || "", name: it.name || "", warranty: num(x.warranty) }); } }); });
          const ids = new Set(hits.map(h => h.id));
          const xh = window.__SN ? window.__SN.hits(inp.value) : [];
          draw(hits.concat(loc.filter(l => !l.id || !ids.has(l.id))).concat(xh));
        }).catch(e => { gb.innerHTML = `<div class="sn-e neg">${esc(/غير معروف/.test(e.message) ? "البحث في المستندات المحفوظة يحتاج إعادة بناء البرنامج (build-exe)" : e.message)}</div>`; draw(loc); });
      }
      ov.addEventListener("click", e => {
        const b = e.target.closest("button"); if (e.target === ov) return;
        if (b && b.dataset.x) close();
        else if (b && b.dataset.w === "max") box.classList.toggle("maxi");
        else if (b && b.dataset.w === "min") box.classList.toggle("mini");
        else if (b && b.dataset.a === "go") go();
        else if (b && b.dataset.a === "print") {
          const w = window.open("", "_blank"); if (!w) return;
          w.document.write(`<html dir="rtl"><head><meta charset="utf-8"><title>بحث برقم السيريال</title><style>body{font-family:Tahoma;font-size:12px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #bbb;padding:4px}th{background:#e1ebff}</style></head><body><h3>السيريال: ${esc(inp.value)} — ${esc(ov.querySelector(".v-name").textContent)}</h3><table><tr><th>الاسم</th><th>رقم الفاتورة</th><th>الحالة</th><th>التعامل</th><th>التاريخ</th></tr>${last.map(h => `<tr><td>${esc(h.party)}</td><td>${esc(h.no)}</td><td>${esc(ST[h.status] || h.status)}</td><td>${esc(h.typeName)}</td><td>${esc(h.date)} ${esc(h.time)}</td></tr>`).join("")}</table></body></html>`);
          w.document.close(); setTimeout(() => { try { w.print(); } catch (x) { } }, 250);
        }
      });
      gb.addEventListener("dblclick", e => { const r = e.target.closest(".sn-r"); if (!r) return; const h = last[+r.dataset.i]; if (!h || (!h.local && !h.id)) return; close();
        if (h.local) { try { openTab(h.key, TY[h.type].tab, "pur"); } catch (x) { } } else openSaved(h.type, h.id); });
      box.addEventListener("keydown", e => { if (e.key === "Enter" && e.target === inp) { e.preventDefault(); go(); } else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); } });
      draw([]); setTimeout(() => inp.focus(), 0);
    }
    function serialFill() {
      const r = selRowOrWarn(); if (!r) return;
      const SNH = () => window.__SN, SNOUT = !!(ty.out || ty.dir < 0 || type === "PurchaseReturn"), P_BY_ID = id => (window.products || []).find(p => p.id == id);
      if (!isSerial(r.pid)) { emAlert("هذا الصنف ليس مخزون برقم تسلسلي"); return; }
      const n = Math.max(1, Math.round((+r.qty || 1) * (r.factor || 1))), cur = (r.x && r.x.serials) || [];
      const ov = modal("تعبئة ارقام السيريال — " + r.name, `<div class="pu-ser"><p>عدد القطع: <b>${n}</b></p>
        <div class="row"><label class="pu-f"><span class="lb">أول سيريال</span><span class="pu-in"><input class="s0" placeholder="مثال: SN-1000" autocomplete="off"></span></label>
        <label class="pu-f"><span class="lb">الخطوة</span><span class="pu-in"><input class="st n" value="1" inputmode="numeric"></span></label><button type="button" class="pu-bt b gen">توليد</button></div>
        <label class="pu-f"><span class="lb">الأرقام (سطر لكل قطعة — يمكنك المسح بالباركود)</span><textarea class="ls" rows="9">${esc(cur.join("\n"))}</textarea></label><div class="cnt"></div>
        ${SNOUT ? '<div class="pu-snav"><div class="hd"><b>الأرقام المتاحة في المخزون</b><span class="n">…</span><button type="button" class="pu-bt b auto">اختيار تلقائي</button></div><input class="flt" placeholder="تصفية / مسح بالباركود" autocomplete="off"><div class="chips"></div></div>' : ""}</div>`, ov => {
          const l = ov.querySelector(".ls").value.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
          const dup = l.find((x, k) => l.indexOf(x) !== k); if (dup) { say("سيريال مكرر: " + dup, "w"); return false; }
          /* الربط مع «ضبط الأرقام التسلسلية»: الصادر من المتاح فقط ، والوارد لا يتكرر مع ما في المخزون */
          if (SNH() && SNH().ready()) {
            if (SNOUT) { const av = new Set(SNH().avail(r.pid).concat(cur)), bad = l.filter(x => !av.has(x)); if (bad.length) { say("غير متاح في المخزون: " + bad.slice(0, 3).join(" ، ") + (bad.length > 3 ? " …" : ""), "w"); return false; } }
            else { const bad = l.filter(x => !cur.includes(x) && SNH().owner(x) != null && SNH().avail(SNH().owner(x)).includes(x)); if (bad.length) { const op = (P_BY_ID(SNH().owner(bad[0])) || {}).name; say("موجود مسبقاً في المخزون: " + bad[0] + (op ? " («" + op + "»)" : ""), "w"); return false; } }
          }
          r.x = r.x || {}; r.x.serials = l; markDirty(); renderRow(S.sel); say("تم حفظ " + l.length + " سيريال لـ «" + r.name + "»", "s");
        });
      const ls = ov.querySelector(".ls"), cnt = ov.querySelector(".cnt");
      const upd = () => { const k = ls.value.split(/\r?\n/).filter(x => x.trim()).length; cnt.textContent = k + " / " + n; cnt.classList.toggle("neg", k !== n); };
      ls.addEventListener("input", upd); upd();
      if (SNH()) SNH().load().then(() => { if (!ov.isConnected) return; if (SNOUT) avDraw(); }).catch(() => { const b = ov.querySelector(".pu-snav .n"); if (b) b.textContent = "—"; });
      function avDraw() {
        const box = ov.querySelector(".pu-snav"); if (!box) return;
        const picked = new Set(ls.value.split(/\r?\n/).map(x => x.trim()).filter(Boolean)), q = ov.querySelector(".flt").value.trim().toLowerCase();
        const av = Array.from(new Set(SNH().avail(r.pid).concat(cur)));
        box.querySelector(".n").textContent = av.length + " رقم";
        box.querySelector(".chips").innerHTML = av.filter(z => !q || z.toLowerCase().includes(q)).slice(0, 400).map(z => `<button type="button" class="ch${picked.has(z) ? " on" : ""}" data-sn="${esc(z)}">${esc(z)}</button>`).join("") || '<span class="e">لا توجد أرقام متاحة لهذا الصنف — راجع «ضبط الأرقام التسلسلية»</span>';
      }
      if (SNOUT) {
        const box = ov.querySelector(".pu-snav");
        const setL = l => { ls.value = l.join("\n"); upd(); avDraw(); };
        const curL = () => ls.value.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
        box.addEventListener("click", e => { const c = e.target.closest(".ch"); if (c) { const l = curL(), i = l.indexOf(c.dataset.sn); if (i >= 0) l.splice(i, 1); else l.push(c.dataset.sn); setL(l); return; }
          if (e.target.closest(".auto")) { const l = curL(); SNH().avail(r.pid).forEach(z => { if (l.length < n && !l.includes(z)) l.push(z); }); setL(l); } });
        box.querySelector(".flt").addEventListener("input", avDraw);
        box.querySelector(".flt").addEventListener("keydown", e => { if (e.key !== "Enter") return; e.preventDefault(); e.stopPropagation(); const v = e.target.value.trim(); if (!v) return; const av = SNH().avail(r.pid).concat(cur); if (!av.includes(v)) { say("غير متاح في المخزون: " + v, "w"); return; } const l = curL(); if (!l.includes(v)) l.push(v); e.target.value = ""; setL(l); });
        ls.addEventListener("input", avDraw);
      }
      ov.querySelector(".gen").addEventListener("click", () => {
        const s0 = ov.querySelector(".s0").value.trim(), st = Math.max(1, parseInt(ov.querySelector(".st").value) || 1);
        const m = s0.match(/^(.*?)(\d+)$/); if (!m) { say("أدخل أول سيريال ينتهي برقم", "w"); return; }
        const pre = m[1], w = m[2].length, b0 = +m[2];
        ls.value = Array.from({ length: n }, (_, k) => pre + String(b0 + k * st).padStart(w, "0")).join("\n"); upd();
      });
    }
    function lotPop(i) {
      const r = S.rows[i]; if (!r) return;
      const cell = grid.querySelector(`.pu-d[data-i="${i}"] [data-k="name"]`) || grid;
      const el = openPop(cell, `<div class="pu-desc"><div class="hd">رقم التشغيلة — ${esc(r.name)}</div><input class="ed" value="${esc((r.x && r.x.lot) || "")}" autocomplete="off" style="width:100%;height:26px;border:0;border-bottom:2px solid #1f7ad8;outline:0;font:inherit;direction:ltr"><div class="ft"><button type="button" class="pu-bt g">حفظ</button></div></div>`, "pu-descpop");
      const d = el.querySelector(".ed"); setTimeout(() => d.focus(), 0);
      const ok = () => { r.x = r.x || {}; r.x.lot = d.value.trim(); closePop(); markDirty(); if (r.x.lot && !layKeys().includes("lot")) { const k = layKeys(); k.splice(k.indexOf("total"), 0, "lot"); setLayout(k); } else renderRow(i); };
      el.querySelector("button").addEventListener("click", ok);
      d.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); ok(); } });
    }
    function expAdd(b) {
      const r = selRowOrWarn(); if (!r) return;
      /* تاريخ الصلاحية للأصناف المخزنية فقط (مخزون / مخزون بصلاحية / بسيريال / منتج تام / ملابس) */
      if (isExpRow(r)) { batchPop(S.sel); return; }
      const ty = (window.__ITYPE && window.__ITYPE[r.pid]) || "stock", SK = window.__ITYPE_STOCK || ["stock", "serial", "expiry", "made", "apparel", "scale"];
      if (SK.indexOf(ty) < 0) { say("تاريخ الصلاحية متاح للأصناف المخزنية فقط — «" + r.name + "» ليس صنف مخزون", "w"); try { window.ANOUER_SOUND && ANOUER_SOUND("err"); } catch (e) { } return; }
      const el = openPop(b, `<div class="pu-desc"><div class="hd">تاريخ صلاحية — ${esc(r.name)}</div><input type="date" class="ed" value="${esc((r.x && r.x.expDate) || "")}"><div class="ft"><button type="button" class="pu-bt g">حفظ</button></div></div>`, "pu-descpop");
      const d = el.querySelector(".ed"); setTimeout(() => d.focus(), 0);
      el.querySelector("button").addEventListener("click", () => {
        r.x = r.x || {}; r.x.expDate = d.value; closePop(); markDirty();
        if (d.value && !layKeys().includes("expDate")) { const k = layKeys(); k.splice(k.indexOf("total"), 0, "expDate"); setLayout(k); } else renderRow(S.sel);
        say(d.value ? "تاريخ الصلاحية: " + d.value : "تم مسح تاريخ الصلاحية", "s");
      });
    }
    function expShow() {
      const l = S.rows.map((r, i) => ({ r, i, d: r.x && r.x.expDate })).filter(o => o.d).sort((a, b) => a.d.localeCompare(b.d));
      const td = today(), soon = new Date(Date.now() + 90 * 864e5).toISOString().slice(0, 10);
      const ov = document.createElement("div"); ov.className = "pu-ov";
      ov.innerHTML = `<div class="pu-dlg"><div class="dh"><span>تواريخ الصلاحية</span><button type="button" class="dx">✕</button></div><div class="db"><div class="pu-exl">
        ${l.length ? `<div class="h"><span>#</span><span>الصنف</span><span>الكمية</span><span>تاريخ الصلاحية</span><span>المتبقي</span></div>` + l.map(o => { const days = Math.round((new Date(o.d) - new Date(td)) / 864e5);
          return `<div class="r${o.d < td ? " ex" : o.d <= soon ? " sn" : ""}" data-i="${o.i}"><span>${o.i + 1}</span><span class="t">${esc(o.r.name)}</span><span>${fmt(o.r.qty)}</span><span>${esc(o.d)}</span><span>${days < 0 ? "منتهي" : days + " يوم"}</span></div>`; }).join("") : '<div class="pq-empty">لا توجد تواريخ صلاحية في هذه الفاتورة — استخدم «اضافة تاريخ صلاحية»</div>'}
        </div></div><div class="df"><button type="button" class="pu-bt b" data-x="1">إغلاق</button></div></div>`;
      document.body.appendChild(ov);
      ov.addEventListener("click", e => { const r = e.target.closest(".r[data-i]"); if (r) { ov.remove(); const i = +r.dataset.i; select(i); flash(i); focusCell(i, "qty"); return; } if (e.target === ov || e.target.closest(".dx,[data-x]")) ov.remove(); });
      ov.addEventListener("keydown", e => { if (e.key === "Escape") ov.remove(); });
      ov.querySelector("[data-x]").focus();
    }
    /* «نسخ التعامل» (مطابق DEXEF): المبيعات | المشتريات | المخازن — نسخ أصناف المستند الحالي إلى مستند جديد من النوع المختار */
    const CPG = [
      ["المبيعات", '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6M9 16h3"/>', "#1565c0", [["@Sale", "فاتورة مبيعات"], ["@SaleReturn", "مرتجع مبيعات"], ["Quotation", "عرض سعر"], ["", "فاتورة أولية"], ["SupplyOrder", "أمر توريد"], ["StockOut", "إذن صرف"], ["", "إعتماد إذن صرف"]]],
      ["المشتريات", '<path d="M3 4h2l2.4 11h11L21 7H6.2"/><circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/>', "#2e8b57", [["Purchase", "فاتورة مشتريات"], ["PurchaseReturn", "مرتجع شراء"], ["PurchaseOrder", "طلبية شراء"], ["", "استلام عروض أسعار"], ["", "أمر شراء"], ["StockIn", "إذن استلام"], ["", "إعتماد أذون الإستلام"]]],
      ["المخازن", '<path d="M3 9l9-5 9 5v11H3z"/><path d="M8 20v-6h8v6"/>', "#e0622a", [["Transfer", "تحويلات مخازن"], ["TransferReq", "طلب تحويل بضاعة"], ["Opening", "مخزون أول المدة"], ["Waste", "هالك المخزون"], ["Charity", "الصدقات"], ["ReserveReq", "طلب حجز بضاعة"], ["Reserve", "حجز بضاعة"], ["ReserveCancel", "إلغاء حجز البضاعة"]]]
    ];
    const CPC = { "@Sale": "#1565c0", "@SaleReturn": "#e65100" };
    function copyMenu(b) {
      if (!S.rows.length) { say("لا توجد أصناف لنسخها", "w"); return; }
      const t = totals(), flat = [];
      const col = g => `<div class="cp-col" style="--gc:${g[2]}"><div class="cp-gh"><i>${'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' + g[1] + "</svg>"}</i><b>${g[0]}</b></div>${g[3].map(x => {
        const ok = !!x[0] && (x[0][0] === "@" ? typeof window.newInvoice === "function" : !!TY[x[0]]), i = ok ? flat.push(x) - 1 : -1, c = x[0] && (CPC[x[0]] || (TY[x[0]] && TY[x[0]].c)) || "#b0bac8";
        return `<button type="button" class="cp-it${ok ? "" : " dis"}${x[0] === type ? " cur" : ""}"${ok ? ` data-i="${i}"` : " disabled"} style="--c:${c}"><i class="d"></i><span>${x[1]}</span>${x[0] === type ? '<em>الحالي</em>' : ok ? "" : '<small>غير متاح</small>'}</button>`;
      }).join("")}</div>`;
      const el = openPop(b, `<div class="pu-cpy"><div class="cp-hd"><b>نسخ التعامل</b><span>نسخ <em>${S.rows.length}</em> صنف · الاجمالي <em>${fmt(t.total)}</em> إلى مستند جديد</span></div>
        <div class="cp-cols">${CPG.map(col).join("")}</div>
        <div class="cp-ft"><button type="button" class="cp-clip">${I.copy}<span>نسخ الأصناف إلى الحافظة</span></button><span class="cp-k"><kbd>↑↓</kbd><kbd>←→</kbd> تنقّل <kbd>Enter</kbd> نسخ <kbd>Esc</kbd> إغلاق</span></div></div>`, "pu-cpypop");
      const its = [...el.querySelectorAll(".cp-it[data-i]")]; let hi = Math.max(0, its.findIndex(x => !x.classList.contains("cur")));
      const mark = () => its.forEach((x, k) => x.classList.toggle("hi", k === hi));
      const pick = k => { const x = flat[+its[k].dataset.i]; closePop(); if (x[0][0] === "@") copyToSale(x[0] === "@SaleReturn"); else copyTo(x[0]); };
      el.addEventListener("mousedown", e => e.preventDefault());
      el.addEventListener("mousemove", e => { const x = e.target.closest(".cp-it[data-i]"); if (x) { hi = its.indexOf(x); mark(); } });
      el.addEventListener("click", e => { const x = e.target.closest(".cp-it[data-i]"); if (x) { pick(its.indexOf(x)); return; } if (e.target.closest(".cp-clip")) { closePop(); copyClipboard(); } });
      POP.key = e => {
        const k = e.key;
        if (k === "ArrowDown" || k === "ArrowUp") { hi = (hi + (k === "ArrowDown" ? 1 : -1) + its.length) % its.length; mark(); return true; }
        if (k === "ArrowLeft" || k === "ArrowRight") {   // التنقل بين الأعمدة (RTL: اليسار = العمود التالي)
          const cols = [...el.querySelectorAll(".cp-col")], ci = cols.indexOf(its[hi].closest(".cp-col")), ni = ci + (k === "ArrowLeft" ? 1 : -1);
          if (ni < 0 || ni >= cols.length) return true;
          const row = [...cols[ci].querySelectorAll(".cp-it")].indexOf(its[hi]), tgt = [...cols[ni].querySelectorAll(".cp-it")], cand = tgt.slice(Math.min(row, tgt.length - 1)).concat(tgt.slice(0, row).reverse()).find(x => x.dataset.i != null);
          if (cand) { hi = its.indexOf(cand); mark(); } return true;
        }
        if (k === "Enter") { pick(hi); return true; }
        if (k === "Escape") { closePop(); return true; }
        return false;
      };
      mark();
    }
    /* نسخ إلى فاتورة/مرتجع مبيعات: تبويب مبيعات جديد بالأصناف نفسها وبسعر البيع الحالي للوحدة */
    function copyToSale(ret) {
      /* عرض السلعة / أمر توريد → فاتورة مبيعات بنفس أسعار العرض (بعد خصم الصنف) واسم العميل */
      const src = S.rows.map(r => { const p = prodById(r.pid); const u = p && unitByName(p, r.unit); const q = +r.qty || 1;
        const qp = ty.cust ? r2((lineGross(r) - lineDisc(r)) / q * (CX.rate || 1)) : 0;
        return { pid: r.pid, name: (p && p.name) || r.name, qty: q, unit: r.unit || (u && u.name) || "حبة", price: ty.cust ? qp : r2((u && +u.price) || +r.sale || (p && +p.price) || 0) }; }).filter(r => r.pid);
      if (!src.length) { say("لا توجد أصناف لنسخها", "w"); return; }
      const n0 = document.querySelector("#tabs .tab.active"), k0 = n0 && n0.dataset.key;
      try { ret ? window.newReturn() : window.newInvoice(); } catch (e) { say("تعذّر فتح فاتورة مبيعات: " + e.message, "e"); return; }
      const n1 = document.querySelector("#tabs .tab.active");
      if (!n1 || n1.dataset.key === k0 || document.querySelector(".main").dataset.view !== "sales") return;   // الحد الأقصى للفواتير المفتوحة (رسالة من شاشة المبيعات)
      try {
        rows = src; sel = 0; renderRows(); if (typeof calc === "function") calc();
        if (ty.cust) {
          const c = supById(S.supId), cn = document.getElementById("custName");
          if (c && cn) { cn.value = c.name; cn.dispatchEvent(new Event("input", { bubbles: true })); cn.dispatchEvent(new Event("change", { bubbles: true })); }
          if (S.id && !ret && F("status") && F("status").value !== "conv") { F("status").value = "conv"; markDirty(); try { DOCS[key] && setTimeout(() => quietStatus(), 50); } catch (e) { } }
          say("✔ تم تحويل " + ty.t + (S.no ? " رقم " + S.no : "") + " إلى " + (ret ? "مرتجع مبيعات" : "فاتورة مبيعات") + " — " + src.length + " صنف بنفس الأسعار" + (c ? " للعميل " + c.name : ""), "s");
          return;
        }
        say("تم نسخ " + src.length + " صنف إلى " + (ret ? "مرتجع مبيعات" : "فاتورة مبيعات") + " جديدة بسعر البيع الحالي", "s");
      } catch (e) { say("تعذّر نسخ الأصناف: " + e.message, "e"); }
    }
    /* حفظ «الحالة» فقط لمستند عميل محفوظ (تم التحويل لفاتورة) — بلا أثر على المخزون */
    function quietStatus() {
      if (!S.id) return;
      const pl = payload();
      const ok = () => { S.dirty = false; updTitle(); LISTS[type] = null; try { refreshReviews(); } catch (e) { } };
      if (B()) call("fm.pur.save", pl).then(ok).catch(e => say("لم تُحفظ الحالة: " + e.message, "w"));
      else { const d = LOCAL.docs.find(x => x.id === S.id); if (d && d.doc) { d.doc.pl = pl; } ok(); }
    }
    function copyTo(k) {
      const snap = { rows: JSON.parse(JSON.stringify(S.rows)), supId: S.supId, cust: !!ty.cust, rate: CX.rate || 1, parentId: k === "PurchaseReturn" && type === "Purchase" ? S.id : 0 };
      const d = openDoc(k);
      d.paste(snap);
      say("تم نسخ " + snap.rows.length + " صنف إلى " + TY[k].t, "s");
    }
    function copyClipboard() {
      const txt = ["الكود\tالصنف\tالوحدة\tالكمية\tالسعر\tالاجمالي"].concat(S.rows.map(r => [r.code, r.name, r.unit, r.qty, r.price, lineTotal(r)].join("\t"))).join("\r\n");
      try { navigator.clipboard.writeText(txt).catch(() => { }); say("نُسخت " + S.rows.length + " سطر", "s"); } catch (e) { say("تعذّر النسخ", "e"); }
    }
    D.paste = function (snap) {
      S.rows = snap.rows.map(r => Object.assign({}, r)); S.parentId = snap.parentId || 0;
      if (!!snap.cust !== !!ty.cust) S.rows.forEach(r => {   // بيع ↔ شراء: السعر من مصدر الطرف الجديد (سعر البيع / التكلفة)
        const p = prodById(r.pid), u = p && unitByName(p, r.unit); if (!u) return;
        const c = costOf(p, u), k = CX.rate || 1; r.price = k === 1 ? c : r2(c / k); r.lastCost = r.price; r._bp = c; r._blc = c; r._cxp = r.price; r.dp = 0; r.disc = 0; });
      const s = (!!snap.cust === !!ty.cust) && supById(snap.supId); if (s) setSupplier(s, true);
      S.sel = S.rows.length ? 0 : -1; markDirty(); renderAll();
    };
    D.syncCols = function (h) { if (h) hidden = h; renderGrid(); updTotals(); if (CUST && CUST.draw) CUST.draw(); };

    /* ---------- الحفظ ---------- */
    let saving = false;
    function validate() {
      if (!S.rows.length) { say("لا توجد أصناف في الفاتورة", "w"); focusCell(-1, "name"); return false; }
      const bad = S.rows.findIndex(r => !(+r.qty > 0));
      if (bad >= 0) { say("الكمية غير صحيحة في السطر " + (bad + 1), "w"); focusCell(bad, "qty"); return false; }
      { const H = window.ANOUER_HOMO, miss = H ? H.missing(S.rows.map(r => ({ pid: r.pid, q2: r.x && r.x.hq2, q3: r.x && r.x.hq3 }))) : null;
        if (miss) { say("أدخل " + miss.label + " للصنف «" + (S.rows[miss.i].name || "") + "» (وحدات غير متجانسة) — السطر " + (miss.i + 1), "w"); focusCell(miss.i, "name"); return false; } }
      const neg = S.rows.findIndex(r => (+r.price || 0) < 0);
      if (neg >= 0) { say("السعر غير صحيح في السطر " + (neg + 1), "w"); focusCell(neg, "price"); return false; }
      if (!F("date").value) { say("أدخل التاريخ", "w"); F("date").focus(); return false; }
      if (S.credit && !S.supId) { say("التعامل الآجل يتطلب اختيار مورد", "w"); sn.focus(); return false; }
      /* «يجب إدخال أصل فاتورة المشتريات قبل إجراء أى مرتجعات» */
      if (type === "PurchaseReturn" && RETP().purOrig === true && !S.parentId && !String((F("ref") || {}).value || "").trim()) { say("يجب إدخال أصل فاتورة المشتريات (رقم المرجع) قبل حفظ المرتجع — أو افتح المرتجع من الفاتورة الأصلية", "w"); try { F("ref").focus(); } catch (e) { } return false; }
      /* «أقل مبلغ يتم قبول عليه عمل طلبية مبيعات» */
      if (type === "SupplyOrder" && +RETP().minOrder > 0) { const tt = totals(); if (tt && +tt.total < +RETP().minOrder - 1e-9) { say("أقل مبلغ لطلبية المبيعات " + fmt(+RETP().minOrder) + " — الطلبية الحالية " + fmt(tt.total), "w"); return false; } }
      /* المصروفات (نفس فحص DEXEF): المصروف ، القيمة ، طريقة التوزيع ، نوع المصروف ، جهة الصرف ، اختيار الأصناف */
      for (let i = 0; i < S.exps.length; i++) {
        const x = S.exps[i], go = k => { showExpTab(); setTimeout(() => { const el = $(`.pu-exps .pu-er[data-i="${i}"] [data-e="${k}"]`); if (el) el.focus(); }, 30); };
        const miss = (t2, k) => { say("المصروفات: «" + t2 + "» حقل إجباري في السطر " + (i + 1), "w"); go(k); return false; };
        if (!(x.name || "").trim()) return miss("المصروف", "name");
        if (!(+x.amt)) return miss("القيمة", "amt");
        if (x.pay !== "Customer" && !String(x.acct || "").trim()) return miss("جهة الصرف", "acct");
        if (x.all === false && !(x.items || []).length) return miss("اختيار الأصناف", "all");
      }
      const R = k => gr(type, k);
      if (ty.gla && !F("gla").value.trim()) { say("حساب الأستاذ حقل إجباري", "w"); F("gla").focus(); return false; }
      if (ty.side) {
        const tw = F("trWh").value;
        if (tw === "") { say("مخزن التحويل حقل إجباري", "w"); showSide("tr"); F("trWh").focus(); return false; }
        if (+tw === curWh()) { say("لا يمكن التحويل إلى نفس المخزن", "w"); showSide("tr"); F("trWh").focus(); return false; }
      }
      if (R("party") && !S.supId && !ty.store) { say("اسم ( العميل أو المورد ) حقل إجباري", "w"); sn.focus(); return false; }
      if (ty.lite && F("deal") && !F("deal").value.trim()) { say("التعامل حقل إجباري", "w"); F("deal").focus(); return false; }
      if (R("ref") && !F("ref").value.trim()) { say("رقم المرجع حقل إجباري", "w"); F("ref").focus(); return false; }
      if (R("due") && M("due") && !F("due").value) { say("تاريخ الإستحقاق حقل إجباري", "w"); F("due").focus(); return false; }
      if (R("tax") && M("vat") && !vatRate()) { say("الضريبة حقل إجباري", "w"); F("vat").focus(); return false; }
      if (R("notes") && !F("notes").value.trim()) { say("الملاحظات حقل إجباري", "w"); F("notes").focus(); return false; }
      if (R("desc") && !(D.desc || "").trim()) { say("الوصف حقل إجباري", "w"); descPop(root.querySelector('[data-a="desc"]')); return false; }
      { const s = supById(S.supId), t0 = totals();
        if (s && gt(type, "blockLimit") && s.lim > 0 && type === "Purchase" && s.bal + t0.rem > s.lim) { say("لا يمكن الحفظ: تجاوز حد الإئتمان للمورد (" + fmt(s.lim) + ")", "w"); return false; } }
      if (EXP_IN) {   // مخزون بصلاحية: لا يدخل المخزون بدون تاريخ صلاحية
        for (let i = 0; i < S.rows.length; i++) { const r = S.rows[i]; if (!isExpRow(r)) continue; const c = batchCheck(r);
          if (c && c.hard) { say("السطر " + (i + 1) + ": «" + r.name + "» مخزون بصلاحية — " + c.m, "w"); try { window.ANOUER_SOUND && ANOUER_SOUND("err"); } catch (e) { } select(i); batchPop(i); return false; } }
      }
      const t = totals();
      if (t.total < 0) { say("الخصم أكبر من إجمالي الفاتورة", "w"); F("dval").focus(); return false; }
      if (ty.pay && t.paid > 0 && F("ptype").value !== "cash" && !F("acct").value.trim()) { say("اسم الحساب حقل إجباري", "w"); F("acct").focus(); return false; }
      if (type === "PurchaseReturn" || ty.out || type === "Reserve") {
        // الكمية المطلوبة لكل صنف (مجمّعة على كل أسطره) مقابل رصيد المخزن المختار
        const need = {}; S.rows.forEach(r => { need[r.pid] = (need[r.pid] || 0) + ((+r.qty || 0) + (type === "PurchaseReturn" && r.x ? +r.x.bonus || 0 : 0)) * (r.factor || 1); });
        const over = S.rows.find(r => { const p = prodById(r.pid); return p && need[r.pid] > whQty(p.id) - (type === "Reserve" ? WHM().reserved(p.id, curWh()) : 0) + 1e-9; });
        if (over && !S._overOk) { ask((ty.out ? "الكمية المطلوبة من «" : "الكمية المرتجعة من «") + over.name + "» أكبر من رصيد المخزون .. هل تريد المتابعة ؟", () => { S._overOk = true; save(S._lastMode || "new"); }); return false; }
      }
      return true;
    }
    /* أسطر البونص المجانية (المشتريات ومرتجعها فقط) */
    function bonusLines() {
      if (type !== "Purchase" && type !== "PurchaseReturn") return [];
      return S.rows.filter(r => r.pid && r.x && +r.x.bonus > 0).map(r => ({ ProductId: r.pid, ProductUnitId: r.puid || 0, Qty: +r.x.bonus, Factor: r.factor || 1, Price: 0, Disc: 0, Tax: 0, SalePrice: 0, Notes: "بونص" }));
    }
    function payload() { const P0 = payload0(); return CX.rate === 1 || CX.code === "DZD" ? P0 : cxDzd(P0); }
    /* الحفظ بالدينار: أسعار/خصومات/ضرائب الأسطر والمدفوع ورأس المستند × سعر الصرف */
    function cxDzd(P) {
      const k = CX.rate;
      (P.Lines || []).forEach((l, i) => { const r = i < S.rows.length ? S.rows[i] : null, exact = r && r._bp != null && r._cxp != null && Math.abs((+r.price || 0) - r._cxp) < .0001;
        ["Disc", "Tax", "CostNet"].forEach(f => { if (+l[f]) l[f] = r2(l[f] * k); }); if (+l.Price) l.Price = exact ? r2(r._bp) : r2(l.Price * k); });
      ["Paid", "HeadDisc", "Extra", "Tax"].forEach(f => { if (+P[f]) P[f] = r2(P[f] * k); });
      P.Notes = [P.Notes || "", `العملة ${CX.code} × ${k}`].filter(Boolean).join(" | ").slice(0, 500);
      return P;
    }
    function payload0() {
      const t = totals();
      const meta = { cfx: window.__cfDoc ? __cfDoc.meta(root) : undefined, wht: window.__WHT ? __WHT.PUR.meta(root, { total: t.total * (CX.rate || 1), tax: t.tax * (CX.rate || 1) }) : undefined, itemCard: D.itemCard || undefined, mode: F("mode").value, wh: whName(), whId: curWh(), status: F("status").value, prefix: F("prefix").value, desc: D.desc || "", plv: ty.cust ? plv() : undefined, validTo: ty.cust && F("due").value ? F("due").value : undefined,
        cur: F("cur").value, rate: num(F("rate").value) || 1, vat: +F("vat").value, slice: +F("slice").value, sv: 2, dtype: F("dtype").value, dval: num(F("dval").value),
        exps: S.exps.filter(x => x.name || x.amt).map(expN), credit: S.credit,
        gla: ty.gla ? F("gla").value.trim() : undefined, deal: ty.lite && F("deal") ? F("deal").value.trim() : undefined, trWh: ty.side ? WHM().nameOf(F("trWh").value) : undefined, toWhId: ty.side ? +F("trWh").value || 0 : undefined, trBr: ty.side ? +F("trBr").value || 0 : undefined,
        trBrName: ty.side ? ((F("trBr").selectedOptions[0] || {}).textContent || "") : undefined, lx: S.rows.some(r => r.x && Object.keys(r.x).length) ? S.rows.map(r => r.x || null) : undefined, idisc: S.rows.some(r => Math.abs(lineDisc(r) - r2(r.disc || 0)) > .004) ? S.rows.map(r => r2(r.disc || 0)) : undefined, bn: bonusLines().length ? S.rows.length : undefined, ptype: F("ptype").value, acct: F("ptype").value === "cash" ? "" : F("acct").value.trim() };
      const pt = PAYT.find(x => x.k === F("ptype").value) || PAYT[0];
      return {
        Id: S.id || 0, Type: type, No: F("no").value.trim(), Date: F("date").value, SupplierId: S.supId || 0,
        BranchId: +F("branch").value || 0, TreasuryId: ty.pay && pt.k === "cash" ? (+F("treas").value || 0) : 0, PayMethod: pt.m, PayAccount: pt.k === "cash" ? "" : (pt.t + ": " + F("acct").value.trim()), Credit: !!S.credit, Paid: t.paid,
        HeadDisc: r2(t.hd + (t.dat || 0)), Extra: t.extra, Tax: t.etax || 0, DueDate: M("due") ? F("due").value : "", RefNo: F("ref").value.trim(), Notes: F("notes").value.trim(),
        Meta: JSON.stringify(meta), ParentId: S.parentId || 0, WarehouseId: curWh(), ToWarehouseId: ty.side ? +F("trWh").value || 0 : 0,
        Lines: S.rows.map(r => ({ ProductId: r.pid, ProductUnitId: r.puid || 0, Qty: +r.qty || 0, Factor: r.factor || 1, Price: +r.price || 0,
          Disc: lineDisc(r), Tax: lineTax(r), CostNet: (() => { const c = rowNetCost(r); return Math.abs(c - lineTotal(r)) > .004 ? c : 0; })(), SalePrice: !ty.store && type === "Purchase" && gt(type, "track") && r.sale > 0 && r.sale !== r.sale0 ? +r.sale : 0, Notes: r.notes || "",
          Qty2: r.x && num(r.x.hq2) || 0, Qty3: r.x && num(r.x.hq3) || 0,
          UnitSales: !ty.store && type === "Purchase" && gt(type, "track") ? unitSales(r) : [],
          UnitBuys: !ty.store && type === "Purchase" && (+CX.rate || 1) === 1 ? unitBuys(r) : [] }))
          /* عمود «البونص» ← سطر مجاني (سعر صفر) بنفس الوحدة: يزيد المخزون (ويخفّض متوسط التكلفة) دون أن يغيّر قيمة الفاتورة */
          .concat(bonusLines()),
        /* مصروفات لا تُضاف على فاتورة المورد: نقدي (خزينة) / تتحمله الشركة / شركة وسيطة */
        Expenses: ty.store ? [] : S.exps.filter(x => !isInvExp(x) && expNet(x) > 0).map(x => ({ Kind: x.pay, TreasuryId: x.pay === "Cash" ? +x.acct || 0 : 0, SupplierId: x.pay === "OtherCustomer" ? +x.acct || 0 : 0,
          Account: x.pay === "Company" ? x.acct : x.pay === "Cash" ? ((META.treasuries.find(z => String(z.id) === x.acct) || {}).name || "") : ((SUPS.find(z => String(z.id) === x.acct) || {}).name || ""), Name: x.name, Amount: expNet(x) }))
      };
    }
    function save(mode) {
      if (saving) return;
      closePop();
      if (D.pend) commitPend(true);
      S._lastMode = mode;
      if (!validate()) return;
      if (S.id && !S._editOk) { askE(() => { S._editOk = true; save(mode); }); return; }
      const pl = payload(), t = totals();
      saving = true; root.classList.add("busy");
      const done = res => {
        saving = false; root.classList.remove("busy");
        const wasEdit = !!S.id;
        S.id = res.id; S.no = String(res.no); S.dirty = false; S._editOk = false; S._overOk = false;
        if (D.draftId) { DR.del(D.draftId).catch(() => { }); D.draftId = 0; D.draftManual = false; } clearTimeout(D._drT); D._drP = 0; paintDraft(null);   // المستند حُفظ فعلياً → حذف مسودته
rememberAcct();
        try { if (pl.SupplierId && (type === "Purchase" || type === "PurchaseReturn")) window.dispatchEvent(new CustomEvent("anouer:pur-saved", { detail: { type, title: ty.t, sup: pl.SupplierId } })); } catch (e) { }   /* الحارس الذكي لأعمار الديون */
        Object.keys(INFO).forEach(k => delete INFO[k]);
        F("no").value = S.no;
        // تحديث محلي فوري (الرصيد، التكلفة، سعر البيع) ثم إعادة التحميل من القاعدة
        localApply(pl);
        try { if (res && res.pq && res.pq.length && window.ANOUER_PQ) setTimeout(() => ANOUER_PQ.onPurchase(res), 350); } catch (e) { }   /* سعر البيع المؤجل حسب الدفعة (price-queue.js) */
        say((wasEdit ? "✔ تم تعديل " : "✔ تم حفظ ") + ty.t + " رقم " + res.no + (ty.pay && t.rem > 0 ? " — الباقي للمورد " + fmt(t.rem) : ""), "s");
        try { if (typeof SaveSound !== "undefined") SaveSound.play(); } catch (e) { }
        LISTS[type] = null;
        refreshData(false);
        if (mode === "print") { printDoc(); reset(); }
        else if (mode === "new") reset();
        else if (mode === "close") { reset(true); try { closeTab(key); } catch (e) { } }
        else updTitle();
      };
      const fail = err => { saving = false; root.classList.remove("busy");
        if ((ty.store || ty.cust) && /نوع مستند غير معروف|غير معروف/.test(err.message || "")) { say("مستندات المخازن تتطلب نسخة البرنامج الجديدة — شغّل build-exe.bat ثم أعد فتح البرنامج", "w"); return; }
        say("لم يتم الحفظ: " + err.message, "e"); try { alert("لم يتم حفظ " + ty.t + ":\n" + err.message); } catch (e) { } };
      if (B()) call("fm.pur.save", pl).then(done).catch(fail);
      else setTimeout(() => {   // وضع المعاينة: حفظ في الذاكرة
        let id = S.id, no = pl.No;
        if (!id) { LOCAL.seq[type]++; id = Date.now(); no = no || String(+(META.next[type] || 1)); META.next[type] = String(+no + 1); }
        LOCAL.docs = LOCAL.docs.filter(d => d.id !== id);
        const sup = supById(pl.SupplierId);
        LOCAL.docs.unshift({ id, type, no, date: pl.Date, time: new Date().toTimeString().slice(0, 8), supId: pl.SupplierId, sup: sup ? sup.name : "", cnt: pl.Lines.length,
          before: t.before, disc: t.disc, extra: t.extra, tax: t.tax, total: t.total, paid: t.paid, rem: t.rem, qty: t.q, doc: JSON.parse(JSON.stringify({ pl, rows: S.rows, exps: S.exps, desc: D.desc })) });
        done({ id, no });
      }, 120);
    }
    function localApply(pl) {
      const dir = type === "Purchase" ? 1 : type === "PurchaseReturn" ? -1 : ty.dir || 0;
      if (!dir) return;
      if (!B()) {
        pl.Lines.forEach(l => { const p = prodById(l.ProductId); if (!p) return; p.stock = r2((+p.stock || 0) + dir * l.Qty * l.Factor);
          if (dir > 0 && (type === "Purchase" || l.Price > 0)) { p.cost = r2((l.Qty * l.Price - l.Disc) / (l.Qty * l.Factor)); if (l.SalePrice) { const u = (p._u || []).find(x => x.puid === l.ProductUnitId); if (u) u.price = l.SalePrice; else p.price = l.SalePrice; } } });
        const s = supById(pl.SupplierId), t = totals(); if (s) s.bal = r2(s.bal + dir * t.rem);
      }
    }
    function refreshData(showMsg) {
      const jobs = [loadMeta(), loadSups(), WHM().load(true)];
      try { if (B() && window.__anouerLink && __anouerLink.loadProducts) jobs.push(__anouerLink.loadProducts()); } catch (e) { }
      try { if (window.ANOUER_SUPPLIERS && ANOUER_SUPPLIERS.reload) ANOUER_SUPPLIERS.reload(); } catch (e) { }
      return Promise.all(jobs.map(j => Promise.resolve(j).catch(() => { }))).then(() => {
        Object.values(DOCS).forEach(d => d.refreshMeta());
        if (S) { S.rows.forEach(r => { const p = prodById(r.pid); if (p) { const u = unitByName(p, r.unit); if (u) { r.lastCost = costOf(p, u); if (r.sale === r.sale0) { r.sale = +u.price || 0; r.sale0 = r.sale; } } } }); renderGrid(); updTotals(); renderSide(); }
        if (showMsg) say("تم تحديث البيانات", "s");
      });
    }

    /* ---------- فتح مستند محفوظ ---------- */
    function fill(h, lines) {
      S = blank();
      S.id = h.id; S.no = String(h.no); S.supId = h.supId || 0; S.parentId = h.parentId || 0;
      let m = {}; try { m = h.meta ? JSON.parse(h.meta) : {}; } catch (e) { }
      if (window.__cfDoc) __cfDoc.load(root, m.cfx);   // الحقول الإضافية
      if (window.__WHT) __WHT.PUR.load(root, m.wht);   // ضريبة الخصم والإضافة
      if (+m.bn > 0 && lines.length > +m.bn) lines = lines.slice(0, +m.bn);   /* أسطر البونص المجانية تُعرض في عمود «البونص» وليس كأسطر */
      F("no").value = h.no; F("date").value = h.date || today(); F("due").value = h.due || ""; F("ref").value = h.ref || ""; F("notes").value = h.notes || "";
      F("prefix").value = m.prefix || ""; D.desc = m.desc || "";
      if (m.mode && MODES.includes(m.mode)) { F("mode").value = m.mode; applySettings(); }
      F("vat").value = String(m.vat || 0); F("slice").value = String(m.sv >= 2 ? (m.slice || 0) : 0);   // مستندات قديمة: الشريحة كانت داخل خصم الصنف F("cur").value = m.cur || "DZD"; F("rate").value = m.rate || 1;
      F("dtype").value = m.dtype || "v"; F("dval").value = m.dtype ? (m.dval || "") : (h.disc - lines.reduce((s, l) => s + (+l.disc || 0), 0) || "");
      if (h.branchId) F("branch").value = String(h.branchId);
      if (h.treasId) F("treas").value = String(h.treasId);
      setPType(m.ptype || "cash", true); if (m.acct) F("acct").value = m.acct;
      if (m.status) F("status").value = m.status;
      if (ty.cust && m.plv && F("plv")) F("plv").value = String(m.plv);
      { const wid = h.whId || m.whId || (m.wh ? WHM().byName(m.wh) : 0); D.whId = wid; F("wh").value = String(wid); if (F("wh").value !== String(wid)) { refreshMeta(); F("wh").value = String(wid); } }
      if (ty.gla && m.gla) glaSet(m.gla);
      if (ty.lite && F("deal")) F("deal").value = m.deal != null ? m.deal : (ty.deal || "");
      if (ty.side) { if (m.trBr) F("trBr").value = String(m.trBr); const tid = h.toWhId || m.toWhId || (m.trWh ? WHM().byName(m.trWh) : 0); D.toWhId = tid; if (tid) F("trWh").value = String(tid); }
      S.exps = (m.exps || []).map(expN);
      S.rows = lines.map(l => {
        const p = prodById(l.pid), u = p && unitByName(p, l.unit);
        return { pid: l.pid, code: l.code || (p && p.code) || "", name: l.name || (p && p.name) || "", unit: l.unit, puid: l.puid, factor: +l.factor || 1, qty: +l.qty, price: +l.price,
          lastCost: p && u ? costOf(p, u) : +l.price, sale: +l.sale || (u ? +u.price : 0), sale0: u ? +u.price : +l.sale || 0, tax: (+l.tax || 0) > 0,
          disc: +l.disc || 0, dp: lineGrossOf(l) ? r2((+l.disc || 0) / lineGrossOf(l) * 100) : 0, notes: l.notes || "" };
      });
      if (Array.isArray(m.lx)) S.rows.forEach((r, i) => { if (m.lx[i]) r.x = m.lx[i]; });
      if (Array.isArray(m.idisc)) S.rows.forEach((r, i) => { if (m.idisc[i] != null) { r.disc = +m.idisc[i] || 0; const g = lineGross(r); r.dp = g ? r2(r.disc / g * 100) : 0; } });
      { const rx = S.rows.reduce((s, r) => s + rowExtra(r), 0); if (!S.exps.length && h.extra - rx > .005) S.exps = [expN({ name: "مصروفات", amt: r2(h.extra - rx) })]; }
      D.itemCard = m.itemCard || 0;
      if (S.rows.some(r => r.x && r.x.expDate)) showExpCols(S.rows.some(r => r.x && r.x.lot));
      const s = supById(S.supId);
      F("supName").value = s ? s.name : (h.sup || ""); F("supCode").value = s ? s.code : "";
      S.credit = ty.pay ? (m.credit != null ? !!m.credit : (h.total - h.paid) > .001) : false;
      setCredit(S.credit, true);
      if (S.credit) F("paid").value = fmt(h.paid);
      S.sel = S.rows.length ? 0 : -1; S.dirty = false;
      renderAll(); refreshMeta();
    }
    const lineGrossOf = l => (+l.qty || 0) * (+l.price || 0);
    D.open = function (id) {
      if (B()) return call("fm.pur.get", { id }).then(h => { fill(h, h.lines || []); return h; }).catch(e => { say("تعذّر فتح المستند: " + e.message, "e"); });
      const d = LOCAL.docs.find(x => x.id === id); if (!d) return Promise.resolve();
      const pl = d.doc.pl;
      fill({ id: d.id, no: d.no, date: d.date, supId: d.supId, sup: d.sup, meta: pl.Meta, total: d.total, paid: d.paid, disc: d.disc, extra: d.extra, notes: pl.Notes, ref: pl.RefNo, due: pl.DueDate, branchId: pl.BranchId, treasId: pl.TreasuryId },
        d.doc.rows.map(r => ({ pid: r.pid, code: r.code, name: r.name, unit: r.unit, puid: r.puid, factor: r.factor, qty: r.qty, price: r.price, disc: r.disc, tax: r.tax ? 1 : 0, sale: r.sale, notes: r.notes })));
      return Promise.resolve();
    };
    function list() {
      if (LISTS[type]) return Promise.resolve(LISTS[type]);
      if (!B()) return Promise.resolve(LOCAL.docs.filter(d => d.type === type));
      return call("fm.pur.list", { type, from: "2000-01-01", to: today() }).then(l => (LISTS[type] = l || []));
    }
    function nav(d) {
      const go = () => list().then(l => {
        if (!l.length) { say("لا توجد مستندات محفوظة", "i"); return; }
        const sorted = l.slice().sort((a, b) => (+a.no || 0) - (+b.no || 0));
        let i = S.id ? sorted.findIndex(x => x.id === S.id) : sorted.length;
        i += d;
        if (i < 0) { say("هذا أول مستند", "i"); return; }
        if (i >= sorted.length) { if (S.id) { reset(); say("مستند جديد", "i"); } else say("هذا آخر مستند", "i"); return; }
        D.open(sorted[i].id);
      });
      if (S.dirty && S.rows.length) ask("يوجد تعديلات لم تُحفظ .. هل تريد الانتقال ؟", go); else go();
    }
    function openByNo(no) {
      list().then(l => {
        const x = l.find(r => String(r.no) === String(no));
        if (!x) return;      // رقم جديد يدوي
        const go = () => D.open(x.id);
        if (S.dirty && S.rows.length) ask("يوجد تعديلات لم تُحفظ .. هل تريد فتح المستند رقم " + no + " ؟", go); else go();
      });
    }
    function findDialog() {
      const el = openPop(root.querySelector('[data-a="find"]'), `<div class="pu-find"><div class="hd">بحث عن ${esc(ty.t)}</div><input class="fq" placeholder="الرقم أو اسم المورد" autocomplete="off"><div class="fl"></div></div>`, "pu-findpop", { alignLeft: false });
      const q = el.querySelector(".fq"), fl = el.querySelector(".fl");
      let rows = [], ix = 0;
      const draw = () => {
        const v = norm(q.value);
        list().then(l => {
          rows = l.filter(x => !v || String(x.no).includes(v) || norm(x.sup).includes(v)).slice(0, 60);
          ix = Math.min(ix, Math.max(0, rows.length - 1));
          fl.innerHTML = rows.length ? rows.map((x, i) => `<div class="fr${i === ix ? " on" : ""}" data-i="${i}"><b>${esc(x.no)}</b><span>${esc(x.date)}</span><span>${esc(x.sup || "تعامل نقدي")}</span><i>${fmt(x.total)}</i></div>`).join("") : '<div class="pq-empty">لا توجد نتائج</div>';
        });
      };
      el.addEventListener("click", e => { const r = e.target.closest(".fr"); if (r) { ix = +r.dataset.i; pick(); } });
      const pick = () => { const x = rows[ix]; if (!x) return; closePop(); const go = () => D.open(x.id); if (S.dirty && S.rows.length) ask("يوجد تعديلات لم تُحفظ .. هل تريد فتح المستند ؟", go); else go(); };
      q.addEventListener("input", () => { ix = 0; draw(); });
      POP.key = e => { if (e.key === "ArrowDown") { ix = Math.min(rows.length - 1, ix + 1); draw(); } else if (e.key === "ArrowUp") { ix = Math.max(0, ix - 1); draw(); } else if (e.key === "Enter") pick(); else if (e.key === "Escape") closePop(); else return false; return true; };
      draw(); setTimeout(() => q.focus(), 0);
    }
    function loadFromDialog() {
      // تحميل الفاتورة: جلب أصناف مستند آخر (طلبية → فاتورة، فاتورة → مرتجع)
      const src = type === "PurchaseReturn" ? "Purchase" : type === "Purchase" ? "PurchaseOrder" : "Purchase";
      const b = root.querySelector('[data-a="loadinv"]');
      const el = openPop(b, `<div class="pu-find"><div class="hd">تحميل من ${esc(TY[src].t)}</div><div class="srcs">${Object.keys(TY).filter(k => k !== "PurchaseOrder" || type !== "PurchaseOrder").map(k => `<label><input type="radio" name="src${key}" value="${k}"${k === src ? " checked" : ""}> ${TY[k].t}</label>`).join("")}</div><input class="fq" placeholder="الرقم أو اسم المورد" autocomplete="off"><div class="fl"></div></div>`, "pu-findpop");
      let cur = src, rows = [], ix = 0;
      const q = el.querySelector(".fq"), fl = el.querySelector(".fl");
      const lst = k => LISTS[k] ? Promise.resolve(LISTS[k]) : B() ? call("fm.pur.list", { type: k, from: "2000-01-01", to: today() }).then(l => (LISTS[k] = l || [])) : Promise.resolve(LOCAL.docs.filter(d => d.type === k));
      const draw = () => lst(cur).then(l => {
        const v = norm(q.value);
        rows = l.filter(x => !v || String(x.no).includes(v) || norm(x.sup).includes(v)).slice(0, 60);
        ix = Math.min(ix, Math.max(0, rows.length - 1));
        fl.innerHTML = rows.length ? rows.map((x, i) => `<div class="fr${i === ix ? " on" : ""}" data-i="${i}"><b>${esc(x.no)}</b><span>${esc(x.date)}</span><span>${esc(x.sup || "تعامل نقدي")}</span><i>${fmt(x.total)}</i></div>`).join("") : '<div class="pq-empty">لا توجد مستندات</div>';
      });
      el.addEventListener("change", e => { if (e.target.type === "radio") { cur = e.target.value; ix = 0; draw(); } });
      el.addEventListener("click", e => { const r = e.target.closest(".fr"); if (r) { ix = +r.dataset.i; pick(); } });
      q.addEventListener("input", () => { ix = 0; draw(); });
      const pick = () => {
        const x = rows[ix]; if (!x) return; closePop();
        const apply = (h, lines) => {
          const add = lines.map(l => { const p = prodById(l.pid); const u = p && unitByName(p, l.unit);
            return { pid: l.pid, code: l.code || (p && p.code) || "", name: l.name || (p && p.name) || "", unit: l.unit, puid: l.puid, factor: +l.factor || 1, qty: +l.qty, price: +l.price,
              lastCost: p && u ? costOf(p, u) : +l.price, sale: u ? +u.price : +l.sale || 0, sale0: u ? +u.price : +l.sale || 0, tax: (+l.tax || 0) > 0, disc: +l.disc || 0, dp: lineGrossOf(l) ? r2((+l.disc || 0) / lineGrossOf(l) * 100) : 0, notes: "" }; });
          S.rows = S.rows.concat(add);
          if (!S.supId && h.supId) { const s = supById(h.supId); if (s) setSupplier(s, true); }
          if (type === "PurchaseReturn" && cur === "Purchase") { S.parentId = h.id; if (!F("ref").value) F("ref").value = h.no; }
          if (cur === "PurchaseOrder" && !F("ref").value) F("ref").value = "طلبية " + h.no;
          S.sel = S.rows.length - add.length; markDirty(); renderAll();
          say("تم تحميل " + add.length + " صنف من " + TY[cur].t + " رقم " + h.no, "s");
        };
        if (B()) call("fm.pur.get", { id: x.id }).then(h => apply(h, h.lines || [])).catch(e => say(e.message, "e"));
        else { const d = LOCAL.docs.find(z => z.id === x.id); if (d) apply({ id: d.id, no: d.no, supId: d.supId }, d.doc.rows.map(r => ({ pid: r.pid, code: r.code, name: r.name, unit: r.unit, puid: r.puid, factor: r.factor, qty: r.qty, price: r.price, disc: r.disc, tax: r.tax ? 1 : 0, sale: r.sale }))); }
      };
      POP.key = e => { if (e.key === "ArrowDown") { ix = Math.min(rows.length - 1, ix + 1); draw(); } else if (e.key === "ArrowUp") { ix = Math.max(0, ix - 1); draw(); } else if (e.key === "Enter") pick(); else if (e.key === "Escape") closePop(); else return false; return true; };
      draw(); setTimeout(() => q.focus(), 0);
    }
    function delDoc() {
      if (!S.id) {
        if (!S.rows.length) { say("لا يوجد ما يُحذف", "i"); return; }
        ask("هل تريد مسح كل أصناف الفاتورة ؟", () => reset()); return;
      }
      ask("هل تريد حذف " + ty.t + " رقم " + S.no + " ؟ سيتم عكس أثرها على المخزون ورصيد المورد والخزينة", () => {
        const after = () => { LISTS[type] = null; say("تم حذف " + ty.t + " رقم " + S.no, "s"); try { if (typeof DelSound !== "undefined") DelSound.play(); } catch (e) { } reset(); refreshData(false); refreshReviews(); };
        if (B()) call("fm.pur.delete", { id: S.id }).then(after).catch(e => say("لم يتم الحذف: " + e.message, "e"));
        else { LOCAL.docs = LOCAL.docs.filter(d => d.id !== S.id); after(); }
      });
    }

    /* ---------- الطباعة ---------- */
    function printDoc(preview) {
      const t = totals(), s = supById(S.supId);
      /* «تصميم التقارير»: الطباعة بالتصميم الافتراضي للتعامل (مشتريات / مرتجع مشتريات …) */
      if (window.ANOUER_RD && !window.__rdOff) {
        const nm = ty.t || "", tx = /مرتجع/.test(nm) ? "مرتجع مشتريات" : /أمر/.test(nm) ? "أمر شراء" : /طلبي/.test(nm) ? "طلبية مشتريات" : /عرض|عروض/.test(nm) ? "استلام عروض اسعار" : /استلام|إذن/.test(nm) ? "إذن استلام" : "مشتريات";
        const items = S.rows.filter(r => r.name).map(r => ({ "Item Code": r.code || "", Barcode: r.code || "", "Item Name": r.name, Unite: r.unit || "", Qty: +r.qty || 0, Price: +r.price || 0, "Item Discount": +r.disc || 0, "Net Price": +r.price || 0, Total: lineTotal(r), Description: r.desc || "" }));
        const hd = { Number: (F("prefix").value || "") + (S.no || F("no").value || META.next[type] || ""), Transaction: nm, Date: F("date").value, Time: "", "Customer Name": s ? s.name : "تعامل نقدي", "Customer Code": s ? (s.code || "") : "", "Customer Phone": s ? (s.phone || "") : "", "Customer Address": s ? (s.address || "") : "",
          WrittenBy: ANOUER_RD.userName(), Branch: (META.branches.find(b => b.id == F("branch").value) || {}).name || "", Store: whName(), "Payment Method": S.credit ? "أجل" : "كاش", Reference: F("ref").value || "", Notes: F("notes").value || "",
          "Before Discount": t.before, Discount: t.disc || 0, Extra: t.extra || 0, Taxes: t.tax || 0, "Net Amount": t.total, Paid: t.paid || 0, Remain: t.rem || 0, "Previous Balance": s ? (+s.bal || 0) - (t.rem || 0) : 0, "Current Balance": s ? (+s.bal || 0) : 0 };
        items.forEach((r, i) => { r.Index = i + 1; });
        hd["Item Count"] = items.length; hd["Qty Total"] = t.q || 0; hd["Amount In Words"] = ANOUER_RD.tafqit(t.total, ANOUER_RD.currencyName());
        ANOUER_RD.printTx({ tx, data: { header: hd, items }, mode: preview ? "preview" : "direct", title: nm + " " + hd.Number }).catch(e => say("تعذّرت الطباعة: " + ((e && e.message) || e), "e"));
        return;
      }
      const paper = (root.querySelector('[data-f="paper"]') || {}).value || "A4";
      const withSale = !!(root.querySelector('[data-f="pSale"]') || {}).checked, withBal = !!(root.querySelector('[data-f="pBal"]') || {}).checked;
      let co = "ANOUER"; try { co = (window.__companyName || document.querySelector(".stbar,.sb")?.textContent.match(/ANOUER[^\s]*/)?.[0]) || "ANOUER"; } catch (e) { }
      const w = window.open("", "_blank");
      if (!w) { say("تعذّر فتح نافذة الطباعة", "w"); return; }
      const narrow = paper === "80";
      w.document.write(`<html dir="rtl"><head><meta charset="utf-8"><title>${esc(ty.t)} ${esc(S.no || "")}</title><style>
        @page{size:${narrow ? "80mm auto" : paper};margin:${narrow ? "3mm" : "12mm"}}body{font-family:Tahoma,Arial;font-size:${narrow ? 11 : 12.5}px;color:#111;margin:0}
        .h{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid ${ty.c};padding-bottom:8px;margin-bottom:10px}
        .h h1{margin:0;font-size:${narrow ? 16 : 22}px;color:${ty.c}}.h .co{font-weight:700;font-size:${narrow ? 13 : 16}px}
        .meta{display:grid;grid-template-columns:${narrow ? "1fr" : "1fr 1fr"};gap:3px 20px;margin-bottom:10px}.meta div span{color:#555}
        table{width:100%;border-collapse:collapse}th,td{border:1px solid #bbb;padding:${narrow ? "2px 3px" : "5px 6px"};text-align:center}th{background:#eef3fb}td.n{text-align:right}
        .tot{margin-top:10px;margin-right:auto;width:${narrow ? "100%" : "45%"};border-collapse:collapse}.tot td{text-align:right}.tot td:last-child{text-align:left;font-weight:700}
        .tot tr.g td{background:${ty.c};color:#fff;font-size:15px}.ft{margin-top:24px;display:flex;justify-content:space-between;color:#444}
      </style></head><body>
      <div class="h"><div><div class="co">${esc(co)}</div><div>${esc((META.branches.find(b => b.id == F("branch").value) || {}).name || "")}</div></div><h1>${esc(ty.t)}</h1><div style="text-align:left">رقم: <b>${esc(F("prefix").value)}${esc(S.no || F("no").value || META.next[type])}</b><br>التاريخ: ${esc(F("date").value)}</div></div>
      <div class="meta"><div><span>${WHO}: </span><b>${esc(s ? s.name : "تعامل نقدي")}</b></div>${ty.cust ? `<div><span>الحالة: </span>${esc((F("status").selectedOptions[0] || {}).textContent || "")}</div>${F("due").value ? `<div><span>${type === "Quotation" ? "صالح حتى" : "تاريخ التوريد"}: </span>${esc(F("due").value)}</div>` : ""}` : `<div><span>التعامل: </span>${S.credit ? "أجل" : "كاش"}</div>`}
        ${F("ref").value ? `<div><span>رقم المرجع: </span>${esc(F("ref").value)}</div>` : ""}${F("due").value ? `<div><span>تاريخ الاستحقاق: </span>${esc(F("due").value)}</div>` : ""}
        <div><span>المخزن: </span>${esc(whName())}</div>${D.desc ? `<div style="grid-column:1/-1"><span>الوصف: </span>${esc(D.desc)}</div>` : ""}</div>
      <table><tr><th>#</th>${narrow ? "" : "<th>الكود</th>"}<th>الصنف</th><th>الوحدة</th><th>الكمية</th><th>السعر</th>${S.rows.some(r => r.disc) ? "<th>الخصم</th>" : ""}${withSale ? "<th>سعر البيع</th>" : ""}<th>الاجمالي</th></tr>
      ${S.rows.map((r, i) => `<tr><td>${i + 1}</td>${narrow ? "" : `<td>${esc(r.code)}</td>`}<td class="n">${esc(r.name)}</td><td>${esc(r.unit)}</td><td>${fmt(r.qty)}</td><td>${fmt(r.price)}</td>${S.rows.some(x => x.disc) ? `<td>${fmt(r.disc)}</td>` : ""}${withSale ? `<td>${fmt(r.sale)}</td>` : ""}<td>${fmt(lineTotal(r))}</td></tr>`).join("")}</table>
      ${S.exps.length ? `<table style="margin-top:8px"><tr><th>المصروفات</th><th>المبلغ</th></tr>${S.exps.map(x => `<tr><td class="n">${esc(x.name)}</td><td>${fmt(x.amt)}</td></tr>`).join("")}</table>` : ""}
      <table class="tot"><tr><td>الاجمالى</td><td>${fmt(t.before)}</td></tr>${t.disc ? `<tr><td>الخصم</td><td>${fmt(t.disc)}</td></tr>` : ""}${t.extra ? `<tr><td>الاضافى</td><td>${fmt(t.extra)}</td></tr>` : ""}${t.tax ? `<tr><td>الضرائب</td><td>${fmt(t.tax)}</td></tr>` : ""}
        <tr class="g"><td>الصافي</td><td>${fmt(t.total)} ${esc(F("cur").value)}</td></tr>${ty.pay ? `<tr><td>المدفوع</td><td>${fmt(t.paid)}</td></tr><tr><td>الباقى</td><td>${fmt(t.rem)}</td></tr>` : ""}
        ${withBal && s ? `<tr><td>رصيد ${WHO}</td><td>${fmt(s.bal)}</td></tr>` : ""}</table>
      ${F("notes").value ? `<p>ملاحظات: ${esc(F("notes").value)}</p>` : ""}
      <div class="ft"><span>توقيع المستلم: ..................</span><span>عدد الأصناف: ${S.rows.length} — الكميات: ${fmt(t.q)}</span></div>
      </body></html>`);
      w.document.close(); w.focus();
      if (!preview) setTimeout(() => { try { w.print(); } catch (e) { } }, 250);
    }

    /* ---------- إكسيل ---------- */
    function exportXls() {
      if (!S.rows.length) { say("لا توجد أصناف للتصدير", "w"); return; }
      const head = ["الكود", "اسم الصنف", "الوحدة", "الكمية", "السعر", "الخصم", "سعر البيع", "الاجمالي"];
      const data = S.rows.map(r => [r.code, r.name, r.unit, +r.qty, +r.price, r2(r.disc || 0), +r.sale || 0, lineTotal(r)]);
      const name = ty.t + " " + (S.no || F("no").value || "جديدة");
      if (window.XLSX) {
        const ws = XLSX.utils.aoa_to_sheet([head].concat(data)); ws["!cols"] = [{ wch: 16 }, { wch: 40 }, { wch: 14 }, { wch: 9 }, { wch: 11 }, { wch: 9 }, { wch: 11 }, { wch: 12 }];
        const wb = XLSX.utils.book_new(); wb.Workbook = { Views: [{ RTL: true }] }; XLSX.utils.book_append_sheet(wb, ws, "الأصناف");
        XLSX.writeFile(wb, name + ".xlsx");
      } else {
        const q = v => { v = String(v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
        const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["﻿" + [head].concat(data).map(r => r.map(q).join(",")).join("\r\n")], { type: "text/csv" })); a.download = name + ".csv"; document.body.appendChild(a); a.click(); setTimeout(() => a.remove(), 300);
      }
      say("تم تصدير " + S.rows.length + " صنف", "s");
    }
    function ensureXlsx() {
      if (window.XLSX) return Promise.resolve();
      return new Promise((ok, no) => { const s = document.createElement("script"); s.src = "/assets/js/vendor/xlsx.full.min.js"; s.onload = ok; s.onerror = () => no(new Error("تعذّر تحميل مكتبة إكسيل")); document.head.appendChild(s); });
    }
    function importXls() {
      const inp = document.createElement("input"); inp.type = "file"; inp.accept = ".xlsx,.xls,.csv";
      inp.onchange = () => {
        const f = inp.files && inp.files[0]; if (!f) return;
        ensureXlsx().then(() => f.arrayBuffer()).then(buf => {
          const wb = XLSX.read(buf, { type: "array" }), ws = wb.Sheets[wb.SheetNames[0]];
          const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" });
          if (!aoa.length) { say("الملف فارغ", "w"); return; }
          const H = aoa[0].map(h => norm(h));
          const find = keys => H.findIndex(h => keys.some(k => h.includes(k)));
          let cCode = find(["كود", "code", "باركود", "barcode"]), cName = find(["اسم", "صنف", "name", "designation"]), cQty = find(["كمي", "qty", "quant"]), cPrice = find(["سعر الشراء", "السعر", "price", "prix", "cout", "تكلف"]), cUnit = find(["وحد", "unit"]), cSale = find(["سعر البيع", "sale", "vente"]);
          if (cSale === cPrice) cSale = -1;
          let start = 1; if (cCode < 0 && cName < 0) { cCode = 0; cName = 1; cQty = 2; cPrice = 3; start = 0; }
          let ok = 0, miss = [];
          aoa.slice(start).forEach(row => {
            const code = String(row[cCode] == null ? "" : row[cCode]).trim(), name = cName >= 0 ? String(row[cName] || "").trim() : "";
            if (!code && !name) return;
            let m = code ? exactCode(code) : null;
            if (!m && name) { const p = prods().find(x => norm(x.name) === norm(name)); if (p) m = { p, u: defUnit(p) }; }
            if (!m) { miss.push(code || name); return; }
            let u = m.u; if (cUnit >= 0 && row[cUnit]) { const uu = unitByName(m.p, String(row[cUnit]).trim()); if (uu) u = uu; }
            const r = rowFromProduct(m.p, u, cQty >= 0 ? num(row[cQty]) || 1 : 1);
            if (cPrice >= 0 && num(row[cPrice]) > 0) r.price = num(row[cPrice]);
            if (cSale >= 0 && num(row[cSale]) > 0) r.sale = num(row[cSale]);
            applyDp(r); S.rows.push(r); ok++;
          });
          S.sel = S.rows.length - 1; markDirty(); renderAll();
          say("تم استيراد " + ok + " سطر" + (miss.length ? " — غير موجود: " + miss.length + " (" + miss.slice(0, 3).join("، ") + (miss.length > 3 ? "…" : "") + ")" : ""), miss.length ? "w" : "s");
        }).catch(e => say("تعذّر قراءة الملف: " + e.message, "e"));
      };
      inp.click();
    }

    /* ---------- نوافذ الأصناف ---------- */
    function modal(title, body, onOk, okText) {
      const ov = document.createElement("div"); ov.className = "pu-ov";
      ov.innerHTML = `<div class="pu-dlg" role="dialog" aria-label="${esc(title)}"><div class="dh"><span>${esc(title)}</span><button type="button" class="dx" aria-label="إغلاق">✕</button></div><div class="db">${body}</div>
        <div class="df"><button type="button" class="pu-bt g" data-ok="1">${okText || "حفظ"}</button><button type="button" class="pu-bt b" data-x="1">إغلاق</button></div></div>`;
      document.body.appendChild(ov);
      const close = () => { ov.remove(); };
      ov.addEventListener("click", e => { if (e.target === ov || e.target.closest(".dx,[data-x]")) close(); else if (e.target.closest("[data-ok]")) { if (onOk(ov) !== false) close(); } });
      ov.addEventListener("keydown", e => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); } });
      setTimeout(() => { const f = ov.querySelector("input,select,textarea,button"); if (f) f.focus(); }, 0);
      return ov;
    }
    /* تعديل الأسعار — مطابق DEXEF: بيانات اساسية + اسعار البيع و الشراء لكل وحدة */
    function pricesDialog(i) {
      const r = S.rows[i], p = prodById(r.pid); if (!p) return;
      const us = unitsOf(p);
      const LV = [["buy", "سعر الشراء"], ["sale", "سعر البيع"], ["rp", "التجزئة"], ["pp", "عابر سبيل"], ["sp", "سعر استطلاع"], ["wp", "الجملة"], ["p5", "سعر 5ومافوق"]];
      // نسخة قابلة للتعديل لكل وحدة
      const E = {};
      us.forEach(u => { E[u.name] = { bc: String(u.bc || "").split(/\s+/)[0] || (u.base ? p.code || "" : ""), buy: u.name === r.unit ? r2(+r.price || costOf(p, u)) : costOf(p, u),
        sale: u.name === r.unit ? (+r.sale || +u.price || 0) : (+u.price || 0), rp: +u.rp || 0, pp: +u.pp || 0, sp: +u.sp || 0, wp: +u.wp || 0, p5: +u.p5 || 0,
        ds: !!u.def, dp: !!u.defBuy, dirty: false }; });
      let cur = r.unit && E[r.unit] ? r.unit : us[0].name;
      const ov = document.createElement("div"); ov.className = "pu-ov pu-prov";
      const inp = (k, req) => `<div class="pr-f"><button type="button" class="pr-dd" data-calc="${k}" tabindex="-1">▾</button><input data-k="${k}" inputmode="decimal" autocomplete="off">${req ? '<i class="req">*</i>' : '<i></i>'}</div>`;
      ov.innerHTML = `<div class="pu-prw" role="dialog" aria-label="تعديل الأسعار" tabindex="-1">
        <div class="pr-x"><button type="button" class="dx" data-x="1" aria-label="إغلاق">✕</button></div>
        <div class="pr-t">تعديل الأسعار</div>
        <div class="pr-b">
          <div class="pr-tabs"><div class="pr-tab o">بيانات<br>اساسية</div><div class="pr-tab b">اسعار<br>البيع و<br>الشراء</div></div>
          <div class="pr-body">
            <div class="pr-grp">
              <div class="pr-r"><span class="pl">الباركود</span><div class="pr-f"><i></i><input data-k="bc" class="bc" autocomplete="off"><i class="req">*</i></div></div>
              <div class="pr-r"><span class="pl">اسم الصنف</span><div class="pr-f wide"><button type="button" class="pr-dd" data-a="prod" tabindex="-1">⌵</button><input value="${esc(p.name)}" readonly class="nm"><i class="req">*</i></div></div>
              <div class="pr-r"><span class="pl">اسم الوحدة</span><div class="pr-f"><select data-k="unit">${us.map(u => `<option${u.name === cur ? " selected" : ""}>${esc(u.name)}</option>`).join("")}</select><i class="req">*</i></div></div>
              <div class="pr-r"><span class="pl">العملة</span><div class="pr-f"><select><option>DZD</option></select><i></i></div></div>
            </div>
            <div class="pr-grp lv">${LV.map(x => `<div class="pr-r"><span class="pl">${x[1]}</span>${inp(x[0])}</div>`).join("")}</div>
            <div class="pr-m"></div>
            <div class="pr-chk"><label><input type="checkbox" data-k="ds"> افتراض البيع</label><label><input type="checkbox" data-k="dp"> افتراض للشراء</label></div>
          </div>
        </div>
        <div class="pr-ft"><button type="button" class="pu-bt g" data-ok="1">حفظ</button><button type="button" class="pu-bt b" data-x="1">إغلاق</button></div></div>`;
      document.body.appendChild(ov);
      const box = ov.querySelector(".pu-prw"), Q = s => box.querySelector(s);
      const load = () => {
        const e = E[cur];
        Q('[data-k="bc"]').value = e.bc;
        LV.forEach(x => { Q(`[data-k="${x[0]}"]`).value = e[x[0]] ? r2(e[x[0]]) : "0"; });
        Q('[data-k="ds"]').checked = e.ds; Q('[data-k="dp"]').checked = e.dp;
        margin();
      };
      const margin = () => {
        const e = E[cur], m = Q(".pr-m"), u = unitByName(p, cur) || { factor: 1 };
        if (e.buy > 0 && e.sale > 0) { const pc = (e.sale - e.buy) / e.buy * 100; m.innerHTML = `هامش الربح: <b class="${pc < 0 ? "neg" : ""}">${fmt(pc)}%</b> — ربح الوحدة <b class="${pc < 0 ? "neg" : ""}">${fmt(e.sale - e.buy)}</b>${u.factor > 1 ? ` — القطعة: شراء ${fmt(e.buy / u.factor)} / بيع ${fmt(e.sale / u.factor)}` : ""}`; }
        else m.innerHTML = "";
      };
      const close = () => { ov.remove(); focusCell(i, "price"); };
      ov.addEventListener("input", e => {
        const t = e.target, k = t.dataset.k; if (!k || k === "unit") return;
        const x = E[cur]; x[k] = k === "bc" ? t.value : num(t.value); x.dirty = true;
        if (k === "buy" || k === "sale") margin();
      });
      ov.addEventListener("change", e => {
        const t = e.target, k = t.dataset.k;
        if (k === "unit") { cur = t.value; load(); }
        else if (k === "ds" || k === "dp") { if (t.checked) Object.values(E).forEach(x => { if (x[k]) { x[k] = false; x.dirty = true; } }); E[cur][k] = t.checked; E[cur].dirty = true; }
      });
      ov.addEventListener("focusin", e => { if (e.target.matches("input:not([readonly])") && e.target.select) try { e.target.select(); } catch (x) { } });
      ov.addEventListener("click", e => {
        if (e.target === ov) return;
        const b = e.target.closest("button"); if (!b) return;
        if (b.dataset.x) close();
        else if (b.dataset.calc) { const k = b.dataset.calc; calcPop(b.closest(".pr-f"), E[cur][k], v => { E[cur][k] = v; E[cur].dirty = true; Q(`[data-k="${k}"]`).value = v; margin(); }); }
        else if (b.dataset.a === "prod") say("لتعديل صنف آخر اختر سطره في الفاتورة ثم «تعديل أسعار الصنف»", "i");
        else if (b.dataset.ok) save();
      });
      box.addEventListener("keydown", e => {
        if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); if (POP) closePop(); else close(); }
        else if (e.key === "Enter" && e.target.matches("input,select")) {
          e.preventDefault(); e.stopPropagation();
          const fs = Array.from(box.querySelectorAll(".pr-body input:not([readonly]):not([type=checkbox]),.pr-body select[data-k]"));
          const k = fs.indexOf(e.target); if (k >= 0 && k < fs.length - 1) fs[k + 1].focus(); else save();
        } else if (e.key === "F2" || (e.ctrlKey && (e.key === "s" || e.code === "KeyS"))) { e.preventDefault(); e.stopPropagation(); save(); }
      });
      function save() {
        const ch = us.filter(u => E[u.name].dirty);
        if (!ch.length) { close(); return; }
        const bad = ch.find(u => !String(E[u.name].bc || "").trim() && u.bc);
        if (bad) { say("الباركود حقل إجباري (" + bad.name + ")", "w"); if (bad.name !== cur) { cur = bad.name; Q('[data-k="unit"]').value = cur; load(); } Q('[data-k="bc"]').focus(); return; }
        const dupBc = ch.map(u => String(E[u.name].bc || "").trim()).filter(Boolean).find((b, k, a) => a.indexOf(b) !== k);
        if (dupBc) { say("نفس الباركود لوحدتين: " + dupBc, "w"); return; }
        const apply = () => {
          // تحديث محلي: الصنف + سطر الفاتورة
          ch.forEach(u => { const x = E[u.name];
            u.bc = x.bc; u.price = x.sale; u.rp = x.rp; u.pp = x.pp; u.sp = x.sp; u.wp = x.wp; u.p5 = x.p5; u.def = x.ds; u.defBuy = x.dp;
            if (x.buy > 0) p.cost = r2(x.buy / (u.factor || 1)); });
          if (!p._u && ch.length) { const x = E[ch[0].name]; p.price = x.sale; }
          S.rows.forEach((row, j) => { if (row.pid !== p.id) return; const u = unitByName(p, row.unit); if (!u) return;
            row.lastCost = costOf(p, u); const x = E[u.name]; if (x && x.dirty) { if (x.buy > 0) row.price = r2(x.buy); row.sale = x.sale; row.sale0 = x.sale; row.sx = null; row.sxm = null; applyDp(row); } });
          markDirty(); renderGrid(); updTotals(); renderSide();
          say("تم حفظ أسعار «" + p.name + "»", "s");
          ov.remove(); focusCell(i, "qty");
        };
        if (!B()) { apply(); return; }
        const units = ch.filter(u => u.puid).map(u => { const x = E[u.name]; return { ProductUnitId: u.puid, Barcode: x.bc, Purchase: x.buy, Sale: x.sale, Retail: x.rp, Passer: x.pp, Survey: x.sp, Whole: x.wp, Price5: x.p5, DefSale: x.ds, DefPurchase: x.dp }; });
        if (!units.length) { apply(); return; }
        call("fm.prices.save", { productId: p.id, units }).then(apply).catch(e => say("لم يتم حفظ الأسعار: " + e.message, "e"));
      }
      load();
      setTimeout(() => { const b = Q('[data-k="bc"]'); b.focus(); b.select(); }, 0);
    }
    function barcodeDialog(i) {
      const r = S.rows[i], p = prodById(r.pid), u = unitByName(p, r.unit) || {};
      const code = String(u.bc || p.code || "").split(/\s+/)[0];
      modal("طباعة باركود الصنف", `<div class="pu-bcd"><div class="pv">${code128(code)}<div class="nm">${esc(p.name)}</div><div class="pr">${fmt(r.sale || u.price || p.price)} DZD</div></div>
        <label class="pu-f"><span class="lb">عدد الملصقات</span><span class="pu-in"><input class="cnt n" type="number" min="1" value="${Math.max(1, Math.round((+r.qty || 1) * (r.factor || 1)))}"></span></label>
        <label class="pu-chk"><input type="checkbox" class="wp" checked> طباعة السعر</label></div>`, ov => {
          const n = Math.min(500, Math.max(1, Math.round(num(ov.querySelector(".cnt").value)))), wp = ov.querySelector(".wp").checked;
          const w = window.open("", "_blank"); if (!w) { say("تعذّر فتح نافذة الطباعة", "w"); return false; }
          const one = `<div class="l">${code128(code)}<div class="nm">${esc(p.name)}</div>${wp ? `<div class="pr">${fmt(r.sale || u.price || p.price)} DZD</div>` : ""}</div>`;
          w.document.write(`<html dir="rtl"><head><meta charset="utf-8"><style>@page{size:50mm 30mm;margin:1mm}body{margin:0;font-family:Arial}.l{width:48mm;height:28mm;display:flex;flex-direction:column;align-items:center;justify-content:center;page-break-after:always;overflow:hidden}.l svg{width:44mm;height:12mm}.nm{font-size:9px;text-align:center;max-height:22px;overflow:hidden}.pr{font-weight:700;font-size:12px}</style></head><body>${Array(n).fill(one).join("")}</body></html>`);
          w.document.close(); setTimeout(() => { try { w.print(); } catch (e) { } }, 250);
        }, "طباعة");
    }
    /* إضافة سريعة → «تحديد الاصناف» (مطابق DEXEF): اختيار أصناف بمعايير متعددة ثم إضافتها للفاتورة دفعة واحدة */
    function quickAdd() {
      pickItemsDlg({ onClose: () => focusCell(-1, "name"), onPick: (l, done) => {
        const have = new Set(S.rows.map(r => r.pid)), add = l.filter(p => !have.has(p.id));
        if (!add.length) { say("كل الأصناف المطابقة (" + l.length + ") موجودة بالفاتورة", "i"); return false; }
        const doAdd = () => {
          add.forEach(p => { const r = rowFromProduct(p, defUnit(p), 1); applyDp(r); S.rows.push(r); });
          S.sel = S.rows.length - add.length; markDirty(); renderAll();
          say("تمت إضافة " + add.length + " صنف" + (l.length > add.length ? " (" + (l.length - add.length) + " موجود مسبقاً)" : ""), "s");
          done(); focusCell(S.sel, "qty");
        };
        if (add.length > 150) { ask("سيتم إضافة " + add.length + " صنف للفاتورة .. هل تريد المتابعة ؟", doAdd); return false; }
        doAdd(); return false;
      } });
    }
    function newSupplier() {
      if (ty.cust) {   // «إضافة عميل سريع» (quick-cust.js) ثم اختياره في المستند
        if (window.ANOUER_QCUST) ANOUER_QCUST.open(F("supName").value.trim(), name => { const c = PARTY().find(x => norm(x.name) === norm(name)); if (c) setSupplier(c); }, { only: 1 });
        else try { openTab("cust", "إضافة عميل", "cust"); } catch (e) { say("شاشة العملاء غير متاحة", "w"); }
        return;
      }
      /* «إضافة مورد سريع» (quick-cust.js وضع المورد): يُحفظ ثم يُختار في الفاتورة مباشرة */
      if (window.ANOUER_QCUST) {
        const sn = F("supName");
        ANOUER_QCUST.open(sn.value.trim(), (name, ex) => {
          ex = ex || {};
          const done = () => {
            const s = SUPS.find(x => (ex.id && x.id === ex.id)) || SUPS.find(x => norm(x.name) === norm(name));
            if (!s) { say("تمت إضافة المورد — اختره من القائمة", "i"); return; }
            setSupplier(s);
            if (ty.pay && !S.id && ex.terms) { const want = /^[أاآإ]جل$/.test(String(ex.terms).trim()); if (want !== !!S.credit) { setCredit(want, true); if (!!S.credit === want) dealFlash(root.querySelector(".pu-deal .ib"), want ? "أجل" : "كاش", want); } }
            setTimeout(() => focusCell(-1, "name"), 40);
          };
          if (!B()) { SUPS.push({ id: Date.now(), code: ex.code || "", name, bal: 0, ph: ex.ph || "", last: "", inv: 0, lim: 0, mail: "", addr: "", note: "", ph2: "", x: ex.x || {} }); done(); return; }
          loadSups().then(done, done);
        }, { sup: 1, list: SUPV(), input: sn });
        return;
      }
      if (window.ANOUER_SUPPLIERS && (ANOUER_SUPPLIERS.form || ANOUER_SUPPLIERS.add)) {
        D.awaitSup = true;
        (ANOUER_SUPPLIERS.form || ANOUER_SUPPLIERS.add)();
        say("بعد حفظ المورد سيظهر في القائمة", "i");
      } else { try { openTab("surev", "مراجعة الموردين", "surev"); } catch (e) { say("شاشة الموردين غير متاحة", "w"); } }
    }

    /* ---------- طريقة الدفع: النوع ⌵ (نقدي / تحويل بنكي / فيزا كارد / عهد الموظفين / حساب في الشجرة) ---------- */
    const ACCK = k => "pur.accts." + k;
    function setPType(k, silent) {
      const pt = PAYT.find(x => x.k === k) || PAYT[0];
      F("ptype").value = pt.k;
      const ic = root.querySelector(".pt-ic"); ic.innerHTML = pt.ic; ic.title = pt.t;
      const cash = pt.k === "cash", tr = F("treas"), ac = F("acct");
      tr.hidden = !cash; ac.hidden = cash;
      if (!cash) {
        const l = lsGet(ACCK(pt.k), pt.def ? [pt.def] : []);
        const dl = ac.nextElementSibling; if (dl) { if (!dl.id) { dl.id = "puAcct" + Math.random().toString(36).slice(2); ac.setAttribute("list", dl.id); } dl.innerHTML = l.map(x => `<option value="${esc(x)}">`).join(""); }
        if (!silent || !ac.value) ac.value = l[0] || "";
        ac.placeholder = pt.k === "custody" ? "اسم الموظف" : pt.k === "acct" ? "اسم الحساب في الشجرة" : pt.t;
      }
      root.classList.toggle("pay-noncash", !cash);
      if (!silent) { markDirty(); if (!cash && !ac.value) setTimeout(() => ac.focus(), 0); }
    }
    function ptypeMenu() {
      const cur = F("ptype").value;
      const anchor = root.querySelector(".pu-ptype");
      const el = openPop(anchor, `<div class="pu-ptl">${PAYT.map(x => `<div class="pt-o${x.k === cur ? " on" : ""}" data-k="${x.k}"><i>${x.ic}</i><span>${x.t}</span></div>`).join("")}<div class="pt-ft">⋰</div></div>`, "pu-ptpop");
      let ix = Math.max(0, PAYT.findIndex(x => x.k === cur));
      const hl = () => el.querySelectorAll(".pt-o").forEach((o, i) => o.classList.toggle("on", i === ix));
      el.addEventListener("mousedown", e => e.preventDefault());
      el.addEventListener("mousemove", e => { const o = e.target.closest(".pt-o"); if (o) { ix = PAYT.findIndex(x => x.k === o.dataset.k); hl(); } });
      el.addEventListener("click", e => { const o = e.target.closest(".pt-o"); if (!o) return; closePop(); setPType(o.dataset.k); updTotals(); });
      POP.key = e => { if (e.key === "ArrowDown") { ix = Math.min(PAYT.length - 1, ix + 1); hl(); } else if (e.key === "ArrowUp") { ix = Math.max(0, ix - 1); hl(); } else if (e.key === "Enter") { closePop(); setPType(PAYT[ix].k); } else if (e.key === "Escape") closePop(); else return false; return true; };
    }
    function rememberAcct() {
      const k = F("ptype").value; if (k === "cash") return;
      const v = F("acct").value.trim(); if (!v) return;
      const l = lsGet(ACCK(k), []).filter(x => x !== v); l.unshift(v); lsSet(ACCK(k), l.slice(0, 30));
    }

    /* ---------- شاشة الدفع (✓ بجانب المبلغ) — مطابقة DEXEF ---------- */
    function payDlg() {
      closePop();
      if (!ty.pay) return;
      const t = totals(), need = t.total;
      let txt = S.credit ? String(r2(t.paid)) : "0", fresh = true, trIx = Math.max(0, META.treasuries.findIndex(x => String(x.id) === F("treas").value));
      // مبالغ سريعة (كما DEXEF): المطلوب بالضبط ثم تقريبه للأعلى (50 / 100 / 500 / 1000 / 5000…) — المطلوب يساراً
      const quick = () => {
        if (!(need > 0)) return [0, 0, 0, 0];
        const l = [r2(need)];
        [50, 100, 500, 1000, 5000, 10000, 50000, 100000].forEach(m => { const v = Math.ceil(need / m) * m; if (v > need + .001 && !l.includes(v) && l.length < 4) l.push(v); });
        while (l.length < 4) l.push(l[l.length - 1] * 2);
        return l.reverse();
      };
      const ov = document.createElement("div"); ov.className = "pu-ov pu-payov";
      const K = k => `<button type="button" class="py-k" data-k="${k}">${k === "back" ? '<svg viewBox="0 0 22 14" width="22" height="14"><rect x="1" y="1" width="20" height="12" rx="1.5" fill="none" stroke="#222" stroke-width="1.6"/><path d="M14 7H7M10 4L7 7l3 3" fill="none" stroke="#222" stroke-width="1.6"/></svg>' : k}</button>`;
      ov.innerHTML = `<div class="pu-pay2" role="dialog" aria-label="الدفع" tabindex="-1">
        <div class="py-h"><div class="py-r"><span>المطلوب</span><b class="py-v py-need">${fmt(need)}</b></div><div class="py-r"><span>المدفوع</span><b class="py-v py-paid"></b></div><div class="py-r py-big"><span>الباقي</span><b class="py-v py-rem"></b></div></div>
        <div class="py-kp">${K("back")}<span></span>${K("C")}${K("9")}${K("8")}${K("7")}${K("6")}${K("5")}${K("4")}${K("3")}${K("2")}${K("1")}${K("00")}${K(".")}${K("0")}</div>
        <div class="py-tr"><button type="button" class="py-tn" data-a="tr" title="تغيير الحساب">${'<svg viewBox="0 0 26 18" width="26" height="18"><rect x="1" y="2" width="24" height="14" rx="2" fill="#5b6fd8"/><rect x="4" y="5" width="18" height="8" rx="1" fill="#e6ebff"/><circle cx="13" cy="9" r="2.6" fill="#5b6fd8"/></svg>'}<span></span></button><button type="button" class="py-ta" data-a="tr" title="الحساب التالي">${'<svg viewBox="0 0 24 24" width="24" height="24"><circle cx="12" cy="12" r="11" fill="#1d2a38"/><path d="M17 12H8M11.5 7.5L7 12l4.5 4.5" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'}</button></div>
        <div class="py-qk"></div>
        <div class="py-f"><button type="button" class="pu-bt g" data-a="ok">موافق</button><button type="button" class="pu-bt b" data-a="all">دفع الكل</button><button type="button" class="pu-bt b" data-a="cancel">الغاء</button></div></div>`;
      document.body.appendChild(ov);
      const box = ov.querySelector(".pu-pay2");
      const draw = () => {
        const paid = num(txt), rem = r2(need - paid);
        box.querySelector(".py-paid").textContent = fresh && !S.credit ? fmt(paid) : (txt || "0");
        const re = box.querySelector(".py-rem"); re.textContent = fmt(Math.abs(rem)); re.classList.toggle("py-pos", rem <= 0);
        box.querySelector(".py-big span").textContent = rem < 0 ? "الزيادة" : "الباقي";
        const tr = META.treasuries[trIx] || META.treasuries[0], pk = F("ptype").value;
        box.querySelector(".py-tn span").textContent = pk === "cash" ? (tr ? tr.name : "") : ((PAYT.find(x => x.k === pk) || {}).t + " — " + (F("acct").value || "…"));
        box.querySelector(".py-qk").innerHTML = quick().map(v => `<button type="button" class="py-q" data-q="${v}">${fmt(v)}</button>`).join("");
      };
      const close = () => { ov.remove(); F("paid").focus(); };
      const apply = v => {
        v = Math.max(0, r2(v));
        const tr = META.treasuries[trIx]; if (tr && F("ptype").value === "cash") F("treas").value = String(tr.id);
        if (v >= need - .001) { setCredit(false, true); }
        else {
          if (!S.supId) { say("الدفع الجزئي يتطلب اختيار مورد (تعامل أجل)", "w"); return false; }
          setCredit(true, true); F("paid").value = fmt(v); S.paidTouched = true;
        }
        if (v > need + .001) say("المبلغ أكبر من المطلوب — يُسجَّل المطلوب فقط (" + fmt(need) + ")", "i");
        markDirty(); updTotals(); return true;
      };
      const press = k => {
        if (k === "C") { txt = "0"; fresh = false; }
        else if (k === "back") { txt = fresh ? "0" : (txt.length > 1 ? txt.slice(0, -1) : "0"); fresh = false; }
        else if (k === ".") { if (fresh) { txt = "0."; fresh = false; } else if (!txt.includes(".")) txt += "."; }
        else { txt = (fresh || txt === "0") ? (k === "00" ? "0" : k) : txt + k; fresh = false; }
        draw();
      };
      box.addEventListener("mousedown", e => { if (e.target.closest("button")) e.preventDefault(); });
      ov.addEventListener("click", e => {
        if (e.target === ov) { close(); return; }
        const b = e.target.closest("button"); if (!b) return;
        if (b.dataset.k) press(b.dataset.k);
        else if (b.dataset.q != null) { txt = String(+b.dataset.q); fresh = false; draw(); }
        else if (b.dataset.a === "tr") { if (F("ptype").value !== "cash") { const i = PAYT.findIndex(x => x.k === F("ptype").value); setPType(PAYT[(i + 1) % PAYT.length].k); draw(); return; } if (META.treasuries.length > 1) { trIx = (trIx + 1) % META.treasuries.length; draw(); } else say("لا يوجد حساب آخر — الخزينة الرئيسية فقط", "i"); }
        else if (b.dataset.a === "ok") finish();
        else if (b.dataset.a === "all") payAllFill();
        else if (b.dataset.a === "cancel") close();
      });
      box.addEventListener("keydown", e => {
        const k = e.key;
        if (/^[0-9]$/.test(k)) press(k); else if (k === "." || k === ",") press(".");
        else if (k === "Backspace") press("back"); else if (k === "Delete") press("C");
        else if (k === "Enter") finish();
        else if (k === "Escape") close();
        else if (k === "F7" || k === "+") payAllFill();
        else return;
        e.preventDefault(); e.stopPropagation();
      });
      /* «دفع الكل» يملأ المطلوب ويبقي النافذة؛ «موافق» يسجّل الدفع ويحفظ المستند (حفظ و جديد) — مثل DEXEF */
      function payAllFill() { txt = String(r2(need)); fresh = false; draw(); const ok = box.querySelector('[data-a="ok"]'); if (ok) { ok.classList.remove("py-pulse"); void ok.offsetWidth; ok.classList.add("py-pulse"); } }
      function finish() { const v = fresh && !num(txt) && !S.supId ? need : num(txt); if (apply(v) === false) return; ov.remove(); setTimeout(() => { try { save("new"); } catch (e) { say("تعذّر الحفظ: " + (e.message || e), "e"); } }, 0); }
      draw(); setTimeout(() => box.focus(), 0);
      try { if (typeof QtySound !== "undefined") { box.addEventListener("click", e => { if (e.target.closest(".py-k")) QtySound.play(); }); } } catch (e) { }
    }

    /* ---------- الخصائص: نماذج الفواتير ---------- */
    function propsDialog() {
      closePop();
      const mode = F("mode").value;
      const IC2 = {
        fold: '<svg viewBox="0 0 16 16"><path d="M1 3.5h5l1.5 1.5H15v8.5H1z" fill="#f2a516"/><path d="M1 6h14v7.5H1z" fill="#f7c04a"/><path d="M8 7.5v4M6 9.5l2 2 2-2" stroke="#2e7d32" stroke-width="1.4" fill="none"/></svg>',
        doc: '<svg viewBox="0 0 16 16"><path d="M3 1h7l3 3v11H3z" fill="#fff" stroke="#5c6b80" stroke-width="1.2"/><path d="M10 1v3h3" fill="none" stroke="#5c6b80" stroke-width="1.2"/></svg>',
        ok: '<svg viewBox="0 0 16 16"><rect x="1" y="1" width="14" height="14" rx="2" fill="#2e9b4a"/><path d="M4 8.2l2.6 2.6L12 5.4" stroke="#fff" stroke-width="2" fill="none"/></svg>'
      };
      const sw = (on, attrs) => `<label class="sw"><input type="checkbox" ${attrs}${on ? " checked" : ""}><i></i><b>${on ? "نعم" : "لا"}</b></label>`;
      const row = (label, ctl) => `<div class="pg"><span class="pl">${label}</span><span class="pv">${ctl}</span></div>`;
      const mt = (k, label) => row(label, sw(gm(mode, k), `data-m="${k}"`));
      const sel = (attr, opts, v, icon) => `<span class="pu-in ps${icon ? " ic" : ""}">${icon ? `<i>${icon}</i>` : ""}<select ${attr}>${opts.map(o => `<option value="${esc(o[0])}"${String(o[0]) === String(v) ? " selected" : ""}>${esc(o[1])}</option>`).join("")}</select></span>`;
      const REQ = [["party", "اسم ( العميل أو المورد )"], ["addr", "عنوان المرسل اليه"], ["phone", "رقم تليفون المرسل"], ["rep", "اسم المندوب"], ["cc", "مركز التكلفة"], ["terms", "شروط الدفع"],
        ["due", "تاريخ الإستحقاق"], ["tax", "الضريبة"], ["dtax", "ضريبة الخصم و الإضافة"], ["ship", "طريقة الشحن"], ["f1", "حقل1"], ["f2", "حقل2"], ["f3", "حقل3"], ["f4", "حقل4"], ["f5", "حقل5"],
        ["ref", "رقم المرجع"], ["desc", "الوصف"], ["notes", "الملاحظات"]];
      const reqList = t => REQ.map(r => `<div class="rq"><span class="pl">${r[1]}</span><span class="ln"></span>${sw(gr(t, r[0]), `data-r="${r[0]}"`)}</div>`).join("");
      const col = gt(type, "color") || ty.c, rgb = c => { const n = parseInt(String(c).replace("#", ""), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255].join("; "); };
      const tsel = (k, opts) => sel(`data-t="${k}"`, opts, gt(type, k) === true ? "1" : gt(type, k) === false ? "0" : gt(type, k), IC2.ok);
      const yn = [["1", "نعم"], ["0", "لا"]];
      const kinds = Object.keys(TY).map(k => [k, TY[k].t]);
      const html = `<div class="pu-props">
        <div class="top"><div class="tl"><span>الاسم</span><span>الحالة</span></div>
          <div class="tv"><div class="nm"><span class="pu-in"><input data-n value="${esc(mode)}" readonly></span><i class="req">*</i></div><label class="pu-chk"><input type="checkbox" data-m="active"${gm(mode, "active") ? " checked" : ""}> نشط</label></div></div>
        <div class="ptabs"><button type="button" class="on" data-p="g">عام</button><button type="button" data-p="r">الحقول الإجبارية</button><button type="button" data-p="x">الخصائص</button></div>
        <div class="pp" data-p="g"><div class="pcols">
          <div class="pc">
            <div class="grp">${mt("totals", "اجماليات الفاتورة ؟")}${mt("currency", "العملات")}${mt("serial", "استخدام مسلسل ترقيم خاص")}
              ${row("طريقة الدفع الإفتراضية ؟", sel('data-m="payDefault"', [["cash", "كاش"], ["credit", "أجل"]], gm(mode, "payDefault"), I.coins))}</div>
            <h4>المحاسبة</h4><div class="grp">${mt("expenses", "هل يوجد لديك مصروفات على الفواتير ؟")}${mt("terms", "ظهور شروط الدفع (خصم تعجيل الدفع)")}${mt("due", "تاريخ الاستحقاق")}${mt("slices", "ظهور شرائح الخصم ( الخصم مركب ) ؟")}</div>
            <h4>الضرائب</h4><div class="grp">${mt("vat", "إستخدام ضريبة القيمة المضافة ؟")}${row("ضريبة القيمة المضافة الافتراضية", sel('data-m="vatDefault"', VAT.map(v => [v[1], v[1] ? v[0] : ""]), gm(mode, "vatDefault")))}
              ${mt("discTax", "إستخدام ضريبة الخصم و الإضافة ؟")}${row("ضريبة الخصم الافتراضية ؟", sel('data-m="discTaxDefault"', [["", ""]].concat((window.__WHT ? __WHT.defs() : []).map(d => [d.no, (d.name || "") + " " + (+d.pct) + "%"])), gm(mode, "discTaxDefault")))}</div>
          </div>
          <div class="pc l"><h4>أخرى</h4><div class="grp">${mt("extra", "الحقول الاضافية ؟")}${mt("reps", "نسب المناديب")}${mt("ship", "بيانات الشحن")}${mt("cc", "إستخدام مراكز التكلفة ؟")}</div></div>
        </div></div>
        <div class="pp" data-p="r" hidden>
          <div class="rqtop"><span class="pl">التعامل</span>${sel('data-rt', kinds, type)}</div>
          <div class="rql">${reqList(type)}</div>
        </div>
        <div class="pp" data-p="x" hidden>
          <h4>بيانات أساسية</h4>
          <div class="basic"><div class="bcol">
              ${row("الاسم", `<span class="pu-in ps"><input data-t="name" value="${esc(gt(type, "name") || ty.t)}"></span>`)}
              ${row("طبيعة التعامل", sel('data-t="kind"', kinds, gt(type, "kind") || type, IC2.fold))}
              ${row("له تأثير على الحسابات", tsel("affects", yn))}</div>
            <div class="bcol s">${row("النوع", sel('data-t="side"', [["cr", "دائن"], ["db", "مدين"]], gt(type, "side") || (type === "PurchaseReturn" ? "db" : "cr"), IC2.doc))}</div>
            <button type="button" class="pu-bt b psave" data-a="tsave">حفظ</button></div>
          <div class="stabs"><button type="button" class="on" data-s="g">عام</button><button type="button" data-s="v">طريقة العرض</button><button type="button" data-s="c">خصائص العميل</button><button type="button" data-s="t">الاجماليات</button></div>
          <div class="sp" data-s="g"><div class="pcols">
            <div class="pc"><h4>رصيد الأصناف</h4><div class="grp">
                ${row("يؤثر فى رصيد الصنف", tsel("stock", yn))}
                ${row("طريقة التأثير فى الرصيد", sel('data-t="dir"', [["in", "بالزيادة"], ["out", "بالنقص"], ["none", "بدون"]], type === "Purchase" ? "in" : type === "PurchaseReturn" ? "out" : "none", IC2.ok))}
                ${row("تتبع رصيد الأصناف لكل فاتورة ؟", tsel("trackInv", yn))}
                ${row("تتبع الاسعار؟", tsel("track", yn))}</div>
              <h4>بيانات الجداول</h4><div class="grp">
                ${row("الجدول الرئيسى", `<span class="pu-in ps"><input value="${type === "PurchaseReturn" ? "Purchase_Return" : type === "PurchaseOrder" ? "Purchase_Order" : "Purchase"}" readonly></span>`)}
                ${row("جدول الاصناف", `<span class="pu-in ps"><input value="${type === "PurchaseReturn" ? "Purchase_Return_Entry" : type === "PurchaseOrder" ? "Purchase_Order_Entry" : "Purchase_Entry"}" readonly></span>`)}
                ${row("جدول الدفع", sel('data-t="payTable"', [["p", TY[type].t]], "p"))}</div></div>
            <div class="pc l"><h4>اخرى</h4><div class="grp">
                ${row("نوع التعامل", sel('data-t="kind2"', kinds, type))}
                ${row("اللون", `<span class="pu-in ps ic pcol"><i class="sw2" style="background:${col}"></i><span class="cv">${rgb(col)}</span><input type="color" data-t="color" value="${col}"></span>`)}
                ${row("SerialMode", sel('data-t="serialMode"', [["IN", "IN"], ["OUT", "OUT"]], gt(type, "serialMode")))}
                ${row("BillTrans", sel('data-t="billTrans"', [["IN", "IN"], ["OUT", "OUT"]], gt(type, "billTrans")))}</div></div></div></div>
          <div class="sp" data-s="v" hidden><div class="grp cols2">${(() => { const vk = layKeys(); return COLS.filter(c => c.k !== "name").sort((a, b) => (vk.includes(b.k) - vk.includes(a.k)) || a.t.localeCompare(b.t, "ar")).map(c => row(c.t, sw(vk.includes(c.k), `data-col="${c.k}"`))).join(""); })()}</div><p class="hint">أعمدة الجدول في طريقة العرض «${esc(mode)}» — يمكنك أيضاً سحب رؤوس الأعمدة لإعادة ترتيبها وتغيير عرضها</p></div>
          <div class="sp" data-s="c" hidden><div class="grp">${row("إظهار رصيد المورد في الفاتورة", sw(gt(type, "showBal"), 'data-tb="showBal"'))}${row("التنبيه عند تجاوز حد الإئتمان", sw(gt(type, "limitWarn"), 'data-tb="limitWarn"'))}${row("منع الحفظ عند تجاوز حد الإئتمان", sw(gt(type, "blockLimit"), 'data-tb="blockLimit"'))}</div></div>
          <div class="sp" data-s="t" hidden><div class="grp">${[["tBefore", "الاجمالى"], ["tDisc", "الخصم"], ["tExtra", "الاضافى"], ["tTax", "الضرائب"], ["tPaid", "المدفوع"], ["tRem", "الباقى"]].map(x => row(x[1], sw(gt(type, x[0]), `data-tb="${x[0]}"`))).join("")}</div></div>
        </div></div>`;
      const collect = ov => {
        const v = {};
        ov.querySelectorAll("[data-m]").forEach(x => { const k = x.dataset.m; v["m." + mode + "." + k] = x.type === "checkbox" ? x.checked : (k === "vatDefault" ? +x.value : x.value); });
        const rt = ov.querySelector("[data-rt]").value;
        ov.querySelectorAll("[data-r]").forEach(x => { v["r." + rt + "." + x.dataset.r] = x.checked; });
        return v;
      };
      const collectT = ov => {
        const v = {};
        ov.querySelectorAll('[data-t]').forEach(x => { const k = x.dataset.t; if (["affects", "stock", "trackInv", "track", "linkSale"].includes(k)) v["t." + type + "." + k] = x.value === "1"; else if (["name", "kind", "side", "color", "serialMode", "billTrans"].includes(k)) v["t." + type + "." + k] = x.value; });
        ov.querySelectorAll("[data-tb]").forEach(x => { v["t." + type + "." + x.dataset.tb] = x.checked; });
        return v;
      };
      const ov = modal("نماذج الفواتير", html, ov => {
        saveSet(Object.assign(collect(ov), collectT(ov)));
        { const on = new Set(Array.from(ov.querySelectorAll("[data-col]")).filter(x => x.checked).map(x => x.dataset.col)); on.add("name");
          const cur = layKeys(), keys = cur.filter(k => on.has(k)).concat(Array.from(on).filter(k => !cur.includes(k)));
          if (keys.join() !== cur.join()) setLayout(keys); }
        say("تم حفظ نموذج «" + mode + "»", "s");
      });
      ov.querySelector(".pu-dlg").classList.add("props");
      ov.addEventListener("change", e => {
        const t = e.target, s = t.closest(".sw"); if (s) s.querySelector("b").textContent = t.checked ? "نعم" : "لا";
        if (t.matches("[data-rt]")) { const v = {}; ov.querySelectorAll("[data-r]").forEach(x => { v[x.dataset.r] = x.checked; });
          ov.dataset.rtPrev && Object.keys(v).forEach(k => { SET["r." + ov.dataset.rtPrev + "." + k] = v[k]; });
          ov.dataset.rtPrev = t.value; ov.querySelector(".rql").innerHTML = reqList(t.value); }
      });
      ov.dataset.rtPrev = type;
      ov.addEventListener("input", e => { const t = e.target; if (t.matches('input[type=color]')) { const w = t.closest(".pcol"); w.querySelector(".sw2").style.background = t.value; w.querySelector(".cv").textContent = rgb(t.value); } });
      ov.addEventListener("click", e => {
        const b = e.target.closest("button"); if (!b) return;
        if (b.dataset.a === "tsave") { saveSet(collectT(ov)); say("تم حفظ خصائص «" + ty.t + "»", "s"); }
        if (b.parentElement.classList.contains("ptabs")) { ov.querySelectorAll(".ptabs button").forEach(x => x.classList.toggle("on", x === b)); ov.querySelectorAll(".pp").forEach(p => { p.hidden = p.dataset.p !== b.dataset.p; }); }
        if (b.parentElement.classList.contains("stabs")) { ov.querySelectorAll(".stabs button").forEach(x => x.classList.toggle("on", x === b)); ov.querySelectorAll(".sp").forEach(p => { p.hidden = p.dataset.s !== b.dataset.s; }); }
      });
      const gt0 = root.querySelector('.pu-rt[data-rt="gen"]'); if (gt0) gt0.click();
    }

    /* ---------- اختصارات المستند ---------- */
    D.onKey = function (e) {
      const k = e.key, ctrl = e.ctrlKey && !e.altKey;
      if (document.querySelector(".pu-ov,#cfOv.show,#emOv.show,.txs-ov.show")) return false;
      if (k === "F4" && e.target === F("ref")) { txOpen({ q: F("ref").value.trim() }); return true; }
      if (k === "F1" && !e.ctrlKey && !e.altKey) { itemSearch(); return true; }   // F1: نافذة البحث عن الأصناف (مثل DEXEF)
      if ((k === "F4" || k === "F3") && e.target.dataset && (e.target.dataset.c === "name" || e.target.dataset.c === "code") && e.target.closest(".pu-grid")) {
        const row = e.target.closest(".pu-d"); openPicker(e.target, row ? +row.dataset.i : null, !!row && k === "F4"); return true;
      }
      if (k === "F2") { save("new"); return true; }
      if (k === "F4" && !(e.target.dataset && (e.target.dataset.c === "name" || e.target.dataset.c === "code"))) { save("print"); return true; }
      if (ctrl && e.shiftKey && e.code === "KeyS") { saveDraft(false); return true; }   // حفظ التغييرات (مسودة)
      if (ctrl && (k === "s" || k === "S" || e.code === "KeyS") && !e.shiftKey) { save("stay"); return true; }
      if (ctrl && (k === "p" || e.code === "KeyP")) { if (S.rows.length) printDoc(); return true; }
      if (k === "F3") { const t = e.target.dataset && e.target.dataset.c ? e.target : grid.querySelector(".pu-new [data-c=name]"); openPicker(t, t.closest(".pu-d") ? +t.closest(".pu-d").dataset.i : null); return true; }
      if (k === "F5") { refreshData(true); return true; }
      if (ctrl && e.code === "KeyF") { const t = root.querySelector('.pu-rt[data-rt="fmt"]'); if (t && !t.classList.contains("on")) t.click(); setTimeout(() => { F("gfind").focus(); F("gfind").select(); }, 0); return true; }
      if (k === "F6" && ty.store) return true;
      if (k === "F8" && ty.store) return true;
      if (k === "F6") { F("supName").focus(); supPicker(F("supName")); return true; }
      if (k === "F7") { if (ty.pay) payDlg(); return true; }
      if (k === "F8") { setCredit(!S.credit); return true; }
      if (k === "F9") { focusCell(-1, "name"); return true; }
      if (k === "Insert") { focusCell(-1, "name"); return true; }
      if (e.altKey && !e.ctrlKey && (k === "PageUp" || k === "ArrowRight")) { nav(-1); return true; }
      if (e.altKey && !e.ctrlKey && (k === "PageDown" || k === "ArrowLeft")) { nav(1); return true; }
      if (k === "Escape" && POP) { closePop(); return true; }
      return false;
    };

    /* «قراءة فاتورة ورقية» (scan.js): إدراج الأسطر المطابقة + المورد + رقم المرجع + التاريخ */
    function importScan(o) {
      o = o || {}; let n = 0;
      if (o.sup && F("supName")) setSupplier(o.sup, true);
      if (o.ref && F("ref") && !F("ref").value) F("ref").value = String(o.ref).slice(0, 40);
      if (o.date && F("date") && /^\d{4}-\d\d-\d\d$/.test(o.date)) F("date").value = o.date;
      (o.rows || []).forEach(x => {
        const p = prodById(x.pid); if (!p) return;
        const us = unitsOf(p), u = us.find(z => z.name === x.unit) || defUnit(p);
        const r = rowFromProduct(p, u, +x.qty || 1);
        if (+x.price > 0) r.price = r2(+x.price);
        if (x.note) r.notes = String(x.note).slice(0, 120);
        if (+o.dp > 0 && +o.dp < 100) r.dp = r2(+o.dp);   /* خصم الفاتورة الورقية (Remise 3%) على كل سطر */
        applyDp(r); S.rows.push(r); n++;
      });
      if (n) { S.sel = S.rows.length - 1; markDirty(); renderGrid(); updTotals(); renderSide(); flash(S.sel); }
      return n;
    }
    /* ---------- «حفظ التغييرات» (مطابق DEXEF Ctrl+Shift+S): مسودة بدون أي أثر على رصيد الأصناف + حفظ تلقائي ضد انقطاع الكهرباء ---------- */
    function snap() {
      const f = {}; root.querySelectorAll("[data-f]").forEach(el => { if (el.matches("input,select,textarea")) f[el.dataset.f] = el.type === "checkbox" ? el.checked : el.value; });
      const st = {}; Object.keys(S).forEach(k => { if (k[0] !== "_" && k !== "loadedAt") st[k] = S[k]; });
      return { v: 1, type, at: new Date().toISOString(), S: JSON.parse(JSON.stringify(st)), f, desc: D.desc || "", whId: D.whId, toWhId: D.toWhId, cx: { code: CX.code, rate: CX.rate }, itemCard: D.itemCard || 0 };
    }
    D.restore = function (sn, info) {
      closePop(); info = info || {};
      S = Object.assign(blank(), sn.S || {}); S.dirty = true;
      D.desc = sn.desc || ""; D.whId = sn.whId; D.toWhId = sn.toWhId; D.itemCard = sn.itemCard || 0; D.pend = null;
      const f = sn.f || {};
      if (f.mode && MODES.includes(f.mode)) { F("mode").value = f.mode; applySettings(); }
      refreshMeta();
      Object.keys(f).forEach(k => { if (k === "mode") return; const el = F(k); if (!el) return; if (el.type === "checkbox") el.checked = !!f[k]; else el.value = f[k]; });
      if (sn.cx) { CX.code = sn.cx.code || "DZD"; CX.rate = +sn.cx.rate || 1; try { cxPaint(); } catch (e) { } }
      setCredit(!!S.credit, true); if (S.credit && f.paid != null) F("paid").value = f.paid;
      setPType(f.ptype || "cash", true); if (f.acct != null && F("acct")) F("acct").value = f.acct; if (f.treas && F("treas")) F("treas").value = f.treas;
      D.draftId = info.id || 0; D.draftManual = !info.auto; D.draftAt = info.updated ? new Date(String(info.updated).replace(" ", "T")) : null;
      S.sel = S.rows.length ? S.rows.length - 1 : -1;
      renderAll(); updTitle(); paintDraft(info.auto ? "auto" : "manual", true);
      if (S.sel >= 0) setTimeout(() => flash(S.sel), 60);
    };
    D.draftsOf = () => D.draftId;
    D.dropDraftLink = () => { D.draftId = 0; D.draftManual = false; paintDraft(null); };
    function draftMeta() { const t = totals(); return { type, title: ty.t + (S.no ? " رقم " + S.no : ""), party: (F("supName") && F("supName").value) || (ty.pay ? "تعامل نقدي" : ""), cnt: S.rows.length, total: r2(t.total), invoiceId: S.id || 0 }; }
    let drBusy = false, drAgain = false;
    function saveDraft(auto) {
      if (!S.rows.length && !S.exps.length) { if (!auto) say("لا توجد أصناف لحفظها كمسودة", "w"); return; }
      if (drBusy) { drAgain = true; return; }
      if (D.pend && !auto) commitPend(true);
      drBusy = true; if (!auto) D.draftManual = true;
      clearTimeout(D._drT); D._drP = 0; paintDraft("saving");
      const o = Object.assign(draftMeta(), { id: D.draftId || 0, payload: JSON.stringify(snap()), auto: !D.draftManual });
      DR.save(o).then(r => {
        D.draftId = r.id; D.draftAt = new Date(); paintDraft(D.draftManual ? "manual" : "auto", !auto);
        if (!auto) { say("✔ تم حفظ التغييرات كمسودة — رصيد الأصناف لم يتغيّر، وتجدها في «المسودات المحفوظة»", "s"); try { if (typeof SaveSound !== "undefined") SaveSound.play(); } catch (e) { } }
      }).catch(e => { paintDraft("err"); if (!auto) say("تعذّر حفظ المسودة: " + ((e && e.message) || e), "e"); })
        .then(() => { drBusy = false; if (drAgain) { drAgain = false; autoKick(); } });
    }
    /* الحفظ التلقائي: بعد 4 ثوانٍ من آخر تعديل (وعلى الأكثر كل 20 ثانية أثناء العمل المتواصل) */
    function autoKick() {
      if (!S || (!S.rows.length && !S.exps.length) || saving) return;
      const now = Date.now(); if (!D._drP) D._drP = now;
      clearTimeout(D._drT);
      D._drT = setTimeout(() => { D._drP = 0; if (S.dirty && (S.rows.length || S.exps.length)) saveDraft(true); }, now - D._drP > 20000 ? 50 : 4000);
    }
    root.addEventListener("change", e => { if (e.target.closest("[data-f],.pu-grid,.pu-exps")) autoKick(); });
    D.dropAutoDraft = () => { if (D.draftId && !D.draftManual) { DR.del(D.draftId).catch(() => { }); D.draftId = 0; } clearTimeout(D._drT); D._drP = 0; };
    function paintDraft(st, pulse) {
      let el = root.querySelector(".pu-drft");
      if (!el) { const bn = root.querySelector(".pu-banner"); if (!bn) return; bn.insertAdjacentHTML("beforeend", '<button type="button" class="pu-drft" data-a="drafts" hidden></button>'); el = root.querySelector(".pu-drft"); }
      if (!st) { el.hidden = true; return; }
      const tm = D.draftAt ? D.draftAt.toTimeString().slice(0, 5) : "";
      const ic = st === "saving" ? '<i class="sp"></i>' : st === "err" ? "⚠" : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 18a5 5 0 0 1-.7-9.95A6 6 0 0 1 18 9a4 4 0 0 1 0 8.5"/><path d="M9 14l2.5 2.5L16 12"/></svg>';
      el.className = "pu-drft " + st; el.hidden = false;
      el.innerHTML = ic + `<span>${st === "saving" ? "جارٍ الحفظ…" : st === "err" ? "تعذّر الحفظ التلقائي" : (st === "manual" ? "مسودة محفوظة" : "حُفظ تلقائياً") + (tm ? " " + tm : "")}</span>`;
      el.title = st === "manual" ? "حُفظت التغييرات كمسودة (Ctrl+Shift+S) — بدون أثر على رصيد الأصناف. اضغط لعرض كل المسودات" : "حفظ تلقائي ضد انقطاع الكهرباء — عند إعادة فتح البرنامج تجد الفاتورة كما هي. اضغط لعرض المسودات";
      if (pulse) { el.classList.remove("pulse"); void el.offsetWidth; el.classList.add("pulse"); }
    }

    /* «البحث عن تعامل» (مطابق DEXEF): المكبّر بجانب «رقم المرجع #» — تحميل أصناف من مستند سابق (أمر شراء ← فاتورة، فاتورة ← مرتجع ...) */
    const TX_SRC = { Purchase: "PurchaseOrder", PurchaseReturn: "Purchase", PurchaseOrder: "PurchaseOrder", Transfer: "TransferReq", Reserve: "ReserveReq", ReserveCancel: "Reserve", StockIn: "Purchase", StockOut: "StockOut", Quotation: "Quotation", SupplyOrder: "SupplyOrder" };
    function txOpen(o) {
      if (!window.ANOUER_TX) { say("وحدة البحث عن تعامل غير محمّلة", "w"); return; }
      ANOUER_TX.open(Object.assign({ ctx: "pur." + type, target: type, targetName: ty.t, defType: TX_SRC[type] || type, apply: txApply,
        onClose: done => { if (done) setTimeout(() => { try { focusCell(-1, "name"); } catch (e) { } }, 30); } }, o || {}));
    }
    /* «تحميل الفاتورة» (مطابق DEXEF): التعامل + الاسم ← تجميع فواتيره وتحميل أصنافها */
    const LD_SRC = { Purchase: "PurchaseOrder", PurchaseReturn: "Purchase", PurchaseOrder: "Purchase", TransferReq: "TransferReq", Transfer: "TransferReq", Reserve: "ReserveReq", ReserveCancel: "Reserve", Quotation: "Quotation", SupplyOrder: "Quotation" };
    function loadOpen() {
      ANOUER_TX.open({ mode: "load", ctx: "load." + type, target: type, targetName: ty.t, defType: LD_SRC[type] || (ty.store ? type : ty.cust ? "Quotation" : "Purchase"), apply: txApply,
        onClose: done => { if (done) setTimeout(() => { try { focusCell(-1, "name"); } catch (e) { } }, 30); } });
    }
    function txApply(r) {
      const add = []; let miss = 0;
      r.docs.forEach(x => x.lines.forEach(l => {
        const p = prodById(l.pid); if (!p) { miss++; return; }
        const u = unitByName(p, l.unit) || defUnit(p);
        const row = rowFromProduct(p, u, +l.qty || 1);
        if (r.price === "doc" && +l.price > 0) {
          row.price = r2(+l.price);
          if (+l.disc > 0 && +l.origQty > 0) { const g = (+l.origQty) * (+l.price); row.dp = g ? r2(+l.disc / g * 100) : 0; row.disc = r2(row.price * row.qty * row.dp / 100); }
        }
        if (l.notes) row.notes = String(l.notes).slice(0, 120);
        applyDp(row); add.push(row);
      }));
      if (!add.length) { say(miss ? "الأصناف المحددة غير موجودة في الفهرس" : "لم يتم تحميل أي صنف", "w"); return false; }
      if (r.merge) {   // دمج الأصناف المتكررة: نفس الصنف + الوحدة + السعر + نسبة الخصم ← سطر واحد بمجموع الكميات
        const mp = new Map();
        add.slice().forEach(row => { const k = row.pid + "|" + row.unit + "|" + row.price + "|" + (row.dp || 0); const ex = mp.get(k); if (ex) { ex.qty = r2((+ex.qty || 0) + (+row.qty || 0)); applyDp(ex); add.splice(add.indexOf(row), 1); } else mp.set(k, row); });
      }
      const go = () => {
        if (r.replace) S.rows = [];
        S.rows = S.rows.concat(add);
        const h = r.docs[0].h || {};
        if (!S.supId && ty.pay && h.supId) { const s = supById(h.supId); if (s) setSupplier(s, true); }
        if (type === "PurchaseReturn" && r.docs.length === 1 && r.docs[0].d.type === "Purchase") S.parentId = r.docs[0].d.id;
        if (r.link && F("ref")) { F("ref").value = String(r.ref).slice(0, 40); F("ref").classList.add("linked"); }
        S.sel = S.rows.length - add.length; markDirty(); renderAll(); flash(S.sel);
        say("تم تحميل " + add.length + " صنف من " + (r.docs.length > 1 ? r.docs.length + " مستندات" : ANOUER_TX.tName(r.docs[0].d.type) + " رقم " + r.docs[0].d.no) + (miss ? " — تعذّر إيجاد " + miss + " صنف" : ""), miss ? "w" : "s");
      };
      go(); return add.length;
    }
    F("ref").addEventListener("keydown", e => { if (e.key === "F4" || (e.altKey && e.key === "ArrowDown")) { e.preventDefault(); e.stopPropagation(); txOpen({ q: F("ref").value.trim() }); } });
    F("ref").addEventListener("input", () => F("ref").classList.remove("linked"));
    D.txSearch = txOpen;
    root.querySelector(".pu-scan").addEventListener("click", e => { e.stopPropagation(); if (window.ANOUER_SCAN) ANOUER_SCAN.open({ doc: D, sups: () => SUPS }); else say("وحدة القراءة غير محمّلة", "w"); });
    Object.defineProperty(D, "rows", { get: () => S ? S.rows : [], configurable: true });
    Object.assign(D, { printDoc, saveDraft, importScan, renderExps, reset, refreshMeta, applySettings, renderAll, totals, focusFirst, save, addProduct, payload, cxSet, setSupplier, searchProducts, renderSide, isDirty: () => !!(S && S.dirty && (S.rows.length || S.exps.length)), info: () => ({ n: S ? S.rows.length : 0, tot: S ? totals().total : 0 }) });
    Object.defineProperty(D, "state", { get: () => S });
    reset(true); applySettings();
    if (ty.side) showSide("tr");
    return D;
  }

  /* ------------------------------------------------------------------ إدارة التبويبات */
  function activeKey() { const t = document.querySelector("#tabs .tab.active"); return t ? t.dataset.key : ""; }
  function glaList() {
    if (G("puGlaList")) { liveCoa(); return; }
    if (!window.__FH_COA) return;
    const dl = document.createElement("datalist"); dl.id = "puGlaList";
    const all = window.__FH_COA, par = new Set(all.map(a => a[0].slice(0, -1)));
    dl.innerHTML = all.filter(a => !par.has(a[0]) && a[0].length > 2).map(a => `<option value="${esc(a[1])}">${esc(a[0])}</option>`).join("");
    document.body.appendChild(dl);    try { liveCoa(); } catch (e) { }
  }
  function openDoc(type, opts) {
    opts = opts || {};
    loadWhs(true); if (TY[type].store) glaList();
    // تبويب فارغ من نفس النوع؟ نعيد استخدامه
    if (!opts.forceNew) {
      const empty = Object.values(DOCS).find(d => d.type === type && !d.state.id && !d.state.rows.length && document.querySelector(`#tabs .tab[data-key="${d.key}"]`));
      if (empty) { try { if (window.__vkRestampPur) __vkRestampPur(empty); } catch (e) { } openTab(empty.key, TY[type].tab, "pur"); return empty; }
    }
    const key = "pur:" + type + ":" + (tabSeq++);
    const d = Doc(key, type);
    DOCS[key] = d;
    openTab(key, TY[type].tab, "pur");
    return d;
  }
  function showActive() {
    const k = activeKey();
    // تنظيف مستندات أُغلقت تبويباتها
    Object.keys(DOCS).forEach(x => { if (!document.querySelector(`#tabs .tab[data-key="${x}"]`) && x !== k) { DOCS[x].root.remove(); delete DOCS[x]; } });
    Object.values(DOCS).forEach(d => { d.root.hidden = d.key !== k; });
    const d = DOCS[k];
    if (d) { d.refreshMeta(); d.renderAll(); setTimeout(() => d.focusFirst(), 30); }
    else if (/^pur:/.test(k)) { const type = k.split(":")[1]; if (TY[type]) { const nd = Doc(k, type); DOCS[k] = nd; nd.root.hidden = false; } }
  }
  RV.VIEW_SHOW.pur = showActive;

  // تأكيد إغلاق تبويب فيه أصناف غير محفوظة
  const tabsEl = G("tabs");
  if (tabsEl) tabsEl.addEventListener("click", e => {
    const x = e.target.closest(".x"); if (!x) return;
    const tb = x.closest(".tab"), k = tb && tb.dataset.key, d = k && DOCS[k];
    if (!d) return;
    if (purCloseGuard(k)) { e.stopImmediatePropagation(); e.preventDefault(); }
  }, true);
  /* مثل المبيعات (DEXEF): فاتورة جديدة بها أصناف لا تُغلق أبداً بـ ✕ — رسالة «الفاتورة يوجد بها اصناف هل تريد الاغلاق» بالصوت الاعتيادي ،
     «موافق» يبقيها مفتوحة ، تُغلق فقط بعد حذف الأصناف كلها (أو الحفظ). المستند المحفوظ المفتوح من «مراجعة المشتريات» يُغلق مباشرة.
     ترجع true إذا مُنع الإغلاق. */
  function purCloseGuard(k) {
    const d = DOCS[k]; if (!d || !d.state) return false;
    const S = d.state, drop = () => { S.dirty = false; try { d.dropAutoDraft(); } catch (x) { } };
    if (S.id) { drop(); return false; }
    if (!S.rows.length) { drop(); return false; }
    let m = "ظهور رسالة تنبيه"; try { if (window.__invOnCloseMode) m = __invOnCloseMode(); } catch (x) { }
    if (m === "عدم ظهور رسالة تنبيه") { drop(); return false; }
    if (activeKey() !== k) openTab(k, TY[d.type].tab, "pur");
    if (m === "منع إغلاق الفاتورة") { say("لا يمكن إغلاق فاتورة بها أصناف — احفظها أو امسح أصنافها أولاً", "w"); return true; }
    const inf = d.info ? d.info() : { n: S.rows.length, tot: 0 };
    if (window.invAskClose) invAskClose({ n: inf.n, tot: inf.tot, onF2: () => { try { d.save("new"); } catch (x) { } } });
    else say("الفاتورة يوجد بها اصناف — احذفها أو احفظها أولاً", "w");
    return true;
  }
  window.__purCloseGuard = purCloseGuard;
  /* مستند مشتريات فارغ تماماً (جديد، بدون أصناف ولا مورد) — يُستعمل لإغلاق التبويبات الفارغة المكرّرة */
  window.__purEmpty = k => { const d = DOCS[k]; if (!d || !d.state) return false; const S = d.state; return !S.id && !S.rows.length && !S.sup && !S.supId && !S.supplierId; };

  // لوحة المفاتيح: تمر عبر خطاف الشاشة النشطة قبل حاجز مفاتيح F العام
  const prevViewKey = window.__viewKey;
  window.__viewKey = function (e) {
    if (POP && POP.key && POP.key(e)) return true;
    if (main.dataset.view === "pur") { const d = DOCS[activeKey()]; if (d && d.onKey(e)) return true; }
    return prevViewKey ? prevViewKey(e) : false;
  };
  const prevCtrlN = window.__ctrlN;
  window.__ctrlN = function () {
    if (main.dataset.view === "pur") { const d = DOCS[activeKey()]; if (d) { openDoc(d.type, { forceNew: d.state.rows.length > 0 }); return true; } }
    const rv = Object.keys(TY).find(k => main.dataset.view === TY[k].rv);
    if (rv) { openDoc(rv); return true; }
    return prevCtrlN ? prevCtrlN() : false;
  };
  const prevKb = window.__kbOwner;
  window.__kbOwner = function (e) {
    if (main.dataset.view === "pur" && e && e.ctrlKey && /^[lm]$/i.test(e.key || "")) return false;
    return prevKb ? prevKb(e) : false;
  };

  /* ------------------------------------------------------------------ مراجعة التعاملات */
  const REV = {};
  /* ✨ أدوات مراجعة المبيعات نفسها (القائمة اليمنى ، Customization ، طريقة العرض) لمراجعة المشتريات / مرتجع المشتريات / طلبيات الشراء */
  const XT = { Purchase: 1, PurchaseReturn: 1, PurchaseOrder: 1 }, XI = {};
  const xOf = (type, el) => XI[type] || (window.__SRXmk && el ? (XI[type] = window.__SRXmk({ view: TY[type].rv, k: "pur." + type + ".rev", elId: el.id })) : null);
  function refreshReviews() { Object.keys(REV).forEach(t => { LISTS[t] = null; loadReview(t); }); }
  function loadReview(type) {
    const R = REV[type]; if (!R) return;
    const p = B() ? call("fm.pur.list", { type, from: "2000-01-01", to: today() }).then(l => (LISTS[type] = l || [])) : Promise.resolve(LOCAL.docs.filter(d => d.type === type));
    p.then(l => { const ty0 = TY[type]; (l || []).forEach(r => { if (r && r.name == null) { let nm = r.sup || "تعامل نقدي"; if (ty0.lite) { try { const m = r.meta ? JSON.parse(r.meta) : {}; nm = m.deal || ty0.deal || ty0.t; } catch (e) { nm = ty0.t; } } Object.defineProperty(r, "name", { value: nm, writable: true, configurable: true, enumerable: false }); } }); R.data = l; R.S.render(); }).catch(e => say("تعذّر تحميل " + TY[type].rev + ": " + e.message, "e"));
  }
  Object.keys(TY).forEach(type => {
    const ty = TY[type];
    const el = document.createElement("div");
    el.className = "vw pu-rev"; el.id = "v_" + ty.rv; el.tabIndex = -1; el.setAttribute("aria-label", ty.rev);
    main.appendChild(el);
    const st = document.createElement("style");
    st.textContent = `.main[data-view=${ty.rv}]>#v_${ty.rv}{display:flex;animation:vwIn .22s ease-out}`;
    document.head.appendChild(st);
    RV.VIEW_SHOW[ty.rv] = function () {
      if (!REV[type]) {
        const R = REV[type] = { data: [] };
        const PD = [0, 6, 30, 90, 365, 1e9];
        R.S = RV.Review(el, {
          title: ty.rev,
          filters: RV.ddSel(RV.BR, RV.BR[0]) + RV.ddSel(["المخزن الرئيسي، المخزن1", "المخزن الرئيسي"], "المخزن الرئيسي، المخزن1") + `<span class="rv-sel" data-per="1">${RV.ddSel(RV.PERIODS, RV.PERIODS[3]).replace(/^<span[^>]*>|<\/span>$/g, "")}</span>`,
          head: `<div class="rv-dd"><span class="lb"></span><span>⋯</span><span class="ck">✓</span><span style="font-size:9px;color:#777">⌄</span></div><div class="rv-ttl">${esc(ty.rev)}</div><div style="flex:1"></div><div class="rv-search"><span>${RV.SRCH}</span><input placeholder="Enter text to search..."></div>`,
          side: [["عام", "gen"], ["نظرة عامة", "ov"], ["التقارير", "rep"], ["الملخص", "sum"], ["اجماليات الأصناف", "layers"]],
          moreCols: ty.store ? storeMore(type) : undefined,
          cols: ty.store ? storeCols(type) : ty.cust ? custCols(type) : [{ k: "rn", w: "44px" }, { t: "التاريخ", w: "120px", f: r => r.date }, { t: "الوقت", w: "90px", f: r => r.time }, { t: "الرقم", w: "90px", f: r => r.no, v: r => +r.no || 0 },
            { t: "الاسم", w: "minmax(150px,1fr)", f: r => r.sup || "تعامل نقدي", txt: 1 }, { t: "عدد الأصناف", w: "100px", f: r => r.cnt },
            { t: "اجمالي قبل الخصم", w: "130px", f: r => r2(r.before), sum: 1 }, { t: "اجمالي الخصم", w: "100px", f: r => r2(r.disc), sum: 1 },
            { t: "الضريبة", w: "86px", f: r => r2(r.tax), sum: 1 }, { t: "الاجمالي", w: "110px", f: r => r2(r.total), sum: 1 },
            { t: "المدفوع", w: "100px", f: r => r2(r.paid), sum: 1 }, { t: "الباقي", w: "110px", f: r => r2(r.rem), sum: 1 }, { k: "ic", w: "40px" }],
          icon: `<span class="rv-info" title="تفاصيل">i</span>`, totals: 1,
          data: () => R.data,
          pass: r => { const s = el.querySelector("[data-per] select"), d = PD[s ? s.selectedIndex : 3]; if (d >= 1e9) return true; return (new Date(today()) - new Date(r.date)) / 864e5 <= d; },
          onNew: () => openDoc(type),
          onTb: XT[type] ? (a, b, r, S) => { const X = xOf(type, el); return X ? X.tb(a, b, r, S) : false; } : undefined,
          onIcon: r => showDetail(type, r),
          onOpen: r => openSaved(type, r.id),
          onDel: r => {
            ask("هل تريد حذف " + ty.t + " رقم " + r.no + (ty.cust ? " ؟" : ty.store ? " ؟ سيتم عكس أثرها على أرصدة المخزون" : " ؟ سيتم عكس أثرها على المخزون ورصيد المورد والخزينة"), () => {
              const after = () => { say("تم حذف " + ty.t + " رقم " + r.no, "s"); LISTS[type] = null; loadReview(type); loadSups(); Promise.resolve((() => { try { if (window.__anouerLink) return __anouerLink.loadProducts(); } catch (e) { } })()).catch(() => { }).then(() => WHM().load(true)); };
              if (B()) call("fm.pur.delete", { id: r.id }).then(after).catch(e => say("لم يتم الحذف: " + e.message, "e"));
              else { LOCAL.docs = LOCAL.docs.filter(d => d.id !== r.id); after(); }
            });
          }
        });
        const rf = el.querySelector('.rv-tb [data-a="refresh"]');
        if (rf) rf.addEventListener("click", () => { LISTS[type] = null; loadReview(type); });
        if (XT[type]) { const X = xOf(type, el); if (X) { try { X.attach(R.S); } catch (e) { console.warn("pur-rev-x", e); } } wireRevMenu(type, el); }
      }
      loadReview(type);
      setTimeout(() => el.focus(), 0);
    };
  });
  /* القائمة اليمنى في المراجعة (مثل «مراجعة مبيعات» و DEXEF): جديد Ctrl+N · تعديل Ctrl+E · تحديث البيانات F5 · نسخ التعامل ◂ ·
     حذف Ctrl+D · طباعة ◂ · ملف الفاتورة · أغلاق الصفحة */
  const revLines = (type, r) => B() ? call("fm.pur.get", { id: r.id }).then(h => h.lines || []) : Promise.resolve(((LOCAL.docs.find(x => x.id === r.id) || {}).doc || { rows: [] }).rows || []);
  function revCopy(t, m) { try { navigator.clipboard.writeText(String(t == null ? "" : t)).then(() => say(m, "s"), () => say("تعذّر النسخ", "e")); } catch (e) { say("تعذّر النسخ", "e"); } }
  function revFile(type, r) {
    revLines(type, r).then(L => {
      const q = v => { v = String(v == null ? "" : v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
      const txt = "\ufeff" + [["الكود", "الصنف", "الوحدة", "الكمية", "السعر", "الاجمالي"].join(",")].concat(L.map(l => [l.code || "", l.name, l.unit || "", l.qty, l.price, l.total != null ? l.total : r2((+l.qty || 0) * (+l.price || 0) - (+l.disc || 0))].map(q).join(","))).join("\r\n");
      const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([txt], { type: "text/csv;charset=utf-8" })); a.download = TY[type].t + "-" + r.no + ".csv"; document.body.appendChild(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); say("تم تصدير ملف " + TY[type].t + " رقم " + r.no + " (" + L.length + " صنف)", "s");
    }).catch(e => say("تعذّر تصدير الملف: " + ((e && e.message) || e), "e"));
  }
  function revPrint(type, r, preview) {
    openSaved(type, r.id);
    const t0 = Date.now(), go = () => { const d = Object.values(DOCS).find(x => x.type === type && x.state && x.state.id === r.id && !x.root.hidden);
      if (d && d.state.rows.length && d.printDoc) { d.printDoc(!!preview); return; } if (Date.now() - t0 < 8000) setTimeout(go, 200); else say("تعذّر فتح المستند للطباعة", "e"); };
    setTimeout(go, 150);
  }
  function revMenu(type, el, r, cx, cy) {
    const R = REV[type]; if (!R || !R.S) return;
    const it = [
      { ic: "n", t: "جديد", kb: "Ctrl+N", f: () => openDoc(type) },
      { ic: "e", t: "تعديل", kb: "Ctrl+E", f: () => openSaved(type, r.id), dis: !r },
      { ic: "r", t: "تحديث البيانات", kb: "F5", f: () => { LISTS[type] = null; loadReview(type); say("تم تحديث البيانات", "s"); } },
      { ic: "c", t: "نسخ التعامل", dis: !r, sub: r ? [{ t: "نسخ رقم الفاتورة", f: () => revCopy(r.no, "تم نسخ الرقم " + r.no) }, { t: "نسخ الاسم", f: () => revCopy(r.sup || "تعامل نقدي", "تم نسخ: " + (r.sup || "تعامل نقدي")) }, { t: "نسخ الاجمالي", f: () => revCopy(r2(r.total), "تم نسخ الاجمالي " + fmt(r.total)) }] : [] },
      { ic: "d", t: "حذف", kb: "Ctrl+D", f: () => R.S.cfg.onDel && R.S.cfg.onDel(r, R.S.render), dis: !r },
      { ic: "g", t: "طباعة", dis: !r, sub: r ? [{ t: "طباعة الفاتورة", f: () => revPrint(type, r) }, { t: "معاينة الطباعة", f: () => revPrint(type, r, true) }] : [] },
      { ic: "f", t: "ملف الفاتورة", f: () => revFile(type, r), dis: !r },
      { ic: "v", t: "أغلاق الصفحة", f: () => { try { closeTab(TY[type].rv); } catch (e) { } } }
    ];
    try {
      const X = window.__rcm; if (!X) return; const m = X.el(), FN = {}; X.fn(FN); let n = 0; const reg = f => { const k = "k" + (n++); FN[k] = f; return k; }; const RCI = X.RCI || {};
      it.forEach(x => { x.k = x.f ? reg(x.f) : ""; if (x.sub) x.sub.forEach(y => y.k = reg(y.f)); });
      m.innerHTML = it.map(x => `<div class="rcm-i${x.dis ? " dis" : ""}" role="menuitem" data-k="${x.k}">${RCI[x.ic] || ""}<b>${x.t}</b>${x.kb ? `<kbd>${x.kb}</kbd>` : ""}${x.sub ? '<span class="ar">◀</span>' : ""}${x.sub ? `<div class="rcm-sub">${x.sub.map(y => `<div class="rcm-i" data-k="${y.k}"><b>${y.t}</b></div>`).join("")}</div>` : ""}</div>`).join("");
      m.classList.add("show"); const w = m.offsetWidth, h = m.offsetHeight; let l = cx - w; if (l < 4) l = Math.min(cx, innerWidth - w - 4); let t = cy; if (t + h > innerHeight - 4) t = Math.max(4, innerHeight - h - 4);
      m.style.left = l + "px"; m.style.top = t + "px";
      m.querySelectorAll(".rcm-sub").forEach(sb => { sb.classList.remove("flip"); sb.style.display = "block"; const b = sb.getBoundingClientRect(); sb.style.display = ""; if (b.left < 4) sb.classList.add("flip"); });
    } catch (e) { console.warn("revMenu", e); }
  }
  function wireRevMenu(type, el) {
    if (el.__rvm) return; el.__rvm = 1;
    el.addEventListener("contextmenu", e => {
      const R = REV[type]; if (!R || !R.S || main.dataset.view !== TY[type].rv) return;
      const body = e.target.closest(".rv-rows,.rv-grid"); if (!body || e.target.closest(".rv-h,.rv-f")) return;
      e.preventDefault(); const d = e.target.closest(".rv-d"); let r = null;
      if (d) { R.S.sel = +d.dataset.i; el.querySelectorAll(".rv-d").forEach(x => { const on = x === d; x.classList.toggle("cur", on); x.classList.toggle("sel", on); }); r = (R.S.cur || [])[R.S.sel]; if (r && r._grp) r = null; }
      revMenu(type, el, r, e.clientX, e.clientY);
    });
    window.addEventListener("keydown", e => {
      if (main.dataset.view !== TY[type].rv) return; const R = REV[type]; if (!R || !R.S) return;
      if (document.querySelector("dialog[open],.pu-ov,.irw-ov,.dxm-ov")) return;
      const r = (R.S.cur || [])[R.S.sel], ok = r && !r._grp, c = e.ctrlKey && !e.shiftKey && !e.altKey;
      if (c && e.code === "KeyE") { e.preventDefault(); e.stopImmediatePropagation(); if (ok) openSaved(type, r.id); else say("اختر سطراً أولاً", "w"); }
      else if (c && e.code === "KeyD") { e.preventDefault(); e.stopImmediatePropagation(); if (ok && R.S.cfg.onDel) R.S.cfg.onDel(r, R.S.render); else say("اختر سطراً أولاً", "w"); }
      else if (c && e.code === "KeyN") { e.preventDefault(); e.stopImmediatePropagation(); openDoc(type); }
      else if (e.key === "F5" && !e.ctrlKey) { e.preventDefault(); e.stopImmediatePropagation(); LISTS[type] = null; loadReview(type); say("تم تحديث البيانات", "s"); }
    }, true);
  }
  /* أعمدة مراجعة عرض السلعة / أوامر التوريد (مطابقة DEXEF) + الحالة الملوّنة وصلاحية العرض (لمستي) */
  function custCols(type) {
    const mj = r => { if (r._m === undefined) { try { r._m = r.meta ? JSON.parse(r.meta) : (r.doc && r.doc.pl ? JSON.parse(r.doc.pl.Meta || "{}") : {}); } catch (e) { r._m = {}; } } return r._m || {}; };
    const stOf = r => { const m = mj(r), L = CST[type], x = L.find(z => z[0] === m.status) || L[0];
      const due = r.due || m.validTo || (r.doc && r.doc.pl ? r.doc.pl.DueDate : "");
      return type === "Quotation" && x[0] === "open" && due && due < today() ? CST.Quotation.find(z => z[0] === "exp") : x; };
    const dueOf = r => r.due || mj(r).validTo || (r.doc && r.doc.pl ? r.doc.pl.DueDate : "") || "";
    return [{ k: "rn", w: "44px" }, { t: "التاريخ", w: "110px", f: r => r.date }, { t: "الوقت", w: "84px", f: r => r.time }, { t: "الرقم", w: "80px", f: r => r.no, v: r => +r.no || 0 },
      { t: "الاسم", w: "minmax(150px,1fr)", f: r => r.sup || "تعامل نقدي", txt: 1 }, { t: "عدد الأصناف", w: "90px", f: r => r.cnt },
      { t: "اجمالي قبل الخصم", w: "120px", f: r => r2(r.before), sum: 1 }, { t: "اجمالي الخصم", w: "100px", f: r => r2(r.disc), sum: 1 },
      { t: "الضريبة", w: "84px", f: r => r2(r.tax), sum: 1 }, { t: "الاجمالي", w: "110px", f: r => r2(r.total), sum: 1 },
      { t: "الحالة", w: "128px", f: r => stOf(r)[1], h: r => { const x = stOf(r); return `<span class="pu-stc" style="--sc:${x[2]}">${esc(x[1])}</span>`; }, txt: 1 },
      { t: type === "Quotation" ? "صالح حتى" : "تاريخ التوريد", w: "104px", f: r => dueOf(r), txt: 1 },
      { t: "رقم المرجع", w: "90px", f: r => r.ref || (r.doc && r.doc.pl ? r.doc.pl.RefNo : "") || "", txt: 1 }, { t: "المستخدم", w: "90px", f: r => r.user || "", txt: 1 },
      { t: "الملاحظات", w: "140px", f: r => r.notes || (r.doc && r.doc.pl ? r.doc.pl.Notes : "") || "", txt: 1 }, { k: "ic", w: "40px" }];
  }
  /* أعمدة مراجعة مستندات المخازن (مطابقة DEXEF) */
  function storeCols(type) {
    const ty = TY[type], mj = r => { if (r._m === undefined) { try { r._m = r.meta ? JSON.parse(r.meta) : (r.doc && r.doc.pl ? JSON.parse(r.doc.pl.Meta || "{}") : {}); } catch (e) { r._m = {}; } } return r._m || {}; };
    const ST = { open: "مفتوحة", done: "تم التنفيذ", cancel: "ملغاة", ok: "معتمدة", review: "تحت المراجعة" };
    /* «أخرى» (مخزون أول المدة / هالك مخزون / الصدقات): نفس أعمدة DEXEF الظاهرة — والباقي في «اختيار الحقول» (storeMore) */
    if (ty.lite) return [{ k: "rn", w: "44px" }, { t: "التاريخ", w: "130px", f: r => r.date }, { t: "الوقت", w: "100px", f: r => r.time }, { t: "الرقم", w: "100px", f: r => r.no, v: r => +r.no || 0 },
      { t: "الاسم", w: "minmax(180px,1fr)", f: r => mj(r).deal || ty.deal || ty.t, txt: 1 }, { t: "عدد الأصناف", w: "130px", f: r => r.cnt, sum: 0 }, { t: "الاجمالي", w: "140px", f: r => r2(r.total), sum: 1 }, { k: "ic", w: "40px" }];
    const c = [{ k: "rn", w: "44px" }, { t: "التاريخ", w: "110px", f: r => r.date }, { t: "الوقت", w: "84px", f: r => r.time }, { t: "الرقم", w: "80px", f: r => r.no, v: r => +r.no || 0 },
      { t: "اسم المخزن", w: "130px", f: r => mj(r).wh || "المخزن الرئيسي", txt: 1 }];
    if (ty.side) c.push({ t: ty.side === "to" ? "مخزن التحويل" : "طلب من", w: "130px", f: r => mj(r).trWh || "", txt: 1 });
    if (ty.gla) c.push({ t: "حساب الأستاذ", w: "minmax(150px,1fr)", f: r => mj(r).gla || ty.gla, txt: 1 });
    c.push({ t: "عدد الأصناف", w: "90px", f: r => r.cnt }, { t: "اجمالي الكمية", w: "100px", f: r => r2(r.qty), sum: 1 }, { t: "الاجمالي", w: "110px", f: r => r2(r.total), sum: 1 });
    if (ty.req) c.push({ t: "الحالة", w: "90px", f: r => ST[mj(r).status] || "مفتوحة", txt: 1 });
    c.push({ t: "رقم المرجع", w: "90px", f: r => r.ref || (r.doc && r.doc.pl ? r.doc.pl.RefNo : "") || "", txt: 1 }, { t: "المستخدم", w: "90px", f: r => r.user || "", txt: 1 },
      { t: "الملاحظات", w: ty.gla ? "140px" : "minmax(140px,1fr)", f: r => r.notes || (r.doc && r.doc.pl ? r.doc.pl.Notes : "") || "", txt: 1 }, { k: "ic", w: "40px" });
    return c;
  }
  /* أعمدة إضافية لمراجعة «أخرى» (مخفية افتراضياً — «اختيار الحقول») + لمستي: متوسط سعر الوحدة واليوم */
  function storeMore(type) {
    const ty = TY[type]; if (!ty.lite) return [];
    const mj = r => { if (r._m === undefined) { try { r._m = r.meta ? JSON.parse(r.meta) : (r.doc && r.doc.pl ? JSON.parse(r.doc.pl.Meta || "{}") : {}); } catch (e) { r._m = {}; } } return r._m || {}; };
    const DN = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
    return [{ t: "اسم المخزن", w: "130px", f: r => mj(r).wh || "المخزن الرئيسي", txt: 1 }, { t: "حساب الأستاذ", w: "170px", f: r => mj(r).gla || ty.gla || "", txt: 1 },
      { t: "اجمالي الكمية", w: "110px", f: r => r2(r.qty), sum: 1 }, { t: "متوسط سعر الوحدة", w: "120px", f: r => (+r.qty ? r2((+r.total || 0) / +r.qty) : 0) },
      { t: "رقم المرجع", w: "100px", f: r => r.ref || (r.doc && r.doc.pl ? r.doc.pl.RefNo : "") || "", txt: 1 }, { t: "الحالة", w: "90px", f: r => mj(r).status || "", txt: 1 },
      { t: "المستخدم", w: "100px", f: r => r.user || "", txt: 1 }, { t: "الملاحظات", w: "160px", f: r => r.notes || (r.doc && r.doc.pl ? r.doc.pl.Notes : "") || "", txt: 1 },
      { t: "اليوم", w: "90px", f: r => { const d = new Date(r.date); return isNaN(d) ? "" : DN[d.getDay()]; }, txt: 1 }];
  }
  /* ---------- «المسودات المحفوظة»: استكمال فاتورة محفوظة كمسودة أو عمل استُرجع بعد انقطاع الكهرباء ---------- */
  const ago = s => { const d = new Date(String(s || "").replace(" ", "T")); if (isNaN(d)) return ""; const m = Math.round((Date.now() - d) / 6e4); return m < 1 ? "الآن" : m < 60 ? "منذ " + m + " د" : m < 1440 ? "منذ " + Math.round(m / 60) + " س" : "منذ " + Math.round(m / 1440) + " يوم"; };
  function openDraft(x) {
    const ex = Object.values(DOCS).find(d => d.draftsOf && String(d.draftsOf()) === String(x.id) && document.querySelector(`#tabs .tab[data-key="${d.key}"]`));
    if (ex) { openTab(ex.key, TY[ex.type].tab, "pur"); return Promise.resolve(); }
    return DR.get(x.id).then(g => {
      let sn; try { sn = JSON.parse(g.payload); } catch (e) { throw new Error("بيانات المسودة تالفة"); }
      const t = sn.type || x.type || g.type; if (!TY[t]) throw new Error("نوع المستند غير معروف: " + t);
      const d = openDoc(t, { forceNew: false });
      d.restore(sn, { id: x.id, auto: x.auto, updated: g.updated || x.updated });
      say("📝 استكمال " + (x.title || TY[t].t) + (x.party ? " — " + x.party : "") + " (" + (x.cnt || sn.S.rows.length) + " صنف)", "s");
    }).catch(e => say("تعذّر فتح المسودة: " + ((e && e.message) || e), "e"));
  }
  function draftsDlg() {
    const old = document.querySelector(".drf-ov"); if (old) old.remove();
    const ov = document.createElement("div"); ov.className = "drf-ov";
    ov.innerHTML = `<div class="drf" role="dialog" aria-modal="true" aria-label="المسودات المحفوظة" tabindex="-1">
      <div class="drf-hd"><span class="ic">${I.drafts}</span><div><b>المسودات المحفوظة</b><small>فواتير حُفظت بـ «حفظ التغييرات» أو حُفظت تلقائياً — بدون أي أثر على رصيد الأصناف</small></div><span class="sp"></span><button type="button" class="x" data-x="1" title="إغلاق (Esc)">✕</button></div>
      <div class="drf-q"><input placeholder="بحث بالاسم أو النوع…" autocomplete="off"><span class="n"></span></div>
      <div class="drf-l"><div class="drf-sk"></div><div class="drf-sk"></div></div>
      <div class="drf-ft"><span>💡 <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>S</kbd> يحفظ التغييرات كمسودة في أي وقت، والحفظ التلقائي يعمل كل بضع ثوانٍ ضد انقطاع الكهرباء</span><button type="button" class="cl" data-x="1">إغلاق</button></div></div>`;
    document.body.appendChild(ov);
    const box = ov.querySelector(".drf"), L = ov.querySelector(".drf-l"), q = ov.querySelector(".drf-q input");
    let all = [], view = [], hi = 0;
    const close = () => { ov.remove(); document.removeEventListener("keydown", key, true); };
    const draw = () => {
      const f = norm(q.value); view = all.filter(x => !f || norm([x.title, x.party, TY[x.type] ? TY[x.type].t : x.type, x.user].join(" ")).includes(f));
      if (hi >= view.length) hi = Math.max(0, view.length - 1);
      ov.querySelector(".drf-q .n").textContent = all.length ? view.length + " مسودة" : "";
      L.innerHTML = view.length ? view.map((x, i) => `<div class="drf-r${i === hi ? " on" : ""}" data-i="${i}" style="--c:${(TY[x.type] || {}).c || "#90a4ae"}">
          <span class="tp">${esc(TY[x.type] ? TY[x.type].t : x.type)}</span>
          <span class="nm"><b>${esc(x.party || "تعامل نقدي")}</b><small>${esc(x.title || "")}${x.user ? " · " + esc(x.user) : ""}</small></span>
          <span class="ct"><b>${x.cnt || 0}</b><small>صنف</small></span>
          <span class="tt">${fmt(+x.total || 0)}</span>
          <span class="tm"><b>${esc(ago(x.updated))}</b><small>${esc(String(x.updated || "").slice(0, 16))}</small></span>
          <span class="bd ${x.auto ? "auto" : "man"}">${x.auto ? "⚡ تلقائي" : "💾 يدوي"}</span>
          <span class="ac"><button type="button" class="op" data-op="${i}">استكمال</button><button type="button" class="dl" data-dl="${i}" title="حذف المسودة">✕</button></span></div>`).join("")
        : `<div class="drf-emp"><svg viewBox="0 0 64 64" width="58" height="58"><rect x="12" y="8" width="40" height="48" rx="6" fill="#eef3fb"/><path d="M20 22h24M20 30h24M20 38h14" stroke="#b8c8e2" stroke-width="3" stroke-linecap="round"/></svg><b>${all.length ? "لا توجد مسودة مطابقة" : "لا توجد مسودات محفوظة"}</b><small>اضغط Ctrl+Shift+S داخل أي فاتورة لحفظها كمسودة</small></div>`;
      const on = L.querySelector(".drf-r.on"); if (on) on.scrollIntoView({ block: "nearest" });
    };
    const load = () => DR.list("").then(l => { all = l || []; draw(); }).catch(e => { L.innerHTML = `<div class="drf-emp"><b>تعذّر تحميل المسودات</b><small>${esc((e && e.message) || e)}</small></div>`; });
    const delAt = i => { const x = view[i]; if (!x) return; ask("حذف مسودة «" + (x.party || x.title || "") + "» نهائياً ؟", () => DR.del(x.id).then(() => { Object.values(DOCS).forEach(d => { if (d.draftsOf && String(d.draftsOf()) === String(x.id)) d.dropDraftLink(); }); all = all.filter(z => z !== x); draw(); say("تم حذف المسودة", "s"); }).catch(e => say(e.message, "e"))); };
    const openAt = i => { const x = view[i]; if (!x) return; close(); openDraft(x); };
    ov.addEventListener("click", e => {
      if (e.target === ov || e.target.closest("[data-x]")) { close(); return; }
      const o = e.target.closest("[data-op]"); if (o) { openAt(+o.dataset.op); return; }
      const d = e.target.closest("[data-dl]"); if (d) { delAt(+d.dataset.dl); return; }
      const r = e.target.closest(".drf-r"); if (r) { hi = +r.dataset.i; draw(); }
    });
    L.addEventListener("dblclick", e => { const r = e.target.closest(".drf-r"); if (r && !e.target.closest("button")) openAt(+r.dataset.i); });
    q.addEventListener("input", () => { hi = 0; draw(); });
    function key(e) {
      if (document.getElementById("cfOv") && document.getElementById("cfOv").classList.contains("show")) return;
      const k = e.key;
      if (k === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); close(); }
      else if (k === "ArrowDown" || k === "ArrowUp") { e.preventDefault(); e.stopImmediatePropagation(); hi = Math.max(0, Math.min(view.length - 1, hi + (k === "ArrowDown" ? 1 : -1))); draw(); }
      else if (k === "Enter") { e.preventDefault(); e.stopImmediatePropagation(); openAt(hi); }
      else if (k === "Delete" && e.target !== q) { e.preventDefault(); e.stopImmediatePropagation(); delAt(hi); }
      else if (/^F\d+$/.test(k)) { e.preventDefault(); e.stopImmediatePropagation(); }
    }
    document.addEventListener("keydown", key, true);
    load(); setTimeout(() => q.focus(), 30);
  }
  /* عند تشغيل البرنامج: مسودات موجودة (يدوية أو عمل استُرجع بعد انقطاع) → بطاقة «استكمال» */
  function checkRecovery(n) {
    if (document.querySelector(".drf-rec")) return;
    if (!B() && (n || 0) < 5) { setTimeout(() => checkRecovery((n || 0) + 1), 3000); return; }   // انتظار جاهزية الاتصال بالبرنامج
    DR.list("").then(l => {
      l = (l || []).filter(x => !Object.values(DOCS).some(d => d.draftsOf && String(d.draftsOf()) === String(x.id)));
      if (!l.length) return;
      const a = l.filter(x => x.auto), x = l[0];
      const el = document.createElement("div"); el.className = "drf-rec"; el.setAttribute("role", "alert");
      el.innerHTML = `<span class="ic">${a.length ? "⚡" : "📝"}</span><div class="tx"><b>${a.length ? "تم استرجاع عمل غير محفوظ" : "لديك مسودات محفوظة"}</b><small>${l.length > 1 ? l.length + " مسودات — آخرها: " : ""}${esc(TY[x.type] ? TY[x.type].t : x.type)} · ${esc(x.party || "تعامل نقدي")} · ${x.cnt || 0} صنف · ${fmt(+x.total || 0)} · ${esc(ago(x.updated))}</small></div>
        <button type="button" class="go">استكمال</button>${l.length > 1 ? '<button type="button" class="all">عرض الكل</button>' : ""}<button type="button" class="x" title="لاحقاً">✕</button>`;
      document.body.appendChild(el); requestAnimationFrame(() => el.classList.add("in"));
      const bye = () => { el.classList.remove("in"); setTimeout(() => el.remove(), 250); };
      el.querySelector(".go").onclick = () => { bye(); openDraft(x); };
      const al = el.querySelector(".all"); if (al) al.onclick = () => { bye(); draftsDlg(); };
      el.querySelector(".x").onclick = bye;
    }).catch(() => { if ((n || 0) < 4) setTimeout(() => checkRecovery((n || 0) + 1), 6000); });   // قبل تسجيل الدخول: إعادة المحاولة
  }
  function openSaved(type, id) {
    const ex = Object.values(DOCS).find(d => d.type === type && d.state.id === id && document.querySelector(`#tabs .tab[data-key="${d.key}"]`));
    if (ex) { openTab(ex.key, TY[type].tab, "pur"); return; }
    const d = openDoc(type, { forceNew: false });
    d.open(id);
  }
  function showDetail(type, r) {
    const show = lines => {
      const ov = document.createElement("div"); ov.className = "pu-ov";
      ov.innerHTML = `<div class="pu-dlg wide"><div class="dh"><span>${esc(TY[type].t)} رقم ${esc(r.no)} — ${esc(TY[type].store ? (function () { try { return JSON.parse(r.meta || (r.doc && r.doc.pl.Meta) || "{}").wh || "المخزن الرئيسي"; } catch (e) { return ""; } })() : r.sup || "تعامل نقدي")} — ${esc(r.date)}</span><button type="button" class="dx">✕</button></div>
        <div class="db"><div class="pu-det"><div class="h"><span>#</span><span>الكود</span><span>الصنف</span><span>الوحدة</span><span>الكمية</span><span>السعر</span><span>الاجمالي</span></div>
        ${lines.map((l, i) => `<div class="r"><span>${i + 1}</span><span>${esc(l.code)}</span><span class="t">${esc(l.name)}</span><span>${esc(l.unit)}</span><span>${fmt(l.qty)}</span><span>${fmt(l.price)}</span><span>${fmt(l.total != null ? l.total : l.qty * l.price - (l.disc || 0))}</span></div>`).join("")}
        <div class="f"><span>الاجمالي ${fmt(r.total)}</span>${TY[type].store ? `<span>الكمية ${fmt(r.qty)}</span>` : `<span>المدفوع ${fmt(r.paid)}</span><span>الباقي ${fmt(r.rem)}</span>`}</div></div></div>
        <div class="df"><button type="button" class="pu-bt g" data-open="1">فتح للتعديل</button><button type="button" class="pu-bt b" data-x="1">إغلاق</button></div></div>`;
      document.body.appendChild(ov);
      ov.addEventListener("click", e => { if (e.target === ov || e.target.closest(".dx,[data-x]")) ov.remove(); else if (e.target.closest("[data-open]")) { ov.remove(); openSaved(type, r.id); } });
      ov.addEventListener("keydown", e => { if (e.key === "Escape") { e.stopPropagation(); ov.remove(); } });
      ov.querySelector("[data-x]").focus();
    };
    if (B()) call("fm.pur.get", { id: r.id }).then(h => show(h.lines || [])).catch(e => say(e.message, "e"));
    else { const d = LOCAL.docs.find(x => x.id === r.id); show(d ? d.doc.rows.map(x => ({ code: x.code, name: x.name, unit: x.unit, qty: x.qty, price: x.price, disc: x.disc })) : []); }
  }

  /* ------------------------------------------------------------------ Code128-B (طباعة الباركود) */
  function code128(txt) {
    const P = "212222,222122,222221,121223,121322,131222,122213,122312,132212,221213,221312,231212,112232,122132,122231,113222,123122,123221,223211,221132,221231,213212,223112,312131,311222,321122,321221,312212,322112,322211,212123,212321,232121,111323,131123,131321,112313,132113,132311,211313,231113,231311,112133,112331,132131,113123,113321,133121,313121,211331,231131,213113,213311,213131,311123,311321,331121,312113,312311,332111,314111,221411,431111,111224,111422,121124,121421,141122,141221,112214,112412,122114,122411,142112,142211,241211,221114,413111,241112,134111,111242,121142,121241,114212,124112,124211,411212,421112,421211,212141,214121,412121,111143,111341,131141,114113,114311,411113,411311,113141,114131,311141,411131,211412,211214,211232,2331112".split(",");
    txt = String(txt || "").replace(/[^\x20-\x7e]/g, "") || "0";
    const codes = [104]; for (const ch of txt) codes.push(ch.charCodeAt(0) - 32);
    let sum = 104; for (let i = 1; i < codes.length; i++) sum += codes[i] * i;
    codes.push(sum % 103); codes.push(106);
    let x = 10, bars = "";
    codes.forEach(c => { const p = P[c]; for (let i = 0; i < p.length; i++) { const w = +p[i]; if (i % 2 === 0) bars += `<rect x="${x}" y="0" width="${w}" height="50"/>`; x += w; } });
    return `<svg viewBox="0 0 ${x + 10} 64" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none"><g fill="#000">${bars}</g><text x="${(x + 10) / 2}" y="62" font-size="11" text-anchor="middle" font-family="Arial">${esc(txt)}</text></svg>`;
  }

  /* ------------------------------------------------------------------ واجهة عامة */
  const dl = document.createElement("datalist"); dl.id = "puExpList";
  dl.innerHTML = Array.from(new Set(["نقل", "تحميل وتنزيل", "جمارك", "عمولة", "تأمين", "مصاريف بنكية"].concat(Object.keys(EXPDEF)))).map(x => `<option value="${esc(x)}">`).join("");
  document.body.appendChild(dl);
  /* حسابات المصروفات (شجرة الحسابات ← 3 المصروفات) لنوع «مصروف تتحمله الشركة» */
  const dlc = document.createElement("datalist"); dlc.id = "puCoaExp";
  dlc.innerHTML = COA_EXP.map(x => `<option value="${esc(x)}">`).join("");
  document.body.appendChild(dlc);
  /* القوائم تتبع «شجرة الحسابات» الحيّة: أي حساب يُضاف أو يُعدّل هناك يظهر هنا (حساب الأستاذ / حسابات المصروفات) */
  function liveCoa() {
    try {
      if (!window.__AC || !__AC.coaTree) return;
      __AC.coaTree(true).then(t => {
        if (!t || !t.rows || !t.rows.length) return;
        const leaves = t.rows.filter(n => !n.kids.length);
        const g = G("puGlaList"); if (g) g.innerHTML = leaves.filter(n => n.no.length > 2).map(n => `<option value="${esc(n.name)}">${esc(n.no)}</option>`).join("");
        dlc.innerHTML = leaves.filter(n => /^3/.test(n.no)).map(n => `<option value="${esc(n.name)}">`).join("");
      }).catch(() => { });
    } catch (e) { }
  }
  setTimeout(liveCoa, 2500);
  window.addEventListener("anouer:coa", liveCoa);

  window.ANOUER_PURCHASES = {
    newInvoice: () => openDoc("Purchase"),
    pickItems: o => pickItemsDlg(o || {}),
    slices: SLICES,
    newReturn: () => openDoc("PurchaseReturn"),
    newOrder: () => openDoc("PurchaseOrder"),
    newDoc: type => openDoc(type), types: TY, loadWhs,
    review: type => openTab(TY[type || "Purchase"].rv, TY[type || "Purchase"].rev, TY[type || "Purchase"].rv),
    open: openSaved, docs: DOCS, meta: META, reload: () => Promise.all([loadMeta(), loadSups()]),
    /* «البحث عن تعامل»: حذف مستند محفوظ مع عكس أثره ثم تحديث الشاشات المفتوحة والمراجعات */
    delSaved: (type, id) => (B() ? call("fm.pur.delete", { id }) : Promise.resolve(LOCAL.docs = LOCAL.docs.filter(d => d.id !== id))).then(r => {
      LISTS[type] = null;
      Object.values(DOCS).forEach(d => { try { if (d.state && d.state.id === id) d.reset(); } catch (e) { } });
      try { refreshReviews(); } catch (e) { }
      Promise.all([loadMeta(), loadSups(), WHM().load(true), B() && window.__anouerLink && __anouerLink.loadProducts ? __anouerLink.loadProducts() : null].map(j => Promise.resolve(j).catch(() => { })))
        .then(() => Object.values(DOCS).forEach(d => { try { d.refreshMeta(); } catch (e) { } }));
      try { if (window.ANOUER_SUPPLIERS && ANOUER_SUPPLIERS.reload) ANOUER_SUPPLIERS.reload(); } catch (e) { }
      return r;
    }),
    sups: () => SUPS, drafts: () => draftsDlg(), checkRecovery: () => checkRecovery(),
    /* لوحات المراجعة الجانبية (review-panes.js): الشبكة الحالية (بعد التصفية) وكل السجلات */
    revS: t => REV[t] ? REV[t].S : null, revData: t => REV[t] ? REV[t].data || [] : (LISTS[t] || [])
  };

  loadSettings();
  Promise.all([loadMeta(), loadSups()]);
  setTimeout(() => checkRecovery(), 3500);
  // الموردون الجدد من شاشة الموردين
  window.addEventListener("anouer:suppliers", () => loadSups().then(() => Object.values(DOCS).forEach(d => { if (d.awaitSup) { d.awaitSup = false; } d.renderAll(); })));
})();
