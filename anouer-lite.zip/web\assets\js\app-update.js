/* ANOUER — «تحديث البرنامج» (نسخ العملاء PRO / LITE) 2026
   - يتحقق وحده عند التشغيل (مرة كل 6 ساعات) ويُظهر شارة «تحديث جديد» صغيرة — بدون إزعاج.
   - نافذة التحديث: النسخة الحالية ← الجديدة، ما الجديد، الحجم، ثم «تحديث الآن»: تنزيل + تحقق SHA-256 + تثبيت + إعادة تشغيل.
   - لا حذف ولا تثبيت من جديد: بياناتك، تفعيلاتك ونوع نسختك (LITE / PRO) تبقى كما هي — والتحديث لا يفتح أي ميزة مدفوعة.
   - المضيف: fm.update.check / fm.update.download / fm.update.install (AppUpdate.cs). */
(function () {
  "use strict";
  if (window.ANOUER_UPDATE) return;
  const ED = window.ANOUER_EDITION || {};
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const call = (a, p) => Anouer.call(a, p || {});
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const say = (m, k) => { try { (window.say || window.toast || console.log)(m, k || "i"); } catch (e) { } };
  const snd = k => { try { window.ANOUER_SOUND && ANOUER_SOUND(k); } catch (e) { } };
  const LSK = "anouer.upd.at", HIDE = "anouer.upd.hide";
  const mb = n => (n / 1048576).toFixed(1).replace(/\.0$/, "") + " MB";
  const edName = () => ED.lite ? "ANOUER LITE" : "ANOUER PRO";
  let INFO = null, BUSY = false;

  (function css() {
    const st = document.createElement("style"); st.id = "updCss";
    st.textContent = `
.upd-ov{position:fixed;inset:0;z-index:100050;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,.38);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);animation:updF .18s ease-out}
@keyframes updF{from{opacity:0}}@keyframes updU{from{transform:translateY(14px) scale(.98);opacity:0}}
.upd-w{width:460px;max-width:calc(100vw - 32px);border-radius:20px;background:rgba(255,255,255,.92);border:1px solid rgba(255,255,255,.8);box-shadow:0 30px 80px -24px rgba(15,23,42,.55),inset 0 1px 0 #fff;overflow:hidden;font:13px "Segoe UI",Tahoma,sans-serif;color:#0f172a;direction:rtl;animation:updU .24s cubic-bezier(.2,1,.3,1)}
.upd-hd{position:relative;padding:22px 22px 18px;background:radial-gradient(120% 120% at 100% 0%,#ffe8d6 0%,transparent 55%),radial-gradient(120% 120% at 0% 0%,#e3ecff 0%,transparent 55%),#fbfaf8;border-bottom:1px solid #eef0f3;display:flex;gap:14px;align-items:center}
.upd-lg{width:52px;height:52px;border-radius:16px;flex:none;display:grid;place-items:center;background:linear-gradient(145deg,#fb923c,#ea580c 60%,#c2410c);box-shadow:inset 0 1px 0 rgba(255,255,255,.45),0 12px 24px -12px rgba(234,88,12,.7)}
.upd-lg svg{width:28px;height:28px}
.upd-hd h3{margin:0;font-size:17px;font-weight:700}.upd-hd small{display:block;color:#5b6478;font-size:12px;margin-top:2px}
.upd-x{position:absolute;top:12px;left:12px;width:30px;height:30px;border:0;border-radius:10px;background:transparent;color:#64748b;font-size:16px;cursor:pointer}.upd-x:hover{background:#eef1f5;color:#0f172a}
.upd-bd{padding:16px 22px 6px;display:flex;flex-direction:column;gap:12px}
.upd-vv{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:10px}
.upd-v{padding:10px 12px;border-radius:14px;border:1px solid #e6e9ee;background:#fff;text-align:center}
.upd-v small{display:block;font-size:11px;color:#64748b}.upd-v b{display:block;font:700 16px Consolas,monospace;direction:ltr;margin-top:2px}
.upd-v.nw{border-color:#bbf7d0;background:linear-gradient(180deg,#f0fdf4,#fff)}.upd-v.nw b{color:#15803d}
.upd-ar{color:#94a3b8;font-size:18px}
.upd-nt{max-height:170px;overflow:auto;margin:0;padding:10px 14px;border-radius:14px;background:#f8fafc;border:1px solid #eef1f5;list-style:none;display:flex;flex-direction:column;gap:6px}
.upd-nt li{display:flex;gap:8px;line-height:1.5}.upd-nt li:before{content:"";width:6px;height:6px;border-radius:50%;background:#ea580c;margin-top:7px;flex:none}
.upd-sf{display:flex;gap:8px;align-items:flex-start;padding:9px 12px;border-radius:12px;background:#ecfdf5;border:1px solid #d1fae5;color:#065f46;font-size:12px;line-height:1.5}
.upd-sf svg{width:16px;height:16px;flex:none;margin-top:1px}
.upd-pg{height:6px;border-radius:6px;background:#eef1f5;overflow:hidden;display:none}.upd-pg i{display:block;height:100%;width:35%;border-radius:6px;background:linear-gradient(90deg,#fb923c,#ea580c);animation:updL 1.1s ease-in-out infinite}
@keyframes updL{0%{transform:translateX(320%)}100%{transform:translateX(-120%)}}
.upd-w.busy .upd-pg{display:block}
.upd-st{min-height:18px;font-size:12px;color:#475569;text-align:center}
.upd-st.u-ok{color:#15803d;font-weight:600;background:none}.upd-st.u-er{color:#b91c1c;font-weight:600;background:none}
.upd-ft{display:flex;gap:8px;padding:12px 22px 20px}
.upd-ft button{height:44px;border-radius:13px;font:inherit;font-size:14px;font-weight:700;cursor:pointer;transition:transform .12s,filter .15s}
.upd-ft button:active{transform:scale(.97)}
.upd-go{flex:1;border:0;color:#fff;background:linear-gradient(145deg,#fb923c,#ea580c 55%,#c2410c);box-shadow:inset 0 1px 0 rgba(255,255,255,.35),0 12px 24px -14px rgba(234,88,12,.8)}
.upd-go[disabled]{filter:grayscale(.5) opacity(.6);cursor:default}
.upd-lt{padding:0 18px;border:1px solid #e2e8f0;background:#fff;color:#334155}
.upd-pill{position:fixed;bottom:16px;left:16px;z-index:100040;display:flex;align-items:center;gap:8px;height:40px;padding:0 14px 0 10px;border:1px solid rgba(255,255,255,.8);border-radius:999px;background:rgba(255,255,255,.86);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);box-shadow:0 14px 34px -14px rgba(15,23,42,.45);font:600 12.5px "Segoe UI",Tahoma,sans-serif;color:#0f172a;cursor:pointer;direction:rtl;animation:updU .3s cubic-bezier(.2,1,.3,1)}
.upd-pill i{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(145deg,#22c55e,#15803d);color:#fff;font-style:normal;font-size:13px}
.upd-pill b{font:700 12px Consolas,monospace;color:#15803d;direction:ltr}
.upd-pill .cl{margin-inline-start:4px;color:#94a3b8;font-size:14px;padding:0 2px}.upd-pill .cl:hover{color:#0f172a}
:root.dark .upd-w,:root[data-theme="dark"] .upd-w{background:rgba(17,22,36,.94);color:#eef2fb;border-color:rgba(255,255,255,.1)}`;
    document.head.appendChild(st);
  })();

  const LOGO = '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11"/><path d="m7 10 5 5 5-5"/><path d="M5 19h14"/></svg>';
  const SHIELD = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3l7.5 3v5.5c0 4.6-3.2 8.2-7.5 9.5-4.3-1.3-7.5-4.9-7.5-9.5V6z"/><path d="m8.8 12.2 2.3 2.3 4.2-4.6" stroke-linecap="round"/></svg>';

  function check(force) {
    if (!HOST()) return Promise.resolve(null);
    return call("fm.update.check").then(r => { INFO = r; try { localStorage.setItem(LSK, String(Date.now())); } catch (e) { } return r; });
  }

  function open() {
    if (document.querySelector(".upd-ov")) return;
    const ov = document.createElement("div"); ov.className = "upd-ov";
    ov.innerHTML = `<div class="upd-w" role="dialog" aria-modal="true" aria-label="تحديث البرنامج">
      <div class="upd-hd"><span class="upd-lg">${LOGO}</span><div><h3>تحديث البرنامج</h3><small>${esc(edName())} — تحديث مباشر بدون حذف ولا تثبيت من جديد</small></div><button type="button" class="upd-x" aria-label="إغلاق">✕</button></div>
      <div class="upd-bd"><div class="upd-st">جارٍ البحث عن تحديث …</div></div>
      <div class="upd-ft"><button type="button" class="upd-go" disabled>تحديث الآن</button><button type="button" class="upd-lt">لاحقاً</button></div></div>`;
    document.body.appendChild(ov);
    const W = ov.querySelector(".upd-w"), bd = ov.querySelector(".upd-bd"), go = ov.querySelector(".upd-go");
    const close = () => { if (BUSY) return; ov.remove(); };
    ov.querySelector(".upd-x").onclick = close; ov.querySelector(".upd-lt").onclick = close;
    ov.addEventListener("mousedown", e => { if (e.target === ov) close(); });
    const st = (t, c) => { const s = bd.querySelector(".upd-st"); if (s) { s.className = "upd-st" + (c ? " " + c : ""); s.textContent = t; } };
    const draw = r => {
      if (!r) { bd.innerHTML = `<div class="upd-st u-er">التحديث يعمل داخل البرنامج فقط.</div>`; return; }
      if (r.dev) { bd.innerHTML = `<div class="upd-sf">${SHIELD}<span>هذه نسختك الخاصة (التطوير) — التحديث المباشر يخص نسخ العملاء PRO و LITE فقط.</span></div><div class="upd-st"></div>`; return; }
      const notes = Array.isArray(r.notes) ? r.notes : r.notes ? String(r.notes).split(/\n+/) : [];
      bd.innerHTML = `<div class="upd-vv"><div class="upd-v"><small>نسختك الحالية</small><b>${esc(r.current)}</b></div><span class="upd-ar">←</span><div class="upd-v ${r.newer ? "nw" : ""}"><small>${r.newer ? "النسخة الجديدة" : "آخر نسخة"}</small><b>${esc(r.latest || r.current)}</b></div></div>
        ${r.newer && notes.length ? `<ul class="upd-nt">${notes.map(n => `<li>${esc(n)}</li>`).join("")}</ul>` : ""}
        ${r.newer ? `<div class="upd-sf">${SHIELD}<span>بياناتك وفواتيرك وتفعيلاتك تبقى كما هي، ونوع نسختك (${esc(edName())}) لا يتغيّر. تُحفظ نسخة احتياطية قبل التحديث، ويُعاد تشغيل البرنامج وحده.</span></div>` : ""}
        <div class="upd-pg"><i></i></div><div class="upd-st ${r.newer ? "" : "u-ok"}">${r.newer ? "الحجم: <bdi>" + mb(r.size || 0) + "</bdi>" + (r.date ? " · <bdi>" + esc(r.date) + "</bdi>" : "") : "✓ برنامجك محدَّث — آخر نسخة"}</div>`;
      go.disabled = !r.newer; go.textContent = r.newer ? "تحديث الآن" : "محدَّث ✓";
    };
    check(true).then(draw).catch(e => { bd.innerHTML = `<div class="upd-st u-er">تعذّر الاتصال بخادم التحديثات — تأكد من الإنترنت ثم أعد المحاولة.</div>`; go.disabled = false; go.textContent = "إعادة المحاولة"; go.onclick = () => { ov.remove(); open(); }; });
    go.onclick = () => {
      if (!INFO || !INFO.newer || BUSY) return;
      BUSY = true; W.classList.add("busy"); go.disabled = true; ov.querySelector(".upd-lt").disabled = true;
      st("جارٍ تنزيل التحديث والتحقق من سلامته …");
      call("fm.update.download").then(d => {
        st("✓ تم التنزيل (" + mb(d.size || 0) + ") — جارٍ التثبيت، سيُغلق البرنامج ويُعاد تشغيله …", "u-ok"); snd("ok");
        return new Promise(res => setTimeout(res, 900)).then(() => call("fm.update.install"));
      }).catch(e => {
        BUSY = false; W.classList.remove("busy"); go.disabled = false; ov.querySelector(".upd-lt").disabled = false; snd("err");
        const m = String(e && e.message || e);
        st(/canceled|ألغ|cancel/i.test(m) ? "أُلغي التثبيت — يلزم موافقة «المسؤول» لتحديث الملفات." : m.replace(/^Error:\s*/, ""), "u-er");
      });
    };
  }

  /* شارة «تحديث جديد» */
  function pill(r) {
    if (!r || !r.newer || document.querySelector(".upd-pill")) return;
    try { if (localStorage.getItem(HIDE) === r.latest) return; } catch (e) { }
    const p = document.createElement("div"); p.className = "upd-pill"; p.setAttribute("role", "button"); p.tabIndex = 0;
    p.innerHTML = `<i>↓</i><span>تحديث جديد متوفر</span><b>${esc(r.latest)}</b><span class="cl" title="إخفاء">✕</span>`;
    p.onclick = e => { if (e.target.classList.contains("cl")) { try { localStorage.setItem(HIDE, r.latest); } catch (x) { } p.remove(); return; } p.remove(); open(); };
    document.body.appendChild(p);
  }
  function auto() {
    if (!ED.dist || !HOST()) return;
    check().then(pill).catch(() => { });   /* طلب صغير واحد عند التشغيل ثم كل 6 ساعات */
  }
  setTimeout(auto, 15000);
  setInterval(auto, 6 * 3600e3);

  window.ANOUER_UPDATE = { open, check };
})();
