/* ==========================================================================
   «صورة إعلانية» — محرر مستقل بأسلوب فوتوشوب (ANOUER 2026)
   مربع «صورة إعلانية» في بطاقة الصنف ← نافذة من مرحلتين:
     1) الصورة والقص: كاميرا / ملف / لصق / صورة الصنف الحالية ، تدوير 90° وقلب ،
        إزالة الخلفية تلقائياً + ممحاة سحرية (نقرة تمسح كل لون متشابه) + فرشاة مسح / استرجاع بحواف ناعمة ،
        تنعيم / تقليص / توسيع الحافة ، عكس ، تراجع وإعادة (Ctrl+Z / Ctrl+Y) ، تكبير بالعجلة وتحريك بالمسافة.
     2) التركيب: المنتج طبقة مستقلة فوق الخلفية — سحب ، تكبير (العجلة) ، تدوير ، قلب ، ظل ، انعكاس ، دمج مع إضاءة المشهد ،
        سطوع / تباين / تشبّع ؛ الخلفية: مشهد مرسوم من اسم الصنف (ad-scene.js) أو صورة حقيقية من جهازك أو لون ؛ العنوان قابل للتعديل.
   ثم «اعتماد للصنف» (1600 أو 2000 بكسل) أو تنزيل الصورة. كل شيء يعمل بدون إنترنت.
   ========================================================================== */
(function () {
  "use strict";
  if (window.ANOUER_ADSTUDIO) return;
  const G = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const say = (m, t) => { try { if (typeof toast === "function") toast(m, t || "i"); else console.log(m); } catch (e) { } };
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
  const mk = (w, h) => { const c = document.createElement("canvas"); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h)); return c; };
  const loadImg = src => new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => no(new Error("تعذّر فتح الصورة")); i.src = src; });
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  const W0 = 1600, S = 2000, PS = 1000;   // دقة العمل للصورة ، دقة المشهد ، دقة المعاينة

  const IC = {
    logo: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5l1.9 5.3 5.3 1.9-5.3 1.9L12 16.9l-1.9-5.3-5.3-1.9 5.3-1.9zM18.5 14l.9 2.4 2.4.9-2.4.9-.9 2.4-.9-2.4-2.4-.9 2.4-.9z"/></svg>',
    box: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M9.5 8.5h5v7h-5z" fill="currentColor" stroke="none" opacity=".5"/></svg>',
    wand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 20 15 9"/><path d="m13 7 4 4"/><path d="M18 2.5v3M16.5 4h3M20.5 8.5v2M19.5 9.5h2M10.5 2.5v2M9.5 3.5h2"/></svg>',
    erase: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><path d="m15.5 4.5 4 4-9.5 9.5H6l-2-2a1.4 1.4 0 0 1 0-2z"/><path d="M10 20h10M9 9l5 5"/></svg>',
    restore: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M18.5 4.5c-2 2.6-5.5 7-8.6 9.6"/><path d="M9.9 14.1c-1.6-.6-3.4.2-4 1.9-.5 1.5-.3 3-1.9 3.9 2.7 1 6.3.4 7.4-1.6.8-1.4.1-3.4-1.5-4.2z"/></svg>',
    hand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M8 13V5.5a1.5 1.5 0 0 1 3 0V12M11 11V4a1.5 1.5 0 0 1 3 0v7M14 11V5.5a1.5 1.5 0 0 1 3 0V13M17 9.5a1.5 1.5 0 0 1 3 0V14a7 7 0 0 1-7 7h-1a6 6 0 0 1-5-2.7L4.3 15a1.6 1.6 0 0 1 2.6-1.9L8 14.5"/></svg>',
    move: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v18M3 12h18M9 6l3-3 3 3M9 18l3 3 3-3M6 9l-3 3 3 3M18 9l3 3-3 3"/></svg>',
    rotL: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4.5 9A8 8 0 1 1 4 14"/><path d="M4 4v5h5"/></svg>',
    rotR: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M19.5 9A8 8 0 1 0 20 14"/><path d="M20 4v5h-5"/></svg>',
    flip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><path d="M12 3v18" stroke-dasharray="2 2"/><path d="M9 7 3 17h6zM15 7l6 10h-6z"/></svg>',
    undo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/></svg>',
    redo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="m15 14 5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/></svg>',
    fit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
    cam: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><path d="M4 8.5A1.5 1.5 0 0 1 5.5 7h2l1.4-2h6.2L16.5 7h2A1.5 1.5 0 0 1 20 8.5v9A1.5 1.5 0 0 1 18.5 19h-13A1.5 1.5 0 0 1 4 17.5z"/><circle cx="12" cy="12.5" r="3.4"/></svg>',
    phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="7" y="2.8" width="10" height="18.4" rx="2.2"/><path d="M10.5 18h3"/></svg>',
    file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><path d="M4 6.5A1.5 1.5 0 0 1 5.5 5h13A1.5 1.5 0 0 1 20 6.5v11a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 17.5z"/><path d="m4.5 16 4.5-4.5 3.5 3.5 2.5-2.5 4.5 4.5"/><circle cx="15.5" cy="9.5" r="1.4"/></svg>',
    img: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 13l2.5 2.5L16 10"/></svg>',
    auto: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5l1.9 5.3 5.3 1.9-5.3 1.9L12 16.9l-1.9-5.3-5.3-1.9 5.3-1.9z"/></svg>',
    ok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>',
    dl: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M12 4v11M7.5 10.5 12 15l4.5-4.5M5 19.5h14"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>'
  };

  let E = null;
  const Q = k => E && E.ov.querySelector('[data-k="' + k + '"]');

  /* ================================================================ النافذة */
  function open() {
    if (E) { E.ov.focus(); return; }
    if (!window.ANOUER_ADSCENE) { say("محرك الخلفيات غير محمّل", "e"); return; }
    const ov = document.createElement("div"); ov.className = "as-ov"; ov.tabIndex = -1;
    ov.innerHTML = `<div class="as-dlg" role="dialog" aria-label="صورة إعلانية للصنف">
  <header class="as-hd">
    <span class="as-logo">${IC.logo}</span>
    <div class="as-ttl"><b>صورة إعلانية</b><small>محرر احترافي — قصّ المنتج بدقة ثم ركّبه على خلفية من اسم الصنف</small></div>
    <nav class="as-steps"><button type="button" data-v="cut" class="on"><i>1</i>الصورة والقص</button><button type="button" data-v="comp"><i>2</i>التركيب والخلفية</button></nav>
    <button type="button" class="as-x" data-a="close" title="إغلاق (Esc)">${IC.x}</button>
  </header>
  <div class="as-bd">
    <nav class="as-tools" data-k="tools">
      <div data-g="cut">
        <button type="button" data-t="box" title="تحديد المنتج (M): ارسم مستطيلاً حول المنتج — يُمسح كل ما خارجه ويُعزل المنتج داخله">${IC.box}</button>
        <button type="button" data-t="wand" class="on" title="الممحاة السحرية (W): انقر على الخلفية فتُمسح كل الألوان المتشابهة — مع Shift تسترجع">${IC.wand}</button>
        <button type="button" data-t="erase" title="فرشاة المسح (E)">${IC.erase}</button>
        <button type="button" data-t="restore" title="فرشاة الاسترجاع (R)">${IC.restore}</button>
        <button type="button" data-t="hand" title="تحريك العرض (H) — أو اضغط المسافة واسحب">${IC.hand}</button>
      </div>
      <div data-g="comp" hidden><button type="button" data-t="move" class="on" title="تحريك المنتج (V) — العجلة للتكبير">${IC.move}</button></div>
      <span class="as-sep"></span>
      <button type="button" data-a="rotL" title="تدوير 90° يساراً">${IC.rotL}</button>
      <button type="button" data-a="rotR" title="تدوير 90° يميناً">${IC.rotR}</button>
      <button type="button" data-a="flipSrc" title="قلب أفقي">${IC.flip}</button>
      <span class="as-sep"></span>
      <button type="button" data-a="undo" title="تراجع (Ctrl+Z)">${IC.undo}</button>
      <button type="button" data-a="redo" title="إعادة (Ctrl+Y)">${IC.redo}</button>
      <button type="button" data-a="fit" title="ملاءمة العرض (0)">${IC.fit}</button>
    </nav>
    <main class="as-stage" data-k="stage">
      <canvas data-k="cv"></canvas>
      <div class="as-empty" data-k="empty">
        <div class="as-drop">${IC.file}<b>صوّر المنتج أو اختر صورته</b><small>أو الصق الصورة (Ctrl+V) أو اسحبها إلى هنا</small>
          <div class="as-srcs"><button type="button" data-a="phone">${IC.phone}من الهاتف</button><button type="button" data-a="cam">${IC.cam}كاميرا الحاسوب</button><button type="button" data-a="file">${IC.file}من ملف</button><button type="button" data-a="cur" data-k="curBtn" hidden>${IC.img}صورة الصنف الحالية</button></div>
          <ul><li>للعزل التلقائي النظيف: ضع المنتج على ورقة بيضاء أو طاولة بلون واحد</li><li>الخلفية المزدحمة؟ امسحها بالممحاة السحرية والفرشاة مثل فوتوشوب</li></ul></div>
      </div>
      <div class="as-cam" data-k="camBox" hidden><video data-k="video" autoplay playsinline muted></video>
        <div class="as-cambar"><select data-k="dev"></select><button type="button" class="as-shot" data-a="shot" title="التقاط (المسافة)"><i></i></button><button type="button" data-a="camX">إلغاء</button></div></div>
      <div class="as-phone" data-k="phoneBox" hidden>
        <div class="as-phc"><div class="as-qr" data-k="qr"><i class="as-qsp"></i></div>
          <div class="as-pht"><b>${IC.phone}صوّر المنتج بكاميرا هاتفك</b>
            <ol><li>اربط الهاتف بنفس شبكة <b>Wi-Fi</b> الحاسوب.</li><li>امسح الرمز بكاميرا الهاتف ← تفتح صفحة ANOUER.</li><li>صوّر المنتج — تصل الصورة هنا تلقائياً وتبدأ إزالة الخلفية.</li></ol>
            <div class="as-url" data-k="url"></div><small>كاميرا الهاتف أوضح بكثير من كاميرا الحاسوب ✓ — يمكنك إرسال صورة أخرى في أي وقت لتحلّ محل الحالية</small>
            <button type="button" class="as-b" data-a="phoneX">إغلاق</button></div></div></div>
      <div class="as-busy" data-k="busy" hidden><i></i><span></span></div>
      <div class="as-zoom" data-k="zoomLbl"></div>
      <input type="file" accept="image/*" data-k="file" hidden><input type="file" accept="image/*" data-k="bgFile" hidden>
    </main>
    <aside class="as-panel" data-k="panel">
      <div data-g="cut">
        <section><h4>الصورة</h4><div class="as-row3"><button type="button" class="as-b" data-a="phone">${IC.phone}الهاتف</button><button type="button" class="as-b" data-a="cam">${IC.cam}الكاميرا</button><button type="button" class="as-b" data-a="file">${IC.file}ملف</button></div></section>
        <section><h4>إزالة الخلفية</h4>
          <button type="button" class="as-big" data-a="autoCut">${IC.auto}<span>إزالة تلقائية</span></button>
          <small class="as-note" data-k="cutNote"></small>
          <button type="button" class="as-b as-w" data-a="boxTool">${IC.box}خلفية مزدحمة؟ حدّد المنتج بمستطيل</button>
          <div class="as-row2"><button type="button" class="as-b" data-a="keepAll" title="إلغاء كل المسح">إظهار الكل</button><button type="button" class="as-b" data-a="invert" title="عكس: ما مُسح يظهر وما ظهر يُمسح">عكس</button></div>
        </section>
        <section data-k="wandSec"><h4>الممحاة السحرية</h4>
          <label class="as-sl"><span>التسامح</span><input type="range" min="4" max="90" value="30" data-k="tol"><output data-k="tolV">30</output></label>
          <label class="as-ck"><input type="checkbox" data-k="cont" checked>المناطق المتصلة فقط</label>
          <small class="as-note">انقر على الخلفية لمسحها — <b>Shift</b>+نقرة لاسترجاع منطقة</small>
        </section>
        <section data-k="brushSec" hidden><h4>الفرشاة</h4>
          <label class="as-sl"><span>الحجم</span><input type="range" min="4" max="240" value="40" data-k="bsz"><output data-k="bszV">40</output></label>
          <label class="as-sl"><span>الصلابة</span><input type="range" min="0" max="100" value="60" data-k="bhd"><output data-k="bhdV">60</output></label>
          <small class="as-note">[ و ] لتغيير الحجم</small>
        </section>
        <section><h4>الحافة</h4>
          <div class="as-row3"><button type="button" class="as-b" data-a="feather">تنعيم</button><button type="button" class="as-b" data-a="shrink">تقليص</button><button type="button" class="as-b" data-a="grow">توسيع</button></div>
          <label class="as-ck"><input type="checkbox" data-k="ghost" checked>إظهار الجزء الممسوح باهتاً</label>
        </section>
        <button type="button" class="as-next" data-a="toComp">التالي: التركيب والخلفية ←</button>
      </div>
      <div data-g="comp" hidden>
        <section><h4>الخلفية</h4>
          <div class="as-seg as-seg4" data-k="bgKind"><button type="button" data-bk="real" class="on">حقيقية تلقائية</button><button type="button" data-bk="scene">مرسومة</button><button type="button" data-bk="photo">من جهازك</button><button type="button" data-bk="color">لون</button></div>
          <div data-bkp="real scene"><select data-k="theme"></select></div>
          <div data-bkp="real"><div class="as-rl" data-k="rlist"></div>
            <div class="as-row2"><button type="button" class="as-b" data-a="realNext">${IC.rotR}صورة أخرى</button><button type="button" class="as-b" data-a="realMore">المزيد من الصور</button></div>
            <label class="as-sl"><span>العمق</span><input type="range" min="0" max="30" value="14" data-k="dof"><output data-k="dofV">14</output></label>
            <small class="as-note" data-k="realNote">صور فوتوغرافية حقيقية حرة الاستعمال (CC0) — تُختار تلقائياً من نوع الصنف</small></div>
          <div data-bkp="scene"><button type="button" class="as-b as-w" data-a="reseed">${IC.rotR}شكل آخر</button></div>
          <div data-bkp="photo" hidden><button type="button" class="as-b as-w" data-a="bgPick">${IC.file}اختر صورة الخلفية من جهازك</button>
            <label class="as-sl"><span>ضبابية</span><input type="range" min="0" max="30" value="8" data-k="bgBlur"><output data-k="bgBlurV">8</output></label>
            <small class="as-note">صوّر طاولة أو رفاً أو مكاناً جميلاً بدون المنتج ، ثم اختره هنا</small></div>
          <div data-bkp="color" hidden><div class="as-sw" data-k="sw"></div></div>
        </section>
        <section><h4>النص</h4>
          <label class="as-ck"><input type="checkbox" data-k="tOn" checked>إظهار العنوان</label>
          <input type="text" class="as-in" data-k="head" maxlength="34" placeholder="العنوان">
          <input type="text" class="as-in" data-k="sub" maxlength="40" placeholder="السطر الثاني (اسم الصنف)">
        </section>
        <section><h4>المنتج</h4>
          <label class="as-sl"><span>الحجم</span><input type="range" min="20" max="180" value="100" data-k="psz"><output data-k="pszV">100%</output></label>
          <label class="as-sl"><span>الدوران</span><input type="range" min="-45" max="45" value="0" data-k="prot"><output data-k="protV">0°</output></label>
          <div class="as-row2"><button type="button" class="as-b" data-a="center">توسيط على الطاولة</button><button type="button" class="as-b" data-a="flipP">قلب المنتج</button></div>
          <label class="as-sl"><span>الظل</span><input type="range" min="0" max="100" value="65" data-k="shd"><output data-k="shdV">65</output></label>
          <label class="as-ck"><input type="checkbox" data-k="refl">انعكاس على السطح</label>
          <label class="as-ck"><input type="checkbox" data-k="blend" checked>دمج مع إضاءة الخلفية</label>
        </section>
        <section><h4>الإضاءة واللون</h4>
          <label class="as-sl"><span>السطوع</span><input type="range" min="60" max="150" value="100" data-k="br"><output data-k="brV">100</output></label>
          <label class="as-sl"><span>التباين</span><input type="range" min="60" max="160" value="105" data-k="ct"><output data-k="ctV">105</output></label>
          <label class="as-sl"><span>التشبّع</span><input type="range" min="0" max="200" value="110" data-k="st"><output data-k="stV">110</output></label>
        </section>
        <section class="as-out"><label>الدقة <select data-k="osz"><option value="1600">1600×1600</option><option value="2000">2000×2000</option></select></label>
          <button type="button" class="as-apply" data-a="apply">${IC.ok}<span>اعتماد للصنف</span></button>
          <button type="button" class="as-b as-w" data-a="download">${IC.dl}تنزيل الصورة</button></section>
      </div>
    </aside>
  </div></div>`;
    document.body.appendChild(ov);
    E = {
      ov, view: "cut", tool: "wand", src: null, m: null, W: 0, H: 0, maskCv: null, undo: [], redo: [], ver: 0, pver: -1, prod: null, pbox: null,
      z: 1, px: 0, py: 0, mouse: null, drag: null, space: false,
      opt: { tol: 30, cont: true, bsz: 40, bhd: 60, ghost: true },
      bg: { kind: ["scene", "color", "real"].includes(lsGet("as.bgk", "real")) ? lsGet("as.bgk", "real") : "real", theme: "auto", seed: 0, photo: null, blur: 8, dof: 14, color: lsGet("as.col", "#f3ece2") },
      real: { q: "", list: [], page: 1, idx: 0, img: null, busy: false, err: "" },
      txt: { on: true, head: "", sub: null },
      pt: null, adj: { br: 100, ct: 105, st: 110, shd: 65, refl: false, blend: true, flip: false, rot: 0 },
      layers: null, lkey: "", padj: null, pakey: ""
    };
    const th = window.ANOUER_ADSCENE.themes();
    Q("theme").innerHTML = '<option value="auto">✨ تلقائي من اسم الصنف</option>' + th.map(t => `<option value="${t[0]}">${t[2]} ${esc(t[1])}</option>`).join("");
    const COLS = ["#f3ece2", "#ffffff", "#f6e7ee", "#e7f1fb", "#e8f5ea", "#fff4d6", "#2b2f3a", "#1d1410", "#5b2b6e", "#0f3d3e"];
    Q("sw").innerHTML = COLS.map(c => `<button type="button" data-col="${c}" style="background:${c}" title="${c}"></button>`).join("") + `<label title="لون آخر"><input type="color" data-k="colIn" value="${E.bg.color}"></label>`;
    try { if (window.__itImg && __itImg.get()) Q("curBtn").hidden = false; } catch (e) { }
    const cv = Q("cv"); E.cv = cv; E.cx = cv.getContext("2d");
    ov.addEventListener("click", onClick);
    ov.addEventListener("input", onInput);
    ov.addEventListener("change", onInput);
    ov.addEventListener("keydown", onKey);
    ov.addEventListener("keyup", e => { if (e.code === "Space" && E) { E.space = false; cursor(); } });
    ov.addEventListener("paste", onPaste);
    const st = Q("stage");
    st.addEventListener("dragover", e => { e.preventDefault(); st.classList.add("over"); });
    st.addEventListener("dragleave", () => st.classList.remove("over"));
    st.addEventListener("drop", e => { e.preventDefault(); st.classList.remove("over"); const f = e.dataTransfer.files && e.dataTransfer.files[0]; if (f && /^image\//.test(f.type)) fromBlob(f); });
    cv.addEventListener("pointerdown", pDown); cv.addEventListener("pointermove", pMove); cv.addEventListener("pointerup", pUp); cv.addEventListener("pointercancel", pUp);
    cv.addEventListener("pointerleave", () => { if (E) { E.mouse = null; draw(); } });
    cv.addEventListener("wheel", onWheel, { passive: false });
    E.ro = new ResizeObserver(() => { if (E) { sizeCv(); if (E.view === "cut") fitView(true); draw(); } }); E.ro.observe(st);
    syncUi(); setView("cut");
    requestAnimationFrame(() => ov.classList.add("show")); ov.focus();
  }
  function close() {
    if (!E) return; stopCam(); stopPhone(); try { E.ro.disconnect(); } catch (e) { }
    const ov = E.ov; E = null; ov.classList.remove("show"); setTimeout(() => ov.remove(), 180);
  }
  const busy = (t) => { const b = Q("busy"); if (!b) return; b.hidden = !t; if (t) b.querySelector("span").textContent = t; };
  const note = (t, cls) => { const n = Q("cutNote"); if (n) { n.textContent = t || ""; n.className = "as-note" + (cls ? " as-n-" + cls : ""); } };

  /* ================================================================ المصدر */
  function fromBlob(f) { const r = new FileReader(); r.onload = () => setSrc(String(r.result)); r.onerror = () => say("تعذّر قراءة الصورة", "e"); r.readAsDataURL(f); }
  async function setSrc(url) {
    let im; try { im = await loadImg(url); } catch (e) { say(e.message, "e"); return; }
    if (!E) return;
    const k = Math.min(1, W0 / Math.max(im.naturalWidth, im.naturalHeight)), c = mk(im.naturalWidth * k, im.naturalHeight * k), x = c.getContext("2d");
    x.imageSmoothingQuality = "high"; x.drawImage(im, 0, 0, c.width, c.height);
    E.src = c; E.W = c.width; E.H = c.height; E.sd = x.getImageData(0, 0, E.W, E.H).data;
    E.m = new Uint8Array(E.W * E.H).fill(255); E.maskCv = mk(E.W, E.H); E.undo = []; E.redo = []; E.pt = null; E.adj.rot = 0; E.adj.flip = false;
    maskAll(); Q("empty").hidden = true; stopCam(); setView("cut"); fitView(); draw();
    autoCut();   // يبدأ تلقائياً ، ويمكن التصحيح يدوياً
  }
  /* تدوير / قلب الصورة الأصلية مع القناع */
  function transformSrc(kind) {
    if (!E.src) return;
    const rot = (cv) => { const c = kind === "flip" ? mk(cv.width, cv.height) : mk(cv.height, cv.width), x = c.getContext("2d");
      if (kind === "flip") { x.translate(c.width, 0); x.scale(-1, 1); }
      else if (kind === "R") { x.translate(c.width, 0); x.rotate(Math.PI / 2); }
      else { x.translate(0, c.height); x.rotate(-Math.PI / 2); }
      x.drawImage(cv, 0, 0); return c; };
    E.src = rot(E.src); const mc = rot(E.maskCv); E.W = E.src.width; E.H = E.src.height;
    E.sd = E.src.getContext("2d").getImageData(0, 0, E.W, E.H).data;
    const md = mc.getContext("2d").getImageData(0, 0, E.W, E.H).data; E.m = new Uint8Array(E.W * E.H); for (let i = 0; i < E.m.length; i++) E.m[i] = md[i * 4 + 3];
    E.maskCv = mk(E.W, E.H); E.undo = []; E.redo = []; E.pt = null; maskAll(); fitView(); draw();
  }

  /* ================================================================ القناع */
  function maskAll() { maskRect(0, 0, E.W, E.H); }
  function maskRect(x0, y0, x1, y1) {
    x0 = clamp(Math.floor(x0), 0, E.W); y0 = clamp(Math.floor(y0), 0, E.H); x1 = clamp(Math.ceil(x1), 0, E.W); y1 = clamp(Math.ceil(y1), 0, E.H);
    const w = x1 - x0, h = y1 - y0; if (w <= 0 || h <= 0) return;
    const x = E.maskCv.getContext("2d"), d = x.createImageData(w, h), p = d.data;
    for (let y = 0; y < h; y++) { let o = (y0 + y) * E.W + x0, q = y * w * 4; for (let i = 0; i < w; i++, o++, q += 4) { p[q] = p[q + 1] = p[q + 2] = 0; p[q + 3] = E.m[o]; } }
    x.putImageData(d, x0, y0); E.ver++;
  }
  function push() { E.undo.push(E.m.slice()); if (E.undo.length > 12) E.undo.shift(); E.redo = []; }
  function undo() { if (!E.undo.length) return; E.redo.push(E.m); E.m = E.undo.pop(); maskAll(); draw(); }
  function redo() { if (!E.redo.length) return; E.undo.push(E.m); E.m = E.redo.pop(); maskAll(); draw(); }

  /* إزالة تلقائية: نفس محرّك «تصوير ذكي» (قناع Gemini إن وُجد المفتاح ، وإلا العزل المحلي) */
  async function autoCut() {
    if (!E || !E.src) return;
    const P = window.ANOUER_PSTUDIO, T = P && P._t; if (!T || !T.cutout) { note("العزل التلقائي غير متاح — استعمل الممحاة السحرية", "w"); return; }
    const ai = !!(P.ai && P.ai.has()); busy(ai ? "عزل المنتج بالذكاء الاصطناعي…" : "عزل المنتج…");
    const myVer = E.ver, src = E.src;
    try {
      const r = await T.cutout(src.toDataURL("image/jpeg", 0.95), null, ai, null);
      if (!E || E.src !== src) return; busy("");
      if (E.ver !== myVer) return;   // بدأ المستخدم التعديل يدوياً
      const busyBg = r.how === "local" && r.dv > 34;
      if (r.how === "none" || r.how === "box" || busyBg) { setTool("box"); note("خلفية التصوير مزدحمة — ارسم مستطيلاً حول المنتج فيُعزل داخله ، ثم صحّح بالممحاة السحرية والفرشاة", "w"); return; }
      const f = mk(E.W, E.H), fx = f.getContext("2d"); fx.drawImage(r.full, 0, 0, E.W, E.H); const d = fx.getImageData(0, 0, E.W, E.H).data;
      push(); for (let i = 0; i < E.m.length; i++) E.m[i] = d[i * 4 + 3]; maskAll(); draw();
      note(r.how === "ai" ? "✓ عُزل بالذكاء الاصطناعي — صحّح ما تبقى بالفرشاة" : "✓ عُزل تلقائياً — صحّح ما تبقى بالممحاة أو الفرشاة", "ok");
    } catch (e) { if (E) { busy(""); note("تعذّر العزل التلقائي — استعمل الممحاة السحرية", "w"); } console.warn(e); }
  }
  /* عزل بنموذج الألوان (على طريقة GrabCut): ألوان الخلفية من حلقة خارج المستطيل ، وألوان المنتج من داخله ،
     ثم 3 دورات تعلّم + تنعيم + أكبر جزء متصل + سد الثقوب. يعمل بدون إنترنت ومع الخلفيات المزدحمة. */
  function grab(x0, y0, x1, y1) {
    const W = E.W, H = E.H, d = E.sd, bw = x1 - x0, bh = y1 - y0, NB = 4096, bin = o => ((d[o] >> 4) << 8) | ((d[o + 1] >> 4) << 4) | (d[o + 2] >> 4);
    const ring = Math.max(8, Math.round(Math.max(bw, bh) * .07)), rx0 = Math.max(0, x0 - ring), ry0 = Math.max(0, y0 - ring), rx1 = Math.min(W, x1 + ring), ry1 = Math.min(H, y1 + ring);
    const smooth = h => { const o = new Float32Array(NB); for (let r = 0; r < 16; r++) for (let g = 0; g < 16; g++) for (let b = 0; b < 16; b++) { let s = 0; for (let dr = -1; dr <= 1; dr++) for (let dg = -1; dg <= 1; dg++) for (let db = -1; db <= 1; db++) { const R = r + dr, Gg = g + dg, B = b + db; if (R < 0 || Gg < 0 || B < 0 || R > 15 || Gg > 15 || B > 15) continue; s += h[(R << 8) | (Gg << 4) | B] * (dr || dg || db ? .35 : 1); } o[(r << 8) | (g << 4) | b] = s; } let t = 0; for (let i = 0; i < NB; i++) t += o[i]; for (let i = 0; i < NB; i++) o[i] = o[i] / (t || 1); return o; };
    let bg = new Float32Array(NB), fg = new Float32Array(NB);
    for (let y = ry0; y < ry1; y += 1) for (let x = rx0; x < rx1; x += 1) { const inB = x >= x0 && x < x1 && y >= y0 && y < y1, edgeB = inB && (x < x0 + 3 || x >= x1 - 3 || y < y0 + 3 || y >= y1 - 3); if (!inB || edgeB) bg[bin((y * W + x) * 4)] += 1; }
    if (rx1 - rx0 === bw && ry1 - ry0 === bh) { /* المستطيل يملأ الصورة: الحواف وحدها خلفية */ }
    const cx0 = x0 + bw * .28, cx1 = x1 - bw * .28, cy0 = y0 + bh * .22, cy1 = y1 - bh * .22;
    for (let y = Math.round(cy0); y < cy1; y++) for (let x = Math.round(cx0); x < cx1; x++) fg[bin((y * W + x) * 4)] += 1;
    const n = bw * bh, P = new Float32Array(n), lab = new Uint8Array(n);
    for (let it = 0; it < 3; it++) {
      const B = smooth(bg), F = smooth(fg);
      for (let y = 0; y < bh; y++) for (let x = 0; x < bw; x++) { const o = ((y + y0) * W + x + x0) * 4, k = bin(o), pf = F[k] + 4e-4, pb = B[k] + 2e-5; P[y * bw + x] = pf / (pf + pb); }   // لون غير موجود في الخلفية ← من المنتج
      /* تنعيم 5×5 (مرتين أفقي/عمودي) */
      const T = new Float32Array(n);
      for (let y = 0; y < bh; y++) { let acc = 0; for (let x = -2; x < bw + 2; x++) { if (x + 2 < bw) acc += P[y * bw + x + 2]; if (x - 3 >= 0) acc -= P[y * bw + x - 3]; if (x >= 0 && x < bw) T[y * bw + x] = acc / 5; } }
      for (let x = 0; x < bw; x++) { let acc = 0; for (let y = -2; y < bh + 2; y++) { if (y + 2 < bh) acc += T[(y + 2) * bw + x]; if (y - 3 >= 0) acc -= T[(y - 3) * bw + x]; if (y >= 0 && y < bh) P[y * bw + x] = acc / 5; } }
      for (let i = 0; i < n; i++) lab[i] = P[i] > .5 ? 1 : 0;
      if (it < 2) { bg = new Float32Array(NB); fg = new Float32Array(NB);
        for (let y = ry0; y < ry1; y++) for (let x = rx0; x < rx1; x++) { if (x >= x0 && x < x1 && y >= y0 && y < y1) continue; bg[bin((y * W + x) * 4)] += 1; }
        for (let y = 0; y < bh; y++) for (let x = 0; x < bw; x++) { const k = bin(((y + y0) * W + x + x0) * 4); if (lab[y * bw + x]) fg[k] += 1; else bg[k] += .6; } }
    }
    /* أكبر جزء متصل يلمس مركز المستطيل + سد الثقوب */
    const id = new Int32Array(n), q = new Int32Array(n); let best = 0, bestS = 0, cur = 0;
    for (let i = 0; i < n; i++) { if (!lab[i] || id[i]) continue; cur++; let qh = 0, qt = 0, s = 0, cen = 0; q[qt++] = i; id[i] = cur;
      while (qh < qt) { const k = q[qh++], x = k % bw, y = (k - x) / bw; s++; if (x > bw * .3 && x < bw * .7 && y > bh * .3 && y < bh * .7) cen++;
        for (const j of [x > 0 ? k - 1 : -1, x < bw - 1 ? k + 1 : -1, k - bw, k + bw]) if (j >= 0 && j < n && lab[j] && !id[j]) { id[j] = cur; q[qt++] = j; } }
      const sc = s + cen * 4; if (sc > bestS) { bestS = sc; best = cur; } }
    const out = new Uint8Array(n); for (let i = 0; i < n; i++) out[i] = id[i] === best ? 1 : 0;
    const reach = new Uint8Array(n); let qh = 0, qt = 0;
    for (let x = 0; x < bw; x++) for (const k of [x, (bh - 1) * bw + x]) if (!out[k] && !reach[k]) { reach[k] = 1; q[qt++] = k; }
    for (let y = 0; y < bh; y++) for (const k of [y * bw, y * bw + bw - 1]) if (!out[k] && !reach[k]) { reach[k] = 1; q[qt++] = k; }
    while (qh < qt) { const k = q[qh++], x = k % bw; for (const j of [x > 0 ? k - 1 : -1, x < bw - 1 ? k + 1 : -1, k - bw, k + bw]) if (j >= 0 && j < n && !out[j] && !reach[j]) { reach[j] = 1; q[qt++] = j; } }
    let area = 0; for (let i = 0; i < n; i++) { out[i] = reach[i] ? 0 : 1; area += out[i]; }
    return { out, ratio: area / n, bw, bh };
  }
  /* «تحديد المنتج»: ما خارج المستطيل يُمسح ، وداخله يُعزل تلقائياً (بذور الخلفية = حواف المستطيل) */
  async function boxCut(x0, y0, x1, y1) {
    const W = E.W, H = E.H; x0 = clamp(Math.round(Math.min(x0, x1)), 0, W); x1 = clamp(Math.round(Math.max(x0, x1)), 0, W); y0 = clamp(Math.round(Math.min(y0, y1)), 0, H); y1 = clamp(Math.round(Math.max(y0, y1)), 0, H);
    if (x1 - x0 < 12 || y1 - y0 < 12) return;
    push(); for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (x < x0 || x >= x1 || y < y0 || y >= y1) E.m[y * W + x] = 0;
    maskAll(); draw();
    const P = window.ANOUER_PSTUDIO, T = P && P._t, ai = !!(T && T.cutout && P.ai && P.ai.has()), src = E.src, ver = E.ver;
    busy(ai ? "عزل المنتج داخل التحديد بالذكاء الاصطناعي…" : "عزل المنتج داخل التحديد…"); await new Promise(r => setTimeout(r, 30));
    try {
      let ok = false;
      if (ai) { const box = [y0 / H * 1000, x0 / W * 1000, y1 / H * 1000, x1 / W * 1000];
        const r = await T.cutout(src.toDataURL("image/jpeg", 0.95), box, true, null); if (!E || E.src !== src) return;
        if (E.ver === ver && (r.how === "ai" || r.how === "poly")) { const f = mk(W, H), fx = f.getContext("2d"); fx.drawImage(r.full, 0, 0, W, H); const d = fx.getImageData(0, 0, W, H).data;
          for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const i = y * W + x; E.m[i] = Math.min(E.m[i], d[i * 4 + 3]); } ok = true; } }
      if (!ok && E.ver === ver) {
        const g = grab(x0, y0, x1, y1);
        if (g.ratio > .12 && g.ratio < .985) {
          /* حافة ناعمة: تنعيم 3×3 على حدود القناع فقط */
          const o = g.out, bw = g.bw, bh = g.bh;
          for (let y = 0; y < bh; y++) for (let x = 0; x < bw; x++) { const k = y * bw + x; let s = 0, c = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= bw || yy >= bh) continue; s += o[yy * bw + xx]; c++; }
            const i = (y + y0) * W + x + x0; E.m[i] = Math.min(E.m[i], Math.round(255 * s / c)); }
          ok = true;
        }
      }
      if (!E) return; busy(""); if (E.ver !== ver) return; maskAll(); draw();
      note(ok ? "✓ عُزل المنتج داخل التحديد — صحّح الحواف بالفرشاة إن لزم ، و«تراجع» يعيد ما قبل التحديد" : "قُصّت الصورة على التحديد — امسح ما تبقى من الخلفية بالممحاة السحرية", ok ? "ok" : "w");
    } catch (e) { if (E) busy(""); console.warn(e); }
  }
  /* الممحاة السحرية: تمسح (أو تسترجع) كل لون قريب من لون النقطة — متصل أو في كل الصورة */
  function wand(ix, iy, restore) {
    const W = E.W, H = E.H, d = E.sd, N = W * H; if (ix < 0 || iy < 0 || ix >= W || iy >= H) return;
    let r0 = 0, g0 = 0, b0 = 0, n = 0;
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) { const x = ix + dx, y = iy + dy; if (x < 0 || y < 0 || x >= W || y >= H) continue; const o = (y * W + x) * 4; r0 += d[o]; g0 += d[o + 1]; b0 += d[o + 2]; n++; }
    r0 /= n; g0 /= n; b0 /= n;
    const T = E.opt.tol * 2.2, T2 = T * 1.45, dist = i => { const o = i * 4, dr = d[o] - r0, dg = d[o + 1] - g0, db = d[o + 2] - b0; return Math.sqrt(dr * dr * .3 + dg * dg * .59 + db * db * .11) * 1.7; };
    const hit = new Uint8Array(N);
    if (E.opt.cont) { const q = new Int32Array(N); let qh = 0, qt = 0; const s = iy * W + ix; hit[s] = 1; q[qt++] = s;
      while (qh < qt) { const i = q[qh++], x = i % W; const nb = [x > 0 ? i - 1 : -1, x < W - 1 ? i + 1 : -1, i - W, i + W];
        for (const j of nb) { if (j < 0 || j >= N || hit[j]) continue; if (dist(j) < T) { hit[j] = 1; q[qt++] = j; } } } }
    else for (let i = 0; i < N; i++) if (dist(i) < T) hit[i] = 1;
    push();
    let x0 = W, y0 = H, x1 = 0, y1 = 0;
    for (let i = 0; i < N; i++) {
      let a = 0; if (hit[i]) a = 1;
      else { const x = i % W; if ((x > 0 && hit[i - 1]) || (x < W - 1 && hit[i + 1]) || (i >= W && hit[i - W]) || (i < N - W && hit[i + W])) { const dd = dist(i); if (dd < T2) a = 1 - (dd - T) / (T2 - T); } }   // حافة ناعمة
      if (!a) continue; const x = i % W, y = (i - x) / W; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
      E.m[i] = restore ? Math.max(E.m[i], Math.round(255 * a)) : Math.min(E.m[i], Math.round(255 * (1 - a)));
    }
    if (x1 >= x0) maskRect(x0, y0, x1 + 1, y1 + 1); draw();
  }
  /* الفرشاة: مسح / استرجاع بحافة ناعمة */
  function stamp(cx, cy, restore) {
    const r = E.opt.bsz / 2 / Math.max(.05, E.z), hd = E.opt.bhd / 100, W = E.W, H = E.H;
    const x0 = Math.max(0, Math.floor(cx - r)), y0 = Math.max(0, Math.floor(cy - r)), x1 = Math.min(W - 1, Math.ceil(cx + r)), y1 = Math.min(H - 1, Math.ceil(cy + r));
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
      const dd = Math.hypot(x - cx, y - cy) / r; if (dd > 1) continue;
      const a = dd <= hd ? 1 : 1 - (dd - hd) / Math.max(.001, 1 - hd), i = y * W + x;
      E.m[i] = restore ? Math.max(E.m[i], Math.round(255 * a)) : Math.min(E.m[i], Math.round(255 * (1 - a)));
    }
    maskRect(x0, y0, x1 + 1, y1 + 1);
  }
  function edge(kind) {
    if (!E.src) return; push(); const W = E.W, H = E.H, a = E.m, b = new Uint8Array(a.length);
    if (kind === "feather") { for (let pass = 0; pass < 2; pass++) { const s = pass ? b : a, t = pass ? a : b;
        for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { let sum = 0, n = 0; for (let dy = -1; dy <= 1; dy++) { const yy = y + dy; if (yy < 0 || yy >= H) continue; for (let dx = -1; dx <= 1; dx++) { const xx = x + dx; if (xx < 0 || xx >= W) continue; sum += s[yy * W + xx]; n++; } } t[y * W + x] = sum / n; } } }
    else { const f = kind === "shrink" ? Math.min : Math.max;
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const i = y * W + x; let v = a[i]; if (x > 0) v = f(v, a[i - 1]); if (x < W - 1) v = f(v, a[i + 1]); if (y > 0) v = f(v, a[i - W]); if (y < H - 1) v = f(v, a[i + W]); b[i] = v; }
      E.m = b; }
    maskAll(); draw();
  }

  /* ================================================================ المنتج المعزول (مقصوص على حدوده) */
  function prod() {
    if (E.pver === E.ver && E.prod) return E.prod;
    const f = mk(E.W, E.H), x = f.getContext("2d"); x.drawImage(E.src, 0, 0); x.globalCompositeOperation = "destination-in"; x.drawImage(E.maskCv, 0, 0);
    let x0 = E.W, y0 = E.H, x1 = -1, y1 = -1; const m = E.m;
    for (let y = 0; y < E.H; y++) { const o = y * E.W; for (let i = 0; i < E.W; i++) if (m[o + i] > 12) { if (i < x0) x0 = i; if (i > x1) x1 = i; if (y < y0) y0 = y; if (y > y1) y1 = y; } }
    if (x1 < 0) { E.prod = null; E.pver = E.ver; return null; }
    const c = mk(x1 - x0 + 1, y1 - y0 + 1); c.getContext("2d").drawImage(f, -x0, -y0);
    E.prod = c; E.pver = E.ver; E.padj = null; return c;
  }
  /* المنتج بعد الضبط (سطوع/تباين/تشبّع + دمج الإضاءة) — يُعاد حسابه عند التغيير فقط */
  function prodAdj() {
    const P = prod(); if (!P) return null; const a = E.adj, L = E.layers, pt = E.pt;
    const key = [E.pver, a.br, a.ct, a.st, a.blend, E.lkey, a.blend && pt ? Math.round(pt.x / 80) + "," + Math.round(pt.y / 80) + "," + Math.round(pt.h / 60) : ""].join("|");
    if (E.padj && E.pakey === key) return E.padj;
    const c = mk(P.width, P.height), x = c.getContext("2d"); x.filter = `brightness(${a.br}%) contrast(${a.ct}%) saturate(${a.st}%)`; x.drawImage(P, 0, 0); x.filter = "none";
    let out = c;
    if (a.blend && L && pt && E.bg.kind !== "color") {
      try { const A = window.ANOUER_ADSCENE, w = Math.round(pt.h * P.width / P.height), h = Math.round(pt.h);
        if (w > 4 && h > 4) { const amb = A.avgCol(L.back, .2, .25, .6, .4), floor = A.avgCol(L.back, clamp(pt.x / S - .2, 0, .6), clamp(pt.y / S - .02, 0, .8), .4, .12);
          out = A.blendIn(c, w, h, amb, floor, L.blur, Math.round(pt.x - w / 2), Math.round(pt.y - h)); } } catch (e) { console.warn(e); }
    }
    E.padj = out; E.pakey = key; return out;
  }

  /* ================================================================ الخلفية (طبقات) */
  function info() {
    const v = id => { const e = G(id); return e ? String(e.value || "").trim() : ""; };
    return { name: v("itName"), group: v("itGroup") };
  }
  function layers() {
    const I = info(), b = E.bg, t = E.txt;
    const rimg = b.kind === "real" ? E.real.img : null;
    const key = [b.kind, b.theme, b.seed, b.kind === "photo" ? (b.photo ? b.photo.__id : "") + ":" + b.blur : "", b.kind === "color" ? b.color : "", rimg ? rimg.__id + ":" + b.dof : "", t.on, t.head, t.sub, I.name, I.group].join("|");
    if (E.layers && E.lkey === key) return E.layers;
    const A = window.ANOUER_ADSCENE, ids = b.theme !== "auto" ? [b.theme] : A.detect(I.name, I.group), th = A.themeOf(ids[0]);
    const head = t.head || null, sub = t.sub != null && t.sub !== "" ? t.sub : null;
    let L;
    if (b.kind === "scene" || (b.kind === "real" && !rimg)) {   // «حقيقية» قيد الجلب ← المرسومة مؤقتاً
      L = A.render(prod() || null, null, { name: I.name, group: I.group, theme: b.theme, seed: b.seed, title: t.on, head, sub, layers: true });
    } else {
      const back = mk(S, S), x = back.getContext("2d"); x.imageSmoothingQuality = "high";
      if (b.kind === "real") x.drawImage(tilt(rimg, b.dof), 0, 0);
      else if (b.kind === "photo" && b.photo) {
        const im = b.photo, k = Math.max(S / im.width, S / im.height), w = im.width * k, h = im.height * k;
        if (b.blur > 0) { const f = 1 + b.blur / 3, sm = mk(S / f, S / f); sm.getContext("2d").drawImage(im, (S - w) / 2 / f, (S - h) / 2 / f, w / f, h / f); x.drawImage(sm, 0, 0, S, S); }
        else x.drawImage(im, (S - w) / 2, (S - h) / 2, w, h);
      } else {
        const c = b.kind === "color" ? b.color : "#e9e4dc";
        x.fillStyle = c; x.fillRect(0, 0, S, S);
        let g = x.createRadialGradient(S * .5, S * .42, S * .05, S * .5, S * .5, S * .8); g.addColorStop(0, "rgba(255,255,255,.55)"); g.addColorStop(1, "rgba(0,0,0,.18)"); x.fillStyle = g; x.fillRect(0, 0, S, S);
        g = x.createLinearGradient(0, S * .66, 0, S); g.addColorStop(0, "rgba(0,0,0,.06)"); g.addColorStop(.02, "rgba(255,255,255,.18)"); g.addColorStop(1, "rgba(0,0,0,.14)"); x.fillStyle = g; x.fillRect(0, S * .66, S, S * .34);
      }
      const front = mk(S, S), fx = front.getContext("2d");
      if (t.on) { fx.fillStyle = (() => { const g = fx.createLinearGradient(0, 0, 0, S * .32); g.addColorStop(0, "rgba(0,0,0,.36)"); g.addColorStop(1, "rgba(0,0,0,0)"); return g; })(); if (b.kind === "photo" || b.kind === "real") fx.fillRect(0, 0, S, S * .32);
        A.drawTitle(fx, head || th.tag, sub || A.short(I.name || "", 34), { acc: th.acc, ink: "#ffffff", dark: 1, acc2: b.kind === "color" ? th.acc : "rgba(0,0,0,.55)", pillInk: /^#f[0-9a-f]{5}$/i.test(th.acc) ? "#3b2305" : "#fff" }); }
      const vg = fx.createRadialGradient(S * .5, S * .5, S * .45, S * .5, S * .5, S * .78); vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, "rgba(0,0,0,.2)"); fx.fillStyle = vg; fx.fillRect(0, 0, S, S);
      L = { back, front, slot: { cx: S * .5, bottom: S * .86, maxW: S * .6, maxH: S * (t.on ? .58 : .68) } };
    }
    const sm = mk(S / 16, S / 16); sm.getContext("2d").drawImage(L.back, 0, 0, sm.width, sm.height); L.blur = mk(S, S); const bx = L.blur.getContext("2d"); bx.imageSmoothingQuality = "high"; bx.drawImage(sm, 0, 0, S, S);
    E.layers = L; E.lkey = key; E.padj = null;
    if (!E.pt) placeDefault();
    return L;
  }
  /* ================================================================ خلفية حقيقية تلقائية
     صور فوتوغرافية حرة (CC0 / ملكية عامة) من StockSnap و rawpixel عبر Openverse المفتوحة — بحث بنوع الصنف ،
     ثم «عمق ميدان»: الصورة حادّة عند قاعدة المنتج وضبابية في الأعلى كأنها مصوّرة بعدسة احترافية. */
  const RQ = { choco: "chocolate", hazel: "hazelnuts", almond: "almonds", pistachio: "pistachios", walnut: "walnuts", peanut: "peanuts", coconut: "coconut", nuts: "nuts", date: "dates fruit",
    strawberry: "strawberries", mint: "mint leaves", watermelon: "watermelon", citrus: "oranges", cherry: "cherries", fruit: "fruits", caramel: "caramel", honey: "honeycomb", milk: "milk", coffee: "coffee beans",
    candy: "candy", biscuit: "cookies", drink: "ice cubes", snack: "potato chips", clean: "bubbles", beauty: "flower petals", pantry: "vegetables", tea: "tea leaves", spice: "spices", baby: "pastel", premium: "bokeh lights" };
  const RCACHE = {};
  const HOSTOK = () => !!(window.Anouer && Anouer.available && Anouer.call);
  function realQuery() { const I = info(), A = window.ANOUER_ADSCENE, id = E.bg.theme !== "auto" ? E.bg.theme : A.detect(I.name, I.group)[0]; return RQ[id] || "bokeh lights"; }
  async function realSearch(q, page) {
    const k = q + "|" + page; if (RCACHE[k]) return RCACHE[k];
    const ls = lsGet("as.rq." + k, null); if (ls && Date.now() - ls.t < 7 * 864e5 && ls.l && ls.l.length) return (RCACHE[k] = ls.l);
    const u = "https://api.openverse.org/v1/images/?q=" + encodeURIComponent(q) + "&license=cc0,pdm&category=photograph&source=stocksnap,rawpixel&aspect_ratio=wide,square&mature=false&page_size=12&page=" + page;
    const r = await fetch(u, { headers: { Accept: "application/json" } }); if (!r.ok) throw new Error("HTTP " + r.status);
    const j = await r.json(), l = (j.results || []).filter(x => x && x.url && x.thumbnail && (x.width || 0) >= 900 && !/logo|text|poster|illustration|vector|drawing|sign/i.test(x.title || "")).map(x => ({ id: x.id, th: x.thumbnail, url: x.url, t: x.title || "", src: x.source }));
    lsSet("as.rq." + k, { t: Date.now(), l }); return (RCACHE[k] = l);
  }
  async function realLoad(it) {
    let im = null;
    if (HOSTOK()) { try { const r = await Anouer.call("fm.img.raw", { url: it.url }); if (r && r.data) im = await loadImg("data:" + (r.type || "image/jpeg") + ";base64," + r.data); } catch (e) { console.warn("real (host)", e); } }
    if (!im) im = await new Promise((ok, no) => { const i = new Image(); i.crossOrigin = "anonymous"; i.onload = () => ok(i); i.onerror = () => no(new Error("تعذّر تحميل الصورة")); i.src = it.th; });
    const k = Math.min(1, 2200 / Math.max(im.naturalWidth, im.naturalHeight)), c = mk(im.naturalWidth * k, im.naturalHeight * k); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
    c.getContext("2d").getImageData(0, 0, 1, 1);   // يرمي خطأ إن كانت ملوّثة (بلا CORS)
    c.__id = it.id; return c;
  }
  /* مشهد فوتوغرافي من صورة حقيقية: «أرضية» من الصورة نفسها مضغوطة بالمنظور (سطح يمتد للخلف ويقف عليه المنتج)
     + خلفية ضبابية من نفس الصورة (عمق ميدان) + خط أفق ناعم وضوء دافئ — dof = قوة الضبابية */
  function tilt(im, dof) {
    const c = mk(S, S), x = c.getContext("2d"); x.imageSmoothingQuality = "high";
    const cover = (cv, sc) => { const k = Math.max(S / im.width, S / im.height) * (sc || 1), w = im.width * k, h = im.height * k; return [(S - w) / 2, (S - h) / 2, w, h]; };
    /* 1) الخلفية: ضبابية قوية + أفتح قليلاً */
    const f = 5 + dof / 1.6, sm = mk(S / f, S / f), sx = sm.getContext("2d"); sx.imageSmoothingQuality = "high"; const [bx0, by0, bw0, bh0] = cover(null, 1.15); sx.drawImage(im, bx0 / f, by0 / f, bw0 / f, bh0 / f);
    x.drawImage(sm, 0, 0, S, S);
    x.fillStyle = "rgba(255,248,236,.12)"; x.fillRect(0, 0, S, S);
    /* 2) الأرضية: نفس الصورة مضغوطة عمودياً (منظور) من خط الأفق إلى الأسفل */
    const HZ = S * .6, FH = S - HZ, fl = mk(S, FH), fx = fl.getContext("2d"); fx.imageSmoothingQuality = "high";
    const k = Math.max(S / im.width, (FH * 2.1) / im.height), w = im.width * k, h = im.height * k;
    fx.save(); fx.scale(1, .48); fx.drawImage(im, (S - w) / 2, (FH / .48 - h) * .6, w, h); fx.restore();
    /* ضبابية متدرجة نحو الأفق (البعيد أقل وضوحاً) */
    const fb = mk(S / 4, FH / 4); fb.getContext("2d").drawImage(fl, 0, 0, fb.width, fb.height);
    const fb2 = mk(S, FH), f2 = fb2.getContext("2d"); f2.imageSmoothingQuality = "high"; f2.drawImage(fb, 0, 0, S, FH);
    f2.globalCompositeOperation = "destination-in"; let g = f2.createLinearGradient(0, 0, 0, FH); g.addColorStop(0, "#000"); g.addColorStop(.45, "rgba(0,0,0,.35)"); g.addColorStop(.8, "rgba(0,0,0,0)"); f2.fillStyle = g; f2.fillRect(0, 0, S, FH);
    fx.drawImage(fb2, 0, 0);
    /* حافة الأفق ناعمة */
    fx.globalCompositeOperation = "destination-in"; g = fx.createLinearGradient(0, 0, 0, FH); g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(.12, "#000"); fx.fillStyle = g; fx.fillRect(0, 0, S, FH); fx.globalCompositeOperation = "source-over";
    x.drawImage(fl, 0, HZ);
    /* 3) ضوء دافئ خلف المنتج + تعتيم الحافة السفلية */
    g = x.createRadialGradient(S * .5, S * .56, S * .04, S * .5, S * .56, S * .55); g.addColorStop(0, "rgba(255,240,215,.28)"); g.addColorStop(1, "rgba(255,240,215,0)"); x.fillStyle = g; x.fillRect(0, 0, S, S);
    g = x.createLinearGradient(0, S * .82, 0, S); g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, "rgba(0,0,0,.25)"); x.fillStyle = g; x.fillRect(0, S * .82, S, S * .18);
    return c;
  }
  function realNote(t, cls) { const n = Q("realNote"); if (n) { n.textContent = t; n.className = "as-note" + (cls ? " as-n-" + cls : ""); } }
  function realThumbs() {
    const R = E.real, el = Q("rlist"); if (!el) return;
    el.innerHTML = R.list.slice(0, 6).map((it, i) => `<button type="button" data-ri="${i}" class="${i === R.idx ? "on" : ""}" title="${esc(it.t)}"><img src="${esc(it.th)}" alt=""></button>`).join("") || (R.busy ? '<i class="as-rlw"></i>'.repeat(6) : "");
  }
  const srcName = it => it && it.src === "stocksnap" ? "StockSnap" : "rawpixel";
  async function realEnsure(force) {
    if (!E || E.bg.kind !== "real") return; const R = E.real, q = realQuery();
    if (!force && R.q === q && (R.img || R.busy)) return;
    if (R.q !== q) { R.q = q; R.page = 1; R.idx = 0; R.list = []; R.img = null; }
    R.busy = true; realThumbs(); busy("جلب خلفية حقيقية…"); realNote("جارٍ البحث عن صور حقيقية…", "");
    try {
      if (!R.list.length) R.list = await realSearch(q, R.page);
      if (!E || E.real !== R || R.q !== q) return;
      if (!R.list.length) throw new Error("لا توجد صور لهذا النوع");
      realThumbs(); let img = null, err = null;
      for (let t = 0; t < 3 && !img; t++) { try { img = await realLoad(R.list[R.idx]); } catch (e) { err = e; R.idx = (R.idx + 1) % R.list.length; } }
      if (!E || E.real !== R || R.q !== q) return;
      if (!img) throw err || new Error("تعذّر التحميل");
      R.img = img; R.busy = false; busy(""); realThumbs(); realNote("صورة حقيقية حرة الاستعمال (CC0) — " + srcName(R.list[R.idx]) + " · اختر غيرها من الصور أعلاه", "ok");
      draw();
    } catch (e) {
      if (!E) return; R.busy = false; busy(""); realThumbs(); console.warn(e);
      realNote("تعذّر جلب صورة حقيقية (" + (e.message || "بلا إنترنت؟") + ") — بقيت الخلفية المرسومة", "w"); draw();
    }
  }
  async function realPick(i) {
    const R = E.real; if (!R.list[i] || R.busy) return; R.idx = i; R.busy = true; realThumbs(); busy("تحميل الصورة…");
    try { const img = await realLoad(R.list[i]); if (!E || E.real !== R) return; R.img = img; realNote("صورة حقيقية حرة الاستعمال (CC0) — " + srcName(R.list[i]), "ok"); }
    catch (e) { realNote("تعذّر تحميل هذه الصورة — اختر غيرها", "w"); }
    if (!E) return; R.busy = false; busy(""); realThumbs(); draw();
  }
  async function realMore() {
    const R = E.real; if (R.busy) return; R.page++; R.busy = true; busy("صور أخرى…");
    try { const l = await realSearch(R.q, R.page); if (!E || E.real !== R) return; if (l.length) { R.list = l; R.busy = false; busy(""); await realPick(0); return; } R.page = 1; realNote("لا توجد صور أخرى — عدنا للأولى", "w"); }
    catch (e) { R.page--; realNote("تعذّر جلب صور أخرى", "w"); }
    if (E) { R.busy = false; busy(""); realThumbs(); }
  }
  function placeDefault() {
    const P = prod(), L = E.layers; if (!P || !L) return; const s = L.slot, k = Math.min(s.maxW / P.width, s.maxH / P.height);
    E.pt = { x: s.cx, y: s.bottom, h: P.height * k, h0: P.height * k }; syncProdUi();
  }

  /* ================================================================ الرسم */
  function sizeCv() { const st = Q("stage"), r = st.getBoundingClientRect(), dpr = window.devicePixelRatio || 1; E.cw = Math.max(50, r.width); E.ch = Math.max(50, r.height); E.cv.width = Math.round(E.cw * dpr); E.cv.height = Math.round(E.ch * dpr); E.cv.style.width = E.cw + "px"; E.cv.style.height = E.ch + "px"; E.dpr = dpr; }
  function fitView(keep) {
    if (!E.cw) sizeCv(); if (E.view === "cut") { if (!E.src) return; if (keep && E.fitted) return; const k = Math.min((E.cw - 40) / E.W, (E.ch - 40) / E.H); E.z = k; E.cvw0 = E.W * k; E.px = (E.cw - E.W * k) / 2; E.py = (E.ch - E.H * k) / 2; E.fitted = true; }
    zoomLbl();
  }
  function zoomLbl() { const l = Q("zoomLbl"); if (l) l.textContent = E.view === "cut" && E.src ? Math.round(E.z * 100) + "%" : ""; }
  let raf = 0; function draw() { if (!E || raf) return; raf = requestAnimationFrame(() => { raf = 0; if (!E) return; E.view === "cut" ? drawCut() : drawComp(); }); }
  let checker = null;
  function drawCut() {
    const x = E.cx, d = E.dpr; x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, E.cv.width, E.cv.height); if (!E.src) return;
    x.setTransform(d, 0, 0, d, 0, 0);
    if (!checker) { const c = mk(20, 20), cx = c.getContext("2d"); cx.fillStyle = "#3a3d45"; cx.fillRect(0, 0, 20, 20); cx.fillStyle = "#30333a"; cx.fillRect(0, 0, 10, 10); cx.fillRect(10, 10, 10, 10); checker = x.createPattern(c, "repeat"); }
    const w = E.W * E.z, h = E.H * E.z;
    x.fillStyle = checker; x.fillRect(E.px, E.py, w, h);
    x.imageSmoothingQuality = "high";
    if (E.opt.ghost) { x.globalAlpha = .2; x.drawImage(E.src, E.px, E.py, w, h); x.globalAlpha = 1; }
    const f = prodFull(); x.drawImage(f, E.px, E.py, w, h);
    x.strokeStyle = "rgba(255,255,255,.12)"; x.lineWidth = 1; x.strokeRect(E.px + .5, E.py + .5, w - 1, h - 1);
    if (E.drag && E.drag.box) { const [ax, ay] = E.drag.a, [bx, by] = E.drag.b, rx = E.px + Math.min(ax, bx) * E.z, ry = E.py + Math.min(ay, by) * E.z, rw = Math.abs(bx - ax) * E.z, rh = Math.abs(by - ay) * E.z;
      x.fillStyle = "rgba(0,0,0,.45)"; x.fillRect(E.px, E.py, w, ry - E.py); x.fillRect(E.px, ry + rh, w, E.py + h - ry - rh); x.fillRect(E.px, ry, rx - E.px, rh); x.fillRect(rx + rw, ry, E.px + w - rx - rw, rh);
      x.setLineDash([7, 5]); x.strokeStyle = "#fff"; x.lineWidth = 1.5; x.strokeRect(rx, ry, rw, rh); x.setLineDash([]); }
    if (E.mouse && (E.tool === "erase" || E.tool === "restore") && !E.space) { x.beginPath(); x.arc(E.mouse[0], E.mouse[1], E.opt.bsz / 2, 0, Math.PI * 2); x.strokeStyle = "rgba(0,0,0,.7)"; x.lineWidth = 3; x.stroke(); x.strokeStyle = E.tool === "erase" ? "#ff6b9a" : "#5eead4"; x.lineWidth = 1.5; x.stroke(); }
  }
  function prodFull() {
    if (E.fver === E.ver && E.full) return E.full;
    const f = E.full && E.full.width === E.W && E.full.height === E.H ? E.full : mk(E.W, E.H), x = f.getContext("2d");
    x.globalCompositeOperation = "source-over"; x.clearRect(0, 0, E.W, E.H); x.drawImage(E.src, 0, 0); x.globalCompositeOperation = "destination-in"; x.drawImage(E.maskCv, 0, 0); x.globalCompositeOperation = "source-over";
    E.full = f; E.fver = E.ver; return f;
  }
  /* التركيب على لوحة S×S (المعاينة تُصغّر نفس الدالة) */
  function compose(x, k) {
    const L = layers(); x.imageSmoothingQuality = "high";
    x.drawImage(L.back, 0, 0, S * k, S * k);
    const P = prodAdj(), pt = E.pt;
    if (P && pt) {
      const a = E.adj, h = pt.h, w = h * (E.prod.width / E.prod.height), sh = a.shd / 100;
      x.save(); x.scale(k, k);
      if (sh > 0) {
        const el = (rx, ry, al, dy) => { x.save(); x.translate(pt.x, pt.y + dy); x.scale(1, ry / rx); const g = x.createRadialGradient(0, 0, 0, 0, 0, rx); g.addColorStop(0, `rgba(0,0,0,${al})`); g.addColorStop(.55, `rgba(0,0,0,${al * .45})`); g.addColorStop(1, "rgba(0,0,0,0)"); x.fillStyle = g; x.beginPath(); x.arc(0, 0, rx, 0, Math.PI * 2); x.fill(); x.restore(); };
        el(w * .8, w * .13, .34 * sh, w * .02); el(w * .52, w * .035, .62 * sh, 0);
      }
      if (a.refl && !a.rot) { const t = mk(Math.max(1, w * k), Math.max(1, h * .3 * k)), tx = t.getContext("2d"); tx.save(); tx.translate(a.flip ? t.width : 0, h * k); tx.scale(a.flip ? -1 : 1, -1); tx.drawImage(P, 0, 0, w * k, h * k); tx.restore(); tx.globalCompositeOperation = "destination-in"; const g = tx.createLinearGradient(0, 0, 0, t.height); g.addColorStop(0, "rgba(0,0,0,.22)"); g.addColorStop(1, "rgba(0,0,0,0)"); tx.fillStyle = g; tx.fillRect(0, 0, t.width, t.height); x.drawImage(t, pt.x - w / 2, pt.y + 1, w, h * .3); }
      x.translate(pt.x, pt.y - h / 2); x.rotate(a.rot * Math.PI / 180); x.scale(a.flip ? -1 : 1, 1);
      x.shadowColor = `rgba(0,0,0,${.3 * sh})`; x.shadowBlur = 34 * k; x.shadowOffsetY = 8 * k;
      x.drawImage(P, -w / 2, -h / 2, w, h); x.restore();
    }
    x.drawImage(L.front, 0, 0, S * k, S * k);
  }
  function drawComp() {
    const x = E.cx, d = E.dpr; x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, E.cv.width, E.cv.height);
    const side = Math.min(E.cw - 32, E.ch - 32); E.cs = side; E.cox = (E.cw - side) / 2; E.coy = (E.ch - side) / 2;
    if (!E.src) return;
    if (!E.prev) E.prev = mk(PS, PS);
    const px = E.prev.getContext("2d"); px.clearRect(0, 0, PS, PS); compose(px, PS / S);
    x.setTransform(d, 0, 0, d, 0, 0); x.save(); x.shadowColor = "rgba(0,0,0,.45)"; x.shadowBlur = 30; x.shadowOffsetY = 10; x.fillStyle = "#000"; x.fillRect(E.cox, E.coy, side, side); x.restore();
    x.imageSmoothingQuality = "high"; x.drawImage(E.prev, E.cox, E.coy, side, side);
    if (E.pt && (E.drag || E.hover)) { const k = side / S, a = E.adj, h = E.pt.h, w = h * (E.prod.width / E.prod.height); x.save(); x.translate(E.cox + E.pt.x * k, E.coy + (E.pt.y - h / 2) * k); x.rotate(a.rot * Math.PI / 180); x.setLineDash([6, 5]); x.strokeStyle = "rgba(255,255,255,.85)"; x.lineWidth = 1.2; x.strokeRect(-w * k / 2, -h * k / 2, w * k, h * k); x.restore(); }
  }

  /* ================================================================ الفأرة */
  const toImg = (mx, my) => [(mx - E.px) / E.z, (my - E.py) / E.z];
  const toS = (mx, my) => [(mx - E.cox) / E.cs * S, (my - E.coy) / E.cs * S];
  function local(e) { const r = E.cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  function inProd(sx, sy) { const pt = E.pt; if (!pt || !E.prod) return false; const h = pt.h, w = h * (E.prod.width / E.prod.height), a = -E.adj.rot * Math.PI / 180, dx = sx - pt.x, dy = sy - (pt.y - h / 2), rx = dx * Math.cos(a) - dy * Math.sin(a), ry = dx * Math.sin(a) + dy * Math.cos(a); return Math.abs(rx) <= w / 2 + 10 && Math.abs(ry) <= h / 2 + 10; }
  function pDown(e) {
    if (!E || !E.src) return; const [mx, my] = local(e); try { E.cv.setPointerCapture(e.pointerId); } catch (_) { }
    if (E.view === "cut") {
      if (E.space || E.tool === "hand" || e.button === 1) { E.drag = { pan: 1, x: mx, y: my, px: E.px, py: E.py }; return; }
      const [ix, iy] = toImg(mx, my);
      if (E.tool === "wand") { wand(Math.floor(ix), Math.floor(iy), e.shiftKey || e.altKey); return; }
      if (E.tool === "box") { E.drag = { box: 1, a: [ix, iy], b: [ix, iy] }; return; }
      push(); E.drag = { brush: 1, last: [ix, iy], restore: E.tool === "restore" || e.altKey }; stamp(ix, iy, E.drag.restore); draw();
    } else {
      const [sx, sy] = toS(mx, my); if (!inProd(sx, sy)) return;
      E.drag = { move: 1, x: sx, y: sy, ox: E.pt.x, oy: E.pt.y }; draw();
    }
  }
  function pMove(e) {
    if (!E) return; const [mx, my] = local(e); E.mouse = [mx, my];
    if (E.view === "cut") {
      if (E.drag && E.drag.pan) { E.px = E.drag.px + mx - E.drag.x; E.py = E.drag.py + my - E.drag.y; draw(); return; }
      if (E.drag && E.drag.box) { E.drag.b = toImg(mx, my); draw(); return; }
      if (E.drag && E.drag.brush) { const [ix, iy] = toImg(mx, my), [lx, ly] = E.drag.last, r = Math.max(1, E.opt.bsz / 2 / E.z * .3), n = Math.max(1, Math.ceil(Math.hypot(ix - lx, iy - ly) / r));
        for (let i = 1; i <= n; i++) stamp(lx + (ix - lx) * i / n, ly + (iy - ly) * i / n, E.drag.restore); E.drag.last = [ix, iy]; }
      draw();
    } else {
      const [sx, sy] = toS(mx, my);
      if (E.drag && E.drag.move) { E.pt.x = clamp(E.drag.ox + sx - E.drag.x, 0, S); E.pt.y = clamp(E.drag.oy + sy - E.drag.y, S * .1, S * 1.05); draw(); return; }
      const h = inProd(sx, sy); if (h !== !!E.hover) { E.hover = h; E.cv.style.cursor = h ? "move" : "default"; draw(); }
    }
  }
  function pUp(e) { if (!E || !E.drag) return; const was = E.drag; E.drag = null; try { E.cv.releasePointerCapture(e.pointerId); } catch (_) { } if (was.move) E.padj = null; if (was.box) boxCut(was.a[0], was.a[1], was.b[0], was.b[1]); draw(); }
  function onWheel(e) {
    if (!E || !E.src) return; e.preventDefault(); const [mx, my] = local(e), f = e.deltaY < 0 ? 1.12 : 1 / 1.12;
    if (E.view === "cut") { const nz = clamp(E.z * f, .05, 12); E.px = mx - (mx - E.px) * nz / E.z; E.py = my - (my - E.py) * nz / E.z; E.z = nz; zoomLbl(); draw(); }
    else if (E.pt) { E.pt.h = clamp(E.pt.h * f, E.pt.h0 * .2, E.pt.h0 * 1.8); E.padj = null; syncProdUi(); draw(); }
  }
  function cursor() { if (!E) return; E.cv.style.cursor = E.view !== "cut" ? "default" : E.space || E.tool === "hand" ? "grab" : E.tool === "wand" || E.tool === "box" ? "crosshair" : "none"; }

  /* ================================================================ الواجهة */
  function setView(v) {
    if (v === "comp" && (!E.src || !prod())) { say(E.src ? "لم يبقَ شيء من المنتج — استرجع جزءاً منه" : "صوّر المنتج أو اختر صورته أولاً", "w"); return; }
    E.view = v; E.drag = null;
    E.ov.querySelectorAll("[data-v]").forEach(b => b.classList.toggle("on", b.dataset.v === v));
    E.ov.querySelectorAll("[data-g]").forEach(g => g.hidden = g.dataset.g !== v);
    E.ov.querySelector(".as-dlg").dataset.view = v;
    if (v === "comp") { E.tool = "move"; layers(); if (!E.pt) placeDefault(); syncProdUi(); realEnsure(); } else { E.tool = E.ov.querySelector('[data-g="cut"] [data-t].on') ? E.ov.querySelector('[data-g="cut"] [data-t].on').dataset.t : "wand"; }
    sizeCv(); fitView(true); cursor(); draw();
  }
  function setTool(t) {
    E.tool = t; E.ov.querySelectorAll(".as-tools [data-t]").forEach(b => b.classList.toggle("on", b.dataset.t === t));
    Q("wandSec").hidden = t !== "wand"; if (t === "box") note("ارسم مستطيلاً حول المنتج بالفأرة", ""); Q("brushSec").hidden = !(t === "erase" || t === "restore"); cursor(); draw();
  }
  function syncUi() {
    const b = E.bg; E.ov.querySelectorAll("[data-bk]").forEach(x => x.classList.toggle("on", x.dataset.bk === b.kind));
    E.ov.querySelectorAll("[data-bkp]").forEach(x => x.hidden = !x.dataset.bkp.split(" ").includes(b.kind));
    E.ov.querySelectorAll("[data-col]").forEach(x => x.classList.toggle("on", x.dataset.col === b.color));
    const I = info(); if (Q("sub") && !Q("sub").value) Q("sub").placeholder = I.name ? "السطر الثاني — " + window.ANOUER_ADSCENE.short(I.name, 30) : "السطر الثاني (اسم الصنف)";
  }
  function syncProdUi() { if (!E.pt) return; const p = Math.round(E.pt.h / E.pt.h0 * 100); Q("psz").value = p; Q("pszV").textContent = p + "%"; }
  const outV = (k, v) => { const o = Q(k + "V"); if (o) o.textContent = v; };
  function onInput(e) {
    if (!E) return; const t = e.target, k = t.dataset.k; if (!k) return;
    const v = t.type === "checkbox" ? t.checked : t.value;
    if (k === "tol") { E.opt.tol = +v; outV(k, v); }
    else if (k === "cont") E.opt.cont = v;
    else if (k === "bsz") { E.opt.bsz = +v; outV(k, v); draw(); }
    else if (k === "bhd") { E.opt.bhd = +v; outV(k, v); }
    else if (k === "ghost") { E.opt.ghost = v; draw(); }
    else if (k === "theme") { E.bg.theme = v; E.bg.seed = 0; draw(); realEnsure(); }
    else if (k === "dof") { E.bg.dof = +v; outV(k, v); clearTimeout(E.dt); E.dt = setTimeout(draw, e.type === "change" ? 0 : 120); }
    else if (k === "bgBlur") { E.bg.blur = +v; outV(k, v); if (e.type === "change") draw(); else { clearTimeout(E.bt); E.bt = setTimeout(draw, 120); } }
    else if (k === "colIn") { E.bg.color = v; lsSet("as.col", v); syncUi(); draw(); }
    else if (k === "tOn") { E.txt.on = v; E.pt = null; draw(); }
    else if (k === "head") { E.txt.head = String(v).trim(); clearTimeout(E.tt); E.tt = setTimeout(draw, 250); }
    else if (k === "sub") { E.txt.sub = String(v).trim(); clearTimeout(E.tt); E.tt = setTimeout(draw, 250); }
    else if (k === "psz") { if (E.pt) { E.pt.h = E.pt.h0 * v / 100; outV(k, v + "%"); E.padj = null; draw(); } }
    else if (k === "prot") { E.adj.rot = +v; outV(k, v + "°"); draw(); }
    else if (k === "shd") { E.adj.shd = +v; outV(k, v); draw(); }
    else if (k === "refl") { E.adj.refl = v; draw(); }
    else if (k === "blend") { E.adj.blend = v; draw(); }
    else if (k === "br" || k === "ct" || k === "st") { E.adj[k] = +v; outV(k, v); draw(); }
    else if (k === "file" && e.type === "change") { const f = t.files && t.files[0]; if (f) fromBlob(f); t.value = ""; }
    else if (k === "bgFile" && e.type === "change") { const f = t.files && t.files[0]; t.value = ""; if (f) { const r = new FileReader(); r.onload = async () => { const im = await loadImg(String(r.result)).catch(() => null); if (!im || !E) return; const c = mk(Math.min(2400, im.naturalWidth), Math.min(2400, im.naturalWidth) * im.naturalHeight / im.naturalWidth); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); c.__id = Date.now(); E.bg.photo = c; E.bg.kind = "photo"; syncUi(); draw(); }; r.readAsDataURL(f); } }
    else if (k === "dev" && e.type === "change") { stopCam(); startCam(v); }
  }
  function onClick(e) {
    if (!E) return; const b = e.target.closest("button, [data-col], [data-ri]"); if (!b) return;
    if (b.dataset.v) return setView(b.dataset.v);
    if (b.dataset.t) return setTool(b.dataset.t);
    if (b.dataset.bk) { if (b.dataset.bk === "photo" && !E.bg.photo) { Q("bgFile").click(); return; } E.bg.kind = b.dataset.bk; if (E.bg.kind !== "photo") lsSet("as.bgk", E.bg.kind); E.pt = null; syncUi(); draw(); realEnsure(); return; }
    if (b.dataset.ri != null) { realPick(+b.dataset.ri); return; }
    if (b.dataset.col) { E.bg.color = b.dataset.col; lsSet("as.col", E.bg.color); const ci = Q("colIn"); if (ci) ci.value = E.bg.color; syncUi(); draw(); return; }
    const a = b.dataset.a; if (!a) return;
    if (a === "close") close();
    else if (a === "file") Q("file").click();
    else if (a === "cam") startCam();
    else if (a === "phone") startPhone();
    else if (a === "phoneX") { hidePhone(); if (!E.src) Q("empty").hidden = false; }
    else if (a === "camX") { stopCam(); if (!E.src) Q("empty").hidden = false; }
    else if (a === "shot") shot();
    else if (a === "cur") { try { const u = __itImg.get(); if (u) setSrc(u); } catch (_) { } }
    else if (a === "boxTool") setTool("box");
    else if (a === "autoCut") { if (E.src) { E.ver++; autoCut(); } }
    else if (a === "keepAll") { if (E.src) { push(); E.m.fill(255); maskAll(); draw(); } }
    else if (a === "invert") { if (E.src) { push(); for (let i = 0; i < E.m.length; i++) E.m[i] = 255 - E.m[i]; maskAll(); draw(); } }
    else if (a === "feather" || a === "shrink" || a === "grow") edge(a);
    else if (a === "undo") undo();
    else if (a === "redo") redo();
    else if (a === "fit") { E.fitted = false; fitView(); draw(); }
    else if (a === "rotL") transformSrc("L");
    else if (a === "rotR") transformSrc("R");
    else if (a === "flipSrc") transformSrc("flip");
    else if (a === "toComp") setView("comp");
    else if (a === "reseed") { E.bg.seed++; draw(); }
    else if (a === "realNext") { const R = E.real; if (R.list.length) realPick((R.idx + 1) % Math.min(6, R.list.length)); else realEnsure(true); }
    else if (a === "realMore") realMore();
    else if (a === "bgPick") Q("bgFile").click();
    else if (a === "center") { E.pt = null; placeDefault(); E.adj.rot = 0; Q("prot").value = 0; outV("prot", "0°"); draw(); }
    else if (a === "flipP") { E.adj.flip = !E.adj.flip; draw(); }
    else if (a === "apply") apply();
    else if (a === "download") download();
  }
  function onKey(e) {
    if (!E) return; e.stopPropagation(); const typing = /INPUT|SELECT|TEXTAREA/.test(e.target.tagName) && e.target.type !== "checkbox" && e.target.type !== "range";
    if (e.key === "Escape") { e.preventDefault(); if (!Q("phoneBox").hidden) { hidePhone(); if (!E.src) Q("empty").hidden = false; } else if (!Q("camBox").hidden) { stopCam(); if (!E.src) Q("empty").hidden = false; } else close(); return; }
    if (typing) return;
    if (e.ctrlKey && (e.key === "z" || e.key === "Z")) { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
    if (e.ctrlKey && (e.key === "y" || e.key === "Y")) { e.preventDefault(); redo(); return; }
    if (e.ctrlKey && e.key === "Enter") { e.preventDefault(); E.view === "cut" ? setView("comp") : apply(); return; }
    if (e.code === "Space") { e.preventDefault(); if (!Q("camBox").hidden) { shot(); return; } if (!E.space) { E.space = true; cursor(); } return; }
    if (E.view === "cut") { const m = { KeyM: "box", KeyW: "wand", KeyE: "erase", KeyR: "restore", KeyH: "hand" }[e.code]; if (m) { setTool(m); return; } }
    if (e.key === "[" || e.key === "]") { E.opt.bsz = clamp(E.opt.bsz + (e.key === "]" ? 6 : -6), 4, 240); Q("bsz").value = E.opt.bsz; outV("bsz", E.opt.bsz); draw(); }
    if (e.key === "0") { E.fitted = false; fitView(); draw(); }
  }
  function onPaste(e) { const f = [...(e.clipboardData ? e.clipboardData.items : [])].find(i => /^image\//.test(i.type)); if (f) { e.preventDefault(); fromBlob(f.getAsFile()); } }

  /* ================================================================ الهاتف (نفس خدمة «تصوير ذكي»: رمز QR ← صفحة ANOUER على الهاتف) */
  function hidePhone() { const b = E && Q("phoneBox"); if (b) b.hidden = true; }
  function startPhone() {
    stopCam(); const box = Q("phoneBox"); Q("empty").hidden = true; box.hidden = false;
    if (!HOSTOK()) { Q("qr").innerHTML = '<div class="as-pe">متاح داخل برنامج ANOUER فقط</div>'; return; }
    if (E.phone) return;   // الخدمة تعمل — الرمز ظاهر
    Q("qr").innerHTML = '<i class="as-qsp"></i>';
    Anouer.call("fm.scan.phone", { on: 1 }).then(r => {
      if (!E) return; E.phone = true;
      const ips = r.ips || [], show = ip => { const u = "http://" + ip + ":" + r.port + "/m/" + r.token + "?k=item"; Q("qr").innerHTML = window.ANOUER_QR ? ANOUER_QR.svg(u, 190) : ""; Q("url").innerHTML = `<code>${esc(u)}</code>${ips.length > 1 ? `<select data-k="ip">${ips.map(i => `<option${i === ip ? " selected" : ""}>${esc(i)}</option>`).join("")}</select>` : ""}`; const sel = Q("ip"); if (sel) sel.onchange = () => show(sel.value); };
      if (!ips.length) { Q("qr").innerHTML = '<div class="as-pe">الحاسوب غير متصل بشبكة</div>'; return; }
      show(ips[0]);
      const pad = n => String(n).padStart(2, "0"), d = new Date(); E.since = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`; E.seen = E.seen || new Set();
      E.poll = setInterval(() => {
        if (!E) return;
        Anouer.call("fm.scan.poll", { since: E.since }).then(x => {
          if (!E || !x) return; E.since = x.now || E.since;
          (x.phone || []).forEach(f => { if (E.seen.has(f.path)) return; E.seen.add(f.path);
            Anouer.call("fm.scan.read", { path: f.path }).then(y => { if (E) { hidePhone(); setSrc("data:" + y.type + ";base64," + y.data); say("📱 وصلت صورة من الهاتف", "s"); } }).catch(() => { }); });
        }).catch(() => { });
      }, 1500);
    }).catch(e => { if (E) Q("qr").innerHTML = `<div class="as-pe">${esc(e.message || e)}</div>`; });
  }
  function stopPhone() { if (!E) return; if (E.poll) { clearInterval(E.poll); E.poll = null; } if (E.phone && HOSTOK()) { Anouer.call("fm.scan.phone", { on: 0 }).catch(() => { }); } E.phone = false; }

  /* ================================================================ الكاميرا */
  async function startCam(devId) {
    hidePhone(); const box = Q("camBox"); Q("empty").hidden = true; box.hidden = false;
    try {
      const st = await navigator.mediaDevices.getUserMedia({ video: devId ? { deviceId: { exact: devId }, width: { ideal: 1920 }, height: { ideal: 1080 } } : { width: { ideal: 1920 }, height: { ideal: 1080 }, facingMode: "environment" }, audio: false });
      if (!E) { st.getTracks().forEach(t => t.stop()); return; }
      E.stream = st; Q("video").srcObject = st;
      const devs = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === "videoinput"), cur = st.getVideoTracks()[0].getSettings().deviceId;
      Q("dev").innerHTML = devs.map((d, i) => `<option value="${esc(d.deviceId)}"${d.deviceId === cur ? " selected" : ""}>${esc(d.label || "كاميرا " + (i + 1))}</option>`).join(""); Q("dev").hidden = devs.length < 2;
    } catch (e) { box.hidden = true; if (!E.src) Q("empty").hidden = false; say("تعذّر فتح الكاميرا — " + (e.name === "NotAllowedError" ? "اسمح للبرنامج باستعمالها" : e.message || e.name), "e"); }
  }
  function stopCam() { if (E && E.stream) { E.stream.getTracks().forEach(t => t.stop()); E.stream = null; } const b = E && Q("camBox"); if (b) b.hidden = true; }
  function shot() { const v = Q("video"); if (!v || !v.videoWidth) return; const c = mk(v.videoWidth, v.videoHeight); c.getContext("2d").drawImage(v, 0, 0); stopCam(); setSrc(c.toDataURL("image/jpeg", 0.95)); }

  /* ================================================================ التصدير */
  function finalCanvas(Z) {
    const c = mk(S, S), x = c.getContext("2d"); E.padj = null; compose(x, 1);
    if (Z === S) return c; const o = mk(Z, Z), ox = o.getContext("2d"); ox.imageSmoothingQuality = "high"; ox.drawImage(c, 0, 0, Z, Z); return o;
  }
  function apply() {
    if (!E.src || !prod()) { say("صوّر المنتج أولاً", "w"); return; }
    if (E.view !== "comp") { setView("comp"); return; }
    const Z = +Q("osz").value || 1600, url = finalCanvas(Z).toDataURL("image/jpeg", 0.93);
    if (window.__itImg) __itImg.set(url); else { const im = G("itImgP"); if (im) { im.src = url; im.hidden = false; } }
    close(); say("تم وضع الصورة الإعلانية على الصنف ✓ — لا تنس الحفظ", "s");
  }
  function download() {
    if (!E.src || !prod()) return; const Z = +Q("osz").value || 1600, url = finalCanvas(Z).toDataURL("image/jpeg", 0.93), a = document.createElement("a");
    a.href = url; a.download = (info().name || "ANOUER-ad").replace(/[\\/:*?"<>|]+/g, " ").trim().slice(0, 60) + ".jpg"; document.body.appendChild(a); a.click(); a.remove();
  }

  window.ANOUER_ADSTUDIO = { open, close, _t: { setSrc, wand, edge, boxCut: (a, b, c, d) => boxCut(a, b, c, d), maskAll: () => { maskAll(); draw(); }, state: () => E } };
})();
