/* ANOUER — «التوريد التلقائي» (تحديثات 2026)
   • كي ينفد رصيد صنف بعد البيع (أو يوصل حد الطلب إذا اخترتو) ← يدوّر على أرخص مورد سبق الشراء منه
     (آخر سعر للوحدة الأساسية خلال سنة) ← ويبعثلو رسالة واتساب أوتوماتيكية من واتساب البرنامج: «ورّدلنا هذا الصنف».
   • الأصناف اللي تنفد قريب من بعضها لنفس المورد ← رسالة وحدة مجمّعة (بطاقة عدّ تنازلي: إرسال الآن / إلغاء).
   • إلزامية معلومات المورد: مورد بلا رقم ← نافذة إجبارية لإدخال رقمه قبل الإرسال (والطلب يبقى معلّق حتى يتدخل).
   • بلا تكرار: نفس الصنف ما يتطلبش مرة أخرى حتى تدخل مشتريات جديدة أو تفوت مدة «عدم التكرار» — حتى من أجهزة أخرى.
   • لوحة «التوريد التلقائي» (المشتريات ← التوريد التلقائي): السجل ، الأصناف المنتهية الآن ، الإعدادات ، معاينة الرسالة.
   المضيف: fm.reorder.offers / last / mark / log ، fm.suppliers.setPhone ، win.wa {op:"send"} (واتساب البرنامج). */
(function () {
  "use strict";
  if (window.ANOUER_REORDER) return;
  const A = () => window.Anouer;
  const HOST = () => !!(A() && A().available && A().call);
  const call = (a, p) => A().call(a, p || {});
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const N = v => (Math.round((+v || 0) * 100) / 100).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const say = (m, k) => { try { toast(m, k || "i"); } catch (e) { } };
  const snd = k => { try { window.ANOUER_SOUND && ANOUER_SOUND(k); } catch (e) { } };
  const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } } };
  const pad = n => String(n).padStart(2, "0");
  const stamp = d => { d = d || new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + " " + pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds()); };
  const parseAt = s => { const m = /^(\d{4})-(\d\d)-(\d\d)[ T](\d\d):(\d\d)(?::(\d\d))?/.exec(String(s || "")); return m ? new Date(+m[1], m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)).getTime() : 0; };

  /* ------------------------------------------------------------ الإعدادات */
  const CK = "anouer.reorder.cfg";
  const DEF = { on: true, mode: "auto", trig: "zero", cool: 3, wait: 25, sign: "" };
  const cfg = () => Object.assign({}, DEF, LS.get(CK, {}));
  const setCfg = o => LS.set(CK, Object.assign(cfg(), o));
  let CO = "";
  function company() { if (CO || !HOST()) return Promise.resolve(CO); return call("fm.settings.get", { prefix: "Company." }).then(d => (CO = (d && (d["Company.Name"] || d["Company.TradeName"])) || ""), () => ""); }

  /* ------------------------------------------------------------ الهاتف */
  function waNum(ph) {
    let d = String(ph || "").replace(/[^\d+]/g, "");
    if (d.startsWith("+")) d = d.slice(1); else if (d.startsWith("00")) d = d.slice(2);
    else if (/^0[5-7]\d{8}$/.test(d)) d = "213" + d.slice(1);          /* موبايل جزائري 05 / 06 / 07 */
    else if (/^0\d{8,9}$/.test(d)) d = "213" + d.slice(1);
    return /^\d{10,15}$/.test(d) ? d : "";
  }
  function phonesOf(o) {
    let x = {}; try { x = o.extra ? JSON.parse(o.extra) : {}; } catch (e) { }
    return [o.phone, x.ph, x.wa, x.ph2, x.ph3].map(waNum).filter(Boolean).filter((v, i, a) => a.indexOf(v) === i);
  }
  const prettyPh = d => d.startsWith("213") && d.length === 12 ? "0" + d.slice(3, 6) + " " + d.slice(6, 8) + " " + d.slice(8, 10) + " " + d.slice(10) : "+" + d;

  /* ------------------------------------------------------------ الواجهة (CSS) */
  (function css() {
    const st = document.createElement("style"); st.id = "roCss";
    st.textContent = `
.ro-card{position:fixed;left:18px;bottom:18px;z-index:100030;width:370px;max-width:calc(100vw - 36px);direction:rtl;font:13px "Segoe UI",Tahoma,sans-serif;color:#0f172a;
 border-radius:18px;background:rgba(255,255,255,.93);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,.9);
 box-shadow:0 24px 60px -20px rgba(15,23,42,.5),0 0 0 1px rgba(15,23,42,.05);overflow:hidden;animation:roIn .35s cubic-bezier(.2,1.2,.35,1)}
@keyframes roIn{from{opacity:0;transform:translateY(16px) scale(.97)}}
.ro-card .hd{display:flex;gap:11px;align-items:center;padding:13px 14px 10px;background:radial-gradient(120% 140% at 100% 0,#e9fbef 0,transparent 60%),radial-gradient(120% 140% at 0 0,#eef4ff 0,transparent 55%)}
.ro-ic{width:40px;height:40px;border-radius:13px;flex:none;display:grid;place-items:center;font-size:21px;background:linear-gradient(145deg,#22c55e,#15803d);box-shadow:inset 0 1px 0 rgba(255,255,255,.4),0 10px 20px -10px #15803d}
.ro-card .hd b{display:block;font-size:14px}.ro-card .hd small{display:block;color:#475569;font-size:11.5px;margin-top:1px}
.ro-card .x{margin-right:auto;align-self:flex-start;border:0;background:transparent;color:#94a3b8;font-size:15px;cursor:pointer;border-radius:8px;width:26px;height:26px}.ro-card .x:hover{background:#f1f5f9;color:#0f172a}
.ro-its{margin:0 12px;padding:6px 10px;border-radius:12px;background:#f8fafc;border:1px solid #eef1f5;max-height:150px;overflow:auto}
.ro-it{display:flex;gap:8px;align-items:center;padding:5px 0;border-bottom:1px dashed #e8ecf2}.ro-it:last-child{border:0}
.ro-it .n{flex:1;min-width:0;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ro-it .q{font-weight:700;color:#1d4ed8;white-space:nowrap}
.ro-it .p{color:#64748b;font-size:11.5px;white-space:nowrap}.ro-sv{font-size:10.5px;color:#15803d;font-weight:700;background:#dcfce7;border-radius:6px;padding:0 6px;white-space:nowrap}
.ro-ft{display:flex;gap:8px;align-items:center;padding:10px 12px 12px}
.ro-ft button{height:34px;border-radius:11px;font:inherit;font-weight:700;cursor:pointer;padding:0 14px}
.ro-go{flex:1;border:0;color:#fff;background:linear-gradient(145deg,#22c55e,#16a34a 55%,#15803d);box-shadow:inset 0 1px 0 rgba(255,255,255,.35),0 10px 20px -12px #15803d}
.ro-no{border:1px solid #e2e8f0;background:#fff;color:#334155}
.ro-tm{position:relative;height:3px;background:#eef1f5}.ro-tm i{position:absolute;inset:0;right:auto;background:linear-gradient(90deg,#22c55e,#86efac);transform-origin:left}
.ro-card.sent .ro-ic{background:linear-gradient(145deg,#3b82f6,#1d4ed8)}.ro-card.err .ro-ic{background:linear-gradient(145deg,#f87171,#dc2626)}
.ro-ov{position:fixed;inset:0;z-index:100060;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,.4);backdrop-filter:blur(6px);animation:roF .18s}
@keyframes roF{from{opacity:0}}
.ro-w{width:430px;max-width:calc(100vw - 30px);border-radius:20px;background:#fff;direction:rtl;font:13px "Segoe UI",Tahoma,sans-serif;color:#0f172a;box-shadow:0 30px 80px -24px rgba(15,23,42,.6);overflow:hidden;animation:roIn .26s cubic-bezier(.2,1,.3,1)}
.ro-w .hd{display:flex;gap:12px;align-items:center;padding:18px 20px 14px;background:radial-gradient(120% 140% at 100% 0,#fff1e6 0,transparent 60%),#fbfaf8;border-bottom:1px solid #f0f2f5}
.ro-w .hd .ro-ic{background:linear-gradient(145deg,#fb923c,#ea580c)}
.ro-w h3{margin:0;font-size:16px}.ro-w .hd small{display:block;color:#5b6478;font-size:12px;margin-top:2px}
.ro-w .bd{padding:16px 20px 6px;display:flex;flex-direction:column;gap:12px}
.ro-w .row{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;background:#f8fafc;border:1px solid #eef1f5}
.ro-w .row b{font-weight:700}.ro-w .row span{color:#64748b;font-size:12px}
.ro-w label.f{display:flex;flex-direction:column;gap:6px;font-weight:600;font-size:12.5px}
.ro-w input.ph{height:44px;border-radius:12px;border:1.5px solid #cbd5e1;padding:0 14px;font:600 17px Consolas,monospace;direction:ltr;text-align:left;outline:0;letter-spacing:.5px}
.ro-w input.ph:focus{border-color:#16a34a;box-shadow:0 0 0 4px rgba(22,163,74,.15)}.ro-w input.ph.bad{border-color:#dc2626;box-shadow:0 0 0 4px rgba(220,38,38,.12)}
.ro-w .hint{font-size:11.5px;color:#64748b}.ro-w .hint.e{color:#b91c1c;font-weight:600}
.ro-w .ft{display:flex;gap:8px;padding:12px 20px 18px}.ro-w .ft button{height:42px;border-radius:12px;font:inherit;font-size:13.5px;font-weight:700;cursor:pointer;padding:0 16px}
.ro-w .ft .ro-go{flex:1}
/* اللوحة */
.ro-pn{width:960px;max-width:calc(100vw - 30px);height:min(640px,calc(100vh - 40px));display:flex;flex-direction:column}
.ro-kp{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;padding:14px 20px 4px}
.ro-k{padding:10px 12px;border-radius:14px;background:#f8fafc;border:1px solid #eef1f5}.ro-k b{display:block;font-size:20px;font-weight:800}.ro-k small{color:#64748b;font-size:11.5px}
.ro-k.g b{color:#15803d}.ro-k.b b{color:#1d4ed8}.ro-k.o b{color:#c2410c}.ro-k.r b{color:#b91c1c}
.ro-tabs{display:flex;gap:6px;padding:10px 20px 0;border-bottom:1px solid #eef1f5}
.ro-tabs button{border:0;background:transparent;padding:9px 14px;font:inherit;font-weight:700;color:#64748b;cursor:pointer;border-bottom:3px solid transparent}
.ro-tabs button.on{color:#ea580c;border-bottom-color:#ea580c}
.ro-bd{flex:1;overflow:auto;padding:10px 20px 14px}
.ro-tb{width:100%;border-collapse:separate;border-spacing:0}
.ro-tb th{position:sticky;top:0;background:#fff;text-align:right;font-size:11.5px;color:#64748b;font-weight:700;padding:8px;border-bottom:1px solid #eef1f5}
.ro-tb td{padding:8px;border-bottom:1px solid #f4f6f9;vertical-align:middle}.ro-tb tr:hover td{background:#fafcff}
.ro-tb .num{font-variant-numeric:tabular-nums;white-space:nowrap}
.ro-st{display:inline-flex;align-items:center;gap:4px;padding:2px 9px;border-radius:999px;font-size:11px;font-weight:700;white-space:nowrap}
.ro-st.sent{background:#dcfce7;color:#15803d}.ro-st.send{background:#e0ecff;color:#1d4ed8}.ro-st.err{background:#fee2e2;color:#b91c1c}
.ro-st.nophone{background:#ffedd5;color:#c2410c}.ro-st.nosup{background:#f1f5f9;color:#475569}.ro-st.cancel{background:#f1f5f9;color:#64748b}
.ro-a{border:1px solid #dbe3ee;background:#fff;color:#1d4ed8;border-radius:8px;padding:3px 10px;font:600 11.5px inherit;cursor:pointer}.ro-a:hover{background:#eff6ff}
.ro-emp{text-align:center;color:#94a3b8;padding:46px 0;font-size:13px}.ro-emp i{display:block;font-size:34px;font-style:normal;margin-bottom:6px}
.ro-set{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.ro-set .box{padding:12px 14px;border-radius:14px;border:1px solid #eef1f5;background:#fbfcfe}
.ro-set .box h4{margin:0 0 8px;font-size:13px}.ro-set label{display:flex;align-items:center;gap:8px;padding:4px 0;cursor:pointer}
.ro-set input[type=number]{width:70px;height:30px;border:1px solid #cbd5e1;border-radius:8px;padding:0 8px;font:inherit}
.ro-set textarea{width:100%;min-height:150px;border:1px solid #e2e8f0;border-radius:12px;padding:10px;font:12.5px/1.6 "Segoe UI",Tahoma;background:#f8fafc;resize:vertical;direction:rtl}
.ro-sw{position:relative;width:40px;height:22px;flex:none}.ro-sw input{opacity:0;position:absolute;inset:0;margin:0;cursor:pointer}
.ro-sw i{position:absolute;inset:0;border-radius:999px;background:#cbd5e1;transition:.2s}.ro-sw i:after{content:"";position:absolute;top:3px;right:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:.2s;box-shadow:0 1px 3px rgba(0,0,0,.3)}
.ro-sw input:checked+i{background:#16a34a}.ro-sw input:checked+i:after{right:21px}
.ro-tools{display:flex;gap:8px;align-items:center;margin-bottom:10px}.ro-tools .sp{flex:1}
.ro-tools input[type=search]{height:32px;border:1px solid #e2e8f0;border-radius:10px;padding:0 10px;font:inherit;width:220px}
.ro-tools button{height:32px;border-radius:10px;border:0;padding:0 14px;font:700 12.5px inherit;cursor:pointer;color:#fff;background:linear-gradient(145deg,#22c55e,#15803d)}
.ro-tools button.gh{background:#fff;color:#334155;border:1px solid #e2e8f0}
html.dark .ro-card,html.dark .ro-w{background:rgba(17,22,36,.96);color:#eef2fb;border-color:rgba(255,255,255,.08)}
html.dark .ro-its,html.dark .ro-w .row,html.dark .ro-k,html.dark .ro-set .box{background:rgba(255,255,255,.04);border-color:rgba(255,255,255,.08)}
html.dark .ro-tb th{background:#111624;color:#94a3b8}html.dark .ro-tb td{border-color:rgba(255,255,255,.05)}html.dark .ro-tb tr:hover td{background:rgba(255,255,255,.03)}
html.dark .ro-card .hd,html.dark .ro-w .hd{background:rgba(255,255,255,.03);border-color:rgba(255,255,255,.06)}
html.dark .ro-no,html.dark .ro-a,html.dark .ro-tools button.gh{background:transparent;color:#cbd5e1;border-color:rgba(255,255,255,.15)}
html.dark .ro-set textarea,html.dark .ro-tools input,html.dark .ro-set input[type=number],html.dark .ro-w input.ph{background:rgba(255,255,255,.05);color:#eef2fb;border-color:rgba(255,255,255,.15)}`;
    document.head.appendChild(st);
  })();

  /* ------------------------------------------------------------ الرسالة */
  function message(sup, items, co) {
    const c = cfg(), L = [];
    L.push("السلام عليكم " + (sup.name || "") + " 👋");
    L.push("طلب توريد" + (co ? " من *" + co + "*" : "") + ":");
    L.push("");
    items.forEach((it, i) => {
      L.push((items.length > 1 ? (i + 1) + ") " : "📦 ") + "*" + it.name + "*");
      L.push("   الكمية: " + N(it.qty) + " " + (it.unit || "") + (it.code ? " · الكود: " + it.code : "") + (it.price ? " · آخر سعر: " + N(it.price) + " دج" : ""));
    });
    L.push("");
    L.push("نرجو تأكيد التوفّر وموعد التسليم 🙏");
    if (c.sign) L.push(c.sign);
    L.push("— طلب تلقائي من برنامج ANOUER");
    return L.join("\n");
  }

  /* ------------------------------------------------------------ التسجيل (مشترك) */
  function mark(entry) { if (!HOST()) return Promise.resolve(); return call("fm.reorder.mark", { entry }).catch(() => { }); }
  const entriesOf = (req, sup, items, st, err) => items.map(it => ({
    id: (it.req || req) + "-" + it.pid, req: it.req || req, pid: it.pid, name: it.name, code: it.code, supId: sup.id, sup: sup.name, phone: sup.ph || "",
    qty: it.qty, unit: it.unit, price: it.price, base: it.base, alt: it.alt || "", save: it.save || 0, st, err: err || "", at: stamp()
  }));

  /* ------------------------------------------------------------ الفحص بعد البيع */
  const INFL = new Set();
  function checkMany(pids) {
    const c = cfg(); if (!c.on || !HOST()) return;
    pids = [...new Set(pids.map(Number).filter(Boolean))].filter(p => !INFL.has(p)); if (!pids.length) return;
    pids.forEach(p => INFL.add(p));
    call("fm.reorder.last", { ids: pids }).catch(() => ({})).then(L => {
      L = L || {};
      return pids.reduce((pr, pid) => pr.then(() => one(pid, L[pid])).catch(() => { }), Promise.resolve());
    }).finally(() => pids.forEach(p => INFL.delete(p)));
  }
  function one(pid, last, force, reqHint) {
    const c = cfg();
    return call("fm.reorder.offers", { id: pid }).then(d => {
      if (!d || d.active === false) return;
      const thr = c.trig === "reorder" && +d.reorder > 0 ? +d.reorder : 0;
      if (!force && !(+d.stock <= thr)) return;
      if (!force && last && last.st !== "err" && last.st !== "cancel" && last.st !== "nophone") {
        const at = parseAt(last.at), bought = d.lastBuyAt && parseAt(d.lastBuyAt) > at;
        if (!bought && Date.now() - at < (+c.cool || 3) * 86400000) return;     /* طُلب مؤخراً ولم تدخل مشتريات بعده */
      }
      const offs = (d.offers || []).map(o => Object.assign(o, { phs: phonesOf(o) }));
      if (!offs.length) {
        const req = "R" + Date.now().toString(36);
        mark(entriesOf(req, { id: 0, name: "" }, [{ pid, name: d.name, code: d.code, qty: 0, unit: "", price: 0 }], "nosup")[0]);
        card({ kind: "nosup", title: "نفد «" + d.name + "»", sub: "لا يوجد مورد سبق الشراء منه — سجّل مشترياته باسم المورد لتفعيل الطلب التلقائي" });
        snd("err"); return;
      }
      const best = offs[0], alt = offs.find(o => o !== best);
      const qty = +best.qty > 0 ? +best.qty : Math.max(1, Math.ceil((+d.sold30 || 1) / (+best.factor || 1)));
      const item = { req: reqHint || "", pid, name: d.name, code: d.code, qty, unit: best.unit, price: +best.price, base: +best.base, factor: +best.factor || 1,
        alt: alt ? alt.name : "", save: alt ? Math.max(0, (+alt.base - +best.base) * (+best.factor || 1)) : 0, n: offs.length };
      const sup = { id: best.id, name: best.name, code: best.code, ph: best.phs[0] || "" };
      if (!sup.ph) return needPhone(sup, item, offs);
      queue(sup, item);
    });
  }

  /* ------------------------------------------------------------ إلزامية رقم المورد */
  const ASK = [];
  function needPhone(sup, item, offs) {
    const req = item.req || "R" + Date.now().toString(36); item.req = req;   /* نفس السطر في السجل يتحدّث بعد إدخال الرقم والإرسال */
    mark(entriesOf(req, sup, [item], "nophone", "المورد بلا رقم هاتف")[0]);
    ASK.push({ sup, item, offs }); if (ASK.length === 1) askNext();
  }
  function askNext() {
    const a = ASK[0]; if (!a) return;
    if (document.querySelector(".ro-ov.ph")) return;
    const { sup, item, offs } = a, other = offs.find(o => o.id !== sup.id && o.phs.length);
    const ov = document.createElement("div"); ov.className = "ro-ov ph";
    ov.innerHTML = `<div class="ro-w" role="dialog" aria-modal="true"><div class="hd"><span class="ro-ic">📇</span><div><h3>رقم المورد إجباري</h3><small>للطلب التلقائي لـ «${esc(item.name)}» — نفد الرصيد</small></div></div>
      <div class="bd"><div class="row">🏷️ <div style="flex:1"><b>${esc(sup.name)}</b><br><span>أرخص مورد: ${N(item.price)} دج / ${esc(item.unit)}${item.save > 0 ? ` · أوفر من «${esc(item.alt)}» بـ ${N(item.save)} دج` : ""}</span></div></div>
      <label class="f">رقم واتساب المورد<input class="ph" type="tel" inputmode="tel" placeholder="0550 12 34 56" autocomplete="off"></label>
      <div class="hint">يُحفظ في بطاقة المورد ، ويُرسل الطلب مباشرة من واتساب البرنامج.</div></div>
      <div class="ft"><button type="button" class="ro-go">حفظ الرقم وإرسال الطلب</button>${other ? `<button type="button" class="ro-no" data-o>إرسال لـ «${esc(other.name)}»</button>` : ""}<button type="button" class="ro-no" data-l>لاحقاً</button></div></div>`;
    document.body.appendChild(ov);
    const inp = ov.querySelector("input.ph"), hint = ov.querySelector(".hint"), go = ov.querySelector(".ro-go");
    setTimeout(() => inp.focus(), 40);
    const done = () => { ov.remove(); ASK.shift(); setTimeout(askNext, 200); };
    const save = () => {
      const w = waNum(inp.value);
      if (!w) { inp.classList.add("bad"); hint.className = "hint e"; hint.textContent = "رقم غير صالح — مثال: 0550123456 أو +213550123456"; snd("err"); inp.focus(); return; }
      go.disabled = true; go.textContent = "جارٍ الحفظ …";
      call("fm.suppliers.setPhone", { id: sup.id, phone: inp.value.trim() }).then(() => {
        sup.ph = w; say("تم حفظ رقم المورد «" + sup.name + "»", "s"); done(); queue(sup, item);
      }).catch(e => { go.disabled = false; go.textContent = "حفظ الرقم وإرسال الطلب"; hint.className = "hint e"; hint.textContent = String(e && e.message || e); snd("err"); });
    };
    go.onclick = save;
    inp.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); save(); } else if (e.key === "Escape") { e.preventDefault(); done(); } e.stopPropagation(); });
    inp.addEventListener("input", () => { inp.classList.remove("bad"); });
    const ob = ov.querySelector("[data-o]"); if (ob) ob.onclick = () => { done(); queue({ id: other.id, name: other.name, code: other.code, ph: other.phs[0] }, Object.assign({}, item, { price: +other.price, unit: other.unit, base: +other.base, qty: +other.qty || item.qty })); };
    ov.querySelector("[data-l]").onclick = () => { done(); say("الطلب معلّق — أدخل رقم «" + sup.name + "» من لوحة التوريد التلقائي", "w"); };
  }

  /* ------------------------------------------------------------ التجميع + بطاقة العدّ التنازلي */
  const PEND = new Map();
  function queue(sup, item) {
    const c = cfg();
    let g = PEND.get(sup.id);
    if (!g) { g = { sup, items: [], t0: Date.now(), el: null, tm: 0 }; PEND.set(sup.id, g); }
    if (!g.items.some(x => x.pid === item.pid)) g.items.push(item);
    snd("notify");
    drawPend(g);
    if (c.mode === "auto" && !g.tm) { g.due = Date.now() + (+c.wait || 25) * 1000; g.tm = setInterval(() => tick(g), 200); }
  }
  function tick(g) {
    const left = g.due - Date.now(), tot = (+cfg().wait || 25) * 1000;
    const bar = g.el && g.el.querySelector(".ro-tm i"); if (bar) bar.style.transform = "scaleX(" + Math.max(0, left / tot) + ")";
    const s = g.el && g.el.querySelector("[data-s]"); if (s) s.textContent = Math.max(0, Math.ceil(left / 1000));
    if (left <= 0) { clearInterval(g.tm); g.tm = 0; send(g); }
  }
  function drawPend(g) {
    const auto = cfg().mode === "auto";
    if (!g.el) { g.el = document.createElement("div"); g.el.className = "ro-card"; document.body.appendChild(g.el); stackCards(); }
    g.el.innerHTML = `<div class="hd"><span class="ro-ic">📦</span><div><b>طلب توريد لـ «${esc(g.sup.name)}»</b><small>${g.items.length > 1 ? g.items.length + " أصناف نفدت" : "نفد رصيد الصنف"} · أرخص مورد${g.sup.ph ? " · " + prettyPh(g.sup.ph) : ""}</small></div><button class="x" data-c title="إلغاء">✕</button></div>
      <div class="ro-its">${g.items.map(it => `<div class="ro-it"><span class="n" title="${esc(it.name)}">${esc(it.name)}</span><span class="q">${N(it.qty)} ${esc(it.unit)}</span><span class="p">${N(it.price)} دج</span>${it.save > 0 ? `<span class="ro-sv" title="مقارنة بـ «${esc(it.alt)}»">أرخص بـ ${N(it.save)}</span>` : ""}</div>`).join("")}</div>
      <div class="ro-ft"><button class="ro-go" data-g>${auto ? `إرسال الآن <span style="opacity:.8">(<span data-s>${Math.max(0, Math.ceil(((g.due || Date.now() + (+cfg().wait || 25) * 1000) - Date.now()) / 1000))}</span> ث)</span>` : "إرسال عبر واتساب"}</button><button class="ro-no" data-v>عرض الرسالة</button></div>${auto ? '<div class="ro-tm"><i></i></div>' : ""}`;
    g.el.querySelector("[data-g]").onclick = () => { clearInterval(g.tm); g.tm = 0; send(g); };
    g.el.querySelector("[data-c]").onclick = () => { clearInterval(g.tm); g.tm = 0; PEND.delete(g.sup.id); const req = "R" + Date.now().toString(36); entriesOf(req, g.sup, g.items, "cancel", "أُلغي").forEach(mark); fade(g.el); say("أُلغي طلب التوريد", "i"); };
    g.el.querySelector("[data-v]").onclick = () => company().then(co => preview(message(g.sup, g.items, co)));
  }
  function stackCards() { let b = 18; [...document.querySelectorAll(".ro-card")].reverse().forEach(c => { c.style.bottom = b + "px"; b += c.offsetHeight + 10; }); }
  function fade(el) { if (!el) return; el.style.transition = "opacity .3s,transform .3s"; el.style.opacity = "0"; el.style.transform = "translateY(10px)"; setTimeout(() => { el.remove(); stackCards(); }, 320); }
  function card(o) {
    const el = document.createElement("div"); el.className = "ro-card" + (o.kind === "nosup" || o.kind === "err" ? " err" : o.kind === "sent" ? " sent" : "");
    el.innerHTML = `<div class="hd"><span class="ro-ic">${o.kind === "sent" ? "✓" : o.kind === "nosup" ? "⚠" : "✕"}</span><div><b>${esc(o.title)}</b><small>${esc(o.sub || "")}</small></div><button class="x" title="إغلاق">✕</button></div>
      <div class="ro-ft" style="padding-top:2px"><button class="ro-no" data-p style="flex:1">لوحة التوريد التلقائي</button></div>`;
    document.body.appendChild(el); stackCards();
    el.querySelector(".x").onclick = () => fade(el); el.querySelector("[data-p]").onclick = () => { fade(el); open(); };
    setTimeout(() => fade(el), o.kind === "sent" ? 6000 : 12000);
  }

  /* ------------------------------------------------------------ الإرسال عبر واتساب البرنامج */
  const WAIT = {};
  window.addEventListener("anouer:wasend", e => { const m = e.detail || {}, w = WAIT[m.id]; if (!w) return; delete WAIT[m.id]; clearTimeout(w.tm); m.ok ? w.ok() : w.no(new Error(m.err || "تعذّر الإرسال")); });
  function waSend(ph, text, id) {
    if (!HOST()) return Promise.reject(new Error("يعمل داخل البرنامج فقط"));
    return new Promise((ok, no) => {
      WAIT[id] = { ok, no, tm: setTimeout(() => { delete WAIT[id]; no(new Error("لم يصل رد من واتساب البرنامج خلال 3 دقائق — تأكد من تسجيل الدخول في واتساب")); }, 180000) };
      call("win.wa", { op: "send", phone: ph, text, id }).then(r => {
        if (!r || r.queued !== true) { const w = WAIT[id]; delete WAIT[id]; if (w) clearTimeout(w.tm); no(new Error(r && r.err ? r.err : "واتساب البرنامج غير متاح — حدّث البرنامج")); }
      }).catch(e => { const w = WAIT[id]; delete WAIT[id]; if (w) clearTimeout(w.tm); no(e); });
    });
  }
  function send(g) {
    PEND.delete(g.sup.id);
    const req = "R" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
    if (g.el) { g.el.querySelector(".ro-ft").innerHTML = '<div style="flex:1;text-align:center;color:#1d4ed8;font-weight:700">⏳ جارٍ الإرسال عبر واتساب البرنامج …</div>'; const t = g.el.querySelector(".ro-tm"); if (t) t.remove(); }
    company().then(co => {
      const text = message(g.sup, g.items, co);
      entriesOf(req, g.sup, g.items, "send").forEach(mark);
      return waSend(g.sup.ph, text, req).then(() => {
        entriesOf(req, g.sup, g.items, "sent").forEach(mark); snd("ok");
        fade(g.el); card({ kind: "sent", title: "أُرسل طلب التوريد لـ «" + g.sup.name + "»", sub: g.items.length + " صنف · " + prettyPh(g.sup.ph) });
      }, e => {
        const m = String(e && e.message || e);
        entriesOf(req, g.sup, g.items, "err", m).forEach(mark); snd("err");
        fade(g.el); card({ kind: "err", title: "تعذّر إرسال طلب «" + g.sup.name + "»", sub: m + " — يمكنك إعادة الإرسال من اللوحة" });
      });
    });
  }

  /* ------------------------------------------------------------ الربط بحفظ فاتورة المبيعات */
  function hook() {
    if (typeof doSave !== "function") return false;
    if (doSave.__ro) return true;
    const orig = doSave;
    const w = function () {
      let pids = [];
      try { if (!document.querySelector(".inv.retmode")) pids = rows.filter(r => r && r.pid && +r.qty > 0 && !r.ret).map(r => r.pid); } catch (e) { }
      const r = orig.apply(this, arguments);
      if (pids.length && cfg().on) {
        setTimeout(() => checkMany(pids), 2500);
        /* حفظ بطيء في المضيف: فحص ثانٍ للأصناف اللي رصيدها المحلي وصل الصفر */
        setTimeout(() => { try { const low = pids.filter(id => { const p = products.find(x => x.id == id); return p && (typeof SWQ === "function" ? SWQ(p) : +p.stock) <= 0; }); if (low.length) checkMany(low); } catch (e) { } }, 9000);
      }
      return r;
    };
    Object.keys(orig).forEach(k => { try { w[k] = orig[k]; } catch (e) { } });
    w.__ro = 1;
    try { doSave = w; } catch (e) { } window.doSave = w;
    return true;
  }
  if (!hook()) { let k = 0; const t = setInterval(() => { if (hook() || ++k > 40) clearInterval(t); }, 300); }

  /* ------------------------------------------------------------ معاينة الرسالة */
  function preview(text) {
    const ov = document.createElement("div"); ov.className = "ro-ov";
    ov.innerHTML = `<div class="ro-w"><div class="hd"><span class="ro-ic" style="background:linear-gradient(145deg,#22c55e,#15803d)">💬</span><div><h3>الرسالة اللي تُرسل للمورد</h3><small>واتساب البرنامج · بلا أي خدمة خارجية</small></div></div>
      <div class="bd"><div style="white-space:pre-wrap;line-height:1.7;padding:12px 14px;border-radius:14px 14px 4px 14px;background:#dcf8c6;color:#0f172a;font-size:13px">${esc(text)}</div></div>
      <div class="ft"><button class="ro-no" style="flex:1">إغلاق</button></div></div>`;
    document.body.appendChild(ov);
    const close = () => ov.remove(); ov.querySelector(".ro-no").onclick = close; ov.addEventListener("mousedown", e => { if (e.target === ov) close(); });
  }

  /* ------------------------------------------------------------ لوحة «التوريد التلقائي» */
  const ST = { sent: ["sent", "✓ أُرسل"], send: ["send", "⏳ قيد الإرسال"], err: ["err", "✕ خطأ"], nophone: ["nophone", "📇 ناقص رقم المورد"], nosup: ["nosup", "⚠ بلا مورد"], cancel: ["cancel", "أُلغي"] };
  function open(tab) {
    if (document.querySelector(".ro-ov.pn")) return;
    const ov = document.createElement("div"); ov.className = "ro-ov pn";
    ov.innerHTML = `<div class="ro-w ro-pn" role="dialog" aria-label="التوريد التلقائي"><div class="hd"><span class="ro-ic" style="background:linear-gradient(145deg,#22c55e,#15803d)">📦</span><div><h3>التوريد التلقائي</h3><small>كي ينفد رصيد صنف: أرخص مورد + رسالة واتساب أوتوماتيكية «ورّدلنا»</small></div><button class="x" style="margin-right:auto;border:0;background:transparent;font-size:16px;cursor:pointer;color:#94a3b8" title="إغلاق">✕</button></div>
      <div class="ro-kp"></div><div class="ro-tabs"><button data-t="log">سجل الطلبات</button><button data-t="out">الأصناف المنتهية الآن</button><button data-t="set">الإعدادات</button></div><div class="ro-bd"></div></div>`;
    document.body.appendChild(ov);
    const bd = ov.querySelector(".ro-bd"), kp = ov.querySelector(".ro-kp");
    const close = () => { ov.remove(); document.removeEventListener("keydown", key, true); };
    const key = e => { if (e.key === "Escape" && !document.querySelector(".ro-ov.ph")) { e.preventDefault(); e.stopPropagation(); close(); } };
    document.addEventListener("keydown", key, true);
    ov.querySelector(".hd .x").onclick = close; ov.addEventListener("mousedown", e => { if (e.target === ov) close(); });
    let LOG = [];
    const kpis = () => {
      const t = stamp().slice(0, 10), w = Date.now() - 7 * 86400000;
      const c = k => LOG.filter(x => x.st === k).length;
      kp.innerHTML = `<div class="ro-k g"><b>${LOG.filter(x => x.st === "sent" && String(x.at).slice(0, 10) === t).length}</b><small>أُرسلت اليوم</small></div>
        <div class="ro-k b"><b>${LOG.filter(x => x.st === "sent" && parseAt(x.at) >= w).length}</b><small>هذا الأسبوع</small></div>
        <div class="ro-k o"><b>${c("nophone")}</b><small>ناقص رقم المورد</small></div><div class="ro-k r"><b>${c("err")}</b><small>أخطاء</small></div>
        <div class="ro-k"><b>${cfg().on ? (cfg().mode === "auto" ? "تلقائي" : "بتأكيد") : "متوقف"}</b><small>الوضع الحالي</small></div>`;
    };
    const tabs = ov.querySelectorAll(".ro-tabs button");
    const go = t => { tabs.forEach(b => b.classList.toggle("on", b.dataset.t === t)); (t === "out" ? drawOut : t === "set" ? drawSet : drawLog)(); };
    tabs.forEach(b => b.onclick = () => go(b.dataset.t));
    function drawLog() {
      bd.innerHTML = '<div class="ro-emp"><i>⏳</i>جارٍ التحميل …</div>';
      (HOST() ? call("fm.reorder.log") : Promise.resolve([])).then(l => {
        LOG = Array.isArray(l) ? l : []; kpis();
        if (!LOG.length) { bd.innerHTML = '<div class="ro-emp"><i>📭</i>لا توجد طلبات بعد — كي ينفد رصيد صنف بعد البيع ، يظهر طلبه هنا</div>'; return; }
        bd.innerHTML = `<div class="ro-tools"><input type="search" placeholder="بحث: صنف أو مورد …"><span class="sp"></span></div><table class="ro-tb"><thead><tr><th>الوقت</th><th>الصنف</th><th>المورد</th><th>الكمية</th><th>آخر سعر</th><th>الحالة</th><th></th></tr></thead><tbody></tbody></table>`;
        const tb = bd.querySelector("tbody"), q = bd.querySelector("input");
        const draw = () => {
          const s = q.value.trim().toLowerCase();
          tb.innerHTML = LOG.filter(x => !s || (String(x.name) + " " + String(x.sup)).toLowerCase().includes(s)).slice(0, 300).map((x, i) => {
            const S = ST[x.st] || ["cancel", x.st];
            const act = x.st === "err" || x.st === "cancel" ? `<button class="ro-a" data-r="${i}">إعادة الإرسال</button>` : x.st === "nophone" ? `<button class="ro-a" data-r="${i}">أدخل الرقم</button>` : x.st === "nosup" ? `<button class="ro-a" data-r="${i}">إعادة الفحص</button>` : "";
            return `<tr><td class="num">${esc(String(x.at || "").slice(5, 16).replace("-", "/"))}</td><td><b>${esc(x.name)}</b>${x.code ? `<br><small style="color:#94a3b8">${esc(x.code)}</small>` : ""}</td><td>${esc(x.sup || "—")}${x.phone ? `<br><small style="color:#94a3b8;direction:ltr;unicode-bidi:isolate">${esc(prettyPh(x.phone))}</small>` : ""}</td>
              <td class="num">${x.qty ? N(x.qty) + " " + esc(x.unit || "") : "—"}</td><td class="num">${x.price ? N(x.price) + " دج" : "—"}${+x.save > 0 ? ` <span class="ro-sv" title="أرخص من «${esc(x.alt || "")}»">أرخص بـ ${N(x.save)}</span>` : ""}</td><td><span class="ro-st ${S[0]}" title="${esc(x.err || "")}">${S[1]}</span></td><td>${act}</td></tr>`;
          }).join("");
          const L2 = LOG.filter(x => !s || (String(x.name) + " " + String(x.sup)).toLowerCase().includes(s));
          tb.querySelectorAll("[data-r]").forEach(b => b.onclick = () => { const x = L2[+b.dataset.r]; if (!x) return; close(); one(+x.pid, null, true, x.req || "").catch(e => say(String(e && e.message || e), "e")); });
        };
        q.oninput = draw; draw();
      }).catch(e => { bd.innerHTML = `<div class="ro-emp"><i>⚠</i>${esc(String(e && e.message || e))}</div>`; });
    }
    function drawOut() {
      let P = []; try { P = (products || []).filter(p => p && p.active !== false && p.type !== "service"); } catch (e) { }
      const stk = p => { try { return typeof SWQ === "function" ? +SWQ(p) || 0 : +p.stock || 0; } catch (e) { return +p.stock || 0; } };
      const out = P.filter(p => stk(p) <= 0).sort((a, b) => stk(a) - stk(b));
      if (!out.length) { bd.innerHTML = '<div class="ro-emp"><i>✅</i>لا توجد أصناف منتهية الرصيد حالياً</div>'; return; }
      bd.innerHTML = `<div class="ro-tools"><b>${out.length} صنف رصيده 0 أو أقل</b><span class="sp"></span><button class="gh" data-all>تحديد الكل</button><button data-send>طلب المحدد من أرخص مورد</button></div>
        <table class="ro-tb"><thead><tr><th style="width:30px"></th><th>الصنف</th><th>الكود</th><th>الرصيد</th></tr></thead><tbody>${out.slice(0, 500).map(p => `<tr><td><input type="checkbox" data-p="${p.id}"></td><td><b>${esc(p.name)}</b></td><td class="num">${esc(p.code || "")}</td><td class="num" style="color:#b91c1c;font-weight:700">${N(stk(p))}</td></tr>`).join("")}</tbody></table>`;
      bd.querySelector("[data-all]").onclick = () => { const cb = bd.querySelectorAll("[data-p]"), all = [...cb].every(x => x.checked); cb.forEach(x => x.checked = !all); };
      bd.querySelector("[data-send]").onclick = () => {
        const ids = [...bd.querySelectorAll("[data-p]:checked")].map(x => +x.dataset.p);
        if (!ids.length) { say("حدّد الأصناف أولاً", "w"); return; }
        if (!HOST()) { say("يعمل داخل البرنامج فقط", "w"); return; }
        close(); say("جارٍ تجهيز " + ids.length + " طلب توريد …", "i");
        ids.reduce((pr, id) => pr.then(() => one(id, null, true)).catch(() => { }), Promise.resolve());
      };
    }
    function drawSet() {
      const c = cfg();
      bd.innerHTML = `<div class="ro-set">
        <div class="box"><h4>التشغيل</h4><label><span class="ro-sw"><input type="checkbox" data-k="on" ${c.on ? "checked" : ""}><i></i></span>التوريد التلقائي مفعّل</label>
          <label><input type="radio" name="roM" value="auto" ${c.mode === "auto" ? "checked" : ""}> إرسال أوتوماتيكي (بعد <input type="number" data-k="wait" min="5" max="600" value="${c.wait}"> ثانية لتجميع الأصناف)</label>
          <label><input type="radio" name="roM" value="ask" ${c.mode === "ask" ? "checked" : ""}> اسألني قبل كل إرسال</label></div>
        <div class="box"><h4>متى يُطلب الصنف؟</h4><label><input type="radio" name="roT" value="zero" ${c.trig === "zero" ? "checked" : ""}> عند انقضاء الرصيد (0 أو أقل)</label>
          <label><input type="radio" name="roT" value="reorder" ${c.trig === "reorder" ? "checked" : ""}> عند الوصول لـ «حد الطلب» في بطاقة الصنف</label>
          <label>عدم تكرار الطلب لنفس الصنف لمدة <input type="number" data-k="cool" min="1" max="60" value="${c.cool}"> يوم (أو حتى تدخل مشتريات)</label></div>
        <div class="box"><h4>توقيع الرسالة (اختياري)</h4><input data-k="sign" value="${esc(c.sign)}" placeholder="مثال: محمد — 0550 12 34 56" style="width:100%;height:34px;border:1px solid #cbd5e1;border-radius:10px;padding:0 10px;font:inherit">
          <div style="font-size:11.5px;color:#64748b;margin-top:8px">الرسالة تُرسل من «واتساب البرنامج» (أيقونة واتساب في الشريط الأيمن) — سجّل الدخول فيه مرة وحدة بمسح QR.</div></div>
        <div class="box"><h4>معاينة الرسالة</h4><textarea readonly></textarea></div></div>`;
      const upd = () => {
        const o = {}; bd.querySelectorAll("[data-k]").forEach(i => { o[i.dataset.k] = i.type === "checkbox" ? i.checked : i.type === "number" ? Math.max(+i.min || 0, Math.min(+i.max || 999, +i.value || 0)) : i.value; });
        const m = bd.querySelector('input[name="roM"]:checked'), t = bd.querySelector('input[name="roT"]:checked'); if (m) o.mode = m.value; if (t) o.trig = t.value;
        setCfg(o); kpis();
        company().then(co => { bd.querySelector("textarea").value = message({ name: "مؤسسة النور للتوزيع" }, [{ name: "Cece BON 24P مشطة", code: "6132500980132", qty: 10, unit: "Batte", price: 3200 }, { name: "حليب كانديا 1 لتر", code: "6130001", qty: 6, unit: "كرتون", price: 720 }], co); });
      };
      bd.querySelectorAll("input").forEach(i => i.addEventListener(i.type === "text" || !i.type ? "input" : "change", upd));
      bd.querySelector('[data-k="sign"]').addEventListener("input", upd);
      upd();
    }
    if (HOST()) call("fm.reorder.log").then(l => { LOG = Array.isArray(l) ? l : []; kpis(); }).catch(() => kpis()); else kpis();
    go(tab || "log");
  }

  /* القائمة: المشتريات ← التوريد التلقائي */
  try { if (Array.isArray(window.__PURCH) && !window.__PURCH.some(x => x && x.t === "التوريد التلقائي")) window.__PURCH.push({ t: "التوريد التلقائي", ic: "pOrd", g: 1, run: () => open() }); } catch (e) { }

  window.ANOUER_REORDER = { open, check: checkMany, cfg, message };
})();
