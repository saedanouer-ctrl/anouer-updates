/* ANOUER — «التعرف على الصنف بالكاميرا» (للأصناف بدون باركود) — 2026
   أيقونة في رأس شاشة المبيعات ← الكاميرا ← يتعرف على الصنف من صورته المحفوظة في البرنامج ويضيفه للفاتورة فوراً.
   • بدون إنترنت وبدون مكتبات: بصمة بصرية لكل صورة صنف (ألوان HSV + اتجاهات الحواف HOG + توزيع الألوان) — مقارنة كل الأصناف في أقل من 10 مم/ث.
   • يتعلم: كل صنف تؤكده (أو «تعليم») تُحفظ بصمة صورته الحقيقية من الكاميرا ← دقة أعلى في المرة القادمة (محفوظة في القاعدة لكل الأجهزة).
   • قراءة النص على العلبة (Windows OCR — لاتيني + عربي) تقوّي النتيجة وتجد حتى الأصناف التي ليس لها صورة:
     الكلمة النادرة في أسماء الأصناف (مثل اسم العلامة) تكفي وحدها للتعرف.
   • الصور المكرّرة (نفس الصورة لعدة أصناف) وبطاقات ANOUER المؤقتة ليست صور منتجات ← تُتجاهَل في المقارنة.
   • إضافة تلقائية عند ثبات التعرف + اختيار بالأرقام 1–4 + المسافة للتجميد + L للتعليم. */
(function () {
  "use strict";
  if (window.ANOUER_VIS) return;
  const G = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const say = (m, k) => { try { toast(m, k || "i"); } catch (e) { console.log(m); } };
  const snd = k => { try { if (window.ANOUER_SOUND) ANOUER_SOUND(k); } catch (e) { } };
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const PR = () => window.ANOUER_PROPS;
  const PRODS = () => { try { return (typeof products !== "undefined" && Array.isArray(products)) ? products : []; } catch (e) { return []; } };
  const thumbOf = p => { try { return window.__pimg ? window.__pimg(p) || "" : ""; } catch (e) { return ""; } };
  const noBC = p => !String(p.barcode || "").trim();
  const fmt = n => (Math.round((+n || 0) * 100) / 100).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
  const CFG = Object.assign({ onlyNoBC: false, auto: true, dev: "", ocr: true, ai: true }, lsGet("anouer.vis.cfg", {}));
  const saveCfg = () => lsSet("anouer.vis.cfg", CFG);
  /* ترقية 2026-11: «بدون باركود فقط» كان مفعّلاً افتراضياً فيُخفي كل صنف له باركود (حتى لو كانت له صورة) ← يُطفأ مرة واحدة */
  if (!CFG.v2) { CFG.onlyNoBC = false; CFG.v2 = 1; saveCfg(); }
  const isPh = id => { try { return !!(PR() && +PR().get("pimg.ph." + id, 0)); } catch (e) { return false; } };

  /* =================================================================== البصمة البصرية */
  const N = 64, HB = 18, NB = HB * 2 + 4, CELLS = 4, OB = 8, HOGN = CELLS * CELLS * OB, LAY = 4, LAYN = LAY * LAY * 3;
  const DLEN = NB + HOGN + LAYN + 2;
  const cv1 = document.createElement("canvas"); cv1.width = cv1.height = N; const cx1 = cv1.getContext("2d", { willReadFrequently: true });
  const cv2 = document.createElement("canvas"); cv2.width = cv2.height = N; const cx2 = cv2.getContext("2d", { willReadFrequently: true });
  /* src: صورة/كانفس/فيديو ، r: مستطيل القص {x,y,w,h} بإحداثيات المصدر */
  function draw(cx, src, r) {
    cx.fillStyle = "#fff"; cx.fillRect(0, 0, N, N);
    const s = Math.max(r.w, r.h), dw = N * r.w / s, dh = N * r.h / s;
    cx.drawImage(src, r.x, r.y, r.w, r.h, (N - dw) / 2, (N - dh) / 2, dw, dh);
    return cx.getImageData(0, 0, N, N).data;
  }
  /* نموذج الخلفية: سطح مرسوم من ألوان الحواف (يتحمّل تدرّج الإضاءة والطاولة) + عتبة متكيّفة حسب تشتّت الحواف */
  function bgOf(d) {
    const px = (x, y) => { const k = (y * N + x) * 4; return [d[k], d[k + 1], d[k + 2]]; };
    const edge = f => { const a = []; for (let i = 0; i < N; i++) { const p = f(i); a.push(p); } return a; };
    const sm = a => a.map((_, i) => { const s = [0, 0, 0]; let n = 0; for (let j = Math.max(0, i - 5); j <= Math.min(N - 1, i + 5); j++) { s[0] += a[j][0]; s[1] += a[j][1]; s[2] += a[j][2]; n++; } return [s[0] / n, s[1] / n, s[2] / n]; });
    const avg2 = (p, q) => [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2, (p[2] + q[2]) / 2];
    const T = sm(edge(i => avg2(px(i, 0), px(i, 1)))), B = sm(edge(i => avg2(px(i, N - 1), px(i, N - 2)))), L = sm(edge(i => avg2(px(0, i), px(1, i)))), R = sm(edge(i => avg2(px(N - 1, i), px(N - 2, i))));
    const TL = T[0], TR = T[N - 1], BL = B[0], BR = B[N - 1], E = new Float32Array(N * N * 3);
    for (let y = 0; y < N; y++) { const v = y / (N - 1); for (let x = 0; x < N; x++) { const u = x / (N - 1), k = (y * N + x) * 3;
      for (let c = 0; c < 3; c++) E[k + c] = (1 - v) * T[x][c] + v * B[x][c] + (1 - u) * L[y][c] + u * R[y][c] - ((1 - u) * (1 - v) * TL[c] + u * (1 - v) * TR[c] + (1 - u) * v * BL[c] + u * v * BR[c]); } }
    const dev = [];
    for (let i = 0; i < N; i++) for (const [x, y] of [[i, 0], [i, N - 1], [0, i], [N - 1, i]]) { const k = (y * N + x), q = k * 4, e = k * 3; dev.push(Math.hypot(d[q] - E[e], d[q + 1] - E[e + 1], d[q + 2] - E[e + 2])); }
    dev.sort((p, q) => p - q);
    E.thr = Math.max(34, Math.min(100, dev[Math.floor(dev.length * 0.75)] * 2.2 + 16));
    return E;
  }
  function maskOf(d, E, thr) {
    const m = new Uint8Array(N * N); let n = 0, x0 = N, y0 = N, x1 = -1, y1 = -1;
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
      const i = y * N + x, k = i * 4, e = i * 3, dr = d[k] - E[e], dg = d[k + 1] - E[e + 1], db = d[k + 2] - E[e + 2];
      if (dr * dr + dg * dg + db * db > thr * thr) { m[i] = 1; n++; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    }
    /* تنظيف: حذف النقاط المعزولة */
    for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) { const i = y * N + x; if (!m[i]) continue; const nb = m[i - 1] + m[i + 1] + m[i - N] + m[i + N]; if (nb === 0) { m[i] = 0; n--; } }
    return { m, n, box: n ? { x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1 } : null };
  }
  /* وزن المركز: الصنف في وسط المربع والخلفية على الأطراف */
  const CW = (() => { const w = new Float32Array(N * N), c = (N - 1) / 2; for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { const r = Math.hypot(x - c, y - c) / (N / 2); w[y * N + x] = Math.max(0.08, Math.exp(-r * r * 1.6)); } return w; })();
  function hsv(r, g, b) {
    r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0; if (d > 1e-6) { h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; if (h < 0) h += 1; }
    return [h, mx ? d / mx : 0, mx];
  }
  function describe(src, rect) {
    /* 1) تحديد الصنف داخل القص (إزالة الخلفية) ثم إعادة الرسم على مقاس ثابت */
    let d = draw(cx1, src, rect), bg = bgOf(d), mk = maskOf(d, bg, bg.thr);
    const s = Math.max(rect.w, rect.h), ox = (N - N * rect.w / s) / 2, oy = (N - N * rect.h / s) / 2;
    if (mk.box && mk.n > N * N * 0.06 && mk.n < N * N * 0.97) {
      const b = mk.box, pad = 2, k = s / N;
      const r2 = { x: rect.x + Math.max(0, (b.x - pad - ox)) * k, y: rect.y + Math.max(0, (b.y - pad - oy)) * k, w: Math.min(rect.w, (b.w + pad * 2) * k), h: Math.min(rect.h, (b.h + pad * 2) * k) };
      if (r2.w > 8 && r2.h > 8) { d = draw(cx2, src, r2); bg = bgOf(d); mk = maskOf(d, bg, bg.thr); }
    }
    let M = mk.m; if (mk.n < N * N * 0.06) { M = new Uint8Array(N * N).fill(1); }
    const out = new Float32Array(DLEN);
    /* 2) هستوغرام الألوان (HSV) بتوزيع ناعم على الخانات */
    const gray = new Float32Array(N * N); let cnt = 0;
    const lay = new Float32Array(LAYN), layN = new Float32Array(LAY * LAY);
    for (let i = 0; i < N * N; i++) {
      const k = i * 4, r = d[k], g = d[k + 1], b = d[k + 2]; gray[i] = 0.299 * r + 0.587 * g + 0.114 * b;
      if (!M[i]) continue; cnt++;
      const [h, sa, v] = hsv(r, g, b), cw = CW[i];
      if (v < 0.18) out[NB - 4] += cw;
      else if (sa < 0.2) out[NB - 3 + (v < 0.45 ? 0 : v < 0.78 ? 1 : 2)] += cw;
      else { const f = h * HB, b0 = Math.floor(f) % HB, b1 = (b0 + 1) % HB, w1 = f - Math.floor(f), vb = v < 0.6 ? 0 : HB, ww = cw * (0.5 + sa / 2); out[vb + b0] += (1 - w1) * ww; out[vb + b1] += w1 * ww; }
      const x = i % N, y = (i / N) | 0, c = ((y * LAY / N) | 0) * LAY + ((x * LAY / N) | 0), sm = r + g + b + 1;
      lay[c * 3] += r / sm; lay[c * 3 + 1] += g / sm; lay[c * 3 + 2] += v; layN[c]++;
    }
    let hs = 0; for (let i = 0; i < NB; i++) hs += out[i]; if (hs > 0) for (let i = 0; i < NB; i++) out[i] /= hs;
    /* 3) اتجاهات الحواف (HOG مبسّط 4×4 خلايا × 8 اتجاهات) */
    const cs = N / CELLS;
    for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) {
      const gx = gray[y * N + x + 1] - gray[y * N + x - 1], gy = gray[(y + 1) * N + x] - gray[(y - 1) * N + x], mag = Math.sqrt(gx * gx + gy * gy);
      if (mag < 8) continue;
      let a = Math.atan2(gy, gx); if (a < 0) a += Math.PI; const f = a / Math.PI * OB, o0 = Math.floor(f) % OB, o1 = (o0 + 1) % OB, w1 = f - Math.floor(f);
      const c = ((y / cs) | 0) * CELLS + ((x / cs) | 0), base = NB + c * OB, mw = mag * (M[y * N + x] ? 1 : 0.25) * CW[y * N + x];
      out[base + o0] += mw * (1 - w1); out[base + o1] += mw * w1;
    }
    let hn = 0; for (let i = NB; i < NB + HOGN; i++) hn += out[i] * out[i]; hn = Math.sqrt(hn) || 1;
    for (let i = NB; i < NB + HOGN; i++) out[i] = Math.min(0.25, out[i] / hn); hn = 0; for (let i = NB; i < NB + HOGN; i++) hn += out[i] * out[i]; hn = Math.sqrt(hn) || 1; for (let i = NB; i < NB + HOGN; i++) out[i] /= hn;
    /* 4) توزيع الألوان المكاني + الشكل (نسبة الطول/العرض والامتلاء) */
    for (let c = 0; c < LAY * LAY; c++) { const n = layN[c]; for (let j = 0; j < 3; j++) out[NB + HOGN + c * 3 + j] = n ? lay[c * 3 + j] / n : -1; }
    const bx = mk.box || { w: N, h: N };
    out[DLEN - 2] = Math.log((bx.w + 1) / (bx.h + 1)); out[DLEN - 1] = cnt / (N * N);
    return out;
  }
  function sim(a, b) {
    let hi = 0; for (let i = 0; i < NB; i++) hi += Math.min(a[i], b[i]);
    let ho = 0; for (let i = NB; i < NB + HOGN; i++) ho += a[i] * b[i];
    let ld = 0, ln = 0; for (let i = NB + HOGN; i < NB + HOGN + LAYN; i++) { if (a[i] < 0 || b[i] < 0) continue; const t = a[i] - b[i]; ld += t * t; ln++; }
    const ly = ln ? Math.exp(-Math.sqrt(ld / ln) * 7) : 0.5;
    const sh = Math.exp(-Math.abs(a[DLEN - 2] - b[DLEN - 2]) * 1.6);
    return 0.5 * hi + 0.27 * Math.max(0, ho) + 0.15 * ly + 0.08 * sh;
  }
  const enc = f => { const q = new Uint8Array(f.length * 2); for (let i = 0; i < f.length; i++) { const v = Math.max(-1, Math.min(1, f[i])), u = Math.round((v + 1) * 32767.5); q[i * 2] = u & 255; q[i * 2 + 1] = u >> 8; } let s = ""; for (let i = 0; i < q.length; i++) s += String.fromCharCode(q[i]); return btoa(s); };
  const dec = s => { try { const b = atob(s), f = new Float32Array(b.length / 2); for (let i = 0; i < f.length; i++) f[i] = ((b.charCodeAt(i * 2) | (b.charCodeAt(i * 2 + 1) << 8)) / 32767.5) - 1; return f.length === DLEN ? f : null; } catch (e) { return null; } };
  /* الأوزان الحقيقية (LAY قد تتجاوز 1 للسطوع) — نحفظها مقسومة */
  const pack = f => { const g = Float32Array.from(f); for (let i = NB + HOGN; i < NB + HOGN + LAYN; i++) g[i] = g[i] < 0 ? -1 : g[i] / 2; g[DLEN - 2] = Math.max(-1, Math.min(1, g[DLEN - 2] / 4)); return enc(g); };
  const unpack = s => { const g = dec(s); if (!g) return null; for (let i = NB + HOGN; i < NB + HOGN + LAYN; i++) g[i] = g[i] < -0.99 ? -1 : g[i] * 2; g[DLEN - 2] *= 4; return g; };

  /* =================================================================== الفهرس */
  const IDX = { map: new Map(), built: 0, busy: null, gen: new Set(), groups: [], words: new Map(), df: new Map(), prod: new Map(), alias: new Map() };   /* id → {p, img:[desc], cam:[desc], key} */
  const CK = "anouer.vis.idx2";
  try { localStorage.removeItem("anouer.vis.idx1"); } catch (e) { }
  const keyOf = t => t ? t.length + ":" + t.slice(-24) + ":" + t.slice(80, 104) : "";
  /* صورة الصنف للعرض: الصورة العامة (مكرّرة/مؤقتة) لا تُعرض كأنها صورة هذا الصنف */
  const showT = p => IDX.gen.has(p.id) ? "" : thumbOf(p);
  /* كلمات أسماء الأصناف + ندرتها (كلمة تظهر في صنف واحد = تعريف قوي) */
  const wordsOf = name => Array.from(new Set(norm(name).split(" ").filter(x => x.length >= 3 && !/^\d+$/.test(x))));
  /* «كلمات العلبة» المتعلَّمة: ما قُرئ فعلاً على علبة كل صنف عند إضافته (تُحفظ في القاعدة) ← في المرة التالية تكفي قراءة Windows السريعة */
  const ALK = "vis.words";
  function aliasLoad() { IDX.alias = new Map(); try { const o = PR() && PR().get ? PR().get(ALK, {}) : {}; Object.keys(o || {}).forEach(k => { if (Array.isArray(o[k]) && o[k].length) IDX.alias.set(isNaN(+k) ? k : +k, o[k].slice(0, 20)); }); } catch (e) { } }
  function aliasSave() { try { const o = {}; IDX.alias.forEach((v, k) => { if (v.length) o[k] = v; }); if (PR() && PR().put) PR().put(ALK, o); } catch (e) { } }
  function buildWords(list) {
    IDX.words = new Map(); IDX.df = new Map(); IDX.prod = new Map();
    list.forEach(p => { const w = wordsOf(p.name); if (!w.length) return; IDX.words.set(p.id, w); IDX.prod.set(p.id, p); w.forEach(x => IDX.df.set(x, (IDX.df.get(x) || 0) + 1)); });
    IDX.alias.forEach((a, id) => { const w = IDX.words.get(id); if (!w) return; a.forEach(x => { if (w.indexOf(x) < 0) IDX.df.set(x, (IDX.df.get(x) || 0) + 1); }); });
  }
  const rare = w => { const d = IDX.df.get(w) || 1; return d <= 1 ? 1 : d === 2 ? 0.7 : d <= 5 ? 0.45 : d <= 15 ? 0.25 : 0.12; };
  function loadImg(src) { return new Promise(res => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = src; }); }
  function camViews(id) { const v = PR() && PR().get ? PR().get("vis.v." + id, null) : null; return Array.isArray(v) ? v.map(unpack).filter(Boolean) : []; }
  function build(onProg) {
    if (IDX.busy) return IDX.busy;
    IDX.busy = (async () => {
      const cache = lsGet(CK, {}), next = {}, list = PRODS().filter(p => p && p.active !== false);
      let done = 0; const todo = [];
      aliasLoad(); buildWords(list);
      /* نفس الصورة عند 3 أصناف أو أكثر (صورة عامة من المتجر/الاستيراد) أو بطاقة ANOUER المؤقتة ← ليست صورة منتج:
         كانت تعطي كل هذه الأصناف نفس النسبة بالضبط وتغطي على الصنف الحقيقي */
      const TH = new Map(), cnt = new Map(); IDX.gen = new Set(); IDX.map.clear();
      list.forEach(p => { const t = thumbOf(p); if (!t) return; const k = keyOf(t); TH.set(p.id, [t, k]); cnt.set(k, (cnt.get(k) || 0) + 1); });
      /* مجموعات الصور المكرّرة (للعرض والمسح من نافذة «صور عامة») */
      const GR = new Map(); IDX.groups = [];
      list.forEach(p => { const tk = TH.get(p.id); if (!tk || cnt.get(tk[1]) < 6 || isPh(p.id)) return; let g = GR.get(tk[1]); if (!g) { g = { t: tk[0], ps: [] }; GR.set(tk[1], g); IDX.groups.push(g); } g.ps.push(p); });
      IDX.groups.sort((a, b) => b.ps.length - a.ps.length);
      list.forEach(p => {
        const tk = TH.get(p.id), cam = camViews(p.id);
        let t = tk ? tk[0] : "", key = tk ? tk[1] : "";
        /* نفس الصورة لـ 3–5 أصناف = أذواق/أحجام نفس المنتج (STANUTS ×3) ← صورة حقيقية تُعرض وتُقارَن ؛ 6 فأكثر = صورة عامة */
        if (t && (cnt.get(key) >= 6 || isPh(p.id))) { IDX.gen.add(p.id); t = ""; key = ""; }
        if (!t && !cam.length) return;
        const e = { p, img: [], cam, key };
        if (t) { const c = cache[p.id]; if (c && c.k === key && Array.isArray(c.d)) { const fs = c.d.map(unpack).filter(Boolean); if (fs.length) { e.img = fs; next[p.id] = c; } } if (!e.img.length) todo.push([e, t]); }
        IDX.map.set(p.id, e);
      });
      for (const [e, t] of todo) {
        const im = await loadImg(t); done++;
        if (im && im.naturalWidth) {
          const W = im.naturalWidth, H = im.naturalHeight, f = describe(im, { x: 0, y: 0, w: W, h: H }); e.img = [f];
          /* منظر مقرَّب (وسط العلبة): الصنف القريب من الكاميرا يملأ المربع فلا تظهر حوافه — نقارن بالاثنين */
          try { const z = Math.min(W, H) * 0.62; if (z >= 40) e.img.push(describe(im, { x: (W - z) / 2, y: (H - z) / 2, w: z, h: z })); } catch (x) { }
          next[e.p.id] = { k: e.key, d: e.img.map(pack) };
        }
        if (onProg && done % 8 === 0) { onProg(done, todo.length); await new Promise(r => setTimeout(r, 0)); }
      }
      lsSet(CK, next); IDX.built = Date.now(); IDX.busy = null;
      return IDX.map;
    })();
    return IDX.busy;
  }
  function learn(p, f) {
    if (!f || f[DLEN - 1] > 0.96 || f[DLEN - 1] < 0.05) return false;   /* لم يُفصل الصنف عن الخلفية ← لا نتعلّم */
    const e = IDX.map.get(p.id) || { p, img: [], cam: [], key: "" }; IDX.map.set(p.id, e);
    e.cam.unshift(f); if (e.cam.length > 6) e.cam.length = 6;
    try { if (PR() && PR().put) PR().put("vis.v." + p.id, e.cam.map(pack)); } catch (x) { }
    return true;
  }
  /* «تراجع»: يُنسى ما تعلّمه البرنامج من هذه اللقطة + تُحفظ كمثال سلبي (هذا المنظر ليس هذا الصنف) */
  function unlearn(p, f) {
    const e = IDX.map.get(p.id);
    /* كل البصمات المتعلَّمة التي تشبه هذا المنظر (تعلّم خاطئ قديم) تُحذف — ليس فقط آخر واحدة */
    if (e && f) { const n0 = e.cam.length; e.cam = e.cam.filter(g => g !== f && sim(g, f) <= 0.86); if (e.cam.length !== n0) { try { if (PR() && PR().put) PR().put("vis.v." + p.id, e.cam.map(pack)); } catch (x) { } } }
    if (!f) return;
    const n = negOf(p.id); n.unshift(f); if (n.length > 8) n.length = 8;
    try { if (PR() && PR().put) PR().put("vis.n." + p.id, n.map(pack)); } catch (x) { }
  }
  /* هذا المنظر يخص صنفاً واحداً: تُحذف البصمات المشابهة من كل الأصناف الأخرى (تنظيف أخطاء التعلّم السابقة) */
  function purge(f, keepId) {
    if (!f) return 0; let n = 0;
    IDX.map.forEach((e, id) => { if (id === keepId || !e.cam.length) return; const n0 = e.cam.length; e.cam = e.cam.filter(g => sim(g, f) <= 0.86);
      if (e.cam.length !== n0) { n += n0 - e.cam.length; try { if (PR() && PR().put) PR().put("vis.v." + id, e.cam.map(pack)); } catch (x) { } } });
    return n;
  }
  const NEG = new Map();
  function negOf(id) { if (!NEG.has(id)) { const v = PR() && PR().get ? PR().get("vis.n." + id, null) : null; NEG.set(id, Array.isArray(v) ? v.map(unpack).filter(Boolean) : []); } return NEG.get(id); }
  let BGF = null;   /* بصمة الخلفية الحالية (الطاولة) — بصمة متعلَّمة تشبه الخلفية = تعلّم ضعيف */

  /* =================================================================== المطابقة (+ نص العلبة) */
  const norm = s => String(s || "").toLowerCase().replace(/[à-ɏ]/g, c => c.normalize("NFD").replace(/[\u0300-\u036f]/g, "")).replace(/[ً-ْـ]/g, "").replace(/[أإآا]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/[^a-z0-9؀-ۿ]+/g, " ").trim();
  const NOOCR = () => ({ toks: [], raw: [], ai: [], at: 0, f: null });
  let OCR = NOOCR();
  const SAME = 0.66;   /* نفس المنظر (علبة ممسوكة باليد تتحرك قليلاً) */

  /* ------------------------------------------------------------------ حضور الصنف أمام الكاميرا
     نموذج خلفية طويل المدى: وسيط آخر ~31 لقطة مصغّرة (32×18) — الرفوف ثابتة فتغلب على الوسيط حتى لو مرّ أشخاص أو عُرضت علب.
     «الحضور» = نسبة خلايا المربع الأوسط التي تختلف عن هذه الخلفية. بدون حضور: لا إضافة تلقائية ولا قراءة ولا تعلّم
     (كان يقرأ أسماء علب الرفوف البعيدة ويضيفها ، ثم يتعلّم «صورة الخلفية» كأنها الصنف فيضيفه في كل مرة). */
  const GW = 32, GH = 18, GN = GW * GH, PRES = 0.36, IDLE = 0.12;
  const cvg = document.createElement("canvas"); cvg.width = GW; cvg.height = GH; const cxg = cvg.getContext("2d", { willReadFrequently: true });
  const BGM = { S: [], med: null, saved: 0, n: 0 }, BGK = "anouer.vis.bgm", TRUST = 20;   /* n = عدد اللقطات المجمّعة (محفوظ) — النموذج يُعتمد بعد 20 لقطة ≈ 40 ثانية في أول استعمال فقط */
  function gridOf(v) { cxg.drawImage(v, 0, 0, GW, GH); const d = cxg.getImageData(0, 0, GW, GH).data, a = new Uint8Array(GN * 3); for (let i = 0; i < GN; i++) { a[i * 3] = d[i * 4]; a[i * 3 + 1] = d[i * 4 + 1]; a[i * 3 + 2] = d[i * 4 + 2]; } return a; }
  function bgmLoad() {
    BGM.S = []; BGM.med = null; BGM.saved = Date.now(); BGM.n = 0;
    try { const s = lsGet(BGK, null), b = s && s.d ? atob(s.d) : ""; if (b.length === GN * 3) { BGM.n = +s.n || 0; const a = new Uint8Array(GN * 3); for (let i = 0; i < a.length; i++) a[i] = b.charCodeAt(i); BGM.med = a; for (let k = 0; k < 9; k++) BGM.S.push(a); } } catch (e) { }
  }
  function bgmAdd(a) {
    BGM.S.push(a); if (BGM.S.length > 31) BGM.S.shift(); BGM.n++;
    const n = BGM.S.length; if (n < 6) return;
    const m = new Uint8Array(GN * 3), t = new Uint8Array(n), h = n >> 1;
    for (let i = 0; i < m.length; i++) { for (let k = 0; k < n; k++) t[k] = BGM.S[k][i]; t.sort(); m[i] = t[h]; }
    BGM.med = m;
    const now = Date.now(); if (now - BGM.saved > 45000 || BGM.n === TRUST) { BGM.saved = now; let x = ""; for (let i = 0; i < m.length; i++) x += String.fromCharCode(m[i]); lsSet(BGK, { d: btoa(x), at: now, n: Math.min(BGM.n, 999) }); }
  }
  function presence(a, v) {
    const m = BGM.med; if (!m || BGM.n < TRUST || !v.videoWidth) return null;
    const r = cropRect(v), cw = v.videoWidth / GW, ch = v.videoHeight / GH;
    const x0 = Math.max(0, Math.round(r.x / cw)), x1 = Math.min(GW, Math.round((r.x + r.w) / cw)), y0 = Math.max(0, Math.round(r.y / ch)), y1 = Math.min(GH, Math.round((r.y + r.h) / ch));
    /* تعويض تغيّر التعريض/الإضاءة: نسبة السطوع خارج المربع */
    let la = 0, lm = 0;
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) { if (x >= x0 && x < x1 && y >= y0 && y < y1) continue; const i = (y * GW + x) * 3; la += a[i] + a[i + 1] + a[i + 2]; lm += m[i] + m[i + 1] + m[i + 2]; }
    const g = la > 0 ? Math.max(0.7, Math.min(1.45, lm / la)) : 1;
    let n = 0, c = 0;
    for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const i = (y * GW + x) * 3; n++; if (Math.abs(a[i] * g - m[i]) + Math.abs(a[i + 1] * g - m[i + 1]) + Math.abs(a[i + 2] * g - m[i + 2]) > 72) c++; }
    return n ? c / n : null;
  }
  /* كلمات الخلفية: ما يُقرأ والمشهد فارغ (أسماء علب الرفوف) — تُتجاهَل في قراءة Windows عند عرض صنف */
  const BGW = new Map(), BWK = "anouer.vis.bgw"; let BGI = 0;
  function bgwLoad() { BGW.clear(); BGI = 0; try { const o = lsGet(BWK, null); if (o && o.w) { BGI = +o.i || 0; Object.keys(o.w).forEach(k => BGW.set(k, o.w[k])); } } catch (e) { } }
  function bgwAdd(toks) {
    BGI++; toks.forEach(t => { const e = BGW.get(t) || [0, BGI]; e[0] = Math.min(9, e[0] + 1); e[1] = BGI; BGW.set(t, e); });
    BGW.forEach((e, k) => { if (BGI - e[1] > 60) BGW.delete(k); });   /* لم تُرَ في آخر 60 قراءة فارغة ← لم تعد في الخلفية */
    const w = {}; BGW.forEach((e, k) => { w[k] = e; }); lsSet(BWK, { i: BGI, w });
  }
  const isBgW = t => { const e = BGW.get(t); return !!(e && e[0] >= 2); };
  /* الكلمات المقروءة تتراكم ما دام المنظر نفسه (كل قراءة تلتقط كلمات مختلفة) وتُمسح عند تغيّر العلبة.
     raw = قراءة Windows (تُحذف منها كلمات الخلفية) ، ai = قراءة Gemini (للعلبة الأمامية فقط) ، toks = المعتمد */
  function addToks(toks, f0, ai) {
    const same = OCR.f && f0 && Date.now() - OCR.at < 8000 && sim(f0, OCR.f) > SAME;
    const raw = same ? OCR.raw.slice() : [], aiT = same ? OCR.ai.slice() : [], dst = ai ? aiT : raw;
    toks.forEach(t => { if (dst.indexOf(t) < 0) dst.push(t); }); if (dst.length > 60) dst.splice(0, dst.length - 60);
    const eff = aiT.slice(); raw.forEach(t => { if (!isBgW(t) && eff.indexOf(t) < 0) eff.push(t); });
    OCR = { toks: eff, raw, ai: aiT, at: toks.length || !same ? Date.now() : OCR.at, f: same ? OCR.f : (f0 || null) };
  }
  const splitToks = s => norm(s).split(" ").filter(t => t.length >= 3 && !/^\d+$/.test(t));
  /* تطابق كلمة من اسم الصنف مع كلمات العلبة: 2 = مطابقة تامة ، 1 = تقريبية (جزء/خطأ حرف واحد في القراءة) */
  function ed1(a, b) { const la = a.length, lb = b.length; if (Math.abs(la - lb) > 1) return false; let i = 0, j = 0, d = 0;
    while (i < la && j < lb) { if (a[i] === b[j]) { i++; j++; continue; } if (++d > 1) return false; if (la > lb) i++; else if (lb > la) j++; else { i++; j++; } } return d + (la - i) + (lb - j) <= 1; }
  /* ✦ (2026-11-25) مطابقة الاسم عربي ↔ لاتيني: «ستانوتس» = «STANUTS» ، «بيبسي» = «PEPSI» ، «شيبس» = «CHIPS»
     مفتاح صوتي = هيكل الحروف الساكنة بعد توحيد الكتابتين (p=b ، v=f ، c/q/k/ق/ك ، ch/sh/ش=s …) — يُحسب مرة واحدة لكل كلمة */
  const AR2L = { "ب": "b", "پ": "b", "ت": "t", "ط": "t", "ث": "t", "ج": "j", "چ": "s", "خ": "k", "د": "d", "ض": "d", "ذ": "d", "ظ": "d", "ر": "r", "ز": "z", "س": "s", "ص": "s", "ش": "s", "غ": "g", "ڨ": "g", "گ": "g", "ف": "f", "ڤ": "f", "ق": "k", "ك": "k", "ل": "l", "م": "m", "ن": "n" };
  const PHC = new Map();
  const isAr = w => /[؀-ۿ]/.test(w);
  function phon(w) {
    let k = PHC.get(w); if (k !== undefined) return k;
    if (isAr(w)) { k = ""; for (const c of w) k += AR2L[c] || ""; }
    else k = w.replace(/([a-z])\1+/g, "$1").replace(/sch|sh|ch/g, "s").replace(/ph/g, "f").replace(/dj/g, "j").replace(/qu|ck|kh|q/g, "k").replace(/gh/g, "g").replace(/th/g, "t").replace(/c(?=[eiy])/g, "s").replace(/g(?=[eiy])/g, "j").replace(/c/g, "k").replace(/x/g, "ks").replace(/v/g, "f").replace(/p/g, "b").replace(/[aeiouyhw0-9]/g, "");
    if (PHC.size > 60000) PHC.clear(); PHC.set(w, k); return k;
  }
  /* نوع المنتج بلغتين: «CACAHUETES» على العلبة ↔ «كاوكاو» في اسم الصنف — دليل مساعد (لا يُعتمد وحده) */
  const SYN0 = [["cacahuetes cacahuete arachides arachide peanuts peanut", "كاوكاو فول"], ["chocolat chocolate choco cacao", "شكلاطه شوكولا شوكولاطه شكولاطه شوكولاته كاكاو"], ["lait milk", "حليب"], ["biscuit biscuits cookies", "بسكويت بيسكوي"],
    ["gaufrette gaufrettes wafer wafers", "قوفريت ڨوفريت ويفر"], ["bonbon bonbons candy", "حلوى بونبون"], ["chewing gum", "علك علكه"], ["jus juice", "عصير"], ["eau water", "ماء"], ["cafe coffee", "قهوه"], ["sucre sugar", "سكر"], ["huile oil", "زيت"],
    ["farine flour", "فرينه طحين دقيق"], ["riz rice", "ارز روز"], ["pates pasta spaghetti macaroni", "عجائن مقرونه سباقيتي معكرونه"], ["tomate tomates tomato", "طماطم"], ["fromage cheese", "جبن فرماج"], ["beurre butter", "زبده"], ["yaourt yogurt yoghurt", "ياغورت ياوورت"],
    ["savon soap", "صابون"], ["shampoing shampoo shampooing", "شامبو"], ["fraise strawberry", "فراوله فراز"], ["citron lemon", "ليمون قارص"], ["orange", "برتقال تشينه"], ["menthe mint", "نعناع"], ["vanille vanilla", "فانيلا فانيليا"], ["noisette noisettes hazelnut", "بندق"],
    ["amande amandes almond", "لوز"], ["pistache pistaches", "فستق"], ["miel honey", "عسل"], ["sel salt", "ملح"], ["thon tuna", "تونه طون"], ["sardine sardines", "سردين"], ["confiture jam", "معجون كونفيتور"], ["levure", "خميره"], ["semoule", "سميد"], ["couscous", "كسكس كسكسي"],
    ["lentilles", "عدس"], ["haricot haricots", "لوبيا فاصوليا"], ["chiches", "حمص"], ["dattes", "تمر"], ["nouilles noodles", "نودلز"], ["tournesol graines", "زريعه"], ["vinaigre vinegar", "خل"], ["piment harissa", "هريسه حار"], ["olive olives", "زيتون"], ["detergent lessive", "غسيل مسحوق"]];
  const SYN = new Map();
  SYN0.forEach(([l, a]) => { const L = l.split(" "), A = a.split(" "); L.forEach(x => SYN.set(x, (SYN.get(x) || []).concat(A))); A.forEach(x => SYN.set(x, (SYN.get(x) || []).concat(L))); });
  function ed2(a, b) { const la = a.length, lb = b.length; if (Math.abs(la - lb) > 2) return false; let p = [], c = []; for (let j = 0; j <= lb; j++) p[j] = j;
    for (let i = 1; i <= la; i++) { c = [i]; let m = i; for (let j = 1; j <= lb; j++) { c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); if (c[j] < m) m = c[j]; } if (m > 2) return false; p = c; } return p[lb] <= 2; }
  /* سياق القراءة (يُبنى مرة لكل قراءة): الكلمات + مرادفاتها + مفاتيحها الصوتية + النص ملتصقاً (كلمة قُسمت على سطرين) */
  function readCtx(toks) {
    const T = new Set(toks), Y = new Set(), K = new Map(), K1 = [];
    toks.forEach(t => { const y = SYN.get(t); if (y) y.forEach(x => { if (!T.has(x)) Y.add(x); }); if (t.length >= 4) { const k = phon(t); if (k.length >= 3) { if (!K.has(k)) K.set(k, []); K.get(k).push(t); if (k.length >= 5) K1.push(k); } } });
    const G3 = new Set(); toks.forEach(t => { for (let i = 0; i + 3 <= t.length; i++) G3.add(t.substr(i, 3)); });
    return { T, Y, K, K1, G3, toks, glue: toks.join("") };
  }
  /* تطابق كلمة من اسم الصنف مع كلمات العلبة: 2 = تامة ، 1.6 = نفس النطق بكتابة أخرى (عربي ↔ لاتيني) ، 1 = تقريبية */
  function wHit(w, C) {
    if (C.T.has(w)) return 2;
    if (w.length >= 4) {
      const k = phon(w);
      if (k.length >= 3) { const m = C.K.get(k); if (m) { const cross = m.some(t => isAr(t) !== isAr(w)); if (cross && (k.length >= 4 || m.some(t => t.length >= 4))) return 1.6; if (cross || k.length >= 4) return 1; } }
      if (k.length >= 5) for (const q of C.K1) if (ed1(q, k)) return 1;
    }
    if (C.Y.has(w)) return 0.7;   /* مرادف نوع المنتج: دليل مساعد فقط */
    for (const t of C.toks) { if (t.length < 4 || w.length < 4) continue; if ((t.length >= 5 && w.length >= 5 && ed1(t, w)) || (t.length >= 8 && w.length >= 8 && ed2(t, w)) || (t.indexOf(w) >= 0 || w.indexOf(t) >= 0) && Math.min(t.length, w.length) >= Math.max(t.length, w.length) * 0.6) return 1; }
    if (w.length >= 6 && C.glue.indexOf(w) >= 0) return 1;
    /* خط مزخرف قُرئ مقطّعاً («stan» + «nuts» ، «tanut») ← أغلب مقاطع الكلمة الثلاثية موجودة في المقروء */
    if (w.length >= 6) { let n = 0, m = w.length - 2; for (let i = 0; i < m; i++) if (C.G3.has(w.substr(i, 3))) n++; if (n >= Math.max(4, Math.ceil(m * 0.75))) return 1; }
    return 0;
  }
  /* نتيجة النص لكل صنف — تُحسب مرة واحدة لكل قراءة (كانت تُعاد على كل الأصناف في كل لقطة) */
  const TS = { ocr: null, words: null, map: new Map() };
  function textScores() {
    if (TS.ocr === OCR && TS.words === IDX.words) return TS.map;
    if (!IDX.words.size) { aliasLoad(); buildWords(PRODS().filter(p => p && p.active !== false)); }
    const C = readCtx(OCR.toks), map = new Map();
    IDX.words.forEach((w, id) => {
      let got = 0, all = 0, n = 0, strong = false, brand = 0, exact = 0;
      const fl = w.findIndex(x => /[a-z]/.test(x)), fa = w.findIndex(x => /[؀-ۿ]/.test(x));   /* «كويكلي Quickly 96p»: العلامة = أول كلمة عربية وأول كلمة لاتينية */
      w.forEach((x, wi) => { const r = rare(x); all += r; const h = wHit(x, C); if (!h) return; n++; if (h > 1) exact++; got += r * (h === 2 ? 1 : h > 1 ? 0.92 : 0.8); if (h > 1 && r >= 0.7 && x.length >= 4 && (wi === fl || wi === fa)) strong = true;
        /* اسم العلامة مقروء لكنه مشترك بين أذواق/أحجام قليلة («STANUTS» ×3) ← كلها تصعد لأول القائمة للاختيار (بلا إضافة تلقائية) */
        if (x.length >= 4 && (wi === fl || wi === fa) && (IDX.df.get(x) || 1) <= 8) brand = Math.max(brand, h > 1 ? 1 : h >= 1 ? 0.8 : 0); });
      /* الكلمة النادرة (اسم العلامة) تكفي وحدها ؛ الكلمات الشائعة (حليب، شوكولا…) تحتاج أكثر من واحدة */
      strong = strong || (n >= 2 && exact >= 1 && Math.min(1, got) >= 0.9);
      /* كلمات العلبة المتعلَّمة: دليل مساعد فقط (لا يُعتمد وحده) — مع بصمة الكاميرا يكفي */
      const al = IDX.alias.get(id); if (al) al.forEach(x => { if (w.indexOf(x) >= 0) return; const r = rare(x); all += r * 0.5; const h = wHit(x, C); if (!h) return; n++; got += r * (h === 2 ? 1 : h > 1 ? 0.92 : 0.8); });
      if (!n) return;
      const S = Math.min(1, got);
      /* كلمة واحدة ليست اسم العلامة (نكهة: caramel، chocolat…) ← تقوية خفيفة فقط ولا تُعتمد وحدها */
      let bb = Math.min(strong ? 0.42 : 0.2, 0.34 * S + 0.08 * Math.min(1, got / all));
      if (brand && !strong) bb = Math.max(bb, Math.min(0.4, 0.2 + 0.12 * brand + 0.08 * Math.min(1, got / all)));
      map.set(id, { b: bb, strong });
    });
    TS.ocr = OCR; TS.words = IDX.words; TS.map = map; return map;
  }
  function rank(f, n) {
    const out = [];
    IDX.map.forEach(e => {
      let best = 0, src = "img"; e.img.forEach(g => { const v = sim(f, g); if (v > best) best = v; });
      /* بصمات الكاميرا تتشارك نفس الإضاءة والكاميرا مع اللقطة ← تُخصم لها نسبة ثابتة، وأكثر إذا كانت تشبه الخلفية (تعلّم ضعيف) */
      e.cam.forEach(g => { let v = sim(f, g) - 0.035; if (BGF) { const b = sim(g, BGF); if (b > 0.72) v -= (b - 0.72) * 0.9; } if (v > best) { best = v; src = "cam"; } });
      /* أمثلة سلبية («تراجع» سابق): هذا المنظر بالذات ليس هذا الصنف */
      const ng = e.p && NEG.size !== undefined ? negOf(e.p.id) : []; if (ng.length) { let m = 0; ng.forEach(g => { const v = sim(f, g); if (v > m) m = v; }); if (m > 0.8) best -= (m - 0.8) * 1.6; }
      /* «أولوية بدون باركود»: الصنف الذي له باركود لا يُخفى (كان يختفي تماماً) — يُؤخَّر قليلاً فقط */
      if (CFG.onlyNoBC && !noBC(e.p)) best -= 0.05;
      out.push({ p: e.p, v: best, src, learned: e.cam.length > 0 });
    });
    /* قراءة النص: كلمات اسم الصنف (وكلمات علبته المتعلَّمة) الموجودة على العلبة — صالحة ما دام المنظر نفسه */
    if (OCR.toks.length && Date.now() - OCR.at < 8000 && (!OCR.f || sim(f, OCR.f) > SAME)) {
      const byId = new Map(out.map(o => [o.p.id, o]));
      textScores().forEach((sc, id) => {
        let o = byId.get(id);
        if (!o) { const p = IDX.prod.get(id), e = IDX.map.get(id); if (!p) return; o = { p, v: 0.45, src: "txt", learned: !!(e && e.cam.length) }; out.push(o); byId.set(id, o); }
        o.v += sc.b; o.txt = 1; o.txtStrong = sc.strong;
      });
      /* النص مقروء وفيه أصناف مطابقة ← الشبه الضعيف بالصورة فقط (بلا أي كلمة من الاسم) يتأخر: كان يملأ القائمة بأصناف لا علاقة لها */
      if (out.some(o => o.txt)) out.forEach(o => { if (!o.txt && o.v < 0.66) o.v -= 0.12; });
    }
    out.sort((a, b) => b.v - a.v);
    return out.slice(0, n || 4);
  }

  /* =================================================================== النافذة */
  const IC = {
    cam: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8.5A2.5 2.5 0 0 1 6.5 6h1.7l1.2-1.8h5.2L15.8 6h1.7A2.5 2.5 0 0 1 20 8.5v8A2.5 2.5 0 0 1 17.5 19h-11A2.5 2.5 0 0 1 4 16.5z"/><circle cx="12" cy="12.5" r="3.6"/></svg>',
    spark: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5l1.9 5.6 5.6 1.9-5.6 1.9L12 17.5l-1.9-5.6L4.5 10l5.6-1.9z"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    bolt: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13 2L4 14h6l-1 8 9-12h-6z"/></svg>',
    learn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-5 9 5-9 5z"/><path d="M7 11.5v4.5c3 2 7 2 10 0v-4.5"/></svg>',
    img: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.8"/><path d="M5 18l5-5 3.5 3.5L16 14l3.5 4"/></svg>',
    txt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 6h14M12 6v13M8.5 19h7"/></svg>',
    undo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6L4 11l5 5"/><path d="M4 11h10a6 6 0 0 1 0 12h-2"/></svg>'
  };
  let UI = null;
  function open() {
    if (UI) return;
    if (typeof window.addProduct !== "function") { say("افتح شاشة المبيعات أولاً", "w"); return; }
    const ov = document.createElement("div"); ov.className = "vsr-ov";
    ov.innerHTML = `<div class="vsr-w" role="dialog" aria-modal="true" aria-label="التعرف على الصنف بالكاميرا">
      <div class="vsr-hd"><span class="lg">${IC.cam}<i>${IC.spark}</i></span><div class="tt"><b>التعرف على الصنف بالكاميرا</b><small data-k="idx">جارٍ تجهيز صور الأصناف…</small></div><span class="sp"></span>
        <label class="vsr-sw" title="الأصناف التي ليس لها باركود تُقدَّم في النتائج — الأصناف التي لها باركود تبقى ظاهرة"><input type="checkbox" data-c="onlyNoBC"><i></i>أولوية بدون باركود</label>
        <label class="vsr-sw ai" data-k="aiSw" hidden title="إذا لم يُعرف الصنف من صورته: يُقرأ الاسم المكتوب على العلبة بـ Gemini (يحتاج إنترنت) ثم يتعلّمه البرنامج فيتعرف عليه بعدها فوراً وبلا إنترنت"><input type="checkbox" data-c="ai"><i></i>قراءة ذكية ✨</label>
        <label class="vsr-sw" title="إضافة الصنف تلقائياً عند ثبات التعرف"><input type="checkbox" data-c="auto"><i></i>إضافة تلقائية</label>
        <select data-k="dev" title="الكاميرا"></select><button type="button" class="vsr-x" data-a="x" title="إغلاق (Esc)">${IC.x}</button></div>
      <div class="vsr-bd">
        <div class="vsr-cam"><video playsinline muted></video><div class="vsr-frame"><i></i><i></i><i></i><i></i><u></u></div><div class="vsr-flash"></div>
          <div class="vsr-st"><span class="dot"></span><b data-k="st">تشغيل الكاميرا…</b><span class="vsr-rd" data-k="rd" hidden></span><em data-k="ms"></em></div><div class="vsr-frz" hidden>⏸ متوقف — المسافة للمتابعة</div>
          <div class="vsr-err" hidden></div></div>
        <aside class="vsr-side"><div class="vsr-qw"><span class="qi">${IC.txt}</span><input class="vsr-q" data-k="q" placeholder="اكتب حرفين من الاسم… عربي أو لاتيني" autocomplete="off" spellcheck="false"><button type="button" data-a="qx" title="مسح" hidden>${IC.x}</button></div>
          <div class="vsr-sh"><b data-k="sh">الأصناف المطابقة</b><small data-k="shs">اضغط أو 1–4</small></div><div class="vsr-res"></div>
          <div class="vsr-added" hidden><small>أضيف للفاتورة</small><div data-k="added"></div></div></aside></div>
      <div class="vsr-ft"><button type="button" data-a="frz" class="g"><kbd>Space</kbd>تجميد</button><button type="button" data-a="learn" class="g">${IC.learn}<kbd>L</kbd>تعليم صنف</button><button type="button" data-a="file" class="g">${IC.img}صورة من الجهاز</button><button type="button" data-a="snap" class="g snap" title="صورة واحدة تُقرأ بالذكاء الاصطناعي (تحتاج إنترنت)">${IC.spark}<kbd>F2</kbd>لقطة ذكية</button>
        <span class="sp"></span><span class="vsr-tip">اكتب حرفين من الاسم واضغط Enter — الصنف الذي تختاره تحفظ الكاميرا شكله وتعرفه وحدها في المرة القادمة</span></div>
      <input type="file" accept="image/*" hidden data-k="file"></div>`;
    document.body.appendChild(ov);
    const Q = s => ov.querySelector(s), video = Q("video");
    UI = { ov, Q, video, stream: null, raf: 0, last: 0, frz: false, cur: [], streak: { id: null, n: 0 }, cool: 0, added: [], lastAddId: null, gone: 0, ocrBusy: false, lastF: null, armed: false, present: true, idle: false, pres: null };
    /* الصنف المضاف آخر مرة (حتى بعد إغلاق النافذة وإعادة فتحها) لا يُضاف تلقائياً مرة أخرى حتى يُبعَد عن الكاميرا */
    /* صورة «الخلفية الفارغة» (الطاولة/الكاونتر) — تُحدَّث وحدها عندما لا يظهر أي صنف */
    try { const b = lsGet("anouer.vis.bg", null); if (b) UI.bgF = unpack(b); } catch (e) { }
    try { const l = JSON.parse(sessionStorage.getItem("anouer.vis.last") || "null"); if (l && Date.now() - l.at < 10 * 60000) UI.lastAddId = l.id; } catch (e) { }
    ov.querySelectorAll("[data-c]").forEach(c => { c.checked = !!CFG[c.dataset.c]; c.onchange = () => { CFG[c.dataset.c] = c.checked; saveCfg(); paintIdx(); }; });
    ov.addEventListener("click", onClick);
    ov.addEventListener("mousedown", e => { if (e.target === ov) close(); });
    document.addEventListener("keydown", onKey, true);
    Q('[data-k="file"]').onchange = e => { const f = e.target.files && e.target.files[0]; if (f) fromFile(f); e.target.value = ""; };
    requestAnimationFrame(() => ov.classList.add("in"));
    OCR = NOOCR(); bgmLoad(); bgwLoad(); qInit();
    build((d, n) => { Q('[data-k="idx"]').textContent = "تجهيز صور الأصناف " + d + " / " + n; }).then(paintIdx);
    startCam();
  }
  function paintIdx() {
    if (!UI) return; let n = 0, c = 0; IDX.map.forEach(e => { n++; if (e.cam.length) c++; });
    const g = IDX.gen.size;
    const gen = g ? ` · <span class="w${IDX.groups.length ? " act" : ""}"${IDX.groups.length ? ' data-a="gen" role="button" tabindex="0"' : ""} title="نفس الصورة مستعملة لعدة أصناف (أو بطاقة ANOUER مؤقتة) — ليست صورة المنتج فلا تُقارَن.${IDX.groups.length ? " اضغط لعرضها ومسحها." : ""}">${g} بصورة عامة مُتجاهَلة${IDX.groups.length ? " ›" : ""}</span>` : "";
    UI.Q('[data-k="idx"]').innerHTML = (n ? `${n} صنف بالصور${c ? ` · <b>${c}</b> متعلَّم من الكاميرا` : ""}` : `<span class="w">لا توجد صور حقيقية للأصناف</span>`) + ` · يقرأ الاسم لكل الأصناف${CFG.onlyNoBC ? " · أولوية بدون باركود" : ""}` + gen;
    const sw = UI.Q('[data-k="aiSw"]'); if (sw) sw.hidden = !AI();
  }
  async function startCam() {
    const U = UI; if (!U) return;
    const err = m => { const e = U.Q(".vsr-err"); e.hidden = false; e.innerHTML = m; U.Q('[data-k="st"]').textContent = "الكاميرا غير متاحة"; };
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return err("الكاميرا غير متاحة في هذا الجهاز — استعمل «صورة من الجهاز».");
    try {
      if (U.stream) U.stream.getTracks().forEach(t => t.stop());
      const s = await navigator.mediaDevices.getUserMedia({ video: Object.assign({ width: { ideal: 1280 }, height: { ideal: 720 } }, CFG.dev ? { deviceId: { exact: CFG.dev } } : { facingMode: "environment" }), audio: false });
      if (UI !== U) { s.getTracks().forEach(t => t.stop()); return; }
      U.stream = s; U.video.srcObject = s; await U.video.play().catch(() => { });
      const devs = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === "videoinput"), sel = U.Q('[data-k="dev"]');
      const curId = (s.getVideoTracks()[0].getSettings() || {}).deviceId || "";
      sel.innerHTML = devs.map((d, i) => `<option value="${esc(d.deviceId)}"${d.deviceId === curId ? " selected" : ""}>${esc(d.label || "كاميرا " + (i + 1))}</option>`).join("");
      sel.hidden = devs.length < 2; sel.onchange = () => { CFG.dev = sel.value; saveCfg(); startCam(); };
      U.Q('[data-k="st"]').textContent = "ابحث…"; loop();
    } catch (e) { err("تعذّر تشغيل الكاميرا: " + esc(e.message || e.name || e) + "<br><small>تأكد من توصيل الكاميرا والسماح لـ ANOUER باستعمالها.</small>"); }
  }
  function cropRect(v) {   /* المربع الأوسط (نفس مربع التوجيه) */
    const w = v.videoWidth, h = v.videoHeight, s = Math.min(w, h) * 0.72;
    return { x: (w - s) / 2, y: (h - s) / 2, w: s, h: s };
  }
  function loop() {
    const U = UI; if (!U) return;
    U.raf = requestAnimationFrame(loop);
    const now = performance.now(); if (U.frz || now - U.last < 115 || !U.video.videoWidth) return; U.last = now;
    if (IDX.busy && !IDX.map.size) return;
    const t0 = performance.now(), f = describe(U.video, cropRect(U.video)); U.lastF = f;
    if (!U.sceneF || sim(f, U.sceneF) < SAME) { U.sceneF = f; U.sceneAt = now; U.sceneOcr = 0; U.aiAsked = false; }
    /* الحضور: هل هناك صنف معروض فعلاً أمام الكاميرا؟ (pres = null حتى يتكوّن نموذج الخلفية ≈12 ثانية في أول مرة) */
    if (now - (U.gAt || 0) > 220) { U.gAt = now; try { U.grid = gridOf(U.video); U.pres = presence(U.grid, U.video); } catch (e) { U.pres = null; } }
    const pres = U.pres, present = pres == null || pres >= PRES, idle = pres != null && pres < IDLE; U.present = present; U.idle = idle;
    if (U.grid && now - (U.bgmAt || 0) > (pres != null && !idle ? 4000 : 2000)) { U.bgmAt = now; bgmAdd(U.grid); }
    const fill = f[DLEN - 1], empty = fill < 0.05;   /* لا يوجد شيء داخل المربع */
    /* المشهد فارغ ← لا مطابقة ولا قراءة (نفحص فقط كل ثانية: بصمة متعلَّمة تطابق الخلفية = تعلّم خاطئ يُنظَّف) */
    if (idle) { if (now - (U.idleChk || 0) > 900) { U.idleChk = now; healIdle(rank(f, 2), f); } }
    const r = empty || idle ? [] : rank(f, 4), ms = performance.now() - t0; U.cur = U.qList || r; U.camCur = r; U.okMask = fill <= 0.95;
    /* مؤشر صغير: زمن اللقطة + «الحضور» (كم من المربع يغطيه الصنف) — يفيد في معرفة لماذا لم يُضف صنف */
    U.Q('[data-k="ms"]').innerHTML = `${IC.bolt}${ms.toFixed(0)} مم/ث` + (pres == null ? ` · <span title="البرنامج يتعرّف على المكان (أول مرة فقط)">◌</span>` : ` · <span title="الحضور: نسبة المربع التي يغطيها الصنف المعروض">◉ ${Math.round(pres * 100)}%</span>`);
    if (!U.qList) { paint(r); decide(r); }   /* أثناء الكتابة في خانة البحث: القائمة لنتائج الاسم ولا إضافة تلقائية */
    /* قراءة الاسم: فور ظهور شيء لم يُتعرَّف عليه بثقة (لا تُقرأ الخلفية الفارغة) — المحرّك السريع كل 0.45 ثانية */
    if (idle && CFG.ocr && OCRFAST && HOST() && !U.noOcr && !U.ocrBusy && now - (U.bgOcrAt || 0) > ((U.bgOcrN || 0) < 4 ? 2200 : 20000)) { U.bgOcrAt = now; U.bgOcrN = (U.bgOcrN || 0) + 1; ocr(true); }   /* كلمات الخلفية */
    if (CFG.ocr && HOST() && !U.noOcr && !U.ocrBusy && !empty && !idle && present && (!U.isBg || now - (U.ocrAt || 0) > 3000) && !(r[0] && isSure(r[0], r[1]) && r[0].txt) && (!r[0] || !isSure(r[0], r[1]) || ambiguous(r)) && now - (U.ocrAt || 0) > (OCRFAST ? 600 : 1400)) ocr();
    /* القراءة الذكية: العلبة ثابتة ~1 ثانية ولم تُعرف لا بالصورة ولا بقراءة Windows (خط مزخرف) ← سؤال واحد لـ Gemini لكل علبة */
    if (CFG.ai && !U.noAI && !U.aiBusy && !U.aiAsked && !U.hold && !empty && !U.isBg && present && !(r[0] && isSure(r[0], r[1])) && now - U.sceneAt > 550 && (U.noOcr || !CFG.ocr || !HOST() || U.sceneOcr >= 1) && now - (U.aiAt || 0) > 3500 && now > (U.aiPause || 0) && (U.aiN || 0) < 60 && AI()) { U.aiAsked = true; askAI(); }
    paintRead();
  }
  /* نسبة الثقة المعروضة: قوة التطابق + الفرق عن أقرب منافس */
  const pct = (r, i) => { const v = r[i].v, other = Math.max(0, ...r.filter((_, j) => j !== i).map(o => o.v)), m = v - other;
    return Math.max(0, Math.min(99, Math.round(100 * (0.6 * Math.max(0, Math.min(1, (v - 0.3) / 0.5)) + 0.4 * Math.max(0, Math.min(1, m / 0.15)))))); };
  /* أصناف متشابهة (نفس العلامة/العلبة): الثاني قريب ← نطلب فرقاً أكبر، إلا إذا أكّد نص العلبة الأول */
  const isSure = (top, sec) => { if (!top) return false; if (top.src === "txt" && !top.txtStrong) return false;   /* اسم فقط بكلمة شائعة ← يُعرض ولا يُعتمد وحده */
    const amb = sec && sec.v >= 0.62 ? 0.05 : 0, tx = top.txt && !(sec && sec.txt) ? 0.05 : 0, m = sec ? top.v - sec.v : 1;
    return (top.v >= 0.72 && m >= (top.src === "cam" ? 0.07 : 0.08) + amb - tx) || (top.v >= 0.62 && m >= 0.12 + amb - tx); };
  const ambiguous = r => !!(r[0] && r[1] && r[1].v >= 0.6 && r[0].v - r[1].v < 0.14);
  function paint(r) {
    const U = UI, el = U.Q(".vsr-res");
    if (!r.length) { U.Q(".vsr-cam").classList.remove("lock"); el.innerHTML = `<div class="vsr-none">${IDX.map.size ? "ضع الصنف داخل المربع…" : "لا توجد أصناف بالصور للمقارنة"}</div>`; U.Q('[data-k="st"]').textContent = U.aiBusy ? "✨ يقرأ الاسم المكتوب على العلبة…" : U.lastAddId != null && !U.idle ? "✓ مضاف — أبعد الصنف عن الكاميرا" : "ضع الصنف داخل المربع"; return; }
    const top = r[0], good = isSure(top, r[1]);
    U.Q(".vsr-cam").classList.toggle("lock", good); U.Q('[data-k="st"]').textContent = U.lastAddId === top.p.id ? "✓ «" + top.p.name + "» مضاف — أبعده عن الكاميرا ثم أعده لإضافة واحد آخر" : good ? "تم التعرف: " + top.p.name : U.aiBusy ? "✨ يقرأ الاسم المكتوب على العلبة…" : !U.present ? "قرّب الصنف من الكاميرا حتى يملأ المربع" : U.pres == null && top.src !== "img" && top.v >= 0.6 ? "اضغط الصنف للتأكيد — البرنامج يتعرّف على المكان (أول مرة ≈ 40 ثانية)" : (U.cand && U.cand.id === top.p.id && U.cand.n >= 3 ? "يتأكد من «" + top.p.name + "»…" : "ابحث…");
    el.innerHTML = r.map((o, i) => { const t = showT(o.p), c = pct(r, i);
      return `<button type="button" class="vsr-c${i === 0 && good ? " best" : ""}" data-i="${i}" style="--c:${c}%"><kbd>${i + 1}</kbd><span class="im">${t ? `<img src="${esc(t)}" alt="">` : IC.img}</span><span class="tx"><b>${esc(o.p.name)}</b><small>${esc(fmt(o.p.price))} دج${o.txt ? ` · <i class="ot">${IC.txt}${o.src === "txt" ? "من الاسم" : "نص العلبة"}</i>` : ""}${o.learned ? ` · <i class="oc">متعلَّم</i><i class="of" data-forget="${i}" title="انسَ ما تعلّمه البرنامج من الكاميرا لهذا الصنف (إذا تعلّم صوراً خاطئة)">انسَ ✕</i>` : ""}</small><i class="bar"><u></u></i></span><em>${c}%</em></button>`; }).join("");
  }
  /* الإضافة التلقائية: نفس الصنف 3 مرات متتالية بثقة عالية وفرق واضح عن الثاني */
  function decide(r) {
    const U = UI, top = r[0], sec = r[1], f = U.lastF, now = Date.now();
    /* الخلفية: لا شيء معروف لمدة 1.5 ثانية ← هذه هي الخلفية الحالية */
    const isBg = !!(U.bgF && f && sim(f, U.bgF) > 0.88) && !(top && top.txt); BGF = U.bgF || null; U.isBg = isBg;   /* منظر فيه اسم صنف مقروء ليس خلفية */
    /* بعد كل إضافة: لا إضافة تلقائية لصنف آخر حتى يُبعَد الصنف (فراغ/خلفية) — هذا ما كان يضيف صنفاً خاطئاً أثناء سحب اليد */
    const clear = !top || isBg || !f || f[DLEN - 1] < 0.05 || U.idle;
    if (U.hold) { if (clear) { if (++U.clearN >= 2) { U.hold = false; U.clearN = 0; } } else U.clearN = 0; }
    if ((!top || top.v < 0.6 || isBg) && !(top && top.txt)) { if (!U.quiet) U.quiet = now; else if (now - U.quiet > (OCRFAST ? 1500 : 4500) && !U.ocrBusy && !U.aiBusy && (U.pres == null || U.idle) && f && f[DLEN - 1] >= 0.05) { U.bgF = f; U.quiet = now; if (now - (U.bgSaved || 0) > 15000) { U.bgSaved = now; lsSet("anouer.vis.bg", pack(f)); } } } else U.quiet = 0;
    if (isBg) { U.streak = { id: null, n: 0 }; if (U.lastAddId != null && ++U.gone > 3) U.lastAddId = null; U.armed = true; return; }
    /* آخر صنف أضيف (حتى بعد إعادة فتح النافذة) لا يُضاف تلقائياً مرة ثانية حتى يُبعَد عن الكاميرا ثم يُقدَّم من جديد */
    if (!top) { U.streak = { id: null, n: 0 }; if (U.lastAddId != null && ++U.gone > 3) U.lastAddId = null; return; }
    /* صورة البطاقة فقط ← نطلب فرقاً أكبر؛ بصمة متعلَّمة من الكاميرا ← أسرع */
    /* تأكيد زمني للأصناف المتشابهة: نفس الصنف في المقدمة ~1.4 ثانية متواصلة بقوة عالية وفرق ثابت ← مؤكَّد (الأخطاء العابرة لا تثبت) */
    const mg = sec ? top.v - sec.v : 1, steady = top.v >= 0.74 && mg >= 0.045;
    U.cand = steady && U.cand && U.cand.id === top.p.id ? { id: top.p.id, n: U.cand.n + 1 } : steady ? { id: top.p.id, n: 1 } : null;
    const sure = isSure(top, sec) || !!(U.cand && U.cand.n >= 8);
    if (U.lastAddId != null) { if (top.p.id !== U.lastAddId || top.v < 0.6) { U.gone++; if (U.gone > 4) U.lastAddId = null; } else U.gone = 0; }
    if (!sure) { U.streak = { id: null, n: 0 }; return; }
    U.streak = U.streak.id === top.p.id ? { id: top.p.id, n: U.streak.n + 1 } : { id: top.p.id, n: 1 };
    /* إذا لم تُرصد الخلفية: صنف مختلف ثابت وواثق لمدة ~1 ثانية يعيد التفعيل */
    if (U.hold && U.streak.n >= 6 && top.p.id !== U.lastAddId && top.v >= 0.74) U.hold = false;
    /* ثقة عالية جداً أو الاسم مقروء ومطابق ← لقطتان تكفيان (≈ ربع ثانية) ؛ غير ذلك 3 */
    const need = (top.v >= 0.8 && mg >= 0.14) || (top.txt && top.txtStrong && mg >= 0.1) ? 2 : 3;
    /* لا إضافة تلقائية بدون صنف معروض فعلاً أمام الكاميرا */
    if (CFG.auto && U.present && (U.pres != null || (top.src === "img") || (top.txt && top.txtStrong && OCR.ai.length)) && !U.hold && (U.okMask || top.txt) && U.streak.n >= need && U.lastAddId !== top.p.id && Date.now() > U.cool) add(top.p, true, top);
  }
  /* المشهد فارغ ومع ذلك بصمة متعلَّمة من الكاميرا تطابقه بثقة ← كانت صورة الخلفية (تعلّم خاطئ) ← تُحذف */
  function healIdle(r, f) {
    const U = UI, top = r[0]; if (!U || !top || top.src !== "cam" || !isSure(top, r[1])) { if (U) U.badN = 0; return; }
    U.badN = U.badId === top.p.id ? (U.badN || 0) + 1 : 1; U.badId = top.p.id; if (U.badN < 3) return;
    const e = IDX.map.get(top.p.id); U.badN = 0; if (!e) return;
    const n0 = e.cam.length; e.cam = e.cam.filter(g => sim(g, f) <= 0.8); if (e.cam.length === n0) return;
    try { if (PR() && PR().put) PR().put("vis.v." + top.p.id, e.cam.map(pack)); } catch (x) { }
    say("نُظّفت بصمة خاطئة لـ «" + top.p.name + "» (كانت صورة الخلفية لا الصنف)", "i"); paintIdx();
  }
  /* كلمات العلبة الحالية (للحفظ مع الصنف المضاف) */
  function sceneWords(p) {
    const U = UI; if (!U || !OCR.toks.length || Date.now() - OCR.at > 8000 || (OCR.f && U.lastF && sim(U.lastF, OCR.f) <= SAME)) return [];
    const nm = IDX.words.get(p.id) || [];
    return OCR.toks.filter(t => t.length >= 4 && nm.indexOf(t) < 0).slice(0, 14);
  }
  function add(p, auto, top) {
    const U = UI; if (!U) return;
    try { window.addProduct(p.id); } catch (e) { say("تعذّرت الإضافة: " + (e.message || e), "e"); return; }
    /* الإضافة التلقائية لا تتعلّم فوراً (كانت ترسّخ الخطأ): تُعتمد بعد 20 ثانية إن لم تُصحَّح — الإضافة اليدوية تتعلّم فوراً وتنظف الأصناف الأخرى */
    const shown = U.pres == null ? !auto : U.pres >= PRES;   /* صنف معروض فعلاً (الإضافة اليدوية قبل تكوّن نموذج الخلفية = تأكيد من المستخدم) */
    const lf = U.lastF, okF = lf && shown && !(U.bgF && sim(lf, U.bgF) > 0.85);   /* لا نتعلّم صورة الخلفية */
    /* الاسم مقروء ومطابق (أو اختيار يدوي) ← يتعلّم فوراً شكل العلبة وكلماتها: المرة القادمة تُعرف بلا انتظار */
    const now1 = okF && (!auto || !!(top && top.txt && top.txtStrong));
    let learned = false, al = [];
    if (now1) { learned = learn(p, lf); purge(lf, p.id);
      al = sceneWords(p); if (al.length) { const cur = IDX.alias.get(p.id) || []; al = al.filter(t => cur.indexOf(t) < 0); if (al.length) { IDX.alias.set(p.id, al.concat(cur).slice(0, 20)); aliasSave(); al.forEach(x => IDX.df.set(x, (IDX.df.get(x) || 0) + 1)); TS.ocr = null; } } }
    U.undo = { p, f: lf, learned, auto: !!auto, at: Date.now(), al };
    if (okF && auto && !now1) { const me = U.undo; setTimeout(() => { if (!me.undone) me.learned = learn(p, lf); }, 20000); }
    U.lastAddId = p.id; U.gone = 0; U.cool = Date.now() + 1200; U.streak = { id: null, n: 0 }; U.hold = true; U.clearN = 0;
    try { sessionStorage.setItem("anouer.vis.last", JSON.stringify({ id: p.id, at: Date.now() })); } catch (e) { }
    snd("ok");
    const fl = U.Q(".vsr-flash"); fl.classList.remove("on"); void fl.offsetWidth; fl.classList.add("on");
    const ex = U.added.find(x => x.p.id === p.id); if (ex) ex.n++; else U.added.unshift({ p, n: 1 });
    const a = U.Q(".vsr-added"); a.hidden = false;
    paintAdded();
    say((auto ? "⚡ " : "") + "أضيف: " + p.name, "s");
  }
  function paintAdded() {
    const U = UI; if (!U) return; const a = U.Q(".vsr-added"); a.hidden = !U.added.length;
    U.Q('[data-k="added"]').innerHTML = U.added.slice(0, 6).map(x => `<span><b>${x.n}×</b>${esc(x.p.name)}</span>`).join("") +
      (U.undo ? `<button type="button" class="vsr-undo" data-a="undo" title="حذف آخر صنف من الفاتورة وتعليم البرنامج أنه خطأ (Z)">${IC.undo}<span>تراجع: ليس «${esc(U.undo.p.name)}»</span><kbd>Z</kbd></button>` +
        (U.undo.auto ? `<small class="vsr-fix">غلط؟ اضغط الصنف الصحيح في القائمة (1–4) ← يُستبدل ويتعلّم البرنامج</small>` : "") : "");
  }
  /* «انسَ»: حذف كل بصمات الكاميرا لصنف (تعلّم خاطئ) — صورة البطاقة تبقى */
  function forget(p) {
    const e = IDX.map.get(p.id); if (!e || !e.cam.length) return;
    const n = e.cam.length; e.cam = []; try { if (PR() && PR().put) PR().put("vis.v." + p.id, []); } catch (x) { }
    snd("del"); say("نسي البرنامج " + n + " صورة متعلَّمة لـ «" + p.name + "» — اعرض الصنف الصحيح واضغطه ليتعلّمه من جديد", "i"); paintIdx();
  }
  /* اختيار يدوي: إذا أضيف صنف تلقائياً قبل لحظات واخترت صنفاً آخر ← تصحيح: يُستبدل الخاطئ بالصحيح ويتعلّم البرنامج الاثنين */
  function pick(p) {
    const U = UI; if (!U) return; const x = U.undo;
    if (x && x.auto && x.p.id !== p.id) {
      undoLast(true);
      if (x.f) { learn(p, x.f); purge(x.f, p.id); }   /* نفس اللقطة التي أخطأ فيها = صورة الصنف الصحيح */
      add(p, false); say("✔ تصحيح: «" + x.p.name + "» ← «" + p.name + "» — تعلّم البرنامج الفرق", "s"); return;
    }
    add(p, false);
  }
  /* تراجع عن آخر إضافة: يُنقص من الفاتورة + يتعلّم من الخطأ */
  function undoLast(quiet) {
    const U = UI; if (!U || !U.undo) return; const x = U.undo; U.undo = null; x.undone = true;
    try { const k = rows.map((r, i) => [r, i]).reverse().find(([r]) => r.pid == x.p.id && !r.ret); if (k) { const [r, i] = k; if ((+r.qty || 0) > 1) { r.qty = +r.qty - 1; renderRows(); } else delRow(i); } } catch (e) { }
    unlearn(x.p, x.f);
    if (x.al && x.al.length) { const cur = (IDX.alias.get(x.p.id) || []).filter(t => x.al.indexOf(t) < 0); if (cur.length) IDX.alias.set(x.p.id, cur); else IDX.alias.delete(x.p.id); aliasSave(); TS.ocr = null; }
    const ad = U.added.find(a => a.p.id === x.p.id); if (ad) { ad.n--; if (ad.n <= 0) U.added = U.added.filter(a => a !== ad); }
    U.lastAddId = null; U.hold = true; U.clearN = 0; U.streak = { id: null, n: 0 }; U.cool = Date.now() + 1500;
    try { sessionStorage.removeItem("anouer.vis.last"); } catch (e) { }
    paintAdded(); if (quiet) return; snd("del"); say("↶ حُذف «" + x.p.name + "» — اختر الصنف الصحيح من القائمة (1–4) ليتعلّمه", "i");
  }
  /* منطقة القراءة: أوسع من مربع المطابقة (اسم العلبة قد يخرج عن المربع) لكن ليست كل الصورة (رفوف الخلفية فيها أسماء أخرى) */
  function readRect(v) { const W = v.videoWidth, H = v.videoHeight, h = H * 0.86, w = Math.min(W, h * 1.15); return { x: (W - w) / 2, y: (H - h) / 2, w, h }; }
  let FASTBAD = 0;
  let OCRFAST = true;   /* fm.vis.ocr: محرّك دائم (≈0.1–0.3 ث للقراءة ، لاتيني + عربي) — إن لم يكن في هذا الإصدار نرجع لـ fm.scan.ocr (≈2 ث) */
  async function ocr(bg) {
    const U = UI; if (!U || U.ocrBusy || !U.video.videoWidth) return;
    U.ocrBusy = true; U.ocrAt = performance.now(); const f0 = U.lastF;
    try {
      const r = readRect(U.video), c = document.createElement("canvas"), k = Math.min(1, 1100 / r.w); c.width = Math.round(r.w * k); c.height = Math.round(r.h * k);
      c.getContext("2d").drawImage(U.video, r.x, r.y, r.w, r.h, 0, 0, c.width, c.height);
      /* قراءة من اثنتين بصورة أبيض/أسود عالية التباين: الخطوط الملوّنة على خلفية ملوّنة تُقرأ أحسن (جُرّب: «كويكلي» لم تُقرأ إلا هكذا) */
      U.ocrN = (U.ocrN || 0) + 1;
      /* قراءة من ثلاث مكبَّرة على وسط العلبة (اسم العلامة الكبير المزخرف يُقرأ أحسن مكبَّراً) */
      if (OCRFAST && U.ocrN % 3 === 0) { const zw = r.w * 0.7, zh = r.h * 0.6; c.width = 1100; c.height = Math.round(1100 * zh / zw); c.getContext("2d").drawImage(U.video, r.x + (r.w - zw) / 2, r.y + (r.h - zh) / 2, zw, zh, 0, 0, c.width, c.height); }
      if (OCRFAST && U.ocrN % 2 === 0) { try { hiContrast(c); } catch (e) { } }
      let res = null;
      if (OCRFAST) {
        try { res = await Anouer.call("fm.vis.ocr", { data: c.toDataURL("image/jpeg", 0.88), lang: "fr/en,ar" }); if (res && res.error) { res = null; throw new Error("ocr"); } FASTBAD = 0; }
        catch (e) { if (/Unknown action|غير معروف|not supported|unknown/i.test(String(e && e.message || e)) || ++FASTBAD >= 2) OCRFAST = false; }   /* إصدار قديم أو المحرّك لا يشتغل ← الطريقة القديمة */
      }
      if (!OCRFAST) {
        res = await Anouer.call("fm.scan.ocr", { data: c.toDataURL("image/png"), lang: CFG.ocrLang || "fr" }).catch(() => null);
        if (res && res.error && Array.isArray(res.langs) && res.langs.length && !CFG.ocrTried) { CFG.ocrTried = 1; CFG.ocrLang = res.langs.find(l => /^(fr|en)/i.test(l)) || res.langs[0]; saveCfg(); }
      }
      const toks = []; ((res && res.lines) || []).forEach(l => splitToks(l.t).forEach(t => { if (toks.indexOf(t) < 0) toks.push(t); }));
      if (bg) { if (res && !res.error && UI === U && U.idle) bgwAdd(toks); return; }   /* المشهد فارغ: هذه كلمات الرفوف */
      addToks(toks, f0, false); if (UI === U && res && !res.error) U.sceneOcr = (U.sceneOcr || 0) + 1;
      /* لا محرّك قراءة في هذا الجهاز (أو فشل 3 مرات) ← نتوقف عن المحاولة في هذه الجلسة بدل تشغيله كل لحظة */
      if (UI === U) { U.ocrBad = res && !res.error ? 0 : (U.ocrBad || 0) + 1; if (U.ocrBad >= 3 || (res && Array.isArray(res.used) && !res.used.length)) U.noOcr = true; U.ocrMs = Math.round(performance.now() - U.ocrAt); U.last = 0; }
    } catch (e) { } finally { if (UI === U) { U.ocrBusy = false; U.ocrAt = performance.now(); } }
  }
  /* أبيض/أسود: القناة الأعلى تبايناً + عتبة Otsu */
  function hiContrast(c) {
    const x = c.getContext("2d"), im = x.getImageData(0, 0, c.width, c.height), d = im.data, n = d.length / 4;
    const s = [0, 0, 0], q = [0, 0, 0]; for (let i = 0; i < d.length; i += 16) for (let k = 0; k < 3; k++) { const v = d[i + k]; s[k] += v; q[k] += v * v; }
    const m = n / 4, va = [0, 1, 2].map(k => q[k] / m - (s[k] / m) * (s[k] / m)), ch = va.indexOf(Math.max.apply(null, va));
    const h = new Uint32Array(256); for (let i = ch; i < d.length; i += 4) h[d[i]]++;
    let sum = 0; for (let i = 0; i < 256; i++) sum += i * h[i];
    let sb = 0, wb = 0, best = 0, thr = 127; for (let t = 0; t < 256; t++) { wb += h[t]; if (!wb) continue; const wf = n - wb; if (!wf) break; sb += t * h[t]; const mb = sb / wb, mf = (sum - sb) / wf, bt = wb * wf * (mb - mf) * (mb - mf); if (bt > best) { best = bt; thr = t; } }
    for (let i = 0; i < d.length; i += 4) { const v = d[i + ch] > thr ? 255 : 0; d[i] = d[i + 1] = d[i + 2] = v; }
    x.putImageData(im, 0, 0);
  }
  /* ---------------------------------------------------------------- القراءة الذكية (Gemini — المفتاح المحفوظ في «استوديو صورة الصنف») */
  const AI = () => { try { const a = window.ANOUER_PSTUDIO && ANOUER_PSTUDIO.ai; return a && a.has() && navigator.onLine !== false ? a : null; } catch (e) { return null; } };
  const AIP = `You are reading ONE retail product package held in front of a shop camera in Algeria. Ignore shelves and other products in the background.
Return ONE JSON object only, no prose:
{"front":true only if ONE package is held close to the camera and fills at least about a quarter of the picture - false if you only see shelves, people or far-away products,"brand":"the product / brand name printed largest on the pack, exactly as printed in Latin letters, or ''","brand_ar":"the same name as printed in Arabic script, or ''","words":["up to 8 other distinctive words printed on the pack (variant, flavor, maker) in Latin or Arabic - no weights, no generic words"],"pieces":number of pieces printed on the pack (e.g. '96 pieces') or 0}
Read only what is really printed, even in decorative or handwritten fonts. If no single package is held in front return {"front":false,"brand":"","brand_ar":"","words":[],"pieces":0}. Never read text from the shelves behind.`;
  /* النماذج الأسرع أولاً (flash-lite ثم flash) */
  const fastModels = l => { const ver = n => { const m = /gemini-(\d+(?:\.\d+)?)/.exec(n); return m ? +m[1] : 0; };
    const rk = n => (/lite/.test(n) ? 2000 : 1000) + ver(n) * 10 - (/preview|exp/.test(n) ? 5 : 0) - (/latest/.test(n) ? 2 : 0);
    return l.filter(n => /^gemini-.*flash/.test(n) && !/image|tts|audio|live|embedding|robotics|computer|native|aqa|exp-\d{4}/i.test(n)).sort((a, b) => rk(b) - rk(a)).slice(0, 2); };
  async function askAI() {
    const U = UI, ai = AI(); if (!U || !ai || U.aiBusy || !U.video.videoWidth) return;
    U.aiBusy = true; U.aiAt = performance.now(); U.aiN = (U.aiN || 0) + 1; const f0 = U.lastF, t0 = performance.now();
    try {
      const r = readRect(U.video), c = document.createElement("canvas"), k = Math.min(1, 768 / r.w); c.width = Math.round(r.w * k); c.height = Math.round(r.h * k);
      c.getContext("2d").drawImage(U.video, r.x, r.y, r.w, r.h, 0, 0, c.width, c.height);
      const res = await ai.json(AIP, [c.toDataURL("image/jpeg", 0.82)], { max: 400, models: fastModels });
      if (UI !== U) return;
      const v = (res && res.v) || {}, toks = [];
      if (v.front !== false) [v.brand, v.brand_ar].concat(Array.isArray(v.words) ? v.words : []).forEach(s => splitToks(s).forEach(t => { if (toks.indexOf(t) < 0) toks.push(t); }));
      addToks(toks, f0, true); U.aiBad = 0; U.aiMs = Math.round(performance.now() - t0); U.last = 0;
    } catch (e) {
      const m = String(e && e.message || e); U.aiErr = m; U.aiBad = (U.aiBad || 0) + 1;
      if (/429|حد الاستعمال/.test(m)) U.aiPause = performance.now() + 60000;   /* حد الدقيقة في المفتاح المجاني ← استراحة دقيقة */
      if (U.aiBad >= 3 || /no-key|غير صحيح|403/.test(m)) U.noAI = true;
    } finally { if (UI === U) U.aiBusy = false; }
  }
  /* «قرأ: …» — الكلمات المقروءة من العلبة (التي تطابق أسماء الأصناف أولاً) */
  function paintRead() {
    const U = UI; if (!U) return; const el = U.Q('[data-k="rd"]'); if (!el) return;
    const ok = OCR.toks.length && Date.now() - OCR.at < 8000 && (!OCR.f || !U.lastF || sim(U.lastF, OCR.f) > SAME);
    if (!ok) { if (!el.hidden) el.hidden = true; return; }
    const known = OCR.toks.filter(t => IDX.df.has(t)), rest = OCR.toks.filter(t => !IDX.df.has(t) && t.length >= 4);
    const html = (OCR.ai.length ? "✨ قرأ: " : "قرأ: ") + known.slice(0, 4).map(t => "<b>" + esc(t) + "</b>").concat(rest.slice(0, Math.max(0, 4 - known.length)).map(esc)).join(" · ");
    if (el.__h !== html) { el.__h = html; el.innerHTML = html; } el.hidden = false;
  }
  async function fromFile(f) {
    const U = UI; if (!U) return;
    const url = URL.createObjectURL(f), im = await loadImg(url); URL.revokeObjectURL(url);
    if (!im) { say("تعذّر فتح الصورة", "e"); return; }
    U.frz = true; U.Q(".vsr-frz").hidden = false;
    const s = Math.min(im.naturalWidth, im.naturalHeight), f2 = describe(im, { x: (im.naturalWidth - s) / 2, y: (im.naturalHeight - s) / 2, w: s, h: s });
    U.lastF = f2; OCR = NOOCR(); U.present = true; U.idle = false; const r = rank(f2, 4); U.cur = r; paint(r);
  }
  /* تعليم صنف: اختيار الصنف الظاهر أمام الكاميرا وحفظ بصمته (وصورته إن لم تكن له صورة) */
  function learnPick() {
    const U = UI; if (!U || !U.lastF) { say("وجّه الكاميرا نحو الصنف أولاً", "w"); return; }
    const f = U.lastF; U.frz = true; U.Q(".vsr-frz").hidden = false;
    const snap = document.createElement("canvas"); try { const r = cropRect(U.video), s = 240; snap.width = snap.height = s; snap.getContext("2d").drawImage(U.video, r.x, r.y, r.w, r.h, 0, 0, s, s); } catch (e) { }
    const box = document.createElement("div"); box.className = "vsr-lp";
    box.innerHTML = `<div class="in"><b>${IC.learn} تعليم صنف — ما هو هذا الصنف؟</b><input placeholder="اكتب اسم الصنف أو الكود…" autocomplete="off"><div class="ls"></div>
      <label class="vsr-sw sm"><input type="checkbox" checked data-k="asimg"><i></i>استعمل الصورة كصورة للصنف إن لم تكن له صورة حقيقية</label><button type="button" class="cn">إلغاء</button></div>`;
    U.ov.querySelector(".vsr-w").appendChild(box);
    const inp = box.querySelector("input"), ls = box.querySelector(".ls");
    const list = () => { const q = norm(inp.value); const L = PRODS().filter(p => p && p.active !== false && (!q || norm(p.name + " " + (p.code || "")).includes(q))).slice(0, 40);
      ls.innerHTML = L.map(p => `<button type="button" data-id="${esc(p.id)}"><span class="im">${showT(p) ? `<img src="${esc(showT(p))}">` : IC.img}</span><b>${esc(p.name)}</b><small>${esc(p.code || "")}</small></button>`).join("") || '<div class="vsr-none">لا نتائج</div>'; };
    inp.oninput = list; list(); setTimeout(() => inp.focus(), 30);
    const done = () => { box.remove(); U.frz = false; U.Q(".vsr-frz").hidden = true; };
    box.querySelector(".cn").onclick = done;
    inp.onkeydown = e => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); done(); } else if (e.key === "Enter") { const b = ls.querySelector("[data-id]"); if (b) b.click(); } };
    ls.onclick = e => { const b = e.target.closest("[data-id]"); if (!b) return; const p = PRODS().find(x => String(x.id) === b.dataset.id); if (!p) return;
      learn(p, f); const pg = purge(f, p.id); if (pg) say("نُظّفت " + pg + " بصمة خاطئة من أصناف أخرى", "i");
      if (box.querySelector('[data-k="asimg"]').checked && !showT(p) && window.__pimgPut && snap.width) { try { window.__pimgPut(p.id, snap.toDataURL("image/jpeg", 0.86)); } catch (x) { } }
      snd("save"); say("تعلّم البرنامج «" + p.name + "» ✓", "s"); done(); paintIdx(); };
  }
  /* «صور عامة»: نفس الصورة عند عدة أصناف — عرضها ومسحها (المصغّرة + الدقة العالية). الصنف نفسه لا يتغيّر. */
  async function wipeGroup(g, onProg) {
    const P0 = PR(), vals = {}, memo = {}; let n = 0, bad = 0, err = "";
    g.ps.forEach(p => { vals["pimg." + p.id] = ""; vals["pimg.hd." + p.id] = 0; vals["pimg.ph." + p.id] = 0; memo[p.id] = "";
      try { if (p.code && P0 && P0.get("pimg.c." + p.code, "") === g.t) vals["pimg.c." + p.code] = ""; } catch (e) { } });
    if (P0 && P0.putMany) await P0.putMany(vals); else if (P0) for (const k of Object.keys(vals)) await P0.put(k, vals[k]);
    try { if (window.__pimgSetMany) window.__pimgSetMany(memo); } catch (e) { }
    for (const p of g.ps) {
      if (HOST()) { try { await Anouer.call("fm.pimg.put", { id: +p.id || p.id, data: "", w: 0, h: 0 }); } catch (e) { bad++; err = String(e && e.message || e); } }
      n++; if (onProg) onProg(n, g.ps.length);
    }
    return { n: g.ps.length, bad, err };
  }
  function genPanel() {
    const U = UI; if (!U || !IDX.groups.length || U.ov.querySelector(".vsr-gp")) return;
    const wasFrz = U.frz; U.frz = true; U.Q(".vsr-frz").hidden = false;
    const box = document.createElement("div"); box.className = "vsr-lp vsr-gp"; U.ov.querySelector(".vsr-w").appendChild(box);
    let arm = -1, busy = false;
    const draw = () => {
      const tot = IDX.groups.reduce((a, g) => a + g.ps.length, 0);
      box.innerHTML = `<div class="in"><b>${IC.img} صور عامة مكرّرة <em>${tot} صنف</em></b>
        <p class="nt">هذه الصورة مستعملة لعدة أصناف في نفس الوقت — ليست صورة المنتج ، فلا يُتعرَّف بها على شيء وتتشابه بها بلاطات اللمس. امسحها ثم ضع لكل صنف صورته من «استوديو صورة الصنف» أو «تعليم صنف».</p>
        <div class="gl">${IDX.groups.length ? IDX.groups.map((g, i) => `<div class="g1"><span class="im"><img src="${esc(g.t)}" alt=""></span><div class="tx"><strong>${g.ps.length} صنف بنفس الصورة</strong><small>${esc(g.ps.slice(0, 6).map(p => p.name).join(" ، "))}${g.ps.length > 6 ? " … +" + (g.ps.length - 6) : ""}</small></div>
          <button type="button" class="del${arm === i ? " arm" : ""}" data-g="${i}">${arm === i ? "تأكيد — مسح نهائي من " + g.ps.length + " صنف" : "مسح الصورة"}</button></div>`).join("") : '<div class="vsr-none">✓ لا توجد صور مكرّرة</div>'}</div>
        <small class="wr">⚠ المسح نهائي (الصورة المصغّرة + الدقة العالية). الأصناف وأسعارها وأرصدتها وباركودها لا تتغيّر.</small><button type="button" class="cn">إغلاق</button></div>`;
    };
    const done = () => { box.remove(); if (UI === U) { U.frz = wasFrz; U.Q(".vsr-frz").hidden = !wasFrz; U.last = 0; } };
    box.onclick = async e => {
      if (busy) return;
      if (e.target.closest(".cn") || e.target === box) { done(); return; }
      const b = e.target.closest("[data-g]"); if (!b) { if (arm >= 0) { arm = -1; draw(); } return; }
      const i = +b.dataset.g, g = IDX.groups[i]; if (!g) return;
      if (arm !== i) { arm = i; draw(); return; }   /* الضغطة الأولى تسأل ، الثانية تمسح */
      busy = true; b.disabled = true;
      try {
        const r = await wipeGroup(g, (n, t) => { b.textContent = "يمسح… " + n + " / " + t; });
        snd("del"); say(r.bad ? "مُسحت الصورة من " + r.n + " صنف — تعذّر مسح الدقة العالية لـ " + r.bad + " (" + r.err.slice(0, 80) + ")" : "✓ مُسحت الصورة العامة من " + r.n + " صنف", r.bad ? "w" : "s");
      } catch (x) { say("تعذّر المسح: " + (x && x.message || x), "e"); }
      busy = false; arm = -1; IDX.busy = null; await build(); if (UI === U) paintIdx(); if (box.isConnected) draw();
    };
    draw();
  }
  /* =================================================================== ✦ (2026-11-25) الطريقة السهلة: اكتب حرفين ← اختر ← الكاميرا تتعلّم
     خانة بحث داخل نافذة الكاميرا: الاسم بالعربية أو اللاتينية (بداية أي كلمة ، أو نفس النطق بكتابة أخرى: «ستا» = «STA») أو الكود / الباركود.
     الصنف المختار يُضاف للفاتورة وتُحفظ بصمة ما أمام الكاميرا له ← في المرة القادمة تتعرف عليه الكاميرا وحدها بلا كتابة. */
  let QX = null;
  /* كتابة صوتية تقريبية مع حروف المد: «ستا» ← sta ، «بيبس» ← bibs ، PEPSI ← bibsi (أدق من هيكل السواكن للكلمات القصيرة) */
  const TRC = new Map();
  function trl(w) {
    let k = TRC.get(w); if (k !== undefined) return k;
    if (isAr(w)) { k = ""; for (const c of w) k += AR2L[c] || (c === "ا" ? "a" : c === "و" ? "u" : c === "ي" ? "i" : ""); }
    else k = w.replace(/sch|sh|ch/g, "s").replace(/ph/g, "f").replace(/dj/g, "j").replace(/qu|ck|kh|q/g, "k").replace(/gh/g, "g").replace(/th/g, "t").replace(/c(?=[eiy])/g, "s").replace(/g(?=[eiy])/g, "j").replace(/c/g, "k").replace(/x/g, "ks").replace(/v/g, "f").replace(/p/g, "b").replace(/ou|oo|o|w/g, "u").replace(/ee|e|y/g, "i").replace(/h/g, "").replace(/[0-9]/g, "");
    k = k.replace(/(.)\1+/g, "$1"); if (TRC.size > 60000) TRC.clear(); TRC.set(w, k); return k;
  }
  function qIndex() {
    const P = PRODS(); if (QX && QX.n === P.length && QX.p === P) return QX.l;
    const l = []; P.forEach(p => { if (!p || p.active === false || !p.name) return; const n = norm(p.name), w = n.split(" ").filter(Boolean);
      const codes = [p.code, p.barcode].concat((p._u || []).reduce((a, u) => a.concat([u && u.bc], (u && u.xb) || []), [])).filter(Boolean).map(x => String(x).toLowerCase().replace(/\s/g, ""));
      l.push({ p, n, w, k: w.map(x => x.length >= 3 ? phon(x) : ""), t: w.map(x => x.length >= 3 ? trl(x) : ""), codes }); });
    QX = { n: P.length, p: P, l }; return l;
  }
  function qFind(text, max) {
    const q = norm(text); if (!q) return [];
    const raw = String(text).trim().toLowerCase().replace(/\s/g, ""), T = q.split(" ").filter(Boolean), TK = T.map(t => t.length >= 2 && !/^\d+$/.test(t) ? phon(t) : ""), TT = T.map(t => t.length >= 2 && !/^\d+$/.test(t) ? trl(t) : ""), out = [];
    const L = qIndex();
    for (let i = 0; i < L.length; i++) {
      const e = L[i]; let sc = 0, ok = true;
      if (raw.length >= 3 && e.codes.some(c => c === raw)) sc = 100;
      else if (raw.length >= 4 && /^\d+$/.test(raw) && e.codes.some(c => c.indexOf(raw) >= 0)) sc = 20;
      else for (let j = 0; j < T.length && ok; j++) {
        const t = T[j], tk = TK[j]; let b = 0;
        for (let x = 0; x < e.w.length; x++) { const w = e.w[x]; let v = 0;
          if (w === t) v = 6; else if (w.indexOf(t) === 0) v = 5; else if (t.length >= 3 && w.indexOf(t) > 0) v = 2.5;
          else if (TT[j] && TT[j].length >= 2 && e.t[x] && isAr(w) !== isAr(t) && e.t[x].indexOf(TT[j]) === 0) v = e.t[x] === TT[j] ? 4.8 : 4.2;   /* نفس النطق بكتابة أخرى */
          else if (tk && tk.length >= 2 && e.k[x] && isAr(w) !== isAr(t) && e.k[x].indexOf(tk) === 0) v = e.k[x] === tk ? 3.6 : tk.length >= 3 ? 3 : 1.5;
          else if (tk && tk.length >= 4 && e.k[x] === tk) v = 3;
          if (v && x === 0) v += 1; if (v > b) b = v; }
        if (!b) ok = false; else sc += b;
      }
      if (ok && sc > 0) out.push({ p: e.p, v: sc, src: "q" });
    }
    out.sort((a, b) => b.v - a.v || String(a.p.name).length - String(b.p.name).length);
    return out.slice(0, max || 6);
  }
  function qCss() {
    if (G("vsrQCss")) return; const st = document.createElement("style"); st.id = "vsrQCss";
    st.textContent = `.vsr-qw{position:relative;display:flex;align-items:center;margin-bottom:10px}
.vsr-qw .qi{position:absolute;inset-inline-start:12px;width:18px;height:18px;color:#7dd3fc;pointer-events:none}.vsr-qw .qi svg{width:18px;height:18px}
.vsr-q{width:100%;height:46px;border-radius:14px;border:1.5px solid rgba(125,211,252,.35);background:rgba(15,23,42,.6);color:#f1f5f9;font:inherit;font-size:16px;font-weight:700;padding:0 40px;outline:0;transition:border-color .15s,box-shadow .15s}
.vsr-q::placeholder{color:#64748b;font-weight:500;font-size:13.5px}
.vsr-q:focus{border-color:#38bdf8;box-shadow:0 0 0 4px rgba(56,189,248,.18)}
.vsr-qw button{position:absolute;inset-inline-end:8px;width:30px;height:30px;border:0;border-radius:9px;background:rgba(148,163,184,.16);color:#cbd5e1;display:grid;place-items:center;cursor:pointer}.vsr-qw button svg{width:15px;height:15px}
.vsr-c.qs{outline:2px solid #38bdf8;outline-offset:-2px}.vsr-c .qst{margin-inline-start:auto;font:800 12px Arial,sans-serif;color:#86efac;white-space:nowrap}.vsr-c .qst.no{color:#fca5a5}
.vsr-ft .snap{border-color:rgba(250,204,21,.45)!important;color:#fde68a!important}.vsr-ft .snap svg{width:15px;height:15px;color:#facc15}`;
    document.head.appendChild(st);
  }
  function qInit() {
    const U = UI; qCss(); const inp = U.Q('[data-k="q"]'); if (!inp) return;
    inp.addEventListener("input", () => qRun());
    setTimeout(() => { try { inp.focus(); } catch (e) { } }, 120);
  }
  function qRun() {
    const U = UI; if (!U) return; const inp = U.Q('[data-k="q"]'), v = inp.value;
    U.Q('[data-a="qx"]').hidden = !v;
    if (!v.trim()) { U.qList = null; U.qSel = 0; U.Q('[data-k="sh"]').textContent = "الأصناف المطابقة"; U.Q('[data-k="shs"]').textContent = "اضغط أو 1–4"; U.cur = U.camCur || []; U.last = 0; paint(U.cur); return; }
    U.qList = qFind(v, 6); U.qSel = 0; U.cur = U.qList; qPaint();
  }
  function qPaint() {
    const U = UI, el = U.Q(".vsr-res"), L = U.qList || [];
    U.Q('[data-k="sh"]').textContent = "نتائج الاسم"; U.Q('[data-k="shs"]').textContent = L.length ? "Enter للأول · ↑↓" : "";
    U.Q(".vsr-cam").classList.remove("lock");
    el.innerHTML = L.map((o, i) => { const t = showT(o.p), s = +o.p.stock || 0;
      return `<button type="button" class="vsr-c${i === U.qSel ? " qs" : ""}" data-i="${i}" style="--c:0%"><kbd>${i === U.qSel ? "↵" : i + 1}</kbd><span class="im">${t ? `<img src="${esc(t)}" alt="">` : IC.img}</span><span class="tx"><b>${esc(o.p.name)}</b><small>${esc(fmt(o.p.price))} دج</small></span><i class="qst${s <= 0 ? " no" : ""}">${s <= 0 ? "نفد" : fmt(s)}</i></button>`; }).join("") || `<div class="vsr-none">لا يوجد صنف بهذا الاسم — جرّب حرفين آخرين</div>`;
  }
  function qClear(focus) { const U = UI; if (!U) return; const inp = U.Q('[data-k="q"]'); inp.value = ""; qRun(); if (focus) try { inp.focus(); } catch (e) { } }
  function qKey(e) {
    const U = UI, inp = e.target, L = U.qList;
    if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); if (inp.value) qClear(true); else close(); return; }
    if (!inp.value) {   /* الخانة فارغة ← اختصارات الكاميرا كما هي */
      if (/^[1-4]$/.test(e.key)) { e.preventDefault(); e.stopImmediatePropagation(); const o = (U.camCur || [])[+e.key - 1]; if (o) pick(o.p); return; }
      if (e.code === "Space") { e.preventDefault(); e.stopImmediatePropagation(); toggleFrz(); return; }
      if (e.key === "Enter") { e.preventDefault(); e.stopImmediatePropagation(); const o = (U.camCur || [])[0]; if (o) add(o.p, false); return; }
      e.stopPropagation(); return;
    }
    if (e.key === "Enter") { e.preventDefault(); e.stopImmediatePropagation(); const o = L && L[U.qSel || 0]; if (o) { pick(o.p); qClear(true); } return; }
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); e.stopImmediatePropagation(); if (L && L.length) { U.qSel = ((U.qSel || 0) + (e.key === "ArrowDown" ? 1 : -1) + L.length) % L.length; qPaint(); } return; }
    e.stopPropagation();
  }
  /* ✨ لقطة ذكية: صورة واحدة الآن تُقرأ بالذكاء الاصطناعي ← الأصناف المطابقة للاسم المقروء */
  async function snapAI() {
    const U = UI; if (!U) return;
    if (!AI()) { say("اللقطة الذكية تحتاج إنترنت ومفتاح Gemini (من «استوديو المنتج») — اكتب حرفين من الاسم في خانة البحث بدلها", "w"); return; }
    if (U.aiBusy) return;
    if (U.qList) qClear(false);
    U.noAI = false; U.aiErr = ""; const n0 = OCR.ai.length; say("✨ يقرأ الاسم المكتوب على العلبة…", "i");
    await askAI(); if (UI !== U) return;
    if (U.aiErr && OCR.ai.length === n0) { say("تعذّرت القراءة الذكية: " + U.aiErr.slice(0, 90), "e"); return; }
    const w = OCR.ai.slice(0, 5).join(" · "); U.last = 0;
    say(w ? "✨ قرأ: " + w : "✨ لم يجد اسماً مقروءاً — قرّب العلبة أو اكتب حرفين من الاسم", w ? "s" : "w");
  }
  function onClick(e) {
    const U = UI; if (!U) return;
    const fg = e.target.closest("[data-forget]"); if (fg) { e.stopPropagation(); const o = U.cur[+fg.dataset.forget]; if (o) forget(o.p); return; }
    const c = e.target.closest(".vsr-c"); if (c) { const o = U.cur[+c.dataset.i]; if (o) { const wasQ = !!U.qList; pick(o.p); if (wasQ) qClear(true); } return; }
    const b = e.target.closest("[data-a]"); if (!b) return;
    const a = b.dataset.a;
    if (a === "x") close();
    else if (a === "frz") toggleFrz();
    else if (a === "learn") learnPick();
    else if (a === "file") U.Q('[data-k="file"]').click();
    else if (a === "undo") undoLast();
    else if (a === "gen") genPanel();
    else if (a === "qx") qClear(true);
    else if (a === "snap") snapAI();
  }
  function toggleFrz() { const U = UI; U.frz = !U.frz; U.Q(".vsr-frz").hidden = !U.frz; if (!U.frz) U.last = 0; }
  function onKey(e) {
    const U = UI; if (!U) return;
    if (U.ov.querySelector(".vsr-gp")) { if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); const c = U.ov.querySelector(".vsr-gp .cn"); if (c) c.click(); } return; }
    if (U.ov.querySelector(".vsr-lp")) return;
    if (e.key === "F2") { e.preventDefault(); e.stopImmediatePropagation(); snapAI(); return; }
    if (e.target && e.target.classList && e.target.classList.contains("vsr-q")) { qKey(e); return; }
    if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); close(); return; }
    if (e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName) && e.target.type !== "checkbox") return;
    if (/^[1-4]$/.test(e.key)) { e.preventDefault(); e.stopImmediatePropagation(); const o = U.cur[+e.key - 1]; if (o) pick(o.p); }
    else if (e.code === "Space") { e.preventDefault(); e.stopImmediatePropagation(); toggleFrz(); }
    else if (e.key === "l" || e.key === "L") { e.preventDefault(); e.stopImmediatePropagation(); learnPick(); }
    else if ((e.key === "z" || e.key === "Z" || e.key === "Backspace") && U.undo) { e.preventDefault(); e.stopImmediatePropagation(); undoLast(); }
    else if (e.key === "Enter") { e.preventDefault(); e.stopImmediatePropagation(); const o = U.cur[0]; if (o) add(o.p, false); }
  }
  function close() {
    const U = UI; if (!U) return; UI = null;
    cancelAnimationFrame(U.raf); try { if (U.stream) U.stream.getTracks().forEach(t => t.stop()); } catch (e) { }
    document.removeEventListener("keydown", onKey, true);
    U.ov.classList.remove("in"); U.ov.classList.add("out"); setTimeout(() => U.ov.remove(), 220);
    if (U.added.length) say("أضيف " + U.added.reduce((a, x) => a + x.n, 0) + " صنف بالكاميرا", "s");
  }

  /* =================================================================== الأيقونة في رأس المبيعات */
  function addBtn() {
    const head = document.querySelector(".ihead"); if (!head) return false;
    if (G("visBtn")) return true;
    const b = document.createElement("span"); b.id = "visBtn"; b.className = "vsr-btn"; b.setAttribute("role", "button"); b.tabIndex = 0;
    b.title = "التعرف على الصنف بالكاميرا — بالصورة أو بقراءة الاسم — Ctrl+Alt+K";
    b.innerHTML = `<span class="ic">${IC.cam}</span><i class="sp">${IC.spark}</i><span class="lb">كاميرا</span>`;
    b.onclick = open; b.onkeydown = e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } };
    head.appendChild(b);
    return true;
  }
  if (!addBtn()) { const t = setInterval(() => { if (addBtn()) clearInterval(t); }, 600); setTimeout(() => clearInterval(t), 20000); }
  document.addEventListener("keydown", e => { if (e.ctrlKey && e.altKey && (e.key === "k" || e.key === "K") && !UI) { const s = document.querySelector(".ihead"); if (s && s.offsetParent) { e.preventDefault(); open(); } } });
  window.ANOUER_VIS = { _t: { BGM, BGW, seed: () => { const U = UI; if (!U) return; const a = gridOf(U.video); BGM.S = []; for (let k = 0; k < 9; k++) BGM.S.push(a); BGM.med = a; BGM.n = 99; } }, open, close, build, describe, sim, rank, learn, unlearn, undo: () => undoLast(), add: (p, a) => add(p, a), pick: p => pick(p), idx: IDX, cfg: CFG };
})();
