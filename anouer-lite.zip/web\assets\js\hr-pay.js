/* ANOUER — «الموظفين و الرواتب» (الفهرس) — 2026
   ─ لكل موظف/عامل راتب شهري ← أجر يومي (مثال: 30000 ÷ 30 = 1000 دج في اليوم).
   ─ كل يوم عمل فعلي يدخل كمصروف «رواتب وأجور» في الأرباح والخسائر — يوم الغياب لا يُحسب.
   ─ الحضور: تلقائي (حاضر ما لم يُسجَّل غياب) · من سجل دخول المستخدم · يدوي — مع وقت الدخول/الخروج ونصف اليوم والإجازة المدفوعة.
   ─ «حسب ساعات العمل»: أجر اليوم = الأجر اليومي × (ساعات العمل ÷ ساعات الوردية).
   ─ شجرة الحسابات: استحقاق الشهر يُرحَّل آلياً قيداً واحداً يتحدّث (مدين 32131 أجور نقدية / دائن 2121 مرتبات مستحقة السداد)،
     وصرف الراتب/السلفة = قيد حقيقي (مدين 2121 / دائن الخزينة) يُنقص رصيد الخزينة ويظهر في حركتها.
   التخزين: الموظفين (hre) · الحضور يوماً بيوم (hra) · الصرف والسلف والمكافآت والخصومات (hrp) · الإعدادات (hr.cfg). */
(function () {
  "use strict";
  if (window.ANOUER_HR) return;
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const r2 = n => Math.round((+n || 0) * 100) / 100;
  const N = n => r2(n).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const N0 = n => Math.round(+n || 0).toLocaleString("en-US");
  const num = v => { const x = parseFloat(String(v == null ? "" : v).replace(/[,\s]/g, "")); return isFinite(x) ? x : 0; };
  const T = (m, k) => { try { toast(m, k || "i"); } catch (e) { console.log(m); } };
  const snd = k => { try { if (window.ANOUER_SOUND) ANOUER_SOUND(k); } catch (e) { } };
  const PR = () => window.ANOUER_PROPS, A = () => window.__AC, FH = () => window.__FH;
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const call = (a, p) => Anouer.call(a, p || {});
  const p2 = n => String(n).padStart(2, "0");
  const ymd = d => d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate());
  const today = () => ymd(new Date());
  const D0 = s => new Date(String(s).slice(0, 10) + "T12:00:00");
  const addDays = (s, n) => { const d = D0(s); d.setDate(d.getDate() + n); return ymd(d); };
  const dim = ym => new Date(+ym.slice(0, 4), +ym.slice(5, 7), 0).getDate();
  const ymOf = s => String(s).slice(0, 7);
  const addMonth = (ym, n) => { const d = new Date(+ym.slice(0, 4), +ym.slice(5, 7) - 1 + n, 1); return d.getFullYear() + "-" + p2(d.getMonth() + 1); };
  const monthEnd = ym => ym + "-" + p2(dim(ym));
  const minS = (a, b) => (a < b ? a : b), maxS = (a, b) => (a > b ? a : b);
  const MON = ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
  const DAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  const DAY1 = ["ح", "ن", "ث", "ر", "خ", "ج", "س"];
  const monthName = ym => MON[+ym.slice(5, 7) - 1] + " " + ym.slice(0, 4);
  const nice = s => { const d = D0(s); return DAYS[d.getDay()] + " " + d.getDate() + " " + MON[d.getMonth()] + " " + d.getFullYear(); };
  const dmy = s => { const p = String(s || "").slice(0, 10).split("-"); return p.length === 3 ? p[2] + "/" + p[1] + "/" + p[0] : String(s || ""); };
  const USER = () => window.__USER_NAME || "ANOUER";
  const BRL = () => (window.__FH && __FH.BR) || (window.__RV && __RV.BR) || ["الفرع الرئيسي"];
  const BR = () => BRL()[0];
  const hue = s => { let h = 0; for (const c of String(s || "")) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
  const mins = t => { if (!t) return null; const m = String(t).match(/(\d{1,2}):(\d{2})/); return m ? +m[1] * 60 + +m[2] : null; };
  const span = (a, b) => { let x = mins(a), y = mins(b); if (x == null || y == null) return null; if (y < x) y += 1440; return y - x; };
  const hhmm = m => p2(Math.floor(m / 60)) + ":" + p2(m % 60);
  const t12 = t => { const m = mins(t); if (m == null) return ""; const h = Math.floor(m / 60) % 24; return p2(h % 12 || 12) + ":" + p2(m % 60) + (h < 12 ? " ص" : " م"); };
  const nowHM = () => { const d = new Date(); return p2(d.getHours()) + ":" + p2(d.getMinutes()); };
  const KE = "hre", KA = "hra", KP = "hrp", VIEW = "hr_hub", TITLE = "الموظفين و الرواتب";
  /* ترخيص: في نسخ العملاء «الموظفين و الرواتب» إضافة مدفوعة — تعمل بكود التفعيل فقط (بدون تجربة) */
  const DIST = () => !!(window.ANOUER_EDITION || {}).dist, LIC = () => window.ANOUER_LIC;
  function regLic() { const L = LIC(); if (!DIST() || !L || !L.register || (L.mods && L.mods.hr)) return; L.register("hr", { t: TITLE, tag: "HR", c: "#0f766e", days: 30, noTrial: 1,
    desc: "الموظفين والرواتب: راتب شهري ← أجر يومي يُخصم من الأرباح والخسائر كل يوم عمل (الغياب لا يُحسب)، الحضور والغياب وساعات العمل، كشف الرواتب وصرف الراتب والسلف من الخزينة، وقيود آلية على شجرة الحسابات." }); }
  regLic();
  const licensed = () => { if (!DIST() || !LIC()) return true; regLic(); try { return !!LIC().ok("hr"); } catch (e) { return false; } };
  const licReady = () => (!DIST() || !LIC()) ? Promise.resolve(true) : (regLic(), Promise.resolve(LIC().init()).then(() => licensed()).catch(() => false));
  const SAL_RE = /رواتب|مرتب|أجور|اجور|راتب|أجرة العمال|اجرة العمال/;

  /* ---------------- الإعدادات ---------------- */
  const DEF = { basis: "30", off: [5], offPaid: false, src: "auto", dedupe: true, post: true, accExp: "32131", accLia: "2121", je: {} };
  const cfg = () => { const c = Object.assign({}, DEF, (PR() && PR().get("hr.cfg", {})) || {}); c.je = Object.assign({}, c.je || {}); return c; };
  const putCfg = c => PR() ? Promise.resolve(PR().put("hr.cfg", c)).catch(() => { }) : Promise.resolve();
  const shifts = () => ((PR() && PR().get("usr.shifts", [])) || []).filter(s => s && s.name && s.active !== false);
  const jobs = () => ((PR() && PR().get("usr.jobs", [{ name: "KHELD" }])) || []).filter(s => s && s.name && s.active !== false).map(s => s.name);
  const BASIS = [["30", "30 يوماً (ثابت)"], ["26", "26 يوم عمل"], ["month", "عدد أيام الشهر الفعلي"]];
  const SRC = [["auto", "تلقائي — حاضر ما لم يُسجَّل غياب"], ["login", "من سجل دخول المستخدم للبرنامج"], ["manual", "يدوي — أسجّل الحضور بنفسي"]];
  const MODE = [["day", "يوم كامل عند الحضور"], ["hours", "حسب ساعات العمل الفعلية"]];
  /* حالات اليوم: [الرمز، الاسم، النسبة من الأجر اليومي] */
  const ST = { p: ["حاضر", 1], h: ["نصف يوم", .5], a: ["غائب", 0], l: ["إجازة مدفوعة", 1], o: ["عطلة", 0], u: ["غير مسجَّل", 0], w: ["لم يحضر بعد", 0], f: ["قادم", 0], n: ["خارج فترة العمل", 0] };

  /* ---------------- أيقونات ---------------- */
  const sv = (p, w) => `<svg viewBox="0 0 24 24" width="${w || 18}" height="${w || 18}" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
  const IC = {
    logo: `<svg viewBox="0 0 48 48" width="30" height="30"><defs><linearGradient id="hrxg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#c7fff1"/></linearGradient></defs><circle cx="17" cy="15" r="6.5" fill="url(#hrxg)"/><path d="M5 37c0-7.2 5.4-11.6 12-11.6 3.3 0 6.2 1.1 8.3 3" fill="none" stroke="url(#hrxg)" stroke-width="4" stroke-linecap="round"/><circle cx="33.5" cy="31.5" r="10" fill="#fbbf24"/><circle cx="33.5" cy="31.5" r="7" fill="none" stroke="#b45309" stroke-width="1.6" opacity=".55"/><text x="33.5" y="35.6" text-anchor="middle" font-size="11" font-weight="800" fill="#92400e" font-family="Segoe UI,Arial">دج</text></svg>`,
    plus: sv('<path d="M12 5v14M5 12h14"/>'), gear: sv('<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
    sun: sv('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'),
    users: sv('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.3c2.1.7 3.5 2.6 3.5 5.7"/>'),
    cal: sv('<rect x="3" y="4.5" width="18" height="16" rx="3"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/><path d="M7.5 13.5h2M11 13.5h2M14.5 13.5h2M7.5 17h2M11 17h2"/>'),
    wallet: sv('<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H18v3"/><rect x="3" y="7.5" width="18" height="12.5" rx="2.6"/><path d="M16 13.8h2.5"/>'),
    chart: sv('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'),
    search: sv('<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>', 16),
    x: sv('<path d="M6 6l12 12M18 6L6 18"/>', 16), chev: sv('<path d="M15 6l-6 6 6 6"/>', 16), chevL: sv('<path d="M9 6l6 6-6 6"/>', 16),
    clock: sv('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'), bolt: sv('<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>'),
    check: sv('<path d="M5 12.5l4.5 4.5L19 7.5"/>'), cash: sv('<rect x="2.5" y="6" width="19" height="12" rx="2.4"/><circle cx="12" cy="12" r="2.6"/><path d="M6 9.5v5M18 9.5v5"/>'),
    gift: sv('<rect x="3.5" y="8.5" width="17" height="4" rx="1"/><path d="M5 12.5V20h14v-7.5M12 8.5V20M12 8.5C10 5 7 5 7 7s3 1.5 5 1.5zM12 8.5C14 5 17 5 17 7s-3 1.5-5 1.5z"/>'),
    minus: sv('<circle cx="12" cy="12" r="8.5"/><path d="M8 12h8"/>'), trash: sv('<path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 13h9l1-13"/>', 16),
    edit: sv('<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>', 16), print: sv('<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>', 16),
    tree: sv('<rect x="9" y="2.5" width="6" height="5" rx="1.2"/><rect x="2.5" y="16.5" width="6" height="5" rx="1.2"/><rect x="15.5" y="16.5" width="6" height="5" rx="1.2"/><path d="M12 7.5v4.5M5.5 16.5V12h13v4.5"/>'),
    link: sv('<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>', 14),
    door: sv('<path d="M14 3H6v18h8"/><path d="M14 3l5 2v14l-5 2z"/><circle cx="16.3" cy="12" r=".9" fill="currentColor"/>', 14),
    info: sv('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.6v.4"/>', 16), refresh: sv('<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>', 16),
    star: sv('<path d="M12 3.5l2.6 5.3 5.9.9-4.2 4.1 1 5.8-5.3-2.8-5.3 2.8 1-5.8-4.2-4.1 5.9-.9z"/>', 14)
  };
  const avatar = (name, sz) => `<span class="hrx-av${sz ? " " + sz : ""}" style="--h:${hue(name)}">${esc(String(name || "؟").trim().slice(0, 1))}</span>`;
  const busyBtn = (b, v) => { if (!b) return; b.disabled = !!v; b.classList.toggle("busy", !!v); };

  /* ================= البيانات ================= */
  let EMP = [], ATT = {}, ATTID = {}, PAYS = [], LOGS = {}, VOID = new Set(), LOADED = 0, LOADING = null;
  const DB = () => FH().DB;
  function normEmp(r) {
    const d = r.data || {}, C = cfg();
    return Object.assign({ uid: 0, job: "", shift: "", branch: "", salary: 0, basis: "", mode: "day", src: "", off: null, offPaid: null, start: "", end: "", phone: "", notes: "" }, d,
      { id: r.id, no: r.no, name: r.name, active: r.active !== false, _src: d.src || C.src, _off: Array.isArray(d.off) ? d.off : C.off, _offPaid: d.offPaid == null ? !!C.offPaid : !!d.offPaid });
  }
  function load(force) {
    if (LOADING) return LOADING;
    const H = FH(); if (!H) return Promise.reject(new Error("الفهرس غير محمّل"));
    const pre = PR() && PR().load ? Promise.resolve(PR().load()).catch(() => { }) : Promise.resolve();
    LOADING = pre.then(() => Promise.all([DB().list(KE, force).catch(() => []), DB().list(KA, force).catch(() => []), DB().list(KP, force).catch(() => [])])).then(([e, a, p]) => {
      EMP = (e || []).map(normEmp).sort((x, y) => (+x.no || 0) - (+y.no || 0));
      ATT = {}; ATTID = {}; (a || []).forEach(r => { const d = (r.data || {}).d || r.name; if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return; ATT[d] = Object.assign(ATT[d] || {}, (r.data || {}).m || {}); ATTID[d] = r.id; });
      PAYS = (p || []).map(r => Object.assign({ id: r.id, no: r.no }, r.data || {})).sort((x, y) => String(y.date).localeCompare(String(x.date)) || y.id - x.id);
      return Promise.all([loadLogs(), checkVoid()]);
    }).then(() => { LOADED = Date.now(); }).finally(() => { LOADING = null; });
    return LOADING;
  }
  const ensure = () => (LOADED && Date.now() - LOADED < 45000 ? Promise.resolve() : load(true));
  /* سجل دخول المستخدمين المرتبطين (أول دخول / آخر خروج في اليوم) */
  function loadLogs() {
    LOGS = {};
    if (!HOST()) return Promise.resolve();
    const ids = [...new Set(EMP.filter(e => e.uid && e._src === "login").map(e => e.uid))];
    return Promise.all(ids.map(id => call("users.logins", { id, top: 500 }).then(l => {
      const m = {}; (l || []).forEach(x => { const d = String(x.Date || "").slice(0, 10); if (!d) return; const o = m[d] || (m[d] = { in: "", out: "" }); const i = String(x.LoginAt || "").slice(0, 5), u = String(x.LogoutAt || "").slice(0, 5);
        if (i && (!o.in || i < o.in)) o.in = i; if (u && (!o.out || u > o.out)) o.out = u; });
      LOGS[id] = m;
    }).catch(() => { }))).then(() => { });
  }
  /* صرف/سلفة حُذف قيدها من «قيود المحاسبة» ← لا يُحسب مدفوعاً */
  function checkVoid() {
    VOID = new Set();
    const AC = A(); if (!AC || !PAYS.some(p => p.je && p.je.id)) return Promise.resolve();
    return AC.docs("je", true).then(l => { const ids = new Set((l || []).map(d => String(d.id))); PAYS.forEach(p => { if (p.je && p.je.id && !ids.has(String(p.je.id))) VOID.add(p.id); }); }).catch(() => { });
  }

  /* ================= الحساب ================= */
  function daily(e, date) {
    const s = +e.salary || 0; if (!s) return 0;
    const b = e.basis || cfg().basis;
    const n = b === "month" ? dim(ymOf(date)) : (+b || 30);
    return s / n;
  }
  function shiftOf(e) { const s = shifts().find(x => x.name === e.shift); return s ? { name: s.name, from: s.from || "08:00", to: s.to || "16:00", grace: +s.grace || 0 } : null; }
  function dayInfo(e, date) {
    const t = today();
    if (date > t) return { s: "f", f: 0, amt: 0 };
    if ((e.start && date < e.start) || (e.end && date > e.end)) return { s: "n", f: 0, amt: 0 };
    const rec = (ATT[date] || {})[e.id], wd = D0(date).getDay(), off = (e._off || []).includes(wd);
    let s, tin = "", tout = "", auto = false;
    if (rec && rec.s) { s = rec.s; tin = rec.in || ""; tout = rec.out || ""; }
    else {
      auto = true;
      if (e._src === "login" && e.uid) { const L = (LOGS[e.uid] || {})[date]; if (L) { s = "p"; tin = L.in; tout = L.out; } else s = off ? "o" : (date === t ? "w" : "a"); }
      else if (e._src === "manual") s = off ? "o" : (date === t ? "w" : "u");
      else s = off ? "o" : "p";
      if (rec) { tin = rec.in || tin; tout = rec.out || tout; }
    }
    let f = (ST[s] || ST.u)[1];
    if (s === "o") f = e._offPaid ? 1 : 0;
    const sh = shiftOf(e);
    let worked = null;
    if ((s === "p" || s === "h") && e.mode === "hours") { worked = span(tin, tout); const L = sh ? span(sh.from, sh.to) : 480; if (worked != null && L) f = Math.min(s === "h" ? .5 : 1, worked / L); }
    let late = 0; if (sh && tin && (s === "p" || s === "h")) { const d = mins(tin) - mins(sh.from); if (d > (sh.grace || 0)) late = d; }
    const r = daily(e, date);
    return { s, f, amt: r2(r * f), rate: r, in: tin, out: tout, auto, late, off, worked, note: rec && rec.n || "" };
  }
  const isPay = p => (p.type === "pay" || p.type === "adv") && !VOID.has(p.id);
  /* تكلفة الأجور لفترة — تستعملها قائمة الدخل ولوحات الأرباح */
  function calc(from, to, o) {
    o = o || {};
    const t = today(), end = minS(to, t), res = { on: EMP.length > 0, total: 0, work: 0, adj: 0, days: {}, emps: [], from, to };
    EMP.forEach(e => {
      if (o.br && e.branch && e.branch !== o.br) return;
      if (o.eid && e.id !== o.eid) return;
      const g = { id: e.id, name: e.name, job: e.job, days: 0, half: 0, abs: 0, leave: 0, late: 0, work: 0, bonus: 0, ded: 0, amt: 0 };
      let d = maxS(from, e.start || from); const last = minS(end, e.end || end);
      for (; d <= last; d = addDays(d, 1)) {
        const x = dayInfo(e, d);
        if (x.s === "p") g.days++; else if (x.s === "h") g.half++; else if (x.s === "a") g.abs++; else if (x.s === "l") g.leave++;
        if (x.late) g.late++;
        if (x.amt) { g.work += x.amt; res.days[d] = (res.days[d] || 0) + x.amt; }
      }
      PAYS.forEach(p => { if (p.eid !== e.id || !(p.date >= from && p.date <= to)) return;
        if (p.type === "bonus") { g.bonus += +p.amt || 0; res.days[p.date] = (res.days[p.date] || 0) + (+p.amt || 0); }
        else if (p.type === "ded") { g.ded += +p.amt || 0; res.days[p.date] = (res.days[p.date] || 0) - (+p.amt || 0); } });
      g.work = r2(g.work); g.bonus = r2(g.bonus); g.ded = r2(g.ded); g.amt = r2(g.work + g.bonus - g.ded);
      if (g.amt || g.days || g.half || g.leave || g.abs || e.active) res.emps.push(g);
      res.work += g.work; res.adj += g.bonus - g.ded;
    });
    Object.keys(res.days).forEach(k => res.days[k] = r2(res.days[k]));
    res.work = r2(res.work); res.adj = r2(res.adj); res.total = r2(res.work + res.adj);
    return res;
  }
  function cost(from, to, o) { return licReady().then(ok => { if (!ok) return { on: false, total: 0, days: {}, emps: [] }; return ensure().then(() => { const r = calc(from, to, o); r.dedupe = cfg().dedupe !== false; r.re = SAL_RE; return r; }); }).catch(() => ({ on: false, total: 0, days: {}, emps: [] })); }
  /* ما دُفع للموظف (صرف + سلف) في فترة */
  const paidOf = (eid, from, to) => r2(PAYS.filter(p => p.eid === eid && isPay(p) && p.date >= from && p.date <= to).reduce((s, p) => s + (+p.amt || 0), 0));
  /* ================= الحفظ ================= */
  function saveEmp(e) {
    const data = {}; ["uid", "job", "shift", "branch", "salary", "basis", "mode", "src", "off", "offPaid", "start", "end", "phone", "notes"].forEach(k => { if (e[k] !== undefined) data[k] = e[k]; });
    data.salary = r2(data.salary);
    const go = no => DB().save(KE, { id: e.id || 0, no, name: String(e.name || "").trim(), active: e.active !== false, data });
    return (e.no ? Promise.resolve(e.no) : DB().next(KE)).then(go).then(r => { LOADED = 0; return r; });
  }
  const pend = {};
  let saveT = null;
  /* تسجيل حالة يوم لموظف (يُحفظ مجمّعاً بعد لحظة) */
  function setDay(eid, date, patch) {
    const m = ATT[date] || (ATT[date] = {}), cur = Object.assign({}, m[eid] || {}, patch || {});
    Object.keys(cur).forEach(k => { if (cur[k] === "" || cur[k] == null) delete cur[k]; });
    if (Object.keys(cur).length) m[eid] = cur; else delete m[eid];
    pend[date] = 1; clearTimeout(saveT); saveT = setTimeout(flush, 450);
  }
  function flush() {
    const ds = Object.keys(pend); ds.forEach(d => delete pend[d]);
    return Promise.all(ds.map(d => DB().save(KA, { id: ATTID[d] || 0, no: d.replace(/-/g, ""), name: d, active: true, data: { d, m: ATT[d] || {} } }).then(r => { if (r && r.id) ATTID[d] = r.id; })))
      .then(() => { [...new Set(ds.map(ymOf))].forEach(ym => scheduleSync(ym)); })
      .catch(e => T("تعذّر حفظ الحضور: " + (e.message || e), "e"));
  }

  /* ================= شجرة الحسابات ================= */
  function leaf(n) { while (n && n.kids && n.kids.length) n = n.kids[0]; return n; }
  function accs() {
    const AC = A(), C = cfg(); if (!AC || !AC.coaTree) return Promise.resolve({});
    return AC.coaTree().then(t => { const pk = no => { const n = leaf(t.byNo[String(no)]); return n ? { id: n.id, no: n.no, name: n.name } : null; }; return { exp: pk(C.accExp), lia: pk(C.accLia), tree: t }; }).catch(() => ({}));
  }
  function dirtyAC(kind) { const AC = A(); try { AC.invalidate(); delete AC.AC.tr; } catch (e) { } try { if (window.__AC_REFRESH) __AC_REFRESH(kind); } catch (e) { } }
  const SYNC = {}, SYNCT = {};
  function scheduleSync(ym) { clearTimeout(SYNCT[ym]); SYNCT[ym] = setTimeout(() => syncMonth(ym).then(() => { if (ROOT && S.tab === "pay") paintPostChip(); }), 1200); }
  /* قيد استحقاق الشهر: واحد لكل شهر ويتحدّث كلما تغيّر الحضور (مدين الأجور / دائن المرتبات المستحقة) */
  function syncMonth(ym) {
    const C = cfg(), AC = A();
    if (C.post === false || !AC || !EMP.length || !licensed()) return Promise.resolve(null);
    if (SYNC[ym]) return SYNC[ym].then(() => syncMonth(ym));
    const from = ym + "-01", to = minS(monthEnd(ym), today());
    if (from > today()) return Promise.resolve(null);
    const p = Promise.all([accs(), AC.docs("je", true).catch(() => [])]).then(([ac, list]) => {
      const amt = calc(from, to).total, cur = C.je[ym], doc = cur && cur.id ? (list || []).find(d => String(d.id) === String(cur.id)) : null;
      if (!ac.exp || !ac.lia) return { err: "حسابات القيد غير موجودة في شجرة الحسابات (" + C.accExp + " / " + C.accLia + ")" };
      if (doc && Math.abs((+doc.data.total || 0) - amt) < .005 && doc.data.date === to) return cur;
      if (amt <= 0) { if (!doc) return null; return AC.delDoc("je", doc.id).then(() => { const c = cfg(); delete c.je[ym]; dirtyAC("je"); return putCfg(c); }).then(() => null); }
      const stmt = "استحقاق رواتب وأجور الموظفين — " + monthName(ym) + " (حسب أيام العمل الفعلية)";
      const rows = [{ t: "gl", no: ac.exp.no, name: ac.exp.name, aid: ac.exp.id, dr: amt, cr: 0, note: "أجور أيام العمل" }, { t: "gl", no: ac.lia.no, name: ac.lia.name, aid: ac.lia.id, dr: 0, cr: amt, note: "مستحق للموظفين" }];
      const lg = [{ t: "gl", id: ac.exp.id, d: amt, name: ac.exp.name, what: "قيد" }, { t: "gl", id: ac.lia.id, d: -amt, name: ac.lia.name, what: "قيد" }];
      const data = { date: to, time: AC.nowT(), br: BR(), stmt, cc: "", notes: "آلي — الموظفين و الرواتب (يتحدّث تلقائياً)", rows, dr: amt, cr: amt, total: amt, fx: [], lg, user: USER(), hr: ym };
      const save = doc ? AC.saveDoc("je", { id: doc.id, no: doc.no, data }).then(r => ({ id: doc.id, no: String(doc.no) }))
        : AC.nextNo("je").then(no => AC.saveDoc("je", { id: 0, no, data }).then(r => ({ id: r.id, no: String(r.no || no) })));
      return save.then(j => { const c = cfg(); c.je[ym] = { id: j.id, no: j.no, amt }; dirtyAC("je"); return putCfg(c).then(() => c.je[ym]); });
    }).catch(e => ({ err: e.message || String(e) })).finally(() => { delete SYNC[ym]; });
    SYNC[ym] = p; return p;
  }
  /* صرف راتب / سلفة: قيد حقيقي — مدين المرتبات المستحقة / دائن الخزينة */
  function payJE(p, e) {
    return accs().then(ac => {
      if (!ac.lia) throw new Error("حساب «المرتبات المستحقة» (" + cfg().accLia + ") غير موجود في شجرة الحسابات — اختره من الإعدادات");
      const AC = A(), amt = r2(p.amt), date = p.date || today(), what = p.type === "adv" ? "سلفة" : "صرف راتب";
      const stmt = what + " — " + e.name + (p.note ? " — " + p.note : "");
      const af = AC.accFx({ type: "tr", id: p.tr.id, name: p.tr.name }, -amt, { party: e.name, notes: stmt, what: "قيود المحاسبة" });
      const fx = af.fx, lg = [{ t: "gl", id: ac.lia.id, d: amt, name: ac.lia.name, what: "قيد", party: e.name }].concat(af.lg);
      const rows = [{ t: "gl", no: ac.lia.no, name: ac.lia.name, aid: ac.lia.id, dr: amt, cr: 0, note: e.name }, { t: "tr", no: "", name: p.tr.name, aid: p.tr.id, dr: 0, cr: amt, note: what }];
      return AC.nextNo("je").then(no => {
        const notes = "قيد رقم " + no + " - " + stmt;
        const data = { date, time: AC.nowT(), br: BR(), stmt, cc: "", notes: "آلي — الموظفين و الرواتب", rows, dr: amt, cr: amt, total: amt, fx, lg, user: USER(), hrp: e.id };
        return AC.post(fx, [], { date, no: String(no), notes }).then(() => AC.saveDoc("je", { id: 0, no, data }).catch(er => AC.post([], fx, { date, no: String(no), notes: "عكس " + notes }).then(() => { throw er; })))
          .then(r => { dirtyAC("je"); return { id: r.id, no: String(r.no || no), fx }; });
      });
    });
  }
  function addPay(p, e) {
    const isCash = p.type === "pay" || p.type === "adv";
    return (isCash ? payJE(p, e) : Promise.resolve(null)).then(je => DB().next(KP).then(no => DB().save(KP, { id: 0, no, name: no, active: true,
      data: { eid: e.id, ename: e.name, type: p.type, amt: r2(p.amt), date: p.date, tr: isCash ? { id: p.tr.id, name: p.tr.name } : null, je, note: p.note || "", user: USER(), at: new Date().toLocaleString("sv-SE").slice(0, 16) } })))
      .then(() => load(true)).then(() => { if (!isCash) return syncMonth(ymOf(p.date)); });
  }
  function delPay(p) {
    const AC = A();
    const undo = p.je && p.je.id && !VOID.has(p.id) ? AC.post([], p.je.fx || [], { date: today(), no: String(p.je.no || ""), notes: "إلغاء " + (p.type === "adv" ? "سلفة" : "صرف راتب") + " — " + (p.ename || "") }).then(() => AC.delDoc("je", p.je.id)).then(() => dirtyAC("je")) : Promise.resolve();
    return undo.then(() => DB().del(KP, p.id)).then(() => load(true)).then(() => { if (p.type === "bonus" || p.type === "ded") return syncMonth(ymOf(p.date)); });
  }

  /* ================= الواجهة ================= */
  const S = { tab: "day", day: today(), ym: ymOf(today()), q: "", per: "m", from: "", to: "" };
  let ROOT = null, CLOCK = null;
  function open(go) {
    if (DIST() && LIC() && LIC().gate) { regLic(); return LIC().gate("hr", () => center(go)); }
    return center(go);
  }
  function center(go) {
    const H = FH(); if (!H) { T("الشاشة غير متاحة", "w"); return; }
    const el = H.mkView(VIEW, TITLE);
    if (!el.dataset.b) {
      el.dataset.b = "1"; el.classList.add("hrx-vw"); ROOT = el;
      el.innerHTML = `<div class="hrx-root"><div class="hrx-hero"><i class="hrx-bl a"></i><i class="hrx-bl b"></i><i class="hrx-bl c"></i><i class="hrx-grid"></i>
          <div class="hrx-top"><span class="hrx-logo">${IC.logo}</span><div class="hrx-tt"><h2>الموظفين و الرواتب</h2><p>كل يوم عمل يدخل في <b>الأرباح والخسائر</b> تلقائياً — ويوم الغياب لا يُحسب</p></div><span class="sp"></span>
            <span class="hrx-clock" data-clock></span>
            <button type="button" class="hrx-btn glass" data-a="set" title="الإعدادات وربط شجرة الحسابات">${IC.gear}<span>الإعدادات</span></button>
            <button type="button" class="hrx-btn pri" data-a="new">${IC.plus}<span>موظف جديد</span></button></div>
          <div class="hrx-kpis" data-kpi></div></div>
        <div class="hrx-bar"><div class="hrx-seg" data-seg>${[["day", "الحضور اليومي", IC.sun], ["emp", "الموظفين", IC.users], ["mon", "الحضور الشهري", IC.cal], ["pay", "كشف الرواتب", IC.wallet], ["rep", "الأجور والأرباح", IC.chart]].map(t => `<button type="button" data-t="${t[0]}">${t[2]}<span>${t[1]}</span></button>`).join("")}<i class="hrx-ind"></i></div>
          <span class="sp"></span><label class="hrx-srch">${IC.search}<input data-q placeholder="ابحث عن موظف…" autocomplete="off" spellcheck="false"></label></div>
        <div class="hrx-body" data-body></div></div>`;
      el.addEventListener("click", onClick);
      el.addEventListener("change", onChange);
      const q = el.querySelector("[data-q]"); q.addEventListener("input", () => { S.q = q.value.trim(); drawBody(); });
      el.addEventListener("keydown", e => { if (e.target.matches("input,select,textarea")) e.stopPropagation(); });
      try { window.__RV.VIEW_SHOW[VIEW] = () => { if (licensed()) refresh(); else { try { FH().tabClose(VIEW); } catch (e) { } open(); } }; } catch (e) { }
    }
    H.tabOpen(VIEW, TITLE, VIEW);
    if (go) S.tab = go;
    refresh(true);
  }
  function refresh(first) {
    if (!ROOT) return;
    if (first && !LOADED) ROOT.querySelector("[data-body]").innerHTML = `<div class="hrx-load"><i></i><i></i><i></i></div>`;
    load(true).then(() => { draw(); syncMonth(ymOf(today())).then(() => { if (S.tab === "pay") paintPostChip(); }); }).catch(e => { ROOT.querySelector("[data-body]").innerHTML = `<div class="hrx-empty"><h3>تعذّر التحميل</h3><p>${esc(e.message || e)}</p></div>`; });
    startClock();
  }
  function startClock() {
    clearInterval(CLOCK);
    const tick = () => {
      if (!ROOT || !ROOT.isConnected) { clearInterval(CLOCK); return; }
      const c = ROOT.querySelector("[data-clock]"); if (c) { const d = new Date(); c.innerHTML = `${IC.clock}<b>${p2(d.getHours())}:${p2(d.getMinutes())}</b><span>${DAYS[d.getDay()]} ${d.getDate()} ${MON[d.getMonth()]}</span>`; }
      paintLive();
    };
    tick(); CLOCK = setInterval(tick, 20000);
  }
  /* «عدّاد الأجور الحي»: ما تراكم من أجر اليوم حسب الوقت داخل الوردية */
  function liveNow() {
    const t = today(), now = mins(nowHM()); let full = 0, acc = 0;
    EMP.filter(e => e.active).forEach(e => { const x = dayInfo(e, t); if (!x.amt) return; full += x.amt; const sh = shiftOf(e); const a = mins(x.in || (sh && sh.from) || "08:00"), b = mins(x.out || (sh && sh.to) || "16:00"); let L = b - a; if (L <= 0) L += 1440;
      const k = x.out ? 1 : Math.max(0, Math.min(1, (now - a) / L)); acc += x.amt * k; });
    return { full: r2(full), acc: r2(acc), pct: full ? Math.round(acc / full * 100) : 0 };
  }
  function paintLive() {
    if (!ROOT) return; const k = ROOT.querySelector("[data-live]"); if (!k) return;
    const L = liveNow(); k.querySelector("b").textContent = N0(L.acc); k.querySelector("i").style.setProperty("--p", L.pct + "%");
  }
  function kpis() {
    const t = today(), ym = ymOf(t), act = EMP.filter(e => e.active), dd = act.map(e => dayInfo(e, t)), pres = dd.filter(x => x.s === "p" || x.s === "h").length;
    const m = calc(ym + "-01", t), paid = r2(EMP.reduce((s, e) => s + paidOf(e.id, ym + "-01", monthEnd(ym)), 0)), dayAmt = r2(dd.reduce((s, x) => s + x.amt, 0));
    const L = liveNow();
    const K = (cls, ic, l, v, sm, tab, extra) => `<button type="button" class="hrx-k ${cls}" data-go="${tab}"><span class="i">${ic}</span><span class="l">${l}</span><b>${v}</b><small>${sm}</small>${extra || ""}</button>`;
    ROOT.querySelector("[data-kpi]").innerHTML =
      K("a", IC.sun, "أجور اليوم", N0(dayAmt) + " <em>دج</em>", `تراكم الآن: <span data-live><b>${N0(L.acc)}</b> دج<i style="--p:${L.pct}%"></i></span>`, "day") +
      K("b", IC.users, "الحاضرون اليوم", pres + " <em>/ " + act.length + "</em>", act.length ? (act.length - pres ? (act.length - pres) + " غائب أو لم يحضر بعد" : "الجميع حاضر ✨") : "أضف موظفيك", "day") +
      K("c", IC.cal, "أجور " + MON[+ym.slice(5, 7) - 1] + " حتى اليوم", N0(m.total) + " <em>دج</em>", "تُخصم من أرباح الشهر", "rep") +
      K("d", IC.cash, "المدفوع هذا الشهر", N0(paid) + " <em>دج</em>", "رواتب + سلف", "pay") +
      K("e", IC.wallet, "الباقي للموظفين", N0(Math.max(0, r2(m.total - paid))) + " <em>دج</em>", "مستحق عن هذا الشهر", "pay");
  }
  function draw() {
    if (!ROOT) return;
    kpis();
    const seg = ROOT.querySelector("[data-seg]");
    seg.querySelectorAll("[data-t]").forEach(b => b.classList.toggle("on", b.dataset.t === S.tab));
    const on = seg.querySelector(".on"), ind = seg.querySelector(".hrx-ind");
    if (on && ind) { ind.style.width = on.offsetWidth + "px"; ind.style.right = (seg.clientWidth - on.offsetLeft - on.offsetWidth) + "px"; }
    drawBody();
  }
  const match = e => !S.q || (e.name + " " + (e.job || "") + " " + (e.phone || "")).toLowerCase().includes(S.q.toLowerCase());
  function drawBody() {
    if (!ROOT) return; const b = ROOT.querySelector("[data-body]");
    if (!EMP.length) { b.innerHTML = emptyHTML(); return; }
    b.innerHTML = S.tab === "day" ? dayHTML() : S.tab === "emp" ? empHTML() : S.tab === "mon" ? monHTML() : S.tab === "pay" ? payHTML() : repHTML();
    if (S.tab === "pay") paintPostChip();
    if (S.tab === "rep") paintRep();
  }
  function emptyHTML() {
    return `<div class="hrx-empty big"><span class="art">${IC.logo}</span><h3>أضف موظفيك… وخلي ANOUER يحسب الأجور كل يوم</h3>
      <p>اكتب الراتب الشهري لكل عامل (مثلاً <b>30,000 دج</b>) ← ANOUER يحسب الأجر اليومي (<b>1,000 دج</b>) ويخصمه من أرباح كل يوم يعمل فيه.<br>يوم الغياب لا يُحسب، والسلف والرواتب تُصرف من الخزينة بقيد حقيقي على شجرة الحسابات.</p>
      <div class="pts"><span>${IC.sun} حضور بضغطة</span><span>${IC.clock} ساعات العمل والتأخير</span><span>${IC.chart} أرباح بعد الأجور</span><span>${IC.tree} قيود آلية</span></div>
      <button type="button" class="hrx-btn pri xl" data-a="new">${IC.plus}<span>إضافة أول موظف</span></button></div>`;
  }
  const stBtns = (cur, eid, date) => `<div class="hrx-st" data-eid="${eid}" data-date="${date}">${[["p", "حاضر"], ["h", "نصف يوم"], ["a", "غائب"], ["l", "إجازة"]].map(s => `<button type="button" data-s="${s[0]}" class="${s[0]}${cur === s[0] ? " on" : ""}">${s[1]}</button>`).join("")}</div>`;
  function dayHTML() {
    const d = S.day, t = today(), list = EMP.filter(e => (e.active || dayInfo(e, d).amt) && match(e));
    const infos = list.map(e => [e, dayInfo(e, d)]), tot = r2(infos.reduce((s, x) => s + x[1].amt, 0)), pres = infos.filter(x => x[1].s === "p" || x[1].s === "h").length;
    return `<div class="hrx-dayhd"><div class="hrx-dnav"><button type="button" class="hrx-ib" data-a="dprev" title="اليوم السابق">${IC.chevL}</button><label class="hrx-dpick"><input type="date" data-day value="${d}" max="${t}"><b>${nice(d)}</b></label><button type="button" class="hrx-ib" data-a="dnext" title="اليوم التالي"${d >= t ? " disabled" : ""}>${IC.chev}</button>${d !== t ? `<button type="button" class="hrx-btn sm" data-a="dtoday">اليوم</button>` : ""}</div>
      <div class="hrx-dsum"><span><i class="dot p"></i>${pres} حاضر</span><span><i class="dot a"></i>${infos.length - pres} غير حاضر</span><span class="amt">أجور اليوم <b>${N(tot)}</b> دج</span></div>
      <span class="sp"></span><button type="button" class="hrx-btn sm" data-a="allp">${IC.check}<span>الكل حاضر</span></button>${HOST() && EMP.some(e => e.uid) ? `<button type="button" class="hrx-btn sm" data-a="relog" title="إعادة قراءة سجل الدخول">${IC.refresh}<span>سجل الدخول</span></button>` : ""}</div>
      <div class="hrx-note">${IC.info}<span>ما تسجّله هنا يُحسب مباشرة في <b>قائمة الدخل</b> كمصروف «رواتب وأجور» — الغائب لا يُخصم أجره من أرباح اليوم.</span></div>
      <div class="hrx-cards">${infos.map(([e, x], i) => dayCard(e, x, d, i)).join("") || `<div class="hrx-empty"><p>لا يوجد موظف مطابق</p></div>`}</div>`;
  }
  function dayCard(e, x, d, i) {
    const sh = shiftOf(e), closed = x.s === "f" || x.s === "n";
    const tag = x.auto && !closed ? `<i class="hrx-tag auto" title="لم يُسجَّل يدوياً">${x.s === "p" && e._src === "login" ? "من سجل الدخول" : x.s === "o" ? "عطلة أسبوعية" : x.s === "w" ? "لم يحضر بعد" : x.s === "u" ? "غير مسجَّل" : "تلقائي"}</i>` : "";
    const cur = x.auto ? (x.s === "p" ? "p" : "") : x.s;
    return `<div class="hrx-card s-${x.s}" style="--d:${i * 35}ms"><div class="hd">${avatar(e.name)}<div class="nm"><b>${esc(e.name)}</b><small>${esc([e.job, sh ? sh.name + " " + t12(sh.from) + " ← " + t12(sh.to) : ""].filter(Boolean).join(" · ") || "—")}</small></div>${tag}</div>
      ${closed ? `<div class="hrx-closed">${esc(ST[x.s][0])}</div>` : stBtns(cur, e.id, d)}
      ${closed ? "" : `<div class="hrx-times"><label>${IC.door}<span>دخول</span><input type="time" data-tin="${e.id}" value="${esc(x.in || "")}"></label><label><span>خروج</span><input type="time" data-tout="${e.id}" value="${esc(x.out || "")}"></label>${x.late ? `<i class="hrx-tag late">تأخر ${x.late} د</i>` : ""}${x.worked != null ? `<i class="hrx-tag hrs">${hhmm(x.worked)} س</i>` : ""}</div>`}
      <div class="ft"><span class="rt">${N(x.rate || daily(e, d))} دج/يوم${e.mode === "hours" ? " · بالساعات" : ""}</span><b class="${x.amt ? "" : "z"}">${x.amt ? "−" + N(x.amt) : "0"} <em>دج</em></b></div></div>`;
  }
  function empHTML() {
    const ym = ymOf(today()), from = ym + "-01", t = today();
    const list = EMP.filter(match).sort((a, b) => (b.active - a.active) || (+a.no - +b.no));
    return `<div class="hrx-ecards">${list.map((e, i) => {
      const g = calc(from, t, { eid: e.id }).emps[0] || { days: 0, amt: 0 }, wd = monthWorkdays(e, from, t), pct = wd ? Math.min(100, Math.round((g.days + g.half / 2) / wd * 100)) : 0;
      return `<button type="button" class="hrx-ec${e.active ? "" : " off"}" data-edit="${e.id}" style="--d:${i * 35}ms"><div class="hd">${avatar(e.name, "lg")}<div class="nm"><b>${esc(e.name)}</b><small>${esc(e.job || "بدون وظيفة")}${e.active ? "" : " · غير نشط"}</small></div><span class="hrx-ring" style="--p:${pct}"><b>${pct}<small>%</small></b></span></div>
        <div class="hrx-sal"><div><small>الراتب الشهري</small><b>${N(e.salary)} <em>دج</em></b></div><div><small>الأجر اليومي</small><b>${N(daily(e, t))} <em>دج</em></b></div></div>
        <div class="hrx-chips">${e.uid ? `<i>${IC.link} مستخدم البرنامج</i>` : ""}<i>${esc((SRC.find(s => s[0] === e._src) || SRC[0])[1].split(" —")[0])}</i>${e.mode === "hours" ? "<i>بالساعات</i>" : ""}${e.shift ? `<i>${esc(e.shift)}</i>` : ""}${e._off.length ? `<i>عطلة: ${e._off.map(x => DAYS[x]).join("، ")}</i>` : ""}</div>
        <div class="ft"><span>${MON[+ym.slice(5, 7) - 1]}: <b>${g.days}</b> يوم${g.half ? " + " + g.half + " نصف" : ""}</span><b>${N(g.amt)} <em>دج</em></b></div></button>`; }).join("")}
      <button type="button" class="hrx-ec add" data-a="new"><span>${IC.plus}</span><b>موظف جديد</b><small>عامل، كاشير، سائق…</small></button></div>`;
  }
  function monthWorkdays(e, from, to) { let n = 0; for (let d = maxS(from, e.start || from); d <= minS(to, e.end || to); d = addDays(d, 1)) if (!(e._off || []).includes(D0(d).getDay())) n++; return n; }
  function monHTML() {
    const ym = S.ym, n = dim(ym), t = today(), list = EMP.filter(e => match(e) && (e.active || calc(ym + "-01", monthEnd(ym), { eid: e.id }).emps.length));
    const dayTot = Array(n + 1).fill(0);
    const rows = list.map(e => {
      let cells = "", days = 0, amt = 0;
      for (let i = 1; i <= n; i++) { const d = ym + "-" + p2(i), x = dayInfo(e, d); dayTot[i] += x.amt; amt += x.amt; if (x.s === "p") days++; else if (x.s === "h" || (x.s === "l")) days += x.s === "h" ? .5 : 1;
        cells += `<td class="c s-${x.s}${x.auto ? " au" : ""}${d === t ? " td" : ""}" data-cell="${e.id}|${d}" title="${esc(e.name + " — " + nice(d) + " — " + ST[x.s][0] + (x.amt ? " — " + N(x.amt) + " دج" : ""))}"><i></i></td>`; }
      return `<tr><th>${avatar(e.name, "sm")}<span>${esc(e.name)}</span></th>${cells}<td class="n">${days}</td><td class="n amt">${N0(amt)}</td></tr>`;
    }).join("");
    const head = Array.from({ length: n }, (_, i) => { const d = ym + "-" + p2(i + 1), w = D0(d).getDay(); return `<th class="${w === 5 ? "fri" : ""}${d === t ? " td" : ""}"><small>${DAY1[w]}</small>${i + 1}</th>`; }).join("");
    return `<div class="hrx-mhd"><div class="hrx-dnav"><button type="button" class="hrx-ib" data-a="mprev">${IC.chevL}</button><b class="mn">${monthName(ym)}</b><button type="button" class="hrx-ib" data-a="mnext"${ym >= ymOf(t) ? " disabled" : ""}>${IC.chev}</button></div>
      <div class="hrx-legend">${[["p", "حاضر"], ["h", "نصف يوم"], ["a", "غائب"], ["l", "إجازة مدفوعة"], ["o", "عطلة"], ["u", "غير مسجَّل"]].map(s => `<span><i class="lg s-${s[0]}"></i>${s[1]}</span>`).join("")}<span class="hint">اضغط على أي يوم لتغيير حالته</span></div></div>
      <div class="hrx-mtw"><table class="hrx-mt"><thead><tr><th>الموظف</th>${head}<th>الأيام</th><th>الأجر</th></tr></thead><tbody>${rows}</tbody>
      <tfoot><tr><th>أجور اليوم</th>${dayTot.slice(1).map(v => `<td>${v ? `<span title="${N(v)} دج">${v >= 1000 ? r2(v / 1000) + "k" : N0(v)}</span>` : ""}</td>`).join("")}<td></td><td class="n amt">${N0(dayTot.reduce((a, b) => a + b, 0))}</td></tr></tfoot></table></div>`;
  }
  function payRows(ym) {
    const from = ym + "-01", to = monthEnd(ym);
    return EMP.map(e => { const g = calc(from, to, { eid: e.id }).emps[0]; if (!g && !e.active) return null; const G = g || { days: 0, half: 0, leave: 0, work: 0, bonus: 0, ded: 0, amt: 0 };
      const paid = paidOf(e.id, from, to); return { e, g: G, paid, rem: r2(G.amt - paid) }; }).filter(x => x && (x.e.active || x.g.amt || x.paid) && match(x.e));
  }
  function payHTML() {
    const ym = S.ym, R = payRows(ym), from = ym + "-01", to = monthEnd(ym);
    const tot = k => R.reduce((s, x) => s + (k === "paid" ? x.paid : k === "rem" ? x.rem : x.g[k]), 0);
    const ops = PAYS.filter(p => p.date >= from && p.date <= to && (!S.q || String(p.ename || "").includes(S.q)));
    const TY = { pay: ["صرف راتب", "pay"], adv: ["سلفة", "adv"], bonus: ["مكافأة", "bonus"], ded: ["خصم", "ded"] };
    return `<div class="hrx-mhd"><div class="hrx-dnav"><button type="button" class="hrx-ib" data-a="mprev">${IC.chevL}</button><b class="mn">كشف رواتب ${monthName(ym)}</b><button type="button" class="hrx-ib" data-a="mnext"${ym >= ymOf(today()) ? " disabled" : ""}>${IC.chev}</button></div>
      <div class="hrx-post" data-post></div><span class="sp"></span><button type="button" class="hrx-btn sm" data-a="printpay">${IC.print}<span>طباعة الكشف</span></button></div>
      <div class="hrx-tw"><table class="hrx-pt"><thead><tr><th>الموظف</th><th>أيام العمل</th><th>الأجر اليومي</th><th>المستحق بالحضور</th><th>مكافآت</th><th>خصومات</th><th>الصافي</th><th>المدفوع</th><th>الباقي</th><th></th></tr></thead>
      <tbody>${R.map((x, i) => `<tr style="--d:${i * 30}ms"><th>${avatar(x.e.name, "sm")}<span><b>${esc(x.e.name)}</b><small>${N(x.e.salary)} دج / شهر</small></span></th>
        <td class="n">${x.g.days}${x.g.half ? `<small> +${x.g.half}½</small>` : ""}${x.g.leave ? `<small> +${x.g.leave} إجازة</small>` : ""}${x.g.abs ? `<small class="hneg"> · ${x.g.abs} غياب</small>` : ""}</td>
        <td class="n">${N(daily(x.e, from))}</td><td class="n">${N(x.g.work)}</td><td class="n hpos">${x.g.bonus ? "+" + N(x.g.bonus) : ""}</td><td class="n hneg">${x.g.ded ? "−" + N(x.g.ded) : ""}</td>
        <td class="n b">${N(x.g.amt)}</td><td class="n">${N(x.paid)}</td><td class="n b ${x.rem > 0 ? "rem" : x.rem < 0 ? "neg" : "zero"}">${N(x.rem)}</td>
        <td class="act"><button type="button" class="hrx-btn sm pri" data-pay="${x.e.id}">${IC.cash}<span>صرف</span></button><button type="button" class="hrx-ib" data-adj="${x.e.id}" title="مكافأة / خصم">${IC.gift}</button></td></tr>`).join("")}</tbody>
      <tfoot><tr><th>الإجمالي</th><td></td><td></td><td class="n">${N(tot("work"))}</td><td class="n">${N(tot("bonus"))}</td><td class="n">${N(tot("ded"))}</td><td class="n b">${N(tot("amt"))}</td><td class="n">${N(tot("paid"))}</td><td class="n b">${N(tot("rem"))}</td><td></td></tr></tfoot></table></div>
      <div class="hrx-ops"><h4>حركات ${monthName(ym)}<small>الصرف والسلف قيود حقيقية تُنقص الخزينة · المكافآت والخصومات تؤثر على الأرباح في تاريخها</small></h4>
      ${ops.length ? ops.map(p => `<div class="hrx-op ${TY[p.type][1]}${VOID.has(p.id) ? " void" : ""}"><span class="ty">${TY[p.type][0]}</span><b>${esc(p.ename || "")}</b><span class="dt">${dmy(p.date)}</span>${p.tr ? `<span class="tr">${IC.cash} ${esc(p.tr.name)}</span>` : ""}${p.je ? `<span class="je">${IC.tree} قيد ${esc(p.je.no)}</span>` : ""}${VOID.has(p.id) ? `<span class="vd">قيده محذوف — لا يُحسب</span>` : ""}<span class="nt">${esc(p.note || "")}</span><span class="sp"></span><b class="am">${p.type === "ded" ? "−" : ""}${N(p.amt)} <em>دج</em></b><button type="button" class="hrx-ib dng" data-delop="${p.id}" title="حذف">${IC.trash}</button></div>`).join("") : `<div class="hrx-empty sm"><p>لا توجد حركات في هذا الشهر بعد</p></div>`}</div>`;
  }
  function paintPostChip() {
    const el = ROOT && ROOT.querySelector("[data-post]"); if (!el) return;
    const C = cfg(), j = C.je[S.ym];
    if (C.post === false) { el.innerHTML = `<span class="hrx-pc off">${IC.tree} الترحيل لشجرة الحسابات متوقف</span>`; return; }
    el.innerHTML = j ? `<span class="hrx-pc pon" title="مدين ${esc(C.accExp)} / دائن ${esc(C.accLia)} — يتحدّث تلقائياً مع الحضور">${IC.tree} مُرحَّل لشجرة الحسابات · قيد <b>${esc(j.no)}</b> · ${N(j.amt)} دج</span>` : `<span class="hrx-pc">${IC.tree} يُرحَّل تلقائياً عند وجود أيام عمل</span>`;
  }
  function repHTML() {
    const t = today(); if (!S.from) { S.from = ymOf(t) + "-01"; S.to = t; }
    const P = [["m", "هذا الشهر"], ["pm", "الشهر السابق"], ["w", "آخر 7 أيام"], ["c", "مخصص"]];
    return `<div class="hrx-mhd"><div class="hrx-pseg">${P.map(p => `<button type="button" data-per="${p[0]}" class="${S.per === p[0] ? "on" : ""}">${p[1]}</button>`).join("")}</div>
      <label class="hrx-rng"><span>من</span><input type="date" data-rf value="${S.from}" max="${t}"></label><label class="hrx-rng"><span>إلى</span><input type="date" data-rt value="${S.to}" max="${t}"></label>
      <span class="sp"></span><button type="button" class="hrx-btn sm" data-a="pl">${IC.chart}<span>قائمة الدخل</span></button><button type="button" class="hrx-btn sm" data-a="printrep">${IC.print}<span>طباعة</span></button></div>
      <div data-rep><div class="hrx-load"><i></i><i></i><i></i></div></div>`;
  }
  let REP = null;
  function paintRep() {
    const host = ROOT.querySelector("[data-rep]"); if (!host) return;
    const from = S.from, to = S.to, R = window.ANOUER_REPORTS;
    const sales = R && R.data ? R.data(from, to).catch(() => ({ inv: [] })) : Promise.resolve({ inv: [] });
    Promise.all([sales, cost(from, to)]).then(([D, L]) => {
      const gp = {}; (D.inv || []).forEach(x => { if (x.t !== "Sale" && x.t !== "SaleReturn") return; const s = x.t === "SaleReturn" ? -1 : 1, c = (x.lines || []).reduce((a, l) => a + (+l.cost || 0), 0); gp[x.date] = (gp[x.date] || 0) + s * ((+x.total || 0) - c); });
      const days = []; for (let d = from; d <= to; d = addDays(d, 1)) { const pres = EMP.filter(e => { const s = dayInfo(e, d).s; return s === "p" || s === "h"; }).length; days.push({ d, pres, gp: r2(gp[d] || 0), lab: r2(L.days[d] || 0) }); }
      days.forEach(x => x.net = r2(x.gp - x.lab));
      const G = r2(days.reduce((s, x) => s + x.gp, 0)), Lb = r2(days.reduce((s, x) => s + x.lab, 0)), Nt = r2(G - Lb), pct = G > 0 ? Math.round(Lb / G * 100) : 0;
      REP = { from, to, days, G, Lb, Nt, emps: L.emps };
      const mx = Math.max(1, ...days.map(x => Math.max(Math.abs(x.gp), x.lab)));
      const bars = days.slice(-31).map((x, i) => `<div class="b" title="${esc(nice(x.d))}\nمجمل الربح: ${N(x.gp)} دج\nالأجور: ${N(x.lab)} دج\nالصافي: ${N(x.net)} دج" style="--d:${i * 18}ms"><span class="g" style="--h:${Math.max(0, x.gp) / mx * 100}%"></span><span class="l" style="--h:${x.lab / mx * 100}%"></span><small>${+x.d.slice(8)}</small></div>`).join("");
      host.innerHTML = `<div class="hrx-rk"><div class="k g"><small>مجمل الربح من المبيعات</small><b>${N(G)} <em>دج</em></b></div><div class="op">−</div><div class="k l"><small>أجور الموظفين (أيام العمل)</small><b>${N(Lb)} <em>دج</em></b><i>${pct}% من مجمل الربح</i></div><div class="op">=</div><div class="k ${Nt >= 0 ? "n" : "x"}"><small>الربح بعد الأجور</small><b>${N(Nt)} <em>دج</em></b><i>قبل باقي المصروفات</i></div></div>
        <div class="hrx-chart"><div class="hd"><b>كل يوم: الربح مقابل الأجور</b><span><i class="lg g"></i>مجمل الربح</span><span><i class="lg l"></i>الأجور</span></div><div class="bars">${bars}</div></div>
        <div class="hrx-two"><div class="hrx-tw"><table class="hrx-pt sm"><thead><tr><th>اليوم</th><th>الحاضرون</th><th>مجمل الربح</th><th>الأجور</th><th>الصافي</th></tr></thead><tbody>${days.slice().reverse().map(x => `<tr><th>${esc(nice(x.d))}</th><td class="n">${x.pres}</td><td class="n">${N(x.gp)}</td><td class="n hneg">${x.lab ? "−" + N(x.lab) : "0"}</td><td class="n b ${x.net < 0 ? "neg" : ""}">${N(x.net)}</td></tr>`).join("")}</tbody></table></div>
        <div class="hrx-tw"><table class="hrx-pt sm"><thead><tr><th>الموظف</th><th>أيام</th><th>الأجر</th></tr></thead><tbody>${L.emps.filter(g => g.amt).sort((a, b) => b.amt - a.amt).map(g => `<tr><th>${avatar(g.name, "sm")}<span>${esc(g.name)}</span></th><td class="n">${g.days}${g.half ? "+" + g.half + "½" : ""}</td><td class="n b">${N(g.amt)}</td></tr>`).join("") || `<tr><td colspan="3" class="hrx-e">لا أجور في هذه الفترة</td></tr>`}</tbody></table></div></div>`;
    });
  }

  /* ================= الأحداث ================= */
  function onClick(ev) {
    const t = ev.target, b = t.closest("button");
    const seg = t.closest("[data-seg] [data-t]"); if (seg) { S.tab = seg.dataset.t; draw(); return; }
    const go = t.closest("[data-go]"); if (go) { S.tab = go.dataset.go; if (S.tab === "day") S.day = today(); draw(); return; }
    const sb = t.closest(".hrx-st [data-s]"); if (sb) { const w = sb.parentElement, eid = +w.dataset.eid, d = w.dataset.date, s = sb.dataset.s, cur = ((ATT[d] || {})[eid] || {}).s;
      const patch = { s: cur === s ? "" : s }; if (s === "p" && cur !== s && !((ATT[d] || {})[eid] || {}).in && d === today()) { const e = EMP.find(x => x.id === eid); if (e && e.mode === "hours") patch.in = nowHM(); }
      setDay(eid, d, patch); snd("click"); draw(); return; }
    const cell = t.closest("[data-cell]"); if (cell) { const [eid, d] = cell.dataset.cell.split("|"); if (d > today()) return; const e = EMP.find(x => x.id === +eid), x = dayInfo(e, d); if (x.s === "n") return;
      const order = ["p", "h", "a", "l", ""], cur = ((ATT[d] || {})[eid] || {}).s || "", nx = order[(order.indexOf(cur) + 1) % order.length];
      setDay(+eid, d, { s: nx }); draw(); return; }
    const ed = t.closest("[data-edit]"); if (ed) { empDlg(EMP.find(e => e.id === +ed.dataset.edit)); return; }
    if (t.closest("[data-pay]")) { payDlg(EMP.find(e => e.id === +t.closest("[data-pay]").dataset.pay)); return; }
    if (t.closest("[data-adj]")) { adjDlg(EMP.find(e => e.id === +t.closest("[data-adj]").dataset.adj)); return; }
    if (t.closest("[data-delop]")) { const p = PAYS.find(x => x.id === +t.closest("[data-delop]").dataset.delop); if (p) confirmDlg("حذف الحركة", `حذف «${p.type === "pay" ? "صرف راتب" : p.type === "adv" ? "سلفة" : p.type === "bonus" ? "مكافأة" : "خصم"}» بمبلغ <b>${N(p.amt)} دج</b> لـ «${esc(p.ename)}»؟${p.je && !VOID.has(p.id) ? "<br><small>سيُحذف قيدها ويرجع المبلغ إلى «" + esc(p.tr ? p.tr.name : "الخزينة") + "».</small>" : ""}`, "حذف", () => delPay(p).then(() => { T("تم الحذف", "s"); draw(); })); return; }
    const per = t.closest("[data-per]"); if (per) { S.per = per.dataset.per; const td = today(), ym = ymOf(td);
      if (S.per === "m") { S.from = ym + "-01"; S.to = td; } else if (S.per === "pm") { const p = addMonth(ym, -1); S.from = p + "-01"; S.to = monthEnd(p); } else if (S.per === "w") { S.from = addDays(td, -6); S.to = td; }
      drawBody(); return; }
    if (!b || !b.dataset.a) return;
    const a = b.dataset.a;
    if (a === "new") empDlg(null);
    else if (a === "set") setDlg();
    else if (a === "dprev") { S.day = addDays(S.day, -1); drawBody(); }
    else if (a === "dnext") { if (S.day < today()) { S.day = addDays(S.day, 1); drawBody(); } }
    else if (a === "dtoday") { S.day = today(); drawBody(); }
    else if (a === "mprev") { S.ym = addMonth(S.ym, -1); drawBody(); }
    else if (a === "mnext") { if (S.ym < ymOf(today())) { S.ym = addMonth(S.ym, 1); drawBody(); } }
    else if (a === "allp") { EMP.filter(e => e.active && match(e)).forEach(e => { const x = dayInfo(e, S.day); if (x.s !== "n" && x.s !== "f") setDay(e.id, S.day, { s: "p" }); }); snd("save"); draw(); T("✔ تم تسجيل الجميع حاضرين — " + nice(S.day), "s"); }
    else if (a === "relog") { busyBtn(b, true); loadLogs().then(() => { draw(); T("تم تحديث الحضور من سجل الدخول", "s"); }); }
    else if (a === "printpay") printPay();
    else if (a === "printrep") printRep();
    else if (a === "pl") { const R = window.ANOUER_REPORTS; const r = R && R.rows && R.rows.find(x => x.frm === "FrmRptBranchListDT" && x.tags === "ProfitLoss"); if (r) R.run(r); else T("افتح التقارير ← الحسابات ← قائمة الدخل", "i"); }
  }
  function onChange(ev) {
    const t = ev.target;
    if (t.matches("[data-day]")) { if (t.value) { S.day = minS(t.value, today()); drawBody(); } return; }
    if (t.matches("[data-tin],[data-tout]")) { const eid = +(t.dataset.tin || t.dataset.tout), k = t.dataset.tin ? "in" : "out", d = S.day, rec = (ATT[d] || {})[eid] || {};
      const patch = { [k]: t.value }; if (!rec.s) { const x = dayInfo(EMP.find(e => e.id === eid), d); if (t.value && x.s !== "p" && x.s !== "h") patch.s = "p"; }
      setDay(eid, d, patch); draw(); return; }
    if (t.matches("[data-rf],[data-rt]")) { const f = ROOT.querySelector("[data-rf]").value, to = ROOT.querySelector("[data-rt]").value; if (f && to && f <= to) { S.from = f; S.to = minS(to, today()); S.per = "c"; drawBody(); } }
  }

  /* ================= الحوارات ================= */
  function dlg(o) {
    document.querySelectorAll(".hrx-ov").forEach(x => x.remove());
    const ov = document.createElement("div"); ov.className = "hrx-ov";
    ov.innerHTML = `<div class="hrx-dlg ${o.cls || ""}" role="dialog" aria-modal="true" style="${o.w ? "width:" + o.w + "px" : ""}"><div class="hrx-dh">${o.icon ? `<span class="di">${o.icon}</span>` : ""}<div><h3>${o.title}</h3>${o.sub ? `<p>${o.sub}</p>` : ""}</div><span class="sp"></span><button type="button" class="hrx-ib" data-x title="إغلاق (Esc)">${IC.x}</button></div>
      <div class="hrx-db">${o.body}</div><div class="hrx-df">${o.foot || ""}<span class="sp"></span><button type="button" class="hrx-btn" data-x>إلغاء</button><button type="button" class="hrx-btn pri" data-ok>${o.ok || "حفظ"}</button></div></div>`;
    document.body.appendChild(ov);
    const prev = window.__FH_DLGKEY;
    const close = () => { ov.classList.add("out"); setTimeout(() => ov.remove(), 160); window.__FH_DLGKEY = prev; };
    window.__FH_DLGKEY = e => { if (!document.body.contains(ov)) return false; if (e.key === "Escape") { close(); return true; } if (e.key === "F2") { ok(); return true; } if (/^F\d+$/.test(e.key)) return true; return false; };
    const q = s => ov.querySelector(s);
    const ok = () => { const btn = q("[data-ok]"); if (btn.disabled) return; const r = o.onOk(q, btn); if (r && r.then) { busyBtn(btn, true); r.then(v => { if (v !== false) close(); else busyBtn(btn, false); }).catch(e => { busyBtn(btn, false); T(e.message || String(e), "e"); }); } else if (r !== false) close(); };
    ov.addEventListener("mousedown", e => { if (e.target === ov) close(); });
    ov.addEventListener("click", e => { if (e.target.closest("[data-x]")) close(); else if (e.target.closest("[data-ok]")) ok(); });
    ov.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Escape") { e.preventDefault(); close(); } else if (e.key === "Enter" && e.target.tagName !== "TEXTAREA" && !e.target.matches("select")) { e.preventDefault(); ok(); } });
    if (o.wire) o.wire(q, ov);
    setTimeout(() => { const f = ov.querySelector("input:not([type=hidden]):not([type=checkbox]),select"); if (f) f.focus(); }, 40);
    return { q, close, ov };
  }
  function confirmDlg(title, html, okT, fn) { dlg({ title, icon: IC.trash, cls: "sm", w: 430, body: `<p class="hrx-cf">${html}</p>`, ok: okT, onOk: () => fn() }).ov.querySelector("[data-ok]").classList.add("dng"); }
  const fld = (lb, inner, o) => `<label class="hrx-f${o && o.cls ? " " + o.cls : ""}"><span class="lb">${lb}${o && o.req ? '<i class="req">*</i>' : ""}</span>${inner}${o && o.hint ? `<small class="ht">${o.hint}</small>` : ""}</label>`;
  const selO = (opts, v) => opts.map(o => Array.isArray(o) ? `<option value="${esc(o[0])}"${String(o[0]) === String(v) ? " selected" : ""}>${esc(o[1])}</option>` : `<option${o === v ? " selected" : ""}>${esc(o)}</option>`).join("");
  function users() {
    if (HOST()) return call("users.list").then(l => (l || []).filter(u => u.IsActive !== false).map(u => ({ id: u.UserId, name: u.FullName || u.Username }))).catch(() => []);
    const L = (FH().lsGet && FH().lsGet("fh.users", [{ UserId: 1, Username: "admin", FullName: "مدير النظام" }])) || []; return Promise.resolve(L.map(u => ({ id: u.UserId, name: u.FullName || u.Username })));
  }
  function empDlg(e) {
    const C = cfg(), isNew = !e;
    e = e || { name: "", salary: 0, basis: "", mode: "day", src: "", off: null, offPaid: null, start: today(), active: true, branch: BR() };
    const off = Array.isArray(e.off) ? e.off : C.off;
    users().then(U => {
      const used = new Set(EMP.filter(x => x.uid && x.id !== e.id).map(x => +x.uid));
      const J = jobs(), SH = shifts();
      const body = `<div class="hrx-eg">
        <div class="hrx-ep">${avatar(e.name || "؟", "xl")}<div class="hrx-calc" data-calc></div></div>
        <div class="hrx-ef">
          ${fld("الاسم", `<input data-k="name" value="${esc(e.name)}" placeholder="اسم الموظف أو العامل">`, { req: 1 })}
          <div class="row2">${fld("مستخدم البرنامج", `<select data-k="uid"><option value="0">— بدون (عامل) —</option>${U.map(u => `<option value="${u.id}"${+e.uid === u.id ? " selected" : ""}${used.has(u.id) ? " disabled" : ""}>${esc(u.name)}${used.has(u.id) ? " (مرتبط)" : ""}</option>`).join("")}</select>`, { hint: "اختياري — لقراءة الحضور من سجل الدخول" })}
            ${fld("الوظيفة", `<input data-k="job" list="hrxJobs" value="${esc(e.job || "")}" placeholder="كاشير، عامل مخزن…"><datalist id="hrxJobs">${J.map(j => `<option value="${esc(j)}">`).join("")}</datalist>`)}</div>
          <div class="row2">${fld("الراتب الشهري", `<span class="money"><input data-k="salary" inputmode="decimal" value="${e.salary ? N(e.salary) : ""}" placeholder="30,000"><em>دج</em></span>`, { req: 1 })}
            ${fld("الأجر اليومي يُحسب على", `<select data-k="basis"><option value="">الافتراضي (${esc((BASIS.find(b => b[0] === C.basis) || BASIS[0])[1])})</option>${selO(BASIS, e.basis)}</select>`)}</div>
          <div class="row2">${fld("طريقة الحساب", `<select data-k="mode">${selO(MODE, e.mode || "day")}</select>`)}
            ${fld("الوردية", `<select data-k="shift"><option value="">— بدون —</option>${SH.map(s => `<option value="${esc(s.name)}"${s.name === e.shift ? " selected" : ""}>${esc(s.name)} (${esc(s.from || "08:00")} ← ${esc(s.to || "16:00")})</option>`).join("")}</select>`, { hint: SH.length ? "" : "أضف الورديات من: الخصائص ← صلاحيات المستخدمين ← ورديات العمل" })}</div>
          ${fld("تسجيل الحضور", `<select data-k="src"><option value="">الافتراضي (${esc((SRC.find(s => s[0] === C.src) || SRC[0])[1].split(" —")[0])})</option>${selO(SRC, e.src)}</select>`)}
          ${fld("أيام العطلة الأسبوعية", `<div class="hrx-days" data-days>${DAYS.map((n, i) => `<button type="button" data-wd="${i}" class="${off.includes(i) ? "on" : ""}">${n}</button>`).join("")}</div>`)}
          <label class="hrx-sw"><input type="checkbox" data-k="offPaid"${(e.offPaid == null ? C.offPaid : e.offPaid) ? " checked" : ""}><i></i><span>العطلة الأسبوعية مدفوعة (تُحسب في الأجور)</span></label>
          <div class="row3">${fld("تاريخ بداية العمل", `<input type="date" data-k="start" value="${esc(e.start || "")}">`)}${fld("الفرع", `<select data-k="branch">${selO(BRL(), e.branch || BR())}</select>`)}${fld("الهاتف", `<input data-k="phone" inputmode="tel" value="${esc(e.phone || "")}">`)}</div>
          ${isNew ? "" : `<label class="hrx-sw"><input type="checkbox" data-k="active"${e.active ? " checked" : ""}><i></i><span>نشط — يعمل حالياً</span></label>`}
        </div></div>`;
      dlg({ title: isNew ? "موظف جديد" : "بطاقة الموظف", sub: isNew ? "الراتب الشهري ← أجر يومي يدخل في الأرباح والخسائر كل يوم عمل" : esc(e.name), icon: IC.users, w: 860, body,
        foot: isNew ? "" : `<button type="button" class="hrx-btn dng" data-del>${IC.trash}<span>حذف</span></button>`,
        wire: (q, ov) => {
          const days = new Set(off);
          const paint = () => { const s = num(q('[data-k="salary"]').value), b = q('[data-k="basis"]').value || C.basis, n = b === "month" ? dim(ymOf(today())) : +b, d = n ? s / n : 0, nm = q('[data-k="name"]').value.trim();
            const av = ov.querySelector(".hrx-ep .hrx-av"); av.textContent = (nm || "؟").slice(0, 1); av.style.setProperty("--h", hue(nm));
            const wd = 7 - days.size, mo = q('[data-k="mode"]').value;
            q("[data-calc]").innerHTML = `<div class="eq"><span>${N(s)}</span><i>÷</i><span>${n}</span><i>=</i></div><b>${N(d)} <em>دج</em></b><small>الأجر اليومي${mo === "hours" ? " (يتناسب مع ساعات العمل)" : ""}</small>
              <div class="hrx-mini"><span>أسبوع عمل كامل (${wd} أيام)</span><b>${N(d * wd)} دج</b></div><div class="hrx-mini"><span>يوم غياب واحد</span><b class="hpos">يوفّر ${N(d)} دج</b></div>`; };
          q("[data-days]").addEventListener("click", ev => { const x = ev.target.closest("[data-wd]"); if (!x) return; const i = +x.dataset.wd; days.has(i) ? days.delete(i) : days.add(i); x.classList.toggle("on", days.has(i)); paint(); });
          ov.addEventListener("input", paint); ov.addEventListener("change", paint);
          const sal = q('[data-k="salary"]'); sal.addEventListener("blur", () => { const v = num(sal.value); sal.value = v ? N(v) : ""; });
          const us = q('[data-k="uid"]'), nmI = q('[data-k="name"]'); us.addEventListener("change", () => { const u = U.find(x => x.id === +us.value); if (u && !nmI.value.trim()) nmI.value = u.name; if (+us.value && !q('[data-k="src"]').value) q('[data-k="src"]').value = "login"; paint(); });
          const del = ov.querySelector("[data-del]"); if (del) del.onclick = () => { const has = PAYS.some(p => p.eid === e.id); if (has) { T("للموظف حركات صرف — اجعله «غير نشط» بدل الحذف", "w"); return; }
            confirmDlg("حذف الموظف", `حذف «${esc(e.name)}» نهائياً؟<br><small>أيام عمله السابقة لن تُحسب بعد الآن في الأرباح والخسائر. للاحتفاظ بالتاريخ اجعله «غير نشط».</small>`, "حذف", () => DB().del(KE, e.id).then(() => { LOADED = 0; T("تم حذف الموظف", "s"); return load(true); }).then(() => { draw(); syncMonth(ymOf(today())); })); };
          paint(); ov.__days = days;
        },
        onOk: (q, btn) => {
          const v = k => q(`[data-k="${k}"]`), name = v("name").value.trim(), sal = num(v("salary").value);
          if (!name) { v("name").classList.add("err"); v("name").focus(); T("اكتب اسم الموظف", "w"); return false; }
          if (!(sal > 0)) { v("salary").classList.add("err"); v("salary").focus(); T("اكتب الراتب الشهري", "w"); return false; }
          if (EMP.some(x => x.name === name && x.id !== e.id)) { v("name").classList.add("err"); T("يوجد موظف بنفس الاسم", "w"); return false; }
          const days = [...btn.closest(".hrx-ov").__days].sort();
          const act = isNew ? true : v("active").checked;
          const row = { id: e.id || 0, no: e.no || "", name, active: act, uid: +v("uid").value || 0, job: v("job").value.trim(), salary: sal, basis: v("basis").value, mode: v("mode").value, shift: v("shift").value, src: v("src").value,
            off: JSON.stringify(days) === JSON.stringify(C.off.slice().sort()) && isNew ? null : days, offPaid: v("offPaid").checked === !!C.offPaid && isNew ? null : v("offPaid").checked, start: v("start").value, branch: v("branch").value, phone: v("phone").value.trim(),
            end: act ? "" : (e.end || today()), notes: e.notes || "" };
          return saveEmp(row).then(() => load(true)).then(() => { snd("save"); T("✔ تم حفظ «" + name + "» — أجره اليومي " + N(daily(normEmp({ data: row }), today())) + " دج", "s"); draw(); syncMonth(ymOf(today())); });
        } });
    });
  }
  function treasuries() { const AC = A(); return AC ? AC.accounts("tr", true).then(l => (l || []).filter(t => t.active !== false)).catch(() => []) : Promise.resolve([]); }
  function payDlg(e) {
    if (!e) return;
    const ym = S.ym, from = ym + "-01", to = monthEnd(ym), g = calc(from, to, { eid: e.id }).emps[0] || { amt: 0 }, rem = Math.max(0, r2(g.amt - paidOf(e.id, from, to)));
    treasuries().then(TR => {
      if (!TR.length) { T("لا توجد خزينة — أضفها من الفهرس ← طرق الدفع ← الخزينة", "w"); return; }
      const C = cfg();
      dlg({ title: "صرف للموظف", sub: esc(e.name) + " — " + monthName(ym), icon: IC.cash, w: 560,
        body: `<div class="hrx-pyh">${avatar(e.name, "lg")}<div><small>الباقي من ${monthName(ym)}</small><b>${N(rem)} <em>دج</em></b><small>المستحق ${N(g.amt)} · المدفوع ${N(paidOf(e.id, from, to))}</small></div></div>
          <div class="hrx-tyseg" data-ty><button type="button" data-v="pay" class="on">${IC.cash} صرف راتب</button><button type="button" data-v="adv">${IC.bolt} سلفة</button></div>
          <div class="row2">${fld("المبلغ", `<span class="money"><input data-k="amt" inputmode="decimal" value="${rem ? N(rem) : ""}"><em>دج</em></span>`, { req: 1 })}${fld("التاريخ", `<input type="date" data-k="date" value="${minS(today(), to)}" max="${today()}">`)}</div>
          ${fld("من الخزينة", `<select data-k="tr">${TR.map(t => `<option value="${t.id}">${esc(t.name)} — رصيد ${N(t.bal)} دج</option>`).join("")}</select>`, { req: 1 })}
          ${fld("ملاحظات", `<input data-k="note" placeholder="اختياري">`)}
          <div class="hrx-je">${IC.tree}<span>قيد آلي: <b>مدين</b> ${esc(C.accLia)} المرتبات المستحقة ← <b>دائن</b> الخزينة — يُنقص رصيد الخزينة ويظهر في حركتها.</span></div>`,
        ok: "صرف",
        wire: (q) => { const s = q("[data-ty]"); s.addEventListener("click", ev => { const b = ev.target.closest("[data-v]"); if (!b) return; s.querySelectorAll("button").forEach(x => x.classList.toggle("on", x === b)); }); },
        onOk: q => {
          const amt = num(q('[data-k="amt"]').value); if (!(amt > 0)) { q('[data-k="amt"]').classList.add("err"); T("اكتب المبلغ", "w"); return false; }
          const tr = TR.find(t => String(t.id) === q('[data-k="tr"]').value), type = q("[data-ty] .on").dataset.v, date = q('[data-k="date"]').value || today();
          if (tr && HOST() && +tr.bal < amt) { T("رصيد «" + tr.name + "» (" + N(tr.bal) + " دج) لا يكفي لصرف " + N(amt) + " دج", "w"); return false; }
          return addPay({ type, amt, date, tr, note: q('[data-k="note"]').value.trim() }, e).then(() => { snd("save"); T("✔ تم " + (type === "adv" ? "صرف سلفة" : "صرف الراتب") + " " + N(amt) + " دج لـ «" + e.name + "»", "s"); draw(); });
        } });
    });
  }
  function adjDlg(e) {
    if (!e) return;
    dlg({ title: "مكافأة أو خصم", sub: esc(e.name), icon: IC.gift, w: 500,
      body: `<div class="hrx-tyseg" data-ty><button type="button" data-v="bonus" class="on">${IC.gift} مكافأة</button><button type="button" data-v="ded">${IC.minus} خصم / جزاء</button></div>
        <div class="row2">${fld("المبلغ", `<span class="money"><input data-k="amt" inputmode="decimal"><em>دج</em></span>`, { req: 1 })}${fld("التاريخ", `<input type="date" data-k="date" value="${minS(today(), monthEnd(S.ym))}" max="${today()}">`)}</div>
        ${fld("السبب", `<input data-k="note" placeholder="مثال: ساعات إضافية، تأخر متكرر…">`)}
        <div class="hrx-je">${IC.info}<span>المكافأة تزيد أجور ذلك اليوم في الأرباح والخسائر، والخصم ينقصها — وتدخل في قيد استحقاق الشهر.</span></div>`,
      wire: q => { const s = q("[data-ty]"); s.addEventListener("click", ev => { const b = ev.target.closest("[data-v]"); if (!b) return; s.querySelectorAll("button").forEach(x => x.classList.toggle("on", x === b)); }); },
      onOk: q => { const amt = num(q('[data-k="amt"]').value); if (!(amt > 0)) { q('[data-k="amt"]').classList.add("err"); T("اكتب المبلغ", "w"); return false; }
        const type = q("[data-ty] .on").dataset.v;
        return addPay({ type, amt, date: q('[data-k="date"]').value || today(), note: q('[data-k="note"]').value.trim() }, e).then(() => { snd("save"); T("✔ تم تسجيل " + (type === "bonus" ? "المكافأة" : "الخصم"), "s"); draw(); }); } });
  }
  function setDlg() {
    const C = cfg();
    accs().then(ac => {
      const t = ac.tree, leaves = pre => t ? t.rows.filter(r => !r.kids.length && String(r.no).startsWith(pre)).map(r => [r.no, r.no + " — " + r.name]) : [];
      const j = C.je[ymOf(today())];
      dlg({ title: "إعدادات الرواتب", sub: "طريقة حساب الأجر اليومي والربط مع شجرة الحسابات", icon: IC.gear, w: 640,
        body: `<div class="row2">${fld("الأجر اليومي = الراتب الشهري ÷", `<select data-k="basis">${selO(BASIS, C.basis)}</select>`, { hint: "مثال: 30,000 ÷ 30 = 1,000 دج في اليوم" })}${fld("تسجيل الحضور الافتراضي", `<select data-k="src">${selO(SRC, C.src)}</select>`)}</div>
          ${fld("العطلة الأسبوعية الافتراضية", `<div class="hrx-days" data-days>${DAYS.map((n, i) => `<button type="button" data-wd="${i}" class="${C.off.includes(i) ? "on" : ""}">${n}</button>`).join("")}</div>`)}
          <label class="hrx-sw"><input type="checkbox" data-k="offPaid"${C.offPaid ? " checked" : ""}><i></i><span>العطلة الأسبوعية مدفوعة</span></label>
          <label class="hrx-sw"><input type="checkbox" data-k="dedupe"${C.dedupe !== false ? " checked" : ""}><i></i><span>منع الازدواج: مصروفات «الرواتب/الأجور» المسجّلة يدوياً لا تُحسب مرتين في قائمة الدخل</span></label>
          <div class="hrx-sec">${IC.tree}<b>شجرة الحسابات</b></div>
          <label class="hrx-sw"><input type="checkbox" data-k="post"${C.post !== false ? " checked" : ""}><i></i><span>ترحيل استحقاق الأجور آلياً (قيد واحد لكل شهر يتحدّث مع الحضور)</span></label>
          <div class="row2">${fld("حساب مصروف الأجور (مدين)", `<select data-k="accExp">${selO(leaves("3").length ? leaves("3") : [[C.accExp, C.accExp]], C.accExp)}</select>`)}${fld("حساب المرتبات المستحقة (دائن)", `<select data-k="accLia">${selO(leaves("2").length ? leaves("2") : [[C.accLia, C.accLia]], C.accLia)}</select>`)}</div>
          <div class="hrx-je">${IC.info}<span>${j ? `قيد ${monthName(ymOf(today()))}: رقم <b>${esc(j.no)}</b> بمبلغ <b>${N(j.amt)}</b> دج.` : "لم يُرحَّل قيد لهذا الشهر بعد."} صرف الراتب/السلفة = مدين المرتبات المستحقة / دائن الخزينة.</span></div>`,
        wire: (q, ov) => { const days = new Set(C.off); q("[data-days]").addEventListener("click", ev => { const x = ev.target.closest("[data-wd]"); if (!x) return; const i = +x.dataset.wd; days.has(i) ? days.delete(i) : days.add(i); x.classList.toggle("on", days.has(i)); }); ov.__days = days; },
        onOk: (q, btn) => { const c = cfg(), v = k => q(`[data-k="${k}"]`);
          const accChanged = c.accExp !== v("accExp").value || c.accLia !== v("accLia").value;
          Object.assign(c, { basis: v("basis").value, src: v("src").value, off: [...btn.closest(".hrx-ov").__days].sort(), offPaid: v("offPaid").checked, dedupe: v("dedupe").checked, post: v("post").checked, accExp: v("accExp").value, accLia: v("accLia").value });
          const fixOld = accChanged ? Promise.all(Object.keys(c.je).map(ym => { const old = c.je[ym]; return A().delDoc("je", old.id).catch(() => { }).then(() => { delete c.je[ym]; }); })) : Promise.resolve();
          return fixOld.then(() => putCfg(c)).then(() => { LOADED = 0; return load(true); }).then(() => { T("✔ تم حفظ إعدادات الرواتب", "s"); draw(); return syncMonth(ymOf(today())); }).then(() => paintPostChip()); } });
    });
  }

  /* ================= الطباعة (نافذة ANOUER) ================= */
  function printPay() {
    const R = window.ANOUER_REPORTS; if (!R || !R.docTab) { T("التقارير غير محمّلة", "w"); return; }
    const rows = payRows(S.ym).map(x => ({ name: x.e.name, job: x.e.job || "", sal: r2(x.e.salary), days: x.g.days + (x.g.half ? x.g.half / 2 : 0) + x.g.leave, rate: r2(daily(x.e, S.ym + "-01")), work: x.g.work, bonus: x.g.bonus, ded: x.g.ded, amt: x.g.amt, paid: x.paid, rem: x.rem, sig: "" }));
    R.docTab("كشف رواتب " + monthName(S.ym), { chips: [["الشهر", monthName(S.ym)], ["الأجر اليومي", "حسب أيام العمل الفعلية"]], land: true,
      cols: [{ t: "الموظف", k: "name", w: 40, cls: "l" }, { t: "الوظيفة", k: "job", w: 22 }, { t: "الراتب", k: "sal", w: 20, n: 1 }, { t: "الأيام", k: "days", w: 12, n: 1, sum: 1 }, { t: "اليومي", k: "rate", w: 16, n: 1 }, { t: "المستحق", k: "work", w: 20, n: 1, sum: 1 }, { t: "مكافآت", k: "bonus", w: 16, n: 1, sum: 1 }, { t: "خصومات", k: "ded", w: 16, n: 1, sum: 1 }, { t: "الصافي", k: "amt", w: 20, n: 1, sum: 1 }, { t: "المدفوع", k: "paid", w: 20, n: 1, sum: 1 }, { t: "الباقي", k: "rem", w: 20, n: 1, sum: 1 }, { t: "التوقيع", k: "sig", w: 22, nosort: 1 }], rows });
  }
  function printRep() {
    const R = window.ANOUER_REPORTS; if (!R || !R.docTab || !REP) return;
    R.docTab("الأجور والأرباح اليومية", { chips: [["من", dmy(REP.from)], ["إلى", dmy(REP.to)]],
      cols: [{ t: "اليوم", k: "day", w: 40, cls: "l" }, { t: "الحاضرون", k: "pres", w: 14, n: 1 }, { t: "مجمل الربح", k: "gp", w: 24, n: 1, sum: 1 }, { t: "الأجور", k: "lab", w: 24, n: 1, sum: 1 }, { t: "الربح بعد الأجور", k: "net", w: 26, n: 1, sum: 1 }],
      rows: REP.days.map(x => ({ day: nice(x.d), pres: x.pres, gp: x.gp, lab: x.lab, net: x.net, _cls: x.net < 0 ? "neg" : "" })) });
  }

  window.ANOUER_HR = { open, cost, licensed, calc: (f, t, o) => ensure().then(() => calc(f, t, o)), load, syncMonth, SAL_RE, cfg, _t: { dayInfo, daily, setDay, flush, EMP: () => EMP, ATT: () => ATT, PAYS: () => PAYS } };
  window.addEventListener("anouer:props", ev => { const k = ev.detail && ev.detail.key; if (k === "usr.shifts" && ROOT && ROOT.isConnected) draw(); });
})();
