/* ANOUER — بطاقة الصنف «إضافة صنف» مطابقة DEXEF ONE أيقونةً أيقونة:
   - أنواع الأصناف الثمانية (مخزون، مجموعة، منتج تام، خدمة، مخزون بسيريال، مخزون بصلاحية، بضاعة أمانة، ملابس و أحذية)
     ولكل نوع وصفه وتبويباته وحقوله (الضمان، الصلاحية، وصف المحتوى: الألوان والمقاسات ...).
   - الفروع/المخازن: قائمة اختيار متعدد (الكل + موافق/إلغاء). المجموعة: شجرة المجموعات + (+) مجموعة جديدة.
   - وحدات القياس: قائمة مجموعات الوحدات + (+) تعريف وحدات، واختيارها يملأ جدول الوحدات.
   - اسم المورد / سياسة التوزيع: قوائم بحث بصف تصفية. حساب الأستاذ وحسابات المبيعات/التكلفة/المرتجع/الضرائب: شجرة الحسابات.
   - الرصيد الافتتاحي: نافذة (الكمية × تكلفة الوحدة = الإجمالي، في تاريخ، حساب الأستاذ) ← مستند «مخزون أول المدة».
   - الحفظ حقيقي في قاعدة البيانات (fm.item.save) لكل حقول البطاقة، والتعديل يقرأها كاملة (fm.item.get).
   - «مخزون بصلاحية» يعمل كصنف مخزون (رصيد افتتاحي وتعقّب مخزون)، وتاريخ الصلاحية للأصناف المخزنية فقط. */
(function () {
  "use strict";
  const H = window.__FH, A = window.__AC, V = document.getElementById("vItem");
  if (!H || !A || !V) { console.warn("item-card: __FH/__AC/vItem غير متاح"); return; }
  const { esc, num, say, DB, Dlg, BR, norm, call, today } = H;
  const G = id => document.getElementById(id), Q = s => V.querySelector(s), QA = s => [...V.querySelectorAll(s)];
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const r2 = v => Math.round((+v || 0) * 100) / 100;
  const fx = v => { v = +v || 0; return String(Math.round(v * 10000) / 10000); };
  const NO_BASE = "10613021705032231010000";
  const PRODS = () => (typeof products !== "undefined" && Array.isArray(products)) ? products : [];
  const T = (m, k) => { try { if (typeof toast === "function") toast(m, k || "i"); else say(m, k); } catch (e) { } };

  /* ------------------------------------------------------------------ أنواع الأصناف (نصوص DEXEF حرفياً) */
  const TY = {
    stock: { t: "مخزون", d: "المنتجات التى يتم شراؤها للبيع ويتم تعقبها فى المخزون، وتضاف على الميزانية العمومية", tabs: ["data", "acc", "props", "extra"], val: 1, open: 1, led: "مخزون البضاعة", root: "12" },
    group: { t: "مجموعة", d: "قد تحتاج للجمع بين أكثر من صنف وتقديمهم للعميل على أنه صنف واحد .. كنوع من انواع العروض", tabs: ["data", "props", "comp", "extra"], val: 1, open: 0, led: "مخزون البضاعة", root: "12" },
    made: { t: "منتج تام", d: "تستخدم فى حالة التصنيع حيث يتم اضافة الاصناف الداخله فى تكوين صنف .. وبالتالى يتم خصمها فى حالة التصنيع من هذا الصنف", tabs: ["data", "acc", "props", "comp", "extra"], val: 1, open: 1, led: "مخزون البضاعة", root: "12" },
    service: { t: "خدمة", d: "هى خدمة تقدم للعميل مقابل مبلغ مالى .. مثال (تكلفة توصيل الطلبات . تكلفة ايجار شيء معين ) وهكذا", tabs: ["data", "acc", "props", "extra"], val: 0, open: 0, led: "", root: "12" },
    serial: { t: "مخزون بسيريال", d: "المنتجات التى يتم شراؤها للبيع ويتم تعقبها فى المخزون. ولكن كل صنف له رقم تسلسلى خاص به", tabs: ["data", "acc", "props", "extra"], val: 1, open: 1, led: "مخزون البضاعة", root: "12", warranty: 1 },
    expiry: { t: "مخزون بصلاحية", d: "المنتجات التى يتم شراؤها للبيع ويتم تعقبها فى المخزون. ولكن كل صنف له تاريخ صلاحية", tabs: ["data", "acc", "props", "extra"], val: 1, open: 1, led: "مخزون البضاعة", root: "12", exp: 1 },
    consign: { t: "بضاعة أمانة", d: "بضاعة مرسلة إلى تاجر ليبيعها لحساب المرسل مقابل نسبة متفق عليها الطرفان", tabs: ["data", "acc", "props", "extra"], val: 0, open: 0, led: "إيرادات محصلة مقدما", root: "21" },
    apparel: { t: "ملابس و أحذية", d: "المنتجات التى تحتوى على ألوان ومقاسات ويتم تعقبها فى المخزون وتضاف على الميزانية العمومية . بحيث ان لكل صنف عدة ألوان وكل لون له أكثر من مقاس", tabs: ["data", "content", "acc", "props", "extra"], val: 1, open: 0, led: "مخزون البضاعة", root: "12" },
    scale: { t: "ميزان", d: "منتجات تُباع بالوزن (خضر، لحوم، حلويات، توابل...) بسعر الكيلوغرام .. اكتب المبلغ الذى يريده العميل فيُحسب الوزن تلقائياً بالغرام أو الكيلوغرام", tabs: ["data", "acc", "props", "extra"], val: 1, open: 1, led: "مخزون البضاعة", root: "12", scale: 1 }
  };
  const TYORDER = ["stock", "group", "made", "service", "serial", "expiry", "consign", "apparel", "scale"];
  const STOCK_KINDS = ["stock", "serial", "expiry", "made", "apparel", "scale"];
  window.__ITYPE_STOCK = STOCK_KINDS;
  const IC_X = "✕", IC_PICK = '<svg viewBox="0 0 16 16" width="14" height="14"><rect x="1.5" y="2" width="13" height="12" rx="1.5" fill="#fff" stroke="#3b6fd4"/><path d="M4 8l2.5 2.5L12 5" fill="none" stroke="#1f9d55" stroke-width="2"/></svg>';
  const LEGACY = { "مخزون": "stock", "خدمة": "service", "تجميع": "group", "تصنيع": "made", "منتج تام": "made" };

  /* ------------------------------------------------------------------ الحالة */
  const S = { id: null, moves: 0, type: "stock", units: [], open: null, brs: null, whs: null, sup: null, dpol: "", colors: [], sizes: [], loadSeq: 0 };
  const blankU = () => ({ bc: "", n: "", u: "", cost: "", price: "", retail: "", q5: "", dB: false, dS: false, act: false });

  /* ------------------------------------------------------------------ بناء الواجهة */
  const sel = G("itType");
  sel.innerHTML = TYORDER.map(k => `<option value="${k}">${TY[k].t}</option>`).join("");
  sel.dataset.own = "1";
  ["itNo", "itName", "itActive"].forEach(id => { const e = G(id); if (e) e.dataset.own = "1"; });
  /* ✓ صحة الرقم (أخضر = متاح، أحمر = مستخدم) */
  const noIc = G("itNoIc"); let okI = noIc && noIc.parentNode ? noIc.parentNode.querySelector(".it-ok") : null;
  if (!okI) { okI = document.createElement("span"); if (noIc && noIc.parentNode) noIc.parentNode.appendChild(okI); }
  okI.classList.add("ic-nok"); okI.id = "itNoOk";

  const tabs = G("itTabs");
  if (!tabs.querySelector('[data-p="content"]')) { const t = document.createElement("div"); t.className = "it-stab hid"; t.dataset.p = "content"; t.textContent = "وصف المحتوى"; tabs.querySelector('[data-p="data"]').after(t); }

  /* --- بيانات الصنف: التصنيف */
  const dataPn = Q('.it-pn[data-p="data"]'), clsSb = dataPn.querySelector(".it-sec .it-sb.it-cols");
  clsSb.innerHTML = `<div>
      <div class="it-r"><label>الفروع</label><span class="ic-cb" data-cb="br" style="width:235px"></span><span class="it-req">*</span></div>
      <div class="it-r"><label>المخازن</label><span class="ic-cb" data-cb="wh" style="width:240px"></span><span class="it-req">*</span></div>
      <div class="it-r"><label>المجموعة</label><span data-tp="grp"></span><span class="it-plus" data-a="grpAdd" title="إضافة مجموعة">+</span></div>
      <div class="it-r"><label>الباركود العالمى</label><input class="it-in" id="itGtin" data-own="1" style="width:185px;text-align:center" autocomplete="off"><span class="it-sel" style="width:55px"><select id="itGtinStd" data-own="1"><option>GS1</option><option>EGS</option></select></span></div>
      <div class="it-r"><label>وحدات القياس</label><span class="ic-lk" data-lk="uom" style="width:220px"></span><span class="it-plus" data-a="uomAdd" title="تعريف وحدات">+</span></div>
    </div><div>
      <div class="it-r"><label>اسم المورد</label><span class="ic-lk" data-lk="sup" style="width:236px"></span></div>
      <div class="it-r"><label>سياسة التوزيع</label><span class="ic-lk" data-lk="dpol" style="width:236px"></span></div>
      <div class="it-r"><label>حساب الاستاذ</label><span data-tp="led"></span></div>
      <div class="it-r" data-row="valm"><label>طريقة تقييم المخزون</label><span class="it-sel fill" style="width:236px"><select id="itValm" data-own="1"><option>الوارد أولاً صادر أولاً</option><option>المتوسط المرجح</option></select></span><span class="it-req">*</span></div>
      <div class="it-r" data-row="homo"><label>التجانس بين الوحدات</label><span class="it-sel fill" style="width:236px"><select id="itHomo" data-own="1" title="غير متجانسة: تُدخل كمية ثانية (وثالثة) مستقلة في الفواتير — مثل الأمتار وعدد الأثواب"><option value="">متجانسة</option><option value="1">غير متجانسة</option></select></span></div>
      <div class="it-r" data-row="eq"><label>معادلة الصنف</label><span class="it-sel fill" style="width:236px"><select id="itEq" data-own="1" title="عند البيع تنفتح حاسبة المعادلة — مثال: الكمية = الطول × العرض"><option value="">بدون معادلة</option></select></span></div>
    </div>`;
  /* --- جدول الوحدات (يُستبدل العنصر لفصل معالجات النسخة القديمة) */
  const oldU = G("itUnits"), UG = oldU.cloneNode(false); oldU.replaceWith(UG); UG.classList.add("ic-ug");
  /* --- الرصيد الافتتاحي + الضمان + خصائص الصلاحية */
  const openSec = G("itOpen").closest(".it-sec");
  openSec.classList.add("ic-opensec"); openSec.dataset.row = "open";
  openSec.querySelector(".it-sb").innerHTML = `<div class="it-r"><span class="ic-open" id="itOpenBox" tabindex="0" role="button" title="الرصيد الافتتاحي"><span class="v"></span><i>⌄</i></span></div>`;
  const xRow = document.createElement("div"); xRow.className = "ic-xrow"; openSec.before(xRow); xRow.appendChild(openSec);
  xRow.insertAdjacentHTML("beforeend", `<div class="it-sec ic-warr" data-row="warr"><div class="it-st">الضمان</div><div class="it-sb"><div class="it-r"><label>مدة الضمان</label><span class="it-num" style="width:90px"><input id="itWarr" data-own="1" value="0" inputmode="numeric"><span class="spn"><b>▲</b><b>▼</b></span></span><span style="margin-right:8px">شهر</span></div></div></div>
    <div class="it-sec ic-expx" data-row="exp"><div class="it-st">خصائص</div><div class="it-sb ic-2c"><div class="it-r"><label>أقل مدة صلاحية يمكن قبولها</label><span class="it-num" style="width:90px"><input id="itMinShelf" data-own="1" value="30" inputmode="numeric"><span class="spn"><b>▲</b><b>▼</b></span></span></div>
      <div class="it-r"><label>طريقة تتبع الصنف ؟</label><span class="it-sel fill" style="width:170px"><select id="itTrack" data-own="1"><option>برقم التشغيلة</option><option>بتاريخ الصلاحية</option><option>برقم التشغيلة و الرقم التسلسلي</option></select></span></div></div></div>`);
  G("itOpen") && (G("itOpen").id = "itOpenOld");

  /* --- وصف المحتوى (ملابس و أحذية) */
  const contPn = document.createElement("div"); contPn.className = "it-pn"; contPn.dataset.p = "content";
  contPn.innerHTML = ["clr", "siz"].map(k => `<div class="it-sec"><div class="it-st">${k === "clr" ? "الالوان" : "المقاسات"}</div><div class="it-sb">
      <div class="ic-ctb"><span class="ic-ch">يرجى إختيار جميع ${k === "clr" ? "الألوان التى يحتويها الصنف" : "المقاسات التى يحتويها كل لون من الصنف"}</span>
        <button type="button" class="ic-cbt" data-a="${k}Pick"><span class="ic-ci">${IC_PICK}</span>${k === "clr" ? "إختيار الالوان" : "إختيار المقاسات"}</button>
        <button type="button" class="ic-cbt" data-a="${k}Def"><b class="ic-gp">+</b>${k === "clr" ? "تعريف لون" : "تعريف المقاس"}</button></div>
      <div class="ic-cg" data-cg="${k}"></div></div></div>`).join("");
  dataPn.after(contPn);

  /* --- الحسابات: حقول الشجرة بدل القوائم الثابتة */
  const rowBy = (pn, lbl) => QA(`.it-pn[data-p="${pn}"] .it-r`).find(r => { const l = r.querySelector("label"); return l && l.textContent.trim() === lbl; });
  function hostIn(pn, lbl, key) { const r = rowBy(pn, lbl); if (!r) return null; const s = r.querySelector(".it-sel"); const h = document.createElement("span"); h.dataset.tp = key; if (s) s.replaceWith(h); else r.appendChild(h); return h; }
  const TP = {};
  const tpDefs = [["acc", "حساب المبيعات", "sale", "4", ["41"], "مبيعات بضائع مشتراة"], ["acc", "تكلفة البضاعة المباعة", "cogs", "3", [], "تكلفة البضاعة المباعة"], ["acc", "مرتجع المبيعات", "ret", "4", ["41"], "مرتجعات مبيعات  (مدين)"],
    ["acc", "حساب الضريبة", "tax", "21", [], ""], ["acc", "حساب ضريبة الخصم", "dtax", "21", [], ""]];
  tpDefs.forEach(([pn, lbl, key, root, hide, def]) => { const h = hostIn(pn, lbl, key); if (h) TP[key] = A.treePicker(h, { key: "itA_" + key, root, hide, value: def }); TP[key] && (TP[key].def = def); });
  /* أرقام بدل القوائم الثابتة: الحد الأدنى/الأقصى/فترة الركود/تكلفة إضافية */
  [["الحد الادنى", "itMin", "10"], ["الحد الأقصى", "itMax", "100"], ["فترة الركود", "itStag", "10"], ["تكلفة إضافية", "itXCost", "0"]].forEach(([lbl, id, v]) => {
    const r = QA(".it-pn .it-r").find(x => { const l = x.querySelector("label"); return l && l.textContent.trim() === lbl; }); if (!r) return;
    const s = r.querySelector(".it-sel"); if (!s) return;
    const w = s.style.width || "120px"; const n = document.createElement("span"); n.className = "it-num"; n.style.width = w;
    n.innerHTML = `<input id="${id}" value="${v}" inputmode="decimal"><span class="spn"><b>▲</b><b>▼</b></span>`; s.replaceWith(n);
  });
  /* الضرائب: «يخضع القيمة المضافة = لا» يعطّل حقول الضريبة (مثل DEXEF) */
  const vatSel = (rowBy("acc", "يخضع القيمة المضافة") || V).querySelector("select");
  /* «كما بالفاتورة» (الافتراضى): الصنف يتبع ضريبة الفاتورة — «نعم»: نسبته الخاصة — «لا»: معفى */
  if (vatSel && ![...vatSel.options].some(o => o.text === "كما بالفاتورة")) { vatSel.insertAdjacentHTML("afterbegin", "<option>كما بالفاتورة</option>"); vatSel.value = "كما بالفاتورة"; }
  const tgSet = (t, on) => { if (!t) return; t.classList.toggle("on", !!on); const em = t.querySelector("em"); if (em) em.textContent = on ? "نعم" : "لا"; };
  const cashTg = () => (rowBy("acc", "يخضع للخصم النقدى") || V).querySelector(".it-tg");
  tgSet(cashTg(), true);   // كل الأصناف تخضع للخصم النقدى افتراضياً (كما كانت الفواتير تعمل)
  if (G("itMax")) G("itMax").value = "0"; if (G("itStag")) G("itStag").value = "0";   // 0 = بلا حد أقصى / فترة الركود العامة من «التنبيهات»
  (rowBy("acc", "الحد الأقصى") || V).title = "0 = بلا حد أقصى"; (rowBy("acc", "فترة الركود") || V).title = "0 = حسب الإعداد العام في مركز التنبيهات";
  if (G("itSerial")) { G("itSerial").readOnly = true; G("itSerial").dataset.own = "1"; G("itSerial").value = "تلقائى"; G("itSerial").title = "الرقم الداخلى للصنف في قاعدة البيانات (يُعطى تلقائياً عند الحفظ)"; }
  function vatUi() { const on = vatSel && vatSel.value === "نعم"; (rowBy("acc", "سعر الصنف يشمل الضريبة ؟") || V).classList && rowBy("acc", "سعر الصنف يشمل الضريبة ؟").classList.toggle("ic-dis", !!vatSel && vatSel.value === "لا"); const rows = [rowBy("acc", "حساب الضريبة")]; const rr = QA('.it-pn[data-p="acc"] .it-r').filter(r => (r.querySelector("label") || {}).textContent === "نسبة الضريبة"); rows.push(rr[0]); rows.forEach(r => r && r.classList.toggle("ic-dis", !on)); }
  if (vatSel) vatSel.addEventListener("change", vatUi);
  const dtSel = (rowBy("acc", "يخضع لضريبة الخصم") || V).querySelector("select");
  function dtUi() { const on = dtSel && dtSel.value === "نعم"; const rr = QA('.it-pn[data-p="acc"] .it-r').filter(r => (r.querySelector("label") || {}).textContent === "نسبة الضريبة"); [rowBy("acc", "حساب ضريبة الخصم"), rr[1]].forEach(r => r && r.classList.toggle("ic-dis", !on)); }
  if (dtSel) dtSel.addEventListener("change", dtUi);
  /* الخصائص: الشركة المنتجة / المادة الفعالة: قوائم بحث + (+) */
  [["الشركة المنتجة", "mk"], ["المادة الفعالة", "actv"]].forEach(([lbl, k]) => {
    const r = rowBy("props", lbl); if (!r) return; r.querySelectorAll("span,input").forEach(x => x.remove());
    r.insertAdjacentHTML("beforeend", `<span class="ic-lk" data-lk="${k}" style="width:236px"></span><span class="it-plus" data-a="${k}Add" title="إضافة">+</span>`);
  });

  /* ------------------------------------------------------------------ أدوات: قائمة بحث (Lookup) */
  function lookup(host, o) {
    host.innerHTML = `<span class="ic-lkb"><button type="button" class="dd" tabindex="-1">${A.I && A.I.dd ? A.I.dd : "▾"}</button><input autocomplete="off" spellcheck="false"></span>`;
    const inp = host.querySelector("input"), dd = host.querySelector(".dd");
    const L = { value: o.value || null }; let pop = null, rows = [], fi = 0, AFS = {};
    const show = v => { inp.value = v ? v.name || "" : ""; };
    show(L.value);
    function close() { if (pop) { pop.remove(); pop = null; document.removeEventListener("mousedown", out, true); } }
    function out(e) { if (pop && !pop.contains(e.target) && !host.contains(e.target)) { close(); show(L.value); } }
    function draw() {
      if (!pop) return;
      const cols = o.cols, q = inp.value.trim();
      const list = rows.filter(r => (!q || q === (L.value && L.value.name) || norm(r.name + " " + (r.code || "")).includes(norm(q))) && cols.every((c, i) => !window.AF || AF.test(r[c.k], AFS[i])));
      pop.querySelector(".b").innerHTML = list.map((r, i) => `<div class="r${i === fi ? " f" : ""}${L.value && String(L.value.id) === String(r.id) ? " s" : ""}" data-id="${esc(r.id)}" style="grid-template-columns:${cols.map(c => c.w || "1fr").join(" ")}">${cols.map(c => `<span>${esc(r[c.k] == null ? "" : r[c.k])}</span>`).join("")}</div>`).join("") || '<div class="e">لا توجد بيانات</div>';
      pop._list = list;
    }
    function open() {
      if (pop) return;
      Promise.resolve(o.load()).then(l => {
        rows = l || []; if (pop) return;
        pop = document.createElement("div"); pop.className = "ic-lpop"; const r = host.getBoundingClientRect(), w = Math.max(o.width || 0, r.width + 40);
        pop.style.width = w + "px"; pop.style.left = Math.max(4, r.right - w) + "px"; pop.style.top = (r.bottom + 1) + "px";
        const tpl = o.cols.map(c => c.w || "1fr").join(" ");
        pop.innerHTML = `<div class="h" style="grid-template-columns:${tpl}">${o.cols.map(c => `<span>${esc(c.t)}</span>`).join("")}</div>${window.AF ? `<div class="af" style="grid-template-columns:${tpl}">${o.cols.map((c, i) => AF.cell(i, c.num ? "num" : "txt", AFS[i])).join("")}</div>` : ""}<div class="b"></div><div class="ft"><button type="button" class="cx" title="مسح">${IC_X}</button></div>`;
        document.body.appendChild(pop);
        if (window.AF) AF.wire(pop.querySelector(".af"), AFS, () => { fi = 0; draw(); }, "iclk." + o.key);
        fi = Math.max(0, rows.findIndex(x => L.value && String(x.id) === String(L.value.id)));
        draw();
        const tp = pop.getBoundingClientRect(); if (tp.bottom > innerHeight - 4) pop.style.top = Math.max(4, r.top - tp.height - 1) + "px";
        pop.addEventListener("mousedown", e => { if (!e.target.closest(".af-c,input")) e.preventDefault(); });
        pop.addEventListener("click", e => { if (e.target.closest(".cx")) { pick(null); return; } const d = e.target.closest(".r[data-id]"); if (d) pick((pop._list || []).find(x => String(x.id) === d.dataset.id)); });
        pop.addEventListener("mousemove", e => { const d = e.target.closest(".r[data-id]"); if (!d) return; const i = [...pop.querySelectorAll(".r[data-id]")].indexOf(d); if (i !== fi) { fi = i; pop.querySelectorAll(".r[data-id]").forEach((x, j) => x.classList.toggle("f", j === fi)); } });
        setTimeout(() => document.addEventListener("mousedown", out, true), 0);
      });
    }
    function pick(r) { L.value = r ? { id: r.id, name: r.name, code: r.code } : null; show(L.value); close(); if (o.onPick) o.onPick(r || null); inp.dispatchEvent(new Event("change", { bubbles: true })); }
    dd.addEventListener("mousedown", e => e.preventDefault());
    dd.addEventListener("click", () => { if (pop) close(); else { open(); } inp.focus(); });
    inp.addEventListener("input", () => { if (!pop) open(); else { fi = 0; draw(); } });
    inp.addEventListener("keydown", e => {
      if (!pop) { if (e.key === "ArrowDown" || e.key === "F4") { e.preventDefault(); open(); } return; }
      const n = (pop._list || []).length; const rs = () => pop.querySelectorAll(".r[data-id]");
      if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); fi = Math.max(0, Math.min(n - 1, fi + (e.key === "ArrowDown" ? 1 : -1))); rs().forEach((x, j) => x.classList.toggle("f", j === fi)); const c = rs()[fi]; if (c) c.scrollIntoView({ block: "nearest" }); }
      else if (e.key === "Enter") { e.preventDefault(); const r = (pop._list || [])[fi]; if (r) pick(r); }
      else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); show(L.value); }
    });
    inp.addEventListener("blur", () => setTimeout(() => { if (pop && !pop.contains(document.activeElement) && document.activeElement !== inp) { close(); show(L.value); } }, 160));
    return Object.assign(L, { set(v) { L.value = v || null; show(L.value); }, get: () => L.value, input: inp, refresh() { rows = []; } });
  }

  /* ------------------------------------------------------------------ أدوات: اختيار متعدد (الفروع / المخازن) */
  function checkCombo(host, o) {
    host.innerHTML = `<span class="ic-cbb" tabindex="0"><span class="t"></span><button type="button" class="dd" tabindex="-1">▾</button></span>`;
    const box = host.firstElementChild, tx = box.querySelector(".t");
    const C = { ids: null, list: [] }; let pop = null;
    const names = () => { const l = C.list; if (!l.length) return ""; const on = C.ids == null ? l : l.filter(x => C.ids.includes(String(x.id))); return on.map(x => x.name).join("، "); };
    const paint = () => { tx.textContent = names(); tx.title = tx.textContent; };
    function load() { return Promise.resolve(o.load()).then(l => { C.list = l || []; paint(); return C.list; }); }
    function close() { if (pop) { pop.remove(); pop = null; document.removeEventListener("mousedown", out, true); } }
    function out(e) { if (pop && !pop.contains(e.target) && !host.contains(e.target)) close(); }
    function open() {
      if (pop) { close(); return; }
      load().then(l => {
        const cur = C.ids == null ? l.map(x => String(x.id)) : C.ids.slice();
        pop = document.createElement("div"); pop.className = "ic-cpop"; const r = box.getBoundingClientRect();
        pop.style.width = Math.max(200, r.width) + "px"; pop.style.left = Math.max(4, r.right - Math.max(200, r.width)) + "px"; pop.style.top = (r.bottom + 1) + "px";
        pop.innerHTML = `<label class="ci all"><input type="checkbox" data-all="1"><span>${esc(o.allText || "(Select All)")}</span></label>${l.map(x => `<label class="ci"><input type="checkbox" data-id="${esc(x.id)}"${cur.includes(String(x.id)) ? " checked" : ""}><span>${esc(x.name)}</span></label>`).join("")}<div class="bt"><button type="button" data-a="cancel">Cancel</button><button type="button" class="ok" data-a="ok">OK</button></div>`;
        document.body.appendChild(pop);
        const all = pop.querySelector("[data-all]"), cbs = [...pop.querySelectorAll("[data-id]")];
        const syncAll = () => { const n = cbs.filter(c => c.checked).length; all.checked = n === cbs.length; all.indeterminate = n > 0 && n < cbs.length; };
        syncAll();
        all.addEventListener("change", () => { cbs.forEach(c => c.checked = all.checked); });
        cbs.forEach(c => c.addEventListener("change", syncAll));
        pop.addEventListener("click", e => { const a = e.target.dataset.a; if (a === "cancel") close(); else if (a === "ok") { const on = cbs.filter(c => c.checked).map(c => c.dataset.id); if (!on.length) { say("اختر واحداً على الأقل", "w"); return; } C.ids = on.length === cbs.length ? null : on; paint(); close(); if (o.onChange) o.onChange(C.ids); } });
        pop.addEventListener("keydown", e => { if (e.key === "Escape") { e.stopPropagation(); close(); } });
        setTimeout(() => document.addEventListener("mousedown", out, true), 0);
      });
    }
    box.addEventListener("click", open);
    box.addEventListener("keydown", e => { if (e.key === "F4" || (e.key === "ArrowDown" && e.altKey) || e.key === " ") { e.preventDefault(); open(); } });
    load();
    return Object.assign(C, { set(ids) { C.ids = ids && ids.length ? ids.map(String) : null; paint(); }, get: () => C.ids, load, first: () => { const l = C.list; const on = C.ids == null ? l : l.filter(x => C.ids.includes(String(x.id))); return on[0] || null; } });
  }

  /* ------------------------------------------------------------------ مصادر البيانات */
  const whList = () => DB.list("wh").then(l => (l || []).filter(x => x.active !== false).sort((a, b) => (a.no === "1" ? -1 : b.no === "1" ? 1 : (+a.no || 0) - (+b.no || 0))).map(x => ({ id: x.id, name: x.name }))).catch(() => [{ id: 0, name: "المخزن الرئيسي" }]).then(l => l.length ? l : [{ id: 0, name: "المخزن الرئيسي" }]);
  const brList = () => Promise.resolve((BR && BR.length ? BR : ["الفرع الرئيسي"]).map(b => ({ id: b, name: b })));
  function grpTree() {
    return DB.list("igrp").catch(() => []).then(l => {
      let rows = (l || []).map(x => ({ id: x.id, no: String(x.id), name: String(x.name || ""), pid: x.parentId || null, d: {} }));
      const cats = Array.from(new Set(PRODS().map(p => p.cat).filter(Boolean)));
      cats.forEach(c => { if (!rows.some(r => r.name === c)) rows.push({ id: "c:" + c, no: "c:" + c, name: c, pid: null, d: {} }); });
      const byId = {}, byNo = {}; rows.forEach(r => { byId[r.id] = r; byNo[r.no] = r; r.kids = []; });
      rows.forEach(r => { const p = r.pid != null ? byId[r.pid] : null; r.par = p && p !== r ? p : null; if (r.par) r.par.kids.push(r); });
      const cmp = (a, b) => a.name.localeCompare(b.name, "ar");
      rows.forEach(r => r.kids.sort(cmp));
      return { rows, byNo, roots: rows.filter(r => !r.par).sort(cmp) };
    });
  }
  function supList() {
    const fromMem = () => { try { const l = (window.ANOUER_SUPPLIERS && ANOUER_SUPPLIERS.list && ANOUER_SUPPLIERS.list()) || []; return l.map(s => ({ id: s.id || s.SupplierId, code: s.no || s.code || s.Code || "", name: s.name || s.Name || "" })).filter(s => s.name); } catch (e) { return []; } };
    if (HOST()) return Anouer.call("suppliers.search", { q: "" }).then(l => (l || []).map(s => ({ id: s.SupplierId, code: s.Code || "", name: s.Name || "" }))).catch(fromMem);
    return Promise.resolve(fromMem());
  }
  const catList = k => () => DB.list(k).catch(() => []).then(l => (l || []).filter(x => x.active !== false).map(x => ({ id: x.id, code: x.no, name: x.name, data: x.data || {} })));
  /* مجموعات الوحدات (الفهرس ← وحدات القياس): تُبذر تلقائياً من وحدات الأصناف الحالية */
  /* مجموعات الوحدات (وحدات القياس): كل وحدة موجودة في قاعدة البيانات (المنقولة من DEXEF ONE) تُضاف تلقائياً
     كمجموعة بنفس اسمها (مثل DEXEF: اختيار «كرتونة» يضع سطر كرتونة × 1) — المجموعات المعرّفة يدوياً تبقى كما هي. */
  let UOM_SYNC = null;
  function uomSync() {
    if (UOM_SYNC) return UOM_SYNC;
    UOM_SYNC = Promise.all([DB.list("uom").catch(() => []), loadAllUnits()]).then(([l, names]) => {
      const have = new Set((l || []).map(x => String(x.name || "").trim()));
      let no = (l || []).reduce((m, x) => Math.max(m, parseInt(x.no, 10) || 0), 0);
      const add = names.filter(n => n && !have.has(n)).map(n => ({ no: String(++no), name: n, data: JSON.stringify({ units: [{ code: "1", name: n, factor: 1, cur: "DZD", defSale: true, defBuy: true }] }) }));
      if (!add.length) return l || [];
      return DB.bulk("uom", add).then(() => DB.list("uom", true)).catch(() => l || []);
    }).catch(() => { UOM_SYNC = null; return []; });
    return UOM_SYNC;
  }
  let UOMN = [];   /* أسماء الوحدات داخل مجموعات «وحدات القياس» (حتى المعرّفة بزر + ولم تُستعمل بعد في صنف) */
  function uomList() {
    return uomSync().then(l => { UOMN = Array.from(new Set((l || []).flatMap(x => ((x.data && x.data.units) || []).map(u => u.name).concat([x.name])).map(n => String(n || "").trim()).filter(Boolean))); return l; }).then(l => (l || []).filter(x => x.active !== false).map(x => ({ id: x.id, code: x.no, name: x.name, units: (x.data && x.data.units) || [{ name: x.name, factor: 1, defSale: true, defBuy: true }] })).sort((a, b) => (parseInt(a.code, 10) || 0) - (parseInt(b.code, 10) || 0)));
  }

  /* ------------------------------------------------------------------ تركيب العناصر */
  const CB = { br: checkCombo(Q('[data-cb="br"]'), { load: brList, allText: "(Select All)" }), wh: checkCombo(Q('[data-cb="wh"]'), { load: whList, allText: "(كل المخازن)" }) };
  const GRP = A.treePicker(Q('[data-tp="grp"]'), { key: "itGrp", source: grpTree, pickGroups: true, value: "" });
  GRP.input.id = "itGroup"; GRP.input.style.width = "200px";
  /* صنف جديد + اختيار مجموعة ← يرث إعداداتها (مثل DEXEF) — grp-apply.js */
  GRP.input.addEventListener("change", () => { if (S.id == null) setTimeout(() => grpInherit(GRP.get()), 0); });
  function grpInherit(name) {
    const GA = window.ANOUER_GRP; if (!GA || !name) return;
    GA.cfg(name).then(g => {
      if (!g || S.id != null || GRP.get() !== name) return;
      const pt = GA.patch(g), x = pt.x, done = [];
      if (pt.type && TY[pt.type] && pt.type !== S.type) { applyType(pt.type); done.push(TY[pt.type].t); }
      if (x.valm && G("itValm")) { G("itValm").value = x.valm; done.push("التقييم"); }
      if (x.homo != null && G("itHomo")) G("itHomo").value = x.homo ? "1" : "";
      if (x.supplier) { LK.sup.set(x.supplier); done.push("المورد"); }
      if (x.acc) { Object.keys(x.acc).forEach(k => { if (TP[k]) TP[k].set(x.acc[k]); }); done.push("الحسابات"); }
      if (x.f) { writeFields(x.f); try { vatUi(); dtUi(); } catch (e) { } done.push("الضرائب والخصومات والتنبيهات"); if (x.f["acc|التنبيهات|الحد الادنى|0"] && G("itMin")) G("itMin").value = x.f["acc|التنبيهات|الحد الادنى|0"]; }
      if (x.eq && G("itEq")) { try { window.ANOUER_ITEMEQ ? ANOUER_ITEMEQ.cardFill(G("itEq"), x.eq) : (G("itEq").value = x.eq); } catch (e) { } done.push("ƒ " + x.eq); }
      if (done.length) T("📂 أخذ الصنف إعدادات المجموعة «" + name + "»: " + done.join("، "), "i");
    }).catch(() => { });
  }
  let LED = null;
  function mkLed(root, def) { const h = Q('[data-tp="led"]'); LED = A.treePicker(h, { key: "itLed", root, hide: [], value: def }); LED.input.style.width = "200px"; LED.root = root; }
  mkLed("12", "مخزون البضاعة");
  const LK = {
    uom: lookup(Q('[data-lk="uom"]'), { key: "uom", cols: [{ k: "name", t: "الاسم" }], load: uomList, width: 240, onPick: r => { if (r) applyUom(r); } }),
    sup: lookup(Q('[data-lk="sup"]'), { key: "sup", cols: [{ k: "code", t: "الكود", w: "90px" }, { k: "name", t: "الاسم" }], load: supList, width: 360 }),
    dpol: lookup(Q('[data-lk="dpol"]'), { key: "dpol", cols: [{ k: "name", t: "الاسم" }], load: catList("dpol"), width: 260 })
  };
  ["mk", "actv"].forEach(k => { const h = Q(`[data-lk="${k}"]`); if (h) LK[k] = lookup(h, { key: k, cols: [{ k: "name", t: "الاسم" }], load: catList(k), width: 260 }); });

  /* ------------------------------------------------------------------ جدول الوحدات (مطابق DEXEF ONE)
     - بطاقة جديدة: سطر فارغ واحد فقط.  الكتابة في أي خانة من السطر الفارغ تُنشئ وحدة:
       العدد 1، الأسعار 0، نشط ✓، والباركود = رقم الصنف (إن لم تكتب باركوداً).
     - «الوحدة»: قائمة بحث بكل الوحدات (الاسم) + ✕ مسح.  «ع...»: عدد القطع بأسهم ▲▼.
     - اختيار «وحدات القياس» يستبدل الجدول بوحدات المجموعة (افتراض الشراء/البيع منها).
     - Enter/Tab: الخانة التالية ثم السطر التالي.  ✕: حذف السطر. */
  const UCOLS = [["الباركود", "180px", "bc"], ["رقم الملصق", "84px", "lbl", "lbl"], ["عدد القطع", "56px", "n", "spin"], ["الوحدة", "128px", "u", "lk"], ["سعر الشراء", "72px", "cost", "num"], ["سعر البيع", "75px", "price", "num"], ["التجزئة", "64px", "retail", "num"], ["سعر 5ومافوق", "70px", "q5", "num"], ["افتراض للشراء", "80px", "dB", "c"], ["افتراض للبيع", "78px", "dS", "c"], ["نشط", "56px", "act", "c"], ["", "36px", "x"]];
  const UTPL = UCOLS.map(c => c[1]).join(" ");
  const TXT = ["bc", "lbl", "n", "u", "cost", "price", "retail", "q5"];
  /* كل الوحدات: جدول Units في قاعدة البيانات (المنقول من DEXEF) + وحدات الأصناف */
  let ALLU = null;
  function unitNames() {
    const base = PRODS().flatMap(p => (p._u || []).map(u => u.name)).concat(PRODS().map(p => p.unit));
    return Array.from(new Set((ALLU || []).concat(UOMN, base).map(x => String(x || "").trim()).filter(Boolean))).sort((a, b) => a.localeCompare(b, "ar"));
  }
  function loadAllUnits(force) {
    if (ALLU && !force) return Promise.resolve(unitNames());
    const p = HOST() ? Anouer.call("lookups.get").then(r => ((r && r.units) || []).map(u => u.Name || u.name)).catch(() => []) : Promise.resolve([]);
    return p.then(l => { ALLU = l || []; return unitNames(); });
  }
  const newRow = (k, v) => { const r = { bc: "", lbl: "", n: "1", u: "", cost: "0", price: "0", retail: "0", q5: "0", dB: false, dS: false, act: true }; if (k) r[k] = v; if (k !== "bc" && !r.bc) r.bc = codeNow(); return r; };
  const shown = (r, k) => r[k] == null ? "" : String(r[k]);
  function rowHTML(r, i, blank) {
    return `<div class="it-gr${blank ? " nw" : ""}" data-i="${i}" style="grid-template-columns:${UTPL}">${UCOLS.map(c => {
      const k = c[2];
      if (k === "x") return `<div><span class="del" data-del="${i}" title="${blank ? "مسح" : "حذف السطر"}">✕</span></div>`;
      if (c[3] === "c") return `<div><input type="checkbox" data-k="${k}"${!blank && r[k] ? " checked" : ""}></div>`;
      if (c[3] === "spin") return `<div class="sp"><input type="text" data-k="n" value="${blank ? "" : esc(shown(r, "n"))}" inputmode="decimal" class="n"><span class="spn"><b data-sp="1">▲</b><b data-sp="-1">▼</b></span></div>`;
      if (c[3] === "lk") return `<div class="lk"><input type="text" data-k="u" value="${blank ? "" : esc(shown(r, "u"))}" autocomplete="off"><button type="button" class="dd" data-ulk="${i}" tabindex="-1">⌄</button></div>`;
      return `<div><input type="text" data-k="${k}" value="${blank ? "" : esc(shown(r, k))}"${c[3] === "num" ? ' inputmode="decimal" class="n"' : ""}${k === "bc" ? ' spellcheck="false"' : ""}${k === "lbl" ? ' class="lb" spellcheck="false" autocomplete="off" placeholder="—" title="الرقم الكبير المطبوع على ملصق الكرتونة (مثل 15281) — تكتبه في البيع فيدخل هذه الوحدة مباشرة"' : ""}></div>`;
    }).join("")}</div>`;
  }
  function renderUnits(focus) {
    UG.innerHTML = `<div class="it-gh" style="grid-template-columns:${UTPL}">${UCOLS.map(c => `<div title="${esc(c[0])}">${c[0] === "عدد القطع" ? "ع..." : c[0] === "سعر 5ومافوق" ? "سعر..." : c[0]}</div>`).join("")}</div>`
      + S.units.map((r, i) => rowHTML(r, i, false)).join("") + rowHTML({}, S.units.length, true);
    try { markAuto(); } catch (x) { }
    if (focus) { const el = UG.querySelector(`.it-gr[data-i="${focus.i}"] input[data-k="${focus.k}"]`); if (el) { el.focus(); try { if (focus.pos != null) el.setSelectionRange(focus.pos, focus.pos); else el.select(); } catch (x) { } } }
  }
  /* ---------- أسعار الوحدة الكبرى تلقائياً = سعر الوحدة الصغرى × عدد القطع (الكرتونة 6 × 190 = 1140)
     - تُحسب عند كتابة سعر الشراء/البيع/التجزئة/سعر5 في الوحدة الأساسية (العدد 1) أو عند تغيير عدد القطع.
     - إذا كتبت سعراً خاصاً للكرتونة بيدك يبقى كما هو (خانة «يدوي»)؛ امسحه ليعود الحساب التلقائي. */
  const PK = ["cost", "price", "retail", "q5"];
  const nOf = r => +num(r && r.n) || 1;
  const baseIdx = () => S.units.findIndex(r => nOf(r) === 1);
  function autoCell(j, k, flash) {
    /* ✦ (2026-11-26) يشمل أيضاً وحدة ثانية بالعدد 1 (باركود آخر لنفس القطعة) ← تأخذ سعر القطعة */
    const bi = baseIdx(), b = S.units[bi], r = S.units[j]; if (!b || !r || j === bi || (r.__man && r.__man[k])) return;
    const bv = +num(b[k]) || 0, v = bv ? fx(Math.round(bv * nOf(r) * 100) / 100) : (r[k] && +num(r[k]) ? r[k] : "0");
    if (String(r[k]) === v) return;
    r[k] = v;
    const el = UG.querySelector(`.it-gr[data-i="${j}"] input[data-k="${k}"]`);
    if (el) { el.value = v; el.classList.add("it-auto"); el.title = nOf(r) === 1 ? `نفس سعر القطعة: ${v} — اكتب سعراً آخر لتثبيته` : `محسوب تلقائياً: ${fx(bv)} × ${fx(nOf(r))} = ${v} — اكتب سعراً آخر لتثبيته`; if (flash) { el.classList.remove("it-fl"); void el.offsetWidth; el.classList.add("it-fl"); } }
    if (flash && bv && (k === "price" || k === "cost")) pill(j);
  }
  /* شارة عائمة تشرح الحساب: «⚡ 12 قطعة × 110 = 1,320» — تختفي وحدها */
  const PILLT = {};
  function pill(j) {
    clearTimeout(PILLT[j]); PILLT[j] = setTimeout(() => {
      const g = UG.querySelector(`.it-gr[data-i="${j}"]`), r = S.units[j], b = S.units[baseIdx()]; if (!g || !r || !b) return;
      let p = g.querySelector(".it-pill"); if (!p) { p = document.createElement("span"); p.className = "it-pill"; g.appendChild(p); }
      const n = nOf(r), pr = +num(r.price) || 0, bp = +num(b.price) || 0, bc = +num(b.cost) || 0;
      const f = v => (+v || 0).toLocaleString("en-US", { maximumFractionDigits: 2 });
      p.innerHTML = n === 1 ? `<i>⚡</i>نفس سعر القطعة <b>${f(bp || bc)}</b>` : `<i>⚡</i><b>${f(n)}</b> ${esc(b.u || "قطعة")} × ${f(bp || bc)} = <b>${f(pr || n * bc)}</b>`;
      p.classList.remove("go"); void p.offsetWidth; p.classList.add("go");
      clearTimeout(p.__t); p.__t = setTimeout(() => p.remove(), 2600);
    }, 30);
  }
  /* عدد القطع من اسم الوحدة: «كرتونة 36حبة» ← 36 ، «علبة 12» ← 12 ، «شد x6» ← 6 */
  function nFromName(v) { const m = String(v || "").replace(/[٠-٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d)).match(/(?:^|[^\d.])(\d{1,4})(?:\s*(?:حبة|حبه|حبات|قطعة|قطع|قطعه|pcs|pc|p|x|×|علبة|علب|كيس|اكياس|زجاجة|قارورة))?(?![\d.])(?!\s*(?:(?:لتر|ليتر|كلغ|كغ|كيلو|غرام|جرام|غ|ل|مل|سل|سم|م)(?![\u0621-\u064A])|(?:kg|gr|g|l|ml|cl|cm)\b))/i); const n = m ? +m[1] : 0; return n > 1 && n <= 2000 ? n : 0; }
  function nFromUnit(i) {
    const r = S.units[i]; if (!r || i === baseIdx() || r.__nMan) return;
    const n = nFromName(r.u); if (!n || String(nOf(r)) === String(n)) return;
    r.n = fx(n); r.__nAuto = true;
    const el = UG.querySelector(`.it-gr[data-i="${i}"] input[data-k="n"]`); if (el) { el.value = r.n; el.classList.remove("it-fl"); void el.offsetWidth; el.classList.add("it-fl"); el.title = "عدد القطع من اسم الوحدة «" + r.u + "»"; }
    autoRow(i);
  }
  function autoFrom(k) { S.units.forEach((r, j) => autoCell(j, k, true)); }
  function autoRow(j) { PK.forEach(k => autoCell(j, k, true)); }
  /* عدد القطع في الاسم: البطاقة تحفظ اسم القطعة كما كتبته — الفاتورة والإيصال يعرضان العدد حسب الوحدة (unit-name.js) */
  function markAuto() { const bi = baseIdx(); S.units.forEach((r, j) => PK.forEach(k => { if (j === bi || (r.__man && r.__man[k])) return; const el = UG.querySelector(`.it-gr[data-i="${j}"] input[data-k="${k}"]`); if (el) { el.classList.add("it-auto"); el.title = "يُحسب تلقائياً من سعر الوحدة الصغرى × عدد القطع"; } })); }
  /* إنشاء وحدة من السطر الفارغ عند أول إدخال (مثل DEXEF) */
  function materialize(k, v, pos) { const r = newRow(k, v); S.units.push(r); const i = S.units.length - 1; renderUnits({ i, k, pos }); openPaint(); return i; }
  UG.addEventListener("click", e => {
    const d = e.target.closest("[data-del]");
    if (d) { const i = +d.dataset.del; if (i < S.units.length) { S.units.splice(i, 1); try { window.DelSound && DelSound.play(); } catch (x) { } } renderUnits(); openPaint(); return; }
    const sp = e.target.closest("[data-sp]");
    if (sp) { const g = sp.closest(".it-gr"), i = +g.dataset.i; let r = S.units[i]; if (!r) { materialize("n", "1"); r = S.units[i]; } r.n = fx(Math.max(1, (+num(r.n) || 0) + (+sp.dataset.sp))); g.querySelector('[data-k="n"]').value = r.n; r.__nMan = true; if (!g.classList.contains("nw")) { autoRow(i); return; } renderUnits(); if (i !== baseIdx()) autoRow(i); return; }
    const lb = e.target.closest("[data-ulk]"); if (lb) { const inp = lb.parentNode.querySelector("input"); inp.focus(); uPop(inp); return; }
    const g = e.target.closest(".it-gr"); if (g) UG.querySelectorAll(".it-gr").forEach(x => x.classList.toggle("sel", x === g));
  });
  /* الآلة الحاسبة ▾ على خانات الأسعار (سعر الشراء ، سعر البيع ، التجزئة ، سعر 5ومافوق) — Alt+↓ */
  try {
    if (window.ANOUER_CALC) ANOUER_CALC.attach(UG, { sel: 'input.n[data-k][inputmode="decimal"]:not([data-k="n"])', title: inp => {
      const c = UCOLS.find(x => x[2] === inp.dataset.k), g = inp.closest(".it-gr"), r = g && S.units[+g.dataset.i], nm = (G("itName") && G("itName").value.trim()) || "";
      return (c ? c[0] : "") + (nm ? " — " + nm : "") + (r && r.u ? " (" + r.u + ")" : ""); } });
  } catch (e) { }
  UG.addEventListener("input", e => {
    const t = e.target, g = t.closest(".it-gr"); if (!g || !t.dataset.k) return;
    const i = +g.dataset.i, k = t.dataset.k;
    if (i >= S.units.length) {
      if (t.type === "checkbox") { t.checked = false; return; }
      if (!t.value) return;
      if (k === "u") { const v = t.value, pos = t.selectionStart; const nu = materialize("u", v, pos); if (nu !== baseIdx()) { autoRow(nu); nFromUnit(nu); } const ni = UG.querySelector(`.it-gr[data-i="${S.units.length - 1}"] input[data-k="u"]`); if (ni) uPop(ni); return; }
      { const ni = materialize(k, t.value, t.selectionStart); if (PK.includes(k) && ni !== baseIdx()) { const r0 = S.units[ni]; r0.__man = { [k]: true }; } if (k === "n") S.units[ni].__nMan = true; if (ni !== baseIdx()) autoRow(ni); } return;
    }
    const r = S.units[i];
    if (t.type === "checkbox") { r[k] = t.checked; if ((k === "dB" || k === "dS") && t.checked) { S.units.forEach((x, j) => { if (j !== i) x[k] = false; }); UG.querySelectorAll(`input[data-k="${k}"]`).forEach((c, j) => { if (j !== i) c.checked = false; }); } return; }
    r[k] = t.value; if (k === "bc") r.__auto = false;
    if (k === "u") uPop(t);
    if (PK.includes(k)) {
      if (i === baseIdx()) autoFrom(k);
      else { r.__man = r.__man || {}; r.__man[k] = t.value.trim() !== ""; t.classList.toggle("it-auto", !r.__man[k]); t.title = r.__man[k] ? "سعر يدوي للوحدة — امسحه ليُحسب تلقائياً" : ""; if (!r.__man[k]) autoCell(i, k, true); }
    } else if (k === "n") { r.__nMan = t.value.trim() !== ""; if (nOf(r) === 1 && i === baseIdx()) PK.forEach(autoFrom); else autoRow(i); }
    else if (k === "u") nFromUnit(i);
  });
  /* التنقل: Enter/Tab للخانة التالية، وفي آخر خانة → السطر التالي */
  UG.addEventListener("keydown", e => {
    const t = e.target; if (!t.dataset || !t.dataset.k || t.type === "checkbox") return;
    if (t.dataset.k === "u" && UPOP && ["ArrowDown", "ArrowUp", "Enter", "Escape", "Tab"].includes(e.key)) { if (uKey(e)) return; }
    if (t.dataset.k === "n" && (e.key === "ArrowUp" || e.key === "ArrowDown")) { e.preventDefault(); const g = t.closest(".it-gr"), i = +g.dataset.i; if (!S.units[i]) return; S.units[i].n = fx(Math.max(1, (+num(S.units[i].n) || 0) + (e.key === "ArrowUp" ? 1 : -1))); S.units[i].__nMan = true; t.value = S.units[i].n; autoRow(i); return; }
    if (t.dataset.k === "u" && e.altKey && e.key === "ArrowDown") { e.preventDefault(); uPop(t, true); return; }
    if (e.key !== "Enter" && !(e.key === "Tab" && !e.shiftKey)) return;
    const g = t.closest(".it-gr"), i = +g.dataset.i, j = TXT.indexOf(t.dataset.k);
    if (t.dataset.k === "u" && S.units[i] && t.value.trim()) { const v = t.value.trim(), all = unitNames(); if (!all.includes(v)) { const m = all.find(x => norm(x).includes(norm(v))); if (m) { t.value = m; S.units[i].u = m; } } }
    if (i >= S.units.length && !t.value) { if (e.key === "Tab") return; e.preventDefault(); return; }
    e.preventDefault();
    if (j < TXT.length - 1) { const n = g.querySelector(`input[data-k="${TXT[j + 1]}"]`); if (n) { n.focus(); try { n.select(); } catch (x) { } } }
    else { const n = UG.querySelector(`.it-gr[data-i="${i + 1}"] input[data-k="bc"]`); if (n) n.focus(); }
  });
  UG.addEventListener("focusout", e => { const t = e.target; if (t.dataset && t.dataset.k === "u") setTimeout(() => { if (UPOP && document.activeElement !== t && !UPOP.contains(document.activeElement)) uClose(); }, 150); });
  /* قائمة الوحدات (مثل DEXEF: عنوان «الاسم»، بحث بالكتابة، ✕ مسح) */
  let UPOP = null, UFI = 0, UINP = null;
  function uClose() { if (UPOP) { UPOP.remove(); UPOP = null; UINP = null; } }
  function uCommit(name) {
    const inp = UINP; if (!inp) return; const g = inp.closest(".it-gr"), i = +g.dataset.i;
    if (S.units[i]) { S.units[i].u = name || ""; inp.value = name || ""; nFromUnit(i); }
    uClose(); const n = g.querySelector('input[data-k="cost"]'); if (n && name) { n.focus(); try { n.select(); } catch (x) { } } else inp.focus();
    openPaint();
  }
  function uDraw() {
    if (!UPOP) return; const q = norm(UINP.value || ""), all = unitNames();
    const exact = all.some(x => x === (UINP.value || "").trim());
    const l = all.filter(x => !q || exact || norm(x).includes(q));
    UFI = Math.max(0, Math.min(UFI, l.length - 1));
    UPOP.querySelector(".b").innerHTML = l.map((x, j) => `<div class="r${j === UFI ? " f" : ""}${x === UINP.value ? " s" : ""}" data-u="${esc(x)}">${esc(x)}</div>`).join("") || '<div class="e">لا توجد وحدة بهذا الاسم — ستُضاف كوحدة جديدة</div>';
    UPOP._l = l; const f = UPOP.querySelector(".r.f"); if (f) f.scrollIntoView({ block: "nearest" });
  }
  function uPop(inp, force) {
    if (UPOP && UINP === inp && !force) { UFI = 0; uDraw(); return; }
    uClose(); UINP = inp;
    const build = () => {
      if (UINP !== inp || UPOP) { if (UPOP) uDraw(); return; }
      UPOP = document.createElement("div"); UPOP.className = "ic-upop";
      UPOP.innerHTML = `<div class="h">الاسم</div><div class="b"></div><div class="ft"><button type="button" class="cx" title="مسح">✕</button></div>`;
      document.body.appendChild(UPOP);
      const r = inp.closest("div").getBoundingClientRect(), w = Math.max(240, r.width + 60); UPOP.style.width = w + "px"; UPOP.style.left = Math.max(4, r.right - w) + "px";
      UPOP.style.top = (r.bottom + 1) + "px";
      const all = unitNames(); UFI = Math.max(0, all.indexOf(inp.value)); uDraw();
      const pr = UPOP.getBoundingClientRect(); if (pr.bottom > innerHeight - 4) UPOP.style.top = Math.max(4, r.top - pr.height - 1) + "px";
      UPOP.addEventListener("mousedown", e => e.preventDefault());
      UPOP.addEventListener("click", e => { if (e.target.closest(".cx")) { uCommit(""); return; } const d = e.target.closest("[data-u]"); if (d) uCommit(d.dataset.u); });
    };
    if (ALLU) build(); else loadAllUnits().then(build);
  }
  function uKey(e) {
    const l = UPOP._l || [];
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); UFI = Math.max(0, Math.min(l.length - 1, UFI + (e.key === "ArrowDown" ? 1 : -1))); UPOP.querySelectorAll(".r").forEach((x, j) => x.classList.toggle("f", j === UFI)); const f = UPOP.querySelector(".r.f"); if (f) f.scrollIntoView({ block: "nearest" }); return true; }
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); uClose(); return true; }
    if (e.key === "Enter" || e.key === "Tab") { e.preventDefault(); const v = (UINP.value || "").trim(); const pick = l.includes(v) ? v : (l[UFI] || v); uCommit(pick); return true; }
    return false;
  }
  addEventListener("resize", uClose);
  function applyUom(set) {
    const old = {}; S.units.forEach(u => { old[u.u] = u; });
    const no = codeNow();
    S.units = (set.units || []).map(u => { const o = old[u.name] || {}; return { bc: o.bc || no, n: fx(u.factor || 1), u: u.name, cost: o.cost || "0", price: o.price || "0", retail: o.retail || "0", q5: o.q5 || "0", dB: !!u.defBuy, dS: !!u.defSale, act: true, __auto: !o.bc }; });
    if (S.units.length && !S.units.some(u => u.dS)) S.units[0].dS = true;
    if (S.units.length && !S.units.some(u => u.dB)) S.units[0].dB = true;
    renderUnits(); openPaint();
  }
  const codeNow = () => (G("itNo").value || "").trim();

  /* ------------------------------------------------------------------ الألوان والمقاسات (ملابس و أحذية) */
  function renderCG() {
    const c = Q('[data-cg="clr"]'), z = Q('[data-cg="siz"]');
    c.innerHTML = `<div class="h"><span></span><span>الكود</span><span>الاسم</span><span>الصورة</span><span></span></div>` + S.colors.map((x, i) => `<div class="r"><span>${i + 1}</span><span>${esc(x.code || "")}</span><span>${esc(x.name)}</span><span><i class="sw" style="background:${esc(x.hex || "#fff")}"></i></span><span><b data-rm="clr" data-i="${i}" title="حذف">✕</b></span></div>`).join("") + `<div class="nr" data-a="clrPick">Click here to add a new row</div>`;
    z.innerHTML = `<div class="h z"><span></span><span>الكود</span><span>الاسم</span><span></span></div>` + S.sizes.map((x, i) => `<div class="r z"><span>${i + 1}</span><span>${esc(x.code || "")}</span><span>${esc(x.name)}</span><span><b data-rm="siz" data-i="${i}" title="حذف">✕</b></span></div>`).join("") + `<div class="nr" data-a="sizPick">Click here to add a new row</div>`;
  }
  function pickDlg(k) {
    const isC = k === "clr";
    catList(k)().then(l => {
      const have = new Set((isC ? S.colors : S.sizes).map(x => x.name));
      const D = Dlg({ title: isC ? "إختيار الالوان" : "إختيار المقاسات", w: 430, okText: "موافق", onOk: d => {
        const on = [...d.body.querySelectorAll("[data-pi]:checked")].map(c => l[+c.dataset.pi]);
        const arr = isC ? S.colors : S.sizes; on.forEach(x => { if (!arr.some(y => y.name === x.name)) arr.push({ id: x.id, code: x.code, name: x.name, hex: (x.data || {}).hex || "" }); });
        renderCG(); d.close(); } });
      D.body.innerHTML = `<div class="ic-pk"><div class="ic-pkh">يرجى إختيار ${isC ? "الالوان" : "المقاسات"} المراد إضافتها</div><div class="ic-pkg"><div class="h"><span><input type="checkbox" data-pa="1"></span><span>${isC ? "اللون" : "المقاس"}</span></div>
        <div class="f"><span></span><span><input class="ic-pkq" placeholder="ᴀʙc"></span></div>
        <div class="b">${l.map((x, i) => `<label class="r"><span><input type="checkbox" data-pi="${i}"${have.has(x.name) ? " checked disabled" : ""}></span><span>${isC ? `<i class="sw" style="background:${esc((x.data || {}).hex || "#fff")}"></i>` : ""}${esc(x.name)}</span></label>`).join("") || `<div class="e">لا توجد ${isC ? "ألوان" : "مقاسات"} — استعمل «${isC ? "تعريف لون" : "تعريف المقاس"}»</div>`}</div></div></div>`;
      D.body.querySelector("[data-pa]").addEventListener("change", e => D.body.querySelectorAll("[data-pi]:not(:disabled)").forEach(c => c.checked = e.target.checked));
      D.body.querySelector(".ic-pkq").addEventListener("input", e => { const q = norm(e.target.value); D.body.querySelectorAll(".ic-pkg .b .r").forEach(r => r.style.display = !q || norm(r.textContent).includes(q) ? "" : "none"); });
    });
  }
  function defDlg(k, done) {
    const isC = k === "clr";
    DB.next(k).catch(() => "1").then(no => {
      const D = Dlg({ title: isC ? "الالوان" : "المقاسات", w: 400, onOk: d => {
        const nm = d.body.querySelector("[data-f=name]").value.trim(); if (!nm) { say("الاسم مطلوب", "w"); d.body.querySelector("[data-f=name]").focus(); return; }
        const data = isC ? { hex: d.body.querySelector("[data-f=hex]").value } : {};
        d.busy(1); DB.save(k, { id: 0, no: d.body.querySelector("[data-f=no]").value.trim() || no, name: nm, active: true, data }).then(r => { T("تم حفظ " + (isC ? "اللون" : "المقاس") + ": " + nm, "s"); d.close(); if (done) done({ id: r && r.id, code: no, name: nm, hex: data.hex }); }).catch(e => { d.busy(0); say(e.message || e, "e"); });
      } });
      D.body.innerHTML = `<div class="ic-df"><label>الكود</label><input data-f="no" value="${esc(no)}"><i class="it-req">*</i><label>الاسم</label><input data-f="name"><i class="it-req">*</i>${isC ? '<label>اللون</label><span class="ic-hex"><input type="color" data-f="hex" value="#ffffff"></span><i class="it-req">*</i>' : ""}</div>`;
      setTimeout(() => D.body.querySelector("[data-f=name]").focus(), 30);
    });
  }
  contPn.addEventListener("click", e => {
    const a = e.target.closest("[data-a]"); if (a) { const k = a.dataset.a; if (k === "clrPick" || k === "sizPick") pickDlg(k.slice(0, 3)); else if (k === "clrDef" || k === "sizDef") defDlg(k.slice(0, 3), x => { (k === "clrDef" ? S.colors : S.sizes).push(x); renderCG(); }); return; }
    const rm = e.target.closest("[data-rm]"); if (rm) { (rm.dataset.rm === "clr" ? S.colors : S.sizes).splice(+rm.dataset.i, 1); renderCG(); }
  });

  /* ------------------------------------------------------------------ تعريف مجموعة وحدات (+) */
  function uomDlg() {
    const rows = [{ code: "1", name: "", factor: "1", cur: "DZD", defSale: true, defBuy: true }];
    const D = Dlg({ title: "الوحدات", w: 620, onOk: d => {
      const nm = d.body.querySelector("[data-f=name]").value.trim(); if (!nm) { say("الاسم مطلوب", "w"); d.body.querySelector("[data-f=name]").focus(); return; }
      const us = rows.filter(r => r.name.trim()).map(r => ({ code: r.code, name: r.name.trim(), factor: +num(r.factor) || 1, cur: r.cur || "DZD", defSale: !!r.defSale, defBuy: !!r.defBuy }));
      if (!us.length) { say("أضف وحدة واحدة على الأقل", "w"); return; }
      d.busy(1); DB.next("uom").catch(() => "").then(no => DB.save("uom", { id: 0, no: no || String(Date.now() % 100000), name: nm, active: true, data: { units: us } })).then(r => { T("تم حفظ الوحدات: " + nm, "s"); d.close(); UOM_SYNC = null; ALLU = null; LK.uom.refresh(); const set = { id: r && r.id, name: nm, units: us }; LK.uom.set(set); applyUom(set); }).catch(e => { d.busy(0); say(e.message || e, "e"); });
    } });
    /* اقتراحات خانة «الاسم»: كل الوحدات المعروفة (قاعدة البيانات + مجموعات وحدات القياس + الأصناف) */
    uomList().catch(() => []).then(() => { let dl = document.getElementById("icUnits"); if (!dl) { dl = document.createElement("datalist"); dl.id = "icUnits"; document.body.appendChild(dl); } dl.innerHTML = unitNames().map(n => `<option value="${esc(n)}">`).join(""); });
    const draw = () => { D.body.querySelector(".b").innerHTML = rows.map((r, i) => `<div class="r" data-i="${i}"><span>${i + 1}</span><input data-c="code" value="${esc(r.code)}"><input data-c="name" value="${esc(r.name)}" list="icUnits"><input data-c="factor" class="n" value="${esc(r.factor)}"><input data-c="cur" value="${esc(r.cur)}"><span><input type="checkbox" data-c="defSale"${r.defSale ? " checked" : ""}></span><span><input type="checkbox" data-c="defBuy"${r.defBuy ? " checked" : ""}></span><b data-x="${i}">✕</b></div>`).join("") + `<div class="nr">Click here to add a new row</div>`; };
    D.body.innerHTML = `<div class="ic-ud"><div class="ic-df"><label>الاسم</label><input data-f="name"><i class="it-req">*</i></div><div class="ic-ug2"><div class="h"><span></span><span>الكود</span><span>الاسم</span><span>عدد القطع</span><span>العملة</span><span>إفتراض البيع</span><span>إفتراض الشراء</span><span></span></div><div class="b"></div></div></div>`;
    draw();
    const b = D.body.querySelector(".b");
    b.addEventListener("input", e => { const r = e.target.closest(".r"); if (!r) return; const x = rows[+r.dataset.i], c = e.target.dataset.c; x[c] = e.target.type === "checkbox" ? e.target.checked : e.target.value; if ((c === "defSale" || c === "defBuy") && e.target.checked) { rows.forEach(y => { if (y !== x) y[c] = false; }); draw(); } });
    b.addEventListener("click", e => { const x = e.target.closest("[data-x]"); if (x) { rows.splice(+x.dataset.x, 1); if (!rows.length) rows.push({ code: "1", name: "", factor: "1", cur: "DZD" }); draw(); return; } if (e.target.closest(".nr")) { rows.push({ code: String(rows.length + 1), name: "", factor: "1", cur: "DZD" }); draw(); const ins = b.querySelectorAll('[data-c="name"]'); ins[ins.length - 1].focus(); } });
    setTimeout(() => D.body.querySelector("[data-f=name]").focus(), 30);
  }
  function simpleAdd(k, title, lk) {
    DB.next(k).catch(() => "").then(no => {
      const D = Dlg({ title, w: 380, onOk: d => { const nm = d.body.querySelector("[data-f=name]").value.trim(); if (!nm) { say("الاسم مطلوب", "w"); return; } d.busy(1); DB.save(k, { id: 0, no: no || "1", name: nm, active: true, data: {} }).then(r => { T("تم حفظ: " + nm, "s"); d.close(); lk.refresh(); lk.set({ id: r && r.id, name: nm }); }).catch(e => { d.busy(0); say(e.message || e, "e"); }); } });
      D.body.innerHTML = `<div class="ic-df"><label>الكود</label><input value="${esc(no || "")}" readonly><label>الاسم</label><input data-f="name"><i class="it-req">*</i></div>`;
      setTimeout(() => D.body.querySelector("[data-f=name]").focus(), 30);
    });
  }
  V.addEventListener("click", e => {
    const a = e.target.closest("[data-a]"); if (!a || !V.contains(a)) return; const k = a.dataset.a;
    if (k === "grpAdd") { if (window.__FH_GRPDLG) window.__FH_GRPDLG(null, () => { DB.list("igrp", true).then(l => { const last = (l || []).slice().sort((x, y) => y.id - x.id)[0]; if (last) GRP.set(last.name); }); }); else say("شاشة المجموعات غير متاحة", "w"); }
    else if (k === "uomAdd") uomDlg();
    else if (k === "mkAdd" && LK.mk) simpleAdd("mk", "الشركة المنتجة", LK.mk);
    else if (k === "actvAdd" && LK.actv) simpleAdd("actv", "المادة الفعالة", LK.actv);
  });

  /* ------------------------------------------------------------------ الرصيد الافتتاحي (+ دفعات الصلاحية لـ«مخزون بصلاحية») */
  const OB = G("itOpenBox");
  const DAY = 864e5, dDiff = (a, b) => Math.round((new Date(a) - new Date(b)) / DAY);
  const isExp = () => !!TY[S.type].exp;
  /* نافذة الدفعات: «مخزون بصلاحية» (التاريخ إجباري) و«مخزون» (التاريخ ورقم التشغيلة اختياريان) */
  const useB = () => isExp() || S.type === "stock";
  const needLot = () => isExp() && /التشغيلة/.test(G("itTrack").value);
  const minShelf = () => isExp() ? Math.max(0, parseInt(G("itMinShelf").value, 10) || 0) : 0;
  function openPaint() {
    const o = S.open, v = OB.querySelector(".v");
    if (o && +o.qty > 0) {
      let t = `${fx(o.qty)} ${o.unit || ""} × ${fx(o.cost)} = ${fx(r2(o.qty * o.cost))}`;
      const bs = (o.batches || []).filter(x => +x.qty > 0);
      const dated = bs.filter(x => x.exp || x.lot);
      if (useB() && (isExp() ? bs.length : dated.length)) { const near = bs.map(x => x.exp).filter(Boolean).sort()[0]; t += ` — ${bs.length} ${bs.length > 1 ? "دفعات" : "دفعة"}${near ? " (أقرب صلاحية \u2066" + near + "\u2069)" : ""}`; }
      else if (isExp()) t += " — ⚠ بدون تاريخ صلاحية";
      v.textContent = t; OB.classList.add("on"); OB.classList.toggle("warn", isExp() && !bs.length);
    } else { v.textContent = ""; OB.classList.remove("on", "warn"); }
  }
  let OPOP = null, OLED = null, OB_ROWS = [];
  function openClose() { if (OPOP) { OPOP.remove(); OPOP = null; document.removeEventListener("mousedown", openOut, true); } }
  function openOut(e) { if (OPOP && !OPOP.contains(e.target) && !OB.contains(e.target) && !e.target.closest(".ac-tpp")) { openSave(); openClose(); } }
  function openSave() {
    if (!OPOP) return; const g = k => OPOP.querySelector(`[data-o="${k}"]`);
    const bs = useB() ? OB_ROWS.filter(x => +num(x.qty) > 0).map(x => ({ qty: +num(x.qty), exp: x.exp || "", lot: (x.lot || "").trim() })) : [];
    const qty = useB() ? bs.reduce((t, x) => t + x.qty, 0) : (+num(g("qty").value) || 0);
    S.open = qty > 0 ? { qty: r2(qty), unit: g("unit").value, cost: +num(g("cost").value) || 0, date: g("date").value || today(), ledger: OLED ? OLED.get() : "الأرصدة الإفتتاحية", batches: bs } : null;
    openPaint();
  }
  /* فحص دفعة: تاريخ مطلوب، رقم تشغيلة حسب «طريقة التتبع»، وتحذير أقل مدة صلاحية */
  function batchMsg(x, date) {
    if (!(+num(x.qty) > 0)) return "";
    if (!x.exp) return isExp() ? "أدخل تاريخ الصلاحية" : "";
    if (needLot() && !(x.lot || "").trim()) return "أدخل رقم التشغيلة";
    const d = dDiff(x.exp, date || today());
    if (d < 0) return "منتهي الصلاحية منذ " + (-d) + " يوم";
    if (d < minShelf()) return "أقل من أقل مدة صلاحية (" + minShelf() + " يوم)";
    return "";
  }
  function drawBatches() {
    if (!OPOP) return; const host = OPOP.querySelector(".bt-g"); if (!host) return;
    const date = OPOP.querySelector('[data-o="date"]').value || today();
    host.innerHTML = `<div class="h"><span>#</span><span>الكمية</span><span>تاريخ الصلاحية</span><span>رقم التشغيلة${needLot() ? ' <i class="it-req">*</i>' : ""}</span><span>المتبقي</span><span></span></div>`
      + OB_ROWS.map((x, i) => { const m = batchMsg(x, date), d = x.exp ? dDiff(x.exp, date) : null;
        return `<div class="r${m ? " bad" : ""}" data-i="${i}" title="${esc(m)}"><span>${i + 1}</span><input data-b="qty" class="n" value="${esc(x.qty)}" inputmode="decimal"><input type="date" data-b="exp" value="${esc(x.exp || "")}"><input data-b="lot" value="${esc(x.lot || "")}" autocomplete="off"><span class="dl${d != null && d < 0 ? " ex" : d != null && d < Math.max(30, minShelf()) ? " sn" : ""}">${d == null ? "" : d < 0 ? "منتهي" : d + " يوم"}</span><b data-bx="${i}" title="حذف الدفعة">✕</b></div>`; }).join("")
      + `<div class="nr" data-badd="1">+ إضافة دفعة صلاحية</div>`;
    const tq = OB_ROWS.reduce((t, x) => t + (+num(x.qty) || 0), 0); const q = OPOP.querySelector('[data-o="qty"]'); q.value = fx(r2(tq));
    const c = +num(OPOP.querySelector('[data-o="cost"]').value) || 0; OPOP.querySelector('[data-o="tot"]').value = fx(r2(tq * c));
  }
  function openPop() {
    if (OPOP) { openSave(); openClose(); return; }
    if (!TY[S.type].open) return;
    const o = S.open || { qty: 0, unit: "", cost: 0, date: today(), ledger: "الأرصدة الإفتتاحية", batches: [] };
    const us = S.units.filter(u => u.u); const units = us.length ? [...new Set(us.map(u => u.u))] : ["قطعة"];
    const def = o.unit || (us.find(u => u.dB) || us[0] || { u: "قطعة" }).u;
    if (!o.cost) { const du = us.find(u => u.u === def); if (du && +num(du.cost)) o.cost = +num(du.cost); }
    const ex = useB();
    OB_ROWS = ex ? ((o.batches && o.batches.length) ? o.batches.map(x => ({ qty: fx(x.qty), exp: x.exp || "", lot: x.lot || "" })) : [{ qty: o.qty ? fx(o.qty) : "", exp: "", lot: "" }]) : [];
    OPOP = document.createElement("div"); OPOP.className = "ic-opop" + (ex ? " exp" : "");
    OPOP.innerHTML = `<b class="h">الرصيد افتتاحى${ex ? (isExp() ? ' <small>— مخزون بصلاحية: أدخل كل دفعة بتاريخ صلاحيتها</small>' : ' <small>— مخزون: تاريخ الصلاحية ورقم التشغيلة اختياريان لكل دفعة</small>') : ""}</b>
      <div class="g"><label>الكمية</label><label>الوحدة</label><span></span><label>تكلفة الوحدة</label><span></span><label>إجمالي التكلفة</label>
        <input data-o="qty" class="n" value="${o.qty ? fx(o.qty) : "0"}" inputmode="decimal"${ex ? ' readonly tabindex="-1" title="مجموع كميات الدفعات"' : ""}><select data-o="unit">${units.map(u => `<option${u === def ? " selected" : ""}>${esc(u)}</option>`).join("")}</select><i>X</i>
        <span class="it-num"><input data-o="cost" value="${fx(o.cost || 0)}" inputmode="decimal"><span class="spn"><b>▲</b><b>▼</b></span></span><i>=</i><input data-o="tot" class="n" value="${fx(r2((o.qty || 0) * (o.cost || 0)))}" inputmode="decimal"></div>
      ${ex ? '<div class="bt-t">دفعات الصلاحية</div><div class="bt-g"></div>' : ""}
      <div class="ln"></div>
      <div class="r"><label>فى تاريخ</label><input type="date" data-o="date" value="${esc(o.date || today())}"><i class="it-req">*</i></div>
      <div class="r"><label>حساب الأستاذ</label><span data-o="led"></span><i class="it-req">*</i></div>
      <div class="ft"><button type="button" class="cx" title="مسح الرصيد الافتتاحي">✕</button><span class="hint">${ex ? "Ctrl+Enter = موافق" : "Enter = موافق"}</span><button type="button" class="okb">موافق</button></div>`;
    document.body.appendChild(OPOP);
    OLED = A.treePicker(OPOP.querySelector('[data-o="led"]'), { key: "itOLed", root: "2", value: o.ledger || "الأرصدة الإفتتاحية" });
    const g = k => OPOP.querySelector(`[data-o="${k}"]`);
    if (ex) drawBatches();
    const place = () => { const r = OB.getBoundingClientRect(), w = ex ? 560 : 440; OPOP.style.width = w + "px"; OPOP.style.left = Math.max(4, r.right - w) + "px"; const h = OPOP.offsetHeight; let top = r.top - h - 4; if (top < 4) top = Math.min(r.bottom + 2, innerHeight - h - 4); OPOP.style.top = Math.max(4, Math.min(top, innerHeight - h - 4)) + "px"; };   // لا تخرج من أسفل الشاشة إن كان الزر تحت الطيّة
    place();
    const recalc = src => { const q = +num(g("qty").value) || 0, c = +num(g("cost").value) || 0; if (src === "tot") { const t = +num(g("tot").value) || 0; g("cost").value = q ? fx(r2(t / q)) : "0"; } else g("tot").value = fx(r2(q * c)); };
    ["qty", "cost", "tot"].forEach(k => g(k).addEventListener("input", () => recalc(k)));
    g("date").addEventListener("change", () => { if (ex) drawBatches(); });
    g("unit").addEventListener("change", () => { const du = S.units.find(u => u.u === g("unit").value); if (du && +num(du.cost)) { g("cost").value = fx(+num(du.cost)); recalc("cost"); } });
    const ok = () => {
      if (ex) {
        const date = g("date").value || today();
        const bad = OB_ROWS.map((x, i) => ({ i, m: batchMsg(x, date) })).find(z => z.m && /أدخل/.test(z.m));
        if (bad) { say("الدفعة " + (bad.i + 1) + ": " + bad.m, "w"); try { window.ANOUER_SOUND && ANOUER_SOUND("err"); } catch (e) { } const r = OPOP.querySelector(`.bt-g .r[data-i="${bad.i}"] [data-b="${/التشغيلة/.test(bad.m) ? "lot" : "exp"}"]`); if (r) r.focus(); return; }
        const keys = {}; for (const x of OB_ROWS) { if (!(+num(x.qty) > 0)) continue; const k = x.exp + "|" + (x.lot || "").trim(); if (keys[k]) { say("دفعة مكررة: نفس تاريخ الصلاحية ورقم التشغيلة — اجمع كميتها في سطر واحد", "w"); return; } keys[k] = 1; }
        const warn = OB_ROWS.map(x => batchMsg(x, date)).filter(Boolean); if (warn.length) say("تنبيه: " + warn[0], "w");
      }
      openSave(); openClose(); OB.focus();
    };
    /* تحديث حالة الدفعة في مكانها (بدون إعادة رسم حتى لا يضيع المؤشر) */
    const updRow = rEl => { const x = OB_ROWS[+rEl.dataset.i]; if (!x) return; const date = g("date").value || today(), m = batchMsg(x, date), d = x.exp ? dDiff(x.exp, date) : null;
      rEl.classList.toggle("bad", !!m); rEl.title = m; const dl = rEl.querySelector(".dl"); dl.textContent = d == null ? "" : d < 0 ? "منتهي" : d + " يوم"; dl.className = "dl" + (d != null && d < 0 ? " ex" : d != null && d < Math.max(30, minShelf()) ? " sn" : ""); };
    OPOP.addEventListener("input", e => { const t = e.target; if (!t.dataset.b) return; const r = t.closest(".r"); const x = OB_ROWS[+r.dataset.i]; x[t.dataset.b] = t.value; updRow(r);
      if (t.dataset.b === "qty") { const tq = OB_ROWS.reduce((s2, z) => s2 + (+num(z.qty) || 0), 0); g("qty").value = fx(r2(tq)); recalc("qty"); } });
    OPOP.addEventListener("click", e => {
      const sp = e.target.closest(".spn b"); if (sp) { const inp = sp.closest(".it-num").querySelector("input"); inp.value = fx(Math.max(0, (+num(inp.value) || 0) + (sp.textContent === "▲" ? 1 : -1))); recalc("cost"); return; }
      const bx = e.target.closest("[data-bx]"); if (bx) { OB_ROWS.splice(+bx.dataset.bx, 1); if (!OB_ROWS.length) OB_ROWS.push({ qty: "", exp: "", lot: "" }); drawBatches(); place(); return; }
      if (e.target.closest("[data-badd]")) { const last = OB_ROWS[OB_ROWS.length - 1]; OB_ROWS.push({ qty: "", exp: "", lot: "" }); drawBatches(); place(); const q = OPOP.querySelector(`.bt-g .r[data-i="${OB_ROWS.length - 1}"] [data-b="qty"]`); if (q) q.focus(); return; }
      if (e.target.closest(".okb")) { ok(); return; }
      if (e.target.closest(".cx")) { S.open = null; openPaint(); openClose(); }
    });
    OPOP.addEventListener("keydown", e => {
      if (e.key === "Escape") { e.stopPropagation(); openClose(); OB.focus(); return; }
      if (e.key !== "Enter" || e.target.closest(".ac-tp")) return;
      e.preventDefault();
      if (ex && !e.ctrlKey && e.target.dataset.b) {   // Enter داخل الدفعات: الحقل التالي ثم دفعة جديدة
        const ins = [...OPOP.querySelectorAll(".bt-g [data-b]")], j = ins.indexOf(e.target);
        if (j < ins.length - 1) { ins[j + 1].focus(); try { ins[j + 1].select(); } catch (x) { } }
        else { const r = OB_ROWS[OB_ROWS.length - 1]; if (+num(r.qty) > 0 && r.exp) { OB_ROWS.push({ qty: "", exp: "", lot: "" }); drawBatches(); place(); const q = OPOP.querySelector(`.bt-g .r[data-i="${OB_ROWS.length - 1}"] [data-b="qty"]`); if (q) q.focus(); } else ok(); }
        return;
      }
      ok();
    });
    setTimeout(() => { const f = ex ? OPOP.querySelector('.bt-g [data-b="qty"]') : g("qty"); f.focus(); try { f.select(); } catch (x) { } document.addEventListener("mousedown", openOut, true); }, 0);
  }
  OB.addEventListener("click", openPop);
  OB.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === "F4" || e.key === " ") { e.preventDefault(); openPop(); } });
  G("itTrack").addEventListener("change", openPaint);

  /* ------------------------------------------------------------------ أرصدة الصلاحية (دفعات الصنف الحالية — FEFO) */
  const BSEC = document.createElement("div"); BSEC.className = "it-sec ic-bsec"; BSEC.dataset.row = "batches"; BSEC.hidden = true;
  BSEC.innerHTML = `<div class="it-st">أرصدة الصلاحية <button type="button" class="ic-cbt sm" data-a="bRef" title="تحديث">⟳</button></div><div class="it-sb"><div class="ic-bt"></div></div>`;
  xRow.appendChild(BSEC);
  function batchTable(list, host, opts) {
    opts = opts || {}; const td = today();
    if (!list.length) { host.innerHTML = '<div class="e">لا توجد دفعات صلاحية مسجلة — أضفها من الرصيد الافتتاحي أو من «مخزون أول المدة» / المشتريات</div>'; return; }
    host.innerHTML = `<div class="h${opts.item ? " it" : ""}">${opts.item ? "<span>الصنف</span>" : ""}<span>تاريخ الصلاحية</span><span>رقم التشغيلة</span><span>الوارد</span><span>المتبقي</span><span>الحالة</span><span>المستند</span></div>`
      + list.map(b => { const d = b.exp ? dDiff(b.exp, td) : null, st = !b.exp ? "بدون تاريخ" : d < 0 ? "منتهي منذ " + (-d) + " يوم" : d <= (b.ms || 30) ? "قارب الانتهاء: " + d + " يوم" : "صالح: " + d + " يوم";
        return `<div class="r${opts.item ? " it" : ""}${b.rem > 0 ? "" : " z"}${d != null && d < 0 && b.rem > 0 ? " ex" : d != null && d <= (b.ms || 30) && b.rem > 0 ? " sn" : ""}">${opts.item ? `<span class="t">${esc(b.name)}</span>` : ""}<span>${esc(b.exp || "—")}</span><span>${esc(b.lot || "")}</span><span>${fx(b.qty)}</span><span><b>${fx(b.rem)}</b></span><span>${esc(st)}</span><span>${esc(DOCN[b.type] || b.type)} ${esc(b.no)}</span></div>`; }).join("");
  }
  const DOCN = { Opening: "مخزون أول المدة", Purchase: "مشتريات", StockIn: "إضافة مخزنية" };
  function loadBatches() {
    BSEC.hidden = !(useB() && S.id && HOST());
    if (BSEC.hidden) return;
    const host = BSEC.querySelector(".ic-bt"), id = S.id; host.innerHTML = '<div class="e">جارٍ التحميل…</div>';
    Anouer.call("fm.item.batches", { id }).then(l => {
      if (S.id !== id) return; const it = (l || [])[0];
      const rows = it ? it.batches.slice().sort((a, b) => (a.exp || "9999").localeCompare(b.exp || "9999")).map(b => Object.assign({ ms: it.minShelf }, b)) : [];
      if (!isExp() && !rows.length) { BSEC.hidden = true; return; }
      batchTable(rows, host);
      if (it && it.untracked > 0) host.insertAdjacentHTML("beforeend", `<div class="e w">رصيد ${fx(it.untracked)} بدون دفعة صلاحية مسجلة (أُدخل قبل تحويل الصنف إلى «مخزون بصلاحية»)</div>`);
    }).catch(e => { host.innerHTML = '<div class="e">' + esc(H.isUnknown && H.isUnknown(e) ? "أعد بناء البرنامج لتفعيل أرصدة الصلاحية" : (e.message || e)) + "</div>"; });
  }
  BSEC.addEventListener("click", e => { if (e.target.closest('[data-a="bRef"]')) loadBatches(); });
  /* تقرير عام: كل أصناف «مخزون بصلاحية» ودفعاتها (من مراجعة الأصناف / المخازن) */
  window.ITC_EXPIRY = function (onlyId) {
    if (!HOST()) { say("تقرير الصلاحية يعمل مع قاعدة البيانات", "i"); return; }
    Anouer.call("fm.item.batches", { id: onlyId || 0 }).then(l => {
      const rows = []; (l || []).forEach(it => it.batches.forEach(b => rows.push(Object.assign({ name: it.name, ms: it.minShelf }, b))));
      rows.sort((a, b) => (b.rem > 0) - (a.rem > 0) || (a.exp || "9999").localeCompare(b.exp || "9999"));
      const D = Dlg({ title: "أرصدة الصلاحية" + (onlyId && l && l[0] ? " — " + l[0].name : ""), w: 900, noFoot: true });
      const ex = rows.filter(r => r.rem > 0 && r.exp && r.exp < today()).length, sn = rows.filter(r => r.rem > 0 && r.exp && r.exp >= today() && dDiff(r.exp, today()) <= (r.ms || 30)).length;
      D.body.innerHTML = `<div class="ic-exs"><span class="k ex">منتهي: <b>${ex}</b></span><span class="k sn">قارب الانتهاء: <b>${sn}</b></span><span class="k">أصناف بصلاحية: <b>${(l || []).length}</b></span><label><input type="checkbox" class="z0" checked> إخفاء الدفعات المنتهية الرصيد</label></div><div class="ic-bt big"></div>`;
      const draw = () => batchTable(D.body.querySelector(".z0").checked ? rows.filter(r => r.rem > 0) : rows, D.body.querySelector(".ic-bt"), { item: true });
      D.body.querySelector(".z0").addEventListener("change", draw); draw();
    }).catch(e => say(H.isUnknown && H.isUnknown(e) ? "أعد بناء البرنامج لتفعيل تقرير الصلاحية" : (e.message || e), "e"));
  };

  /* ------------------------------------------------------------------ النوع: التبويبات والحقول */
  function applyType(k, keepLed) {
    k = TY[k] ? k : (LEGACY[k] || "stock"); S.type = k; sel.value = k; const t = TY[k];
    G("itDesc").textContent = t.d;
    tabs.querySelectorAll(".it-stab").forEach(x => x.classList.toggle("hid", !t.tabs.includes(x.dataset.p)));
    const on = tabs.querySelector(".it-stab.on"); if (!on || on.classList.contains("hid")) { tabs.querySelectorAll(".it-stab").forEach(x => x.classList.toggle("on", x.dataset.p === "data")); QA(".it-pn").forEach(x => x.classList.toggle("on", x.dataset.p === "data")); }
    Q('[data-row="valm"]').style.visibility = t.val ? "" : "hidden";
    Q('[data-row="open"]').hidden = !t.open; Q('[data-row="warr"]').hidden = !t.warranty; Q('[data-row="exp"]').hidden = !t.exp;
    if (!keepLed && (!LED || LED.root !== t.root || LED.get() !== t.led)) mkLed(t.root, t.led);
    if (!t.open) S.open = null;
    openPaint(); loadBatches();
    try { window.__itScale && __itScale.type(k, !!keepLed); } catch (e) { }
  }

  /* ------------------------------------------------------------------ تسلسل كل حقول البطاقة (المفتوحة) */
  const OWN_SEL = ".ac-tp,.ic-lk,.ic-cb,.ic-ug,.ic-open,[data-own],[data-cg]";
  function fieldNodes() {
    const out = [], SEEN = {};   /* صفّان بنفس الاسم في نفس القسم (نسبة الضريبة ×2) ← المفتاح الثانى ينتهى بـ #2 */
    QA(".it-pn").forEach(pn => {
      const p = pn.dataset.p; if (p === "comp" || p === "content") return;
      pn.querySelectorAll(".it-r").forEach(r => {
        const l = r.querySelector("label"); const lbl = l ? l.textContent.trim() : ""; if (!lbl) return;
        const sec = (r.closest(".it-sec") || {}).querySelector ? (r.closest(".it-sec").querySelector(".it-st") || {}).textContent || "" : "";
        [...r.querySelectorAll("input,select,textarea,.it-tg")].filter(x => !x.closest(OWN_SEL) && !x.dataset.own).forEach((x, i) => { let key = p + "|" + sec.trim() + "|" + lbl + "|" + i; if (SEEN[key]) key += "#" + (++SEEN[key]); else SEEN[key] = 1; out.push({ key, el: x }); });
      });
    });
    return out;
  }
  function readFields() { const o = {}; fieldNodes().forEach(({ key, el }) => { o[key] = el.classList.contains("it-tg") ? el.classList.contains("on") : el.type === "checkbox" ? el.checked : el.value; }); return o; }
  function writeFields(o, reset) {
    fieldNodes().forEach(({ key, el }) => {
      if (!(key in (o || {})) && !reset) return;
      const v = o && key in o ? o[key] : el.__def;
      if (el.classList.contains("it-tg")) { const on = !!v; el.classList.toggle("on", on); const em = el.querySelector("em"); if (em) em.textContent = on ? "نعم" : "لا"; }
      else if (el.type === "checkbox") el.checked = !!v; else if (v != null) el.value = v;
    });
  }
  fieldNodes().forEach(({ el }) => { el.__def = el.classList.contains("it-tg") ? el.classList.contains("on") : el.type === "checkbox" ? el.checked : el.value; });

  /* ------------------------------------------------------------------ الرقم */
  function nextNo() {
    let mx = 0; PRODS().forEach(p => { const c = String(p.code || ""); if (c.length === NO_BASE.length + 3 && c.startsWith(NO_BASE)) { const n = parseInt(c.slice(NO_BASE.length), 10); if (n > mx) mx = n; } });
    return NO_BASE + String(mx + 1).padStart(3, "0");
  }
  /* تغيير رقم الصنف يغيّر باركود الوحدات التي أخذت الرقم تلقائياً */
  let NO_PREV = "";
  function syncBc(old, v) { let ch = false; S.units.forEach(u => { if (!u.bc || u.bc === old || u.__auto) { if (u.bc !== v) { u.bc = v; ch = true; } u.__auto = true; } }); if (ch) renderUnits(); }
  window.itNewNo = function () { const v = nextNo(); const old = G("itNo").value; G("itNo").value = v; G("itGtin").value = v; syncBc(old, v); NO_PREV = v; noCheck(); };
  function noCheck() {
    const v = codeNow(), dup = v && PRODS().some(p => p.id !== S.id && String(p.code) === v);
    okI.textContent = !v ? "" : dup ? "✕" : "✓"; okI.classList.toggle("bad", !!dup); okI.title = !v ? "" : dup ? "الرقم مستخدم لصنف آخر" : "الرقم متاح";
    return !dup;
  }
  G("itNo").addEventListener("input", () => { noCheck(); syncBc(NO_PREV, codeNow()); NO_PREV = codeNow(); });

  /* ------------------------------------------------------------------ إعادة التهيئة / التحميل */
  function reset() {
    S.loadSeq++; S.id = null; S.img0 = null; S.moves = 0; S.open = null; S.colors = []; S.sizes = []; S.extra = {};
    G("itName").value = ""; G("itName").classList.remove("err"); G("itActive").checked = true;
    writeFields({}, true); G("itNote").value = ""; G("itTagList").innerHTML = ""; if (G("itSerial")) G("itSerial").value = "تلقائى";
    window.__itImg && __itImg.set(null); window.__itComps && __itComps.set([]); window.__itBundle && __itBundle.set(null);
    CB.br.set(null); CB.wh.set(null); GRP.set(""); LK.uom.set(null); LK.sup.set(null); LK.dpol.set(null); LK.mk && LK.mk.set(null); LK.actv && LK.actv.set(null);
    G("itGtinStd").value = "GS1"; G("itValm").value = "الوارد أولاً صادر أولاً"; G("itHomo").value = ""; try { window.ANOUER_ITEMEQ ? ANOUER_ITEMEQ.cardFill(G("itEq"), "") : (G("itEq").value = ""); } catch (e) { } G("itWarr").value = "0"; G("itMinShelf").value = "30"; G("itTrack").selectedIndex = 0;
    Object.keys(TP).forEach(k => TP[k].set(TP[k].def || ""));
    applyType("stock"); window.itNewNo();
    S.units = []; NO_PREV = codeNow();   // مثل DEXEF: جدول الوحدات يبدأ بسطر فارغ
    renderUnits(); renderCG(); openPaint(); vatUi(); dtUi(); noCheck();
    tabs.querySelectorAll(".it-stab").forEach(x => x.classList.toggle("on", x.dataset.p === "data")); QA(".it-pn").forEach(x => x.classList.toggle("on", x.dataset.p === "data"));
    const w = Q(".it-wrap"); if (w) w.scrollTop = 0;
  }
  function fill(it, units, x, opts) {
    opts = opts || {};
    S.id = opts.dup ? null : it.id; S.moves = opts.dup ? 0 : (it.moves || 0);
    G("itName").value = (it.name || "") + (opts.dup ? " (نسخة)" : ""); G("itActive").checked = it.active !== false;
    applyType(it.type || x.type || "stock", true);
    G("itNo").value = opts.dup ? nextNo() : (it.code || ""); G("itGtin").value = opts.dup ? G("itNo").value : (x.gtin || it.code || "");
    G("itGtinStd").value = x.gtinStd || "GS1";
    GRP.set(it.category || ""); CB.br.set(x.branches || null); CB.wh.set(x.whs || null);
    LK.sup.set(x.supplier || null); LK.dpol.set(x.dpol || null); LK.uom.set(x.uom || null); LK.mk && LK.mk.set(x.mk || null); LK.actv && LK.actv.set(x.actv || null);
    mkLed(TY[S.type].root, x.ledger != null ? x.ledger : TY[S.type].led);
    G("itValm").value = x.valm || "الوارد أولاً صادر أولاً"; G("itHomo").value = x.homo ? "1" : ""; try { window.ANOUER_ITEMEQ ? ANOUER_ITEMEQ.cardFill(G("itEq"), x.eq || "") : (G("itEq").value = x.eq || ""); } catch (e) { } G("itWarr").value = x.warranty || "0"; G("itMinShelf").value = x.minShelf || "30"; if (x.track) G("itTrack").value = x.track;
    Object.keys(TP).forEach(k => TP[k].set(x.acc && x.acc[k] != null ? x.acc[k] : (TP[k].def || "")));
    writeFields({}, true); writeFields(x.f || {});
    if (!x.v2) {   /* أصناف محفوظة قبل تفعيل الخصائص: «لا» الافتراضية كانت تعنى «حسب الفاتورة» */
      if (vatSel && vatSel.value === "لا") vatSel.value = "كما بالفاتورة"; tgSet(cashTg(), true);
      if (G("itMax")) G("itMax").value = "0"; if (G("itStag")) G("itStag").value = "0";
    }
    if (G("itSerial")) G("itSerial").value = opts.dup || it.id == null ? "تلقائى" : String(it.id);
    if (G("itMin") && it.reorder != null) G("itMin").value = fx(it.reorder);
    G("itNote").value = x.desc || ""; G("itTagList").innerHTML = "";
    (x.tags || []).forEach(t => { G("itTag").value = t; if (window.itAddTag) itAddTag(); }); G("itTag").value = "";
    S.colors = (x.colors || []).slice(); S.sizes = (x.sizes || []).slice();
    window.__itComps && __itComps.set(x.comps || []); window.__itBundle && __itBundle.set(x.bundle || null);
    S.units = (units || []).filter(u => u.active !== false || u.isBase).map(u => ({ puid: opts.dup ? 0 : (+u.puid || 0), xb: !!u.xb, bc: opts.dup ? "" : (u.barcode || ""), n: fx(u.factor || 1), u: u.unit || "", cost: u.cost == null ? "" : fx(u.cost), price: fx(u.price || 0), retail: u.retail == null ? "" : fx(u.retail), q5: u.q5 == null ? "" : fx(u.q5), dB: !!u.defBuy, dS: !!u.defSale, act: u.active !== false }));
    /* ✦ أسعار محفوظة تختلف عن (سعر القطعة × العدد) = أسعار يدوية للوحدة ← لا يغيّرها الحساب التلقائي لاحقاً */
    { const bi = S.units.findIndex(r => (+num(r.n) || 1) === 1), b = S.units[bi]; if (b) S.units.forEach((r, j) => { if (j === bi) return; r.__nMan = true; PK.forEach(k => { const bv = +num(b[k]) || 0, v = +num(r[k]) || 0; if (v && Math.abs(v - bv * (+num(r.n) || 1)) > 0.009) { r.__man = r.__man || {}; r.__man[k] = true; } }); }); }
    { S.units.forEach(r => { r.lbl = ""; }); const LB = !opts.dup && x.lbl;
      if (Array.isArray(LB)) LB.forEach(e => { if (!e || !String(e.v || "").trim()) return; const k = String(e.u || "").trim(), b = String(e.b || "").trim(), c = S.units.filter(r => (r.u || "").trim() === k && !r.lbl); const r = (b && c.find(r => (r.bc || "").trim() === b)) || c.find(r => !b) || c[0]; if (r) r.lbl = String(e.v).trim(); });
      else if (LB) { const sn = new Set(); S.units.forEach(r => { const k = (r.u || "").trim(); if (LB[k] && !sn.has(k)) { sn.add(k); r.lbl = String(LB[k]); } }); } }
    if (opts.dup && S.units[0]) S.units[0].bc = G("itNo").value;
    NO_PREV = codeNow();
    S.open = opts.dup ? null : (x.open || null);
    if (!opts.dup && opts.opening) { const o = opts.opening; S.open = { qty: +o.qty || 0, unit: o.unit || "", cost: +o.cost || 0, date: o.date || today(), ledger: (x.open && x.open.ledger) || "الأرصدة الإفتتاحية", batches: (o.batches || []).map(b => ({ qty: +b.qty || 0, exp: b.exp || "", lot: b.lot || "" })), no: o.no }; }
    try { const im = window.__pimg ? __pimg({ id: it.id, code: it.code }) : ""; window.__itImg && __itImg.set(im || null); S.img0 = im || null; hdLoad(it.id, im || null); } catch (e) { }
    renderUnits(); renderCG(); openPaint(); vatUi(); dtUi(); noCheck();
    try { window.__itScale && __itScale.set(S.type === "scale" ? (x.scale || {}) : null); } catch (e) { }
  }
  /* فتح صنف للتعديل: المؤشر في آخر الاسم بدون تحديد الاسم كله (حتى لا يُستبدل بالكتابة خطأً) */
  let LOAD_T = 0;
  function caretEnd() {
    const n = G("itName"); if (!n || !n.offsetParent) return;
    if (document.activeElement !== n) { const a = document.activeElement; if (a && a !== document.body && a.closest && !a.closest("#vItem,.vw") ) return; try { n.focus({ preventScroll: true }); } catch (e) { n.focus(); } }
    const L = n.value.length; try { n.setSelectionRange(L, L); n.scrollLeft = 0; } catch (e) { }
  }
  G("itName").addEventListener("focus", () => { if (Date.now() - LOAD_T < 2500) setTimeout(() => { const n = G("itName"); if (document.activeElement === n && n.value && n.selectionEnd - n.selectionStart >= n.value.length) { const L = n.value.length; n.setSelectionRange(L, L); } }, 0); });
  function load(p, opts) {
    LOAD_T = Date.now(); [80, 450, 1200].forEach(t => setTimeout(() => { if (Date.now() - LOAD_T < 2500 && !(opts && opts.dup)) caretEnd(); }, t));
    reset(); const seq = ++S.loadSeq;
    const px = (() => { try { return p.x || {}; } catch (e) { return {}; } })();
    const fromP = () => fill({ id: p.id, code: p.code, name: p.name, category: p.cat, active: p.active !== false, type: p.type || "stock", reorder: p.min },
      (p._u && p._u.length ? p._u.map(u => ({ unit: u.name, factor: u.factor, barcode: u.bc, price: u.price, q5: u.p5 || null, retail: u.rp || null, cost: null, defSale: u.def, defBuy: u.defBuy, isBase: u.base, active: true })) : [{ unit: p.unit || "قطعة", factor: 1, barcode: p.code, price: p.price, cost: p.cost, retail: p.retail, q5: p.q5, defSale: true, defBuy: true, isBase: true }]), px, opts);
    if (HOST() && p.id && !String(p.id).startsWith("c:")) {
      Anouer.call("fm.item.get", { id: p.id }).then(r => {
        if (seq !== S.loadSeq) return;
        let x = {}; try { x = r.item.extra ? JSON.parse(r.item.extra) : {}; } catch (e) { x = {}; }
        fill(Object.assign({}, r.item, { moves: r.moves }), r.units, x, Object.assign({}, opts, { opening: r.opening }));
      }).catch(e => { if (seq !== S.loadSeq) return; if (H.isUnknown && H.isUnknown(e)) fromP(); else { say("تعذّر تحميل الصنف: " + (e.message || e), "e"); fromP(); } });
    } else fromP();
  }

  /* ------------------------------------------------------------------ الحفظ */
  let SAVING = false;
  function collect() {
    const x = {
      v: 1, v2: 1, type: S.type, gtin: G("itGtin").value.trim(), gtinStd: G("itGtinStd").value, branches: CB.br.get(), whs: CB.wh.get(),
      supplier: LK.sup.get(), dpol: LK.dpol.get(), uom: LK.uom.get(), mk: LK.mk ? LK.mk.get() : null, actv: LK.actv ? LK.actv.get() : null,
      ledger: LED ? LED.get() : "", valm: TY[S.type].val ? G("itValm").value : "", homo: G("itHomo").value === "1" ? 1 : undefined, eq: (G("itEq") && G("itEq").value) || undefined, warranty: TY[S.type].warranty ? G("itWarr").value : "",
      minShelf: TY[S.type].exp ? G("itMinShelf").value : "", track: TY[S.type].exp ? G("itTrack").value : "",
      acc: Object.keys(TP).reduce((o, k) => { o[k] = TP[k].get(); return o; }, {}),
      f: readFields(), desc: G("itNote").value, tags: [...G("itTagList").children].map(s => s.textContent.replace(/\s*✕\s*$/, "").trim()).filter(Boolean),
      colors: S.type === "apparel" ? S.colors : [], sizes: S.type === "apparel" ? S.sizes : [],
      comps: (S.type === "group" || S.type === "made") && window.__itComps ? __itComps.get() : [],
      bundle: S.type === "group" && window.__itBundle ? __itBundle.get() : null,
      scale: S.type === "scale" && window.__itScale ? __itScale.get() : null,
      open: TY[S.type].open ? S.open : null,
      lbl: (() => { const o = []; S.units.forEach(r => { const k = (r.u || "").trim(), v = String(r.lbl || "").trim(); if (k && v) o.push({ u: k, b: (r.bc || "").trim(), v }); }); return o.length ? o : undefined; })()
    };
    return x;
  }
  function validate() {
    const nmEl = G("itName"), nm = nmEl.value.trim();
    const bad = (m, el, tab) => { say(m, "w"); try { window.ANOUER_SOUND && ANOUER_SOUND("err"); } catch (e) { } if (tab) { tabs.querySelectorAll(".it-stab").forEach(t => t.classList.toggle("on", t.dataset.p === tab)); QA(".it-pn").forEach(p => p.classList.toggle("on", p.dataset.p === tab)); } if (el) { el.classList && el.classList.add("err"); el.focus && el.focus(); } return false; };
    if (!nm) return bad("من فضلك أدخل اسم الصنف", nmEl, "data");
    if (!codeNow()) return bad("من فضلك أدخل رقم الصنف", G("itNo"), "data");
    if (!noCheck()) return bad("الرقم " + codeNow() + " مستخدم لصنف آخر", G("itNo"), "data");
    const us = S.units.filter(u => (u.u || "").trim());
    if (!us.length) return bad("أدخل وحدة واحدة على الأقل في جدول الوحدات", UG.querySelector('input[data-k="u"]'), "data");
    const seen = {}; for (const u of us) { const k = u.u.trim(), f = +num(u.n) || 0;
      /* نفس الوحدة في أكثر من سطر = باركود إضافي لها (مثل DEXEF) بشرط نفس عدد القطع وباركود مختلف */
      if (seen[k]) { if (seen[k].f !== f) return bad("الوحدة «" + k + "» مكررة بعدد قطع مختلف — السطر المكرر يجب أن يكون بنفس عدد القطع (باركود إضافي)", null, "data"); if (!(u.bc || "").trim()) return bad("الوحدة «" + k + "» مكررة في جدول الوحدات — أدخل باركوداً مختلفاً للسطر المكرر أو احذفه", null, "data"); }
      else seen[k] = { f }; if (!(+num(u.n) > 0)) return bad("عدد القطع للوحدة «" + k + "» يجب أن يكون أكبر من صفر", null, "data"); }
    // باركود أخذ رقماً تلقائياً قديماً (قبل تغيير رقم الصنف) ومستخدم لصنف آخر ← يتبع الرقم الحالي تلقائياً
    { const v = codeNow(), isAuto = b => b && b.length === NO_BASE.length + 3 && b.startsWith(NO_BASE), used = b => PRODS().some(p => p.id !== S.id && ((p._u || []).some(z => z.bc === b || (z.xb || []).includes(b)) || String(p.code) === b)); let ch = false;
      us.forEach(u => { const b = (u.bc || "").trim(); if (b && b !== v && isAuto(b) && used(b)) { u.bc = us.some(x => x !== u && (x.bc || "").trim() === v) ? "" : v; u.__auto = true; ch = true; } });
      if (ch) { renderUnits(); T("تم تحديث باركود الوحدة ليطابق رقم الصنف " + v, "i"); } }
    const bcs = {}; for (const u of us) { const b = (u.bc || "").trim(); if (!b) continue;
      /* نفس الباركود لوحدتين مختلفتين مسموح (عند المسح تظهر نافذة اختيار الوحدة) — الممنوع فقط تكراره لنفس الوحدة */
      const ku = b + "\u0001" + (u.u || "").trim(); if (bcs[ku]) return bad("الباركود " + b + " مكرر لنفس الوحدة «" + (u.u || "").trim() + "»", null, "data"); bcs[ku] = 1; const o = PRODS().find(p => p.id !== S.id && ((p._u || []).some(z => z.bc === b || (z.xb || []).includes(b)) || String(p.code) === b)); if (o) return bad("الباركود " + b + " مستخدم للصنف: " + o.name, null, "data"); }
    if (S.id && !G("itActive").checked && window.__deactBlock) { const p0 = PRODS().find(p => String(p.id) === String(S.id)), m = p0 && p0.active !== false && __deactBlock(p0); if (m) { G("itActive").checked = true; return bad(m, G("itActive"), "data"); } }
    { const sn = {}; for (const u of us) { const v = String(u.lbl || "").trim(); if (!v) continue; const k = v.toLowerCase();
        if (sn[k]) return bad("رقم الملصق " + v + " مكتوب لوحدتين في نفس الصنف", null, "data"); sn[k] = 1;
        const o = window.ANOUER_LBL && ANOUER_LBL.owner(v, S.id); if (o) return bad("رقم الملصق " + v + " مستعمل للصنف «" + o.name + "» (" + o.unit + ")", null, "data"); } }
    if (CB.br.get() && !CB.br.get().length) return bad("اختر الفرع", null, "data");
    /* مخزون بصلاحية: الرصيد الافتتاحي لا يُقبل إلا بدفعات صلاحية (تاريخ + رقم تشغيلة حسب طريقة التتبع) */
    if (isExp() && S.open && +S.open.qty > 0) {
      const bs = (S.open.batches || []).filter(b => +b.qty > 0);
      if (!bs.length) { bad("مخزون بصلاحية: أدخل تاريخ الصلاحية لكل دفعة في الرصيد الافتتاحي", null, "data"); setTimeout(openPop, 60); return false; }
      const m = bs.map(b => batchMsg(b, S.open.date)).find(z => /أدخل/.test(z)); if (m) { bad("الرصيد الافتتاحي: " + m, null, "data"); setTimeout(openPop, 60); return false; }
    }
    return true;
  }
  function save() {
    if (SAVING) return;
    if (!validate()) return;
    const x = collect(), us = S.units.filter(u => (u.u || "").trim());
    const wh = CB.wh.first(); const whMain = (CB.wh.list[0] || {}).id;
    const doc = {
      Id: S.id || 0, Code: codeNow(), Name: G("itName").value.trim(), Type: S.type, Category: GRP.get() || "", Active: G("itActive").checked,
      Reorder: +num((G("itMin") || {}).value) || 0, Extra: JSON.stringify(x),
      Units: us.map(u => ({ Unit: u.u.trim(), Factor: +num(u.n) || 1, Barcode: (u.bc || "").trim(), Cost: u.cost === "" ? null : +num(u.cost) || 0, Price: +num(u.price) || 0, Retail: u.retail === "" ? null : +num(u.retail) || 0, Q5: u.q5 === "" ? null : +num(u.q5) || 0, DefBuy: !!u.dB, DefSale: !!u.dS, Active: !!u.act, Puid: u.xb ? 0 : (+u.puid || 0) })),
      Opening: x.open && TY[S.type].open ? { Qty: +x.open.qty || 0, Unit: x.open.unit || us[0].u, Factor: +num((us.find(u => u.u === x.open.unit) || us[0]).n) || 1, Cost: +x.open.cost || 0, Date: x.open.date || today(), WarehouseId: wh && wh.id !== whMain ? (+wh.id || 0) : 0, WhName: wh ? wh.name : "",
        Batches: useB() ? (x.open.batches || []).filter(b => +b.qty > 0).map(b => ({ Qty: +b.qty, Exp: b.exp, Lot: b.lot || "" })) : null } : null
    };
    const nm = doc.Name, img = window.__itImg ? __itImg.get() : null, wasNew = !S.id;
    if (!HOST()) { memSave(doc, x); return; }
    SAVING = true; const btn = Q(".it-save"); if (btn) btn.disabled = true;
    Anouer.call("fm.item.save", doc).then(r => {
      const id = r && r.id;
      try { if (id && window.ANOUER_LBL) ANOUER_LBL.setItem(id, x.lbl); } catch (x0) { }
      if (window.__pimgPut && id) __pimgPut(id, img);
      if (id && img !== S.img0) hdPut(id, img);
      try { window.ANOUER_SOUND && ANOUER_SOUND("save"); } catch (x1) { }
      T((wasNew ? "تم حفظ الصنف: " : "تم تعديل الصنف: ") + nm, "s");
      return reloadAll().then(() => { reset(); G("itName").focus(); });
    }).catch(e => { say("لم يتم حفظ الصنف: " + (e && e.message || e), "e"); try { window.ANOUER_SOUND && ANOUER_SOUND("err"); } catch (x2) { } })
      .then(() => { SAVING = false; if (btn) btn.disabled = false; });
  }
  /* الصورة بالدقة العالية (جدول ProductImages) — المصغّرة 200px تبقى لشبكة اللمس
     «بصمة» آخر حفظ ناجح (طول البيانات) تُحفظ في الخصائص: لا تُعرض صورة قديمة من القاعدة إن فشل آخر حفظ */
  const HDK = id => "pimg.hd." + id;
  const hdMark = (id, v) => { try { if (window.ANOUER_PROPS) ANOUER_PROPS.put(HDK(id), v); } catch (e) { } };
  function hdLoad(id, thumbUrl) {
    if (!HOST() || !id) return; const seq = S.loadSeq;
    Anouer.call("fm.pimg.get", { id }).then(r => {
      if (!r || !r.data || seq !== S.loadSeq || S.id !== id) return;
      let mk = null; try { mk = window.ANOUER_PROPS ? ANOUER_PROPS.get(HDK(id), null) : null; } catch (e) { }
      if (mk != null && +mk !== r.data.length) return;   // صورة القاعدة أقدم من آخر صورة حُفظت
      const cur = window.__itImg ? __itImg.get() : null; if (cur !== thumbUrl) return;   // غيّرها المستخدم أثناء التحميل
      const u = "data:" + (r.type || "image/jpeg") + ";base64," + r.data; S.img0 = u; __itImg.set(u);
    }).catch(() => { });
  }
  function hdPut(id, img) {
    if (!HOST()) return;
    const send = (data, w, h) => {
      const b = String(data || "").replace(/^data:[^,]*,/, "");
      return Anouer.call("fm.pimg.put", { id, data: data || "", w: w || 0, h: h || 0 })
        .then(() => { hdMark(id, b.length); if (b.length) T("حُفظت صورة الصنف بالدقة العالية ✓ (" + (w || "?") + "×" + (h || "?") + ")", "s"); })
        .catch(e => { hdMark(id, -1); const m = String(e && e.message || e); T(/غير معروف|Unknown/i.test(m) ? "أعد بناء البرنامج لحفظ الصورة بالدقة العالية" : "تعذّر حفظ الصورة بالدقة العالية: " + m, "w"); });
    };
    if (!img) return send("");
    if (!/^data:image\//.test(img)) { hdMark(id, -1); return; }
    const i = new Image(); i.onload = () => {
      // حد أقصى 2048px (الجودة العالية بدون تضخيم القاعدة)
      const k = Math.min(1, 2048 / Math.max(i.naturalWidth, i.naturalHeight));
      if (k < 1 || !/^data:image\/(jpeg|png|webp)/.test(img)) { const c = document.createElement("canvas"); c.width = Math.round(i.naturalWidth * k); c.height = Math.round(i.naturalHeight * k); const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height); x.imageSmoothingQuality = "high"; x.drawImage(i, 0, 0, c.width, c.height); send(c.toDataURL("image/jpeg", 0.93), c.width, c.height); }
      else send(img, i.naturalWidth, i.naturalHeight);
    }; i.src = img;
  }
  /* وضع المعاينة (بدون قاعدة): يحفظ في الذاكرة كما سابقاً */
  function memSave(doc, x) {
    const u = doc.Units.find(z => z.DefSale) || doc.Units[0], P = PRODS();
    const o = { name: doc.Name, code: doc.Code, price: u.Price, cat: doc.Category || "عام", unit: u.Unit, active: doc.Active, type: doc.Type, cost: u.Cost != null ? u.Cost : Math.round(u.Price * .8), retail: u.Retail || u.Price, q5: u.Q5 || u.Price, min: doc.Reorder, x,
      _u: doc.Units.map(z => ({ name: z.Unit, price: z.Price, factor: z.Factor, bc: z.Barcode, def: z.DefSale, defBuy: z.DefBuy, p5: z.Q5 || 0, rp: z.Retail || 0, base: z.Factor === 1 })) };
    if (S.id != null) { const p = P.find(q => q.id === S.id); if (p) Object.assign(p, o); T("تم تعديل الصنف: " + doc.Name, "s"); }
    else { o.id = P.reduce((m, p) => Math.max(m, +p.id || 0), 0) + 1; o.stock = doc.Opening ? doc.Opening.Qty * doc.Opening.Factor : 0; P.push(o); T("تم حفظ الصنف: " + doc.Name, "s"); }
    if (window.__pimgPut && (o.id || S.id)) __pimgPut(o.id || S.id, window.__itImg ? __itImg.get() : null);
    try { if (typeof renderCat === "function") renderCat(); } catch (e) { }
    window.__irRender && __irRender(); reset(); G("itName").focus();
  }
  function reloadAll() {
    const L = window.__anouerLink;
    const p = L && L.loadProducts ? L.loadProducts().catch(() => { }) : Promise.resolve();
    ALLU = null;
    return p.then(() => { loadTypes(); try { if (window.ANOUER_WH) ANOUER_WH.load(true); } catch (e) { } window.__irRender && __irRender(); try { if (typeof renderCat === "function") renderCat(); } catch (e) { } });
  }
  /* أنواع الأصناف (للمشتريات وغيرها) */
  function loadTypes() {
    const px = (m, x, id) => { try { const o = typeof x === "string" ? (x ? JSON.parse(x) : {}) : (x || {}); if (o.minShelf || o.track) m[id] = { minShelf: o.minShelf, track: o.track }; } catch (e) { } };
    const sx = (m, x, id) => { try { const o = typeof x === "string" ? (x ? JSON.parse(x) : {}) : (x || {}); m[id] = o.scale || {}; } catch (e) { m[id] = {}; } };
    const done = () => { try { document.dispatchEvent(new CustomEvent("anouer:itypes")); } catch (e) { } };
    if (!HOST()) { const m = {}, xm = {}, sm = {}, all = {}; PRODS().forEach(p => { try { const o = typeof p.x === "string" ? JSON.parse(p.x || "{}") : p.x; if (o) all[p.id] = o; } catch (e) { } }); window.__IXALL = all; PRODS().forEach(p => { m[p.id] = p.type || "stock"; px(xm, p.x, p.id); if (p.type === "scale") sx(sm, p.x, p.id); }); window.__ITYPE = m; window.__IXTRA = xm; window.__ISCALE = sm; done(); return; }
    Anouer.call("fm.item.types").then(l => { const m = {}, xm = {}, sm = {}, all = {}; (l || []).forEach(x => { try { if (x.extra) all[x.id] = JSON.parse(x.extra); } catch (e) { } }); window.__IXALL = all; (l || []).forEach(x => { m[x.id] = x.type || "stock"; if (x.type === "expiry") px(xm, x.extra, x.id); if (x.type === "scale") sx(sm, x.extra, x.id); }); window.__ITYPE = m; window.__IXTRA = xm; window.__ISCALE = sm; done(); }).catch(() => { });
  }
  setTimeout(loadTypes, 1500);
  setTimeout(() => { if (HOST()) uomSync(); }, 2500);
  /* «وحدات القياس» في الخصائص تعدّل نفس المصدر ← تحديث قائمة السهم ▾ */
  window.addEventListener("anouer:uom", () => { UOM_SYNC = null; try { LK.uom.refresh(); } catch (e) { } });   // نقل كل الوحدات إلى «وحدات القياس»

  /* ------------------------------------------------------------------ حذف / تنشيط من مراجعة الأصناف */
  function del(p) {
    const go = () => {
      if (!HOST()) { const P = PRODS(), i = P.indexOf(p); if (i >= 0) P.splice(i, 1); window.__irRender && __irRender(); T("تم حذف الصنف", "s"); return; }
      Anouer.call("fm.item.delete", { id: p.id }).then(() => { try { window.DelSound && DelSound.play(); } catch (e) { } T("تم حذف الصنف: " + p.name, "s"); return reloadAll(); }).catch(e => { say("لم يتم الحذف: " + (e.message || e), "e"); try { window.ANOUER_SOUND && ANOUER_SOUND("err"); } catch (x) { } });
    };
    if (typeof askConfirm === "function") askConfirm("هل تريد حذف الصنف «" + p.name + "» ؟", go); else if (confirm("حذف الصنف؟")) go();
  }
  function toggle(p) {
    if (p && p.active !== false && window.__deactBlock) { const m = __deactBlock(p); if (m) { say(m, "w"); try { window.ANOUER_SOUND && ANOUER_SOUND("err"); } catch (e) { } return; } }
    if (!HOST()) { p.active = p.active === false; window.__irRender && __irRender(); T((p.active ? "تم تنشيط " : "تم تعطيل ") + p.name, "s"); return; }
    Anouer.call("fm.item.get", { id: p.id }).then(r => {
      const it = r.item, act = !(it.active !== false);
      const doc = { Id: it.id, Code: it.code, Name: it.name, Type: it.type || "stock", Category: it.category || "", Active: act, Reorder: it.reorder || 0, Extra: it.extra || "",
        Units: (r.units || []).filter(u => u.active !== false || u.isBase).map(u => ({ Unit: u.unit, Factor: u.factor, Barcode: u.barcode || "", Cost: u.cost, Price: u.price, Retail: u.retail, Q5: u.q5, DefBuy: u.defBuy, DefSale: u.defSale, Active: u.active !== false })), Opening: null };
      let x = {}; try { x = it.extra ? JSON.parse(it.extra) : {}; } catch (e) { }
      if (x.open) doc.Opening = { Qty: +x.open.qty || 0, Unit: x.open.unit, Factor: +((r.units || []).find(u => u.unit === x.open.unit) || {}).factor || 1, Cost: +x.open.cost || 0, Date: x.open.date, WarehouseId: 0 };
      return Anouer.call("fm.item.save", doc).then(() => { T((act ? "تم تنشيط " : "تم تعطيل ") + it.name, "s"); return reloadAll(); });
    }).catch(e => say("تعذّر تغيير الحالة: " + (e.message || e), "e"));
  }

  /* ------------------------------------------------------------------ التصدير */
  /* استوديو الصورة: إضافة وحدة (علبة = N حبة) مع حساب الأسعار تلقائياً من الوحدة الأساسية */
  function addUnit(name, n) {
    n = +n || 0; if (n < 2 || S.units.some(r => nOf(r) === n)) return false;
    if (!S.units.some(r => nOf(r) === 1)) { const b0 = newRow("u", "حبة"); b0.n = "1"; b0.dB = b0.dS = true; b0.__auto = true; S.units.unshift(b0); }
    const r = newRow("u", name); r.n = String(n); S.units.push(r); try { autoRow(S.units.length - 1); } catch (e) { }
    renderUnits(); try { markAuto(); } catch (e) { } return true;
  }
  /* مكونات المجموعة / المنتج التام: كتابة سعر البيع و/أو التكلفة في الوحدة الأساسية (والوحدات الأكبر تُحسب تلقائياً) */
  function setBase(o) {
    o = o || {}; let i = S.units.findIndex(r => nOf(r) === 1);
    if (i < 0) { const b0 = newRow("u", "حبة"); b0.n = "1"; b0.dB = b0.dS = true; b0.__auto = true; S.units.unshift(b0); i = 0; }
    const b = S.units[i];
    if (o.price != null) b.price = fx(o.price);
    if (o.cost != null) b.cost = fx(o.cost);
    renderUnits(); try { if (o.price != null) autoFrom("price"); if (o.cost != null) autoFrom("cost"); markAuto(); } catch (e) { }
    return true;
  }
  /* قراءة QR / GS1: دفعة صلاحية في الرصيد الافتتاحي (+ تحويل النوع إلى «مخزون بصلاحية» عند الحاجة) */
  function addBatch(b) {
    b = b || {}; if (!b.exp && !b.lot) return false;
    if (b.toExpiry && S.type !== "expiry" && TY.expiry) { sel.value = "expiry"; applyType("expiry"); }
    const o = S.open || (S.open = { qty: 0, unit: "", cost: 0, date: today(), ledger: "الأرصدة الإفتتاحية", batches: [] });
    o.batches = (o.batches || []).filter(x => +x.qty > 0 || x.exp || x.lot);
    const same = o.batches.find(x => (x.lot || "") === (b.lot || "") && (x.exp || "") === (b.exp || ""));
    if (same) { if (b.qty) same.qty = (+same.qty || 0) + (+b.qty || 0); }
    else o.batches.push({ qty: +b.qty || 0, exp: b.exp || "", lot: b.lot || "" });
    o.qty = o.batches.reduce((t, x) => t + (+x.qty || 0), 0);
    try { openPaint(); } catch (e) { }
    if (b.open !== false) setTimeout(() => { try { if (!OPOP) openPop(); } catch (e) { } }, 60);
    return true;
  }
  /* باركود الوحدة الأساسية */
  function setBaseBc(code) {
    code = String(code || "").trim(); if (!code) return false;
    let i = S.units.findIndex(r => nOf(r) === 1);
    if (i < 0) { const b0 = newRow("u", "حبة"); b0.n = "1"; b0.dB = b0.dS = true; S.units.unshift(b0); i = 0; }
    S.units.forEach((r, j) => { if (j !== i && (r.bc || "").trim() === code) r.bc = ""; });
    S.units[i].bc = code; S.units[i].__auto = false; renderUnits(); return true;
  }
  window.ITC = { reset, load, save, type: () => applyType(sel.value), del, toggle, state: S, addUnit, setBase, addBatch, setBaseBc, loadTypes,
    setGroup: v => { GRP.close(); GRP.set(String(v || "").trim()); return GRP.get(); },   // تعيين المجموعة برمجياً (بلا فتح قائمة البحث)
    units: { render: () => { renderUnits(); try { markAuto(); } catch (e) { } openPaint(); }, row: newRow, fx, num } };
  reset();
})();
