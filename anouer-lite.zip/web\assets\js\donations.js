/* ANOUER — «التبرعات» (الإضافات ← 3-الخدمات) — مفعّلة — 2026
   حسب وصف DEXEF: «هي جهات خيرية يقوم العميل بالتبرع بباقي الفاتورة إلى إحدى هذه الجهات»
   ─ نافذة الدفع: تحت الخزائن «التبرع بالباقى» — الكسور / الباقى كله / مبلغ آخر ، واختيار الجهة الخيرية
   ─ مركز التبرعات: نظرة عامة ، الجهات الخيرية ، السجل ، تسليم المبالغ للجهات ، حاسبة الزكاة (النصاب)
   ─ الزكاة: النصاب = 85 غ ذهب عيار 24 × سعر الغرام ، الوعاء = البضاعة + النقد + الديون المرجوّة + أصول تجارية
     − الديون الحالّة − تبرعات العملاء المحتجزة (أمانة) ، القدر 2.5% (حول هجري) أو 2.577% (حول ميلادي)
   التخزين: الخصائص (Props) ← don.book (الجهات + الحركات) و don.zakat (بيانات الحاسبة) */
(function () {
  "use strict";
  if (window.__DON) return;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const r2 = n => Math.round((+n || 0) * 100) / 100;
  const N = n => r2(n).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const T = (m, k) => { try { toast(m, k || "i"); } catch (e) { } };
  const PR = () => window.ANOUER_PROPS;
  const HOST = () => !!(window.Anouer && Anouer.available);
  const ADD_DEF = ["disc", "qdisc", "bonus", "extra"];
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const nowIso = () => { const d = new Date(), p = n => String(n).padStart(2, "0"); return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " + p(d.getHours()) + ":" + p(d.getMinutes()); };
  const today = () => nowIso().slice(0, 10);
  const COLORS = ["#059669", "#0284c7", "#7c3aed", "#db2777", "#ea580c", "#0d9488", "#4f46e5", "#ca8a04"];
  const SEED = [{ id: "c1", name: "صندوق المسجد", color: "#059669", note: "", goal: 0, active: true }, { id: "c2", name: "كفالة الأيتام", color: "#0284c7", note: "", goal: 0, active: true }, { id: "c3", name: "مساعدة المرضى", color: "#db2777", note: "", goal: 0, active: true }];

  const enList = () => { try { return (PR() && PR().get("add.enabled", ADD_DEF)) || ADD_DEF; } catch (e) { return ADD_DEF; } };
  const on = () => enList().indexOf("don") >= 0 && (!(window.ANOUER_EDITION || {}).dist || !window.ANOUER_LIC || ANOUER_LIC.ok("donate"));   /* نسخة العملاء: تجربة شهر أو كود تفعيل */
  function setOn(v) { const l = enList().slice(), i = l.indexOf("don"); if (v && i < 0) l.push("don"); if (!v && i >= 0) l.splice(i, 1); return PR() ? PR().put("add.enabled", l) : Promise.resolve(); }
  const book = () => { const b = (PR() && PR().get("don.book", null)) || {}; b.ch = Array.isArray(b.ch) && b.ch.length ? b.ch : SEED.map(x => Object.assign({}, x)); b.tx = Array.isArray(b.tx) ? b.tx : []; return b; };
  const saveBook = b => { if (b.tx.length > 20000) b.tx = b.tx.slice(-20000); return PR() ? PR().put("don.book", b) : Promise.resolve(); };
  const chs = (b, all) => (b || book()).ch.filter(c => all || c.active !== false);
  const chById = (id, b) => (b || book()).ch.find(c => c.id === id) || null;
  const defCh = b => { const l = chs(b); const d = lsGetDef(); return l.find(c => c.id === d) || l[0] || null; };
  function lsGetDef() { try { return localStorage.getItem("don.last") || ""; } catch (e) { return ""; } }
  function lsSetDef(v) { try { localStorage.setItem("don.last", v); } catch (e) { } }
  /* أرصدة الجهات: محصّل (in) − مُسلَّم (out) */
  function chStat(b) {
    b = b || book(); const m = {};
    b.ch.forEach(c => { m[c.id] = { c, inn: 0, out: 0, n: 0, zak: 0, last: "" }; });
    b.tx.forEach(x => { const s = m[x.ch] || (m[x.ch] = { c: { id: x.ch, name: x.chName || "جهة محذوفة", color: "#94a3b8" }, inn: 0, out: 0, n: 0, zak: 0, last: "" });
      if (x.kind === "in") { s.inn += +x.amt || 0; s.n++; } else if (x.kind === "out") s.out += +x.amt || 0; else if (x.kind === "zakat") s.zak += +x.amt || 0; if (x.date > s.last) s.last = x.date; });
    Object.values(m).forEach(s => { s.held = r2(s.inn - s.out); });
    return m;
  }
  const heldTotal = b => Object.values(chStat(b)).reduce((s, x) => s + Math.max(0, x.held), 0);
  const ini = n => String(n || "?").trim().replace(/^(ال)/, "").charAt(0) || "?";
  const chip = (c, cls) => `<span class="dn-av ${cls || ""}" style="--c:${esc(c.color || "#059669")}">${esc(ini(c.name))}</span>`;

  /* ---------------- أيقونات ---------------- */
  const IC = {
    heart: '<svg viewBox="0 0 24 24"><path d="M12 20.5s-7.5-4.6-9.2-9.4C1.6 7.6 3.9 4 7.4 4c2 0 3.5 1.1 4.6 2.6C13.1 5.1 14.6 4 16.6 4c3.5 0 5.8 3.6 4.6 7.1-1.7 4.8-9.2 9.4-9.2 9.4z" fill="currentColor"/></svg>',
    hand: '<svg viewBox="0 0 24 24"><path d="M3 14h3l4 3h6a2 2 0 0 0 0-4h-4M6 14v6H3v-6M14 9.5c0-1.9-1.5-3.5-3.5-3.5S7 7.6 7 9.5c0 2.7 3.5 5 3.5 5s3.5-2.3 3.5-5z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    x: '<svg viewBox="0 0 14 14"><path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    list: '<svg viewBox="0 0 24 24"><path d="M8 6h12M8 12h12M8 18h12" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/><circle cx="4" cy="6" r="1.3" fill="currentColor"/><circle cx="4" cy="12" r="1.3" fill="currentColor"/><circle cx="4" cy="18" r="1.3" fill="currentColor"/></svg>',
    org: '<svg viewBox="0 0 24 24"><path d="M3 21h18M5 21V9l7-5 7 5v12M9 21v-6h6v6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    send: '<svg viewBox="0 0 24 24"><path d="M3 11.5L21 4l-7.5 18-2.3-7.7z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    moon: '<svg viewBox="0 0 24 24"><path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M17 3.5l.6 1.5 1.5.6-1.5.6-.6 1.5-.6-1.5-1.5-.6 1.5-.6z" fill="currentColor"/></svg>',
    plus: '<svg viewBox="0 0 16 16"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    edit: '<svg viewBox="0 0 16 16"><path d="M3 13l.8-3.2L10.5 3l2.5 2.5-6.8 6.7z" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>',
    ok: '<svg viewBox="0 0 16 16"><path d="M3.5 8.5l3 3 6-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };

  /* ================= نافذة الدفع: «التبرع بالباقى» تحت الخزائن ================= */
  let OKING = false;
  const curPaid = () => { try { return TREASURIES.reduce((s, x) => s + pNum(P.amt[x.id]), 0); } catch (e) { return 0; } };
  /* الباقى للعميل قبل التبرع (الإجمالي لا يشمل مبلغ التبرع) */
  const baseChange = () => { try { if (!P || !P.t) return 0; const d = +adj.donate || 0; return r2(curPaid() - (P.t.total - d)); } catch (e) { return 0; } };
  function applyDon(d, chId) {
    d = r2(Math.max(0, d)); const old = +adj.donate || 0;
    adj.extra = r2((+adj.extra || 0) - old + d); adj.donate = d || 0; if (d) { adj.donTo = chId || adj.donTo || (defCh() || {}).id; lsSetDef(adj.donTo); } else delete adj.donTo;
    try { P.t = calc(); payRender(); } catch (e) { }
  }
  function paySection() {
    let PP = null; try { PP = P; } catch (e) { } if (!on() || !PP) return "";
    let isRet = false; try { isRet = !!document.querySelector(".inv.retmode"); } catch (e) { }
    if (isRet) return "";
    const ch = baseChange(), d = +adj.donate || 0, b = book(), L = chs(b);
    if (!(ch > 0.004) && !d) return `<div class="dn-pay idle"><span class="ic">${IC.heart}</span><div><b>التبرع بالباقى</b><small>يظهر عندما يدفع العميل أكثر من المطلوب</small></div></div>`;
    const frac = r2(ch - Math.floor(ch + 1e-9)), r10 = r2(ch - Math.floor(ch / 10 + 1e-9) * 10), r100 = r2(ch - Math.floor(ch / 100 + 1e-9) * 100);
    const opts = []; const push = (v, t) => { v = r2(v); if (v > 0.004 && v <= ch + 1e-9 && !opts.some(o => o.v === v)) opts.push({ v, t }); };
    push(frac, "الكسور"); push(r10, "تقريب 10"); push(r100, "تقريب 100"); push(ch, "الباقى كله");
    const sel = chById(adj.donTo, b) || defCh(b);
    return `<div class="dn-pay${d ? " on" : ""}">
      <div class="dn-ph"><span class="ic">${IC.heart}</span><div class="t"><b>التبرع بالباقى</b><small>الباقى للعميل <em>${N(ch)}</em> DZD</small></div>${d ? `<span class="dn-tag">${IC.ok}تبرع ${N(d)}</span>` : ""}</div>
      <div class="dn-amts">${opts.map(o => `<button type="button" class="dn-a${Math.abs(o.v - d) < 0.005 ? " sel" : ""}" data-dv="${o.v}"><b>${N(o.v)}</b><small>${o.t}</small></button>`).join("")}
        <label class="dn-a cus${d && !opts.some(o => Math.abs(o.v - d) < 0.005) ? " sel" : ""}"><input type="number" min="0" max="${ch}" step="0.01" placeholder="مبلغ" value="${d && !opts.some(o => Math.abs(o.v - d) < 0.005) ? d : ""}" data-dc><small>مبلغ آخر</small></label>
        ${d ? `<button type="button" class="dn-a no" data-dv="0"><b>×</b><small>إلغاء</small></button>` : ""}</div>
      <div class="dn-chs">${L.map(c => `<button type="button" class="dn-c${sel && sel.id === c.id ? " sel" : ""}" data-dch="${esc(c.id)}" style="--c:${esc(c.color)}" title="${esc(c.name)}">${chip(c)}<span>${esc(c.name)}</span></button>`).join("") || '<small class="dn-mut">أضف جهة خيرية من «الإضافات ← التبرعات»</small>'}</div>
      ${d ? `<div class="dn-res">${IC.hand}<span>تبرع <b>${N(d)} DZD</b> لـ «${esc(sel ? sel.name : "")}» — الباقى الجديد للعميل <b>${N(r2(ch - d))}</b></span></div>` : ""}
    </div>`;
  }
  function hookPay() {
    if (typeof payRender !== "function" || payRender.__dn) return false;
    const pr = payRender; const w1 = function () { const r = pr.apply(this, arguments); try { decorate(); } catch (e) { console.error(e); } return r; }; w1.__dn = 1; window.payRender = w1; try { payRender = w1; } catch (e) { }
    const pok = window.payOk; if (typeof pok === "function") { const w2 = function () { OKING = true; try { return pok.apply(this, arguments); } finally { OKING = false; } }; window.payOk = w2; }
    const pc = window.payClose; if (typeof pc === "function") { const w3 = function () { if (!OKING && +adj.donate > 0) { try { adj.extra = r2((+adj.extra || 0) - (+adj.donate || 0)); adj.donate = 0; delete adj.donTo; } catch (e) { } } return pc.apply(this, arguments); }; window.payClose = w3; }
    const pl = $("payList");
    if (pl && !pl.__dn) {
      pl.__dn = 1;
      pl.addEventListener("click", e => {
        const a = e.target.closest("[data-dv]"); if (a) { e.stopPropagation(); applyDon(+a.dataset.dv); return; }
        const c = e.target.closest("[data-dch]"); if (c) { e.stopPropagation(); lsSetDef(c.dataset.dch); if (+adj.donate > 0) { adj.donTo = c.dataset.dch; try { payRender(); } catch (er) { } } else { const ch = baseChange(); if (ch > 0.004) applyDon(ch - Math.floor(ch + 1e-9) > 0.004 ? r2(ch - Math.floor(ch + 1e-9)) : ch, c.dataset.dch); else try { payRender(); } catch (er) { } } }
      });
      pl.addEventListener("change", e => { const i = e.target.closest("[data-dc]"); if (!i) return; const ch = baseChange(); applyDon(Math.min(+i.value || 0, ch)); });
    }
    return true;
  }
  /* لوحة الأرقام لا تكتب أثناء الكتابة في «مبلغ آخر» */
  window.addEventListener("keydown", e => { const t = e.target; if (!(t && t.matches && t.matches("[data-dc]"))) return; e.stopPropagation(); if (e.key === "Enter" || e.key === "Escape") { e.preventDefault(); t.blur(); } }, true);
  function decorate() {
    const pl = $("payList"); if (!pl) return;
    pl.querySelectorAll(".dn-pay").forEach(x => x.remove());
    const h = paySection(); if (h) pl.insertAdjacentHTML("beforeend", h);
    /* تلميح في الوضع المصغّر: «تبرّع بالباقى» يفتح الخزائن */
    const pay = $("pay"), tr = pay && pay.querySelector(".pay-tr"); if (!tr) return;
    let hint = pay.querySelector(".dn-hint"); const ch = baseChange(), show = on() && (ch > 0.004 || +adj.donate > 0) && !pay.classList.contains("exp");
    if (show) { if (!hint) { hint = document.createElement("button"); hint.type = "button"; hint.className = "dn-hint"; hint.onclick = () => { try { payToggle(); } catch (e) { } }; const ar = tr.querySelector("#payArw"); ar ? ar.before(hint) : tr.appendChild(hint); }
      hint.innerHTML = `${IC.heart}<span>${+adj.donate > 0 ? "تبرع " + N(adj.donate) + " DZD" : "تبرّع بالباقى (" + N(ch) + ")"}</span><i>◂</i>`; }
    else if (hint) hint.remove();
  }

  /* ================= الحفظ: تسجيل التبرع بعد نجاح حفظ الفاتورة ================= */
  let PEND = null, HOOKED = false;
  function hookAfterSave() { if (HOOKED) return; HOOKED = true; const prev = window.__sxAfterSave; window.__sxAfterSave = function (r) { try { if (PEND) { const p = PEND; PEND = null; commit(p, r && (r.invoiceNo || r.InvoiceNo)); } } catch (e) { console.error(e); } return prev ? prev.apply(this, arguments) : undefined; }; }
  function commit(p, no) {
    const b = book(), inv = String(no || p.no || ""), c = chById(p.ch, b) || defCh(b); if (!c) return;
    if (inv) b.tx = b.tx.filter(x => !(x.kind === "in" && x.inv === inv));
    b.tx.push({ id: uid(), kind: "in", ch: c.id, chName: c.name, amt: r2(p.amt), inv, cust: p.cust, date: nowIso(), note: "باقى فاتورة" });
    saveBook(b).then(() => thanks(p, c)).catch(e => T("تعذّر حفظ التبرع: " + (e.message || e), "e"));
  }
  function wrapSave() {
    if (typeof doSave !== "function" || doSave.__dn) return;
    const orig = doSave;
    const w = function () {
      let p = null;
      try { const d = +adj.donate || 0; if (d > 0 && !document.querySelector(".inv.retmode")) p = { amt: d, ch: adj.donTo || (defCh() || {}).id, cust: (($("custName") || {}).value || "").trim() || "تعامل نقدى", no: (($("invNo") || {}).value || "") }; } catch (e) { p = null; }
      const res = orig.apply(this, arguments);
      if (p) { if (HOST()) { hookAfterSave(); PEND = p; } else commit(p, p.no || "محلي"); }
      return res;
    };
    w.__dn = 1; doSave = w;
  }
  function thanks(p, c) {
    const d = document.createElement("div"); d.className = "dn-toast"; d.style.setProperty("--c", c.color || "#059669");
    d.innerHTML = `<span class="ic">${IC.heart}</span><div><b>جزاك الله خيراً</b><span>تبرع ${N(p.amt)} DZD لـ «${esc(c.name)}»</span></div>`;
    document.body.appendChild(d); requestAnimationFrame(() => d.classList.add("in")); setTimeout(() => { d.classList.remove("in"); setTimeout(() => d.remove(), 300); }, 3600);
  }

  /* ================= نافذة عامة ================= */
  function win(o) {
    const ov = document.createElement("div"); ov.className = "loy-ov dn-ov";
    ov.innerHTML = `<div class="loy-w dn-w ${o.cls || ""}" role="dialog" aria-label="${esc(o.title)}"><div class="loy-h"><span class="ic">${o.icon || IC.heart}</span><div class="t"><b>${esc(o.title)}</b>${o.sub ? `<small>${o.sub}</small>` : ""}</div><span class="sp"></span>${o.head || ""}<button type="button" class="x" data-x title="إغلاق (Esc)">${IC.x}</button></div><div class="loy-b">${o.body}</div>${o.foot ? `<div class="loy-f">${o.foot}</div>` : ""}</div>`;
    document.body.appendChild(ov); requestAnimationFrame(() => ov.classList.add("in"));
    const close = () => { ov.classList.remove("in"); document.removeEventListener("keydown", key, true); setTimeout(() => ov.remove(), 180); };
    const key = e => { if (e.key === "Escape") { if (document.querySelectorAll(".dn-ov").length > 1 && ov !== Array.from(document.querySelectorAll(".dn-ov")).pop()) return; e.preventDefault(); e.stopPropagation(); close(); } else if (e.key === "Enter" && o.onEnter && e.target.tagName !== "TEXTAREA" && e.target.tagName !== "BUTTON") { e.preventDefault(); e.stopPropagation(); o.onEnter(); } };
    document.addEventListener("keydown", key, true);
    ov.addEventListener("mousedown", e => { if (e.target === ov) close(); });
    ov.querySelector("[data-x]").onclick = close;
    return { el: ov, w: ov.querySelector(".loy-w"), close };
  }

  /* ================= مركز التبرعات ================= */
  const ZDEF = { gold: 0, grams: 85, year: "h", from: "", cash: 0, other: 0, debtsOn: 0, autoStock: true, stock: 0, autoRecv: true, recv: 0, holdOn: true };
  const zcfg = () => Object.assign({}, ZDEF, (PR() && PR().get("don.zakat", {})) || {});
  function stockValue() { try { return r2(products.reduce((s, p) => s + Math.max(0, +p.stock || 0) * Math.max(0, +p.cost || +p.lastBuy || 0), 0)); } catch (e) { return 0; } }
  function recvValue() { try { return r2((window.CUSTOMERS_DATA || []).reduce((s, c) => s + Math.max(0, +c.bal || 0), 0)); } catch (e) { return 0; } }

  function center(tab) {
    tab = tab || "home";
    const w = win({ title: "التبرعات", icon: IC.heart, cls: "loy-cn", sub: "جهات خيرية يتبرع لها العملاء بباقى الفاتورة — وحاسبة الزكاة",
      head: `<label class="loy-sw" title="تفعيل / إلغاء تفعيل الإضافة"><span class="lb"></span><input type="checkbox"${on() ? " checked" : ""}><i></i></label>`,
      body: `<div class="loy-tabs"><button type="button" data-t="home">${IC.heart}نظرة عامة</button><button type="button" data-t="org">${IC.org}الجهات الخيرية</button><button type="button" data-t="tx">${IC.list}السجل</button><button type="button" data-t="zakat">${IC.moon}الزكاة</button></div><div class="loy-pane"></div>`,
      foot: `<small class="loy-st"></small><span class="sp"></span><button type="button" class="loy-btn ghost" data-a="x">إغلاق</button>` });
    const pane = w.el.querySelector(".loy-pane"), sw = w.el.querySelector(".loy-sw input"), stt = w.el.querySelector(".loy-st");
    const paintSw = () => { w.el.querySelector(".loy-sw .lb").textContent = sw.checked ? "مفعّلة" : "غير مفعّلة"; w.w.classList.toggle("off", !sw.checked); stt.innerHTML = sw.checked ? "● الإضافة مفعّلة — يظهر «التبرع بالباقى» في نافذة الدفع تحت الخزائن" : "○ الإضافة غير مفعّلة"; };
    paintSw();
    sw.addEventListener("change", () => setOn(sw.checked).then(() => { paintSw(); T(sw.checked ? "✔ تم تفعيل «التبرعات»" : "تم إلغاء تفعيل «التبرعات»", "s"); }));
    w.el.querySelector('[data-a="x"]').onclick = w.close;
    let qt = "";
    const footBtn = (txt, fn) => { let b = w.el.querySelector(".dn-fb"); if (!b) { b = document.createElement("button"); b.type = "button"; b.className = "loy-btn pri dn-fb"; w.el.querySelector('.loy-f [data-a="x"]').before(b); } b.hidden = !txt; if (txt) { b.textContent = txt; b.onclick = fn; } };
    const draw = () => {
      w.el.querySelectorAll(".loy-tabs [data-t]").forEach(b => b.classList.toggle("on", b.dataset.t === tab));
      const b = book(), S = chStat(b), arr = Object.values(S);
      footBtn(null);
      if (tab === "home") {
        const inn = arr.reduce((s, x) => s + x.inn, 0), out = arr.reduce((s, x) => s + x.out, 0), held = arr.reduce((s, x) => s + Math.max(0, x.held), 0), n = b.tx.filter(x => x.kind === "in").length;
        const mon = today().slice(0, 7), mIn = b.tx.filter(x => x.kind === "in" && String(x.date).startsWith(mon)).reduce((s, x) => s + (+x.amt || 0), 0);
        pane.innerHTML = `<div class="loy-kpis">
            <div class="k g"><span class="i">${IC.heart}</span><small>إجمالي التبرعات</small><b>${N(inn)}</b><em>${N(n)} تبرع · DZD</em></div>
            <div class="k"><span class="i">${IC.moon}</span><small>هذا الشهر</small><b>${N(mIn)}</b><em>DZD</em></div>
            <div class="k b"><span class="i">${IC.send}</span><small>سُلِّم للجهات</small><b>${N(out)}</b><em>DZD</em></div>
            <div class="k o"><span class="i">${IC.hand}</span><small>أمانة لم تُسلَّم بعد</small><b>${N(held)}</b><em>DZD في الخزينة</em></div></div>
          <div class="dn-grid">${arr.filter(x => x.c.active !== false || x.inn).map(x => { const g = +x.c.goal || 0, pc = g ? Math.min(100, Math.round(x.inn / g * 100)) : 0; return `<div class="dn-card" style="--c:${esc(x.c.color)}">
            <div class="h">${chip(x.c, "lg")}<div><b>${esc(x.c.name)}</b><small>${N(x.n)} تبرع${x.last ? " · آخر تبرع " + esc(x.last.slice(0, 10)) : ""}</small></div></div>
            <div class="v"><div><small>المحصّل</small><b>${N(x.inn)}</b></div><div><small>المُسلَّم</small><b>${N(x.out)}</b></div><div class="hd"><small>الأمانة</small><b>${N(x.held)}</b></div></div>
            ${g ? `<div class="gl"><i style="width:${pc}%"></i></div><small class="gt">الهدف ${N(g)} DZD · ${pc}%</small>` : ""}
            <button type="button" class="dn-give" data-give="${esc(x.c.id)}"${x.held > 0.004 ? "" : " disabled"}>${IC.send}تسليم المبلغ للجهة</button></div>`; }).join("")}</div>`;
      } else if (tab === "org") {
        pane.innerHTML = `<div class="dn-orgs">${b.ch.map((c, i) => `<div class="dn-org${c.active === false ? " off" : ""}" data-i="${i}" style="--c:${esc(c.color)}">${chip(c, "lg")}
            <div class="f"><input class="nm" value="${esc(c.name)}" placeholder="اسم الجهة الخيرية"><input class="nt" value="${esc(c.note || "")}" placeholder="الهاتف / الحساب / ملاحظات"></div>
            <label class="gl">الهدف<input type="number" class="gv" min="0" value="${+c.goal || 0}"></label>
            <div class="cl">${COLORS.map(k => `<button type="button" class="sw${k === c.color ? " on" : ""}" data-col="${k}" style="background:${k}"></button>`).join("")}</div>
            <label class="loy-sw sm" title="نشطة"><input type="checkbox" class="ac"${c.active !== false ? " checked" : ""}><i></i></label></div>`).join("")}
          <button type="button" class="dn-add">${IC.plus}إضافة جهة خيرية</button></div>`;
        footBtn("حفظ الجهات", () => {
          const b2 = book(); pane.querySelectorAll(".dn-org").forEach(r => { const c = b2.ch[+r.dataset.i]; if (!c) return; c.name = r.querySelector(".nm").value.trim() || c.name; c.note = r.querySelector(".nt").value.trim(); c.goal = Math.max(0, +r.querySelector(".gv").value || 0); c.active = r.querySelector(".ac").checked; const s = r.querySelector(".sw.on"); if (s) c.color = s.dataset.col; });
          saveBook(b2).then(() => { T("✔ تم حفظ الجهات الخيرية", "s"); draw(); });
        });
        return;
      } else if (tab === "tx") {
        const KN = { in: ["تبرع", "g"], out: ["تسليم", "b"], zakat: ["زكاة", "o"] };
        const l = b.tx.slice().reverse().filter(x => !qt || (x.cust + " " + x.inv + " " + x.chName + " " + x.note).toLowerCase().includes(qt.toLowerCase()));
        pane.innerHTML = `<div class="loy-q"><input placeholder="بحث بالعميل أو الفاتورة أو الجهة…" value="${esc(qt)}"><small>${N(l.length)} حركة</small></div>
          <div class="loy-tbl tx dn-tx"><div class="th"><span>التاريخ</span><span>الجهة</span><span>الحركة</span><span>العميل</span><span>الفاتورة</span><span>المبلغ</span></div>
          ${l.slice(0, 500).map(x => { const k = KN[x.kind] || [x.kind, "b"], c = chById(x.ch, b) || { name: x.chName, color: "#94a3b8" }; return `<div class="tr"><span class="d">${esc(x.date)}</span><span class="nm"><b>${chip(c, "sm")} ${esc(c.name)}</b></span><span><i class="kd ${k[1]}">${k[0]}</i></span><span>${esc(x.cust || x.note || "—")}</span><span>${esc(x.inv || "—")}</span><span class="v ${x.kind === "in" ? "pos" : "neg"}">${N(x.amt)}</span></div>`; }).join("") || `<div class="loy-none">${IC.heart}<b>لا توجد تبرعات بعد</b><small>ستظهر هنا مع أول «تبرع بالباقى» من نافذة الدفع</small></div>`}</div>`;
        const qi = pane.querySelector(".loy-q input"); qi.oninput = () => { qt = qi.value; const p = qi.selectionStart; draw(); const n = pane.querySelector(".loy-q input"); n.focus(); n.setSelectionRange(p, p); };
      } else zakat(pane, b, footBtn, draw);
    };
    w.el.querySelector(".loy-tabs").addEventListener("click", e => { const t = e.target.closest("[data-t]"); if (t) { tab = t.dataset.t; draw(); } });
    pane.addEventListener("click", e => {
      const g = e.target.closest("[data-give]"); if (g) { give(g.dataset.give, draw); return; }
      const col = e.target.closest("[data-col]"); if (col) { const r = col.closest(".dn-org"); r.querySelectorAll(".sw").forEach(s => s.classList.toggle("on", s === col)); r.style.setProperty("--c", col.dataset.col); return; }
      if (e.target.closest(".dn-add")) { const b2 = book(); b2.ch.push({ id: "c" + uid(), name: "جهة خيرية " + (b2.ch.length + 1), color: COLORS[b2.ch.length % COLORS.length], note: "", goal: 0, active: true }); saveBook(b2).then(draw); }
    });
    draw();
  }
  /* تسليم الأمانة للجهة */
  function give(chId, done) {
    const b = book(), s = chStat(b)[chId]; if (!s) return;
    const w = win({ title: "تسليم التبرعات", icon: IC.send, cls: "loy-adj", sub: esc(s.c.name) + " · الأمانة " + N(s.held) + " DZD",
      body: `<label class="loy-fr"><span><b>المبلغ المُسلَّم</b></span><span class="in"><input type="number" class="a" min="0" max="${s.held}" step="0.01" value="${s.held}"></span></label><label class="loy-fr col"><span><b>ملاحظة / رقم الوصل</b></span><input class="n" placeholder="مثال: وصل رقم 15 — سُلّم لإمام المسجد"></label>`,
      foot: `<button type="button" class="loy-btn pri" data-a="ok">تسجيل التسليم</button><span class="sp"></span><button type="button" class="loy-btn ghost" data-a="x">إلغاء</button>`, onEnter: () => w.el.querySelector('[data-a="ok"]').click() });
    w.el.addEventListener("click", e => { const a = e.target.closest("[data-a]"); if (!a) return; if (a.dataset.a === "x") { w.close(); return; }
      const v = r2(Math.min(+w.el.querySelector(".a").value || 0, s.held)); if (!(v > 0)) { T("أدخل المبلغ", "w"); return; }
      const b2 = book(); b2.tx.push({ id: uid(), kind: "out", ch: chId, chName: s.c.name, amt: v, inv: "", cust: "", date: nowIso(), note: w.el.querySelector(".n").value.trim() || "تسليم للجهة" });
      saveBook(b2).then(() => { w.close(); T("✔ تم تسجيل تسليم " + N(v) + " DZD لـ «" + s.c.name + "»", "s"); done && done(); }); });
  }

  /* ================= الزكاة (النصاب) ================= */
  function zakat(pane, b, footBtn, redraw) {
    const Z = zcfg(), held = heldTotal(b);
    const sv = stockValue(), rv = recvValue();
    const yr = Z.year === "g" ? 0.025775 : 0.025;
    const paidZ = b.tx.filter(x => x.kind === "zakat" && (!Z.from || x.date >= Z.from)).reduce((s, x) => s + (+x.amt || 0), 0);
    const f = (k, t, h, v, dis) => `<label class="loy-fr"><span><b>${t}</b>${h ? `<small>${h}</small>` : ""}</span><span class="in"><input type="number" min="0" step="0.01" data-z="${k}" value="${v}"${dis ? " disabled" : ""}></span></label>`;
    pane.innerHTML = `<div class="zk">
      <div class="zk-in">
        <h4>${IC.moon} النصاب</h4>
        ${f("gold", "سعر غرام الذهب عيار 24 (DZD)", "أدخل سعر اليوم", Z.gold)}
        ${f("grams", "نصاب الذهب (غرام)", "85 غرام عند الجمهور", Z.grams)}
        <label class="loy-fr"><span><b>الحول</b></span><span class="in"><select data-z="year"><option value="h"${Z.year !== "g" ? " selected" : ""}>هجري — 2.5%</option><option value="g"${Z.year === "g" ? " selected" : ""}>ميلادي — 2.577%</option></select></span></label>
        <label class="loy-fr"><span><b>بداية الحول</b><small>لحساب ما أُخرج خلال الحول</small></span><span class="in"><input type="date" data-z="from" value="${esc(Z.from)}"></span></label>
        <h4>الأموال الزكوية</h4>
        <label class="loy-fr"><span><b>البضاعة (عروض التجارة)</b><small>الرصيد × سعر التكلفة — ${Z.autoStock ? "محسوب تلقائياً" : "يدوي"}</small></span><span class="in zk-auto"><input type="number" min="0" data-z="stock" value="${Z.autoStock ? sv : Z.stock}"${Z.autoStock ? " disabled" : ""}><label><input type="checkbox" data-z="autoStock"${Z.autoStock ? " checked" : ""}>تلقائي</label></span></label>
        ${f("cash", "النقد في الخزائن والبنوك", "", Z.cash)}
        <label class="loy-fr"><span><b>الديون المرجوّة على العملاء</b><small>${Z.autoRecv ? "من أرصدة العملاء" : "يدوي"}</small></span><span class="in zk-auto"><input type="number" min="0" data-z="recv" value="${Z.autoRecv ? rv : Z.recv}"${Z.autoRecv ? " disabled" : ""}><label><input type="checkbox" data-z="autoRecv"${Z.autoRecv ? " checked" : ""}>تلقائي</label></span></label>
        ${f("other", "أموال تجارية أخرى", "", Z.other)}
        <h4>الخصوم</h4>
        ${f("debtsOn", "ديون حالّة على المحل", "للموردين وغيرهم", Z.debtsOn)}
        <label class="loy-fr"><span><b>تبرعات العملاء المحتجزة</b><small>أمانة للجهات الخيرية — ليست من مال المحل</small></span><span class="in zk-auto"><input type="number" value="${held}" disabled><label><input type="checkbox" data-z="holdOn"${Z.holdOn ? " checked" : ""}>خصم</label></span></label>
      </div>
      <div class="zk-out"></div></div>`;
    const read = () => { const z = zcfg(); pane.querySelectorAll("[data-z]").forEach(i => { const k = i.dataset.z; if (i.type === "checkbox") z[k] = i.checked; else if (i.tagName === "SELECT" || i.type === "date") z[k] = i.value; else if (!i.disabled) z[k] = Math.max(0, +i.value || 0); }); return z; };
    const calcOut = () => {
      const z = read(), y = z.year === "g" ? 0.025775 : 0.025;
      const st = z.autoStock ? sv : +z.stock || 0, rc = z.autoRecv ? rv : +z.recv || 0;
      const assets = st + (+z.cash || 0) + rc + (+z.other || 0), debts = (+z.debtsOn || 0) + (z.holdOn ? held : 0), base = Math.max(0, assets - debts);
      const nisab = (+z.gold || 0) * (+z.grams || 0), reach = nisab > 0 && base >= nisab, due = reach ? base * y : 0, rest = Math.max(0, due - paidZ);
      const pct = nisab > 0 ? Math.min(100, Math.round(base / nisab * 100)) : 0;
      pane.querySelector(".zk-out").innerHTML = `
        <div class="zk-card ${!nisab ? "na" : reach ? "ok" : "no"}">
          <small>${!nisab ? "أدخل سعر غرام الذهب" : reach ? "بلغ المال النصاب — تجب الزكاة" : "لم يبلغ المال النصاب"}</small>
          <b>${N(due)}</b><em>DZD زكاة مستحقة (${(y * 100).toFixed(y === 0.025 ? 1 : 3)}%)</em>
          <div class="zk-bar"><i style="width:${pct}%"></i></div><span class="zk-bl">الوعاء ${pct >= 100 ? "≥" : pct + "% من"} النصاب</span></div>
        <div class="zk-lines">
          <div><span>النصاب (${N(z.grams)} غ × ${N(z.gold)})</span><b>${N(nisab)}</b></div>
          <div><span>مجموع الأموال الزكوية</span><b>${N(assets)}</b></div>
          <div class="neg"><span>الخصوم</span><b>− ${N(debts)}</b></div>
          <div class="tot"><span>الوعاء الزكوي</span><b>${N(base)}</b></div>
          <div><span>أُخرج خلال الحول</span><b>${N(paidZ)}</b></div>
          <div class="tot g"><span>المتبقي إخراجه</span><b>${N(rest)}</b></div></div>
        <button type="button" class="dn-give" data-zpay${due > 0 ? "" : " disabled"}>${IC.hand}تسجيل إخراج زكاة</button>
        <p class="zk-note">تبرعات العملاء أمانة تُسلَّم لجهاتها ولا تُحسب من زكاة المحل. الحساب تقريبي للتجار (عروض التجارة) — يُستحسن مراجعة أهل العلم في الحالات الخاصة.</p>`;
      return z;
    };
    calcOut();
    pane.addEventListener("input", e => { if (e.target.closest("[data-z]")) calcOut(); });
    pane.addEventListener("change", e => { const i = e.target.closest("[data-z]"); if (!i) return; if (i.type === "checkbox" && /auto/.test(i.dataset.z)) { const z = read(); if (PR()) PR().put("don.zakat", z).then(redraw); return; } calcOut(); });
    pane.onclick = e => { if (e.target.closest("[data-zpay]")) zpay(redraw); };
    footBtn("حفظ بيانات الزكاة", () => { const z = read(); if (PR()) PR().put("don.zakat", z).then(() => T("✔ تم حفظ بيانات الزكاة", "s")); });
  }
  function zpay(done) {
    const b = book(), L = chs(b);
    const w = win({ title: "إخراج زكاة", icon: IC.moon, cls: "loy-adj", sub: "من مال المحل",
      body: `<label class="loy-fr"><span><b>المبلغ</b></span><span class="in"><input type="number" class="a" min="0" step="0.01"></span></label>
        <label class="loy-fr"><span><b>الجهة / المستحق</b></span><span class="in"><select class="c">${L.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join("")}<option value="">مستحق آخر</option></select></span></label>
        <label class="loy-fr col"><span><b>ملاحظة</b></span><input class="n" placeholder="مثال: زكاة رمضان 1448"></label>`,
      foot: `<button type="button" class="loy-btn pri" data-a="ok">تسجيل</button><span class="sp"></span><button type="button" class="loy-btn ghost" data-a="x">إلغاء</button>`, onEnter: () => w.el.querySelector('[data-a="ok"]').click() });
    setTimeout(() => w.el.querySelector(".a").focus(), 40);
    w.el.addEventListener("click", e => { const a = e.target.closest("[data-a]"); if (!a) return; if (a.dataset.a === "x") { w.close(); return; }
      const v = r2(+w.el.querySelector(".a").value || 0); if (!(v > 0)) { T("أدخل المبلغ", "w"); return; }
      const cid = w.el.querySelector(".c").value, c = chById(cid, b);
      const b2 = book(); b2.tx.push({ id: uid(), kind: "zakat", ch: cid || "z", chName: c ? c.name : "مستحق", amt: v, inv: "", cust: "", date: nowIso(), note: w.el.querySelector(".n").value.trim() || "إخراج زكاة" });
      saveBook(b2).then(() => { w.close(); T("✔ تقبّل الله — سُجّل إخراج زكاة " + N(v) + " DZD", "s"); done && done(); }); });
  }

  /* ---------------- لوحة الإضافات + قائمة «الإضافات» ---------------- */
  document.addEventListener("click", e => { const c = e.target.closest && e.target.closest('.pp-card[data-a="don"]'); if (!c) return; e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); center(); }, true);
  new MutationObserver(() => { const c = document.querySelector('.pp-card[data-a="don"]:not([data-dn])'); if (!c) return; c.dataset.dn = 1; c.classList.add("loy-addon"); c.insertAdjacentHTML("beforeend", `<span class="loy-badge dn-badge${on() ? "" : " off"}">${IC.heart}${on() ? "مفعّلة" : "غير مفعّلة"}</span>`); })
    .observe(document.body, { childList: true, subtree: true });
  function addMenu() {
    const M = window.__MENUS, A = M && M["الإضافات"]; if (!A) return false;
    if (A.some(i => i.t === "التبرعات")) return true;
    try { if (window.__NAVIC) window.__NAVIC.don = '<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="8.6" fill="#d1fae5"/><path d="M10 15.6s-5-3-6.1-6.2C3.1 7 4.6 4.7 7 4.7c1.3 0 2.3.7 3 1.7.7-1 1.7-1.7 3-1.7 2.4 0 3.9 2.3 3.1 4.7-1.1 3.2-6.1 6.2-6.1 6.2z" fill="#059669"/></svg>'; } catch (e) { }
    const k = A.findIndex(x => x.t === "نقاط الولاء"), k2 = A.findIndex(x => x.t === "كوبونات الخصم");
    A.splice(k >= 0 ? k + 1 : k2 >= 0 ? k2 + 1 : A.length, 0, { t: "التبرعات", ic: "don", run: () => center() });
    return true;
  }
  function boot() {
    wrapSave(); hookPay();
    if (!addMenu()) { let n = 0; const iv = setInterval(() => { if (addMenu() || ++n > 20) clearInterval(iv); }, 500); }
    const P0 = PR(); if (!P0) return;
    Promise.resolve(P0.load ? P0.load() : null).then(() => { if (!P0.get("don.init", false)) { P0.put("don.init", true); if (!P0.get("don.book", null)) saveBook(book()); setOn(true); } }).catch(() => { });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => setTimeout(boot, 50)); else setTimeout(boot, 50);

  window.__DON = { on, center, book, stat: chStat, held: heldTotal, applyDon };
})();
