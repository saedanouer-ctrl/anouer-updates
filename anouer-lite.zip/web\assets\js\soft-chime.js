/* ANOUER — نغمات هادئة 2026 (مُولَّدة بالكامل بـ Web Audio — بدون ملفات ولا حقوق)
   ─ «slice»   : تطبيق شريحة خصم (يدوي أو تلقائي) ← أربيجيو جرس ناعم صاعد (Cmaj9)
   ─ «expense» : سطر مصروف جديد يدخل الفاتورة (مبيعات / مشتريات) ← «قطرة ناعمة» + دخول السطر بانسياب
   صوت ناعم: هجوم بطيء قليلاً ، ذيل يتلاشى ، صدى غرفة خفيف ، ومستوى منخفض لا يزعج الزبون.
   الإعدادات: الخصائص ← طريقة العرض ← النغمات (تشغيل/إيقاف + اختيار النغمة لكل حدث) */
(function () {
  "use strict";
  if (window.ANOUER_CHIME) return;
  let AC = null, OUT = null, REV = null, DLY = null;
  const LAST = {};
  function ctx() {
    if (AC) { if (AC.state === "suspended") AC.resume().catch(() => { }); return AC; }
    const C = window.AudioContext || window.webkitAudioContext; if (!C) return null;
    AC = new C();
    /* السلسلة: صوت ← (جاف + صدى) ← فلتر ناعم ← ضاغط لطيف ← المخرج */
    const lp = AC.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 7200; lp.Q.value = 0.4;
    const cp = AC.createDynamicsCompressor(); cp.threshold.value = -18; cp.knee.value = 12; cp.ratio.value = 3; cp.attack.value = 0.01; cp.release.value = 0.3;
    OUT = AC.createGain(); OUT.gain.value = 0.9;
    OUT.connect(lp); lp.connect(cp); cp.connect(AC.destination);
    /* صدى غرفة: استجابة نبضية من ضجيج يتلاشى (1.6 ث) */
    const len = Math.floor(AC.sampleRate * 1.6), ir = AC.createBuffer(2, len, AC.sampleRate);
    for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); let lpv = 0; for (let i = 0; i < len; i++) { const n = Math.random() * 2 - 1; lpv = lpv * 0.82 + n * 0.18; d[i] = lpv * Math.pow(1 - i / len, 2.6); } }
    const cv = AC.createConvolver(); cv.buffer = ir; REV = AC.createGain(); REV.gain.value = 0.32;
    REV.connect(cv); cv.connect(OUT);
    /* تأخير «بينغ-بونغ» ستيريو ناعم (يمين/يسار) — يعطي اتساعاً عصرياً */
    const mg = AC.createChannelMerger(2), dL = AC.createDelay(1), dR = AC.createDelay(1), fb = AC.createGain(), dlp = AC.createBiquadFilter();
    dL.delayTime.value = 0.19; dR.delayTime.value = 0.19; fb.gain.value = 0.32; dlp.type = "lowpass"; dlp.frequency.value = 3800;
    DLY = AC.createGain(); DLY.gain.value = 0.22;
    DLY.connect(dlp); dlp.connect(dL); dL.connect(dR); dR.connect(fb); fb.connect(dL);
    dL.connect(mg, 0, 0); dR.connect(mg, 0, 1); mg.connect(OUT);
    return AC;
  }
  /* نوتة جرس/ماريمبا: جيبية أساسية + هارمونيات خفيفة ، هجوم 6–12 مللي ، تلاشٍ أُسّي */
  function note(f, t, dur, vel, o) {
    o = o || {}; const a = AC, g = a.createGain(), dry = a.createGain(), pan = a.createStereoPanner ? a.createStereoPanner() : null;
    const parts = o.parts || [[1, 1], [2, 0.22], [3.01, 0.07], [4.2, 0.025]];
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vel, t + (o.atk || 0.009));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    parts.forEach(([m, amp], i) => {
      const os = a.createOscillator(), og = a.createGain(); os.type = "sine"; os.frequency.value = f * m; if (i === 0 && o.det) os.detune.value = o.det;
      og.gain.value = amp; og.gain.setTargetAtTime(amp * (i ? 0.25 : 1), t + 0.02, i ? 0.08 : dur);   /* الهارمونيات تخفت أسرع ← صوت دافئ */
      os.connect(og); og.connect(g); os.start(t); os.stop(t + dur + 0.05);
    });
    dry.gain.value = 1; g.connect(dry);
    if (pan) { pan.pan.value = o.pan || 0; dry.connect(pan); pan.connect(OUT); } else dry.connect(OUT);
    const w = a.createGain(); w.gain.value = o.wet == null ? 1 : o.wet; g.connect(w); w.connect(REV);
  }
  /* جرس زجاجي FM: حامل جيبي + مُعدِّل بنسبة 3.5 يخفت ← لمعة في البداية ثم صفاء */
  function glass(f, t, dur, vel, o) {
    o = o || {}; const a = AC, car = a.createOscillator(), mod = a.createOscillator(), mg = a.createGain(), g = a.createGain(), p = a.createStereoPanner ? a.createStereoPanner() : null;
    car.frequency.value = f; mod.frequency.value = f * (o.ratio || 3.5);
    mg.gain.setValueAtTime(f * (o.idx || 2.2), t); mg.gain.exponentialRampToValueAtTime(f * 0.02, t + (o.bright || 0.35));
    mod.connect(mg); mg.connect(car.frequency);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vel, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    car.connect(g); if (p) { p.pan.value = o.pan || 0; g.connect(p); p.connect(OUT); } else g.connect(OUT);
    const w = a.createGain(); w.gain.value = o.wet == null ? 0.9 : o.wet; g.connect(w); w.connect(REV);
    if (o.dly) { const d = a.createGain(); d.gain.value = o.dly; g.connect(d); d.connect(DLY); }
    car.start(t); mod.start(t); car.stop(t + dur + 0.05); mod.stop(t + dur + 0.05);
  }
  /* وسادة دافئة: مثلثان منحرفان قليلاً + فلتر يفتح ثم يغلق */
  function pad(fs, t, dur, vel) {
    const a = AC, g = a.createGain(), lp = a.createBiquadFilter(); lp.type = "lowpass"; lp.Q.value = 0.7;
    lp.frequency.setValueAtTime(400, t); lp.frequency.linearRampToValueAtTime(2200, t + dur * 0.35); lp.frequency.exponentialRampToValueAtTime(500, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vel, t + 0.16); g.gain.setValueAtTime(vel, t + dur * 0.4); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    fs.forEach(f => [-7, 7].forEach(dt => { const o = a.createOscillator(); o.type = "triangle"; o.frequency.value = f; o.detune.value = dt; o.connect(lp); o.start(t); o.stop(t + dur + 0.05); }));
    lp.connect(g); g.connect(OUT); const w = a.createGain(); w.gain.value = 0.7; g.connect(w); w.connect(REV);
  }
  /* قطرة: جيبية تنزلق من الأعلى ← «بلوب» ناعم */
  function drop(f0, f1, t, dur, vel, pan) {
    const a = AC, o = a.createOscillator(), g = a.createGain(), p = a.createStereoPanner ? a.createStereoPanner() : null;
    o.type = "sine"; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + 0.045);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vel, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); if (p) { p.pan.value = pan || 0; g.connect(p); p.connect(OUT); } else g.connect(OUT);
    const w = a.createGain(); w.gain.value = 0.8; g.connect(w); w.connect(REV); const d = a.createGain(); d.gain.value = 0.28; g.connect(d); d.connect(DLY);
    o.start(t); o.stop(t + dur + 0.05);
  }
  /* نفَس هوائي: ضجيج بفلتر تمرير حزمة ينزلق */
  function air(t, dur, vel, f0, f1) {
    const a = AC, n = a.sampleRate * dur | 0, b = a.createBuffer(1, n, a.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    const s = a.createBufferSource(), bp = a.createBiquadFilter(), g = a.createGain(); s.buffer = b; bp.type = "bandpass"; bp.Q.value = 1.4;
    bp.frequency.setValueAtTime(f0, t); bp.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vel, t + dur * 0.4); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(bp); bp.connect(g); g.connect(OUT); const w = a.createGain(); w.gain.value = 0.6; g.connect(w); w.connect(REV); s.start(t); s.stop(t + dur);
  }
  const SONGS = {
    /* ✦ «Glass Rise» — شريحة: نفَس صاعد ، وسادة Dmaj ، أربيجيو جرس زجاجي D5 F#5 A5 C#6 E6 بتأخير ستيريو ، ولمعة أخيرة */
    slice2: t => { air(t, 0.34, 0.035, 900, 5200); pad([293.66, 440, 554.37], t + 0.06, 1.5, 0.045);
      [[587.33, -.35], [739.99, -.15], [880, .05], [1108.73, .22], [1318.51, .38]].forEach((n, i) => glass(n[0], t + 0.1 + i * 0.058, 1.4 - i * 0.08, 0.085 - i * 0.008, { pan: n[1], dly: i === 4 ? 0.7 : 0.25, idx: 1.8 }));
      glass(2637, t + 0.46, 1.2, 0.018, { pan: .45, idx: .8, bright: .2, dly: 0.9, wet: 1.4 }); },
    /* ✦ «Soft Drop» — مصروف: قطرتان (G5 ← D6) + نبضة دافئة منخفضة + نفَس قصير */
    expense2: t => { drop(1568, 784, t, 0.34, 0.24, -.2); drop(2349, 1175, t + 0.075, 0.45, 0.2, .2);
      glass(392, t, 0.55, 0.08, { ratio: 1, idx: 0.6, bright: .1, wet: .5 }); air(t + 0.02, 0.14, 0.03, 4200, 2400);
      glass(2349.3, t + 0.16, 0.9, 0.014, { idx: .5, pan: .3, dly: 0.8, wet: 1.2 }); },

    /* شريحة: E5 G5 B5 D6 — صاعد ، والأخيرة تطول */
    slice: t => { [[659.25, 0, 1.1, .16, -.25], [783.99, .075, 1.1, .14, -.08], [987.77, .15, 1.2, .13, .1], [1174.66, .225, 1.8, .12, .25]].forEach(n => note(n[0], t + n[1], n[2], n[3], { pan: n[4] }));
      note(2349.3, t + .3, 1.4, .025, { parts: [[1, 1]], atk: .04, wet: 1.6 }); },
    /* مصروف: A5 → E6 ماريمبا + لمعة */
    expense: t => { const mar = [[1, 1], [3.98, 0.12], [9.2, 0.02]];
      note(880, t, .55, .17, { parts: mar, pan: -.15 }); note(1318.5, t + .085, .9, .15, { parts: mar, pan: .15 });
      note(2637, t + .16, 1.1, .022, { parts: [[1, 1]], atk: .03, wet: 1.5 }); }
  };
  /* الإعدادات (الخصائص ← طريقة العرض ← النغمات): لكل حدث مفتاح تشغيل + اختيار النغمة */
  const VG = () => { try { return (window.ANOUER_PROPS && ANOUER_PROPS.get("view.gen", {})) || {}; } catch (e) { return {}; } };
  const EV = { slice: ["chSliceOn", "chSlice", "slice2"], expense: ["chExpOn", "chExp", "expense2"] };
  function render(name) { if (!SONGS[name]) return; try { const a = ctx(); if (!a) return; SONGS[name](a.currentTime + 0.02); } catch (e) { } }
  function play(kind, el) {
    const m = EV[kind]; if (!m) return; const v = VG();
    const now = Date.now(); if (now - (LAST[kind] || 0) < 380) return; LAST[kind] = now;
    fx(kind, el);   /* الحركة تبدأ مع أول نوتة — متناسقة مع النغمة */
    if (v.sChimeOn === false || v[m[0]] === false) return;
    render(SONGS[v[m[1]]] ? v[m[1]] : m[2]);
  }

  /* ---------- الحركة المرافقة (نفس توقيت النوتات) ---------- */
  const CSS = `.chm-sl{position:relative;animation:chmPop .55s cubic-bezier(.2,1.5,.4,1) both;z-index:2}
  .chm-sl::after{content:"";position:absolute;inset:-4px;border-radius:inherit;border-radius:999px;pointer-events:none;box-shadow:0 0 0 0 rgba(139,92,246,.55),0 0 18px 2px rgba(236,72,153,.35);animation:chmRing 1.3s ease-out both}
  @keyframes chmPop{0%{transform:scale(1)}35%{transform:scale(1.09)}100%{transform:scale(1)}}
  @keyframes chmRing{0%{box-shadow:0 0 0 0 rgba(139,92,246,.6),0 0 22px 4px rgba(236,72,153,.45)}100%{box-shadow:0 0 0 14px rgba(139,92,246,0),0 0 0 0 rgba(236,72,153,0)}}
  .chm-sp{position:fixed;z-index:99999;width:9px;height:9px;margin:-4.5px 0 0 -4.5px;pointer-events:none;border-radius:2px;transform:rotate(45deg);background:linear-gradient(135deg,#fff,var(--c));box-shadow:0 0 10px var(--c);animation:chmSp .95s cubic-bezier(.2,.8,.3,1) both}
  @keyframes chmSp{0%{opacity:0;transform:translate(0,0) rotate(45deg) scale(.3)}18%{opacity:1}100%{opacity:0;transform:translate(var(--x),var(--y)) rotate(225deg) scale(.6)}}
  .chm-row{animation:chmIn .5s cubic-bezier(.2,1.2,.35,1) both;position:relative}
  .chm-row::before{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(90deg,transparent,rgba(16,185,129,.22) 45%,rgba(99,102,241,.18) 55%,transparent);background-size:220% 100%;animation:chmSweep .9s .05s ease-out both;border-radius:4px}
  @keyframes chmIn{0%{transform:translateX(-14px);opacity:.35}100%{transform:none;opacity:1}}
  @keyframes chmSweep{0%{background-position:120% 0;opacity:1}100%{background-position:-120% 0;opacity:0}}
  .chm-drop{position:fixed;z-index:99999;width:12px;height:12px;margin:-6px 0 0 -6px;border-radius:50%;pointer-events:none;border:2px solid #10b981;animation:chmDrop .7s ease-out both}
  @keyframes chmDrop{0%{opacity:.9;transform:scale(.2)}100%{opacity:0;transform:scale(3.4)}}
  @media (prefers-reduced-motion:reduce){.chm-sl,.chm-sl::after,.chm-row,.chm-row::before,.chm-sp,.chm-drop{animation:none!important}}`;
  let cssOn = false;
  const addCss = () => { if (cssOn) return; cssOn = true; const st = document.createElement("style"); st.textContent = CSS; document.head.appendChild(st); };
  const vis = e => !!(e && e.offsetParent);
  const retrig = (e, c, ms) => { e.classList.remove(c); void e.offsetWidth; e.classList.add(c); clearTimeout(e["_" + c]); e["_" + c] = setTimeout(() => e.classList.remove(c), ms); };
  function fx(kind, el) {
    try {
      addCss();
      if (kind === "slice") {
        const t = (vis(el) && el) || [...document.querySelectorAll(".slp-btn")].find(vis) || [...document.querySelectorAll('select[data-f="slice"]')].find(vis); if (!t) return;
        retrig(t, "chm-sl", 1400);
        /* 5 شرارات مع النوتات الخمس (0.1 + i × 0.058 ث) — ألوان التدرج البنفسجي/الوردي */
        const r = t.getBoundingClientRect(), C = ["#a78bfa", "#8b5cf6", "#ec4899", "#f472b6", "#fbbf24"];
        for (let i = 0; i < 7; i++) setTimeout(() => { const s = document.createElement("i"); s.className = "chm-sp"; const a = -Math.PI * (0.15 + 0.7 * (i / 6)) , d = 34 + (i % 3) * 12;
          s.style.left = (r.left + r.width / 2) + "px"; s.style.top = (r.top + r.height / 2) + "px"; s.style.setProperty("--x", Math.cos(a) * d + "px"); s.style.setProperty("--y", Math.sin(a) * d + "px"); s.style.setProperty("--c", C[i % C.length]);
          document.body.appendChild(s); setTimeout(() => s.remove(), 1000); }, 100 + i * 50);
      } else if (kind === "expense") {
        const row = vis(el) ? el : null; if (!row) return;
        retrig(row, "chm-row", 1000);
        /* حلقتا «قطرة» على خانة القيمة مع القطرتين (0 و 0.075 ث) */
        const a = row.querySelector('[data-e="name"]') || row.querySelector('[data-e="amt"]') || row, r = a.getBoundingClientRect();
        [0, 75].forEach((d, i) => setTimeout(() => { const s = document.createElement("i"); s.className = "chm-drop"; s.style.left = (r.left + r.width * (i ? .7 : .35)) + "px"; s.style.top = (r.top + r.height / 2) + "px"; if (i) s.style.borderColor = "#6366f1";
          document.body.appendChild(s); setTimeout(() => s.remove(), 760); }, d));
      }
    } catch (e) { }
  }
  window.ANOUER_CHIMES = [["slice2", "زجاجي صاعد ✦ احترافي"], ["expense2", "قطرة ناعمة ✦ احترافي"], ["slice", "جرس ناعم"], ["expense", "ماريمبا دافئة"]];
  window.ANOUER_CHIME_PREVIEW = render;
  window.ANOUER_CHIME = play;
  /* تهيئة الصوت مع أول نقرة / ضغطة زر (سياسة التشغيل التلقائي في WebView2 / Chrome) — حتى تُسمع النغمة فوراً لاحقاً */
  const warm = () => { try { ctx(); } catch (e) { } };
  ["pointerdown", "keydown"].forEach(ev => document.addEventListener(ev, warm, { capture: true, passive: true }));

  /* ---------- المصروفات (المبيعات .sx-exps · المشتريات .pu-exps): سطر مصروف جديد يدخل الجدول ← نغمة + حركة ----------
     يُكتشف عند الكتابة أو الاختيار من القائمة في «Click here to add a new row» (الحدث input على newName) ،
     سواء كُتب الاسم أو اختير من القائمة المنسدلة (مع قيمته الافتراضية المحفوظة) */
  const hostOf = t => t && t.closest && t.closest(".pu-exps, .sx-exps");
  document.addEventListener("input", e => {
    const t = e.target, h = hostOf(t); if (!h || !t.dataset || t.dataset.e !== "newName" || !t.value.trim()) return;
    const n0 = h.querySelectorAll(".pu-er[data-i]").length;
    setTimeout(() => { const rows = h.querySelectorAll(".pu-er[data-i]"); if (rows.length <= n0) return;
      let last = rows[0]; rows.forEach(r => { if (+r.dataset.i > +last.dataset.i) last = r; });
      (window.ANOUER_CHIME || play)("expense", last); }, 60);
  }, true);

  /* تغيير قيمة مصروف موجود (عند اعتمادها) ← نفس النغمة والحركة مرة أخرى */
  const numOf = v => { const x = parseFloat(String(v || "").replace(/[^\d.\-]/g, "")); return isFinite(x) ? x : 0; };
  document.addEventListener("focusin", e => { const t = e.target; if (hostOf(t) && t.dataset && t.dataset.e === "amt") t.__chv0 = numOf(t.value); }, true);
  document.addEventListener("change", e => {
    const t = e.target, h = hostOf(t); if (!h || !t.dataset || t.dataset.e !== "amt") return;
    const v = numOf(t.value); if (!(v > 0) || v === t.__chv0) return; t.__chv0 = v;
    const er = t.closest(".pu-er[data-i]"), ix = er ? er.dataset.i : null; if (ix == null) return;
    setTimeout(() => (window.ANOUER_CHIME || play)("expense", h.querySelector('.pu-er[data-i="' + ix + '"]')), 70);
  }, true);

  /* ---------- شرائح المشتريات: اختيار شريحة ← نغمة ---------- */
  document.addEventListener("change", e => { const t = e.target; if (t && t.matches && t.matches('select[data-f="slice"]') && +t.value > 0) (window.ANOUER_CHIME || play)("slice", t); }, true);
})();
