/* ==========================================================================
   قراءة QR / باركود الصنف — ANOUER
   مربع بجانب «حفظ» في بطاقة الصنف. يقرأ:
     • قارئ الباركود (USB / Bluetooth) — يكتب الرمز كلوحة مفاتيح
     • كاميرا الحاسوب (QR · DataMatrix · EAN · Code128) — BarcodeDetector أو مكتبة ZXing
     • صورة من الجهاز أو لصق Ctrl+V
   ويفكّ رموز GS1 (الأدوية): (01) الرقم العالمي · (17) تاريخ الصلاحية · (10) رقم التشغيلة · (21) الرقم التسلسلي
   · (11) تاريخ الإنتاج · (30) الكمية … + روابط GS1 Digital Link + نص حر (EXP / LOT …)
   ثم يضع الرقم في «الرقم» و«الباركود العالمي» وباركود الوحدة، والصلاحية والتشغيلة في دفعة الرصيد الافتتاحي.
   ========================================================================== */
(function () {
  "use strict";
  if (window.ANOUER_QRREAD) return;
  const G = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const say = (m, t) => { try { if (typeof toast === "function") toast(m, t || "i"); } catch (e) { } };
  const PRODS = () => { try { return typeof products !== "undefined" ? products : []; } catch (e) { return []; } };
  const pad = n => String(n).padStart(2, "0");

  /* ================================================================ فكّ GS1 */
  // الطول الثابت لكل AI (بدون الرمز نفسه)؛ غير المذكور = متغير (حتى FNC1)
  const FIX = { "00": 18, "01": 14, "02": 14, "03": 14, "11": 6, "12": 6, "13": 6, "15": 6, "16": 6, "17": 6, "20": 2, "4100": 13, "410": 13, "411": 13, "412": 13, "413": 13, "414": 13, "415": 13, "416": 13, "7003": 10, "7006": 6, "8005": 6, "8017": 18, "8018": 18 };
  const VARMAX = { "10": 20, "21": 20, "22": 20, "235": 28, "240": 30, "241": 30, "242": 6, "243": 20, "250": 30, "251": 30, "253": 30, "254": 20, "30": 8, "37": 8, "400": 30, "401": 30, "403": 30, "420": 20, "421": 12, "422": 3, "710": 20, "711": 20, "712": 20, "713": 20, "714": 20, "715": 20, "7240": 20, "8004": 30, "8020": 25, "8200": 70, "90": 30, "91": 90, "92": 90, "93": 90, "94": 90, "95": 90, "96": 90, "97": 90, "98": 90, "99": 90 };
  const NAMES = { "00": "SSCC", "01": "الرقم العالمي (GTIN)", "02": "GTIN المحتوى", "10": "رقم التشغيلة (Lot)", "11": "تاريخ الإنتاج", "13": "تاريخ التعبئة", "15": "يُفضّل قبل", "16": "تاريخ البيع الأقصى", "17": "تاريخ الصلاحية", "20": "المتغيّر", "21": "الرقم التسلسلي", "22": "رقم المستهلك", "240": "رقم إضافي", "30": "الكمية", "37": "الكمية", "710": "رقم الدواء الوطني (DE)", "711": "رقم الدواء الوطني (FR)", "712": "رقم الدواء الوطني (ES)", "713": "رقم الدواء الوطني (BR)", "714": "رقم الدواء الوطني (PT)", "715": "رقم الدواء الوطني (US)" };
  const DATE_AI = { "11": 1, "12": 1, "13": 1, "15": 1, "16": 1, "17": 1 };
  const aiAt = (s, i) => {   // يتعرّف على رمز AI في الموضع i (2 أو 3 أو 4 أرقام)
    for (const L of [2, 3, 4]) {
      const k = s.substr(i, L); if (k.length < L || !/^\d+$/.test(k)) continue;
      if (FIX[k] != null || VARMAX[k] != null) return k;
      if (L === 4 && /^3[1-6]\d\d$/.test(k)) return k;   // أوزان/أبعاد 31xx–36xx (6 أرقام)
      if (L === 4 && /^39[0-3]\d$/.test(k)) return k;    // مبالغ/أسعار 390x–393x
    }
    return null;
  };
  const fixLen = k => FIX[k] != null ? FIX[k] : /^3[1-6]\d\d$/.test(k) ? 6 : null;
  const varMax = k => VARMAX[k] != null ? VARMAX[k] : /^39[0-3]\d$/.test(k) ? 18 : 30;
  const okDate = v => /^\d{6}$/.test(v) && +v.slice(2, 4) >= 1 && +v.slice(2, 4) <= 12 && +v.slice(4, 6) <= 31;
  // تحليل بالتراجع: بدون فاصل FNC1 نجرب نهايات الحقل المتغير حتى يُحلّل الباقي كاملاً
  function parseAIs(s, depth) {
    if (!s.length) return [];
    if (depth > 12) return null;
    const k = aiAt(s, 0); if (!k) return null;
    const body = s.slice(k.length), fl = fixLen(k);
    if (fl != null) {
      const v = body.slice(0, fl); if (v.length < fl || !/^\d+$/.test(v)) return null;
      if (DATE_AI[k] && !okDate(v)) return null;
      let rest = body.slice(fl); if (rest[0] === "\x1d") rest = rest.slice(1);
      const r = parseAIs(rest, depth + 1); return r ? [[k, v]].concat(r) : null;
    }
    if (!body.length || body[0] === "\x1d") return null;
    const gs = body.indexOf("\x1d");
    if (gs >= 0) { const v = body.slice(0, gs); if (!v.length || v.length > varMax(k)) return null; const r = parseAIs(body.slice(gs + 1), depth + 1); return r ? [[k, v]].concat(r) : null; }
    const mx = Math.min(varMax(k), body.length);
    if (body.length <= mx) { const whole = [[k, body]]; /* الباقي كله للحقل، إلا إذا وُجد تقسيم أفضل */
      const nextOk = a => DATE_AI[a] || a === "01" || a === "21" && k !== "21" || a === "10" && k !== "10" || /^71[0-5]$/.test(a);
      for (let n = 1; n < body.length; n++) { const r = parseAIs(body.slice(n), depth + 1); if (r && r.length && nextOk(r[0][0]) && (DATE_AI[r[0][0]] || r.length >= 1)) return [[k, body.slice(0, n)]].concat(r); }
      return whole; }
    for (let n = mx; n >= 1; n--) { const r = parseAIs(body.slice(n), depth + 1); if (r) return [[k, body.slice(0, n)]].concat(r); }
    return null;
  }
  const gs1Date = v => { if (!okDate(v)) return ""; const y = 2000 + +v.slice(0, 2), m = +v.slice(2, 4); let d = +v.slice(4, 6); if (!d) d = new Date(y, m, 0).getDate(); return y + "-" + pad(m) + "-" + pad(d); };
  const gtinFix = g => { g = String(g || "").replace(/\D/g, ""); if (g.length === 14 && g[0] === "0") g = g.slice(1); return g; };   // GTIN-14 يبدأ بـ0 ← EAN-13 المطبوع على العلبة
  const checkOk = g => { const d = String(g).replace(/\D/g, ""); if (![8, 12, 13, 14].includes(d.length)) return false; let s = 0; const a = d.slice(0, -1).split("").reverse(); a.forEach((c, i) => { s += +c * (i % 2 ? 1 : 3); }); return (10 - s % 10) % 10 === +d.slice(-1); };
  const freeDate = t => {   // EXP 03/2027 · 31/03/2027 · 2027-03 · 03-27 …
    let m = /(\d{4})[-/.](\d{1,2})(?:[-/.](\d{1,2}))?/.exec(t); if (m) { const y = +m[1], mo = +m[2], d = m[3] ? +m[3] : new Date(y, mo, 0).getDate(); if (mo >= 1 && mo <= 12) return y + "-" + pad(mo) + "-" + pad(d); }
    m = /(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})/.exec(t); if (m) { let y = +m[3]; if (y < 100) y += 2000; const mo = +m[2], d = +m[1]; if (mo >= 1 && mo <= 12) return y + "-" + pad(mo) + "-" + pad(d); }
    m = /(\d{1,2})[-/.](\d{2,4})/.exec(t); if (m) { let y = +m[2]; if (y < 100) y += 2000; const mo = +m[1]; if (mo >= 1 && mo <= 12 && y > 2000) return y + "-" + pad(mo) + "-" + pad(new Date(y, mo, 0).getDate()); }
    return "";
  };
  /* النص المقروء ← { gtin, exp, lot, serial, prod, qty, ais:[[ai,val,name]], raw, kind } */
  function decode(raw) {
    let t = String(raw == null ? "" : raw).replace(/\r/g, "").trim();
    const out = { raw: t, ais: [], kind: "text" };
    if (!t) return out;
    t = t.replace(/^\][A-Za-z]\d/, "");    // بادئة الرمز من القارئ (]d2 ]Q3 ]C1)
    t = t.replace(/[\u001d␝~]|<GS>|\{GS\}|\\x1d/gi, "\x1d");
    // 1) شكل بالأقواس (01)…(17)…
    if (/^\(\d{2,4}\)/.test(t)) {
      const re = /\((\d{2,4})\)([^(]*)/g; let m; while ((m = re.exec(t))) out.ais.push([m[1], m[2].trim()]);
      out.kind = "gs1";
    }
    // 2) GS1 Digital Link (https://…/01/{gtin}/10/{lot}?17=YYMMDD)
    else if (/^https?:\/\//i.test(t)) {
      try {
        const u = new URL(t), parts = u.pathname.split("/").filter(Boolean);
        for (let i = 0; i < parts.length - 1; i++) if (/^\d{2,4}$/.test(parts[i]) && (FIX[parts[i]] != null || VARMAX[parts[i]] != null)) { out.ais.push([parts[i], decodeURIComponent(parts[i + 1])]); i++; }
        u.searchParams.forEach((v, k) => { if (/^\d{2,4}$/.test(k)) out.ais.push([k, v]); });
        if (out.ais.length) out.kind = "gs1link"; else out.kind = "url";
      } catch (e) { out.kind = "url"; }
    }
    // 3) أرقام GS1 متصلة (DataMatrix الأدوية)
    else if (/^(01|02|00|10|11|17|21)\d/.test(t.replace(/\x1d/g, "")) && t.replace(/\x1d/g, "").length > 16) {
      const r = parseAIs(t.replace(/^\x1d/, ""), 0); if (r) { out.ais = r; out.kind = "gs1"; }
    }
    // 4) باركود عادي
    if (!out.ais.length && /^\d{8}$|^\d{12,14}$/.test(t)) { out.kind = "ean"; out.gtin = gtinFix(t); out.check = checkOk(t); return out; }
    if (out.ais.length) {
      out.ais = out.ais.map(([k, v]) => [k, v, NAMES[k] || (/^3[1-6]/.test(k) ? "وزن / قياس" : /^39/.test(k) ? "مبلغ" : "AI " + k)]);
      const A = k => (out.ais.find(x => x[0] === k) || [])[1];
      if (A("01") || A("02")) { out.gtin = gtinFix(A("01") || A("02")); out.check = checkOk(A("01") || A("02")); }
      if (A("17")) out.exp = gs1Date(A("17")); else if (A("15")) out.exp = gs1Date(A("15")); else if (A("16")) out.exp = gs1Date(A("16"));
      if (A("11")) out.prod = gs1Date(A("11"));
      if (A("10")) out.lot = A("10");
      if (A("21")) out.serial = A("21");
      if (A("30") || A("37")) out.qty = +(A("30") || A("37"));
      const nh = out.ais.find(x => /^71[0-5]$/.test(x[0])); if (nh) out.nhrn = nh[1];
      return out;
    }
    // 5) نص حر: أسطر «مفتاح: قيمة» + تواريخ
    const lines = t.split(/\n|;|\|/).map(x => x.trim()).filter(Boolean);
    lines.forEach(l => {
      const kv = /^([^:=]{1,24})[:=]\s*(.+)$/.exec(l); const k = kv ? kv[1].trim().toLowerCase() : "", v = kv ? kv[2].trim() : l;
      if (/exp|per|dlu|use by|valid|صلاح|انتهاء/i.test(k || l)) { const d = freeDate(v); if (d) out.exp = d; }
      else if (/lot|batch|تشغيل|دفعة/i.test(k)) out.lot = v;
      else if (/^(sn|serial|s\/n)|تسلسل/i.test(k)) out.serial = v;
      else if (/ean|gtin|barcode|code|باركود|كود/i.test(k) && /^\d{8,14}$/.test(v.replace(/\s/g, ""))) out.gtin = gtinFix(v);
      else if (/^(name|nom|produit|product|اسم)/i.test(k)) out.name = v;
      else if (/^(fab|mfg|prod)/i.test(k)) { const d = freeDate(v); if (d) out.prod = d; }
    });
    if (!out.gtin) { const g = /(?:^|\D)(\d{13}|\d{8})(?:\D|$)/.exec(t); if (g && checkOk(g[1])) out.gtin = g[1]; }
    if (out.gtin || out.exp || out.lot) out.kind = "text+";
    return out;
  }

  /* ================================================================ فكّ الصورة (كاميرا / ملف) */
  const FORMATS = ["qr_code", "data_matrix", "ean_13", "ean_8", "code_128", "upc_a", "upc_e", "code_39", "itf", "pdf417", "aztec"];
  let BD = null;
  async function nativeDetector() {
    if (BD !== null) return BD;
    try { if ("BarcodeDetector" in window) { const sup = await BarcodeDetector.getSupportedFormats(); const f = FORMATS.filter(x => sup.includes(x)); BD = f.length ? new BarcodeDetector({ formats: f }) : false; } else BD = false; } catch (e) { BD = false; }
    return BD;
  }
  /* ZXing: النسخة المرفقة في vendor أولاً، وإلا من الإنترنت ثم النسخة المحفوظة */
  const ZX_URLS = ["https://cdn.jsdelivr.net/npm/@zxing/library@0.21.3/umd/index.min.js", "https://unpkg.com/@zxing/library@0.21.3/umd/index.min.js"];
  let ZXP = null;
  function zxing() {
    if (window.ZXing) return Promise.resolve(window.ZXing);
    if (ZXP) return ZXP;
    const run = code => new Promise((ok, no) => { const b = new Blob([code], { type: "text/javascript" }), u = URL.createObjectURL(b), s = document.createElement("script"); s.src = u; s.onload = () => { URL.revokeObjectURL(u); window.ZXing ? ok(window.ZXing) : no(new Error("ZXing")); }; s.onerror = () => no(new Error("ZXing")); document.head.appendChild(s); });
    ZXP = (async () => {
      // 1) النسخة المرفقة مع البرنامج (تعمل بدون إنترنت)
      try { await new Promise((ok, no) => { const s = document.createElement("script"); s.src = "/assets/js/vendor/zxing.min.js?v=0213"; s.onload = ok; s.onerror = no; document.head.appendChild(s); }); if (window.ZXing) return window.ZXing; } catch (e) { }
      let cached = null; try { cached = localStorage.getItem("zx.lib.0213"); } catch (e) { }
      if (cached) { try { return await run(cached); } catch (e) { } }
      for (const u of ZX_URLS) {
        try { const r = await fetch(u, { cache: "force-cache" }); if (!r.ok) continue; const code = await r.text(); const z = await run(code); try { localStorage.setItem("zx.lib.0213", code); } catch (e) { } return z; } catch (e) { }
      }
      throw new Error("offline");
    })();
    ZXP.catch(() => { ZXP = null; });
    return ZXP;
  }
  let ZR = null;
  async function zxReader() {
    if (ZR) return ZR; const Z = await zxing();
    const hints = new Map(); const F = Z.BarcodeFormat;
    hints.set(Z.DecodeHintType.POSSIBLE_FORMATS, [F.QR_CODE, F.DATA_MATRIX, F.EAN_13, F.EAN_8, F.CODE_128, F.UPC_A, F.CODE_39, F.ITF, F.PDF_417, F.AZTEC]);
    hints.set(Z.DecodeHintType.TRY_HARDER, true);
    hints.set(Z.DecodeHintType.ASSUME_GS1, false);
    ZR = new Z.MultiFormatReader(); ZR.setHints(hints); return ZR;
  }
  /* يفكّ من canvas ← نص أو null */
  async function decodeCanvas(c) {
    const bd = await nativeDetector();
    if (bd) { try { const r = await bd.detect(c); if (r && r.length) return r[0].rawValue; } catch (e) { } }
    const R = await zxReader(), Z = window.ZXing;
    const x = c.getContext("2d", { willReadFrequently: true }), d = x.getImageData(0, 0, c.width, c.height);
    const lum = new Z.RGBLuminanceSource(rgba2lum(d.data), c.width, c.height);
    for (const bin of [Z.HybridBinarizer, Z.GlobalHistogramBinarizer]) {
      try { const res = R.decode(new Z.BinaryBitmap(new bin(lum))); if (res) return gs1Text(res, Z); } catch (e) { }
    }
    return null;
  }
  const rgba2lum = p => { const o = new Uint8ClampedArray(p.length / 4); for (let i = 0, j = 0; i < p.length; i += 4, j++) o[j] = (p[i] * 299 + p[i + 1] * 587 + p[i + 2] * 114) / 1000; return o; };
  // ZXing يحذف FNC1 من DataMatrix GS1 أحياناً ← نُعيد الفاصل GS إن وُجد في البيانات الخام
  const gs1Text = (res, Z) => { const t = res.getText(); return t; };

  /* ================================================================ تطبيق على بطاقة الصنف */
  const fire = el => el && el.dispatchEvent(new Event("input", { bubbles: true }));
  const isAutoNo = v => /^1061302170503223101\d{7}$/.test(String(v || "")) || !String(v || "").trim();
  function owner(code) { const s = window.ITC && ITC.state ? ITC.state.id : null; return PRODS().find(p => p.id !== s && (String(p.code) === code || (p._u || []).some(u => u && (String(u.bc) === code || (u.xb || []).includes(code))))); }
  function apply(R, o) {
    const done = [];
    if (R.gtin) {
      if (o.no) { const n = G("itNo"); if (n) { n.value = R.gtin; fire(n); done.push("الرقم"); } }
      if (o.gtin) { const g = G("itGtin"); if (g) { g.value = R.gtin; fire(g); done.push("الباركود العالمي"); } }
      if (o.ubc && window.ITC && ITC.setBaseBc) { ITC.setBaseBc(R.gtin); done.push("باركود الوحدة"); }
    }
    if (o.name && R.name) { const n = G("itName"); if (n && !n.value.trim()) { n.value = R.name; fire(n); done.push("الاسم"); } }
    if (o.note && (R.serial || R.nhrn)) { const t = G("itNote"); if (t) { t.value = (t.value ? t.value + "\n" : "") + [R.serial ? "SN: " + R.serial : "", R.nhrn ? "NHRN: " + R.nhrn : ""].filter(Boolean).join(" · "); done.push("الوصف"); } }
    if (o.batch && (R.exp || R.lot) && window.ITC && ITC.addBatch) { ITC.addBatch({ exp: R.exp || "", lot: R.lot || "", qty: R.qty || 0, toExpiry: o.toExp, open: true }); done.push("دفعة الصلاحية"); }
    return done;
  }

  /* ================================================================ الواجهة */
  const IC = {
    qr: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M3 8V4.5A1.5 1.5 0 0 1 4.5 3H8M16 3h3.5A1.5 1.5 0 0 1 21 4.5V8M21 16v3.5a1.5 1.5 0 0 1-1.5 1.5H16M8 21H4.5A1.5 1.5 0 0 1 3 19.5V16"/><rect x="6.5" y="6.5" width="4" height="4" rx=".6" fill="currentColor" stroke="none"/><rect x="13.5" y="6.5" width="4" height="4" rx=".6" fill="currentColor" stroke="none"/><rect x="6.5" y="13.5" width="4" height="4" rx=".6" fill="currentColor" stroke="none"/><path d="M14 14h1.5v1.5H14zM16.5 16.5H18V18h-1.5zM14 17h1.5" fill="currentColor" stroke="none"/></svg>',
    gun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M3 6h13l2 3-6 2-2 9H7l1.6-8H3z"/><path d="M19 4.5l2-1M19.5 7.5H22M19 10.5l2 1"/></svg>',
    cam: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M4 8.5A1.5 1.5 0 0 1 5.5 7h2l1.4-2h6.2L16.5 7h2A1.5 1.5 0 0 1 20 8.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 17.5z"/><circle cx="12" cy="12.6" r="3.6"/></svg>',
    img: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><rect x="3.5" y="4.5" width="17" height="15" rx="2"/><circle cx="9" cy="10" r="1.8"/><path d="M20 16l-5-5-8 8"/></svg>',
    ok: '<svg viewBox="0 0 16 16"><path d="M3.5 8.5l3 3 6-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };
  let D = null;
  const K = k => D && D.ov.querySelector('[data-k="' + k + '"]');
  function open(text) {
    if (D) { if (text) show(text); return; }
    const ov = document.createElement("div"); ov.className = "qrr-ov"; ov.tabIndex = -1;
    ov.innerHTML = `<div class="qrr-dlg" role="dialog" aria-label="قراءة QR الصنف">
      <header><span class="lg">${IC.qr}</span><div><b>قراءة QR / باركود الصنف</b><small>امسح علبة الدواء أو المنتج — نستخرج الرقم وتاريخ الصلاحية ورقم التشغيلة</small></div><button type="button" class="x" data-a="close" title="إغلاق (Esc)">✕</button></header>
      <div class="bd">
        <section class="src">
          <div class="tabs"><button type="button" data-src="gun" class="on">${IC.gun}قارئ الباركود</button><button type="button" data-src="cam">${IC.cam}الكاميرا</button><button type="button" data-src="img">${IC.img}صورة / لصق</button></div>
          <div class="stage" data-k="stage"></div>
          <div class="man"><input data-k="man" placeholder="أو الصق / اكتب محتوى الرمز هنا ثم Enter — مثال: (01)06130000000012(17)270331(10)A123" dir="ltr" autocomplete="off" spellcheck="false"></div>
        </section>
        <aside class="res" data-k="res"></aside>
      </div></div>`;
    document.body.appendChild(ov);
    D = { ov, src: "gun", stream: null, loop: 0, R: null };
    ov.addEventListener("click", onClick); ov.addEventListener("keydown", onKey, true); ov.addEventListener("paste", onPaste);
    ov.addEventListener("change", e => { const t = e.target; if (t.dataset.k === "file" && t.files && t.files[0]) fromFile(t.files[0]); if (t.dataset.k === "dev") startCam(t.value); });
    requestAnimationFrame(() => ov.classList.add("show"));
    setSrc("gun"); drawRes(null);
    if (text) show(text);
  }
  function close() { if (!D) return; stopCam(); const ov = D.ov; D = null; ov.classList.remove("show"); setTimeout(() => ov.remove(), 160); const b = G("itQrBox"); if (b) b.focus(); }
  function setSrc(s) {
    if (!D) return; D.src = s; stopCam();
    D.ov.querySelectorAll("[data-src]").forEach(b => b.classList.toggle("on", b.dataset.src === s));
    const st = K("stage");
    if (s === "gun") {
      st.innerHTML = `<div class="gun" tabindex="0" data-k="gunbox"><div class="beam"><i></i></div>${IC.gun}<b>امسح الرمز الآن بقارئ الباركود</b><small>QR · DataMatrix · EAN — القارئ يكتب الرمز هنا تلقائياً</small><span class="st" data-k="gst">في انتظار المسح…</span></div>`;
      setTimeout(() => { const g = K("gunbox"); g && g.focus(); }, 30);
    } else if (s === "cam") {
      st.innerHTML = `<video autoplay playsinline muted></video><div class="frame"><i></i><i></i><i></i><i></i><span class="laser"></span></div><div class="cst" data-k="cst">تشغيل الكاميرا…</div><select data-k="dev" hidden></select>`;
      startCam();
    } else {
      st.innerHTML = `<label class="drop" data-k="drop"><input type="file" accept="image/*" data-k="file" hidden>${IC.img}<b>اختر صورة الرمز</b><small>أو اسحبها هنا — أو الصقها بـ Ctrl+V</small></label>`;
      const d = K("drop");
      ["dragenter", "dragover"].forEach(t => d.addEventListener(t, e => { e.preventDefault(); d.classList.add("over"); }));
      d.addEventListener("dragleave", () => d.classList.remove("over"));
      d.addEventListener("drop", e => { e.preventDefault(); d.classList.remove("over"); const f = [...(e.dataTransfer.files || [])].find(x => /^image\//.test(x.type)); if (f) fromFile(f); });
    }
  }
  async function startCam(dev) {
    const cst = t => { const e = K("cst"); if (e) e.innerHTML = t; };
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return cst("الكاميرا غير متاحة — استعمل قارئ الباركود أو صورة");
    stopCam();
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: Object.assign({ width: { ideal: 1920 }, height: { ideal: 1080 } }, dev ? { deviceId: { exact: dev } } : { facingMode: "environment" }), audio: false });
      if (!D || D.src !== "cam") { s.getTracks().forEach(t => t.stop()); return; }
      D.stream = s; const v = D.ov.querySelector(".stage video"); v.srcObject = s;
      try { const tr = s.getVideoTracks()[0], caps = tr.getCapabilities ? tr.getCapabilities() : {}; if (caps.focusMode && caps.focusMode.includes("continuous")) tr.applyConstraints({ advanced: [{ focusMode: "continuous" }] }); } catch (e) { }
      const devs = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === "videoinput"), sel = K("dev");
      if (sel && devs.length > 1) { const cur = s.getVideoTracks()[0].getSettings().deviceId; sel.innerHTML = devs.map((d, i) => `<option value="${esc(d.deviceId)}"${d.deviceId === cur ? " selected" : ""}>${esc(d.label || "كاميرا " + (i + 1))}</option>`).join(""); sel.hidden = false; }
      const nat = await nativeDetector();
      if (!nat) { cst("تحميل قارئ الرموز…"); try { await zxReader(); } catch (e) { return cst("تعذّر تحميل قارئ الرموز — استعمل <b>قارئ الباركود</b> أو صورة"); } }
      cst("وجّه الرمز داخل الإطار");
      scanLoop(v);
    } catch (e) { cst(/NotFound|Overconstrained/i.test(e && e.name) ? "لا توجد كاميرا — استعمل قارئ الباركود أو صورة" : "تعذّر تشغيل الكاميرا (الإذن أو برنامج آخر يستعملها)"); }
  }
  function stopCam() { if (D) { D.loop++; if (D.stream) { D.stream.getTracks().forEach(t => t.stop()); D.stream = null; } } }
  function scanLoop(v) {
    const id = D.loop, c = document.createElement("canvas");
    const tick = async () => {
      if (!D || D.loop !== id) return;
      if (v.videoWidth) {
        // منطقة الإطار في الوسط (أسرع وأدق)
        const s = Math.min(v.videoWidth, v.videoHeight) * 0.8, sx = (v.videoWidth - s) / 2, sy = (v.videoHeight - s) / 2, k = Math.min(1, 900 / s);
        c.width = s * k; c.height = s * k; c.getContext("2d", { willReadFrequently: true }).drawImage(v, sx, sy, s, s, 0, 0, c.width, c.height);
        try { const t = await decodeCanvas(c); if (t && D && D.loop === id) { beep(); D.ov.querySelector(".stage").classList.add("hit"); setTimeout(() => D && D.ov.querySelector(".stage").classList.remove("hit"), 500); show(t); return setTimeout(tick, 1600); } } catch (e) { }
      }
      setTimeout(tick, 120);
    };
    tick();
  }
  async function fromFile(f) {
    const u = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(f); });
    const im = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = u; }).catch(() => null);
    if (!im) return say("تعذّر فتح الصورة", "e");
    const st = K("stage"); st.classList.add("busy");
    try {
      for (const mx of [1600, 1000, 2400]) {
        const k = Math.min(1, mx / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement("canvas"); c.width = im.naturalWidth * k; c.height = im.naturalHeight * k; c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
        const t = await decodeCanvas(c).catch(e => { if (e && e.message === "offline") throw e; return null; }); if (t) { beep(); show(t); return; }
      }
      say("لم يُعثر على رمز في الصورة — صوّر الرمز بوضوح وقريباً", "w");
    } catch (e) { say("تعذّر تحميل قارئ الرموز — استعمل قارئ الباركود", "w"); }
    finally { st.classList.remove("busy"); }
  }
  let AC = null;
  function beep() { try { AC = AC || new (window.AudioContext || window.webkitAudioContext)(); const o = AC.createOscillator(), g = AC.createGain(); o.frequency.value = 1760; g.gain.value = .06; o.connect(g); g.connect(AC.destination); o.start(); o.stop(AC.currentTime + .09); } catch (e) { } }

  /* ---------------------------------------------------------------- النتيجة */
  function show(text) { const R = decode(text); D.R = R; drawRes(R); const g = K("gst"); if (g) g.textContent = "✓ تمت القراءة — امسح رمزاً آخر لاستبداله"; }
  const expInfo = d => {
    if (!d) return null; const t = new Date(d + "T00:00:00"), now = new Date(); now.setHours(0, 0, 0, 0);
    const days = Math.round((t - now) / 864e5), mo = Math.round(days / 30.4);
    if (days < 0) return { c: "bad", t: "منتهي منذ " + (-days > 60 ? Math.round(-days / 30.4) + " شهر" : -days + " يوم") };
    if (days <= 90) return { c: "warn", t: "ينتهي بعد " + (days > 60 ? mo + " أشهر" : days + " يوم") };
    return { c: "good", t: "صالح · " + (mo >= 12 ? Math.floor(mo / 12) + " سنة" + (mo % 12 ? " و" + (mo % 12) + " شهر" : "") : mo + " شهر") };
  };
  const dShow = d => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d || ""); return m ? m[3] + "/" + m[2] + "/" + m[1] : d; };
  function drawRes(R) {
    const el = K("res"); if (!el) return;
    if (!R) {
      el.innerHTML = `<div class="emp"><div class="ill">${IC.qr}</div><b>لم يُقرأ رمز بعد</b><p>نقرأ رموز <b>GS1</b> المطبوعة على علب الأدوية (DataMatrix) والـ QR والباركود العادي.</p>
        <ul><li><code>(01)</code> الرقم العالمي ← «الرقم» و«الباركود»</li><li><code>(17)</code> تاريخ الصلاحية ← دفعة الصلاحية</li><li><code>(10)</code> رقم التشغيلة ← نفس الدفعة</li><li><code>(21)</code> الرقم التسلسلي ← الوصف</li></ul></div>`;
      return;
    }
    const ex = expInfo(R.exp), own = R.gtin ? owner(R.gtin) : null, ty = window.ITC && ITC.state ? ITC.state.type : "";
    const autoNo = isAutoNo((G("itNo") || {}).value);
    const kindL = { gs1: "GS1 DataMatrix / QR", gs1link: "GS1 Digital Link", ean: "باركود", "text+": "نص", text: "نص", url: "رابط" }[R.kind] || "";
    const row = (k, lbl, val, extra) => `<div class="fld"><small>${lbl}</small><b dir="ltr">${esc(val)}</b>${extra || ""}</div>`;
    el.innerHTML = `<div class="hd"><b>نتيجة القراءة</b><span class="kd">${esc(kindL)}</span></div>
      ${R.gtin ? `<div class="card main">${row("g", "الرقم العالمي (GTIN)", R.gtin, R.check === false ? '<em class="bad">رقم التحقق غير صحيح</em>' : R.check ? '<em class="good">✓ صحيح</em>' : "")}
        ${own ? `<div class="own">⚠ مسجّل للصنف «${esc(own.name)}» <button type="button" data-a="openOwn" data-id="${own.id}">فتح الصنف</button></div>` : ""}
        <div class="tg"><label><input type="checkbox" data-o="no"${autoNo && !own ? " checked" : ""}>الرقم</label><label><input type="checkbox" data-o="gtin"${own ? "" : " checked"}>الباركود العالمي</label><label><input type="checkbox" data-o="ubc"${own ? "" : " checked"}>باركود الوحدة</label></div></div>` : ""}
      ${R.exp || R.lot ? `<div class="card">${R.exp ? row("e", "تاريخ الصلاحية", dShow(R.exp), ex ? `<em class="${ex.c}">${ex.t}</em>` : "") : ""}${R.lot ? row("l", "رقم التشغيلة (Lot)", R.lot) : ""}
        <div class="tg"><label><input type="checkbox" data-o="batch" checked>إضافة كدفعة في الرصيد الافتتاحي</label>${ty !== "expiry" ? `<label><input type="checkbox" data-o="toExp" checked>تحويل النوع إلى «مخزون بصلاحية»</label>` : ""}</div></div>` : ""}
      ${R.serial || R.nhrn || R.prod || R.qty ? `<div class="card">${R.serial ? row("s", "الرقم التسلسلي", R.serial) : ""}${R.nhrn ? row("n", "رقم الدواء الوطني", R.nhrn) : ""}${R.prod ? row("p", "تاريخ الإنتاج", dShow(R.prod)) : ""}${R.qty ? row("q", "الكمية", R.qty) : ""}
        ${R.serial || R.nhrn ? `<div class="tg"><label><input type="checkbox" data-o="note">كتابته في الوصف</label></div>` : ""}</div>` : ""}
      ${R.name ? `<div class="card">${row("nm", "الاسم", R.name)}<div class="tg"><label><input type="checkbox" data-o="name" checked>اسم الصنف (إن كان فارغاً)</label></div></div>` : ""}
      ${!R.gtin && !R.exp && !R.lot && !R.name ? `<div class="none">لم نتعرّف على رقم أو تاريخ في هذا الرمز. المحتوى معروض بالأسفل.</div>` : ""}
      ${R.ais.length ? `<details class="ais"><summary>كل الحقول (${R.ais.length})</summary>${R.ais.map(a => `<div><code>(${esc(a[0])})</code><span>${esc(a[2])}</span><b dir="ltr">${esc(DATE_AI[a[0]] ? dShow(gs1Date(a[1])) : a[1])}</b></div>`).join("")}</details>` : ""}
      <details class="raw"><summary>النص الخام</summary><pre dir="ltr">${esc(R.raw.replace(/\x1d/g, "⟨GS⟩"))}</pre></details>
      <div class="acts"><button type="button" class="go" data-a="apply"${R.gtin || R.exp || R.lot || R.name ? "" : " disabled"}>${IC.ok}تطبيق على الصنف</button><button type="button" class="b" data-a="again">مسح رمز آخر</button></div>`;
  }
  function doApply() {
    if (!D || !D.R) return;
    const o = {}; D.ov.querySelectorAll("[data-o]").forEach(c => { o[c.dataset.o] = c.checked; });
    const R = D.R, done = apply(R, o);
    close();
    say(done.length ? "تم: " + done.join(" ، ") + " ✓" + (o.batch && (R.exp || R.lot) ? " — اكتب كمية الدفعة" : "") : "لم يُحدَّد ما يُطبّق", done.length ? "s" : "i");
  }
  function onClick(e) {
    if (!D) return;
    const s = e.target.closest("[data-src]"), a = e.target.closest("[data-a]");
    if (s) return setSrc(s.dataset.src);
    if (!a) return;
    const k = a.dataset.a;
    if (k === "close") close();
    else if (k === "apply") doApply();
    else if (k === "again") { D.R = null; drawRes(null); setSrc(D.src); }
    else if (k === "openOwn") { const p = PRODS().find(x => String(x.id) === a.dataset.id); close(); if (p && window.ITC) ITC.load(p); }
  }
  /* قارئ الباركود: يكتب بسرعة وينتهي بـ Enter — نجمّع المفاتيح (مع فاصل GS = Ctrl+] أو F8 حسب إعداد القارئ) */
  let BUF = "", BT = 0;
  function onKey(e) {
    if (!D) return;
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); return; }
    const t = e.target, man = t.dataset && t.dataset.k === "man";
    if (man) { e.stopPropagation(); if (e.key === "Enter") { e.preventDefault(); if (t.value.trim()) { show(t.value); t.value = ""; } } return; }
    if (D.src !== "gun" && !(t.dataset && t.dataset.k === "gunbox")) { if (e.key === "Enter" && e.ctrlKey && D.R) { e.preventDefault(); doApply(); } return; }
    if (/INPUT|SELECT|TEXTAREA/.test(t.tagName)) return;
    e.stopPropagation();
    if (e.key === "Enter") { e.preventDefault(); if (BUF.length >= 4) { const v = BUF; BUF = ""; beep(); show(v); } else if (D.R && e.ctrlKey) doApply(); BUF = ""; return; }
    if ((e.ctrlKey && (e.key === "]" || e.code === "BracketRight")) || e.key === "F8" || e.key === "\x1d") { e.preventDefault(); BUF += "\x1d"; return; }
    if (e.key.length === 1 && !e.ctrlKey && !e.altKey) { e.preventDefault(); const now = Date.now(); if (now - BT > 800) BUF = ""; BT = now; BUF += e.key; const g = K("gst"); if (g) g.textContent = "يقرأ… " + BUF.length; }
  }
  function onPaste(e) {
    if (!D) return; const cd = e.clipboardData; if (!cd) return;
    const f = [...cd.items].find(i => /^image\//.test(i.type)); if (f) { e.preventDefault(); fromFile(f.getAsFile()); return; }
    const t = cd.getData("text"); if (t && !(e.target.dataset && e.target.dataset.k === "man")) { e.preventDefault(); show(t); }
  }

  /* ---------------------------------------------------------------- المربع بجانب «حفظ» */
  function mount() {
    const save = document.querySelector("#vItem .it-save"); if (!save || G("itQrBox")) return;
    const img = G("itImgBox"), stu = G("itStudio");
    const sr = parseFloat(save.style.right) || 799, sw = save.offsetWidth || 132;
    const R0 = sr + sw + 12;            // المربع ملاصق لزر الحفظ
    const b = document.createElement("div"); b.id = "itQrBox"; b.className = "it-qr"; b.tabIndex = 0; b.setAttribute("role", "button");
    b.title = "قراءة QR / باركود: امسح بالقارئ وأنت على هذا المربع، أو انقر للكاميرا والصور — يستخرج الرقم وتاريخ الصلاحية ورقم التشغيلة";
    b.innerHTML = `<span class="ic">${IC.qr}<i class="ln"></i></span><b>قراءة QR</b><small>دواء · منتج</small>`;
    b.style.right = R0 + "px";
    save.parentNode.insertBefore(b, save.nextSibling);
    // إزاحة مربعي «الصورة» و«تصوير ذكي» لليسار لترك مكان المربع
    const gap = 10, w = 118;
    if (img) img.style.right = (R0 + w + gap) + "px";
    const shiftStu = () => { const s = G("itStudio"); if (s) s.style.right = (R0 + (w + gap) * 2) + "px"; const a = G("itAdShot"); if (a) { a.style.right = (R0 + w + gap) + "px"; a.style.width = (w * 2 + gap) + "px"; } };
    shiftStu(); setTimeout(shiftStu, 500); setTimeout(shiftStu, 1500);
    b.addEventListener("click", () => open());
    // القارئ يكتب والمربع مُركّز ← قراءة مباشرة بدون فتح النافذة أولاً
    let buf = "", bt = 0;
    b.addEventListener("keydown", e => {
      if (e.key === "Enter") { e.preventDefault(); if (buf.length >= 4) { const v = buf; buf = ""; beep(); open(v); } else open(); buf = ""; return; }
      if (e.key === " ") { e.preventDefault(); open(); return; }
      if ((e.ctrlKey && (e.key === "]" || e.code === "BracketRight")) || e.key === "F8") { e.preventDefault(); buf += "\x1d"; return; }
      if (e.key.length === 1 && !e.ctrlKey && !e.altKey) { e.preventDefault(); const n = Date.now(); if (n - bt > 800) buf = ""; bt = n; buf += e.key; b.classList.add("rd"); clearTimeout(b.__t); b.__t = setTimeout(() => b.classList.remove("rd"), 600); }
    });
    b.addEventListener("paste", e => { const t = e.clipboardData && e.clipboardData.getData("text"); if (t) { e.preventDefault(); open(t); } });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount); else mount();
  setTimeout(mount, 800);
  /* صورة ثابتة ← نص الرمز: عدة مقاسات + أرباع الصورة (الرموز الصغيرة على العلب) — يستعملها «استوديو صورة الصنف» */
  async function scanImage(im, quick) {   // quick: "full" | "center" (إطار فيديو حيّ) — بدون = فحص كامل لصورة ثابتة
    const W = im.naturalWidth || im.videoWidth || im.width, H = im.naturalHeight || im.videoHeight || im.height; if (!W || !H) return null;
    const cut = (sx, sy, sw, sh, mx) => { const k = Math.min(1, mx / Math.max(sw, sh)), c = document.createElement("canvas"); c.width = Math.max(1, Math.round(sw * k)); c.height = Math.max(1, Math.round(sh * k)); c.getContext("2d", { willReadFrequently: true }).drawImage(im, sx, sy, sw, sh, 0, 0, c.width, c.height); return c; };
    if (quick === "full") return decodeCanvas(cut(0, 0, W, H, 1280));
    if (quick === "center") { const s = Math.min(W, H) * 0.62; return decodeCanvas(cut((W - s) / 2, (H - s) / 2, s, s, 800)); }
    /* أرباع الإطار (60%) — رمز صغير في زاوية العلبة يُقرأ حياً حتى بكاميرا عالية الدقة */
    if (/^t[0-3]$/.test(quick || "")) { const i = +quick[1], w2 = W * 0.6, h2 = H * 0.6; return decodeCanvas(cut(i % 2 ? W - w2 : 0, i > 1 ? H - h2 : 0, w2, h2, 1000)); }
    for (const mx of [1400, 900, 2200]) { const t = await decodeCanvas(cut(0, 0, W, H, mx)); if (t) return t; }
    const w2 = W * 0.6, h2 = H * 0.6;
    for (const [x, y] of [[W * 0.2, H * 0.2], [0, 0], [W - w2, 0], [0, H - h2], [W - w2, H - h2]]) { const t = await decodeCanvas(cut(x, y, w2, h2, 1400)); if (t) return t; }
    return null;
  }
  window.ANOUER_QRREAD = { open, decode, close, decodeCanvas, scanImage, freeDate };
})();
