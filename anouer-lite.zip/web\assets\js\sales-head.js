/* ANOUER — أيقونات رأس فاتورة المبيعات (مطابقة DEXEF ONE):
   • الشارة الزرقاء: شريحة الأسعار — سعر اخر تعامل / 1 سعر البيع / 2 التجزئة / 3 عابر سبيل / 4 سعر استطلاع / 5 الجملة / 6 سعر 5ومافوق
   • العملات: التعامل — كاش / أجل
   الشريحة تحدد سعر الأصناف المضافة وتعيد تسعير أسطر الفاتورة؛ وتُضبط تلقائياً من بطاقة العميل (شريحة الاسعار / التعامل الافتراضى). */
(function () {
  "use strict";
  const $ = id => document.getElementById(id);
  const tierBtn = $("tierBtn"), badge = $("tierBadge"), dealBtn = $("dealBtn"), nm = $("custName");
  if (!tierBtn || !dealBtn) return;
  const say = (m, t) => { try { toast(m, t || "i"); } catch (e) { } };
  const R = () => { try { return rows; } catch (e) { return []; } };
  const P = () => { try { return products; } catch (e) { return []; } };

  const IC = {
    coins: '<svg viewBox="0 0 20 20" width="20" height="20" fill="none" stroke="#444" stroke-width="1.3"><ellipse cx="8" cy="4.5" rx="5" ry="2"/><path d="M3 4.5v9c0 1.1 2.2 2 5 2s5-.9 5-2v-9M3 7.5c0 1.1 2.2 2 5 2s5-.9 5-2M3 10.5c0 1.1 2.2 2 5 2s5-.9 5-2"/><ellipse cx="13.5" cy="12" rx="4" ry="1.7" fill="#fff"/><path d="M9.5 12v3.6c0 .9 1.8 1.7 4 1.7s4-.8 4-1.7V12M9.5 14c0 .9 1.8 1.7 4 1.7s4-.8 4-1.7" fill="#fff"/></svg>',
    user: '<svg viewBox="0 0 20 20" width="20" height="20"><circle cx="10" cy="10" r="8.6" fill="none" stroke="#444" stroke-width="1.4"/><circle cx="10" cy="7.6" r="2.7" fill="#444"/><path d="M5.2 15.3c.8-2.6 2.6-3.8 4.8-3.8s4 1.2 4.8 3.8" fill="#444"/></svg>',
    ring: '<svg viewBox="0 0 12 12" width="11" height="11"><circle cx="6" cy="6" r="4.6" fill="none" stroke="#555" stroke-width="1.3"/></svg>',
    inst: '<svg viewBox="0 0 20 20" width="20" height="20" fill="none" stroke="#444" stroke-width="1.3" stroke-linecap="round"><rect x="2.6" y="4" width="14.8" height="13" rx="2.2"/><path d="M2.6 8h14.8M6.5 2.4v3M13.5 2.4v3"/><path d="M5.8 11h2M9 11h2M12.2 11h2M5.8 14h2M9 14h2" stroke-width="1.7"/></svg>'
  };
  /* الشرائح: [القيمة، الاسم، حقل سعر الوحدة، حقل سعر الصنف (بلا وحدات)] */
  /* من الإعداد المشترك (price-levels.js): الأسماء المخصّصة + الترتيب + المخفي — مع احتياطي ثابت */
  const PL = window.ANOUER_PL;
  const TIERS_DEF = [["last", "سعر اخر تعامل"], ["1", "سعر البيع", "price", "price"], ["2", "التجزئة", "rp", "retail"], ["3", "عابر سبيل", "pp", "passer"],
    ["4", "سعر استطلاع", "sp", "survey"], ["5", "الجملة", "wp", "whole"], ["6", "سعر 5ومافوق", "p5", "q5"], ["7", "سعر 6", "p6", "p6"], ["8", "سعر 7", "p7", "p7"], ["9", "سعر 8", "p8", "p8"]];
  const tiersAll = () => PL ? PL.all().map(x => [x.id, x.name, x.u, x.p, x.hidden]) : TIERS_DEF;
  const T_OF = t => tiersAll().find(x => x[0] === t);
  const DEALS = [["cash", "كاش", IC.coins], ["credit", "أجل", IC.user]];
  /* ✦ «تقسيط» (installments.js): يظهر مع كاش / أجل عندما تكون إضافة الأقساط مفعّلة — محاسبياً = أجل ، وبعد الحفظ يُفتح عقد التقسيط لباقي الفاتورة */
  const D_INST = ["inst", "تقسيط", IC.inst];
  const instOn = () => { try { return !!(window.ANOUER_INST && ANOUER_INST.on()); } catch (e) { return false; } };
  const dealList = () => instOn() ? DEALS.concat([D_INST]) : DEALS;
  let tier = "1", deal = "cash", inst = false;

  /* ---------- القائمة المنسدلة المشتركة ---------- */
  const menu = document.createElement("div"); menu.id = "shMenu"; menu.setAttribute("role", "menu"); document.body.appendChild(menu);
  let owner = null;
  /* حجم القائمة قابل للتكبير بمقبض النقاط في الزاوية (مثل DEXEF) — يُحفظ لكل قائمة */
  const LSG = k => { try { return JSON.parse(localStorage.getItem(k) || "null"); } catch (e) { return null; } };
  const LSS = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
  function fitFont() {
    const its = menu.querySelectorAll("[data-v]"); if (!its.length) return;
    const h = menu.classList.contains("sized") ? (menu.clientHeight - 14) / its.length : 34;
    menu.style.setProperty("--shf", Math.max(13, Math.min(26, h * 0.4)).toFixed(1) + "px");
  }
  function openMenu(btn, items, cur, onPick) {
    if (owner === btn) { closeMenu(); return; }
    menu.innerHTML = items.map(x => `<div data-v="${x.v}" class="${x.v === cur ? "on" : ""}${x.c ? " " + x.c : ""}" role="menuitemradio" aria-checked="${x.v === cur}"><span class="sh-l">${x.t}</span><span class="sh-i">${x.i}</span></div>`).join("") +
      `<span class="sh-grip" title="اسحب لتكبير القائمة — نقر مزدوج للحجم الافتراضي" aria-hidden="true"></span>`;
    const sz = LSG("sh.size." + btn.id);
    menu.classList.toggle("sized", !!sz); menu.style.width = sz ? sz.w + "px" : ""; menu.style.height = sz ? sz.h + "px" : "";
    clearTimeout(outT); clearTimeout(leaveT); entered = false;
    menu.classList.remove("out", "in"); menu.classList.add("show"); void menu.offsetWidth; menu.classList.add("in");
    menu.querySelectorAll("[data-v]").forEach((d, k) => d.style.animationDelay = (40 + k * 28) + "ms");
    owner = btn; btn.classList.add("open"); fitFont();
    const r = btn.getBoundingClientRect();
    menu.style.top = (r.bottom + 2) + "px";
    let l = r.left; if (l + menu.offsetWidth > innerWidth - 4) l = innerWidth - menu.offsetWidth - 4;
    menu.style.left = Math.max(4, l) + "px";
    if (r.bottom + 2 + menu.offsetHeight > innerHeight - 4) menu.style.top = Math.max(4, innerHeight - menu.offsetHeight - 4) + "px";
    const grip = menu.querySelector(".sh-grip"), key = "sh.size." + btn.id;
    grip.addEventListener("pointerdown", e => {
      e.preventDefault(); e.stopPropagation(); grip.setPointerCapture(e.pointerId);
      const sx = e.clientX, sy = e.clientY, sw = menu.offsetWidth, shh = menu.offsetHeight, sl = menu.offsetLeft; resizing = true; clearTimeout(leaveT);
      const mv = ev => {
        const w = Math.max(160, Math.min(innerWidth - 8, sw - (ev.clientX - sx))), h = Math.max(items.length * 30 + 14, Math.min(innerHeight - menu.offsetTop - 6, shh + (ev.clientY - sy)));
        menu.classList.add("sized"); menu.style.width = w + "px"; menu.style.height = h + "px"; menu.style.left = Math.max(4, sl + (sw - w)) + "px"; fitFont();
      };
      const up = () => { resizing = false; grip.removeEventListener("pointermove", mv); grip.removeEventListener("pointerup", up); grip.removeEventListener("pointercancel", up); if (menu.classList.contains("sized")) LSS(key, { w: menu.offsetWidth, h: menu.offsetHeight }); };
      grip.addEventListener("pointermove", mv); grip.addEventListener("pointerup", up); grip.addEventListener("pointercancel", up);
    });
    grip.addEventListener("dblclick", e => { e.stopPropagation(); try { localStorage.removeItem(key); } catch (x) { } menu.classList.remove("sized"); menu.style.width = menu.style.height = ""; fitFont(); });
    grip.addEventListener("click", e => e.stopPropagation());
    menu.onclick = e => { const d = e.target.closest("[data-v]"); if (!d) return; closeMenu(); onPick(d.dataset.v); };
    const on = menu.querySelector(".on") || menu.firstElementChild; if (on) { on.tabIndex = -1; }
  }
  /* إغلاق بتلاشٍ ناعم */
  let outT = 0, leaveT = 0, entered = false, resizing = false;
  function closeMenu() {
    clearTimeout(leaveT); if (owner) owner.classList.remove("open"); owner = null;
    if (!menu.classList.contains("show")) return;
    menu.classList.remove("in"); menu.classList.add("out");
    clearTimeout(outT); outT = setTimeout(() => { menu.classList.remove("show", "out"); }, 170);
  }
  /* ذكي: تختفي القائمة عند إبعاد الفأرة عنها وعن زرّها (مهلة قصيرة للعودة)، ولا تختفي أثناء التكبير أو باللمس */
  function hoverIn() { clearTimeout(leaveT); }
  function hoverOut(e) {
    if (!owner || resizing || (e && e.pointerType && e.pointerType !== "mouse")) return;
    const to = e && e.relatedTarget; if (to && (menu.contains(to) || owner.contains(to))) return;
    clearTimeout(leaveT); leaveT = setTimeout(() => { if (!resizing) closeMenu(); }, entered ? 320 : 900);
  }
  menu.addEventListener("pointerenter", e => { if (e.pointerType === "mouse") entered = true; hoverIn(); });
  menu.addEventListener("pointerleave", hoverOut);
  [tierBtn, dealBtn].forEach(b => { b.addEventListener("pointerenter", hoverIn); b.addEventListener("pointerleave", hoverOut); });
  menu.addEventListener("mousedown", e => e.preventDefault());
  document.addEventListener("mousedown", e => { if (owner && !menu.contains(e.target) && !owner.contains(e.target)) closeMenu(); }, true);
  addEventListener("resize", closeMenu);
  window.addEventListener("keydown", e => {
    if (!owner) return;
    const its = Array.from(menu.querySelectorAll("[data-v]")); let i = its.findIndex(x => x.classList.contains("hl"));
    if (i < 0) i = its.findIndex(x => x.classList.contains("on"));
    if (e.key === "Escape") { closeMenu(); }
    else if (e.key === "ArrowDown" || e.key === "ArrowUp") { i = (i + (e.key === "ArrowDown" ? 1 : -1) + its.length) % its.length; its.forEach((x, k) => x.classList.toggle("hl", k === i)); }
    else if (e.key === "Enter" || e.key === " ") { const x = its[i]; if (x) x.click(); }
    else return;
    e.preventDefault(); e.stopImmediatePropagation();
  }, true);

  /* ---------- شريحة الأسعار ---------- */
  function unitOf(p, name) { return (p._u || []).find(u => u.name === name) || p._d || null; }
  function lastPrice(p, unitName) {
    const cn = (nm && nm.value || "").trim(); let L = [];
    try { L = (SAVED_INV || []).slice().reverse(); } catch (e) { }
    for (const inv of L) { if (cn && inv.name !== cn) continue; const r = (inv.rows || []).find(x => x.pid === p.id && x.unit === unitName); if (r && +r.price > 0) return +r.price; }
    return 0;
  }
  function priceFor(p, unitName, t) {
    t = t || tier;
    const u = unitOf(p, unitName);
    let v = 0;
    if (t === "last") v = lastPrice(p, unitName);
    else {
      const T = T_OF(t) || T_OF("1");
      if (u) v = +u[T[2]] || 0;
      else { let f = 1; try { f = (units && units[unitName]) || 1; } catch (e) { } v = (+p[T[3]] || 0) * f; }
    }
    if (!(v > 0)) v = u ? +u.price || 0 : +p.price || 0;   // لا سعر في الشريحة ← سعر البيع
    return v;
  }
  function reprice(onlyIdx) {
    const rs = R(); let n = 0;
    rs.forEach((r, i) => { if (!r || !r.pid || (onlyIdx != null && i !== onlyIdx)) return; const p = P().find(x => x.id == r.pid); if (!p) return; const v = priceFor(p, r.unit); if (v !== +r.price) { r.price = v; n++; } });
    return n;
  }
  function setTier(t, quiet) {
    if (!T_OF(t)) t = "1";
    tier = t;
    const T = T_OF(t);
    badge.innerHTML = t === "last" ? IC.ring : t;
    badge.classList.toggle("ring", t === "last");
    tierBtn.title = "شريحة الأسعار: " + T[1];
    if (quiet) return;
    /* إعادة تسعير كل أسطر الفاتورة بالشريحة الجديدة + إطار تنبيه بالصوت + إبراز الأسعار التي تغيّرت */
    const old = R().map(r => r && +r.price);
    const n = reprice(); try { renderRows(); } catch (e) { }
    const changed = []; R().forEach((r, i) => { if (r && r.pid && old[i] !== +r.price) changed.push(i); });
    changed.forEach(i => { const c = document.querySelector('#gbody .gr[data-row="' + i + '"] [data-c="p"]'), t = document.querySelector('#gbody .gr[data-row="' + i + '"] [data-c="t"]'); [c, t].forEach(x => { if (x) { x.classList.remove("pchg"); void x.offsetWidth; x.classList.add("pchg"); } }); });
    if (window.ANOUER_PROPS && ANOUER_PROPS.get("inv.gen", {}).tierWarn === false) return;
    const items = R().filter(r => r && r.pid).length;
    if (!items) { say("شريحة الأسعار: " + T[1], "i"); return; }
    try { ANOUER_SOUND("edit"); } catch (e) { }
    const sub = n ? "تم تغيير سعر " + n + " صنف من أصل " + items + " إلى «" + T[1] + "»" : "أسعار الأصناف في «" + T[1] + "» مطابقة للأسعار الحالية";
    if (typeof askOk === "function") askOk("تم تغيير أسعار الأصناف إلى شريحة: " + T[1], sub, () => { try { focusPS(); } catch (e) { } });
    else say(sub, "i");
  }
  tierBtn.addEventListener("click", e => {
    e.stopPropagation();
    const its = tiersAll().filter(x => !x[4] || x[0] === tier).map(x => ({ v: x[0], t: x[1], i: x[0] === "last" ? IC.ring : `<b class="sh-n">${x[0]}</b>`, c: x[4] ? "sh-hid" : "" }));
    if (PL) its.push({ v: "__cfg", t: "تخصيص الشرائح…", i: PL.GEAR, c: "sh-cfg" });
    openMenu(tierBtn, its, tier, v => { if (v === "__cfg") { PL.edit(tierBtn); return; } setTier(v); });
  });
  if (PL) PL.on(() => setTier(tier, true));
  tierBtn.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " " || e.key === "ArrowDown") { e.preventDefault(); tierBtn.click(); } });

  /* الأصناف المضافة وتغيير الوحدة: بسعر الشريحة */
  if (typeof addProduct === "function") {
    const _ap = addProduct;
    addProduct = function (id, rowIdx) {
      const rs = R(), before = rs.length, tgt = rowIdx != null ? rs[rowIdx] : null, wasPid = tgt && tgt.pid;
      const res = _ap.apply(this, arguments);
      if (tier !== "1") {
        let i = -1; try { i = sel; } catch (e) { }
        const r = R()[i];
        const fresh = r && r.pid == id && (R().length > before || (tgt && r === tgt && wasPid != id));
        if (fresh) { reprice(i); try { renderRows(); } catch (e) { } }
      }
      return res;
    };
  }
  if (typeof updUnit === "function") {
    const _uu = updUnit;
    updUnit = function (i) { const res = _uu.apply(this, arguments); if (tier !== "1") { reprice(i); try { renderRows(); } catch (e) { } } return res; };
  }

  /* ---------- التعامل: كاش / أجل ---------- */
  function setDeal(d, quiet) {
    if ((d === "credit" || d === "inst") && !(nm && nm.value.trim())) { say((d === "inst" ? "البيع بالتقسيط" : "التعامل الآجل") + " يتطلب اختيار عميل", "w"); const c = $("custNo"); if (c) c.focus(); d = "cash"; }
    if (d === "inst" && !instOn()) d = "credit";
    inst = d === "inst";
    deal = d === "credit" || d === "inst" ? "credit" : "cash";
    const D = inst ? D_INST : DEALS.find(x => x[0] === deal);
    dealBtn.innerHTML = D[2]; dealBtn.title = "التعامل: " + D[1];
    dealBtn.classList.toggle("credit", deal === "credit"); dealBtn.classList.toggle("inst", inst);
    const iv = document.querySelector(".inv"); if (iv) { iv.classList.toggle("is-credit", deal === "credit"); iv.classList.toggle("is-inst", inst); }
    if (!quiet) say("التعامل: " + D[1] + (inst ? " — بعد حفظ الفاتورة يُفتح جدول الأقساط للباقي" : ""), "i");
  }
  dealBtn.addEventListener("click", e => { e.stopPropagation(); openMenu(dealBtn, dealList().map(x => ({ v: x[0], t: x[1], i: x[2], c: x[0] === "inst" ? "sh-qst" : "" })), inst ? "inst" : deal, v => setDeal(v)); });
  dealBtn.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " " || e.key === "ArrowDown") { e.preventDefault(); dealBtn.click(); } });
  /* الآجل بلا عميل لا يُحفظ */
  if (typeof validRows === "function") {
    const _vr = validRows;
    validRows = function () {
      const v = _vr.apply(this, arguments); if (!v) return v;
      if (deal === "credit" && !(nm && nm.value.trim())) { say("التعامل الآجل يتطلب اختيار عميل", "e"); const c = $("custNo"); if (c) c.focus(); return null; }
      return v;
    };
  }
  /* كاش بلا دفع مسجّل ← مدفوع بالكامل؛ أجل ← المدفوع كما أُدخل والباقي على حساب العميل */
  window.__saleBeforeSave = function () {
    try {
      if (document.querySelector(".inv.retmode")) return;
      if (deal === "cash" && !adj.pays && !(+adj.paid > 0)) { const t = calc(); adj.paid = Math.max(0, +t.total || 0); }
    } catch (e) { }
  };
  window.__saleDeal = () => deal;
  window.__saleSetDeal = (d, q) => setDeal(d === "credit" && inst ? "inst" : d, q);   /* الموديولات الأخرى تعرف كاش / أجل فقط ← «تقسيط» يبقى كما هو ما دام التعامل آجلاً */
  window.__saleInst = () => inst;
  window.__saleSetTier = (t, q) => setTier(t, q);
  window.__saleTier = () => tier;

  /* لمسة: إشارة «تلقائي» عند تغيّر التعامل حسب بطاقة الطرف */
  function dealFlash(btn, txt, credit) {
    try { if (!btn) return; const host = btn.closest("label,.pu-f,.ih-f,div") || btn.parentElement; btn.classList.remove("deal-auto"); void btn.offsetWidth; btn.classList.add("deal-auto");
      document.querySelectorAll(".deal-chip").forEach(x => x.remove());
      const c = document.createElement("span"); c.className = "deal-chip" + (credit ? " cr" : ""); c.innerHTML = `<i>${credit ? "⏳" : "💵"}</i><b>${txt}</b><small>تلقائي</small>`;
      document.body.appendChild(c); const r = btn.getBoundingClientRect(); c.style.left = Math.max(6, r.left + r.width / 2 - c.offsetWidth / 2) + "px"; c.style.top = (r.bottom + 6) + "px";
      setTimeout(() => { c.classList.add("out"); setTimeout(() => c.remove(), 350); }, 2600); setTimeout(() => btn.classList.remove("deal-auto"), 1600); } catch (e) { }
  }
  /* ---------- من بطاقة العميل: شريحة الاسعار / سعر اخر تعامل / التعامل الافتراضى ---------- */
  let lastCust = "";
  function fromCustomer() {
    const n = (nm && nm.value || "").trim(); if (n === lastCust) return; lastCust = n;
    const c = (window.CUSTOMERS_DATA || []).find(x => x.name === n), x = (c && c.x) || {};
    let t = "1";
    if (x.lastPrice === true || x.lastPrice === "true") t = "last";
    else if (x.tier) { const m = { "سعر البيع": "1", "سعر التجزئة": "2", "التجزئة": "2", "عابر سبيل": "3", "سعر استطلاع": "4", "سعر الجملة": "5", "الجملة": "5", "سعر 5 ومافوق": "6", "سعر 5ومافوق": "6", "سعر 6": "7", "سعر 7": "8", "سعر 8": "9" }; tiersAll().forEach(y => { if (y[0] !== "last" && !m[y[1]]) m[y[1]] = y[0]; }); t = m[x.tier] || "1"; }
    if (t !== tier) setTier(t, !n);
    if (n && x.terms) { const want = /^[أاآإ]جل$/.test(String(x.terms).trim()) ? "credit" : "cash"; if (want !== deal) { setDeal(want, true); if (deal === want) dealFlash(dealBtn, want === "credit" ? "أجل" : "كاش", want === "credit"); } }
    if (!n && deal === "credit") setDeal("cash", true);
  }
  if (nm) { nm.addEventListener("input", fromCustomer); nm.addEventListener("change", fromCustomer); }
  /* فاتورة جديدة: الشريحة 1 + كاش */
  try { const _r = resetInv; resetInv = function () { const res = _r.apply(this, arguments); lastCust = ""; setTier("1", true); setDeal("cash", true); return res; }; } catch (e) { }

  /* كل تبويب «مبيعات» يحتفظ بتعامله (كاش / أجل) وشريحته: فاتورة أجل في تبويب ما تنقلش للتبويب الجاي ،
     والتبويب الجديد يبدأ كاش (أو حسب العميل / الإعداد الافتراضى) — كان التعامل مشتركاً بين كل التبويبات */
  window.__salesSessLoad = function (s) {
    try {
      const n = (nm && nm.value || "").trim();
      if (s && s.deal) { lastCust = n; setTier(s.tier || "1", true); setDeal(s.deal === "credit" && n ? (s.inst ? "inst" : "credit") : "cash", true); return; }
      lastCust = ""; setTier("1", true); setDeal("cash", true); fromCustomer();
      const ps = (window.ANOUER_PROPS && ANOUER_PROPS.get("inv.sale", {})) || {};
      if (ps.cash === false && n && !document.querySelector(".inv.retmode")) setDeal("credit", true);
    } catch (e) { }
  };

  setTier("1", true); setDeal("cash", true);
})();
