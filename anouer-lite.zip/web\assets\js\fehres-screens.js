/* ANOUER — شاشات «الفهرس» (مطابقة DEXEF ONE). تعتمد على fehres.js (window.__FH). */
(function () {
  "use strict";
  const H = window.__FH, RV = window.__RV;
  if (!H || !RV) return;
  const { DB, Grid, Dlg, Form, IC, mkView, fileBar, ctxMenu, treeFlat, printList, csvList, fmt, fmtB, esc, say, num, pj, today, prods, HOST, call, lsGet, lsSet, tabOpen, tabClose, fillSel, BR, norm, fieldsChooser, fmtZ, r2 } = H;
  const main = document.querySelector(".main");
  const TI = RV.TI || {};
  const ask = (m, y) => { try { askConfirm(m, y); } catch (e) { if (confirm(m)) y(); } };
  const err = e => say((e && e.message) || String(e || "خطأ"), "e");
  const SCR = {};              // view → {refresh, newItem, edit, del, print}

  /* ================================================================ مصنع شاشات القوائم البسيطة */
  function ListScreen(c) {
    const el = mkView(c.view, c.title);
    let G = null, rows = [], built = false;
    const S = {
      refresh(force) {
        return Promise.resolve(c.load(force)).then(l => { rows = l || []; if (G) { G.set(c.filter ? rows.filter(c.filter(el)) : rows); } }).catch(err);
      },
      newItem() { c.dlg(null, () => S.refresh(true)); },
      edit() { const r = G && G.cur; if (!r) { say("اختر سطراً أولاً", "w"); return; } c.dlg(r, () => S.refresh(true)); },
      del() {
        const r = G && G.cur; if (!r) { say("اختر سطراً أولاً", "w"); return; }
        if (c.canDel && !c.canDel(r)) return;
        ask("هل تريد حذف «" + (r.name || r.no) + "» ؟", () => (c.onDel ? c.onDel(r) : DB.del(c.kind, r.id)).then(() => { say("تم الحذف", "s"); S.refresh(true); }).catch(err));
      },
      print() { printList(c.title, c.cols, G ? G.list : rows); },
      excel() { csvList(c.title, c.cols, G ? G.list : rows); },
      fields() { fieldsChooser(c.title, c.cols, hid => { lsSet("fh.hide." + c.title, hid); build(true); }); },
      close() { tabClose(c.key); },
      get grid() { return G; }, el
    };
    function build(re) {
      if (built && !re) return;
      built = true;
      el.innerHTML = "";
      const hid = new Set(lsGet("fh.hide." + c.title, []));
      const cols = c.cols.filter((x, i) => !hid.has(i));
      const MENU = [["إضافة", "Ctrl+N", IC.add, S.newItem], ["تعديل", "Ctrl+E", IC.edit, S.edit], ["تحديث البيانات", "F5", TI.refresh, () => S.refresh(true)], ["حذف", "Ctrl+D", IC.trash, S.del], ["عرض للطباعة", "Ctrl+P", IC.print, S.print], ["خروج", "Ctrl+Q", "", S.close]];
      if (c.style === "A") fileBar(el, { menu: MENU }, c.left === false ? [] : [["prv", "عرض للطباعة", IC.print, S.print]].concat(c.noFields ? [] : [["cols", "اختيار الحقول", IC.cols, S.fields]]));
      if (c.style === "D") { const b = document.createElement("div"); b.className = "fh-top"; b.innerHTML = `<button type="button" data-a="new">${IC.add}<span>جديد</span></button><span class="sp"></span><button type="button" data-a="prv" title="عرض للطباعة">${IC.print}</button>`; el.appendChild(b); b.addEventListener("click", e => { const x = e.target.closest("button"); if (!x) return; if (x.dataset.a === "new") S.newItem(); else S.print(); }); }
      if (c.ttl) { const t = document.createElement("div"); t.className = "fh-ttl"; t.textContent = c.ttl; el.appendChild(t); }
      if (c.sub) { const t = document.createElement("div"); t.className = "fh-sub"; t.textContent = c.sub; el.appendChild(t); }
      if (c.style !== "D") {
        const bar = document.createElement("div"); bar.className = "fh-bar"; bar.style.paddingTop = c.ttl ? "22px" : "10px";
        bar.innerHTML = `<button type="button" class="fh-btn${c.navy ? " navy" : ""}" data-new="1">${esc(c.newText || "جديد")}</button>${c.filters || ""}`;
        el.appendChild(bar);
        bar.querySelector("[data-new]").addEventListener("click", S.newItem);
        bar.addEventListener("change", () => S.refresh());
      }
      if (c.mtb) {
        const t = document.createElement("div"); t.className = "fh-mtb";
        t.innerHTML = `<div class="fh-srch"><span>${IC.srch}</span><input placeholder="" data-q="1"><span style="color:#2a6cc6;font-size:11px">✓</span></div><button type="button" data-a="view" title="طريقة العرض">${IC.view}▾</button>${c.mtbRight || ""}<span class="sp"></span><button type="button" data-a="new" title="إضافة">${IC.add}</button><button type="button" title="">▾</button><button type="button" data-a="xls">${IC.xls}<span>تصدير</span>▾</button><button type="button" data-a="cols">${IC.cols}<span>إختيار الحقول</span></button><button type="button" data-a="prv">${IC.print}<span>عرض للطباعة</span></button>`;
        el.appendChild(t);
        t.addEventListener("click", e => { const b = e.target.closest("button"); if (!b) return; const a = b.dataset.a; if (a === "new") S.newItem(); else if (a === "xls") S.excel(); else if (a === "cols") S.fields(); else if (a === "prv") S.print(); else if (a === "edit") S.edit(); else if (a === "del") S.del(); else if (a === "view") say("طريقة العرض: جدول", "i"); });
        t.querySelector("[data-q]").addEventListener("input", e => { const q = norm(e.target.value); G.set(rows.filter(r => !q || cols.some(x => x.f && norm(x.f(r)).includes(q))).filter(c.filter ? c.filter(el) : () => true)); });
      }
      const gh = document.createElement("div"); el.appendChild(gh);
      G = Grid(gh, { cols, tree: c.tree, openSet: c.openSet, foot: c.foot, off: r => r.active === false, onOpen: () => S.edit(), onDel: () => S.del(), onIcon: c.onIcon, rn: c.rn, empty: c.empty,
        ctx: (r, e) => ctxMenu([["إضافة", "Ctrl+N", IC.add, S.newItem], ["تعديل", "Ctrl+E", IC.edit, S.edit], ["حذف", "Ctrl+D", IC.trash, S.del], ["تحديث البيانات", "F5", TI.refresh, () => S.refresh(true)], ["عرض للطباعة", "Ctrl+P", IC.print, S.print]], { x: e.clientX + 190, y: e.clientY }) });
      if (rows.length) G.set(rows);
    }
    RV.VIEW_SHOW[c.view] = function () { build(); S.refresh(); setTimeout(() => G && G.focus(), 30); };
    SCR[c.view] = S;
    return S;
  }
  const branchF = (lbl) => `<label class="fh-f"><span>${esc(lbl || "اسم الفرع")}</span><select data-br="1">${BR.map(b => `<option>${esc(b)}</option>`).join("")}</select></label>`;
  const statusF = () => `<label class="fh-f"><span>الحالة</span><select data-st="1"><option value="1">نشط</option><option value="0">غير نشط</option><option value="">الكل</option></select></label>`;
  const activeF = () => `<label class="fh-chk" style="margin-bottom:4px"><input type="checkbox" data-act="1" checked><span>نشط</span></label>`;
  const stFilter = el => r => { const s = el.querySelector("[data-st]"), a = el.querySelector("[data-act]"); if (s && s.value !== "") return (r.active !== false) === (s.value === "1"); if (a && a.checked) return r.active !== false; return true; };
  const brName = d => (d && d.branch) || BR[0];

  /* ================================================================ المخازن */
  /* عدد الأصناف التي لها رصيد في المخزن (أرصدة المخازن) */
  function whCount(r) { const W = window.ANOUER_WH; if (!W || !W.ready) return r.no === "1" ? prods().length : (r.data.count || 0); return prods().filter(p => W.qty(p.id, r.id) !== 0).length; }
  function seedWh() {
    return DB.list("wh").then(l => l.length ? l : DB.bulk("wh", [{ no: "1", name: "المخزن الرئيسي", data: JSON.stringify({ branch: BR[0] }) }]).then(() => DB.list("wh", true)));
  }
  ListScreen({
    view: "fhwh", key: "fhwh", title: "مراجعة المخازن", kind: "wh", style: "A", newText: "إضافة مخزن", navy: 1,
    filters: branchF() + statusF(),
    load: force => (force ? DB.list("wh", true) : seedWh()).then(l => l.map(r => Object.assign(r, { _cnt: whCount(r) }))),
    filter: stFilter,
    cols: [{ t: "رقم المخزن", w: "150px", f: r => r.no, num: 1, v: r => +r.no || 0 }, { t: "الاسم", w: "minmax(180px,1.4fr)", f: r => r.name },
      { t: "عدد الاصناف", w: "140px", f: r => r._cnt, num: 1, v: r => r._cnt }, { t: "العنوان", w: "1fr", f: r => r.data.address || "" },
      { t: "عهدة الموظف", w: "1fr", f: r => r.data.rep || "" }, { t: "التاريخ", w: "130px", f: r => r.data.date || (r.no === "1" ? "" : r.date || ""), num: 1 },
      { t: "نشط", w: "70px", chk: 1, v: r => r.active !== false }],
    dlg: whDlg
  });
  /* «إضافة مخزن» مطابقة DEXEF ONE: نفس الترتيب والمسافات ، اسم الفرع و«المندوب» قوائم بحث شبكية (الاسم / الكود + صف تصفية + ✕ مسح) ،
     مساحة المخزن بأسهم ▲▼ ، هاتفان ، ورسالة «يجب ادخال جميع الحقول التى بجوارها نجمة حمراء» — لمستي: التصفية بالكتابة ، منع تكرار الرقم/الاسم */
  function whDlg(r, done) {
    const D = Dlg({ title: r ? "تعديل مخزن" : "إضافة مخزن", w: 624, onOk: d => save(d) });
    D.ov.querySelector(".fh-dlg").classList.add("whd");
    const F = Form(D.body, {
      icon: IC.wh,
      secs: [{ f: [{ k: "branch", t: "اسم الفرع", type: "select", opts: BR, req: 1 }, { k: "no", t: "رقم المخزن", req: 1, w: "w120" }, { k: "name", t: "اسم المخزن", req: 1 }] },
        { t: "بيانات اضافية", c: "b", f: [{ k: "rep", t: "المندوب", type: "select", blank: 1, opts: [] }, { k: "area", t: "مساحة المخزن", type: "num", w: "w120", sfx: "م2", def: 0 },
          { k: "phone", t: "الهاتف", extra: '<input data-k="phone2" class="wh-ph2">' }, { k: "address", t: "العنوان" }] }]
    });
    /* مساحة المخزن: أسهم ▲▼ مثل DEXEF */
    const ar = F.q("area"); if (ar) { ar.type = "text"; ar.inputMode = "decimal"; ar.insertAdjacentHTML("afterend", '<span class="wh-spn"><b data-s="1">▲</b><b data-s="-1">▼</b></span>');
      ar.parentNode.querySelector(".wh-spn").addEventListener("mousedown", e => { const b = e.target.closest("[data-s]"); if (!b) return; e.preventDefault(); ar.value = String(Math.max(0, r2((num(ar.value) || 0) + +b.dataset.s))); ar.focus(); });
      ar.addEventListener("keydown", e => { if (e.key === "ArrowUp" || e.key === "ArrowDown") { e.preventDefault(); ar.value = String(Math.max(0, r2((num(ar.value) || 0) + (e.key === "ArrowUp" ? 1 : -1)))); } }); }
    const reps = () => (window.__AC && __AC.docs ? __AC.docs("rep").catch(() => []) : Promise.resolve([])).then(l => (l || []).filter(x => x && (((x.data || {}).t) || "rep") === "rep" && x.active !== false).map(x => ({ no: String(x.no || ""), name: x.name || "" })));
    const LK = {
      branch: whLookup(F.q("branch"), { rows: () => Promise.resolve(BR.map((b, i) => ({ no: String(i + 1), name: b }))), cols: ["name", "no"], req: 1 }),
      rep: whLookup(F.q("rep"), { rows: reps, cols: ["no", "name"] })
    };
    if (r) F.set(Object.assign({}, r.data, { no: r.no, name: r.name, active: r.active !== false }));
    else DB.next("wh").then(n => F.set({ no: n }));
    Object.values(LK).forEach(k => k.sync());
    setTimeout(() => F.q("name").focus(), 30);
    function bad(msg, el) { if (el) el.classList.add("bad"); whMsg(msg, () => { if (el) el.focus(); }); return false; }
    function save(d) {
      let miss = null; ["branch", "no", "name"].forEach(k => { const x = F.q(k); const e = !String(x.value || "").trim(); (LK[k] ? LK[k].box : x).classList.toggle("bad", e); if (e && !miss) miss = LK[k] ? LK[k].input : x; });
      if (miss) return bad("يجب ادخال جميع الحقول التى بجوارها نجمة حمراء", miss);
      const v = F.get();
      return DB.list("wh").then(l => {
        const o = (l || []).filter(x => !r || x.id !== r.id);
        if (o.some(x => String(x.no).trim() === String(v.no).trim())) return bad("رقم المخزن «" + v.no + "» موجود من قبل", F.q("no"));
        if (o.some(x => norm(x.name) === norm(v.name))) return bad("اسم المخزن «" + v.name.trim() + "» موجود من قبل", F.q("name"));
        d.busy(1);
        return DB.save("wh", { id: r ? r.id : 0, no: v.no, name: v.name.trim(), active: v.active, data: Object.assign({}, r ? r.data : {}, { branch: v.branch, rep: v.rep, area: num(v.area), phone: v.phone, phone2: v.phone2, address: v.address, date: r ? (r.data.date || r.date) : today() }) })
          .then(() => { say("تم حفظ المخزن", "s"); d.close(); try { window.ANOUER_WH && ANOUER_WH.load(true); } catch (e) { } done(); }).catch(e => { d.busy(0); err(e); });
      });
    }
  }
  /* رسالة DEXEF: أيقونة «!» + النص + «موافق» أخضر في شريط رمادى — Enter / Esc للإغلاق */
  function whMsg(text, then) {
    const ov = document.createElement("div"); ov.className = "whm-ov";
    ov.innerHTML = `<div class="whm" role="alertdialog" aria-modal="true"><button type="button" class="x" title="إغلاق">✕</button><div class="b"><span class="ic"><svg viewBox="0 0 48 44" width="50" height="46"><rect x="2" y="2" width="44" height="32" rx="5" fill="#cfe3fb"/><rect x="2" y="2" width="44" height="32" rx="5" fill="none" stroke="#9cc4f2" stroke-width="2"/><rect x="21.5" y="8" width="5" height="15" rx="2.5" fill="#1f74e0"/><circle cx="24" cy="28" r="2.8" fill="#1f74e0"/><rect x="14" y="38" width="20" height="4" rx="2" fill="#1f74e0"/></svg></span><p>${esc(text)}</p></div><div class="f"><button type="button" class="ok">موافق</button></div></div>`;
    document.body.appendChild(ov);
    const prev = window.__FH_DLGKEY;
    const close = () => { ov.remove(); window.__FH_DLGKEY = prev; document.removeEventListener("keydown", kd, true); if (then) setTimeout(then, 0); };
    const kd = e => { if (e.key === "Enter" || e.key === "Escape" || e.key === " ") { e.preventDefault(); e.stopPropagation(); close(); } };
    window.__FH_DLGKEY = e => { if (e.key === "Enter" || e.key === "Escape") { close(); return true; } return true; };
    document.addEventListener("keydown", kd, true);
    ov.addEventListener("click", e => { if (e.target.closest(".ok,.x")) close(); });
    try { window.ANOUER_SOUND && ANOUER_SOUND("err"); } catch (e) { }
    setTimeout(() => { const k = ov.querySelector(".ok"); if (k) k.focus(); }, 20);
  }
  /* قائمة بحث شبكية بنمط DEXEF (LookUpEdit): تُخفى القائمة الأصلية وتبقى مصدر القيمة */
  const WHI = {
    dd: '<svg viewBox="0 0 10 10" width="9" height="9"><path d="M1.5 3.2L5 6.8l3.5-3.6" fill="none" stroke="#5b6573" stroke-width="1.3"/></svg>',
    abc: '<svg viewBox="0 0 22 12" width="20" height="11"><rect x=".5" y=".5" width="21" height="11" rx="2" fill="#e9f6ec" stroke="#2e8b57"/><text x="11" y="9" font-size="7.5" font-family="Arial" font-weight="700" fill="#2e8b57" text-anchor="middle">ABC</text></svg>',
    arr: '<svg viewBox="0 0 14 10" width="12" height="9"><path d="M13 5H2.5M6 1.2L2 5l4 3.8" fill="none" stroke="#2b7de0" stroke-width="1.5"/></svg>',
    flt: '<svg viewBox="0 0 12 12" width="10" height="10"><path d="M1 1.5h10L7 6.2V11L5 9.8V6.2z" fill="#8a96a5"/></svg>'
  };
  function whLookup(sel, o) {
    sel.style.display = "none";
    const box = document.createElement("span"); box.className = "whk";
    box.innerHTML = `<input autocomplete="off" spellcheck="false"><button type="button" class="dd" tabindex="-1" title="F4">${WHI.dd}</button>`;
    sel.after(box);
    const inp = box.querySelector("input"); let pop = null, rows = [], fi = -1, fq = { name: "", no: "" };
    const T = { box, input: inp, sync() { inp.value = sel.value || ""; } };
    function pick(x) {
      if (x && ![...sel.options].some(op => op.value === x.name)) sel.insertAdjacentHTML("beforeend", `<option>${esc(x.name)}</option>`);
      sel.value = x ? x.name : ""; inp.value = sel.value; box.classList.remove("bad"); sel.dispatchEvent(new Event("change", { bubbles: true })); close(); inp.focus();
    }
    const lst = () => { const q = norm(inp.dataset.typed ? inp.value : ""); return rows.filter(x => (!q || norm(x.name).includes(q) || x.no.startsWith(q)) && (!fq.name || norm(x.name).includes(norm(fq.name))) && (!fq.no || x.no.startsWith(fq.no))); };
    const head = c => c === "name" ? '<span class="nm">الاسم</span>' : '<span class="no">الكود</span>';
    function draw() {
      const l = lst(); if (fi >= l.length) fi = l.length - 1;
      pop.querySelector(".ls").innerHTML = l.map((x, i) => `<div class="r${i === fi ? " f" : ""}${x.name === sel.value ? " s" : ""}" data-i="${i}"><span class="ix">${i === fi ? WHI.arr : ""}</span>${o.cols.map(c => c === "name" ? `<span class="nm">${esc(x.name)}</span>` : `<span class="no">${esc(x.no)}</span>`).join("")}</div>`).join("") || '<div class="e"></div>';
    }
    function open() {
      if (pop) return;
      Promise.resolve(o.rows()).then(l => {
        rows = l || []; if (pop) return;
        pop = document.createElement("div"); pop.className = "whk-pop";
        pop.innerHTML = `<div class="hd"><span class="ix"></span>${o.cols.map(head).join("")}</div>
          <div class="fr"><span class="ix">${WHI.flt}</span>${o.cols.map(c => `<span class="${c === "name" ? "nm" : "no"}"><input data-f="${c}" placeholder=" "><i>${c === "name" ? WHI.abc : "="}</i></span>`).join("")}</div>
          <div class="ls"></div><div class="ft"><span class="gr">⋰</span><button type="button" class="cx" title="مسح">✕</button></div>`;
        document.body.appendChild(pop);
        const rc = box.getBoundingClientRect(); pop.style.left = Math.max(4, rc.right - 274) + "px";
        let tp = rc.bottom + 2; if (tp + 300 > innerHeight) tp = Math.max(4, rc.top - 302); pop.style.top = tp + "px";
        fi = Math.max(0, lst().findIndex(x => x.name === sel.value)); draw(); box.classList.add("on");
        pop.addEventListener("mousedown", e => { if (!e.target.closest("input")) e.preventDefault(); });
        pop.querySelector(".ls").addEventListener("click", e => { const d = e.target.closest("[data-i]"); if (d) pick(lst()[+d.dataset.i]); });
        pop.querySelector(".ls").addEventListener("mousemove", e => { const d = e.target.closest("[data-i]"); if (d && +d.dataset.i !== fi) { fi = +d.dataset.i; draw(); } });
        pop.querySelector(".fr").addEventListener("input", e => { const f = e.target.dataset.f; if (f) { fq[f] = e.target.value.trim(); fi = 0; draw(); } });
        pop.querySelector(".cx").addEventListener("click", () => { if (o.req) { close(); inp.focus(); return; } pick(null); });
        setTimeout(() => document.addEventListener("mousedown", out, true), 0);
        /* مفاتيح النافذة (Esc / Enter) تمر أولاً على القائمة المفتوحة */
        PREVK = window.__FH_DLGKEY; WR = true; window.__FH_DLGKEY = e => { if (pop && ["Escape", "Enter", "ArrowUp", "ArrowDown", "F4"].includes(e.key)) { e.__whk = 1; keys(e); return true; } return PREVK ? PREVK(e) : false; };
      });
    }
    let PREVK = null, WR = false;
    function keys(e) {
      const k = e.key, l = lst();
      if (k === "ArrowDown") { e.preventDefault(); fi = Math.min(l.length - 1, fi + 1); draw(); }
      else if (k === "ArrowUp") { e.preventDefault(); fi = Math.max(0, fi - 1); draw(); }
      else if (k === "Enter") { e.preventDefault(); if (l[fi]) pick(l[fi]); }
      else if (k === "Escape" || k === "F4") { e.preventDefault(); close(); T.sync(); }
    }
    function out(e) { if (pop && !pop.contains(e.target) && !box.contains(e.target)) { close(); T.sync(); } }
    function close() { if (!pop) return; if (WR) { window.__FH_DLGKEY = PREVK; PREVK = null; WR = false; } pop.remove(); pop = null; fq = { name: "", no: "" }; delete inp.dataset.typed; box.classList.remove("on"); document.removeEventListener("mousedown", out, true); }
    box.querySelector(".dd").addEventListener("mousedown", e => e.preventDefault());
    box.querySelector(".dd").addEventListener("click", () => { if (pop) { close(); T.sync(); } else open(); inp.focus(); });
    inp.addEventListener("click", () => { if (!pop) open(); });
    inp.addEventListener("input", () => { inp.dataset.typed = "1"; if (!pop) open(); else { fi = 0; draw(); } });
    inp.addEventListener("keydown", e => {
      const k = e.key;
      if (!pop) { if (k === "F4" || k === "ArrowDown") { e.preventDefault(); open(); } return; }
      if (!e.__whk) { e.stopPropagation(); keys(e); }
    });
    inp.addEventListener("blur", () => setTimeout(() => { if (pop && !pop.contains(document.activeElement)) { close(); T.sync(); } else if (!pop) T.sync(); }, 160));
    return T;
  }
  function users() { return (CACHE_USERS || []).map(u => ({ id: u.id, name: u.name || u.user })); }
  let CACHE_USERS = null;

  /* ================================================================ مجموعات الأصناف (شجرة) */
  function seedGroups() {
    return DB.list("igrp").then(l => {
      if (l.length) return l;
      const p = H.HOSTB() ? call("fm.cat.groupCounts").catch(() => Array.from(new Set(prods().map(x => x.cat).filter(Boolean))).map(n => ({ name: n }))) : Promise.resolve(Array.from(new Set(prods().map(x => x.cat).filter(Boolean))).map(n => ({ name: n })));
      return p.then(gs => { const rows = (gs || []).filter(g => g.name).map((g, i) => ({ no: String(i + 1), name: g.name, data: JSON.stringify({ order: 0 }) })); return rows.length ? DB.bulk("igrp", rows).then(() => DB.list("igrp", true)) : []; });
    });
  }
  const IGOPEN = new Set();
  ListScreen({
    view: "fhig", key: "fhig", title: "مراجعة المجموعات", kind: "igrp", style: "A", noFields: 1, tree: 1, openSet: IGOPEN, rn: false,
    load: force => (force ? DB.list("igrp", true) : seedGroups()).then(l => {
      const cnt = {}; prods().forEach(p => { const k = p.cat || ""; cnt[k] = (cnt[k] || 0) + 1; });
      const f = treeFlat(l.map(r => Object.assign(r, { _cnt: cnt[r.name] || 0 })), (a, b) => (+a.no || 0) - (+b.no || 0) || String(a.no).localeCompare(String(b.no)));
      f.forEach(r => { if (r._kids && !IGOPEN.__init) IGOPEN.add(r.id); }); IGOPEN.__init = 1;
      return f;
    }),
    cols: [{ t: "اسم المجموعة", w: "minmax(220px,1.3fr)", f: r => r.name, tree: 1, icon: () => IC.doc }, { t: "الكود", w: "200px", f: r => r.no, num: 1, v: r => +r.no || r.no },
      { t: "الوصف", w: "1.2fr", f: r => r.data.desc || "" }, { t: "عدد الأصناف", w: "150px", f: r => r._cnt, num: 1, v: r => r._cnt },
      /* «الحالة» = نشط (مثل DEXEF): المجموعة المعلَّمة ✓ تظهر في نافذة البحث (F5) والأصناف بالصور (F10) — اضغط المربع للتغيير */
      { t: "الحالة", w: "180px", chk: 1, chkTip: "نشط: تظهر في نافذة البحث والأصناف بالصور — اضغط للتغيير", v: r => r.active !== false,
        onChk: (r, el, rerender) => { if (!r) return; const on = !(r.active !== false); r.active = on; el.classList.toggle("y", on); el.classList.add("busy");
          DB.save("igrp", { id: r.id, no: r.no, name: r.name, parentId: r.parentId || 0, active: on, data: r.data || {} })
            .then(() => { el.classList.remove("busy"); H.say((on ? "تم تنشيط" : "تم إيقاف") + " المجموعة: " + r.name, "s"); })
            .catch(e => { r.active = !on; el.classList.toggle("y", !on); el.classList.remove("busy"); H.say(e.message || e, "e"); }); } }, { t: "ترتيب الظهور", w: "160px", f: r => r.data.order || 0, num: 1, v: r => +r.data.order || 0 }],
    dlg: grpDlg,
    /* الحذف (مثل DEXEF): لا تُحذف مجموعة بها أصناف أو مجموعات فرعية */
    onDel: r => DB.list("igrp").then(l => {
      const kids = (l || []).filter(x => x.parentId === r.id).length, n = prods().filter(p => String(p.cat || "").trim() === r.name).length;
      if (n) throw new Error("لا يمكن حذف المجموعة «" + r.name + "» — بها " + n + " صنف. انقل الأصناف لمجموعة أخرى أولاً");
      if (kids) throw new Error("لا يمكن حذف المجموعة «" + r.name + "» — تتدرج منها " + kids + " مجموعة فرعية");
      return DB.del("igrp", r.id).then(x => { try { document.dispatchEvent(new CustomEvent("anouer:igrp")); } catch (e) { } return x; });
    })
  });
  /* مطابقة DEXEF ONE (نافذة المجموعة): الأنواع وطرق التقييم والتجانس بنفس خيارات DEXEF */
  const ITYPES = ["مخزون", "خدمة", "مخزون بسيريال", "مخزون بصلاحية", "بضاعة أمانة"], VALM = ["الوارد أولاً صادر أولاً", "المتوسط المرجح"];
  const HOMO = ["جميع وحدات الصنف متجانسة", "يحتوى على نوعين مختلفين", "يحتوى على ثلاثة أنواع مختلفة"];
  const HOMO_OLD = { "متجانسة": HOMO[0], "غير متجانسة": HOMO[1] };
  /* حقول الحسابات: [المفتاح, الجذر في شجرة الحسابات, عُقد تُخفى] — نفس جذور بطاقة الصنف */
  const GACC = { taxAcc: ["21", []], dTaxAcc: ["21", []], aStock: ["", []], aSale: ["4", ["41"]], aCogs: ["3", []], aRet: ["4", ["41"]], aWip: ["", []] };
  function grpDlg(r, done) {
    const D = Dlg({ title: r ? "تعديل مجموعة" : "مجموعة جديدة", w: 1090, onOk: d => save(d) });
    D.ov.querySelector(".fh-dlg").classList.add("grd");
    Promise.all([DB.list("igrp"), loadGla()]).then(([all]) => {
      const par = [["", ""]].concat(all.filter(x => !r || x.id !== r.id).map(x => [x.id, x.name]));
      const unitOpt = (k, sfx) => `<select data-k="${k}u" class="w80"><option>${sfx}</option>${sfx === "قطعة" ? "<option>كرتونة</option>" : "<option>شهر</option>"}</select>`;
      const F = Form(D.body, {
        icon: IC.grp,
        secs: [{ f: [{ k: "no", t: "الرقم", req: 1, w: "w120", extra: '<button type="button" class="grd-gen" title="توليد رقم تلقائى">▮▮▯</button>' }, { k: "name", t: "الاسم", req: 1 }, { k: "parentId", t: "تتدرج من", type: "select", opts: par }] }],
        after: `<div class="fh-tabs"><button type="button" class="on" data-tp="0">عام</button><button type="button" data-tp="1">الحسابات</button><button type="button" data-tp="2">المعادلة</button></div>
          <div class="fh-tp on" data-p="0"><div class="fh-2c"><div>${secHTMLs([{ t: "الخصائص", c: "b", f: [{ k: "itype", t: "نوع الصنف", type: "select", blank: 1, opts: ITYPES }, { k: "valm", t: "طريقة التقييم", type: "select", opts: VALM }, { k: "loc1", t: "مكان التخزين", extra: '<input data-k="loc2" style="flex:1"><input data-k="loc3" style="flex:1">' }, { k: "homo", t: "التجانس بين الوحدات", type: "select", blank: 1, opts: HOMO }, { k: "sup", t: "اسم المورد", type: "select", blank: 1, opts: [] }] },
            { t: "الوصف", c: "b", f: [{ k: "desc", t: "", type: "textarea" }] }, { t: "شاشة اللمس", c: "b", f: [{ k: "hideTouch", t: "", type: "check", lbl: "اخفاء من شاشة اللمس" }, { k: "order", t: "ترتيب الظهور فى شاشة", type: "num", w: "w120", def: 1 }] }])}</div>
            <div class="grd-side"><div class="fh-img" data-img="1"><b>x</b></div><span>الصورة</span><div class="grd-live"></div></div></div></div>
          <div class="fh-tp" data-p="1"><div class="fh-2c"><div>${secHTMLs([{ t: "الضرائب", c: "b", f: [{ k: "taxable", t: "يخضع للضريبة", type: "select", blank: 1, opts: ["نعم", "لا"] }, { k: "taxAcc", t: "حساب الضريبة", type: "select", blank: 1, opts: [] }, { k: "taxSale", t: "نسبة الضريبة المبيعات", type: "num", w: "w80", req: 1, def: 0 }, { k: "taxRate", t: "نسبة الضريبة", type: "num", w: "w80", req: 1, def: 0 }, { k: "incl", t: "هل السعر يشمل", type: "select", blank: 1, opts: ["يشمل الضريبة", "لا يشمل الضريبة"] }, { k: "dTax", t: "يخضع لضريبة الخصم", type: "select", blank: 1, opts: ["نعم", "لا"] }, { k: "dTaxAcc", t: "حساب ضريبة الخصم", type: "select", blank: 1, opts: [] }, { k: "dTaxRate", t: "نسبة الضريبة", type: "num", w: "w80", def: 0 }] },
              { t: "التنبيهات", c: "b", f: [{ k: "min", t: "الحد الادنى", type: "num", w: "w120", extra: unitOpt("min", "قطعة") }, { k: "max", t: "الحد الأقصى", type: "num", w: "w120", extra: unitOpt("max", "قطعة") }, { k: "stag", t: "فترة الركود", type: "num", w: "w120", extra: unitOpt("stag", "يوم") }, { k: "expW", t: "التنبيه قبل انتهاء الصلاحية بـ", type: "num", w: "w120", extra: unitOpt("expW", "يوم") }] }])}</div>
            <div>${secHTMLs([{ t: "الحسابات", c: "b", f: [{ k: "aStock", t: "حساب المخزون", type: "select", blank: 1, opts: [] }, { k: "aSale", t: "حساب المبيعات", type: "select", blank: 1, opts: [] }, { k: "aCogs", t: "حساب تكلفة المبيعات", type: "select", blank: 1, opts: [] }, { k: "aRet", t: "حساب مرتجع المبيعات", type: "select", blank: 1, opts: [] }, { k: "aWip", t: "حساب تحت التشغيل", type: "select", blank: 1, opts: [] }] },
              { t: "الخصم", c: "b", f: [{ k: "dMode", t: "طريقة الخصم", type: "select", blank: 1, opts: ["نسبة", "قيمة"] }, { k: "early", t: "يخضع خصم التعجيل", type: "select", blank: 1, opts: ["نعم", "لا"] }, { k: "dBuy", t: "خصم المشتريات", type: "num", w: "w80", sfx: "%", def: 0 }, { k: "dSale", t: "خصم المبيعات", type: "num", w: "w80", sfx: "%", def: 0 }] },
              { t: "خصائص أخرى", c: "b", f: [{ k: "labor", t: "مصنعية التركيب", type: "select", blank: 1, opts: ["نعم", "لا"] }] }])}</div></div></div>
          <div class="fh-tp" data-p="2"><div class="fh-mini grd-eq"><table><thead><tr><th style="width:26px"></th><th>الاسم</th><th>الحقل</th><th>المعادلة</th><th style="width:30px"></th></tr></thead><tbody data-eq="1"></tbody></table>
            <p class="grd-eqh">ƒ اختر معادلة من «معادلة الأصناف» (الخصائص ← المخازن) — الصنف الجديد في هذه المجموعة يأخذها تلقائياً وتنفتح حاسبتها عند البيع</p></div></div>`
      });
      const q = F.q, AC = window.__AC;
      D.body.querySelector(".fh-tabs").addEventListener("click", e => { const b = e.target.closest("[data-tp]"); if (!b) return; D.body.querySelectorAll("[data-tp]").forEach(x => x.classList.toggle("on", x === b)); D.body.querySelectorAll("[data-p]").forEach(x => x.classList.toggle("on", x.dataset.p === b.dataset.tp)); });
      /* ---- القيم ---- */
      const d0 = r ? Object.assign({}, r.data) : {};
      if (d0.homo && HOMO_OLD[d0.homo]) d0.homo = HOMO_OLD[d0.homo];
      if (d0.valm && !VALM.includes(d0.valm)) d0.valm = /المرجح/.test(d0.valm) ? VALM[1] : VALM[0];
      if (d0.itype && !ITYPES.includes(d0.itype)) q("itype").insertAdjacentHTML("beforeend", `<option>${esc(d0.itype)}</option>`);
      F.set({ taxSale: 0, taxRate: 0, dTaxRate: 0, dBuy: 0, dSale: 0, order: 1, valm: VALM[0] });
      if (r) F.set(Object.assign({}, d0, { no: r.no, name: r.name, parentId: r.parentId || "", active: r.active !== false }));
      else DB.next("igrp").then(n => F.set({ no: n }));
      D.body.querySelector(".grd-gen").addEventListener("click", () => DB.next("igrp").then(n => { q("no").value = n; q("no").classList.remove("bad"); }));
      /* ---- «تتدرج من»: شجرة المجموعات (الرقم / الاسم) — المجموعة نفسها وفروعها لا تظهر (منع الحلقات) ---- */
      const banned = new Set(); if (r) { banned.add(r.id); let ch = true; while (ch) { ch = false; all.forEach(x => { if (!banned.has(x.id) && banned.has(x.parentId)) { banned.add(x.id); ch = true; } }); } }
      const gTree = () => { const rows = all.filter(x => !banned.has(x.id)).map(x => ({ id: x.id, no: String(x.no || ""), name: String(x.name || ""), pid: x.parentId || 0, d: {}, kids: [], par: null }));
        const byId = {}; rows.forEach(n => { byId[n.id] = n; }); rows.forEach(n => { const p = byId[n.pid]; if (p && p !== n) { n.par = p; p.kids.push(n); } });
        const cmp = (a, b) => a.no.localeCompare(b.no, "en", { numeric: true }); rows.forEach(n => n.kids.sort(cmp));
        const byNo = {}; rows.forEach(n => { byNo[n.no] = n; }); return Promise.resolve({ rows, byNo, roots: rows.filter(n => !n.par).sort(cmp) }); };
      const ps = q("parentId");
      if (AC && AC.treePicker) {
        ps.style.display = "none"; const h = document.createElement("span"); h.className = "grd-tp"; ps.after(h);
        const cur = all.find(x => String(x.id) === String(ps.value));
        AC.treePicker(h, { key: "grpPar", source: gTree, pickGroups: true, noCol: true, cls: "grd-pop", width: 380, value: cur ? cur.name : "", ph: "", empty: "لا توجد مجموعات", unit: "مجموعة", onChange: n => { ps.value = n ? String(n.id) : ""; live(); } }).input.removeAttribute("data-k");
      }
      /* ---- اسم المورد: قائمة بحث (الاسم / الكود) ---- */
      const supRows = () => { try { const l = (window.ANOUER_SUPPLIERS && ANOUER_SUPPLIERS.list && ANOUER_SUPPLIERS.list()) || []; return Promise.resolve(l.map(s => ({ no: String(s.no || s.code || s.Code || s.id || ""), name: s.name || s.Name || "" })).filter(s => s.name)); } catch (e) { return Promise.resolve([]); } };
      const SUPL = whLookup(q("sup"), { rows: supRows, cols: ["name", "no"] }); if (d0.sup) { q("sup").insertAdjacentHTML("beforeend", `<option>${esc(d0.sup)}</option>`); q("sup").value = d0.sup; } SUPL.sync();
      /* ---- الحسابات: من «شجرة الحسابات» (القيم القديمة المحفوظة بالرقم تُحوَّل للاسم) ---- */
      if (AC && AC.treePicker) Object.keys(GACC).forEach(k => {
        const sel = q(k); if (!sel) return; sel.style.display = "none"; const h = document.createElement("span"); h.className = "grd-tp acc"; sel.after(h);
        const P = AC.treePicker(h, { key: "grp_" + k, root: GACC[k][0] || undefined, hide: GACC[k][1], value: "", ph: "اختر من شجرة الحسابات", onChange: n => { const v = n ? n.name : ""; if (v && ![...sel.options].some(o => o.value === v)) sel.insertAdjacentHTML("beforeend", `<option>${esc(v)}</option>`); sel.value = v; } });
        P.input.removeAttribute("data-k");
        const v0 = d0[k]; if (v0) AC.coaTree().then(t => { const n = t.byNo[String(v0)] || t.rows.find(x => x.name === v0); const nm = n ? n.name : String(v0); if (![...sel.options].some(o => o.value === nm)) sel.insertAdjacentHTML("beforeend", `<option>${esc(nm)}</option>`); sel.value = nm; P.set(nm, n || null); }).catch(() => { });
      });
      /* ---- أسهم ▲▼ للأرقام (مثل DEXEF) ---- */
      ["taxSale", "taxRate", "dTaxRate", "dBuy", "dSale", "order", "min", "max", "stag", "expW"].forEach(k => { const x = q(k); if (!x || x.__spn) return; x.__spn = 1; x.type = "text"; x.inputMode = "decimal";
        x.insertAdjacentHTML("beforebegin", '<span class="grd-spn"><b data-s="1">▲</b><b data-s="-1">▼</b></span>');
        x.previousElementSibling.addEventListener("mousedown", e => { const b = e.target.closest("[data-s]"); if (!b) return; e.preventDefault(); x.value = String(Math.max(0, r2((num(x.value) || 0) + +b.dataset.s))); x.dispatchEvent(new Event("input", { bubbles: true })); x.focus(); });
        x.addEventListener("keydown", e => { if (e.key === "ArrowUp" || e.key === "ArrowDown") { e.preventDefault(); x.value = String(Math.max(0, r2((num(x.value) || 0) + (e.key === "ArrowUp" ? 1 : -1)))); } }); });
      /* ---- المعادلة: الاسم من «معادلة الأصناف» ← الحقل والمعادلة تُملأ تلقائياً ---- */
      const EQL = () => { try { return window.ANOUER_ITEMEQ ? ANOUER_ITEMEQ.list() : []; } catch (e) { return []; } };
      const eqB = D.body.querySelector("[data-eq]");
      const eqs = (d0.eq || []).slice();
      function eqRender() {
        const L = EQL();
        eqB.innerHTML = eqs.concat([{}]).map((x, i) => { const has = i < eqs.length; const opts = '<option value=""></option>' + L.map(e => `<option${e.name === x.n ? " selected" : ""}>${esc(e.name)}</option>`).join("") + (x.n && !L.some(e => e.name === x.n) ? `<option selected>${esc(x.n)}</option>` : "");
          return `<tr data-r="${i}"><td class="ix">${has ? "" : "✱"}</td><td><select data-e="n">${opts}</select></td><td class="ro">${esc(x.f || "")}</td><td class="ro eqv">${esc(x.q || "")}</td><td>${has ? '<span data-ex="1" class="grd-x" title="حذف">✕</span>' : ""}</td></tr>`; }).join("");
      }
      eqRender();
      eqB.addEventListener("change", e => { const s = e.target.closest("[data-e]"); if (!s) return; const i = +s.closest("tr").dataset.r, E = EQL().find(z => z.name === s.value);
        if (!s.value) { if (i < eqs.length) eqs.splice(i, 1); eqRender(); return; }
        if (eqs.some((z, k) => k !== i && z.n === s.value)) { say("المعادلة «" + s.value + "» مضافة من قبل", "w"); eqRender(); return; }
        const row = { n: s.value, f: E ? E.field : "", q: E ? E.eq : "" }; if (i >= eqs.length) eqs.push(row); else eqs[i] = row; eqRender(); live(); });
      eqB.addEventListener("click", e => { if (e.target.closest("[data-ex]")) { eqs.splice(+e.target.closest("tr").dataset.r, 1); eqRender(); live(); } });
      /* ---- الصورة ---- */
      const img = D.body.querySelector("[data-img]"); let imgData = d0.img || "";
      const showImg = () => { img.style.backgroundImage = imgData ? `url("${imgData}")` : ""; img.classList.toggle("has", !!imgData); live(); };
      img.addEventListener("click", e => {
        if (e.target.tagName === "B") { imgData = ""; showImg(); return; }
        const i = document.createElement("input"); i.type = "file"; i.accept = "image/*";
        i.onchange = () => { const f = i.files && i.files[0]; if (!f) return; const rd = new FileReader(); rd.onload = () => { const im = new Image(); im.onload = () => { const c = document.createElement("canvas"), s2 = Math.min(1, 240 / Math.max(im.width, im.height)); c.width = im.width * s2; c.height = im.height * s2; c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); imgData = c.toDataURL("image/jpeg", .82); showImg(); }; im.src = rd.result; }; rd.readAsDataURL(f); };
        i.click();
      });
      /* ---- لمستي 2026: بطاقة حيّة — عدد الأصناف، المسار، معاينة مربع شاشة اللمس، والإعدادات التى سترثها الأصناف ---- */
      const liveEl = D.body.querySelector(".grd-live");
      function path() { const a = []; let id = +ps.value || 0, g = 0; while (id && g++ < 20) { const x = all.find(z => z.id === id); if (!x) break; a.unshift(x.name); id = x.parentId || 0; } return a; }
      function live() {
        const nm = (q("name").value || "").trim() || "اسم المجموعة", oldNm = r ? r.name : "", cnt = oldNm ? prods().filter(p => String(p.cat || "").trim() === oldNm).length : 0;
        const inh = []; if (q("itype").value) inh.push(q("itype").value); if (q("sup").value) inh.push("🚚 " + q("sup").value); if (num(q("dSale").value) > 0) inh.push("خصم " + num(q("dSale").value) + "%"); if (q("taxable").value) inh.push("الضريبة: " + q("taxable").value); if (eqs.length) inh.push("ƒ " + eqs[0].n); if (q("loc1").value) inh.push("📍 " + q("loc1").value);
        const hid = q("hideTouch").checked || !q("active").checked;
        liveEl.innerHTML = `<div class="gl-t${hid ? " off" : ""}"${imgData ? ` style="background-image:url('${imgData}')"` : ""}><i>${IC.grp}</i><b>${esc(nm)}</b><small>#${esc(q("order").value || "1")}</small></div>
          <div class="gl-k">${hid ? "🙈 مخفية من شاشة اللمس" : "👁 تظهر في شاشة اللمس"}</div>
          ${path().length ? `<div class="gl-p">📂 ${path().map(esc).join(" › ")} › <b>${esc(nm)}</b></div>` : ""}
          ${r ? `<div class="gl-c"><b>${cnt}</b> صنف في المجموعة</div>` : ""}
          ${inh.length ? `<div class="gl-i"><small>الأصناف الجديدة سترث:</small>${inh.map(x => `<span>${esc(x)}</span>`).join("")}</div>` : ""}`;
      }
      D.body.addEventListener("input", live); D.body.addEventListener("change", live); showImg();
      /* ---- «تطبيق على أصناف المجموعة» (لمستي): نشر الإعدادات على الأصناف الموجودة ---- */
      if (r) { const ft = D.ov.querySelector(".fh-dfoot"); ft.insertAdjacentHTML("beforeend", '<button type="button" class="fh-btn grd-apply" title="نشر إعدادات المجموعة على كل أصنافها الحالية">⚡ تطبيق على أصناف المجموعة</button>');
        ft.querySelector(".grd-apply").addEventListener("click", () => { const P = prods().filter(p => String(p.cat || "").trim() === r.name); if (!P.length) { say("لا توجد أصناف في هذه المجموعة", "i"); return; }
          ask("سيتم تطبيق إعدادات المجموعة (التقييم، التجانس، المورد، مكان التخزين، الحسابات، الضرائب، الخصومات، التنبيهات، المعادلة) على " + P.length + " صنف. هل تريد المتابعة ؟", () => {
            const g = Object.assign({}, F.get(), { eq: eqs }); if (window.ANOUER_GRP) ANOUER_GRP.applyToItems(P, g).then(n => say("✔ تم تطبيق الإعدادات على " + n + " صنف", "s")).catch(err); }); }); }
      setTimeout(() => q("name").focus(), 30);
      D.save = d => {
        if (!F.validate()) return;
        const v = F.get();
        if (all.some(x => (!r || x.id !== r.id) && String(x.no).trim() === String(v.no).trim())) { whMsg("الرقم «" + v.no + "» موجود من قبل", () => q("no").focus()); return; }
        if (all.some(x => (!r || x.id !== r.id) && norm(x.name) === norm(v.name))) { whMsg("المجموعة «" + v.name.trim() + "» موجودة من قبل", () => q("name").focus()); return; }
        d.busy(1);
        const data = Object.assign({}, r ? r.data : {}, v, { eq: eqs.filter(x => x.n || x.f || x.q), img: imgData });
        ["no", "name", "parentId", "active"].forEach(k => delete data[k]); Object.keys(data).forEach(k => { if (/^grp(_|Par$)/.test(k)) delete data[k]; });
        const nn = v.name.trim(), ren = r && r.name !== nn ? r.name : "";
        DB.save("igrp", { id: r ? r.id : 0, no: v.no, name: nn, parentId: +v.parentId || 0, active: v.active, data })
          .then(() => ren && window.ANOUER_GRP ? ANOUER_GRP.rename(ren, nn).then(n => { if (n) say("تم نقل " + n + " صنف إلى الاسم الجديد «" + nn + "»", "i"); }) : null)
          .then(() => { say("تم حفظ المجموعة", "s"); try { document.dispatchEvent(new CustomEvent("anouer:igrp")); } catch (e) { } d.close(); done(); }).catch(e => { d.busy(0); err(e); });
      };
    });
    function save(d) { if (d.save) d.save(d); }
  }
  window.__FH_GRPDLG = grpDlg;   /* بطاقة الصنف: زر (+) بجانب المجموعة */
  function secHTMLs(secs) { const tmp = document.createElement("div"); Form(tmp, { side: false, secs }); return tmp.innerHTML; }
  function SUPS() { try { const l = (window.ANOUER_SUPPLIERS && window.ANOUER_SUPPLIERS.list && window.ANOUER_SUPPLIERS.list()) || []; return l.map(s => s.name || s.Name).filter(Boolean); } catch (e) { return []; } }

  /* ================================================================ الأصناف البديلة */
  ListScreen({
    view: "fhalt", key: "fhalt", title: "مراجعة الاصناف البديلة", kind: "alt", style: "D",
    load: force => DB.list("alt", force),
    cols: [{ t: "الرقم", w: "120px", f: r => r.no, num: 1, v: r => +r.no || 0 }, { t: "الاسم", w: "1.2fr", f: r => r.name }, { t: "عدد الاصناف", w: "130px", f: r => (r.data.items || []).length, num: 1 },
      { t: "المتوفر منها", w: "120px", f: r => (r.data.items || []).filter(id => { const p = prods().find(x => x.id == id); return p && (+p.stock || 0) > 0; }).length, num: 1 },
      { t: "الأصناف", w: "2fr", f: r => (r.data.items || []).map(id => { const p = prods().find(x => x.id == id); return p ? p.name : ""; }).filter(Boolean).join(" ⇄ ") },
      { t: "الوصف", w: "1.2fr", f: r => r.data.desc || "" }],
    onDel: r => DB.del("alt", r.id).then(x => { try { document.dispatchEvent(new CustomEvent("anouer:alt")); } catch (e) { } return x; }),
    dlg: altDlg
  });
  function altDlg(r, done) {
    if (window.ANOUER_ALT && ANOUER_ALT.dlg) { ANOUER_ALT.dlg(r, done); return; }   /* النافذة الاحترافية 2026 — alt-items.js */
    const D = Dlg({ title: "", w: 700, okText: "موافق", onOk: d => save(d) });
    D.body.innerHTML = `<div class="fh-desc"><div><h3>الصنف البديل</h3><p>يستخدم الصنف البديل للربط بين اكثر من صنف لهم صفه مشابهه من حيث الاستخدام .. ومن خلالها تستطيع أثناء البيع في حالة أن الصنف المطلوب غير موجود , أن تقوم باستبداله بالصنف المشابه له في الاستخدام</p></div></div><div data-f="1"></div>
      <div class="fh-sec b" style="margin-top:8px"><h4>الاصناف</h4><div class="bx"><div class="fh-mini" style="height:190px"><table><thead><tr><th style="width:24px"></th><th>الكود</th><th>اسم الصنف</th><th style="width:30px"></th></tr></thead><tbody data-it="1"></tbody></table></div></div></div>`;
    const F = Form(D.body.querySelector("[data-f]"), { side: false, secs: [{ t: "بيانات أساسية", f: [{ k: "no", t: "الرقم", req: 1, w: "w120" }, { k: "name", t: "الاسم", req: 1 }, { k: "desc", t: "الوصف", type: "textarea" }] }] });
    const items = (r && r.data.items ? r.data.items.slice() : []);
    const tb = D.body.querySelector("[data-it]");
    const pBy = id => prods().find(p => p.id == id);
    function render(focusNew) {
      tb.innerHTML = items.map((id, i) => { const p = pBy(id) || {}; return `<tr><td>${i + 1}</td><td>${esc(p.code || id)}</td><td class="t">${esc(p.name || "")}</td><td><span data-x="${i}" style="color:#e53935;cursor:pointer;font-weight:700">✕</span></td></tr>`; }).join("") +
        `<tr><td>←</td><td><input data-code="1" class="fh-noenter" list="fhAltList" style="width:100%;border:1px solid #c8ced6;height:22px" placeholder="الكود أو الاسم"></td><td class="t" style="color:#999">Enter للإضافة</td><td><span style="color:#e53935">✕</span></td></tr>`;
      if (focusNew) setTimeout(() => { const x = tb.querySelector("[data-code]"); if (x) x.focus(); }, 0);
    }
    let dl = G("fhAltList"); if (!dl) { dl = document.createElement("datalist"); dl.id = "fhAltList"; document.body.appendChild(dl); }
    dl.innerHTML = prods().slice(0, 4000).map(p => `<option value="${esc(p.code)}">${esc(p.name)}</option>`).join("");
    render();
    tb.addEventListener("click", e => { const x = e.target.closest("[data-x]"); if (x) { items.splice(+x.dataset.x, 1); render(true); } });
    tb.addEventListener("keydown", e => {
      if (e.key !== "Enter" || !e.target.dataset.code) return;
      e.preventDefault(); e.stopPropagation();
      const v = e.target.value.trim(); if (!v) return;
      const q = norm(v), p = prods().find(x => String(x.code) === v || (x.barcode || "").split(" ").includes(v)) || prods().find(x => norm(x.name) === q) || prods().find(x => norm(x.name).includes(q));
      if (!p) { say("لا يوجد صنف بهذا الكود", "w"); return; }
      if (items.includes(p.id)) { say("الصنف موجود بالفعل", "i"); e.target.select(); return; }
      items.push(p.id); render(true);
    });
    if (r) F.set({ no: r.no, name: r.name, desc: r.data.desc || "" }); else DB.next("alt").then(n => F.set({ no: n }));
    setTimeout(() => F.q("name").focus(), 30);
    function save(d) {
      if (!F.validate()) return;
      if (items.length < 2) { say("يجب إضافة صنفين على الأقل للربط بينهم", "w"); return; }
      const v = F.get(); d.busy(1);
      DB.save("alt", { id: r ? r.id : 0, no: v.no, name: v.name.trim(), data: { desc: v.desc, items } }).then(() => { say("تم الحفظ", "s"); d.close(); done(); }).catch(e => { d.busy(0); err(e); });
    }
  }
  const G = id => document.getElementById(id);

  /* ================================================================ الكلمات الدلالية / الشركات المنتجة */
  function smallKind(view, kind, ttl) {
    ListScreen({
      view, key: view, title: ttl, ttl, kind, style: "B",
      load: force => DB.list(kind, force),
      cols: [{ t: "الرقم", w: "1fr", f: r => r.no, num: 1, v: r => +r.no || 0 }, { t: "الاسم", w: "1fr", f: r => r.name }],
      dlg: (r, done) => {
        const D = Dlg({ title: "", w: 420, onOk: d => save(d) });
        D.body.style.padding = "0";
        D.body.innerHTML = `<div style="background:#0d7a0d;color:#fff;text-align:center;font-size:11px;padding:6px">الوصف</div><div style="display:flex;gap:10px;padding:12px 14px"><div style="width:52px;background:#1f8ff0;color:#fff;display:flex;align-items:center;justify-content:center;font-size:11px;height:56px">عام</div><div data-f="1" style="flex:1"></div></div>`;
        const F = Form(D.body.querySelector("[data-f]"), { side: false, secs: [{ f: [{ k: "no", t: "الكود", req: 1, w: "w120" }, { k: "name", t: "الاسم", req: 1 }] }] });
        D.body.querySelectorAll(".fh-fr").forEach(x => x.style.gridTemplateColumns = "60px 1fr");
        D.body.querySelector(".fh-sec .bx").style.borderRight = "0";
        if (r) F.set({ no: r.no, name: r.name }); else DB.next(kind).then(n => F.set({ no: n }));
        setTimeout(() => F.q("name").focus(), 30);
        function save(d) { if (!F.validate()) return; const v = F.get(); d.busy(1); DB.save(kind, { id: r ? r.id : 0, no: v.no, name: v.name.trim(), data: r ? r.data : {} }).then(() => { say("تم الحفظ", "s"); d.close(); done(); }).catch(e => { d.busy(0); err(e); }); }
      }
    });
  }
  smallKind("fhkw", "kw", "الكلمات الدلالية");
  /* الشركات المنتجة (مثل DEXEF + لمستي): عدد الأصناف ، البلد ، الهاتف — النافذة في mk-items.js ، والحذف ممنوع لشركة لها أصناف */
  ListScreen({
    view: "fhmk", key: "fhmk", title: "الشركات المنتجة", ttl: "الشركات المنتجة", kind: "mk", style: "B",
    load: force => DB.list("mk", force),
    cols: [{ t: "الرقم", w: "120px", f: r => r.no, num: 1, v: r => +r.no || 0 }, { t: "الاسم", w: "1.4fr", f: r => r.name },
      { t: "البلد", w: "1fr", f: r => { const c = (r.data || {}).country || ""; return c ? ((window.ANOUER_MK && ANOUER_MK.flag(c)) || "") + " " + c : ""; } },
      { t: "عدد الأصناف", w: "130px", f: r => window.ANOUER_MK ? ANOUER_MK.count(r) : "", num: 1, v: r => window.ANOUER_MK ? ANOUER_MK.count(r) : 0 },
      { t: "الهاتف", w: "1fr", f: r => (r.data || {}).phone || "" }],
    dlg: (r, done) => { if (window.ANOUER_MK) ANOUER_MK.dlg(r, done); },
    onDel: r => { const n = window.ANOUER_MK ? ANOUER_MK.count(r) : 0; if (n) return Promise.reject(new Error("لا يمكن حذف «" + r.name + "» — مربوطة بـ " + n + " صنف. افتحها وفك ربط الأصناف أولاً")); return DB.del("mk", r.id); }
  });

  /* ================================================================ مجموعات العملاء و الموردين */
  const SHOWWITH = ["الكل", "العملاء", "الموردين"];
  ListScreen({
    view: "fhcvg", key: "fhcvg", title: "مجموعات العملاء و الموردين", kind: "cvg", style: "E", mtb: 1,
    mtbRight: `<span class="sep"></span><button type="button" data-a="edit">${IC.edit}<span>تعديل</span></button><button type="button" data-a="del">${IC.trash}<span>حذف</span></button>`,
    filters: `<label class="fh-f" style="margin-right:auto"><span></span><select data-br="1">${BR.map(b => `<option>${esc(b)}</option>`).join("")}</select></label>`,
    load: force => DB.list("cvg", force).then(l => treeFlat(l)),
    cols: [{ t: "الاسم", w: "1.4fr", f: r => r.name, tree: 1 }, { t: "الرقم", w: "1fr", f: r => r.no, num: 1, v: r => +r.no || 0 }, { t: "الحالة", w: "1fr", chk: 1, v: r => r.active !== false }, { t: "الملاحظات", w: "1.6fr", f: r => r.data.notes || "" }],
    dlg: cvgDlg
  });
  function cvgDlg(r, done) {
    const D = Dlg({ title: "", w: 450, closeText: "إلغاء", onOk: d => save(d) });
    D.body.innerHTML = `<div class="fh-desc"><div style="flex:0 0 52px">${IC.cv}</div><div><h3>مجموعات العملاء والموردين</h3><p>يمكنك وضع العملاء و الموردين في مجموعات .. حتى يسهل تصنيفهم واجراء عليهم بعد العمليات دفعة واحدة .. مثال مجموعة محافظة القاهرة او مجموعة الاستيراد من الخارج .. الخ ..</p></div></div><div data-f="1"></div>`;
    D.body.querySelector(".fh-desc svg").style.cssText = "width:46px;height:46px";
    DB.list("cvg").then(all => {
      const F = Form(D.body.querySelector("[data-f]"), { side: false, secs: [
        { t: "بيانات أساسية", f: [{ k: "no", t: "الكود", req: 1, w: "w120" }, { k: "name", t: "الاسم", req: 1 }, { k: "active", t: "الحالة", type: "check", lbl: "نشط", def: true }] },
        { t: "أخرى", c: "b", f: [{ k: "branch", t: "اسم الفرع", type: "select", opts: BR, req: 1, extra: '<label class="ck"><input type="checkbox" data-k="allBr"><span>كل الفروع</span></label>' }, { k: "parentId", t: "يوجد بداخل", type: "select", opts: [["", ""]].concat(all.filter(x => !r || x.id !== r.id).map(x => [x.id, x.name])) }, { k: "showWith", t: "تظهر مع", type: "select", opts: SHOWWITH, w: "w120" }, { k: "notes", t: "الملاحظات", type: "textarea" }] }] });
      D.body.querySelectorAll(".fh-fr").forEach(x => x.style.gridTemplateColumns = "84px 1fr");
      if (r) F.set(Object.assign({}, r.data, { no: r.no, name: r.name, parentId: r.parentId || "", active: r.active !== false })); else DB.next("cvg").then(n => F.set({ no: n }));
      setTimeout(() => F.q("name").focus(), 30);
      D.save = d => { if (!F.validate()) return; const v = F.get(); d.busy(1);
        DB.save("cvg", { id: r ? r.id : 0, no: v.no, name: v.name.trim(), parentId: +v.parentId || 0, active: v.active, data: { branch: v.branch, allBr: v.allBr, showWith: v.showWith, notes: v.notes } })
          .then(() => { say("تم الحفظ", "s"); d.close(); done(); }).catch(e => { d.busy(0); err(e); }); };
    });
    function save(d) { if (d.save) d.save(d); }
  }

  /* ================================================================ شجرة الحسابات + حساب أستاذ */
  const CATS = [["1", "الأصول"], ["2", "الخصوم و حقوق الملكية"], ["3", "المصروفات"], ["4", "الإيرادات"]];
  const ATYPES = [{ g: "الأصول", items: ["أصول طويلة الأجل", "النقدية وما في حكمها", "المدينون", "الأصول المتداولة الأخرى", "الأصول الأخرى"] },
    { g: "الخصوم", items: ["الدائنون", "القروض", "الخصوم المتداولة الأخرى", "الخصوم طويلة الأجل", "حقوق الملكية"] },
    { g: "المصروفات", items: ["تكلفة البضاعة المباعة", "مصروفات النشاط", "مصروفات غير نقدية", "مصروفات غير تشغيلية"] },
    { g: "الإيرادات", items: ["صافي المبيعات", "ايرادات النشاط", "ايرادات غير تشغيلية", "ايرادات غير نقدية"] }];
  const ATYPE_HELP = {
    "النقدية وما في حكمها": "الخزائن والبنوك والعهد وبطاقات الإئتمان — تظهر في قائمة التدفقات النقدية",
    "المدينون": "حسابات العملاء وأوراق القبض وكل من له التزام تجاه المؤسسة",
    "الدائنون": "حسابات الموردين وأوراق الدفع وكل التزام على المؤسسة",
    "صافي المبيعات": "المبيعات ومرتجعاتها والخصومات — تظهر أعلى قائمة الدخل",
    "تكلفة البضاعة المباعة": "تكلفة البضاعة المباعة — تُخصم من صافي المبيعات لحساب مجمل الربح"
  };
  /* شجرة DEXEF الافتراضية (مصدّرة من DEXEF ONE) — [الرقم, الاسم, نوع الحساب] */
  const COA = window.__FH_COA || [];
  function coaSeed() {
    return DB.list("gla").then(l => {
      if (l.length || !COA.length) return l;
      const seen = new Set(), rows = [];
      const stack = [];
      COA.forEach(([no, name, type]) => {
        if (seen.has(no)) return; seen.add(no);
        while (stack.length && !no.startsWith(stack[stack.length - 1])) stack.pop();
        rows.push({ no, name, parentNo: stack.length ? stack[stack.length - 1] : "", data: JSON.stringify({ type: type || "", nature: "مدين و دائن", cur: "DZD" }) });
        stack.push(no);
      });
      return DB.bulk("gla", rows).then(() => DB.list("gla", true));
    });
  }
  function glOpts(prefix) { const l = CACHE_GLA || []; return l.filter(a => String(a.no).startsWith(prefix)).sort((a, b) => String(a.no).localeCompare(String(b.no))).map(a => [a.no, a.no + " - " + a.name]); }
  let CACHE_GLA = null;
  /* مسار حساب الأستاذ في الشجرة: «1 الأصول › 12 … › 1211 الخزينة» (لمسة: يظهر تحت اختيار حساب الأستاذ في بطاقات الخزينة/البنك/الفيزا) */
  function glPath(no) {
    const l = CACHE_GLA || [], by = {}; l.forEach(a => { by[a.id] = a; });
    let a = l.find(x => String(x.no) === String(no)); const out = [];
    while (a) { out.unshift(a.no + " " + a.name); a = a.parentId ? by[a.parentId] : null; }
    return out;
  }
  function glHint(F, k) {
    const sel = F.q(k); if (!sel) return;
    const row = sel.closest(".fh-fr") || sel.parentNode;
    const box = document.createElement("div"); box.className = "pa-glpath"; row.insertAdjacentElement("afterend", box);
    const upd = () => { const p = glPath(sel.value); box.innerHTML = p.length ? `<span>سيظهر في شجرة الحسابات تحت</span>${p.map((x, i) => `<b${i === p.length - 1 ? ' class="l"' : ""}>${esc(x)}</b>`).join("<i>›</i>")}` : ""; };
    sel.addEventListener("change", upd); upd(); setTimeout(upd, 60);
  }
  function loadGla(force) { return (force ? DB.list("gla", true) : coaSeed()).then(l => (CACHE_GLA = l)); }
  /* الأرصدة الفعلية للحسابات المرتبطة ببيانات ANOUER */
  let BAL = {}, PAV = [];
  /* مفتاح الرصيد: حساب أستاذ = رقمه ، حساب نقدية مرتبط (خزينة/بنك/فيزا) = نوعه:رقمه */
  const BK = r => r && r._pa ? r._pa.key : r.no;
  let ROLL = {};
  const RB = r => BAL[BK(r)] || (r._kids ? ROLL[r.id] : null);
  function computeBalances() {
    BAL = {}; PAV = [];
    const put = (no, d, c) => { BAL[no] = { d: r2(d), c: r2(c) }; };
    const add = (no, d, c) => { const b = BAL[no] || (BAL[no] = { d: 0, c: 0 }); b.d = r2(b.d + d); b.c = r2(b.c + c); };
    const ps = [];
    /* الخزائن والبنوك والفيزا: كل حساب يُرحَّل على حساب الأستاذ المختار في بطاقته (1211 / 1212 / 1216 …) ويظهر تحته في الشجرة */
    if (window.ANOUER_PAY) ps.push(ANOUER_PAY.load(true).then(C => { C.all.forEach(a => { BAL[a.key] = { d: a.d, c: a.c }; add(a.gl, a.d, a.c); PAV.push(a); }); }).catch(() => { }));
    else ps.push(trList().then(ts => { let d = 0, c = 0; (ts || []).forEach(t => { d += +t.debit || +t.balance || 0; c += +t.credit || 0; }); put("1211", d, c); }).catch(() => { }));
    try { let d = 0, c = 0; (window.CUSTOMERS_DATA || []).forEach(x => { const b = +x.bal || 0; if (b > 0) d += b; else c -= b; }); put("1231", d, c); } catch (e) { }
    /* المخزون حسب مرحلة الصنف (التصنيع — ANOUER PRO): نصف مصنّع ← 1222 ، منتج تام ← 1223 ، الباقي ← 1221 */
    { const MF = window.ANOUER_MFG;
      ps.push(Promise.resolve(MF && MF.ready ? MF.ready().catch(() => { }) : null).then(() => { try { const v = { 1221: 0, 1222: 0, 1223: 0 }; prods().forEach(p => { const s = MF && MF.stageOf ? MF.stageOf(p.id) : null; v[s === "semi" ? 1222 : s === "fin" ? 1223 : 1221] += (+p.stock || 0) * (+p.cost || 0); });
        put("1221", Math.max(0, v[1221]), Math.max(0, -v[1221])); if (v[1222]) put("1222", Math.max(0, v[1222]), Math.max(0, -v[1222])); if (v[1223]) put("1223", Math.max(0, v[1223]), Math.max(0, -v[1223])); } catch (e) { } })); }
    ps.push((HOST() ? call("suppliers.search", { q: "" }) : Promise.resolve([])).then(ss => { let d = 0, c = 0; (ss || []).forEach(s => { const b = +(s.Balance != null ? s.Balance : s.balance) || 0; if (b > 0) c += b; else d -= b; }); put("2111", d, c); }).catch(() => { }));
    return Promise.all(ps);
  }
  const COAOPEN = new Set();
  function coaScreen() {
    const el = mkView("fhcoa", "شجرة الحسابات");
    let G = null, built = false, rows = [];
    const S = {};
    function build() {
      if (built) return; built = true;
      el.innerHTML = `<div class="rv-flt"><span class="rv-sel"><select data-br="1">${BR.map(b => `<option>${esc(b)}</option>`).join("")}</select></span><span class="rv-sel"><select data-cat="1"><option value="">الكل</option>${CATS.map(c => `<option value="${c[0]}">${esc(c[1])}</option>`).join("")}</select></span></div>
        <div class="rv-tb">${tbHTML()}</div>
        <div class="rv-body"><div class="rv-side"><div class="col" title="طي">›</div><div class="rv-si on" data-i="0">${SIG()}<span>عام</span></div><div class="rv-si" data-i="1">${SIPL()}<span>الأرباح و الخسائر</span></div><div class="rv-si" data-i="2">${SIRP()}<span>التقارير</span></div></div>
        <div class="rv-main" style="display:flex;flex-direction:column"><div class="rv-hd" style="display:flex;align-items:center;gap:10px"><div class="rv-dd" style="width:250px"><span class="lb"></span><span>⋯</span><span class="ck">✓</span><span style="font-size:9px;color:#777">⌄</span></div><div style="flex:1"></div><label class="fh-chk"><input type="checkbox" data-tx="1"><span>ظهور الحسابات التى تحتوى تعاملات فقط</span></label><div style="flex:1"></div><div class="rv-search"><span>${H.IC.srch}</span><input placeholder="Enter text to search..." data-q="1"></div></div><div data-g="1" style="flex:1;min-height:0;display:flex"></div></div></div>`;
      G = Grid(el.querySelector("[data-g]"), {
        tree: 1, openSet: COAOPEN, rn: false, foot: () => { let d = 0, c = 0; rows.forEach(r => { const b = BAL[BK(r)]; if (b && !r._kids) { d += b.d; c += b.c; } }); return [null, fmt(d), fmt(c), fmtB(d - c), null, null]; },
        cols: [{ t: "الاسم", w: "minmax(300px,2fr)", f: r => r._pa ? r.name : r.no + " - " + r.name, tree: 1, cls: r => r._pa ? "fh-pa" : r._lv === 0 ? "lv1" : r._lv === 1 ? "fh-g2" : "", v: r => r.no,
            icon: r => { const P = window.ANOUER_PAY; if (!r._pa || !P) return ""; const k = P.K[r._pa.kind]; return `<i class="fh-pa-ic" style="--c1:${k.c1};--c2:${k.c2}">${P.IC[r._pa.kind]}</i>`; } },
          { t: "مدين DZD", w: "1fr", f: r => { const b = RB(r); return b && b.d ? fmt(b.d) : ""; }, num: 1, v: r => (RB(r) || {}).d || 0 },
          { t: "دائن DZD", w: "1fr", f: r => { const b = RB(r); return b && b.c ? fmt(b.c) : ""; }, num: 1, v: r => (RB(r) || {}).c || 0 },
          { t: "الرصيد DZD", w: "1fr", f: r => { const b = RB(r); return b && (b.d || b.c) ? fmtB(b.d - b.c) : ""; }, num: 1, v: r => { const b = RB(r); return b ? b.d - b.c : 0; } },
          { t: "نوع الحساب", w: "1.1fr", f: r => r._pa && window.ANOUER_PAY ? ANOUER_PAY.K[r._pa.kind].one + " · " + (r.data.type || "") : r.data.type || "" },
          { t: "", w: "40px", nof: 1, html: () => `<span data-ic="st" title="كشف حساب">${IC.rchart}</span>`, cl: "ic" }],
        onOpen: r => r._pa ? paFile(r) : glForm(r), onDel: r => S.del(r), onIcon: r => accStatement(r),
        ctx: (r, e) => ctxMenu(r._pa ? [["ملف الحساب", "", "", () => paFile(r)], ["تعديل", "", "", () => paEdit(r)], ["فتح " + (window.ANOUER_PAY ? ANOUER_PAY.K[r._pa.kind].t : ""), "", "", () => paScreen(r)]]
          : [["جديد", "", "", () => glForm(null, r)], ["تعديل", "", "", () => glForm(r)], ["حذف", "", "", () => S.del(r)], ["كشف حساب", "", "", () => accStatement(r)]], { x: e.clientX + 190, y: e.clientY })
      });
      el.querySelector(".rv-tb").addEventListener("click", e => {
        const b = e.target.closest("button"); if (!b) return; const a = b.dataset.a, r = G.cur;
        if (a === "new") glForm(null, r && r._pa ? rows.find(x => x.id === r._pid) : r); else if (a === "edit") { if (r && r._pa) paEdit(r); else if (r) glForm(r); else say("اختر حساباً", "w"); } else if (a === "del") { if (r) S.del(r); }
        else if (a === "refresh") S.refresh(true); else if (a === "print") printList("شجرة الحسابات", G.__cols || [{ t: "الاسم", f: x => x.no + " - " + x.name }, { t: "نوع الحساب", f: x => x.data.type || "" }], G.list);
        else if (a === "excel") csvList("شجرة الحسابات", [{ t: "الرقم", f: x => x.no }, { t: "الاسم", f: x => x.name }, { t: "مدين", f: x => (RB(x) || {}).d || "" }, { t: "دائن", f: x => (RB(x) || {}).c || "" }, { t: "نوع الحساب", f: x => x.data.type || "" }], G.list);
        else if (a === "mail" && window.ANOUER_MAIL) ANOUER_MAIL.table({ title: "شجرة الحسابات", cols: [{ t: "الرقم", f: x => x.no }, { t: "الاسم", f: x => x.name }, { t: "مدين", f: x => (RB(x) || {}).d || "" }, { t: "دائن", f: x => (RB(x) || {}).c || "" }, { t: "نوع الحساب", f: x => x.data.type || "" }], rows: G.list, xls: 1 });
        else if (a === "up") { if (r && r._pid) { G.selectBy(x => x.id === r._pid); } }
        else if (a === "expand") { G.openAll(rows.filter(x => x._kids).map(x => x.id)); }
        else say("«" + (b.title || "") + "» غير متاح في هذه الشاشة", "i");
      });
      el.addEventListener("change", e => { if (e.target.matches("[data-cat],[data-tx]")) apply(); });
      el.querySelector("[data-q]").addEventListener("input", apply);
      el.querySelector(".rv-side").addEventListener("click", e => { const s = e.target.closest(".rv-si"); if (!s) return; el.querySelectorAll(".rv-si").forEach(x => x.classList.toggle("on", x === s)); pane(+s.dataset.i); });
    }
    function apply() {
      const cat = el.querySelector("[data-cat]").value, tx = el.querySelector("[data-tx]").checked, q = norm(el.querySelector("[data-q]").value);
      let l = rows;
      if (cat) l = l.filter(r => String(r.no).startsWith(cat));
      if (tx) { const keep = new Set(); l.forEach(r => { const b = BAL[BK(r)]; if (b && (b.d || b.c)) { let x = r; while (x) { keep.add(x.id); x = rows.find(y => y.id === x._pid); } } }); l = l.filter(r => keep.has(r.id)); }
      if (q) { const keep = new Set(); l.forEach(r => { if (norm(r.no + " " + r.name).includes(q)) { let x = r; while (x) { keep.add(x.id); COAOPEN.add(x.id); x = rows.find(y => y.id === x._pid); } } }); l = l.filter(r => keep.has(r.id)); }
      G.set(l);
    }
    function pane(i) {
      const body = el.querySelector(".rv-body"); let p = body.querySelector(".fh-pane");
      if (i === 0) { body.classList.remove("fh-pon"); if (p) p.remove(); return; }
      if (!p) { p = document.createElement("div"); p.className = "fh-pane"; body.appendChild(p); }
      body.classList.add("fh-pon");
      if (i === 1) {
        const leafs = rows.filter(r => !r._kids);
        const sum = pre => leafs.filter(r => String(r.no).startsWith(pre)).reduce((s, r) => { const b = BAL[BK(r)]; return s + (b ? b.c - b.d : 0); }, 0);
        const rev = sum("4"), exp = -sum("3");
        let salesV = 0; try { (window.SALES_DATA || []).forEach(x => salesV += +x.total || 0); } catch (e) { }
        p.innerHTML = `<div class="fh-ttl2">الأرباح و الخسائر</div><div class="fh-tbl"><table><thead><tr><th>البند</th><th>المبلغ DZD</th></tr></thead><tbody>
          <tr><td class="t">إيرادات النشاط (4)</td><td class="nb">${fmtB(rev)}</td></tr><tr><td class="t">المصروفات (3)</td><td class="nb">${fmtB(exp)}</td></tr>
          <tr class="tot"><td class="t">صافي الربح / (الخسارة)</td><td class="nb">${fmtB(rev - exp)}</td></tr></tbody></table>
          <p style="font-size:11px;color:#666;padding:6px 4px">تظهر هنا الأرصدة المرحّلة على حسابات الإيرادات والمصروفات في الشجرة.</p></div>`;
      } else {
        p.innerHTML = repGrid([["الحسابات", [["كشف حساب", "rp1", () => { const r = G.cur; if (r) accStatement(r); else say("اختر حساباً من «عام» أولاً", "w"); }], ["ميزان المراجعة", "rp2", () => printTB()], ["شجرة الحسابات", "rp1", () => printList("شجرة الحسابات", [{ t: "الرقم", f: x => x.no }, { t: "الاسم", f: x => x.name }, { t: "نوع الحساب", f: x => x.data.type || "" }], rows)], ["الأرباح و الخسائر", "rp3", () => { el.querySelector('.rv-si[data-i="1"]').click(); }]]]]);
        wireRep(p);
      }
    }
    function printTB() {
      const leafs = rows.filter(r => !r._kids && BAL[BK(r)]);
      printList("ميزان المراجعة", [{ t: "الحساب", f: x => x._pa ? x.no + " › " + x.name : x.no + " - " + x.name }, { t: "مدين", f: x => fmt(BAL[BK(x)].d), num: 1 }, { t: "دائن", f: x => fmt(BAL[BK(x)].c), num: 1 }, { t: "الرصيد", f: x => fmtB(BAL[BK(x)].d - BAL[BK(x)].c), num: 1 }], leafs);
    }
    /* حسابات النقدية المرتبطة (خزينة / بنك / فيزا) داخل الشجرة */
    function paFile(r) { if (window.ANOUER_PAY) ANOUER_PAY.file(r._pa.kind, r._pa.id); }
    function paEdit(r) { const a = r._pa, rec = Object.assign({}, a.rec, { data: a.data }); if (a.kind === "tr") payForm("tr", rec); else if (a.kind === "bk") payForm("bank", rec); else visaDlg(rec); }
    function paScreen(r) { const k = r._pa.kind; tabOpen(k === "tr" ? "fhtr" : k === "bk" ? "fhbk" : "fhvs", k === "tr" ? "الخزينة" : k === "bk" ? "البنوك" : "الفيزا", k === "tr" ? "fhtr" : k === "bk" ? "fhbk" : "fhvs"); }
    function accStatement(r) {
      if (r._pa) { paFile(r); return; }
      const b = RB(r);
      if (!b) { say("لا توجد حركات على الحساب " + r.no + " - " + r.name, "i"); return; }
      if (r.no === "1211") { tabOpen("fhtr", "الخزينة", "fhtr"); return; }
      if (r.no === "1212") { tabOpen("fhbk", "البنوك", "fhbk"); return; }
      if (r.no === "1216") { tabOpen("fhvs", "الفيزا", "fhvs"); return; }
      if (r.no === "1231") { tabOpen("crev", "مراجعة العملاء", "crev"); return; }
      if (r.no === "2111") { tabOpen("surev", "مراجعة الموردين", "surev"); return; }
      if (r.no === "1221") { tabOpen("irev", "مراجعة الأصناف", "irev"); return; }
      say(r.name + " — مدين " + fmt(b.d) + " / دائن " + fmt(b.c), "i");
    }
    S.refresh = force => (S.last = Promise.all([loadGla(force), computeBalances()]).then(() => {
      /* الخزائن والبنوك والفيزا تحت حساب الأستاذ المرتبط بها */
      const byNo = {}; CACHE_GLA.forEach(g => { byNo[String(g.no)] = g; });
      const virt = PAV.map((a, i) => { const g = byNo[a.gl]; return g ? { id: -(1000000 + i), parentId: g.id, no: a.gl, name: a.name, active: a.active, data: { type: (g.data && g.data.type) || "النقدية وما في حكمها" }, _pa: a } : null; }).filter(Boolean);
      rows = treeFlat(CACHE_GLA.slice().concat(virt), (a, b) => String(a.no).localeCompare(String(b.no), "en", { numeric: true }) || (a._pa ? 1 : 0) - (b._pa ? 1 : 0));
      /* لمسة: مجاميع الحسابات الرئيسية (من الحسابات الفرعية) */
      ROLL = {}; const byId = {}; rows.forEach(r => { byId[r.id] = r; });
      rows.forEach(r => { if (r._kids) return; const b = BAL[BK(r)]; if (!b || (!b.d && !b.c)) return; let x = byId[r._pid]; while (x) { const o = ROLL[x.id] || (ROLL[x.id] = { d: 0, c: 0 }); o.d = r2(o.d + b.d); o.c = r2(o.c + b.c); x = x._pid ? byId[x._pid] : null; } }); if (!COAOPEN.__i) { rows.forEach(r => { if (r._lv < 2 && r._kids) COAOPEN.add(r.id); if (r._pa) { let x = byId[r._pid]; while (x) { COAOPEN.add(x.id); x = x._pid ? byId[x._pid] : null; } } }); COAOPEN.__i = 1; } apply(); }).catch(err));
    S.del = r => {
      if (r._pa) { say("«" + r.name + "» " + (window.ANOUER_PAY ? ANOUER_PAY.K[r._pa.kind].one : "") + " مرتبطة بهذا الحساب — عدّلها أو أوقفها من شاشتها", "w"); return; }
      if (r._kids) { say("لا يمكن حذف حساب رئيسي يتفرع منه حسابات", "w"); return; }
      if (BAL[BK(r)] && (BAL[BK(r)].d || BAL[BK(r)].c)) { say("لا يمكن حذف حساب عليه حركات", "w"); return; }
      ask("هل تريد حذف الحساب «" + r.no + " - " + r.name + "» ؟", () => DB.del("gla", r.id).then(() => { say("تم الحذف", "s"); S.refresh(true); }).catch(err));
    };
    RV.VIEW_SHOW.fhcoa = function () { build(); S.refresh(); setTimeout(() => G && G.focus(), 30); };
    /* فتح الشجرة على حساب أستاذ معيّن (من شاشات الخزينة / البنوك / الفيزا) */
    window.__FH_COA_SEL = no => {
      const go = () => { const r = rows.find(x => !x._pa && String(x.no) === String(no)); if (!r) { say("الحساب " + no + " غير موجود في الشجرة", "w"); return; }
        let x = r; while (x && x._pid) { COAOPEN.add(x._pid); x = rows.find(y => y.id === x._pid); } COAOPEN.add(r.id);
        const q = el.querySelector("[data-q]"), cat = el.querySelector("[data-cat]"); if (q) q.value = ""; if (cat) cat.value = "";
        apply(); G.selectBy(y => y === r); };
      build(); Promise.resolve(S.last || S.refresh()).then(go);
    };
    SCR.fhcoa = S;
    return S;
  }
  const COAS = coaScreen();
  function tbHTML() {
    const B = [["جديد", "new", "new"], ["تعديل", "edit", "edit"], ["حذف", "del", "del", 1], ["رفع", "up", "up"], ["نسخ", "copy"], ["تحديد", "refresh", "expand"], ["", "sync", "refresh"], ["طباعة", "print", "print", 1], ["تصدير Excel", "excel", "excel", 1], ["Mail", "mail", "", 1], ["تكرار", "dup"], ["المرفقات", "clip"], ["طريقة العرض", "view"]];
    const L = [["إختيار الحقول", "cols"], ["عرض للطباعة", "prv", "print"]];
    const btn = b => `<button type="button" class="${b[3] ? "dd" : ""}" data-a="${b[2] || ""}" title="${b[0] || "تحديث"}">${TI[b[1]] || ""}${b[0] ? `<span>${b[0]}</span>` : ""}</button>`;
    return B.map(btn).join("") + '<span class="sp"></span>' + L.map(btn).join("") + '<button type="button" data-a="" title="المزيد" style="padding:0 6px">▾</button>';
  }
  const SIG = () => '<svg viewBox="0 0 30 30" fill="#2b7de0"><rect x="3" y="4" width="7" height="7" rx="2"/><rect x="12" y="4" width="7" height="7" rx="2"/><rect x="21" y="4" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="13" rx="2"/><rect x="12" y="14" width="7" height="13" rx="2"/><rect x="21" y="14" width="7" height="13" rx="2"/></svg>';
  const SIPL = () => '<svg viewBox="0 0 30 30" fill="none" stroke="#2b7de0" stroke-width="2"><rect x="5" y="3" width="17" height="22" rx="2"/><path d="M9 9h9M9 13h9M9 17h5"/><circle cx="21" cy="21" r="5" fill="#fff"/><path d="M24.5 24.5L28 28"/></svg>';
  const SIRP = () => '<svg viewBox="0 0 30 30" fill="#2b7de0"><rect x="6" y="5" width="18" height="22" rx="2"/><rect x="10" y="2" width="10" height="5" rx="1" fill="#7fb3f0"/><g fill="#fff"><rect x="9" y="11" width="12" height="2"/><rect x="9" y="15" width="12" height="2"/><rect x="9" y="19" width="8" height="2"/></g></svg>';

  /* حساب أستاذ (نموذج في تبويب — مطابق DEXEF) */
  let GLSEQ = 1;
  const GLDOCS = {};
  function glForm(r, parentHint) {
    const key = r ? "fhgl:" + r.id : "fhgl:new" + (GLSEQ++);
    if (GLDOCS[key]) { tabOpen(key, GLDOCS[key].title, "fhgl"); return; }
    const host = mkView("fhgl", "حساب أستاذ");
    const page = document.createElement("div"); page.className = "fh-doc"; page.dataset.key = key; page.style.cssText = "display:none;flex:1;flex-direction:column;min-height:0";
    host.appendChild(page);
    const doc = GLDOCS[key] = { key, title: r ? "حساب أستاذ - " + r.name : "حساب أستاذ", page };
    fileBar(page, { menu: [["حفظ", "Ctrl+S", IC.save, () => save()], ["جديد", "Ctrl+N", IC.add, () => glForm(null)], ["خروج", "Ctrl+Q", "", () => tabClose(key)]], top: [["save", "حفظ", IC.save, () => save()]] }, []);
    const pg = document.createElement("div"); pg.className = "fh-page"; page.appendChild(pg);
    loadGla().then(all => {
      const F = Form(pg, { icon: IC.money, secs: [
        { f: [{ k: "cat", t: "التصنيف", type: "select", opts: CATS, req: 1 }, { k: "name", t: "اسم الحساب", req: 1 }, { k: "parentId", t: "يندرج من", type: "select", req: 1, opts: [], extra: '<span style="font-size:11px">الرقم</span><input data-k="no" style="flex:0 0 90px;text-align:center"><span class="req">*</span>' }] },
        { t: "النوع", c: "b", f: [{ k: "type", t: "نوع الحساب", type: "select", req: 1, blank: 1, opts: ATYPES.map(g => ({ g: g.g, items: g.items.map(x => [x, x]) })), link: "الشرح" }] },
        { t: "الخصائص", c: "b", f: [{ k: "cc", t: "مركز التكلفة", type: "select", opts: ["لا يتطلب مركز تكلفة", "يتطلب مركز تكلفة"] }, { k: "nature", t: "طبيعة الحساب", type: "select", opts: ["مدين و دائن", "مدين", "دائن"] }, { k: "cur", t: "عملة الحساب", type: "select", opts: ["DZD", "EUR", "USD"] }, { k: "from", t: "اعتباراً من", type: "date" }, { k: "notes", t: "ملاحظات", type: "textarea" }] }],
        after: '<div class="fh-pact"><button type="button" class="fh-btn green" data-save="1">حفظ</button><button type="button" class="fh-btn" data-cls="1">إغلاق</button></div>' });
      const catSel = F.q("cat"), parSel = F.q("parentId");
      function fillPar() {
        const c = catSel.value, opts = all.filter(a => String(a.no).startsWith(c) && (!r || a.id !== r.id)).sort((a, b) => String(a.no).localeCompare(String(b.no), "en", { numeric: true })).map(a => [a.id, a.no + " - " + a.name]);
        fillSel(parSel, [["", ""]].concat(opts), true);
      }
      function nextCode() {
        const pid = +parSel.value, par = all.find(a => a.id === pid);
        const base = par ? String(par.no) : "", kids = all.filter(a => (par ? a.parentId === pid : !a.parentId)).map(a => String(a.no));
        let n = kids.reduce((m, k) => Math.max(m, parseInt(k.slice(base.length), 10) || 0), 0) + 1;
        F.q("no").value = par ? base + n : String(Math.max(5, n));
        if (par && !F.q("type").value) F.q("type").value = par.data.type || "";
      }
      catSel.addEventListener("change", () => { fillPar(); nextCode(); });
      parSel.addEventListener("change", nextCode);
      pg.querySelector('[data-link="type"]').addEventListener("click", () => { const t = F.q("type").value; say(t ? (ATYPE_HELP[t] || "«" + t + "»: يحدد مكان ظهور الحساب في القوائم المالية والتقارير") : "اختر نوع الحساب أولاً", "i"); });
      pg.querySelector("[data-save]").addEventListener("click", save);
      pg.querySelector("[data-cls]").addEventListener("click", () => tabClose(key));
      if (r) { const p = all.find(a => a.id === r.parentId); F.set(Object.assign({ cat: String(r.no)[0] }, r.data, { active: r.active !== false })); fillPar(); F.set({ parentId: r.parentId || "", no: r.no, name: r.name }); }
      else { const ph = parentHint && (parentHint._kids ? parentHint : all.find(a => a.id === parentHint.parentId)); F.set({ cat: ph ? String(ph.no)[0] : "1", from: today(), nature: "مدين و دائن", cur: "DZD" }); fillPar(); if (ph) parSel.value = ph.id; nextCode(); }
      doc.F = F; doc.all = all;
      setTimeout(() => F.q("name").focus(), 50);
    });
    function save() {
      const F = doc.F; if (!F || !F.validate()) return;
      const v = F.get();
      if (!v.no.trim()) { say("يجب إدخال «الرقم»", "w"); F.q("no").focus(); return; }
      DB.save("gla", { id: r ? r.id : 0, no: v.no.trim(), name: v.name.trim(), parentId: +v.parentId || 0, active: v.active, data: { type: v.type, cc: v.cc, nature: v.nature, cur: v.cur, from: v.from, notes: v.notes } })
        .then(() => { say("تم حفظ الحساب " + v.no + " - " + v.name, "s"); CACHE_GLA = null; delete GLDOCS[key]; tabClose(key); page.remove(); if (SCR.fhcoa) SCR.fhcoa.refresh(true); }).catch(err);
    }
    doc.save = save;
    tabOpen(key, doc.title, "fhgl");
  }
  RV.VIEW_SHOW.fhgl = function () { const k = H.activeKey(); Object.values(GLDOCS).forEach(d => d.page.style.display = d.key === k ? "flex" : "none"); };

  /* ================================================================ بنود المصروفات / الإيرادات */
  const EXPT = ["مصروف عام", "مصروف على الإعتماد", "مصروف على الأصول"];
  function itemsKind(view, kind, ttl, sub, glPre) {
    ListScreen({
      view, key: view, title: ttl, ttl, sub, kind, style: "E", mtb: 1,
      filters: branchF("") + activeF(),
      filter: stFilter,
      load: force => Promise.all([DB.list(kind, force), loadGla()]).then(([l]) => { const by = {}; l.forEach(x => by[x.id] = x); return l.map(x => Object.assign(x, { _par: x.parentId && by[x.parentId] ? by[x.parentId].name : "" })); }),
      cols: [{ t: "الرقم", w: "130px", f: r => r.no, num: 1, v: r => +r.no || 0 }, { t: "الاسم", w: "1.3fr", f: r => r.name }].concat(kind === "exp" ? [{ t: "نوع المصروف", w: "1fr", f: r => r.data.type || EXPT[0] }] : [])
        .concat([{ t: "حساب الاستاذ", w: "1.3fr", f: r => glName(r.data.gl) }, { t: "يوجد بداخل", w: "1fr", f: r => r._par }, { t: "الملاحظات", w: "1fr", f: r => r.data.notes || "" }, { t: "نشط", w: "60px", chk: 1, v: r => r.active !== false }])
        .sort((a, b) => kind === "rev" && a.t === "نشط" ? -1 : 0),
      dlg: (r) => itemForm(kind, r, glPre)
    });
  }
  function glName(no) { const a = (CACHE_GLA || []).find(x => String(x.no) === String(no)); return a ? a.name : (no || ""); }
  itemsKind("fhexp", "exp", "بنود المصروفات", "هى بمثابة تبويب لجميع أنواع المصروفات التى تقوم بها المؤسسة .. يمكنك تقسيمها الى تبويب شجرى تفيدك كثيراً فى التقارير", "3");
  itemsKind("fhrev", "rev", "بنود الإيرادات", "", "4");
  const IFDOCS = {};
  let IFSEQ = 1;
  function itemForm(kind, r, glPre) {
    const view = kind === "exp" ? "fhexpf" : "fhrevf";
    const key = view + ":" + (r ? r.id : "n" + IFSEQ++);
    const title = kind === "exp" ? (r ? "بند مصروف - " + r.name : "بند مصروف جديد") : (r ? "بند إيراد - " + r.name : "بند إيراد جديد");
    if (IFDOCS[key]) { tabOpen(key, title, view); return; }
    const host = mkView(view, title);
    const page = document.createElement("div"); page.dataset.key = key; page.style.cssText = "display:none;flex:1;flex-direction:column;min-height:0"; host.appendChild(page);
    const doc = IFDOCS[key] = { key, page, view };
    fileBar(page, { menu: [["حفظ", "Ctrl+S", IC.save, () => save()], ["خروج", "Ctrl+Q", "", () => tabClose(key)]], top: [["save", "حفظ", IC.save, () => save()]] }, []);
    const pg = document.createElement("div"); pg.className = "fh-page"; page.appendChild(pg);
    Promise.all([DB.list(kind), loadGla()]).then(([all]) => {
      const F = Form(pg, { icon: IC.money, sideHtml: '<span style="font-size:10px;color:#444">الحالة</span>', secs: [
        { t: "بيانات أساسية", f: [{ k: "no", t: "الرقم", req: 1, w: "w120" }, { k: "name", t: "الاسم", req: 1 }, { k: "gl", t: "حساب الاستاذ", type: "select", req: 1, blank: 1, opts: glOpts(glPre) }] }]
        .concat(kind === "exp" ? [{ t: "النوع", c: "p", f: [{ k: "type", t: "النوع", type: "select", opts: EXPT }] }] : [])
        .concat([{ t: "الخصائص", c: "b", f: [{ k: "parentId", t: "يندرج من", type: "select", opts: [["", ""]].concat(all.filter(x => !r || x.id !== r.id).map(x => [x.id, x.name])) }, { k: "branch", t: "الفروع", type: "select", req: 1, opts: BR }, { k: "cc", t: "مركز التكلفة", type: "select", opts: ["ليس من الضروري", "ضروري"] }, { k: "notes", t: "الملاحظات", type: "textarea" }] }]),
        after: '<div class="fh-pact"><button type="button" class="fh-btn" data-save="1" style="background:#1f9bf0;min-width:180px">حفظ</button></div>' });
      if (r) F.set(Object.assign({}, r.data, { no: r.no, name: r.name, parentId: r.parentId || "", active: r.active !== false }));
      else DB.next(kind).then(n => F.set({ no: n, type: EXPT[0], branch: BR[0] }));
      pg.querySelector("[data-save]").addEventListener("click", save);
      doc.F = F; setTimeout(() => F.q("name").focus(), 50);
    });
    function save() {
      const F = doc.F; if (!F || !F.validate()) return; const v = F.get();
      DB.save(kind, { id: r ? r.id : 0, no: v.no, name: v.name.trim(), parentId: +v.parentId || 0, active: v.active, data: { gl: v.gl, type: v.type, branch: v.branch, cc: v.cc, notes: v.notes } })
        .then(() => { say("تم الحفظ", "s"); delete IFDOCS[key]; tabClose(key); page.remove(); const s = SCR[kind === "exp" ? "fhexp" : "fhrev"]; if (s) s.refresh(true); }).catch(err);
    }
    doc.save = save;
    tabOpen(key, title, view);
  }
  ["fhexpf", "fhrevf"].forEach(v => { RV.VIEW_SHOW[v] = function () { const k = H.activeKey(); Object.values(IFDOCS).forEach(d => { if (d.view === v) d.page.style.display = d.key === k ? "flex" : "none"; }); }; });

  /* ================================================================ طرق الدفع: الخزينة / البنوك / الفيزا */
  function RevScreen(c) {
    const el = mkView(c.view, c.title);
    let G = null, built = false, rows = [];
    const S = {
      refresh(force) { return Promise.resolve(c.load(force)).then(l => { rows = l || []; apply(); }).catch(err); },
      newItem() { c.form(null); }, edit() { const r = G && G.cur; if (r) c.form(r); else say("اختر سطراً أولاً", "w"); },
      del() { const r = G && G.cur; if (!r) return; if (c.canDel && !c.canDel(r)) return; ask("هل تريد حذف «" + r.name + "» ؟", () => c.del(r).then(() => { say("تم الحذف", "s"); S.refresh(true); }).catch(err)); },
      print() { printList(c.title, vis(), G.list); }, excel() { csvList(c.title, vis(), G.list); },
      /* «إختيار الحقول» = لوحة Customization العائمة (نفس باقي الشاشات) — الأعمدة المخفية تُحفظ لكل شاشة */
      fields() { fieldsChooser(c.title, c.cols, hid => { lsSet("fh.hide." + c.title, hid); mkGrid(); apply(); }); }
    };
    const hidden = () => new Set((lsGet("fh.hide." + c.title, []) || []).map(Number));
    const vis = () => { const h = hidden(); return c.cols.filter((x, i) => !h.has(i)); };
    function mkGrid() {
      const h = hidden(), host = el.querySelector("[data-g]"); host.innerHTML = "";
      const foot = c.foot ? (l => (c.foot(l) || []).filter((x, i) => !h.has(i))) : null;
      G = Grid(host, { cols: vis(), foot, off: r => r.active === false, onOpen: () => S.edit(), onDel: () => S.del(), onIcon: c.onIcon });
    }
    function apply() {
      const q = norm((el.querySelector("[data-q]") || {}).value), act = (el.querySelector("[data-act]") || {}).checked;
      const l = rows.filter(r => (!act || r.active !== false) && (!q || c.cols.some(x => x.f && norm(x.f(r)).includes(q))));
      G.set(l);
      /* لمسة 2026: شريط المؤشرات + عرض البطاقات (طرق الدفع) */
      const P = window.ANOUER_PAY;
      if (P && c.kind) {
        const accs = l.map(r => r._a).filter(Boolean);
        const bd = el.querySelector("[data-band]"); if (bd) bd.innerHTML = P.band(c.kind, accs);
        const cards = P.isCards(c.kind), cd = el.querySelector("[data-cards]"), gh = el.querySelector("[data-g]");
        cd.hidden = !cards; gh.style.display = cards ? "none" : "";
        el.querySelectorAll('.rv-tb button[title="طريقة العرض"]').forEach(b => b.classList.toggle("pa-von", cards));
        if (cards) cd.innerHTML = P.cards(c.kind, accs);
      }
    }
    function build() {
      if (built) return; built = true;
      el.innerHTML = `<div class="rv-flt"><label class="rv-chk"><input type="checkbox" checked data-act="1"><span>نشط</span></label><span class="rv-sel"><select>${BR.map(b => `<option>${esc(b)}</option>`).join("")}</select></span></div><div class="rv-tb">${tbHTML()}</div>
        ${c.kind ? '<div data-band="1"></div>' : ""}<div class="rv-main" style="display:flex;flex-direction:column;flex:1;min-height:0"><div class="rv-hd" style="display:flex;align-items:center;gap:10px"><div class="rv-search" style="width:220px"><span>${H.IC.srch}</span><input placeholder="Enter text to search..." data-q="1"></div><div style="flex:1"></div><div class="rv-dd" style="width:250px"><span class="lb"></span><span>⋯</span><span class="ck">✓</span><span style="font-size:9px;color:#777">⌄</span></div></div><div data-g="1" style="flex:1;min-height:0;display:flex"></div>${c.kind ? '<div class="pa-cards" data-cards="1" hidden></div>' : ""}</div>`;
      mkGrid();
      el.querySelector(".rv-tb").addEventListener("click", e => { const b = e.target.closest("button"); if (!b) return; const a = b.dataset.a; if (a === "new") S.newItem(); else if (a === "edit") S.edit(); else if (a === "del") S.del(); else if (a === "refresh" || a === "expand") S.refresh(true); else if (a === "print") S.print(); else if (a === "excel") S.excel();
        else if (b.title === "إختيار الحقول") S.fields(); else if (b.title === "عرض للطباعة") S.print();
        else if (b.title === "طريقة العرض" && c.kind && window.ANOUER_PAY) { ANOUER_PAY.toggleView(c.kind); apply(); }
        else say("«" + (b.title || "") + "» غير متاح في هذه الشاشة", "i"); });
      el.querySelector("[data-q]").addEventListener("input", apply);
      el.querySelector("[data-act]").addEventListener("change", apply);
      if (c.kind) el.addEventListener("click", e => {
        const P = window.ANOUER_PAY; if (!P) return;
        const gl = e.target.closest("[data-gl]"); if (gl) { e.stopPropagation(); P.openGl(gl.dataset.gl); return; }
        const fb = e.target.closest("[data-file]"); if (fb) { const cur = G && G.cur && G.cur._a; const k = cur ? cur.key : fb.dataset.file; P.file(c.kind, k.split(":")[1]); return; }
        const cd = e.target.closest(".pa-card"); if (!cd) return;
        const r = rows.find(x => x._a && x._a.key === cd.dataset.k); if (!r) return;
        el.querySelectorAll(".pa-card.on").forEach(x => x.classList.remove("on")); cd.classList.add("on");
        G.selectBy(x => x === r);
        const act = e.target.closest("[data-act]");
        if (act && act.dataset.act === "edit") c.form(r); else if (act && act.dataset.act === "file") P.file(c.kind, r.id);
      });
      if (c.kind) el.addEventListener("dblclick", e => { const cd = e.target.closest(".pa-card"); if (!cd || !window.ANOUER_PAY) return; const r = rows.find(x => x._a && x._a.key === cd.dataset.k); if (r) ANOUER_PAY.file(c.kind, r.id); });
    }
    RV.VIEW_SHOW[c.view] = function () { build(); S.refresh(); setTimeout(() => G && G.focus(), 30); };
    SCR[c.view] = S;
    return S;
  }
  /* قائمة الخزائن: fm.cat.treasuries، أو treasury.list في النسخة القديمة، أو محلي في المعاينة */
  function trList() {
    const old = () => call("treasury.list").then(l => (l || []).map(t => ({ id: t.TreasuryId || t.Id || t.id, name: t.Name || t.name, balance: +(t.Balance != null ? t.Balance : t.balance) || 0, debit: +(t.Balance != null ? t.Balance : t.balance) || 0, credit: 0, active: t.IsActive !== false, data: "{}" })));
    if (H.HOSTB()) return call("fm.cat.treasuries").catch(e => { if (H.isUnknown(e)) return old(); throw e; });
    if (HOST()) return old();
    return Promise.resolve(lsGet("fh.tr", [{ id: 1, name: "الخزينة الرئيسية", balance: 0, debit: 0, credit: 0, active: true, data: "{}" }]));
  }
  const sumF = (l, f) => l.reduce((s, r) => s + (+f(r) || 0), 0);
  /* حسابات النقدية الموحّدة (pay-accounts.js): الرصيد مع حركات «الحسابات» + حساب الأستاذ المرتبط في الشجرة */
  const PAYL = (kind, force) => { const P = window.ANOUER_PAY; if (!P) return null; if (force) P.invalidate(); return P.load(!!force).then(C => (C[kind] || []).map(a => Object.assign({}, a.rec, { data: a.data, _a: a }))); };
  const ZM = tip => ({ t: "", w: "40px", nof: 1, html: () => `<span data-ic="z" title="${tip}">${IC.zoom.replace('viewBox="0 0 24 24"', 'viewBox="0 0 24 24" style="width:16px;height:16px"')}</span>`, cl: "ic" });
  const GLC = { t: "حساب الأستاذ", w: "1.25fr", f: r => r._a ? r._a.gl + " - " + r._a.glName : (r.data.gl || "") };
  const PFILE = kind => r => { if (window.ANOUER_PAY) ANOUER_PAY.file(kind, r.id); else say(r.name, "i"); };
  const tD = r => r._a ? r._a.d : r.debit, tC = r => r._a ? r._a.c : r.credit, tB = r => r._a ? r._a.bal : r.balance;
  const aD = r => r._a ? r._a.d : Math.max(0, +r.data.opening || 0), aC = r => r._a ? r._a.c : Math.max(0, -(+r.data.opening || 0)), aB = r => r._a ? r._a.bal : (+r.data.opening || 0);
  /* الخزينة (جدول Treasuries الحقيقي) */
  const TRS = RevScreen({
    view: "fhtr", title: "الخزينة", kind: "tr",
    load: force => PAYL("tr", force) || trList().then(l => (l || []).map(t => Object.assign({}, t, { data: pj(t.data) }))),
    cols: [{ t: "الرقم", w: "1fr", f: r => r.data.no || r.id, num: 1, v: r => +(r.data.no || r.id) }, { t: "الاسم", w: "1.4fr", f: r => r.name }, { t: "مدين", w: "1fr", f: r => fmt(tD(r)), num: 1, v: tD },
      { t: "دائن", w: "1fr", f: r => fmt(tC(r)), num: 1, v: tC }, { t: "الحساب", w: "1fr", f: r => fmtB(tB(r)), num: 1, v: tB }, { t: "العملة", w: "1fr", f: r => r.data.cur || "DZD" }, GLC, ZM("ملف الحساب")],
    foot: l => [null, null, fmt(sumF(l, tD)), fmt(sumF(l, tC)), fmtB(sumF(l, tB)), null, null, null],
    onIcon: PFILE("tr"),
    form: r => payForm("tr", r),
    canDel: () => { say("لا يمكن حذف خزينة — يمكنك إيقافها بإلغاء «نشط»", "w"); return false; }
  });
  /* البنوك */
  const BKS = RevScreen({
    view: "fhbk", title: "البنوك", kind: "bk",
    load: force => PAYL("bk", force) || DB.list("bank", force),
    cols: [{ t: "رقم الحساب", w: "1.2fr", f: r => r.no }, { t: "اسم البنك", w: "1.3fr", f: r => r.name }, { t: "الفرع", w: "1fr", f: r => r.data.allBr ? "كل الفروع" : brName(r.data) }, { t: "العملة", w: "90px", f: r => r.data.cur || "DZD" },
      { t: "مدين", w: "1fr", f: r => fmt(aD(r)), num: 1, v: aD }, { t: "دائن", w: "1fr", f: r => fmt(aC(r)), num: 1, v: aC }, { t: "الحساب", w: "1fr", f: r => fmtB(aB(r)), num: 1, v: aB }, GLC, { t: "الحالة", w: "80px", chk: 1, v: r => r.active !== false }, ZM("ملف الحساب")],
    foot: l => [null, null, null, null, fmt(sumF(l, aD)), fmt(sumF(l, aC)), fmtB(sumF(l, aB)), null, null, null],
    onIcon: PFILE("bk"),
    form: r => payForm("bank", r), del: r => DB.del("bank", r.id)
  });
  /* الفيزا */
  const VSS = RevScreen({
    view: "fhvs", title: "الفيزا", kind: "vs",
    load: force => PAYL("vs", force) || DB.list("visa", force),
    cols: [{ t: "الاسم", w: "1.4fr", f: r => r.name }, { t: "البنك", w: "1.2fr", f: r => r.data.bank || "" }, { t: "النسبة", w: "1fr", f: r => (r.data.rate || 0) + "%", num: 1 }, { t: "مدين", w: "1fr", f: r => fmt(aD(r)), num: 1, v: aD },
      { t: "دائن", w: "1fr", f: r => fmt(aC(r)), num: 1, v: aC }, { t: "الرصيد", w: "1fr", f: r => fmtB(aB(r)), num: 1, v: aB }, GLC, { t: "نشط", w: "70px", chk: 1, v: r => r.active !== false }, ZM("ملف الحساب")],
    foot: l => [null, null, null, fmt(sumF(l, aD)), fmt(sumF(l, aC)), fmtB(sumF(l, aB)), null, null, null],
    onIcon: PFILE("vs"),
    form: r => visaDlg(r), del: r => DB.del("visa", r.id)
  });
  const PFDOCS = {};
  let PFSEQ = 1;
  function payForm(kind, r) {
    const view = "fhpf", key = view + ":" + kind + ":" + (r ? r.id : "n" + PFSEQ++);
    const title = kind === "tr" ? "الخزينة" : (r ? "تعديل بنك" : "إضافة بنك");
    if (PFDOCS[key]) { tabOpen(key, title, view); return; }
    const host = mkView(view, title);
    const page = document.createElement("div"); page.dataset.key = key; page.style.cssText = "display:none;flex:1;flex-direction:column;min-height:0"; host.appendChild(page);
    const doc = PFDOCS[key] = { key, page };
    fileBar(page, { menu: [["حفظ", "Ctrl+S", IC.save, () => save()], ["خروج", "Ctrl+Q", "", () => tabClose(key)]], top: [["save", "حفظ", IC.save, () => save()]] }, []);
    const hdr = document.createElement("div"); hdr.className = "fh-hdr";
    hdr.innerHTML = `<label class="fh-f"><span>اسم الفرع ${kind === "bank" ? '<i style="color:#e53935">*</i>' : ""}</span><select data-h="branch">${BR.map(b => `<option>${esc(b)}</option>`).join("")}</select></label>${kind === "bank" ? '<label class="fh-chk" style="margin-bottom:3px"><input type="checkbox" data-h="allBr"><span>كل الفروع</span></label>' : ""}<span style="flex:1"></span><label class="fh-f"><span>التاريخ <i style="color:#e53935">*</i></span><input type="date" data-h="date" value="${today()}"></label>`;
    page.appendChild(hdr);
    const pg = document.createElement("div"); pg.className = "fh-page"; page.appendChild(pg);
    loadGla().then(() => {
      const big = '<div class="fh-big" data-big="1">0</div>';
      const secs = kind === "tr" ? [
        { f: [{ k: "no", t: "رقم الخزينة", req: 1, w: "w120" }, { k: "name", t: "الاسم", req: 1 }] },
        { t: "الرصيد الإفتتاحي", c: "b", f: [{ k: "opening", t: "المبلغ", type: "num", w: "w120", def: 0, ro: !!r, extra: big }, { k: "cur", t: "عملة الخزينة", type: "select", opts: ["DZD", "EUR", "USD"], req: 1, w: "w80", extra: '<input data-k="rate" type="number" step="any" value="1" class="w80">' }] },
        { t: "بيانات أخرى", c: "b", f: [{ k: "gl", t: "حساب الاستاذ", type: "select", req: 1, opts: glOpts("121") }, { k: "comp", t: "الحساب المكمل", type: "select", req: 1, opts: glOpts("24") }, { k: "ref", t: "اسم المراجع", type: "select", blank: 1, opts: () => users().map(u => u.name) }, { k: "notes", t: "الملاحظات", type: "textarea" }] }]
        : [
        { f: [{ k: "no", t: "رقم الحساب", req: 1 }, { k: "name", t: "اسم البنك", req: 1 }, { k: "atype", t: "نوع الحساب", type: "select", req: 1, opts: ["جاري", "توفير", "ودائع"], w: "w120" }] },
        { t: "الرصيد الإفتتاحي", c: "p", f: [{ k: "opening", t: "المبلغ", type: "num", w: "w120", def: 0, extra: big }, { k: "cur", t: "العملة", type: "select", opts: ["DZD", "EUR", "USD"], req: 1, w: "w80", extra: '<input data-k="rate" type="number" step="any" value="1" class="w80">' }, { k: "gl", t: "حساب الأستاذ", type: "select", req: 1, opts: glOpts("121") }, { k: "comp", t: "الحساب المكمل", type: "select", req: 1, opts: glOpts("24") }] },
        { t: "بيانات الاتصال", c: "b", f: [{ k: "bbr", t: "فرع البنك" }, { k: "addr", t: "العنوان" }, { k: "tel", t: "التليفون", extra: '<input data-k="tel2"><input data-k="tel3">' }, { k: "mail", t: "بريد الكتروني" }] }];
      const F = Form(pg, { icon: kind === "tr" ? IC.tr : IC.bank, secs, after: '<div class="fh-pact"><button type="button" class="fh-btn green" data-save="1">حفظ</button><button type="button" class="fh-btn" data-cls="1">إغلاق</button></div>' });
      const bigEl = pg.querySelector("[data-big]"), op = F.q("opening");
      op.addEventListener("input", () => { bigEl.textContent = fmt(num(op.value)); });
      const dGl = kind === "tr" ? "1211" : "1212";
      if (r) {
        F.set(Object.assign({ gl: dGl, comp: "247", cur: "DZD", rate: 1 }, r.data, { no: r.data.no || r.no || r.id, name: r.name, active: r.active !== false, opening: kind === "tr" ? (r.data.opening || r.balance || 0) : (r.data.opening || 0) }));
        hdr.querySelector('[data-h="branch"]').value = brName(r.data); if (r.data.date) hdr.querySelector('[data-h="date"]').value = r.data.date;
        if (kind === "bank" && r.data.allBr) hdr.querySelector('[data-h="allBr"]').checked = true;
      } else {
        F.set({ gl: dGl, comp: "247", cur: "DZD", rate: 1 });
        if (kind === "tr") TRS_next().then(n => F.set({ no: n })); else F.set({ no: "" });
      }
      bigEl.textContent = fmt(num(op.value));
      glHint(F, "gl");
      pg.querySelector("[data-save]").addEventListener("click", save);
      pg.querySelector("[data-cls]").addEventListener("click", () => tabClose(key));
      doc.F = F; setTimeout(() => F.q(kind === "tr" ? "name" : "no").focus(), 50);
    });
    function save() {
      const F = doc.F; if (!F || !F.validate()) return; const v = F.get();
      const h = { branch: hdr.querySelector('[data-h="branch"]').value, date: hdr.querySelector('[data-h="date"]').value, allBr: !!(hdr.querySelector('[data-h="allBr"]') || {}).checked };
      const data = Object.assign({}, r ? r.data : {}, v, h, { opening: num(v.opening), rate: num(v.rate) || 1 });
      ["name", "active"].forEach(k => delete data[k]);
      let p;
      if (kind === "tr") {
        if (HOST() && !H.HOSTB()) { say("حفظ الخزينة يتطلب تشغيل build-exe.bat (نسخة البرنامج الحالية قديمة)", "w"); return; }
        if (HOST()) p = call("fm.cat.treasurySave", { id: r ? r.id : 0, name: v.name.trim(), active: v.active, opening: num(v.opening), data: JSON.stringify(data) });
        else { const l = lsGet("fh.tr", [{ id: 1, name: "الخزينة الرئيسية", balance: 0, debit: 0, credit: 0, active: true, data: "{}" }]); if (r) { const t = l.find(x => x.id === r.id); Object.assign(t, { name: v.name.trim(), active: v.active, data: JSON.stringify(data) }); } else l.push({ id: l.reduce((m, x) => Math.max(m, x.id), 0) + 1, name: v.name.trim(), balance: num(v.opening), debit: num(v.opening), credit: 0, active: v.active, data: JSON.stringify(data) }); lsSet("fh.tr", l); p = Promise.resolve(); }
      } else p = DB.save("bank", { id: r ? r.id : 0, no: v.no.trim(), name: v.name.trim(), active: v.active, data });
      p.then(() => { say(kind === "tr" ? "تم حفظ الخزينة" : "تم حفظ البنك", "s"); if (window.ANOUER_PAY) ANOUER_PAY.invalidate(); delete PFDOCS[key]; tabClose(key); page.remove(); (kind === "tr" ? TRS : BKS).refresh(true); }).catch(err);
    }
    doc.save = save;
    tabOpen(key, title, view);
  }
  function TRS_next() { return trList().then(l => String((l || []).reduce((m, t) => Math.max(m, +(pj(t.data).no || t.id) || 0), 0) + 1)); }
  RV.VIEW_SHOW.fhpf = function () { const k = H.activeKey(); Object.values(PFDOCS).forEach(d => d.page.style.display = d.key === k ? "flex" : "none"); };
  function visaDlg(r) {
    const D = Dlg({ title: "", w: 600, okText: "موافق", onOk: d => save(d) });
    D.ov.querySelector(".fh-dh span").innerHTML = '<span style="color:#1a1f71;font-weight:700">VISA</span> الفيزا';
    D.body.innerHTML = `<div class="fh-hdr" style="margin:-10px -26px 10px"><label class="fh-f"><span>اسم الفرع <i style="color:#e53935">*</i></span><select data-h="branch">${BR.map(b => `<option>${esc(b)}</option>`).join("")}</select></label><span style="flex:1"></span><label class="fh-f"><span>التاريخ</span><input type="date" data-h="date" value="${today()}"></label></div><div data-f="1"></div>`;
    Promise.all([loadGla(), DB.list("bank")]).then(([, banks]) => {
      const F = Form(D.body.querySelector("[data-f]"), { icon: IC.visa, secs: [
        { t: "بيانات الفيزا", f: [{ k: "no", t: "الرقم", req: 1, w: "w120" }, { k: "name", t: "الاسم", req: 1 }, { k: "bank", t: "اسم البنك", type: "select", req: 1, blank: 1, opts: banks.map(b => b.name) }] },
        { t: "الرصيد الإفتتاحي", c: "b", f: [{ k: "opening", t: "المبلغ", type: "num", w: "w120", def: 0, extra: '<div class="fh-big" data-big="1">0</div>' }, { k: "cur", t: "العملة", type: "select", opts: ["DZD", "EUR", "USD"], req: 1, w: "w80", extra: '<input data-k="rate" type="number" step="any" value="1" class="w80">' }, { k: "gl", t: "حساب الاستاذ", type: "select", req: 1, opts: glOpts("121") }, { k: "comp", t: "الحساب المكمل", type: "select", req: 1, opts: glOpts("24") }] },
        { t: "التحصيل", c: "b", f: [{ k: "rate2", t: "نسبة العمولة", type: "num", w: "w80", sfx: "%", def: 0 }, { k: "feeGl", t: "حساب العمولة", type: "select", opts: glOpts("323") }, { k: "tax", t: "الضريبة", type: "select", blank: 1, opts: ["بدون", "9%", "19%"] }] }] });
      D.body.querySelector("[data-f] .side svg").style.cssText = "width:80px;height:34px";
      D.body.querySelectorAll(".fh-fr").forEach(x => x.style.gridTemplateColumns = "100px 1fr");
      const bigEl = D.body.querySelector("[data-big]"), op = F.q("opening"); op.addEventListener("input", () => bigEl.textContent = fmt(num(op.value)));
      if (r) { F.set(Object.assign({}, r.data, { no: r.no, name: r.name, active: r.active !== false, rate2: r.data.rate || 0 })); D.body.querySelector('[data-h="branch"]').value = brName(r.data); bigEl.textContent = fmt(r.data.opening || 0); }
      else { DB.next("visa").then(n => F.set({ no: n })); F.set({ gl: "1216", comp: "247", feeGl: "3233", cur: "DZD" }); }
      glHint(F, "gl");
      setTimeout(() => F.q("name").focus(), 30);
      D.save = d => { if (!F.validate()) return; const v = F.get(); d.busy(1);
        DB.save("visa", { id: r ? r.id : 0, no: v.no, name: v.name.trim(), active: v.active, data: { bank: v.bank, opening: num(v.opening), cur: v.cur, rate: num(v.rate2), xrate: num(v.rate) || 1, gl: v.gl, comp: v.comp, feeGl: v.feeGl, tax: v.tax, branch: D.body.querySelector('[data-h="branch"]').value, date: D.body.querySelector('[data-h="date"]').value } })
          .then(() => { say("تم الحفظ", "s"); d.close(); if (window.ANOUER_PAY) ANOUER_PAY.invalidate(); VSS.refresh(true); }).catch(e => { d.busy(0); err(e); }); };
    });
    function save(d) { if (d.save) d.save(d); }
  }

  /* ================================================================ المستخدمين (مطابق DEXEF ONE)
     • القائمة: بطاقات / List، الفرع، نشط، بحث، التجميع (بالقسم/بالنوع/بالسماحية/بالمدير)
     • مستخدم جديد: إسم الموظف، النوع، بيانات الدخول (اسم مستخدم + رقم سرى خاص به + تأكيده)، عام / الصلاحيات، الخصائص
     • ملف المستخدم (نقرتان): عام (روابط سريعة + الإعدادات) / خصائص المستخدم / الصلاحيات / سجل الدخول
     • تعديل الرقم السرى: المدير يعيّن رقماً جديداً، والمستخدم يغيّر رقمه بنفسه (من اسم المستخدم أسفل الشاشة)
     الرقم السرى لا يُخزَّن أبداً في الواجهة: يُرسل للمضيف الذي يحفظ تجزئته (PBKDF2) فقط. */
  const UTYPES = [["admin", "مدير النظام", "هو المستخدم المتاح له كل شيء بالبرنامج ككل بدون استثناءات"], ["branch", "مدير فرع", "هو المستخدم المتاح له كل شيء داخل الفرع الخاص به فقط"], ["adv", "مستخدم متقدم", "هو المستخدم المتاح له السماحيات المحددة له مع صلاحيات إضافية للتعديل داخل فرعه"], ["user", "مستخدم", "هو المستخدم المتاح له بعض السماحيات داخل فرع محدد و يتم تحديد له بعض طرق الدفع و المخازن و العملاء و الموردين"], ["ro", "قراءه فقط", "هو المستخدم المتاح له الإطلاع فقط بدون إضافة أو تعديل أو حذف"]];
  const UGRP = [["", "بدون"], ["dept", "ترتيب بالقسم"], ["type", "ترتيب بالنوع"], ["role", "ترتيب بالسماحية"], ["mgr", "ترتيب بالمدير"]];
  const USCOPE = [
    ["جهات التعامل", [["co", "الشركات", 1], ["br", "الفروع", 1], ["wh", "المخازن", 1], ["tr", "الخزائن", 1], ["bk", "البنوك"], ["vs", "بطاقات الإئتمان"], ["cus", "العهد"]]],
    ["جهات التحويل", [["tbr", "فروع التحويل"], ["twh", "مخازن التحويل"], ["ttr", "خزائن التحويل"], ["tbk", "بنوك التحويل"]]],
    ["المخازن", [["it", "الأصناف"], ["sin", "إذون الإضافة"], ["sout", "إذون الصرف"]]],
    ["العملاء و الموردين", [["cu", "العملاء"], ["su", "الموردين"], ["mix", "الحسابات المختلطة"]]],
    ["الحسابات", [["exp", "بنود المصروفات"], ["rev", "بنود الإيرادات"], ["coa", "شجرة الحسابات"]]],
    ["أخرى", [["fa", "الأصول الثابتة"], ["cc", "مراكز التكلفة"], ["lc", "الاعتمادات المستندية"]]]];
  const UACTS = ["عرض", "إضافة", "تعديل", "حذف", "طباعة"];
  const UDAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  let USER_ROLES = [], ME = null;
  const isAdminRole = r => !!r && /^admin$/i.test(String(r.Code || ""));
  const adminRole = () => (USER_ROLES || []).find(isAdminRole) || null;
  const uType = u => (u.ext && u.ext.type) || (adminRole() ? (u.roleId === adminRole().RoleId ? "admin" : "user") : (u.roleId === 1 ? "admin" : "user"));
  const tName = u => (UTYPES.find(t => t[0] === uType(u)) || UTYPES[3])[1];
  const isMe = u => !!(ME && u && ME.UserId === u.id);
  const ampm = hm => { if (!hm) return ""; const [h, m] = String(hm).split(":").map(Number); if (isNaN(h)) return hm; const h12 = h % 12 || 12; return String(h12).padStart(2, "0") + ":" + String(m || 0).padStart(2, "0") + (h < 12 ? " ص" : " م"); };
  const dayName = d => { const x = new Date(String(d) + "T12:00:00"); return isNaN(x) ? "" : UDAYS[x.getDay()]; };
  function loadMe() { if (!HOST()) return Promise.resolve(null); return call("auth.me").then(m => (ME = m || null)).catch(() => null); }

  function loadUsers() {
    const p = HOST() ? Promise.all([call("users.list"), call("roles.list").catch(() => []), DB.list("uext", true), loadMe()])
      : Promise.all([Promise.resolve(lsGet("fh.users", [{ UserId: 1, Username: "admin", FullName: "مدير النظام", RoleId: 1, IsActive: true }])), Promise.resolve([{ RoleId: 1, Code: "Admin", Name: "مدير النظام" }, { RoleId: 2, Code: "Cashier", Name: "كاشير" }]), DB.list("uext", true), Promise.resolve(null)]);
    return p.then(([us, roles, ext]) => {
      const ex = {}; (ext || []).forEach(x => ex[x.no] = x);
      USER_ROLES = roles || [];
      CACHE_USERS = (us || []).map(u => { const e = ex[String(u.UserId)]; return { id: u.UserId, user: u.Username, name: u.FullName || u.Username, roleId: u.RoleId, role: u.RoleName || "", branchId: u.BranchId, active: u.IsActive !== false, created: u.CreatedAt || "", last: u.LastLogin || "", online: !!u.Online, ext: e ? (e.data || {}) : {}, extId: e ? e.id : 0 }; });
      CACHE_USERS.forEach(u => { if (isMe(u)) u.online = true; });
      return CACHE_USERS;
    });
  }

  /* -------- قائمة المستخدمين -------- */
  (function usersScreen() {
    const el = mkView("fhus", "المستخدمين");
    let built = false, list = [], sel = null;
    function build() {
      if (built) return; built = true;
      el.innerHTML = `<div class="fh-bar" style="padding-top:8px"><button type="button" class="fh-btn" data-new="1">جديد</button><span class="gap"></span><label class="fh-f"><span></span><select data-br="1"><option value="">كل الفروع</option>${BR.map(b => `<option>${esc(b)}</option>`).join("")}</select></label><label class="fh-chk" style="margin-bottom:4px"><input type="checkbox" data-act="1" checked><span>نشط</span></label></div>
        <div class="fh-bar us-bar2"><label class="fh-f"><span></span><select data-vw="1"><option value="c">▦ Cards</option><option value="t">☷ List</option></select></label><div class="fh-srch"><span>${H.IC.srch}</span><input data-q="1" placeholder="Enter text to search..."></div><label class="fh-f"><span></span><select data-grp="1">${UGRP.map(g => `<option value="${g[0]}">${esc(g[1])}</option>`).join("")}</select></label><span class="us-cnt" data-cnt="1"></span></div>
        <div data-body="1" style="flex:1;min-height:0;display:flex;flex-direction:column"></div>`;
      el.querySelector("[data-vw]").value = lsGet("fh.us.vw", "c");
      el.querySelector("[data-new]").addEventListener("click", () => userForm(null));
      el.addEventListener("change", e => { if (e.target.dataset.vw) lsSet("fh.us.vw", e.target.value); render(); });
      el.querySelector("[data-q]").addEventListener("input", render);
    }
    function render() {
      const act = el.querySelector("[data-act]").checked, q = norm(el.querySelector("[data-q]").value), vw = el.querySelector("[data-vw]").value, grp = el.querySelector("[data-grp]").value, br = el.querySelector("[data-br]").value;
      const l = list.filter(u => (!act || u.active) && (!br || !u.ext.branch || u.ext.branch === br) && (!q || norm([u.name, u.user, tName(u), u.role, u.ext.job, u.ext.mob].join(" ")).includes(q)));
      el.querySelector("[data-cnt]").textContent = l.length + " مستخدم";
      const body = el.querySelector("[data-body]");
      if (vw === "t") {
        body.innerHTML = ""; const gh = document.createElement("div"); body.appendChild(gh);
        Grid(gh, { cols: [{ t: "المستخدم", w: "1.1fr", f: u => u.user }, { t: "النوع", w: "1fr", f: tName }, { t: "الاسم", w: "1.2fr", f: u => u.name }, { t: "المدير المباشر", w: "1fr", f: u => u.ext.mgr || "" }, { t: "السماحية", w: "1fr", f: u => u.role }, { t: "الإشعارات", w: "1fr", f: u => u.ext.alerts || "اشعارات جديدة 2023" }, { t: "تاريخ الإضافة", w: "100px", f: u => u.created }, { t: "آخر دخول", w: "120px", f: u => u.last }, { t: "إغلاق يومية", w: "76px", chk: 1, v: u => !!u.ext.dayClose }, { t: "", w: "34px", nof: 1, html: u => `<span class="us-lg" data-ic="log" title="سجل الدخول">${IC.rchart}</span>` }],
          off: u => !u.active, onOpen: u => userProfile(u), onIcon: (u, k) => { if (k === "log") userProfile(u, "log"); }, ctx: (u, e) => cardMenu(u, e), empty: "لا يوجد مستخدمين" }).set(l);
        return;
      }
      const gk = u => grp === "type" ? tName(u) : grp === "role" ? (u.role || "—") : grp === "dept" ? (u.ext.dept || "بدون قسم") : grp === "mgr" ? (u.ext.mgr || "بدون مدير") : "";
      const groups = {}; l.forEach(u => { const g = gk(u); (groups[g] = groups[g] || []).push(u); });
      const card = u => `<div class="fh-card us-card${u.active ? "" : " off"}${u.online ? " onl" : ""}${sel === u.id ? " on" : ""}" data-u="${u.id}" tabindex="0" title="${esc(tName(u) + (u.last ? " — آخر دخول: " + u.last : ""))}"><span class="dot" title="${u.online ? "Online" : "Offline"}"></span>${isMe(u) ? '<span class="us-me">أنت</span>' : ""}${IC.av}<div class="nm">${esc(u.name)}</div><div class="ln">${IC.uid}<span>${esc(u.user)}</span></div><div class="mi" data-log="1" title="سجل الدخول">${IC.chart}<span>${esc(u.last ? u.last.slice(0, 10) : "")}</span></div><div class="mi">${IC.phone}<span>${esc(u.ext.mob || "")}</span></div></div>`;
      body.innerHTML = Object.keys(groups).length ? `<div class="us-wrap">${Object.keys(groups).map(g => `${g ? `<div class="fh-ttl2 us-gh">${esc(g)} <small>(${groups[g].length})</small></div>` : ""}<div class="fh-cards">${groups[g].map(card).join("")}</div>`).join("")}</div>` : '<div class="fh-empty">لا يوجد مستخدمين</div>';
    }
    const byEl = c => list.find(u => u.id === +c.dataset.u);
    el.addEventListener("click", e => { const c = e.target.closest("[data-u]"); if (!c) return; sel = +c.dataset.u; el.querySelectorAll(".fh-card").forEach(x => x.classList.toggle("on", x === c)); if (e.target.closest("[data-log]")) userProfile(byEl(c), "log"); });
    el.addEventListener("dblclick", e => { const c = e.target.closest("[data-u]"); if (c && !e.target.closest("[data-log]")) userProfile(byEl(c)); });
    el.addEventListener("contextmenu", e => { const c = e.target.closest("[data-u]"); if (!c) return; e.preventDefault(); sel = +c.dataset.u; el.querySelectorAll(".fh-card").forEach(x => x.classList.toggle("on", x === c)); cardMenu(byEl(c), e); });
    el.addEventListener("keydown", e => { const c = e.target.closest && e.target.closest("[data-u]"); if (c && e.key === "Enter") userProfile(byEl(c)); });
    function cardMenu(u, e) {
      if (!u) return;
      ctxMenu([["فتح ملف المستخدم", "Enter", IC.user, () => userProfile(u)], ["خصائص المستخدم", "", IC.edit, () => userProfile(u, "prop")], ["تعديل الرقم السرى", "", "", () => pwDialog(u)], ["سجل الدخول", "", IC.chart, () => userProfile(u, "log")], [u.active ? "إيقاف الحساب" : "تنشيط الحساب", "", "", () => setActive(u, !u.active)]], { x: e.clientX, y: e.clientY });
    }
    const S = { refresh() { return loadUsers().then(l => { list = l; render(); }).catch(e => { el.querySelector("[data-body]").innerHTML = `<div class="fh-empty">${esc(e.message || "تعذّر تحميل المستخدمين — تحتاج صلاحية مدير النظام")}</div>`; }); }, newItem: () => userForm(null) };
    RV.VIEW_SHOW.fhus = function () { build(); S.refresh(); };
    SCR.fhus = S;
  })();
  const usRefresh = () => { if (SCR.fhus) SCR.fhus.refresh(); };
  function setActive(u, on) {
    if (!on && isMe(u)) { say("لا يمكنك إيقاف حسابك الحالي", "w"); return; }
    ask((on ? "هل تريد تنشيط حساب «" : "هل تريد إيقاف حساب «") + u.name + "» ؟" + (on ? "" : "\nلن يستطيع الدخول للبرنامج حتى يُنشَّط."), () => {
      const p = HOST() ? call("users.setActive", { id: u.id, active: on }) : Promise.resolve(lsSet("fh.users", lsGet("fh.users", []).map(x => x.UserId === u.id ? Object.assign(x, { IsActive: on }) : x)));
      p.then(() => { u.active = on; say(on ? "تم تنشيط الحساب" : "تم إيقاف الحساب", "s"); usRefresh(); Object.values(UPDOCS).forEach(d => { if (d.u.id === u.id) d.paint(); }); }).catch(err);
    });
  }

  /* -------- محرّر «الصلاحيات» (جهات التعامل …): كل سطر قائمة اختيار متعدد؛ لا شيء = الكل -------- */
  function scopeSrc(k) {
    const nm = l => (l || []).filter(x => x.active !== false).map(x => x.name).filter(Boolean);
    if (k === "co") return HOST() ? call("fm.company.list").then(r => ((r && r.companies) || []).map(c => c.Name)).catch(() => ["ANOUER"]) : Promise.resolve(["ANOUER"]);
    if (k === "br" || k === "tbr") return Promise.resolve(BR.slice());
    if (k === "wh" || k === "twh") return DB.list("wh").then(l => ["المخزن الرئيسي"].concat(nm(l).filter(n => n !== "المخزن الرئيسي"))).catch(() => ["المخزن الرئيسي"]);
    if (k === "tr" || k === "ttr") return (HOST() ? call("treasury.list") : Promise.resolve([{ Name: "الخزينة الرئيسية" }])).then(l => (l || []).map(t => t.Name)).catch(() => ["الخزينة الرئيسية"]);
    if (k === "bk" || k === "tbk") return DB.list("bank").then(nm).catch(() => []);
    if (k === "vs") return DB.list("visa").then(nm).catch(() => []);
    return Promise.resolve(UACTS.slice());
  }
  function scopeEditor(host, scope, ro) {
    const val = Object.assign({}, scope || {});
    host.innerHTML = `<div class="us-sc">${USCOPE.map(g => `<div class="us-sg"><div class="us-sgh"><i>▾</i>${esc(g[0])}</div>${g[1].map(r => `<div class="us-sr" data-sk="${r[0]}"><div class="us-sl">${esc(r[1])}${r[2] ? '<b class="req">*</b>' : ""}</div><div class="us-sv${ro ? " ro" : ""}" tabindex="${ro ? -1 : 0}" data-sv="${r[0]}"></div></div>`).join("")}</div>`).join("")}</div>`;
    const paint = k => { const c = host.querySelector(`[data-sv="${k}"]`); if (!c) return; const v = val[k] || []; c.innerHTML = v.length ? v.map(x => `<span class="us-chip">${esc(x)}</span>`).join("") : '<span class="us-all">الكل</span>'; c.title = v.length ? v.join("، ") : "الكل"; };
    USCOPE.forEach(g => g[1].forEach(r => paint(r[0])));
    host.addEventListener("click", e => { const h = e.target.closest(".us-sgh"); if (h) { h.parentNode.classList.toggle("cl"); return; } const c = e.target.closest("[data-sv]"); if (c && !ro) pick(c); });
    host.addEventListener("keydown", e => { const c = e.target.closest && e.target.closest("[data-sv]"); if (c && !ro && (e.key === "Enter" || e.key === " " || e.key === "F4")) { e.preventDefault(); pick(c); } });
    function pick(c) {
      const k = c.dataset.sv;
      document.querySelectorAll(".us-pop").forEach(x => x.remove());
      scopeSrc(k).then(opts => {
        const cur = new Set(val[k] || []); (val[k] || []).forEach(x => { if (!opts.includes(x)) opts.push(x); });
        const pop = document.createElement("div"); pop.className = "us-pop";
        pop.innerHTML = `<label class="fh-chk us-pa"><input type="checkbox" data-all="1" ${cur.size ? "" : "checked"}><span>الكل</span></label><div class="us-pl">${opts.length ? opts.map((o, i) => `<label class="fh-chk"><input type="checkbox" data-o="${i}" ${cur.has(o) ? "checked" : ""}><span>${esc(o)}</span></label>`).join("") : '<div class="us-pe">لا توجد بيانات معرّفة — يبقى «الكل»</div>'}</div><div class="us-pf"><button type="button" class="fh-btn sm green" data-ok="1">موافق</button><button type="button" class="fh-btn sm" data-x="1">إلغاء</button></div>`;
        document.body.appendChild(pop);
        const r = c.getBoundingClientRect(); pop.style.top = Math.min(r.bottom + 2, innerHeight - pop.offsetHeight - 6) + "px"; pop.style.left = Math.max(6, r.right - pop.offsetWidth) + "px";
        const all = pop.querySelector("[data-all]"), boxes = () => Array.from(pop.querySelectorAll("[data-o]"));
        all.addEventListener("change", () => { if (all.checked) boxes().forEach(b => b.checked = false); });
        pop.addEventListener("change", e => { if (e.target.dataset.o != null) all.checked = !boxes().some(b => b.checked); });
        const close = () => { pop.remove(); document.removeEventListener("mousedown", out, true); try { c.focus(); } catch (x) { } };
        const out = e => { if (!pop.contains(e.target)) close(); };
        setTimeout(() => document.addEventListener("mousedown", out, true), 0);
        pop.addEventListener("keydown", e => { if (e.key === "Escape") { e.stopPropagation(); close(); } });
        pop.addEventListener("click", e => {
          if (e.target.closest("[data-x]")) { close(); return; }
          if (e.target.closest("[data-ok]")) { val[k] = all.checked ? [] : boxes().filter(b => b.checked).map(b => opts[+b.dataset.o]); paint(k); close(); }
        });
        const f = pop.querySelector("input"); if (f) f.focus();
      });
    }
    return { get: () => { const o = {}; Object.keys(val).forEach(k => { if (val[k] && val[k].length) o[k] = val[k].slice(); }); return o; } };
  }

  /* -------- نموذج المستخدم (جديد / خصائص المستخدم) -------- */
  function userFormInto(pg, u, opt) {
    opt = opt || {};
    const edit = !!u;
    const jobs = lsGet("fh.jobs", ["KHELD"]), depts = lsGet("fh.depts", []), shifts = lsGet("fh.shifts", []);
    const plus = k => `<button type="button" data-plus="${k}" title="إضافة" class="us-plus">+</button>`;
    const roleOpts = () => (USER_ROLES || []).map(r => [r.RoleId, r.Name]);
    const F = Form(pg, { icon: IC.user, secs: [
      { f: [{ k: "name", t: edit ? "الاسم" : "إسم الموظف", req: 1 }].concat(edit ? [{ k: "user", t: "اسم المستخدم", ro: 1 }] : []).concat([{ k: "type", t: "النوع", type: "select", req: 1, opts: UTYPES.map(t => [t[0], t[1]]) }]) }]
      .concat(edit ? [] : [{ t: "بيانات الدخول", c: "b", f: [{ k: "user", t: "اسم المستخدم", req: 1 }, { k: "pw", t: "الرقم السرى", type: "pass", req: 1, extra: '<button type="button" class="us-eye" data-eye="pw" title="إظهار / إخفاء">👁</button>' }, { k: "pw2", t: "تأكيد الرقم السرى", type: "pass", req: 1 }], html: '<div class="us-meter" data-meter="1"><i></i><span></span></div>' }]),
      after: `<div class="us-tabsel"><button type="button" class="fh-btn navy on" data-ut="gen">عام</button><button type="button" class="fh-btn" data-ut="perm">الصلاحيات</button></div>
        <div class="us-tp on" data-up="gen"><div class="us-gen"><div class="us-gl">` +
        secHTMLs([{ t: edit ? "الخصائص" : "التصنيف", c: "b", f: (edit ? [{ k: "active", t: "الحالة", type: "check", lbl: "نشط" }] : []).concat([{ k: "branch", t: "اسم الفرع", type: "select", req: 1, opts: BR }, { k: "roleId", t: "السماحية", type: "select", blank: 1, opts: roleOpts }, { k: "alerts", t: "التنبيهات", type: "select", opts: ["اشعارات جديدة 2023", "بدون"] }, { k: "rpt", t: "تصميم التقارير الإفتراضى", type: "select", blank: 1, opts: ["A4", "A5", "حراري 80mm"] }]) },
          { t: "بيانات الوظيفة", c: "b", f: [{ k: "job", t: "الوظيفة", type: "select", blank: 1, opts: jobs, extra: plus("jobs") }, { k: "dept", t: "القسم", type: "select", blank: 1, opts: depts, extra: plus("depts") }, { k: "mgr", t: "المدير المباشر", type: "select", blank: 1, opts: () => users().filter(x => !u || x.id !== u.id).map(x => x.name) }, { k: "shift", t: "الوردية", type: "select", blank: 1, opts: shifts, extra: plus("shifts") }] },
          { t: "بيانات الاتصال", c: "b", f: [{ k: "mob", t: "رقم المحمول", extra: '<input data-k="mob2" placeholder="رقم آخر">' }, { k: "mail", t: "الإيميل" }, { k: "addr", t: "العنوان" }] }]) +
        `</div><div class="us-props" data-props="1"><h4>الخصائص</h4><div class="bx"><label class="us-sw"><input type="checkbox" data-k="noOthers"><i></i><b class="n">لا</b><b class="y">نعم</b><span>غير مسموح له برؤية التعاملات التى قام بها الآخرون ؟</span></label><label class="us-sw"><input type="checkbox" data-k="dayClose"><i></i><b class="n">لا</b><b class="y">نعم</b><span>له إغلاق يومية</span></label></div></div></div></div>
        <div class="us-tp" data-up="perm"><div class="us-scope" data-scope="1"></div></div>` });
    const act = document.createElement("div"); act.className = "us-act";
    act.innerHTML = `<button type="button" class="fh-btn green" data-save="1">حفظ</button>${edit ? "" : '<button type="button" class="fh-btn" data-savecp="1">حفظ و نسخ</button>'}`;
    pg.querySelector(".fh-form").prepend(act);
    if (edit) { const sa = pg.querySelector(".fh-form>.side .fh-act"); if (sa) sa.remove(); }
    const hint = document.createElement("div"); hint.className = "fh-hint us-hint"; F.q("type").closest(".fh-fr").after(hint);
    const SC = scopeEditor(pg.querySelector("[data-scope]"), (u && u.ext.scope) || {});
    const tabSel = pg.querySelector(".us-tabsel");
    tabSel.addEventListener("click", e => { const b = e.target.closest("[data-ut]"); if (!b) return; tabSel.querySelectorAll("[data-ut]").forEach(x => { const on = x === b; x.classList.toggle("on", on); x.classList.toggle("navy", on); }); pg.querySelectorAll(".us-tp").forEach(x => x.classList.toggle("on", x.dataset.up === b.dataset.ut)); });
    const rSel = F.q("roleId");
    const upType = () => {
      const t = F.q("type").value, info = UTYPES.find(x => x[0] === t), adm = t === "admin", ar = adminRole();
      hint.textContent = info ? info[2] : "";
      pg.querySelector("[data-props]").style.display = adm ? "none" : "";
      tabSel.querySelector('[data-ut="perm"]').style.display = adm ? "none" : "";
      if (adm && tabSel.querySelector('[data-ut="perm"]').classList.contains("on")) tabSel.querySelector('[data-ut="gen"]').click();
      const rr = rSel.closest(".fh-fr"), req = rr.querySelector(".req");
      if (adm && ar) { rSel.value = ar.RoleId; rSel.disabled = true; req.textContent = ""; }
      else {
        rSel.disabled = false; req.textContent = "*";
        if (ar && String(rSel.value) === String(ar.RoleId) && (!u || uType(u) === "admin")) rSel.value = "";
      }
    };
    F.q("type").addEventListener("change", upType);
    // مقياس قوة الرقم السرى + إظهار/إخفاء
    const meter = pg.querySelector("[data-meter]");
    if (meter) {
      const pw = F.q("pw"); F.q("pw").closest(".fh-fr").after(meter);
      pw.addEventListener("input", () => { const s = pwScore(pw.value); meter.className = "us-meter s" + s.n; meter.querySelector("span").textContent = pw.value ? s.t : ""; });
      pg.querySelector("[data-eye]").addEventListener("click", () => { const t = F.q("pw").type === "password" ? "text" : "password"; F.q("pw").type = t; F.q("pw2").type = t; });
      F.q("user").addEventListener("input", () => { const v = norm(F.q("user").value.trim()), d = !!v && (CACHE_USERS || []).some(x => norm(x.user) === v); F.q("user").classList.toggle("dup", d); F.q("user").title = d ? "اسم المستخدم موجود من قبل" : ""; });
    }
    pg.addEventListener("click", e => {
      const p = e.target.closest("[data-plus]"); if (!p) return;
      const k = p.dataset.plus, v = prompt("إضافة " + ({ jobs: "وظيفة", depts: "قسم", shifts: "وردية" })[k] + ":"); if (!v || !v.trim()) return;
      const l = lsGet("fh." + k, k === "jobs" ? ["KHELD"] : []); if (!l.includes(v.trim())) l.push(v.trim()); lsSet("fh." + k, l);
      const sel = F.q(({ jobs: "job", depts: "dept", shifts: "shift" })[k]); fillSel(sel, [""].concat(l)); sel.value = v.trim();
    });
    if (u) F.set(Object.assign({ alerts: "اشعارات جديدة 2023", branch: BR[0] }, u.ext, { type: uType(u), name: u.name, user: u.user, roleId: u.roleId || "", active: u.active, noOthers: !!u.ext.noOthers, dayClose: !!u.ext.dayClose }));
    else F.set({ type: "admin", alerts: "اشعارات جديدة 2023", job: jobs[0] || "", branch: BR[0], roleId: "" });
    upType();
    pg.querySelector("[data-save]").addEventListener("click", () => save(false));
    const cp = pg.querySelector("[data-savecp]"); if (cp) cp.addEventListener("click", () => save(true));
    function save(copy) {
      if (!F.validate()) return;
      const v = F.get(), adm = v.type === "admin", ar = adminRole();
      const roleId = adm && ar ? ar.RoleId : +v.roleId || null;
      if (!roleId) { say("اختر «السماحية» للمستخدم", "w"); rSel.classList.add("bad"); rSel.focus(); return; }
      if (!edit) {
        if (v.pw !== v.pw2) { say("الرقم السرى وتأكيده غير متطابقين", "w"); F.q("pw2").focus(); return; }
        if (v.pw.length < 4) { say("الرقم السرى يجب ألا يقل عن 4 حروف", "w"); F.q("pw").focus(); return; }
        if ((CACHE_USERS || []).some(x => norm(x.user) === norm(v.user.trim()))) { say("اسم المستخدم «" + v.user.trim() + "» موجود من قبل", "w"); F.q("user").focus(); return; }
      }
      const active = edit ? v.active : pg.querySelector('.fh-form>.side [data-k="active"]').checked;
      if (edit && isMe(u) && !active) { say("لا يمكنك إيقاف حسابك الحالي", "w"); return; }
      const pay = { UserId: u ? u.id : 0, Username: edit ? u.user : v.user.trim(), FullName: v.name.trim(), RoleId: roleId, BranchId: u ? u.branchId : null, IsActive: active, Password: edit ? null : v.pw };
      const ext = Object.assign({}, u ? u.ext : {}, { type: v.type, branch: v.branch, alerts: v.alerts, rpt: v.rpt, job: v.job, dept: v.dept, mgr: v.mgr, shift: v.shift, mob: v.mob, mob2: v.mob2, mail: v.mail, addr: v.addr, noOthers: !adm && !!v.noOthers, dayClose: !adm && !!v.dayClose, scope: adm ? {} : SC.get() });
      const btns = pg.querySelectorAll("[data-save],[data-savecp]"); btns.forEach(b => b.disabled = true);
      let p;
      if (HOST()) p = call("users.save", pay);
      else { const l = lsGet("fh.users", [{ UserId: 1, Username: "admin", FullName: "مدير النظام", RoleId: 1, IsActive: true }]); if (!edit && l.some(x => norm(x.Username) === norm(pay.Username))) p = Promise.reject(new Error("اسم المستخدم موجود من قبل")); else { const rec = Object.assign({}, pay); delete rec.Password; if (u) Object.assign(l.find(x => x.UserId === u.id), rec); else { rec.UserId = l.reduce((m, x) => Math.max(m, x.UserId), 0) + 1; rec.CreatedAt = today(); l.push(rec); } lsSet("fh.users", l); p = Promise.resolve(rec.UserId); } }
      p.then(id => DB.save("uext", { id: u ? u.extId : 0, no: String(+id || pay.UserId), name: pay.Username, data: ext }))
        .then(() => {
          btns.forEach(b => b.disabled = false);
          say("تم حفظ المستخدم «" + pay.FullName + "»", "s");
          usRefresh();
          if (copy) { F.set({ name: "", user: "", pw: "", pw2: "" }); if (meter) { meter.className = "us-meter"; meter.querySelector("span").textContent = ""; } F.q("name").focus(); return; }
          if (opt.onSaved) opt.onSaved(pay, ext);
        }).catch(e => { btns.forEach(b => b.disabled = false); err(e); });
    }
    return { F, save: () => save(false), focus: () => setTimeout(() => F.q("name").focus(), 60) };
  }
  function pwScore(s) {
    s = s || ""; let n = 0;
    if (s.length >= 4) n++; if (s.length >= 8) n++; if (/[A-Za-z؀-ۿ]/.test(s) && /\d/.test(s)) n++; if (/[^A-Za-z0-9؀-ۿ]/.test(s) || (/[a-z]/.test(s) && /[A-Z]/.test(s))) n++;
    if (s.length < 4) n = 0;
    return { n, t: ["قصير جداً", "ضعيف", "متوسط", "جيد", "قوي"][n] };
  }

  const USDOCS = {};
  let USSEQ = 1;
  function userForm(u) {
    if (u) { userProfile(u, "prop"); return; }
    const view = "fhusf", key = view + ":n" + USSEQ++, title = "مستخدم جديد";
    const host = mkView(view, title);
    const page = document.createElement("div"); page.dataset.key = key; page.style.cssText = "display:none;flex:1;flex-direction:column;min-height:0"; host.appendChild(page);
    const pg = document.createElement("div"); pg.className = "fh-page us-page"; page.appendChild(pg);
    const doc = USDOCS[key] = { key, page };
    const UF = userFormInto(pg, null, { onSaved: () => { delete USDOCS[key]; tabClose(key); page.remove(); } });
    doc.save = UF.save;
    tabOpen(key, title, view);
    UF.focus();
  }
  RV.VIEW_SHOW.fhusf = function () { const k = H.activeKey(); Object.values(USDOCS).forEach(d => d.page.style.display = d.key === k ? "flex" : "none"); };

  /* -------- ملف المستخدم (عام / خصائص المستخدم / الصلاحيات / سجل الدخول) -------- */
  const UPDOCS = {};
  const UPI = {
    deals: '<svg viewBox="0 0 40 40"><rect x="8" y="3" width="24" height="34" rx="2" fill="#1f74e0"/><g fill="#fff"><rect x="12" y="9" width="16" height="3"/><rect x="12" y="15" width="16" height="3"/><rect x="12" y="21" width="10" height="3"/></g><path d="M8 37l4-3 4 3 4-3 4 3 4-3 4 3" stroke="#fff" stroke-width="1.6" fill="none"/></svg>',
    log: '<svg viewBox="0 0 40 40"><rect x="4" y="6" width="32" height="28" rx="3" fill="#1f74e0"/><rect x="4" y="6" width="32" height="7" rx="3" fill="#12508f"/><g fill="#fff"><rect x="9" y="18" width="5" height="4"/><rect x="17" y="18" width="5" height="4"/><rect x="25" y="18" width="5" height="4"/><rect x="9" y="25" width="5" height="4"/><rect x="17" y="25" width="5" height="4"/></g></svg>',
    prop: '<svg viewBox="0 0 40 40"><path d="M7 33l2-8L27 7l6 6-18 18z" fill="#1f74e0"/><path d="M24 10l6 6" stroke="#fff" stroke-width="2"/><rect x="5" y="34" width="14" height="3" fill="#12508f"/></svg>',
    lock: '<svg viewBox="0 0 40 40"><path d="M12 17v-5a8 8 0 0 1 16 0v5" fill="none" stroke="#27313c" stroke-width="3.4"/><rect x="8" y="17" width="24" height="19" rx="4" fill="#27313c"/><g fill="#fff"><circle cx="15" cy="26.5" r="1.8"/><circle cx="20" cy="26.5" r="1.8"/><circle cx="25" cy="26.5" r="1.8"/></g></svg>',
    stop: '<svg viewBox="0 0 40 40"><circle cx="20" cy="20" r="15" fill="none" stroke="#c0392b" stroke-width="3.6"/><path d="M9.5 30.5l21-21" stroke="#c0392b" stroke-width="3.6"/></svg>',
    play: '<svg viewBox="0 0 40 40"><circle cx="20" cy="20" r="15" fill="#2d8a4e"/><path d="M16 13l11 7-11 7z" fill="#fff"/></svg>',
    swap: '<svg viewBox="0 0 40 40"><circle cx="15" cy="13" r="6" fill="#27313c"/><path d="M4 34c1-8 6-12 11-12s10 4 11 12z" fill="#27313c"/><path d="M27 15h9M32 11l4 4-4 4M36 26h-9M31 22l-4 4 4 4" stroke="#1f74e0" stroke-width="2.4" fill="none"/></svg>',
    perm: '<svg viewBox="0 0 40 40"><path d="M20 3l14 5v10c0 9-6 15-14 19C12 33 6 27 6 18V8z" fill="#1f74e0"/><path d="M13 20l5 5 9-10" stroke="#fff" stroke-width="3" fill="none"/></svg>',
    edits: '<svg viewBox="0 0 40 40"><path d="M9 27l3.5-9.5L27 3l9 9-14.5 14.5z" fill="#1f74e0"/><path d="M12.5 17.5l9 9" stroke="#fff" stroke-width="2"/><path d="M9 27l-5 7h10l2-4z" fill="#1f74e0"/><rect x="4" y="35" width="32" height="3" rx="1.5" fill="#12508f"/></svg>',
    bin: '<svg viewBox="0 0 40 40"><rect x="7" y="7" width="26" height="4" rx="1.5" fill="#1f74e0"/><rect x="15" y="3" width="10" height="5" rx="1.5" fill="#1f74e0"/><path d="M9 12h22l-2 25H11z" fill="#1f74e0"/><path d="M15 19l10 11M25 19L15 30" stroke="#fff" stroke-width="3" stroke-linecap="round"/></svg>',
    guard: '<svg viewBox="0 0 40 40"><path d="M20 2l15 5.5v10.5c0 9.5-6.5 16.5-15 20-8.5-3.5-15-10.5-15-20V7.5z" fill="#0f2a4f"/><path d="M20 6.5l11 4v8c0 7-4.6 12.6-11 15.5" fill="#1f74e0"/><circle cx="20" cy="18" r="4.5" fill="#fff"/><path d="M12.5 29.5c1.6-4 4.4-6 7.5-6s5.9 2 7.5 6" fill="#fff"/></svg>',
    defs: '<svg viewBox="0 0 40 40"><path d="M5 21l7 7 13-15" stroke="#27313c" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M17 26l3 3 15-17" stroke="#27313c" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    wa: '<svg viewBox="0 0 40 40"><path d="M20 3a17 17 0 0 0-14.6 25.7L3 37l8.6-2.3A17 17 0 1 0 20 3z" fill="#25d366"/><path d="M29.2 24.6c-.5-.2-2.9-1.4-3.3-1.6-.5-.2-.8-.2-1.1.2l-1.6 1.9c-.3.3-.6.4-1 .1a13.8 13.8 0 0 1-6.8-6c-.5-.9.5-.8 1.4-2.6.2-.3.1-.6 0-.9l-1.5-3.6c-.4-1-.8-.8-1.1-.8h-.9c-.4 0-.9.1-1.3.6-.5.5-1.8 1.7-1.8 4.1s1.8 4.8 2 5.1c.3.3 3.5 5.3 8.4 7.5 3.2 1.4 4.4 1.5 6 1.2 1-.2 2.9-1.2 3.3-2.4.4-1.2.4-2.2.3-2.4-.1-.2-.4-.3-.9-.5z" fill="#fff"/></svg>'
  };
  function userProfile(u, tab) {
    if (!u) return;
    const view = "fhusp", key = view + ":" + u.id;
    if (UPDOCS[key]) { tabOpen(key, u.user, view); if (tab) UPDOCS[key].go(tab); return; }
    const host = mkView(view, "ملف المستخدم");
    const page = document.createElement("div"); page.dataset.key = key; page.className = "up-page"; page.style.display = "none"; host.appendChild(page);
    const doc = UPDOCS[key] = { key, page, u };
    page.innerHTML = `<div class="up-hd"><div class="up-av">${IC.user}<span class="up-st"><i></i><b></b></span></div><div class="up-nm"></div>
      <div class="up-tabs"><button type="button" data-t="gen">عام</button><button type="button" data-t="prop">خصائص المستخدم</button><button type="button" data-t="perm">الصلاحيات</button><button type="button" data-t="log">سجل الدخول</button></div></div>
      <div class="up-bd"><aside class="up-side"></aside><div class="up-main"><div class="up-p" data-p="gen"></div><div class="up-p" data-p="prop"></div><div class="up-p" data-p="perm"></div><div class="up-p" data-p="log"></div></div></div>`;
    const P = k => page.querySelector(`[data-p="${k}"]`), done = {};
    doc.paint = function () {
      const x = (CACHE_USERS || []).find(y => y.id === u.id); if (x) { u = doc.u = x; }
      page.querySelector(".up-nm").textContent = u.name;
      const st = page.querySelector(".up-st"); st.classList.toggle("on", !!u.online); st.classList.toggle("off", !u.active); st.querySelector("b").textContent = !u.active ? "موقوف" : u.online ? "Online" : "Offline";
      page.querySelector(".up-side").innerHTML = [["uid", u.user, "اسم المستخدم", 1], ["user", tName(u), "النوع", 1], ["phone", u.ext.mob || "", "رقم المحمول"], ["mail", u.ext.mail || "", "الإيميل"], null, ["br", u.ext.branch || BR[0] || "", "الفرع"], ["role", u.role || "", "السماحية"], ["mgr", u.ext.mgr || "", "المدير المباشر"], ["cal", u.created || "", "تاريخ الإضافة"], ["clk", u.last || "", "آخر دخول"]]
        .map(r => r ? `<div class="up-si${r[3] ? " b" : ""}" title="${esc(r[2])}"><span>${esc(r[1]) || "—"}</span><i>${esc(r[2])}</i></div>` : '<div class="up-sep"></div>').join("");
      if (done.gen) paintGen();
    };
    function paintGen() {
      const me = isMe(u);
      const tile = (k, ic, t, cls) => `<button type="button" class="up-tile${cls ? " " + cls : ""}" data-go="${k}">${UPI[ic]}<span>${esc(t)}</span></button>`;
      /* مطابق DEXEF: روابط سريعة (التعاملات / سجل التعديلات / سلة المحذوفات) + الإعدادات (الرقم السرى / الحسابات الافتراضية)
         + إضافات ANOUER: «مركز الرقابة» و«تنبيهات الواتساب» للمدير (audit-ui.js) */
      const AD = !!(window.__AUD && __AUD.isAdm());
      P("gen").innerHTML = `<h3>روابط سريعة</h3><div class="up-tiles">${tile("deals", "deals", "التعاملات", "pri")}${tile("edits", "edits", "سجل التعديلات")}${tile("bin", "bin", "سلة المحذوفات")}${AD ? tile("guard", "guard", "مركز الرقابة", "grd") : ""}</div>
        <h3>الإعدادات</h3><div class="up-tiles">${tile("pw", "lock", "تعديل الرقم السرى")}${tile("defs", "defs", "الحسابات الإفتراضية")}${AD ? tile("wa", "wa", "تنبيهات الواتساب") : ""}${me ? tile("swap", "swap", "تبديل المستخدم") : tile("act", u.active ? "stop" : "play", u.active ? "إيقاف الحساب" : "تنشيط الحساب")}</div>`;
    }
    function go(t) {
      page.querySelectorAll(".up-tabs [data-t]").forEach(b => b.classList.toggle("on", b.dataset.t === t));
      page.querySelectorAll(".up-p").forEach(p => p.classList.toggle("on", p.dataset.p === t));
      if (done[t] && t !== "log") return; done[t] = 1;
      if (t === "gen") paintGen();
      else if (t === "prop") { P("prop").innerHTML = ""; const pg = document.createElement("div"); pg.className = "fh-page us-page"; P("prop").appendChild(pg); doc.UF = userFormInto(pg, u, { onSaved: () => { loadUsers().then(() => { doc.paint(); usRefresh(); }); } }); }
      else if (t === "perm") permPane(P("perm"), u, () => doc.paint());
      else if (t === "log") loginsPane(P("log"), () => HOST() ? call("users.logins", { id: u.id, top: 500 }) : Promise.resolve(lsGet("fh.ulog." + u.id, [])));
    }
    doc.go = go;
    page.querySelector(".up-tabs").addEventListener("click", e => { const b = e.target.closest("[data-t]"); if (b) go(b.dataset.t); });
    P("gen").addEventListener("click", e => {
      const b = e.target.closest("[data-go]"); if (!b) return; const k = b.dataset.go;
      const AUI = window.__AUDUI;
      if ((k === "deals" || k === "edits" || k === "bin") && AUI) AUI.folders({ deals: "deal", edits: "edit", bin: "del" }[k], u);
      else if (k === "deals") { try { openTab("srev", "مراجعة مبيعات", "srev"); } catch (x) { say("تعذّر فتح التعاملات", "w"); } }
      else if (k === "guard" && AUI) AUI.center({ user: u.id });
      else if (k === "wa" && AUI) AUI.center({ tab: "wa" });
      else if (k === "defs") defsDialog(u);
      else if (k === "pw") pwDialog(u);
      else if (k === "act") setActive(u, !u.active);
      else if (k === "swap") relogin();
      else go(k);
    });
    doc.save = () => { if (doc.UF && P("prop").classList.contains("on")) doc.UF.save(); };
    doc.paint(); go(tab || "gen");
    tabOpen(key, u.user, view);
  }
  RV.VIEW_SHOW.fhusp = function () { const k = H.activeKey(); Object.values(UPDOCS).forEach(d => d.page.style.display = d.key === k ? "flex" : "none"); };

  function permPane(host, u, onSaved) {
    const adm = uType(u) === "admin";
    host.innerHTML = `<div class="up-perm"><div class="up-pl"><h3>${adm ? "مدير النظام" : "جهات التعامل المسموحة"}</h3>${adm ? `<div class="up-note">${esc(UTYPES[0][2])} — لا يحتاج تحديد جهات.</div>` : '<div class="up-note">اترك السطر على «الكل» ليتعامل مع كل الجهات، أو اختر جهات محددة.</div><div data-scope="1"></div><div class="up-pa"><button type="button" class="fh-btn green" data-psave="1">حفظ</button></div>'}</div>
      <div class="up-pr"><h3>صلاحيات السماحية <small>${esc(u.role || "—")}</small></h3><div class="up-plist" data-pl="1"><div class="fh-empty">...</div></div></div></div>`;
    let SC = null;
    if (!adm) {
      SC = scopeEditor(host.querySelector("[data-scope]"), u.ext.scope || {});
      host.querySelector("[data-psave]").addEventListener("click", () => {
        const ext = Object.assign({}, u.ext, { scope: SC.get() });
        DB.save("uext", { id: u.extId || 0, no: String(u.id), name: u.user, data: ext }).then(r => { u.ext = ext; if (r && r.id) u.extId = r.id; say("تم حفظ صلاحيات «" + u.name + "»", "s"); loadUsers().then(onSaved); }).catch(err);
      });
    }
    const pl = host.querySelector("[data-pl]");
    if (!HOST() || !u.roleId) { pl.innerHTML = `<div class="fh-empty">${u.roleId ? "تظهر صلاحيات السماحية عند التشغيل داخل البرنامج" : "لا توجد سماحية"}</div>`; return; }
    Promise.all([call("perms.list"), call("roles.perms", { roleId: u.roleId }), loadMe()]).then(([all, codes, me]) => {
      const on = new Set(codes || []), orig = new Set(on);
      const canEdit = !!(me && (me.Permissions || []).includes("users.manage"));
      const NEW = { "products.quick": 1, "products.quickDelete": 1 };
      /* صلاحيات السماحية قابلة للتعديل (لمن يملك «إدارة المستخدمين») — اضغط على الصلاحية لتفعيلها/إلغائها ثم «حفظ» */
      const paint = () => {
        const dirty = [...on].sort().join() !== [...orig].sort().join();
        pl.innerHTML = `<div class="up-pnote">${canEdit ? `اضغط على أي صلاحية لتفعيلها أو إلغائها — تُطبَّق على <b>كل</b> مستخدمي السماحية «${esc(u.role || "")}»` : "🔒 تعديل الصلاحيات يحتاج صلاحية «إدارة المستخدمين»"}</div>` +
          (all || []).slice().sort((a, b) => (NEW[b.Code] ? 1 : 0) - (NEW[a.Code] ? 1 : 0)).map(p => `<div class="up-pi${on.has(p.Code) ? " y" : ""}${canEdit ? " ed" : ""}${NEW[p.Code] ? " nw" : ""}" data-pc="${esc(p.Code)}" role="switch" aria-checked="${on.has(p.Code)}" tabindex="${canEdit ? 0 : -1}"><span class="up-sw"><b></b></span><span>${esc(p.Name)}${NEW[p.Code] ? ' <em class="up-new">جديد</em>' : ""}</span><code>${esc(p.Code)}</code></div>`).join("") +
          (canEdit ? `<div class="up-psv"><button type="button" class="fh-btn green" data-rsave="1"${dirty ? "" : " disabled"}>حفظ صلاحيات السماحية</button>${dirty ? '<span class="up-dirty">● تغييرات غير محفوظة</span>' : ""}</div>` : "");
      };
      paint();
      if (!canEdit) return;
      const tog = el => { const c = el.dataset.pc; if (c === "users.manage" && on.has(c) && me.RoleId === u.roleId) { say("لا يمكنك إزالة «إدارة المستخدمين» من سماحيتك أنت", "w"); return; } on.has(c) ? on.delete(c) : on.add(c); paint(); const n = pl.querySelector(`[data-pc="${c}"]`); if (n) n.focus(); };
      pl.addEventListener("click", e => {
        const it = e.target.closest(".up-pi.ed"); if (it) { tog(it); return; }
        if (e.target.closest("[data-rsave]")) call("roles.setPerms", { roleId: u.roleId, codes: [...on] }).then(() => { orig.clear(); on.forEach(c => orig.add(c)); paint(); say("تم حفظ صلاحيات السماحية «" + (u.role || "") + "» — تسري عند الدخول التالي للمستخدم", "s"); }).catch(err);
      });
      pl.addEventListener("keydown", e => { const it = e.target.closest(".up-pi.ed"); if (it && (e.key === " " || e.key === "Enter")) { e.preventDefault(); tog(it); } });
    }).catch(e => { pl.innerHTML = `<div class="fh-empty">${esc(e.message || "تعذّر تحميل الصلاحيات")}</div>`; });
  }

  function loginsPane(host, loader) {
    host.innerHTML = `<div class="up-log"><h3>سجل الحضور</h3><div class="up-lg" data-g="1"></div></div>`;
    const G = Grid(host.querySelector("[data-g]"), { cols: [{ t: "حضور", w: "64px", chk: 1, v: r => true }, { t: "التاريخ", w: "110px", f: r => r.Date }, { t: "اليوم", w: "90px", f: r => dayName(r.Date) }, { t: "وقت الدخول", w: "100px", f: r => ampm(r.LoginAt) }, { t: "وقت الخروج", w: "100px", f: r => r.LogoutAt ? ampm(r.LogoutAt) : "" }, { t: "Ip Address", w: "120px", f: r => r.Ip || "" }, { t: "مكان الدخول", w: "1fr", f: r => [r.Machine, r.WinUser].filter(Boolean).join(" — ") }], empty: "لا يوجد سجل دخول بعد" });
    Promise.resolve(loader()).then(l => G.set(l || [])).catch(e => G.set([]) || say(e.message || "تعذّر تحميل سجل الدخول", "w"));
  }

  /* -------- «تعديل الرقم السرى» (مطابق DEXEF) — self: يتطلّب الرقم الحالي -------- */
  function pwDialog(u, self) {
    document.querySelectorAll(".up-pwov").forEach(x => x.remove());
    const ov = document.createElement("div"); ov.className = "up-pwov";
    const nm = self ? ((ME && (ME.Username || ME.FullName)) || "") : u.user;
    ov.innerHTML = `<div class="up-pw" role="dialog" aria-modal="true"><button type="button" class="up-px" data-x="1" title="إغلاق (Esc)">✕</button><h2>تعديل الرقم السرى</h2>
      <div class="up-pwb"><div class="up-art"><div class="up-brand">ANOUER</div><svg viewBox="0 0 220 190"><rect x="98" y="30" width="96" height="140" rx="8" fill="#dfe5ec"/><rect x="110" y="58" width="72" height="12" rx="2" fill="#fff"/><rect x="110" y="84" width="72" height="12" rx="2" fill="#fff"/><rect x="110" y="104" width="72" height="12" rx="2" fill="#fff"/><rect x="116" y="130" width="60" height="12" rx="3" fill="#a9b6c4"/><text x="146" y="48" font-size="9" text-anchor="middle" fill="#6b7886" font-family="Segoe UI,Arial">Reset Password</text><path d="M170 20a14 14 0 0 1 14 14v8h-6v-8a8 8 0 0 0-16 0v8h-6v-8a14 14 0 0 1 14-14z" fill="#8795a4"/><rect x="152" y="40" width="36" height="28" rx="4" fill="#8795a4"/><rect x="38" y="14" width="40" height="16" rx="4" fill="#8795a4"/><text x="58" y="26" font-size="10" text-anchor="middle" fill="#fff">••••••</text><circle cx="62" cy="62" r="11" fill="#2a2f36"/><path d="M50 74h24l8 48H44z" fill="#e9eef3" stroke="#c9d1da"/><path d="M47 120h12l-2 52h-7zM65 120h12l1 52h-7z" fill="#3a4048"/><path d="M58 92l42-26" stroke="#7d8996" stroke-width="7" stroke-linecap="round"/><circle cx="44" cy="98" r="12" fill="none" stroke="#7d8996" stroke-width="5"/><ellipse cx="110" cy="176" rx="80" ry="5" fill="#e6eaef"/></svg></div>
      <div class="up-pwf"><div class="up-pwn">${esc(nm)}</div>${self ? '<label>الرقم السرى الحالى<b>*</b><input type="password" data-o="1" autocomplete="current-password"></label>' : ""}
        <label>الرقم السرى الجديد<b>*</b><input type="password" data-n="1" autocomplete="new-password"></label><div class="us-meter" data-meter="1"><i></i><span></span></div>
        <label>إعادة الرقم السرى<b>*</b><input type="password" data-c="1" autocomplete="new-password"></label><div class="up-pwe" data-e="1"></div></div>
      <div class="up-pwa"><button type="button" class="fh-btn green" data-ok="1">حفظ</button><button type="button" class="fh-btn" data-x="1">الغاء</button></div></div></div>`;
    document.body.appendChild(ov);
    const q = s => ov.querySelector(s), E = q("[data-e]"), meter = q("[data-meter]");
    const close = () => { ov.remove(); window.__FH_DLGKEY = prevKey; };
    const prevKey = window.__FH_DLGKEY;
    window.__FH_DLGKEY = e => { if (!document.body.contains(ov)) return false; if (e.key === "Escape") { close(); return true; } if (e.key === "F2") { ok(); return true; } if (/^F\d+$/.test(e.key)) return true; return false; };
    q("[data-n]").addEventListener("input", () => { const s = pwScore(q("[data-n]").value); meter.className = "us-meter s" + s.n; meter.querySelector("span").textContent = q("[data-n]").value ? s.t : ""; });
    ov.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); const f = Array.from(ov.querySelectorAll("input")), i = f.indexOf(e.target); if (i >= 0 && i < f.length - 1) f[i + 1].focus(); else ok(); } else if (e.key === "Escape") { e.preventDefault(); close(); } });
    ov.addEventListener("click", e => { if (e.target.closest("[data-x]")) close(); else if (e.target.closest("[data-ok]")) ok(); });
    function bad(m, s) { E.textContent = m; const x = q(s); if (x) { x.focus(); x.select(); } }
    function ok() {
      const o = self ? q("[data-o]").value : "", n = q("[data-n]").value, c = q("[data-c]").value; E.textContent = "";
      if (self && !o) return bad("اكتب الرقم السرى الحالى", "[data-o]");
      if (n.length < 4) return bad("الرقم السرى يجب ألا يقل عن 4 حروف", "[data-n]");
      if (n !== c) return bad("إعادة الرقم السرى غير مطابقة", "[data-c]");
      if (self && o === n) return bad("الرقم الجديد مطابق للحالي", "[data-n]");
      if (!HOST()) { close(); say("تعديل الرقم السرى يعمل داخل البرنامج فقط", "w"); return; }
      q("[data-ok]").disabled = true;
      (self ? call("auth.changePassword", { oldPassword: o, newPassword: n }) : call("users.resetPassword", { id: u.id, password: n }))
        .then(() => { close(); say(self ? "تم تغيير الرقم السرى الخاص بك" : "تم تعديل الرقم السرى للمستخدم «" + u.name + "»", "s"); })
        .catch(e => { q("[data-ok]").disabled = false; bad((e && e.message) || "تعذّر الحفظ", self ? "[data-o]" : "[data-n]"); });
    }
    setTimeout(() => (self ? q("[data-o]") : q("[data-n]")).focus(), 30);
  }
  /* -------- «الحسابات الإفتراضية» (مطابق DEXEF): الفرع، الخزينة، البنك، بطاقة الإئتمان، الموظف المسئول عن العهدة،
     شريحة الأسعار، العملة، المخزن ومخزن التحويل — تُحفظ في ملف المستخدم وتُطبَّق عند دخوله (الخزينة في شاشة الدفع) -------- */
  const SLICES = ["سعر البيع", "الجملة", "التجزئة", "عابر سبيل", "استطلاع", "5 ومافوق"];
  function defsDialog(u) {
    document.querySelectorAll(".up-pwov").forEach(x => x.remove());
    const d = Object.assign({ br: BR[0] || "الفرع الرئيسي", tr: "", bk: "", vs: "", cus: "", sl: "", last: false, cur: "DZD", wh: "", twh: "" }, u.ext.defs || {});
    const ov = document.createElement("div"); ov.className = "up-pwov";
    const row = (k, t, req, extra) => `<label class="up-dr"><span>${t}${req ? "<b>*</b>" : ""}</span><select data-d="${k}"><option value="">—</option></select>${extra || ""}</label>`;
    ov.innerHTML = `<div class="up-pw up-df" role="dialog" aria-modal="true"><button type="button" class="up-px" data-x="1" title="إغلاق (Esc)">✕</button><h2>الحسابات الإفتراضية <small>${esc(u.name)}</small></h2>
      <div class="up-ds o">${row("br", "الفرع", 1)}</div>
      <h4>الحسابات</h4><div class="up-ds">${row("tr", "الخزينة الافتراضيه", 1)}${row("bk", "البنك الافتراضي")}${row("vs", "بطاقة الإئتمان الافتراضية")}${row("cus", "الموظف المسئول عن العهدة")}${row("sl", "شريحة الاسعار الافتراضية", 0, '<label class="up-dl"><input type="checkbox" data-last="1"><i></i>سعر اخر تعامل</label>')}${row("cur", "العملة")}</div>
      <h4>المخازن</h4><div class="up-ds">${row("wh", "المخزن الافتراضي")}${row("twh", "مخزن التحويل الافتراضي")}</div>
      <div class="up-pwa"><button type="button" class="fh-btn green" data-ok="1">حفظ</button><button type="button" class="fh-btn" data-x="1">اغلاق</button></div></div>`;
    document.body.appendChild(ov);
    const q = s => ov.querySelector(s);
    const fill = (k, l) => { const s = q(`[data-d="${k}"]`); const v = d[k]; const o = (l || []).slice(); if (v && !o.includes(v)) o.push(v); s.innerHTML = '<option value="">—</option>' + o.map(x => `<option>${esc(x)}</option>`).join(""); s.value = v || ""; };
    Promise.all([scopeSrc("br"), scopeSrc("tr"), scopeSrc("bk"), scopeSrc("vs"), scopeSrc("wh")]).then(([br, tr, bk, vs, wh]) => {
      fill("br", br); fill("tr", tr); fill("bk", bk); fill("vs", vs); fill("wh", wh); fill("twh", wh);
      fill("cus", users().map(x => x.name)); fill("sl", SLICES); fill("cur", ["DZD"].concat(((window.ANOUER_FX && ANOUER_FX.codes && ANOUER_FX.codes()) || []).filter(c => c !== "DZD")));
      if (!d.tr && tr.length) q('[data-d="tr"]').value = tr[0];
      if (!d.wh && wh.length) { q('[data-d="wh"]').value = wh[0]; q('[data-d="twh"]').value = wh[0]; }
    });
    q("[data-last]").checked = !!d.last;
    const close = () => { ov.remove(); window.__FH_DLGKEY = prevKey; };
    const prevKey = window.__FH_DLGKEY;
    window.__FH_DLGKEY = e => { if (!document.body.contains(ov)) return false; if (e.key === "Escape") { close(); return true; } if (e.key === "F2") { ok(); return true; } return /^F\d+$/.test(e.key); };
    ov.addEventListener("click", e => { if (e.target.closest("[data-x]")) close(); else if (e.target.closest("[data-ok]")) ok(); });
    ov.addEventListener("keydown", e => { if (e.key === "Escape") { e.preventDefault(); close(); } });
    function ok() {
      const v = {}; ov.querySelectorAll("[data-d]").forEach(s => v[s.dataset.d] = s.value); v.last = q("[data-last]").checked;
      if (!v.br) { say("اختر الفرع", "w"); q('[data-d="br"]').focus(); return; }
      if (!v.tr) { say("اختر الخزينة الافتراضية", "w"); q('[data-d="tr"]').focus(); return; }
      const ext = Object.assign({}, u.ext, { defs: v });
      q("[data-ok]").disabled = true;
      DB.save("uext", { id: u.extId || 0, no: String(u.id), name: u.user, data: ext }).then(r => { u.ext = ext; if (r && r.id) u.extId = r.id; if (isMe(u)) window.__USER_DEFS = v; close(); say("تم حفظ الحسابات الإفتراضية لـ «" + u.name + "»", "s"); }).catch(e => { q("[data-ok]").disabled = false; err(e); });
    }
  }
  /* تطبيق الحسابات الإفتراضية للمستخدم الحالي: الخزينة المختارة تلقائياً في شاشة الدفع */
  loadMe().then(m => {
    if (!m) return; return DB.list("uext").then(l => { const x = (l || []).find(r => String(r.no) === String(m.UserId)); window.__USER_DEFS = x && x.data && x.data.defs || null; });
  }).catch(() => { });
  (function payDefTreasury() {
    const o = window.openPay; if (typeof o !== "function" || o.__defs) return;
    const w = function () { const r = o.apply(this, arguments); try { const d = window.__USER_DEFS; if (d && d.tr && typeof TREASURIES !== "undefined" && P && !(adj.pays && Object.keys(adj.pays).length)) { const i = TREASURIES.findIndex(t => t.name === d.tr); if (i > 0) { P.act = i; payRender(); } } } catch (e) { } return r; };
    w.__defs = 1; w.__aud = o.__aud; window.openPay = w;
  })();
  function relogin() {
    ask("هل تريد تسجيل الخروج والدخول بمستخدم آخر ؟", () => { if (HOST()) call("win.relogin").catch(err); else say("تبديل المستخدم يعمل داخل البرنامج فقط", "w"); });
  }

  /* -------- اسم المستخدم الحالي أسفل الشاشة + قائمته (تعديل الرقم السرى الخاص بي، سجل دخولي، تبديل المستخدم) -------- */
  (function statusUser() {
    const lbl = document.querySelector(".status span.end"), val = lbl && lbl.nextElementSibling;
    if (!lbl || !val) return;
    [lbl, val].forEach(x => { x.classList.add("us-stat"); x.title = "المستخدم الحالي — اضغط للخيارات"; });
    loadMe().then(m => { if (m && (m.Username || m.FullName)) { val.textContent = m.Username || m.FullName; val.title = (m.FullName || "") + (m.RoleName ? " — " + m.RoleName : ""); } });
    const open = e => {
      e.preventDefault();
      const r = val.getBoundingClientRect();
      ctxMenu([["تعديل الرقم السرى الخاص بي", "", "", () => pwDialog(null, true)], ["سجل الدخول الخاص بي", "", IC.chart, () => {
        const D = Dlg({ title: "سجل الدخول — " + ((ME && ME.Username) || ""), w: 760, noFoot: true });
        D.body.style.height = "420px"; D.body.style.display = "flex"; D.body.style.flexDirection = "column";
        loginsPane(D.body, () => HOST() ? call("auth.myLogins", { top: 500 }) : Promise.resolve([]));
      }], ["تبديل المستخدم", "", "", relogin]], { x: r.right, y: Math.max(4, r.top - 92) });
    };
    lbl.addEventListener("click", open); val.addEventListener("click", open);
  })();
  /* منافذ لقائمة المستخدم في شريط العنوان (user-menu.js) — مطابقة DEXEF */
  window.__FHUS = {
    me: loadMe,
    pwSelf: () => pwDialog(null, true),
    relogin,
    logins: () => { const D = Dlg({ title: "سجل الدخول — " + ((ME && ME.Username) || ""), w: 760, noFoot: true }); D.body.style.height = "420px"; D.body.style.display = "flex"; D.body.style.flexDirection = "column"; loginsPane(D.body, () => HOST() ? call("auth.myLogins", { top: 500 }) : Promise.resolve([])); },
    profileMe: () => loadMe().then(m => loadUsers().then(l => { const u = (l || []).find(x => m && x.id === m.UserId); if (!u) throw new Error("no"); userProfile(u, "prop"); return true; }))
  };

  /* ================================================================ لوحة تقارير (DEXEF tiles) */
  function repGrid(groups) {
    return `<div class="fh-rep">${groups.map((g, gi) => `<div class="col"><b>${esc(g[0])}</b>${g[1].map((x, i) => `<button type="button" class="rb" data-r="${gi}:${i}">${IC[x[1]] || IC.rp2}<span>${esc(x[0])}</span></button>`).join("")}</div>`).join("")}</div>`;
  }
  function wireRep(p, groups) { p.__g = groups; }
  window.__FH_REPGRID = repGrid;

  /* ================================================================ اختصارات الشاشات (ملف: Ctrl+N/E/D/P/Q، F5) */
  const prevKey = window.__viewKey;
  window.__viewKey = function (e) {
    if (window.__FH_DLGKEY && document.querySelector(".fh-ov")) return window.__FH_DLGKEY(e);
    const v = main.dataset.view, s = SCR[v];
    const k = (e.key || "").toLowerCase(), c = e.code || "";
    const FORMS = { fhgl: GLDOCS, fhexpf: IFDOCS, fhrevf: IFDOCS, fhpf: PFDOCS, fhusf: USDOCS };
    if (FORMS[v] && !document.querySelector(".fh-ov")) {
      const d = FORMS[v][H.activeKey()];
      if (d && (e.key === "F2" || (e.ctrlKey && (k === "s" || c === "KeyS")))) { d.save && d.save(); return true; }
      if (d && e.ctrlKey && (k === "q" || c === "KeyQ")) { tabClose(d.key); return true; }
    }
    if (s && !document.querySelector(".fh-ov") && !e.altKey) {
      if (e.ctrlKey && !e.shiftKey && (k === "n" || c === "KeyN") && s.newItem) { s.newItem(); return true; }
      if (e.ctrlKey && !e.shiftKey && (k === "e" || c === "KeyE") && s.edit) { s.edit(); return true; }
      if (e.ctrlKey && !e.shiftKey && (k === "d" || c === "KeyD") && s.del) { s.del(); return true; }
      if (e.ctrlKey && !e.shiftKey && (k === "p" || c === "KeyP") && s.print) { s.print(); return true; }
      if (e.ctrlKey && !e.shiftKey && (k === "q" || c === "KeyQ")) { tabClose(H.activeKey()); return true; }
      if (e.key === "F5" && s.refresh) { s.refresh(true); return true; }
    }
    return prevKey ? prevKey(e) : false;
  };

  window.__FH_SCR = SCR;
  window.__FH_FORMS = { glForm, userForm, itemForm, payForm };
})();
