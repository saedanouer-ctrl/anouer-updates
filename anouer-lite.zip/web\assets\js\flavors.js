/* ANOUER — «الأذواق»: تجميع الأصناف التي لها نفس الاسم ونفس السعر وتختلف في الذوق
   مثال: «CAPRICE 200P علك باطة(فراز+دلاع)» + «CAPRICE 200P علك باطة(فليو)» بنفس السعر ← صنف واحد في البيع «CAPRICE F+D+C»
   - التجميع تلقائي (نفس الاسم الأساسي + نفس السعر + نفس الوحدات)؛ إذا تغيّر سعر أحدها ينفصل وحده تلقائياً.
   - الرصيد مشترك: يظهر مجموع أرصدة الأذواق، وعند الحفظ تُوزَّع الكمية على الأذواق حسب أرصدتها (الأكبر أولاً).
   - الاسم المختصر يظهر في الفواتير (البحث، الأصناف بالصور F10، فاتورة اللمس، أسطر الفاتورة).
   - إطار «الأذواق» في بطاقة الصنف: إدخال الأذواق كرقائق، حرف كل ذوق، الاسم المختصر، وأصناف العائلة. */
(function () {
  "use strict";
  const PR = () => window.ANOUER_PROPS;
  const LS = { get: (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } } };
  const pget = (k, d) => { try { const v = PR() && PR().get(k, null); if (v != null) return v; } catch (e) { } return LS.get(k, d); };
  const pput = (k, v) => { LS.set(k, v); try { PR() && PR().put(k, v); } catch (e) { } };
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => "&#" + c.charCodeAt(0) + ";");
  const F = n => (Math.round((+n || 0) * 100) / 100).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const T = (m, k) => { try { toast(m, k || "i"); } catch (e) { } };
  const norm = s => String(s || "").toLowerCase().replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/[ـ]/g, "").replace(/\s+/g, " ").trim();
  const PRODS = () => { try { return Array.isArray(products) ? products : []; } catch (e) { return []; } };
  const cfg = () => Object.assign({ on: true, inv: true }, pget("flv.cfg", {}) || {});

  /* ---------- الحروف ---------- */
  const DICT = { "فراز": "F", "فريز": "F", "فراولة": "F", "فراوله": "F", "دلاع": "D", "بطيخ": "D", "فليو": "C", "ليمون": "C", "حامض": "C", "برتقال": "O", "تشينة": "O", "تشينه": "O",
    "تفاح": "P", "موز": "B", "نعناع": "M", "شكلاطة": "CH", "شوكولا": "CH", "شوكولاطة": "CH", "شكولاطة": "CH", "فانيلا": "V", "فانيليا": "V", "كراميل": "CA", "مانجو": "MG", "مانغو": "MG",
    "اناناس": "A", "أناناس": "A", "خوخ": "PE", "مشمش": "AB", "كرز": "CE", "جوز الهند": "CO", "كوكو": "CO", "حليب": "L", "قهوة": "CF", "عسل": "MI", "بندق": "N", "لوز": "AM", "فستق": "PI",
    "توت": "FR", "عنب": "R", "رمان": "G", "كيوي": "K", "كولا": "K", "تمر": "T", "جبن": "FO", "طماطم": "TO", "حار": "PI", "باربكيو": "BBQ", "ملح": "S" };
  const TR = { "ا": "A", "أ": "A", "إ": "I", "آ": "A", "ب": "B", "ت": "T", "ث": "T", "ج": "J", "ح": "H", "خ": "KH", "د": "D", "ذ": "D", "ر": "R", "ز": "Z", "س": "S", "ش": "CH", "ص": "S", "ض": "D", "ط": "T", "ظ": "D", "ع": "A", "غ": "G", "ف": "F", "ق": "K", "ك": "K", "ل": "L", "م": "M", "ن": "N", "ه": "H", "ة": "A", "و": "W", "ي": "Y", "ى": "A" };
  const letters = () => pget("flv.letters", {}) || {};
  function letterOf(f) {
    const L = letters(), k = norm(f); if (L[k]) return L[k];
    const d = Object.keys(DICT).find(x => norm(x) === k); if (d) return DICT[d];
    const c = String(f).trim(); if (!c) return "?"; if (/^[a-z]/i.test(c)) return c[0].toUpperCase();
    return TR[c[0]] || c[0];
  }
  function setLetter(f, v) { const L = letters(); v = String(v || "").trim().toUpperCase(); if (v) L[norm(f)] = v; else delete L[norm(f)]; pput("flv.letters", L); bump(); }

  /* ---------- تحليل الاسم ---------- */
  function parse(name) {
    const s = String(name || "").trim(), m = s.match(/^(.*?)\s*[(\[]([^()\[\]]+)[)\]]\s*(.*)$/);
    if (!m) return { base: s, flv: [] };
    const flv = m[2].split(/\s*[+،,\/|&]\s*|\s+و\s+/).map(x => x.trim()).filter(Boolean);
    return { base: (m[1] + (m[3] ? " " + m[3] : "")).replace(/\s+/g, " ").trim(), flv };
  }
  const priceOf = p => Math.round((+p.price || 0) * 100) / 100;
  const uSig = p => (p._u || []).map(u => +u.factor || 1).sort((a, b) => a - b).join(",");
  const shorts = () => pget("flv.short", {}) || {};
  const autoShort = (base, flv) => { const b = String(base).trim().split(/\s+/)[0] || base, seen = new Set(), ls = []; flv.forEach(f => { let l = letterOf(f); if (seen.has(l)) { const t = String(f).trim(); l = (TR[t[0]] || t[0]) + (TR[t[1]] || t[1] || ""); } seen.add(l); ls.push(l); }); return b + " " + ls.join("+"); };

  /* ---------- العائلات ---------- */
  let G = null, SIG = "", VER = 0, GT = 0, GN = -1;
  const bump = () => { VER++; SIG = ""; GT = 0; };
  function groups() {
    const P = PRODS(), c = cfg();
    const now = Date.now(); if (G && now - GT < 400 && P.length === GN) return G;
    let h = 0; for (let i = 0; i < P.length; i++) { const p = P[i]; h = (h * 31 + (+p.id || 0) * 7 + Math.round((+p.price || 0) * 100) + String(p.name || "").length * 13 + (p.active === false ? 1 : 0)) | 0; }
    const sig = VER + ":" + c.on + ":" + P.length + ":" + h; GT = now; GN = P.length;
    if (G && sig === SIG) return G; SIG = sig;
    G = { byId: {}, list: [] }; if (!c.on) return G;
    const by = {};
    P.forEach(p => { if (!p || p.active === false) return; const x = parse(p.name); if (!x.flv.length) return; const k = norm(x.base) + "|" + priceOf(p) + "|" + uSig(p); (by[k] = by[k] || { key: k, base: x.base, bkey: norm(x.base), price: priceOf(p), m: [] }).m.push({ p, flv: x.flv }); });
    const SH = shorts();
    Object.values(by).forEach(g => {
      if (g.m.length < 2) return;
      g.flv = []; g.m.forEach(x => x.flv.forEach(f => { if (!g.flv.some(y => norm(y) === norm(f))) g.flv.push(f); }));
      g.auto = autoShort(g.base, g.flv); g.short = SH[g.bkey] || g.auto;
      G.list.push(g); g.m.forEach(x => { G.byId[x.p.id] = g; });
    });
    return G;
  }
  const whq = p => { try { return window.__flvWhQ0 ? __flvWhQ0(p) : +p.stock || 0; } catch (e) { return +p.stock || 0; } };
  const gStock = g => g.m.reduce((s, x) => s + whq(x.p), 0);
  const rep = g => g.m.slice().sort((a, b) => whq(b.p) - whq(a.p))[0].p;
  const groupOf = id => { const g = groups(); return g.byId[id] || null; };
  function cloneOf(g) { const r = rep(g); const c = Object.assign({}, r, { name: g.short, stock: gStock(g), _flv: g.key, _flvFull: g.base }); return c; }
  /* قائمة أصناف ← عضو واحد لكل عائلة (نسخة باسم مختصر ورصيد مشترك) */
  function collapse(list, withMatch) {
    const g = groups(); if (!g.list.length || !cfg().inv) return list;
    const seen = new Set(), out = [];
    list.forEach(it => { const p = withMatch ? it.p : it; const gr = p && g.byId[p.id]; if (!gr) { out.push(it); return; } if (seen.has(gr.key)) return; seen.add(gr.key); const c = cloneOf(gr); out.push(withMatch ? { p: c, r: Object.assign({}, it.r, { n: [] }) } : c); });
    return out;
  }
  window.__flvCollapse = list => { try { return collapse(list, false); } catch (e) { return list; } };

  /* ---------- الفاتورة ---------- */
  const ROWS = () => { try { return rows; } catch (e) { return []; } };
  const qSum = r => r && r._flvQ ? Object.keys(r._flvQ).reduce((s, k) => s + (+r._flvQ[k] || 0), 0) : 0;
  function qTrim(r, gr) {
    const Q = r._flvQ; Object.keys(Q).forEach(k => { if (!(+Q[k] > 0) || !gr.m.some(x => x.p.id == k)) delete Q[k]; });
    let over = qSum(r) - (+r.qty || 0);
    const order = Object.keys(Q).sort((a, b) => (b == r._flvL) - (a == r._flvL));
    for (const k of order) { if (over <= 1e-9) break; const t = Math.min(Q[k], over); Q[k] -= t; over -= t; if (!(Q[k] > 0)) delete Q[k]; }
    if (!Object.keys(Q).length) { delete r._flvQ; delete r._flvU; delete r._flvL; }
  }
  function normRows() {
    const g = groups(); if (!g.list.length) { ROWS().forEach(r => { if (r && r._grp) { const p = PRODS().find(x => x.id == r.pid); if (p) r.name = p.name; delete r._grp; } }); return; }
    const R = ROWS(), inv = cfg().inv;
    for (let i = 0; i < R.length; i++) {
      const r = R[i]; if (!r || !r.pid) continue;
      const gr = g.byId[r.pid];
      if (!gr) { if (r._grp) { const p = PRODS().find(x => x.id == r.pid); if (p) r.name = p.name; delete r._grp; } continue; }
      r._grp = gr.key;
      /* ذوق محدد (طلبية المتجر) ← كمية ذوق داخل سطر العائلة: كل الأذواق في سطر واحد بدل أسطر كثيرة */
      if (r._flvPin) { r._flvQ = { [r.pid]: +r.qty || 0 }; r._flvU = r.unit; r._flvL = String(r.pid); delete r._flvPin; }
      if (inv) r.name = gr.short;
      /* كميات الأذواق داخل السطر (رقائق): تُلغى إذا تغيّرت الوحدة أو صار مرتجعاً ، وتُقصّ إذا نقصت كمية السطر */
      if (r._flvQ) { if (r._flvU !== r.unit || r.ret) { delete r._flvQ; delete r._flvU; delete r._flvL; } else qTrim(r, gr); }
      const j = R.findIndex((x, k) => k < i && x && !x._flvPin && x._grp === gr.key && x.unit === r.unit && !!x.ret === !!r.ret && Math.abs((+x.price || 0) - (+r.price || 0)) < .005);
      if (j >= 0) { R[j].qty = Math.round(((+R[j].qty || 0) + (+r.qty || 0)) * 1000) / 1000; if (r._flvQ) { const Q = R[j]._flvQ || (R[j]._flvQ = {}); R[j]._flvU = R[j].unit; Object.keys(r._flvQ).forEach(k => { Q[k] = (Q[k] || 0) + r._flvQ[k]; }); } R.splice(i, 1); i--; try { if (sel >= i + 1) sel = j; } catch (e) { } }
    }
  }

  function unhide() { ROWS().forEach(r => { if (r && r.__hp) { r.pid = r.__hp; delete r.__hp; } }); }
  /* ---------- رقائق الأذواق في سطر الفاتورة ----------
     سطر العائلة (مثل «CAPRICE F+D+C») ← رقاقة لكل ذوق برصيده على يسار خانة الاسم:
     سطر واحد للعائلة مهما تعددت الأذواق (بلا اكتظاظ في الفاتورة):
     • بدون اختيار: التوزيع تلقائي عند الحفظ (الأكبر رصيداً أولاً)
     • ضغطة على رقاقة ذوق: +1 من هذا الذوق داخل نفس السطر (C×1 · F+D×1) ، و«−» تنقص واحدة
     • ما لم يُحدَّد ذوقه من كمية السطر ← تلقائي حسب الرصيد */
  const CPAL = ["#e11d48", "#16a34a", "#7c3aed", "#ea580c", "#0891b2", "#ca8a04"];
  function css() {
    if (document.getElementById("flvChipCss")) return;
    const s = document.createElement("style"); s.id = "flvChipCss";
    s.textContent = `#gbody .gr[data-flv]{position:relative}
.flv-rc{position:absolute;top:50%;transform:translateY(-50%);display:flex;gap:3px;direction:ltr;z-index:2;pointer-events:auto}
.flv-rc button{all:unset;box-sizing:border-box;display:inline-flex;align-items:center;gap:3px;height:19px;padding:0 6px 0 4px;border-radius:999px;font:700 10.5px/1 system-ui,Segoe UI,Tahoma,sans-serif;color:#475569;background:#fff;border:1px solid #cbd5e1;cursor:pointer;white-space:nowrap;transition:background .15s,color .15s,border-color .15s,box-shadow .15s}
.flv-rc button i{font-style:normal;display:inline-grid;place-items:center;min-width:14px;height:14px;padding:0 3px;border-radius:999px;background:color-mix(in srgb,var(--c) 14%,#fff);color:var(--c);font-size:9.5px;letter-spacing:.2px}
.flv-rc button em{font-style:normal;font-weight:600;color:#64748b;font-variant-numeric:tabular-nums}
.flv-rc button:hover{border-color:var(--c);box-shadow:0 0 0 2px color-mix(in srgb,var(--c) 18%,transparent)}
.flv-rc button.on{background:var(--c);border-color:var(--c);color:#fff;box-shadow:0 1px 4px color-mix(in srgb,var(--c) 45%,transparent)}
.flv-rc button.on i{background:#fff;color:var(--c)}.flv-rc button.on em{color:#fff}
.flv-rc button.zero:not(.on){opacity:.5}
.flv-rc button b{font-weight:800;font-size:10.5px;font-variant-numeric:tabular-nums}
.flv-rc button s{text-decoration:none;display:inline-grid;place-items:center;width:14px;height:14px;margin-right:-2px;border-radius:50%;background:rgba(255,255,255,.28);font-size:12px;line-height:1;font-weight:800}
.flv-rc button s:hover{background:rgba(255,255,255,.5)}
.flv-rc .au{all:unset;font:600 9.5px/1 system-ui,Segoe UI,Tahoma,sans-serif;color:#94a3b8;align-self:center;padding:0 2px}
body.dark .flv-rc button{background:#1e293b;border-color:#334155;color:#cbd5e1}body.dark .flv-rc button em{color:#94a3b8}`;
    document.head.appendChild(s);
  }
  const fq = n => (Math.round((+n || 0) * 100) / 100).toLocaleString("en-US", { maximumFractionDigits: 2 });
  function chips() {
    const b = document.getElementById("gbody"); if (!b) return;
    const g = groups(); if (!g.list.length) return;
    const R = ROWS(); css();
    b.querySelectorAll(".gr[data-row]").forEach(el => {
      const i = +el.dataset.row, r = R[i]; if (!r || !r.pid || r.ret || r._flvPin) return;
      const gr = g.byId[r.pid]; if (!gr || gr.m.length < 2) return;
      const nm = el.querySelector("input.nm"); if (!nm) return;
      el.setAttribute("data-flv", "1");
      const ms = gr.m.slice().sort((a, b) => (+a.p.id || 0) - (+b.p.id || 0)), Q = r._flvQ || {}, sum = qSum(r), rem = Math.max(0, Math.round(((+r.qty || 0) - sum) * 1000) / 1000);
      const box = document.createElement("span"); box.className = "flv-rc";
      box.innerHTML = ms.map((x, k) => { const n = +Q[x.p.id] || 0, q = whq(x.p), lt = esc(x.flv.map(letterOf).join("+"));
        return `<button type="button" tabindex="-1" class="${n ? "on" : ""}${q <= 0 ? " zero" : ""}" style="--c:${CPAL[k % CPAL.length]}" data-fp="${x.p.id}" title="${esc(x.p.name)} — الرصيد ${fq(q)}\nاضغط: +1 ${esc(r.unit)} من هذا الذوق${n ? "\n− : إنقاص واحدة" : ""}"><i>${lt}</i>${n ? `<b>×${fq(n)}</b><s data-fm="${x.p.id}" title="إنقاص واحدة">−</s>` : `<em>${fq(q)}</em>`}</button>`; }).join("") +
        (sum === 0 ? `<span class="au" title="بدون اختيار: تُوزَّع الكمية على الأذواق حسب الرصيد عند الحفظ">تلقائي</span>` : rem > 0 ? `<span class="au" title="الباقي يُوزَّع حسب الرصيد عند الحفظ">+${fq(rem)} تلقائي</span>` : "");
      box.addEventListener("mousedown", e => { e.preventDefault(); e.stopPropagation(); });
      box.addEventListener("click", e => { const m = e.target.closest("[data-fm]"); if (m) { e.preventDefault(); e.stopPropagation(); step(i, +m.dataset.fm, -1); return; } const t = e.target.closest("[data-fp]"); if (!t) return; e.preventDefault(); e.stopPropagation(); step(i, +t.dataset.fp, 1); });
      el.appendChild(box);
      if (sum) nm.title = ms.filter(x => Q[x.p.id]).map(x => parse(x.p.name).flv.join("+") + " × " + fq(Q[x.p.id])).join("  ·  ") + (rem ? "  ·  تلقائي × " + fq(rem) : "");
      const place = () => { box.style.left = (nm.offsetLeft + 5) + "px"; nm.style.paddingLeft = (box.offsetWidth + 12) + "px"; };
      place(); requestAnimationFrame(place);
    });
  }
  /* ضغطة على رقاقة: +1 من هذا الذوق (كمية السطر تزيد إذا امتلأت) ؛ «−»: −1 من الذوق ومن السطر */
  function step(i, pid, d) {
    const R = ROWS(), r = R[i]; if (!r) return;
    const np = PRODS().find(x => x.id == pid); if (!np) return;
    const Q = r._flvQ || (r._flvQ = {}); r._flvU = r.unit; r._flvL = String(pid);
    const ou = (np._u || []).find(u => u && u.name === r.unit), f = ou ? (+ou.factor || 1) : 1;
    if (d > 0) {
      const sum0 = qSum(r); Q[pid] = (+Q[pid] || 0) + 1;
      if (sum0 + 1 > (+r.qty || 0) + 1e-9) r.qty = Math.round((sum0 + 1) * 1000) / 1000;
      const fl = parse(np.name).flv.join(" + ") || np.name, have = whq(np), need = Q[pid] * f;
      if (need > have + 1e-9) T(fl + " × " + fq(Q[pid]) + " — رصيده " + fq(have) + " فقط", "w"); else T(fl + " × " + fq(Q[pid]), "s");
    } else {
      Q[pid] = (+Q[pid] || 0) - 1; if (!(Q[pid] > 0)) delete Q[pid];
      if ((+r.qty || 0) > 1) r.qty = Math.round(Math.max(qSum(r), (+r.qty || 0) - 1, 1) * 1000) / 1000;
      if (!Object.keys(Q).length) { delete r._flvQ; delete r._flvU; delete r._flvL; }
    }
    try { sel = i; } catch (e) { }
    try { renderRows(); } catch (e) { }
  }
  /* ---------- الطباعة (إيصال / A4 / A5): اسم العائلة + الأذواق وعدد كل ذوق ----------
     • الفاتورة الحالية: من رقائق السطر + التوزيع التلقائي (أو التوزيع المحفوظ نفسه بعد الحفظ)
     • إعادة طباعة فاتورة محفوظة: أسطر الأذواق (نفس العائلة + الوحدة + السعر) تُجمع في سطر واحد */
  const rSig = r => [+r.qty || 0, r.unit || "", JSON.stringify(r._flvQ || {})].join("|");
  const flvLbl = p => parse(p.name).flv.join("+") || p.name;
  function rowParts(r, gr) {
    if (r._flvParts && r._flvParts.sig === rSig(r)) return r._flvParts.l;
    const u0 = (gr.m[0].p._u || []).find(u => u && u.name === r.unit), f = u0 ? (+u0.factor || 1) : 1;
    let left = +r.qty || 0; const parts = [];
    if (r._flvQ) Object.keys(r._flvQ).forEach(k => { const q = Math.min(left, +r._flvQ[k] || 0); if (q > 0 && gr.m.some(x => x.p.id == k)) { parts.push({ pid: +k, q }); left -= q; } });
    gr.m.map(x => ({ p: x.p, av: Math.max(0, whq(x.p) / f - (parts.find(y => y.pid == x.p.id) || { q: 0 }).q) })).sort((a, b) => b.av - a.av).forEach(m => {
      if (left <= 1e-9) return; const take = Math.min(left, Math.floor(m.av * 1000) / 1000); if (take > 0) { const ex = parts.find(y => y.pid == m.p.id); if (ex) ex.q += take; else parts.push({ pid: m.p.id, q: take }); left -= take; } });
    if (left > 1e-9) { if (parts.length) parts[parts.length - 1].q += left; else parts.push({ pid: gr.m[0].p.id, q: left }); }
    return parts;
  }
  window.__flvPrint = function (items) {
    if (!Array.isArray(items)) return items;
    const strip = () => { items.forEach(it => { if (it) delete it._r; }); return items; };
    let g; try { if (!cfg().on) return strip(); g = groups(); } catch (e) { return strip(); }
    if (!g.list.length) return strip();
    const P = PRODS(), byP = id => P.find(x => x.id == id);
    const prodOf = it => { const c = String(it["Item Code"] || ""); return (c && P.find(p => String(p.code) === c)) || P.find(p => p.name === it["Item Name"]) || null; };
    const out = [], seen = {};
    items.forEach(it => {
      if (!it) return;
      if (it._r) {   /* الفاتورة الحالية */
        const r = it._r; delete it._r; const gr = g.byId[r.pid];
        if (gr) { try { it["Item Name"] = gr.base; it._flv = rowParts(r, gr).map(x => { const p = byP(x.pid); return { l: p ? flvLbl(p) : "", q: Math.round(x.q * 1000) / 1000 }; }).filter(x => x.l && x.q > 0); } catch (e) { } }
        out.push(it); return;
      }
      /* فاتورة محفوظة: سطر لكل ذوق ← سطر واحد للعائلة */
      const p = prodOf(it), gr = p && g.byId[p.id];
      if (!gr || !(+it.Qty > 0)) { out.push(it); return; }
      const net = Math.round((+it["Net Price"] || +it.Price || 0) * 100) / 100, k = gr.key + "|" + (it.Unite || "") + "|" + net;
      const fl = { l: flvLbl(p), q: +it.Qty || 0 };
      if (seen[k]) { const m = seen[k]; m.Qty = Math.round((+m.Qty + +it.Qty) * 1000) / 1000; m.Total = Math.round(((+m.Total || 0) + (+it.Total || 0)) * 100) / 100; m["Item Discount"] = (+m["Item Discount"] || 0) + (+it["Item Discount"] || 0);
        const ex = m._flv.find(x => x.l === fl.l); if (ex) ex.q += fl.q; else m._flv.push(fl); return; }
      it["Item Name"] = gr.base; it._flv = [fl]; seen[k] = it; out.push(it);
    });
    return out;
  };
  /* الحفظ: توزيع كمية السطر على أذواق العائلة حسب أرصدتها */
  function split(pay, ret) {
    const g = groups(); if (!g.list.length || !pay || !pay.Items) return pay;
    const vr = ROWS().filter(r => r && r.pid && (+r.qty) > 0), out = [], used = {};
    /* الكميات المحجوزة مسبقاً (ذوق محدد) تُطرح من الرصيد قبل التوزيع */
    pay.Items.forEach((it, i) => { const r = i < vr.length ? vr[i] : null; if (r && r._flvPin && it.Qty > 0) used[it.ProductId] = (used[it.ProductId] || 0) + (+it.Qty) * (+it.UnitFactor || 1);
      if (r && r._flvQ && !ret && it.Qty > 0) Object.keys(r._flvQ).forEach(k => { used[k] = (used[k] || 0) + (+r._flvQ[k] || 0) * (+it.UnitFactor || 1); }); });
    pay.Items.forEach((it, i) => {
      const r = i < vr.length ? vr[i] : null, gr = r && r._grp && g.byId[it.ProductId];
      if (!gr || !(it.Qty > 0) || ret || (r && r._flvPin)) { out.push(it); return; }
      const f = +it.UnitFactor || 1; let left = +it.Qty; const parts = [];
      /* الأذواق المختارة بالرقائق أولاً ، والباقي تلقائي حسب الرصيد */
      if (r && r._flvQ) Object.keys(r._flvQ).forEach(k => { const m = gr.m.find(x => x.p.id == k), q = Math.min(left, +r._flvQ[k] || 0); if (m && q > 0) { parts.push({ p: m.p, q }); left -= q; } });
      const ms = gr.m.map(x => ({ p: x.p, av: Math.max(0, (whq(x.p) - (used[x.p.id] || 0)) / f) })).sort((a, b) => b.av - a.av);
      ms.forEach(m => { if (left <= 1e-9) return; const take = Math.min(left, Math.floor(m.av * 1000) / 1000); if (take > 0) { const ex = parts.find(x => x.p === m.p); if (ex) ex.q += take; else parts.push({ p: m.p, q: take }); left -= take; used[m.p.id] = (used[m.p.id] || 0) + take * f; } });
      if (left > 1e-9) { const p0 = parts.length ? parts[parts.length - 1] : null; if (p0) p0.q += left; else parts.push({ p: ms[0].p, q: left }); }
      if (r) r._flvParts = { sig: rSig(r), l: parts.map(pt => ({ pid: pt.p.id, q: Math.round(pt.q * 1000) / 1000 })) };   /* للطباعة: نفس التوزيع المحفوظ */
      if (parts.length === 1 && parts[0].p.id === it.ProductId) { out.push(it); return; }
      parts.forEach(pt => { const u = (pt.p._u || []).find(x => (+x.factor || 1) === f) || (pt.p._u || [])[0] || {}; const k = pt.q / it.Qty;
        out.push(Object.assign({}, it, { ProductId: pt.p.id, ProductUnitId: u.puid || it.ProductUnitId, Qty: Math.round(pt.q * 1000) / 1000, LineDiscount: Math.round((+it.LineDiscount || 0) * k * 100) / 100, LineTax: Math.round((+it.LineTax || 0) * k * 100) / 100 })); });
    });
    pay.Items = out; return pay;
  }
  function hookSales() {
    if (typeof renderRows === "function" && !renderRows.__flv) { const _rr = renderRows; const w = function () { unhide(); try { normRows(); } catch (e) { } const res = _rr.apply(this, arguments); try { chips(); } catch (e) { } return res; }; w.__flv = 1; window.renderRows = renderRows = w; }
    /* إضافة صنف من العائلة وسطرها الموجود «مختار ذوقه» ← سطر جديد (لا تُزاد كمية الذوق المختار)
       مثال: كرتونة فليو + كرتونة فراز+دلاع = سطران، كل سطر بذوقه */
    if (typeof addProduct === "function" && !addProduct.__flv) { const _ap = addProduct; const w = function (id) { let hid = 0; try { const gr = groupOf(id); if (gr) ROWS().forEach(r => { if (r && r._flvPin && gr.m.some(x => x.p.id == r.pid)) { r.__hp = r.pid; r.pid = 0; hid++; } }); } catch (e) { } try { return _ap.apply(this, arguments); } finally { if (hid) { unhide(); try { renderRows(); } catch (e) { } } } }; w.__flv = 1; window.addProduct = addProduct = w; }
    if (typeof filterProducts === "function" && !filterProducts.__flv) { const _f = filterProducts; const w = function (q, wm) { const l = _f.apply(this, arguments); try { return collapse(l, !!wm); } catch (e) { return l; } }; w.__flv = 1; window.filterProducts = filterProducts = w; }
    /* رصيد العائلة المشترك (المخزن المختار للبيع) */
    if (window.__saleWhQty && !window.__flvWhQ0) { const q0 = window.__saleWhQty; window.__flvWhQ0 = q0; window.__saleWhQty = p => { const g = p && (p._flv ? groups().list.find(x => x.key === p._flv) : groupOf(p.id)); return g && cfg().inv ? g.m.reduce((s, x) => s + (+q0(x.p) || 0), 0) : q0(p); }; }
    if (window.__flvPH) return; window.__flvPH = 1;
    const prevHook = window.__salePayloadHook;
    window.__salePayloadHook = function (pay, ret) { if (prevHook) pay = prevHook(pay, ret) || pay; try { return split(pay, ret); } catch (e) { return pay; } };
  }

  /* ---------- إطار «الأذواق» في بطاقة الصنف ---------- */
  const IC = {
    flv: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21c4.5 0 8-3.6 8-8.2C20 8.4 16.4 5 12 5S4 8.4 4 12.8C4 17.4 7.5 21 12 21z"/><path d="M12 5c0-1.6.8-2.8 2.4-3.4M9 10.5h.01M15 10.5h.01M10 14.5h.01M14.5 15h.01M12 12.5h.01"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M7 7l10 10M17 7L7 17"/></svg>',
    re: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 5v6h-6"/></svg>',
    link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/></svg>',
    unl: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7M4 4l16 16"/></svg>'
  };
  const PAL = ["#e11d48", "#16a34a", "#7c3aed", "#ea580c", "#0891b2", "#ca8a04", "#db2777", "#2563eb"];
  let FR = null;
  function frame() {
    const nm = document.getElementById("itName"), units = document.getElementById("itUnits"); if (!nm || !units) return;
    if (FR && FR.isConnected) return FR;
    const sec = units.closest(".it-sec"); if (!sec) return;
    FR = document.createElement("div"); FR.className = "it-sec flv-sec";
    FR.innerHTML = `<div class="flv-card"><div class="flv-h"><span class="flv-ic">${IC.flv}</span><div class="flv-ht"><b>الأذواق</b><small>الأصناف بنفس الاسم ونفس السعر تُجمع تلقائياً في البيع وتُباع من رصيد مشترك</small></div><span class="flv-st"></span></div>
      <div class="flv-in"><div class="flv-chips"></div><input class="flv-add" placeholder="أضف ذوقاً ثم Enter (مثال: فراز)" autocomplete="off"></div>
      <div class="flv-g">
        <div class="flv-f"><label>الاسم الأساسي</label><b class="flv-base">—</b></div>
        <div class="flv-f"><label>الاسم المختصر في الفواتير</label><span class="flv-sw"><input class="flv-short" spellcheck="false"><button type="button" class="flv-re" title="رجوع للاسم التلقائي">${IC.re}</button></span></div>
      </div>
      <div class="flv-fam"></div>
      <div class="flv-ft"><label class="flv-tg"><input type="checkbox" data-c="on"><i></i>تجميع الأذواق تلقائياً</label><label class="flv-tg"><input type="checkbox" data-c="inv"><i></i>الاسم المختصر في الفواتير</label></div></div>`;
    sec.insertAdjacentElement("afterend", FR);
    const $ = s => FR.querySelector(s), add = $(".flv-add");
    const setName = flv => { const x = parse(nm.value); nm.value = x.base + (flv.length ? "(" + flv.join("+") + ")" : ""); nm.dispatchEvent(new Event("input", { bubbles: true })); draw(); };
    add.addEventListener("keydown", e => {
      if (e.key === "Enter" || e.key === "+" || e.key === "،" || e.key === ",") { e.preventDefault(); e.stopPropagation(); const v = add.value.trim().replace(/[()+]/g, ""); if (!v) return; const x = parse(nm.value); if (!x.flv.some(f => norm(f) === norm(v))) setName(x.flv.concat([v])); add.value = ""; }
      else if (e.key === "Backspace" && !add.value) { const x = parse(nm.value); if (x.flv.length) setName(x.flv.slice(0, -1)); }
    });
    FR.addEventListener("click", e => {
      const d = e.target.closest("[data-del]"); if (d) { const x = parse(nm.value); setName(x.flv.filter((f, i) => i !== +d.dataset.del)); return; }
      const l = e.target.closest("[data-let]"); if (l) { const f = l.dataset.let, inp = document.createElement("input"); inp.className = "flv-li"; inp.value = letterOf(f); inp.maxLength = 3; l.replaceWith(inp); inp.focus(); inp.select();
        const done = ok => { if (ok) setLetter(f, inp.value); draw(); }; inp.addEventListener("keydown", ev => { if (ev.key === "Enter") { ev.preventDefault(); ev.stopPropagation(); done(true); } else if (ev.key === "Escape") { ev.stopPropagation(); done(false); } }); inp.addEventListener("blur", () => done(true)); return; }
      if (e.target.closest(".flv-re")) { const x = parse(nm.value), S = shorts(); delete S[norm(x.base)]; pput("flv.short", S); bump(); draw(); }
    });
    $(".flv-short").addEventListener("change", e => { const x = parse(nm.value), S = shorts(), v = e.target.value.trim(); if (v) S[norm(x.base)] = v; else delete S[norm(x.base)]; pput("flv.short", S); bump(); draw(); T("الاسم المختصر: " + (v || "تلقائي"), "s"); });
    FR.addEventListener("change", e => { const c = e.target.closest("[data-c]"); if (!c) return; const o = cfg(); o[c.dataset.c] = c.checked; pput("flv.cfg", o); bump(); draw(); try { renderRows(); } catch (x) { } });
    let tm = 0; nm.addEventListener("input", () => { clearTimeout(tm); tm = setTimeout(draw, 120); });
    return FR;
  }
  function draw() {
    if (!frame()) return; const nm = document.getElementById("itName"), $ = s => FR.querySelector(s), c = cfg();
    const x = parse(nm.value), price = (() => { const i = FR.closest("#vItem") && document.querySelector('#itUnits .it-gr[data-i="0"] input[data-k="price"]'); return i ? +String(i.value).replace(/[^\d.]/g, "") || 0 : 0; })();
    $(".flv-chips").innerHTML = x.flv.map((f, i) => `<span class="flv-chip" style="--c:${PAL[i % PAL.length]}"><button type="button" class="flv-l" data-let="${esc(f)}" title="حرف الذوق في الاسم المختصر — انقر للتعديل">${esc(letterOf(f))}</button><b>${esc(f)}</b><button type="button" class="flv-x" data-del="${i}" title="حذف">${IC.x}</button></span>`).join("");
    $(".flv-base").textContent = x.base || "—";
    FR.querySelectorAll("[data-c]").forEach(i => { i.checked = !!c[i.dataset.c]; });
    /* العائلة: كل الأصناف بنفس الاسم الأساسي */
    const bk = norm(x.base), meId = (() => { try { return window.ITC && ITC.state && ITC.state.id; } catch (e) { return null; } })();
    const fam = bk && x.flv.length ? PRODS().filter(p => p.active !== false && p.id !== meId && norm(parse(p.name).base) === bk && parse(p.name).flv.length) : [];
    const myPrice = price || (meId ? priceOf(PRODS().find(p => p.id === meId) || {}) : 0);
    const same = fam.filter(p => Math.abs(priceOf(p) - myPrice) < .005);
    const allFlv = x.flv.slice(); same.forEach(p => parse(p.name).flv.forEach(f => { if (!allFlv.some(y => norm(y) === norm(f))) allFlv.push(f); }));
    const sh = shorts()[bk] || autoShort(x.base, allFlv);
    const si = $(".flv-short"); if (document.activeElement !== si) si.value = x.flv.length ? sh : ""; si.disabled = !x.flv.length;
    const st = $(".flv-st");
    if (!x.flv.length) { st.className = "flv-st"; st.textContent = "لا أذواق"; }
    else if (!c.on) { st.className = "flv-st off"; st.textContent = "التجميع متوقف"; }
    else if (same.length) { st.className = "flv-st ok"; st.innerHTML = `${IC.link} مجمّع مع ${same.length} ${same.length > 1 ? "أصناف" : "صنف"}`; }
    else { st.className = "flv-st"; st.innerHTML = fam.length ? `${IC.unl} منفصل — سعر مختلف` : "صنف وحيد"; }
    const tot = same.reduce((s, p) => s + (+p.stock || 0), 0);
    $(".flv-fam").innerHTML = fam.length ? `<div class="flv-fh"><b>أصناف العائلة</b>${same.length ? `<span>الرصيد المشترك مع هذا الصنف: <em>${F(tot)}</em> + رصيده</span>` : ""}</div>
      ${fam.map(p => { const ok = Math.abs(priceOf(p) - myPrice) < .005; return `<div class="flv-m${ok ? " ok" : ""}"><span class="d"></span><span class="n" title="${esc(p.name)}">${esc(p.name)}</span><span class="fl">${parse(p.name).flv.map(f => `<i>${esc(letterOf(f))}</i>`).join("")}</span><span class="p">${F(priceOf(p))}</span><span class="s">${F(p.stock)}</span><span class="t">${ok ? IC.link + "مجمّع" : IC.unl + "سعر مختلف"}</span></div>`; }).join("")}` : (x.flv.length ? `<div class="flv-e">لا توجد أصناف أخرى باسم «${esc(x.base)}» — أضف الأذواق الأخرى كأصناف بنفس الاسم والسعر ليتم تجميعها</div>` : `<div class="flv-e">أضف أذواق هذا الصنف (فراز ، دلاع ، فليو…) — تُكتب في الاسم بين قوسين: ${esc(x.base || "الاسم")}(فراز+دلاع)</div>`);
  }
  function hookItem() {
    if (!document.getElementById("itName")) return;
    frame(); draw();
    if (window.ITC && !ITC.__flv) { ITC.__flv = 1; ["load", "reset"].forEach(k => { const f = ITC[k]; if (typeof f === "function") ITC[k] = function () { const r = f.apply(this, arguments); [60, 500, 1500].forEach(t => setTimeout(draw, t)); return r; }; }); }
    const u = document.getElementById("itUnits"); if (u) u.addEventListener("input", e => { if (e.target.dataset && e.target.dataset.k === "price") { clearTimeout(u.__ft); u.__ft = setTimeout(draw, 200); } });
  }

  /* members: أعضاء عائلة الأذواق لصنف (للخصومات/البونص/خصم الكمية: خصم على ذوق واحد ← يشمل الصنف المجمّع) */
  window.ANOUER_FLV = { parse, groups, groupOf, collapse, letterOf, setLetter, cfg, refresh: () => { bump(); draw(); },
    members: id => { try { const g = groupOf(id); return g ? g.m.map(x => x.p) : null; } catch (e) { return null; } } };
  hookSales(); hookItem();
  window.addEventListener("anouer:catalog", bump);
  window.addEventListener("anouer:props", e => { if (e.detail && /^flv\./.test(e.detail.key)) bump(); });
  setTimeout(() => { if (!window.__flvWhQ0) hookSales(); }, 1500);
})();
