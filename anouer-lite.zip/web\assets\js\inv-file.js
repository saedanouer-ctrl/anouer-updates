/* ANOUER — «ملف الفاتورة» (2026)
   نفس فكرة نافذة DEXEF (الأصناف · سجل التعاملات · المدفوعات · مقارنة العرض · الأرصدة المفتوحة · الاعتمادات · الأرصدة المتاحة · الأرباح)
   لكن ببيانات حقيقية من القاعدة (fm.sale.file) وكل أيقونة تعمل:
   بحث (يحتوي / يبدأ بـ / مطابق) · طريقة العرض (كثافة، صف الفلترة، حفظ التصميم Ctrl+S، الافتراضي) · نسخ · تحديد (العمود / عكس / الكل)
   · تصدير (Excel / Image / Word / PDF / HTML) · اختيار الحقول · عرض للطباعة (داخل البرنامج) · ترتيب بالضغط على رأس العمود.
   يفتح من: أيقونة (i) في مراجعة المبيعات ، «ملف الفاتورة» في القائمة اليمنى ، وأي مكان يستدعي invPop(r). */
(function () {
  "use strict";
  if (window.ANOUER_IF) return;
  const G = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const say = (m, k) => { try { (window.say || window.toast)(m, k || "i"); } catch (e) { console.log(m); } };
  const R2 = v => Math.round((+v || 0) * 100) / 100;
  const N = v => { const n = R2(v); return n.toLocaleString("en-US", { maximumFractionDigits: 2 }); };
  const NQ = v => { const n = Math.round((+v || 0) * 1000) / 1000; return n.toLocaleString("en-US", { maximumFractionDigits: 3 }); };
  const PRODS = () => { try { return window.products || []; } catch (e) { return []; } };
  const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } } };
  const t24 = t => { const m = String(t || "").match(/(\d+):(\d+)(?::(\d+))?\s*(\S*)/); if (!m) return String(t || ""); let h = +m[1]; const pm = /م|pm/i.test(m[4]), am = /ص|am/i.test(m[4]); if (pm && h < 12) h += 12; if (am && h === 12) h = 0; return String(h).padStart(2, "0") + ":" + m[2]; };
  const dPart = s => String(s || "").slice(0, 10), tPart = s => String(s || "").slice(11, 16);
  const isCash = n => !n || /^(تعامل|عميل)?\s*نقد[ىي]$/.test(String(n).trim());

  /* ============================================================ الأيقونات (رسم ANOUER) */
  const I = {
    x: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    srch: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="8.5" cy="8.5" r="5.5"/><path d="M13 13l4.5 4.5"/></svg>',
    dd: '<svg viewBox="0 0 10 10" class="dd"><path d="M2 3.5L5 6.5l3-3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    view: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="2.5" y="3.5" width="15" height="13" rx="2.5"/><path d="M2.5 8h15M8 8v8.5"/></svg>',
    copy: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><rect x="6.5" y="6.5" width="10" height="11" rx="2"/><path d="M13.5 6.5V4.5a2 2 0 0 0-2-2h-6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h1"/></svg>',
    sel: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="2.5" y="2.5" width="15" height="15" rx="3" stroke-dasharray="2.4 2"/><path d="M6.5 10l2.5 2.5 4.5-5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    xl: '<svg viewBox="0 0 20 20"><rect x="7" y="2" width="11" height="16" rx="2" fill="#21a366"/><rect x="2" y="5" width="9" height="10" rx="2" fill="#107c41"/><path d="M4.4 7.4l4.2 5.2M8.6 7.4l-4.2 5.2" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/></svg>',
    cols: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="2.5" y="3" width="15" height="14" rx="2.5"/><path d="M7.5 3v14M12.5 3v14"/></svg>',
    prv: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M4 2.5h8l4 4v11H4z"/><circle cx="9.5" cy="11" r="2.8"/><path d="M11.6 13.1l2.4 2.4" stroke-linecap="round"/></svg>',
    box: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M10 2l7 3.5v9L10 18l-7-3.5v-9z"/><path d="M3 5.5l7 3.5 7-3.5M10 9v9"/></svg>',
    log: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="10" cy="10" r="7.5"/><path d="M10 5.5V10l3 2"/></svg>',
    pay: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="2" y="5" width="16" height="11" rx="2.5"/><circle cx="10" cy="10.5" r="2.4"/><path d="M5 8v5M15 8v5" stroke-linecap="round"/></svg>',
    cmp: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3v14M15 3v14M2.5 7.5L5 5l2.5 2.5M12.5 12.5L15 15l2.5-2.5"/></svg>',
    open: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M2 6h10v8H2zM12 9h3.5L18 11.5V14h-6z"/><circle cx="5.5" cy="15" r="1.6"/><circle cx="14.5" cy="15" r="1.6"/></svg>',
    appr: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M10 2l6.5 2.5v5c0 4-2.8 7-6.5 8.5C6.3 16.5 3.5 13.5 3.5 9.5v-5z"/><path d="M7 10l2 2 4-4" stroke-linecap="round"/></svg>',
    avail: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 15.5h14M5.5 15.5V9M10 15.5V5M14.5 15.5v-4" stroke-linecap="round"/></svg>',
    prof: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 14.5l5-5 3 3 7-7"/><path d="M13 5.5h4.5V10"/></svg>',
    info: '<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="8.5" fill="currentColor"/><circle cx="10" cy="6.2" r="1.3" fill="#fff"/><rect x="9" y="8.6" width="2" height="6.4" rx="1" fill="#fff"/></svg>',
    cash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="2.5" y="6" width="19" height="12" rx="3"/><circle cx="12" cy="12" r="3"/><path d="M6 9.5v5M18 9.5v5" stroke-linecap="round"/></svg>',
    edit: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M4 16l1-4 8.5-8.5 3 3L8 15z"/><path d="M11.5 5.5l3 3"/></svg>',
    prt: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M5 7V2.5h10V7"/><rect x="2" y="7" width="16" height="7" rx="2"/><rect x="5" y="11" width="10" height="6.5" rx="1"/></svg>',
    ret: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M7.5 4L3.5 8l4 4"/><path d="M3.5 8h8a5 5 0 0 1 0 10H9"/></svg>',
    add: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="10" cy="10" r="7.5"/><path d="M10 6.5v7M6.5 10h7"/></svg>',
    ok: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 10.5l3.5 3.5 7.5-8"/></svg>',
    sort: '<svg viewBox="0 0 10 12" class="so"><path d="M5 1.5L8 5H2zM5 10.5L2 7h6z" fill="currentColor"/></svg>',
    filt: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M3 4h14l-5.5 6.5V16l-3-1.5v-4z"/></svg>',
    save: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M4 3h9.5L16.5 6v11H4z"/><path d="M7 3v4h6V3M7 17v-5h6v5"/></svg>',
    reset: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 10a6.5 6.5 0 1 0 2-4.7"/><path d="M3.5 3.5v3h3"/></svg>',
    dens: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 5h14M3 10h14M3 15h14"/></svg>'
  };

  /* ============================================================ الأنماط */
  function css() {
    if (G("ifCss")) return; const st = document.createElement("style"); st.id = "ifCss";
    st.textContent = `
.if-ov [hidden]{display:none!important}
.if-ov{position:fixed;inset:0;z-index:340;background:rgba(15,23,42,.34);backdrop-filter:blur(3px);display:grid;place-items:center;direction:rtl;animation:ifFade .16s ease-out}
@keyframes ifFade{from{opacity:0}}@keyframes ifUp{from{opacity:0;transform:translateY(12px) scale(.985)}}
.if-w{width:min(1240px,94vw);height:min(820px,92vh);background:#f4f7fb;border-radius:22px;box-shadow:0 40px 90px -30px rgba(15,23,42,.55),0 0 0 1px rgba(15,23,42,.06);display:flex;flex-direction:column;overflow:hidden;animation:ifUp .22s cubic-bezier(.2,.9,.3,1.15);font-family:"Segoe UI",Tahoma,Arial,sans-serif;color:#0f172a;outline:0}
.if-hd{position:relative;padding:16px 20px 14px;background:linear-gradient(120deg,#0b3a82 0%,#1d4ed8 55%,#0ea5e9 120%);color:#fff;display:grid;grid-template-columns:auto 1fr auto;gap:18px;align-items:center}
.if-hd:after{content:"";position:absolute;inset:auto 0 0 0;height:1px;background:rgba(255,255,255,.18)}
.if-badge{display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:112px;padding:8px 12px;border-radius:16px;background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.22)}
.if-badge b{font-size:19px;letter-spacing:.2px}.if-badge small{font-size:11px;opacity:.85;margin-top:1px}
.if-w.ret .if-hd{background:linear-gradient(120deg,#7c1d1d 0%,#dc2626 60%,#f97316 120%)}
.if-meta{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px 18px;min-width:0}
.if-meta div{min-width:0}.if-meta small{display:block;font-size:10.5px;opacity:.72;margin-bottom:1px}.if-meta b{display:block;font-size:13.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.if-act{display:flex;gap:6px;align-items:center}
.if-ib{height:36px;min-width:36px;padding:0 10px;border-radius:11px;border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.12);color:#fff;display:inline-flex;align-items:center;gap:6px;font:inherit;font-size:12.5px;font-weight:600;cursor:pointer;transition:background .12s}
.if-ib:hover{background:rgba(255,255,255,.24)}.if-ib svg{width:17px;height:17px}.if-ib.x{padding:0;width:36px;justify-content:center}
.if-kpi{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;padding:12px 20px 0}
.if-k{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:9px 12px;display:flex;flex-direction:column;gap:2px;box-shadow:0 1px 2px rgba(15,23,42,.04)}
.if-k small{font-size:11px;color:#64748b}.if-k b{font-size:17px;font-weight:800;font-variant-numeric:tabular-nums}
.if-k.g b{color:#059669}.if-k.r b{color:#dc2626}.if-k.b b{color:#1d4ed8}.if-k .bar{height:5px;border-radius:9px;background:#e2e8f0;overflow:hidden;margin-top:3px}.if-k .bar i{display:block;height:100%;background:linear-gradient(90deg,#10b981,#34d399);border-radius:9px}
.if-tabs{display:flex;gap:4px;padding:12px 16px 0;overflow-x:auto;scrollbar-width:none}
.if-tab{display:inline-flex;align-items:center;gap:7px;height:38px;padding:0 13px;border-radius:12px 12px 0 0;border:1px solid transparent;border-bottom:0;background:transparent;color:#475569;font:inherit;font-size:13px;font-weight:600;cursor:pointer;white-space:nowrap;position:relative;transition:color .12s,background .12s}
.if-tab svg{width:17px;height:17px}.if-tab:hover{color:#1d4ed8;background:rgba(29,78,216,.06)}
.if-tab.on{background:#fff;border-color:#e2e8f0;color:#1d4ed8;box-shadow:0 -2px 0 #1d4ed8 inset}
.if-tab em{font-style:normal;font-size:10.5px;font-weight:800;min-width:18px;height:18px;padding:0 5px;border-radius:9px;background:#e2e8f0;color:#334155;display:inline-grid;place-items:center}
.if-tab.on em{background:#1d4ed8;color:#fff}.if-tab kbd{display:none}
.if-body{flex:1;min-height:0;margin:0 16px 16px;background:#fff;border:1px solid #e2e8f0;border-radius:0 0 16px 16px;display:flex;flex-direction:column;overflow:hidden}
.if-pane{display:none;flex:1;min-height:0;flex-direction:column}.if-pane.on{display:flex}
.if-tb{display:flex;align-items:center;gap:6px;padding:10px 12px;border-bottom:1px solid #eef2f7;flex-wrap:wrap}
.if-tb .sp{flex:1}
.if-s{position:relative;display:flex;align-items:center;height:36px;width:260px;border:1.5px solid #dbe3ef;border-radius:11px;background:#f8fafc;transition:border-color .12s,box-shadow .12s}
.if-s:focus-within{border-color:#3b82f6;box-shadow:0 0 0 4px rgba(59,130,246,.14);background:#fff}
.if-s>svg{width:17px;height:17px;color:#64748b;margin:0 9px 0 4px;flex:none}
.if-s input{flex:1;min-width:0;border:0;background:transparent;font:inherit;font-size:13px;outline:0;color:#0f172a}
.if-s .clr{width:26px;height:26px;border:0;border-radius:8px;background:transparent;color:#94a3b8;cursor:pointer;display:none;place-items:center}.if-s .clr svg{width:14px;height:14px}.if-s.has .clr{display:grid}
.if-s .mode{height:26px;margin-inline-start:4px;padding:0 7px;border:0;border-inline-start:1px solid #e2e8f0;background:transparent;color:#475569;font:inherit;font-size:11.5px;cursor:pointer;display:flex;align-items:center;gap:3px;border-radius:0 9px 9px 0}
.if-b{height:36px;padding:0 11px;border-radius:11px;border:1px solid #dbe3ef;background:#fff;color:#334155;display:inline-flex;align-items:center;gap:6px;font:inherit;font-size:12.5px;font-weight:600;cursor:pointer;transition:all .12s;position:relative}
.if-b:hover{border-color:#93c5fd;background:#eff6ff;color:#1d4ed8}.if-b:active{transform:translateY(1px)}
.if-b svg{width:17px;height:17px;flex:none}.if-b svg.dd{width:9px;height:9px;opacity:.7}.if-b.ic{padding:0;width:36px;justify-content:center}.if-b.ic.dd2{width:auto;padding:0 8px}
.if-b.on{background:#1d4ed8;border-color:#1d4ed8;color:#fff}
.if-tip{position:fixed;z-index:400;background:#0f172a;color:#fff;font-size:11.5px;padding:5px 9px;border-radius:8px;pointer-events:none;white-space:nowrap;box-shadow:0 8px 20px -8px rgba(0,0,0,.4)}
.if-tip kbd{font:inherit;opacity:.65;margin-inline-start:6px}
.if-mn{position:fixed;z-index:390;min-width:220px;background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 22px 50px -18px rgba(15,23,42,.45);padding:6px;direction:rtl;animation:ifFade .1s;font-family:"Segoe UI",Tahoma,Arial,sans-serif}
.if-mn .mi{display:flex;align-items:center;gap:10px;width:100%;height:36px;padding:0 10px;border:0;border-radius:9px;background:transparent;font:inherit;font-size:13px;color:#0f172a;cursor:pointer;text-align:right}
.if-mn .mi:hover{background:#eff6ff;color:#1d4ed8}.if-mn .mi svg{width:17px;height:17px;flex:none;color:#64748b}.if-mn .mi:hover svg{color:#1d4ed8}
.if-mn .mi kbd{margin-inline-start:auto;font:11px Arial;color:#94a3b8;direction:ltr}.if-mn .mi .ck{margin-inline-start:auto;color:#1d4ed8;width:16px;height:16px}
.if-mn .hr{height:1px;background:#eef2f7;margin:5px 4px}.if-mn .gt{font-size:11px;color:#94a3b8;padding:6px 10px 3px;font-weight:700}
.if-mn label.mi input{width:16px;height:16px;accent-color:#1d4ed8}
.if-g{flex:1;min-height:0;overflow:auto;position:relative}
.if-t{width:100%;border-collapse:separate;border-spacing:0;font-size:13px}
.if-t th{position:sticky;top:0;z-index:2;background:#f1f5fb;color:#334155;font-weight:700;font-size:12px;height:38px;padding:0 10px;text-align:right;border-bottom:1px solid #dbe3ef;white-space:nowrap;cursor:pointer;user-select:none}
.if-t th:hover{background:#e7eef9}.if-t th .so{width:8px;height:10px;opacity:.25;margin-inline-start:5px;vertical-align:-1px}.if-t th.asc .so,.if-t th.desc .so{opacity:1;color:#1d4ed8}
.if-t th.desc .so{transform:rotate(180deg)}.if-t th.csel{background:#dbeafe;color:#1d4ed8}
.if-t th.c,.if-t td.c{text-align:center}.if-t th.n,.if-t td.n{text-align:left;font-variant-numeric:tabular-nums;direction:ltr}
.if-t tr.fr th{top:38px;background:#fbfcfe;height:34px;padding:3px 6px;cursor:default}
.if-t tr.fr input{width:100%;height:27px;border:1px solid #e2e8f0;border-radius:8px;padding:0 7px;font:inherit;font-size:12px;background:#fff;outline:0}.if-t tr.fr input:focus{border-color:#3b82f6}
.if-t td{height:var(--rh,42px);padding:0 10px;border-bottom:1px solid #f1f5f9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:380px}
.if-t tbody tr{cursor:default;transition:background .08s}.if-t tbody tr:hover td{background:#f8fbff}
.if-t tbody tr.cur td{background:#eff6ff}.if-t tbody tr.cur td:first-child{box-shadow:inset -3px 0 0 #1d4ed8}
.if-t tbody tr.sel td{background:#dbeafe}
.if-t td.ix{width:46px;color:#94a3b8;font-size:12px;text-align:center}
.if-t td.ix input,.if-t th.ix input{width:15px;height:15px;accent-color:#1d4ed8;vertical-align:middle;margin:0}
.if-t td.csel{background:#e0ecff!important;color:#1d4ed8;font-weight:700}
.if-t tfoot td{position:sticky;bottom:0;background:#f8fafc;border-top:1.5px solid #dbe3ef;font-weight:800;height:40px;color:#0f172a}
.if-t .gr{color:#059669;font-weight:700}.if-t .rd{color:#dc2626;font-weight:700}.if-t .or{color:#ea580c;font-weight:700}.if-t .mu{color:#64748b}
.if-t .chip{display:inline-flex;align-items:center;gap:5px;height:24px;padding:0 9px;border-radius:999px;font-size:11.5px;font-weight:700;background:#eef2ff;color:#3730a3}
.if-t .chip.add{background:#dcfce7;color:#166534}.if-t .chip.edit{background:#fef3c7;color:#92400e}.if-t .chip.ret{background:#fee2e2;color:#991b1b}.if-t .chip.pay{background:#e0f2fe;color:#075985}
.if-t .ib{width:28px;height:28px;border:0;border-radius:8px;background:transparent;color:#1d4ed8;cursor:pointer;display:inline-grid;place-items:center}.if-t .ib:hover{background:#dbeafe}.if-t .ib svg{width:19px;height:19px}
.if-t .pbar{display:inline-block;width:70px;height:6px;border-radius:9px;background:#fee2e2;vertical-align:middle;margin-inline-end:8px;overflow:hidden}.if-t .pbar i{display:block;height:100%;background:#10b981}
.if-t.dense td{--rh:32px}
.if-sb{display:flex;align-items:center;gap:14px;padding:7px 14px;border-top:1px solid #eef2f7;font-size:11.5px;color:#64748b;background:#fbfcfe}
.if-sb b{color:#0f172a}.if-sb .sp{flex:1}
.if-chips{display:flex;gap:6px}
.if-chips button{height:30px;padding:0 12px;border-radius:999px;border:1px solid #dbe3ef;background:#fff;font:inherit;font-size:12.5px;font-weight:600;color:#475569;cursor:pointer}
.if-chips button.on{background:#1d4ed8;border-color:#1d4ed8;color:#fff}
.if-note{margin:10px 12px 0;padding:9px 12px;border-radius:12px;background:#f0f9ff;border:1px solid #bae6fd;color:#075985;font-size:12.5px;display:flex;gap:8px;align-items:center}.if-note svg{width:17px;height:17px;flex:none}
.if-empty{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:#64748b;text-align:center;padding:30px}
.if-empty .ic{width:74px;height:74px;border-radius:24px;display:grid;place-items:center;background:linear-gradient(135deg,#eff6ff,#e0e7ff);color:#4f46e5}.if-empty .ic svg{width:36px;height:36px}
.if-empty b{font-size:15px;color:#0f172a}.if-empty small{font-size:12.5px;max-width:420px;line-height:1.6}
.if-pays{padding:16px;display:flex;flex-direction:column;gap:12px;overflow:auto}
.if-psum{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
.if-pc{display:flex;align-items:center;gap:14px;padding:12px 14px;border:1px solid #e2e8f0;border-radius:16px;background:#fff;box-shadow:0 1px 2px rgba(15,23,42,.04)}
.if-pc .pi{width:46px;height:46px;border-radius:14px;display:grid;place-items:center;background:linear-gradient(135deg,#1d4ed8,#0ea5e9);color:#fff;flex:none}.if-pc .pi svg{width:24px;height:24px}
.if-pc .pt{flex:1;min-width:0}.if-pc .pt b{display:block;font-size:14px}.if-pc .pt small{display:block;color:#64748b;font-size:12px;margin-top:2px}
.if-pc .pa{font-size:19px;font-weight:800;color:#059669;font-variant-numeric:tabular-nums;direction:ltr}
.if-pc.rem .pi{background:linear-gradient(135deg,#f97316,#ef4444)}.if-pc.rem .pa{color:#dc2626}
.if-load{flex:1;display:grid;place-items:center;color:#64748b;font-size:13px}
.if-load i{width:28px;height:28px;border-radius:50%;border:3px solid #dbeafe;border-top-color:#1d4ed8;animation:ifSp .8s linear infinite;display:block;margin:0 auto 10px}@keyframes ifSp{to{transform:rotate(360deg)}}
.if-src{font-size:11px;padding:2px 8px;border-radius:999px;background:rgba(255,255,255,.18);margin-inline-start:6px;font-weight:600}
@media (max-width:1100px){.if-meta{grid-template-columns:repeat(2,minmax(0,1fr))}.if-kpi{grid-template-columns:repeat(3,1fr)}}`;
    document.head.appendChild(st);
  }

  /* ============================================================ البيانات */
  function whName(id) { try { if (id == null) return "المخزن الرئيسي"; const W = window.ANOUER_WH; return (W && W.nameOf && W.nameOf(id)) || "المخزن الرئيسي"; } catch (e) { return "المخزن الرئيسي"; } }
  function curUser() { try { const sp = Array.from(document.querySelectorAll(".status > span")).find(x => x.textContent.trim() === "المستخدم"); const n = sp && sp.nextElementSibling; return n ? n.textContent.trim() : ""; } catch (e) { return ""; } }
  function brName() { try { const sp = Array.from(document.querySelectorAll(".status > span")).find(x => x.textContent.trim() === "الفرع"); const n = sp && sp.nextElementSibling; return n ? n.textContent.trim() : "الفرع الرئيسي"; } catch (e) { return "الفرع الرئيسي"; } }
  function prodOf(pid, name) { const L = PRODS(); return L.find(p => p.id == pid) || (name ? L.find(p => p.name === name) : null) || null; }

  /* فاتورة محفوظة في القاعدة ← كل شيء من fm.sale.file ؛ غير ذلك (فاتورة محلية/تجريبية) ← ما هو معروف فقط */
  function load(r) {
    const ret = !!r._ret;
    if (r.dbId && HOST()) {
      return Anouer.call("fm.sale.file", { id: r.dbId }).then(d => {
        const h = d.head || {}, rq = {}; (d.retQ || []).forEach(x => { rq[x.pid] = (rq[x.pid] || 0) + (+x.qty || 0); });
        return {
          src: "db", ret: ret || h.type === "SaleReturn",
          head: { no: h.no || r.no, date: dPart(h.date) || r.date, time: tPart(h.date) || t24(r.time), due: dPart(h.due) || dPart(h.date) || r.date, customer: h.customer || r.name || "تعامل نقدى", phone: h.phone || "",
            branch: h.branch || brName(), wh: whName(h.warehouseId), user: h.user || "", treasury: h.treasury || "", notes: h.notes || "", created: h.created || "", updated: h.updated || "", parentNo: h.parentNo || "",
            before: +h.before || 0, disc: +h.disc || 0, extra: +h.extra || 0, tax: +h.tax || 0, total: +h.total || 0, paid: +h.paid || 0, remain: +h.remain || 0, custBalance: h.custBalance },
          lines: (d.lines || []).map(l => ({ pid: l.pid, code: l.code || "", name: l.name || "", unit: l.unit || "", qty: +l.qty || 0, factor: +l.factor || 1, price: +l.price || 0, disc: +l.disc || 0, tax: +l.tax || 0, total: l.total != null ? +l.total : (+l.qty || 0) * (+l.price || 0), cost: l.cost != null ? +l.cost : null, stock: l.stock != null ? +l.stock : null, note: l.note || "" })),
          moves: d.moves || [], pays: d.pays || [], rets: d.rets || [], retQ: rq
        };
      });
    }
    let items = []; try { items = typeof window.srItems === "function" ? window.srItems(r) : (r._items || []); } catch (e) { items = r._items || []; }
    return Promise.resolve(localModel(r, items));
  }
  function localModel(r, items) {
    const ret = !!r._ret;
    const lines = (items || []).map(x => { const p = prodOf(x.pid, x.name); const q = +x.qty || 0, pr = +x.price || 0, c = p && p.cost != null && p.cost !== "" ? +p.cost : null;
      return { pid: x.pid, code: x.code || (p ? p.code : "") || "", name: x.name || (p ? p.name : ""), unit: x.unit || "", qty: q, factor: 1, price: pr, disc: +x.disc || 0, tax: 0, total: x.total != null ? +x.total : q * pr - (+x.disc || 0), cost: c, stock: p && p.stock != null ? +p.stock : null, note: "" }; });
    const tot = +r.total || lines.reduce((a, l) => a + l.total, 0);
    return ({ src: "local", ret,
      head: { no: r.no, date: r.date || "", time: t24(r.time), due: r.date || "", customer: r.name || "تعامل نقدى", phone: "", branch: brName(), wh: whName(null), user: curUser(), treasury: "", notes: "", created: "", updated: "", parentNo: "",
        before: +r.before || tot, disc: +r.disc || 0, extra: 0, tax: +r.tax || 0, total: tot, paid: r.paid != null ? +r.paid : tot, remain: r.rem != null ? +r.rem : Math.max(0, tot - (+r.paid || 0)) },
      lines, moves: [], pays: [], rets: [], retQ: {} });
  }

  /* ============================================================ الشبكة (جدول عام لكل التبويبات) */
  function Grid(host, cfg) {
    const LSK = "anouer.if." + cfg.id;
    const saved = LS.get(LSK, null) || {};
    const st = { rows: [], list: [], q: "", mode: saved.mode || "has", f: {}, hide: Object.assign({}, cfg.hideDef || {}, saved.hide || {}), sort: saved.sort || null, cur: 0, sel: new Set(), csel: null, dense: !!saved.dense, filt: !!saved.filt, pre: null, anchor: null };
    const vis = () => cfg.cols.filter(c => !st.hide[c.k]);
    const raw = (c, x) => { const v = c.v ? c.v(x) : x[c.k]; return v == null ? "" : v; };
    const txt = (c, x) => { const v = raw(c, x); return c.fmt ? c.fmt(v, x) : String(v); };
    const tb = cfg.tb === false ? "" : `<div class="if-tb">
      <div class="if-s"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="8.5" cy="8.5" r="5.5"/><path d="M13 13l4.5 4.5"/></svg><input data-q="1" placeholder="بحث في ${esc(cfg.what || "الأسطر")}…" autocomplete="off" spellcheck="false"><button type="button" class="clr" data-a="qx" data-tip="مسح البحث">${I.x}</button><button type="button" class="mode" data-a="mode" data-tip="طريقة البحث"><span data-k="mode"></span>${I.dd}</button></div>
      <button type="button" class="if-b ic dd2" data-a="view" data-tip="طريقة العرض">${I.view}${I.dd}</button>
      ${cfg.extraTb || ""}
      <span class="sp"></span>
      <button type="button" class="if-b ic" data-a="copy" data-tip="نسخ" data-kb="Ctrl+C">${I.copy}</button>
      <button type="button" class="if-b ic dd2" data-a="sel" data-tip="التحديد">${I.sel}${I.dd}</button>
      <button type="button" class="if-b" data-a="exp" data-tip="تصدير Excel / صورة / Word / PDF">${I.xl}<span>تصدير</span>${I.dd}</button>
      <button type="button" class="if-b" data-a="cols" data-tip="إظهار وإخفاء الأعمدة">${I.cols}<span>إختيار الحقول</span></button>
      <button type="button" class="if-b" data-a="prv" data-tip="معاينة ثم طباعة" data-kb="Ctrl+P">${I.prv}<span>عرض للطباعة</span></button></div>`;
    host.innerHTML = tb + (cfg.top || "") + `<div class="if-g" tabindex="0"><table class="if-t"><thead></thead><tbody></tbody><tfoot></tfoot></table></div><div class="if-sb"><span data-sb="cnt"></span><span data-sb="selc"></span><span class="sp"></span><span data-sb="sb2"></span></div>`;
    const Q = s => host.querySelector(s), T = Q(".if-t"), TH = T.tHead, TB = T.tBodies[0], TF = T.tFoot, GW = Q(".if-g"), QI = Q("[data-q]");
    const MODES = { has: "يحتوي", st: "يبدأ بـ", eq: "مطابق" };
    const match = (v, q) => { v = String(v).toLowerCase(); return st.mode === "eq" ? v === q : st.mode === "st" ? v.startsWith(q) : v.includes(q); };
    function head() {
      const cv = vis();
      TH.innerHTML = `<tr><th class="ix c"><input type="checkbox" data-all="1" title="تحديد الكل (Ctrl+A)"></th>${cv.map(c => `<th data-k="${c.k}" class="${c.n ? "n" : c.c ? "c" : ""}${st.sort && st.sort.k === c.k ? " " + st.sort.d : ""}${st.csel === c.k ? " csel" : ""}" title="ترتيب حسب «${esc(c.t)}»">${esc(c.t)}${I.sort}</th>`).join("")}</tr>`
        + (st.filt ? `<tr class="fr"><th></th>${cv.map(c => `<th><input data-f="${c.k}" value="${esc(st.f[c.k] || "")}" placeholder="${I_F}" autocomplete="off"></th>`).join("")}</tr>` : "");
      T.classList.toggle("dense", st.dense);
      if (Q('[data-k="mode"]')) Q('[data-k="mode"]').textContent = MODES[st.mode];
    }
    const I_F = "تصفية…";
    function body() {
      const cv = vis(), q = st.q.trim().toLowerCase();
      let l = st.rows.filter(x => (!st.pre || st.pre(x)) && (!q || cv.some(c => match(txt(c, x), q))) && cv.every(c => { const f = (st.f[c.k] || "").trim().toLowerCase(); return !f || String(txt(c, x)).toLowerCase().includes(f); }));
      if (st.sort) { const c = cfg.cols.find(z => z.k === st.sort.k); if (c) { const d = st.sort.d === "desc" ? -1 : 1; l = l.slice().sort((a, b) => { const x = raw(c, a), y = raw(c, b); return (typeof x === "number" && typeof y === "number" ? x - y : String(x).localeCompare(String(y), "ar", { numeric: true })) * d; }); } }
      st.list = l; if (st.cur >= l.length) st.cur = Math.max(0, l.length - 1);
      TB.innerHTML = l.map((x, i) => `<tr data-i="${i}" class="${i === st.cur ? "cur" : ""}${st.sel.has(x) ? " sel" : ""}"${cfg.dbl ? ' title="نقرتان: ' + esc(cfg.dblTip || "فتح") + '"' : ""}><td class="ix"><input type="checkbox" data-r="${i}"${st.sel.has(x) ? " checked" : ""}></td>${cv.map(c => { const v = raw(c, x), t = txt(c, x), cl = [c.n ? "n" : c.c ? "c" : "", typeof c.cls === "function" ? c.cls(v, x) : c.cls || "", st.csel === c.k ? "csel" : ""].join(" ").trim();
        return `<td class="${cl}" title="${esc(t)}">${c.h ? c.h(v, x, i) : esc(t)}</td>`; }).join("")}</tr>`).join("")
        || `<tr><td colspan="${cv.length + 1}" style="text-align:center;color:#94a3b8;height:90px">${st.rows.length ? "لا توجد نتائج مطابقة للبحث" : esc(cfg.empty || "لا توجد بيانات")}</td></tr>`;
      if (cfg.foot && l.length) { const ft = cfg.foot(l) || {}; TF.innerHTML = `<tr><td class="ix"></td>${cv.map(c => `<td class="${c.n ? "n" : c.c ? "c" : ""}${ft.cls && ft.cls[c.k] ? " " + ft.cls[c.k] : ""}">${ft[c.k] == null ? "" : esc(ft[c.k])}</td>`).join("")}</tr>`; } else TF.innerHTML = "";
      const all = Q("[data-all]"); if (all) { all.checked = l.length > 0 && l.every(x => st.sel.has(x)); all.indeterminate = !all.checked && l.some(x => st.sel.has(x)); }
      Q('[data-sb="cnt"]').innerHTML = `<b>${l.length}</b> سطر${st.rows.length !== l.length ? " من " + st.rows.length : ""}`;
      Q('[data-sb="selc"]').innerHTML = st.sel.size ? `· محدد <b>${st.sel.size}</b>` + (st.csel ? ` · العمود «${esc((cfg.cols.find(c => c.k === st.csel) || {}).t || "")}»` : "") : st.csel ? `· العمود «${esc((cfg.cols.find(c => c.k === st.csel) || {}).t || "")}» محدد` : "";
      if (cfg.sb) Q('[data-sb="sb2"]').innerHTML = cfg.sb(l) || "";
      if (cfg.after) cfg.after(l);
    }
    function render() { head(); body(); }
    function setCur(i, scroll) { if (!st.list.length) return; st.cur = Math.max(0, Math.min(st.list.length - 1, i)); TB.querySelectorAll("tr[data-i]").forEach(tr => tr.classList.toggle("cur", +tr.dataset.i === st.cur)); if (scroll) { const tr = TB.querySelector("tr.cur"); if (tr) tr.scrollIntoView({ block: "nearest" }); } }
    function save(quiet) { LS.set(LSK, { hide: st.hide, sort: st.sort, dense: st.dense, filt: st.filt, mode: st.mode }); if (!quiet) say("✓ حُفظ تصميم «" + cfg.title + "» — يُستعمل في كل الفواتير", "s"); }
    /* ما يُنسخ/يُصدَّر: الأسطر المحددة (أو كل الأسطر الظاهرة) ، والعمود المحدد فقط إذا حُدد عمود */
    const outRows = () => { const s = st.list.filter(x => st.sel.has(x)); return s.length ? s : st.list; };
    const outCols = () => st.csel ? vis().filter(c => c.k === st.csel) : vis().filter(c => c.t);   /* عمود الأيقونة (i) لا يُطبع ولا يُنسخ */
    function spec() {
      const cs = outCols(), rows = outRows(), ft = cfg.foot && rows.length ? cfg.foot(rows) || {} : null;
      return { title: cfg.title + " — " + (cfg.doc ? cfg.doc() : ""), sub: cfg.sub ? cfg.sub() : "", file: cfg.title + " " + (cfg.docNo ? cfg.docNo() : ""), kpis: cfg.kpis ? cfg.kpis(rows) : null,
        cols: cs.map(c => ({ t: c.t, f: x => txt(c, x), num: !!c.n })), rows, foot: ft ? cs.map(c => ft[c.k] == null ? "" : String(ft[c.k])) : null };
    }
    function copy() {
      const cs = outCols(), rows = outRows(); if (!rows.length) { say("لا توجد أسطر للنسخ", "w"); return; }
      const t = [cs.map(c => c.t).join("\t")].concat(rows.map(x => cs.map(c => String(txt(c, x)).replace(/[\t\n]/g, " ")).join("\t"))).join("\r\n");
      const ok = () => say("✓ نُسخ " + rows.length + " سطر" + (cs.length === 1 ? " من عمود «" + cs[0].t + "»" : "") + " — الصقه في Excel أو أي مكان", "s");
      try { navigator.clipboard.writeText(t).then(ok, () => { fallbackCopy(t); ok(); }); } catch (e) { fallbackCopy(t); ok(); }
    }
    function selAll() { st.list.forEach(x => st.sel.add(x)); body(); }
    function selInv() { st.list.forEach(x => { if (st.sel.has(x)) st.sel.delete(x); else st.sel.add(x); }); body(); }
    function selCol() { const k = st.focusK || (vis()[0] || {}).k; st.csel = st.csel === k ? null : k; if (st.csel) say("حُدد عمود «" + (cfg.cols.find(c => c.k === k) || {}).t + "» — النسخ والتصدير له فقط (اضغط مرة أخرى للإلغاء)", "i"); render(); }
    function menuView(btn) {
      menu(btn, [
        { gt: "الخصائص" },
        { ic: I.dens, t: st.dense ? "عرض مريح (أسطر أوسع)" : "عرض مضغوط (أسطر أكثر)", f: () => { st.dense = !st.dense; render(); } },
        { ic: I.filt, t: st.filt ? "إخفاء صف الفلترة" : "إظهار صف الفلترة تحت العناوين", f: () => { st.filt = !st.filt; if (!st.filt) st.f = {}; render(); } },
        { ic: I.cols, t: "الأعمدة…", f: () => menuCols(btn) },
        { hr: 1 },
        { ic: I.save, t: "حفظ التصميم", kb: "Ctrl+S", f: () => save() },
        { ic: I.reset, t: "التصميم الافتراضي", f: () => { st.hide = Object.assign({}, cfg.hideDef || {}); st.sort = null; st.dense = false; st.filt = false; st.f = {}; st.csel = null; LS.set(LSK, null); render(); say("رجع التصميم الافتراضي", "i"); } }
      ]);
    }
    function menuCols(btn) {
      menu(btn, [{ gt: "الأعمدة الظاهرة" }].concat(cfg.cols.map(c => ({ chk: !st.hide[c.k], t: c.t, keep: 1, f: on => { if (!on && vis().length <= 1) return false; st.hide[c.k] = !on; if (!on && st.csel === c.k) st.csel = null; render(); save(true); return true; } }))));
    }
    function menuSel(btn) {
      menu(btn, [
        { ic: I.cols, t: st.csel ? "إلغاء تحديد العمود" : "تحديد العمود", kb: "Ctrl+Space", f: selCol },
        { ic: I.reset, t: "عكس التحديد", kb: "Ctrl+Shift+Space", f: selInv },
        { ic: I.sel, t: "تحديد الكل", kb: "Ctrl+A", f: selAll },
        { ic: I.x, t: "إلغاء التحديد", kb: "Esc", f: () => { st.sel.clear(); st.csel = null; render(); } }
      ]);
    }
    function menuMode(btn) { menu(btn, Object.keys(MODES).map(k => ({ chk: st.mode === k, radio: 1, t: MODES[k], f: () => { st.mode = k; render(); save(true); } }))); }
    host.addEventListener("click", e => {
      const b = e.target.closest("[data-a]");
      if (b) { const a = b.dataset.a;
        if (a === "qx") { QI.value = ""; st.q = ""; QI.parentNode.classList.remove("has"); body(); QI.focus(); }
        else if (a === "mode") menuMode(b);
        else if (a === "view") menuView(b);
        else if (a === "copy") copy();
        else if (a === "sel") menuSel(b);
        else if (a === "exp") { if (window.ANOUER_LX) ANOUER_LX.menu(b, spec); else say("التصدير غير متاح", "w"); }
        else if (a === "cols") menuCols(b);
        else if (a === "prv") prv();
        else if (cfg.act) cfg.act(a, b, st);
        return; }
      const th = e.target.closest("th[data-k]");
      if (th) { const k = th.dataset.k; st.focusK = k; st.sort = !st.sort || st.sort.k !== k ? { k, d: "asc" } : st.sort.d === "asc" ? { k, d: "desc" } : null; render(); return; }
      const all = e.target.closest("[data-all]"); if (all) { if (all.checked) selAll(); else { st.sel.clear(); body(); } return; }
      const tr = e.target.closest("tr[data-i]"); if (!tr) return;
      const i = +tr.dataset.i, x = st.list[i]; if (!x) return;
      const td = e.target.closest("td"); if (td && td.cellIndex > 0) st.focusK = (vis()[td.cellIndex - 1] || {}).k;
      if (e.target.closest("[data-r]")) { if (st.sel.has(x)) st.sel.delete(x); else st.sel.add(x); st.anchor = i; setCur(i); body(); return; }
      const ib = e.target.closest("[data-ib]"); if (ib && cfg.info) { cfg.info(x, ib); return; }
      if (e.shiftKey && st.anchor != null) { const a = Math.min(st.anchor, i), z = Math.max(st.anchor, i); for (let k = a; k <= z; k++) st.sel.add(st.list[k]); body(); }
      else if (e.ctrlKey) { if (st.sel.has(x)) st.sel.delete(x); else st.sel.add(x); st.anchor = i; body(); }
      else st.anchor = i;
      setCur(i);
    });
    host.addEventListener("dblclick", e => { const tr = e.target.closest("tr[data-i]"); if (tr && cfg.dbl) { const x = st.list[+tr.dataset.i]; if (x) cfg.dbl(x); } });
    host.addEventListener("input", e => {
      if (e.target === QI) { st.q = QI.value; QI.parentNode.classList.toggle("has", !!QI.value); st.cur = 0; body(); return; }
      const f = e.target.closest("[data-f]"); if (f) { st.f[f.dataset.f] = f.value; st.cur = 0; body(); }
    });
    function prv() { if (!window.ANOUER_LX) { say("المعاينة غير متاحة", "w"); return; } ANOUER_LX.preview(spec()); }
    function key(e) {
      const k = e.key, inInput = /INPUT|TEXTAREA|SELECT/.test((e.target && e.target.tagName) || "") && !(e.target.type === "checkbox");
      if (e.ctrlKey && !e.shiftKey && (k === "s" || k === "S" || e.code === "KeyS")) { save(); return true; }
      if (e.ctrlKey && (k === "p" || k === "P" || e.code === "KeyP")) { prv(); return true; }
      if (e.ctrlKey && (k === "f" || k === "F" || e.code === "KeyF") && QI) { QI.focus(); QI.select(); return true; }
      if (inInput) { if (k === "ArrowDown" && e.target === QI) { GW.focus(); return true; } return false; }
      if (e.ctrlKey && e.shiftKey && e.code === "Space") { selInv(); return true; }
      if (e.ctrlKey && e.code === "Space") { selCol(); return true; }
      if (e.ctrlKey && (k === "a" || k === "A" || e.code === "KeyA")) { selAll(); return true; }
      if (e.ctrlKey && (k === "c" || k === "C" || e.code === "KeyC")) { copy(); return true; }
      if (k === "ArrowDown" || k === "ArrowUp") { setCur(st.cur + (k === "ArrowDown" ? 1 : -1), true); if (e.shiftKey) { const x = st.list[st.cur]; if (x) { st.sel.add(x); body(); } } return true; }
      if (k === "Home" || k === "End") { setCur(k === "Home" ? 0 : st.list.length - 1, true); return true; }
      if (k === " " && st.list[st.cur]) { const x = st.list[st.cur]; if (st.sel.has(x)) st.sel.delete(x); else st.sel.add(x); body(); return true; }
      if (k === "Enter" && cfg.dbl && st.list[st.cur]) { cfg.dbl(st.list[st.cur]); return true; }
      if (k === "Escape" && (st.sel.size || st.csel)) { st.sel.clear(); st.csel = null; render(); return true; }
      return false;
    }
    return { set(rows, pre) { st.rows = rows || []; st.pre = pre || null; st.sel.clear(); st.cur = 0; st.q = ""; st.f = {}; st.csel = null; if (QI) { QI.value = ""; QI.parentNode.classList.remove("has"); } render(); return st.list; },
      filter(pre) { st.pre = pre; st.cur = 0; body(); }, key, state: st, refresh: body, focusSearch() { if (QI) QI.focus(); } };
  }
  function fallbackCopy(t) { const a = document.createElement("textarea"); a.value = t; a.style.cssText = "position:fixed;opacity:0"; document.body.appendChild(a); a.select(); try { document.execCommand("copy"); } catch (e) { } a.remove(); }

  /* ============================================================ القوائم المنسدلة + التلميحات */
  let MN = null;
  function closeMenu() { if (MN) { MN.remove(); MN = null; } }
  function menu(btn, items) {
    closeMenu();
    const m = MN = document.createElement("div"); m.className = "if-mn";
    m.innerHTML = items.map((x, i) => x.hr ? '<div class="hr"></div>' : x.gt ? `<div class="gt">${esc(x.gt)}</div>`
      : x.chk != null && !x.radio ? `<label class="mi"><input type="checkbox" data-i="${i}"${x.chk ? " checked" : ""}><span>${esc(x.t)}</span></label>`
      : `<button type="button" class="mi" data-i="${i}">${x.ic || ""}<span>${esc(x.t)}</span>${x.kb ? `<kbd>${esc(x.kb)}</kbd>` : ""}${x.radio && x.chk ? `<span class="ck">${I.ok}</span>` : ""}</button>`).join("");
    document.body.appendChild(m);
    const r = btn.getBoundingClientRect(); m.style.top = Math.min(innerHeight - m.offsetHeight - 8, r.bottom + 6) + "px"; m.style.left = Math.max(8, Math.min(innerWidth - m.offsetWidth - 8, r.right - m.offsetWidth)) + "px";
    m.addEventListener("click", e => { const b = e.target.closest("button[data-i]"); if (!b) return; const x = items[+b.dataset.i]; closeMenu(); if (x && x.f) x.f(); });
    m.addEventListener("change", e => { const c = e.target.closest("input[data-i]"); if (!c) return; const x = items[+c.dataset.i]; if (x && x.f && x.f(c.checked) === false) c.checked = true; });
    setTimeout(() => document.addEventListener("mousedown", function h(e) { if (MN && !MN.contains(e.target)) { closeMenu(); document.removeEventListener("mousedown", h, true); } }, true), 0);
  }
  let TIP = null, tipT = 0;
  function tipOn(e) {
    const b = e.target.closest && e.target.closest("[data-tip]"); if (!b || !UI || !UI.ov.contains(b)) return;
    clearTimeout(tipT); tipT = setTimeout(() => { if (!TIP) { TIP = document.createElement("div"); TIP.className = "if-tip"; document.body.appendChild(TIP); }
      TIP.innerHTML = esc(b.dataset.tip) + (b.dataset.kb ? `<kbd>${esc(b.dataset.kb)}</kbd>` : ""); TIP.style.display = "block";
      const r = b.getBoundingClientRect(); TIP.style.top = (r.top - TIP.offsetHeight - 7) + "px"; TIP.style.left = Math.max(6, Math.min(innerWidth - TIP.offsetWidth - 6, r.left + r.width / 2 - TIP.offsetWidth / 2)) + "px"; }, 380);
  }
  function tipOff(e) { if (e.target.closest && e.target.closest("[data-tip]")) { clearTimeout(tipT); if (TIP) TIP.style.display = "none"; } }

  /* ============================================================ النافذة */
  const TABS = [
    { k: "items", t: "الأصناف", ic: I.box }, { k: "log", t: "سجل التعاملات", ic: I.log }, { k: "pay", t: "المدفوعات", ic: I.pay }, { k: "qct", t: "مقارنة العرض", ic: I.cmp },
    { k: "open", t: "الأرصدة المفتوحة", ic: I.open }, { k: "appr", t: "الاعتمادات", ic: I.appr }, { k: "avail", t: "الأرصدة المتاحة", ic: I.avail }, { k: "prof", t: "الأرباح", ic: I.prof }];
  let UI = null;
  function build() {
    css();
    const ov = document.createElement("div"); ov.className = "if-ov";
    ov.innerHTML = `<div class="if-w" tabindex="-1" role="dialog" aria-modal="true" aria-label="ملف الفاتورة">
      <div class="if-hd"><div class="if-badge"><b data-h="type">مبيعات</b><small data-h="no"></small></div>
        <div class="if-meta"><div><small>العميل</small><b data-h="cust"></b></div><div><small>التاريخ والوقت</small><b data-h="dt"></b></div><div><small>تاريخ الاستحقاق</small><b data-h="due"></b></div><div><small>المستخدم</small><b data-h="user"></b></div>
          <div><small>الفرع</small><b data-h="br"></b></div><div><small>المخزن</small><b data-h="wh"></b></div><div><small>الخزينة</small><b data-h="tr"></b></div><div><small>ملاحظات</small><b data-h="notes"></b></div></div>
        <div class="if-act"><button type="button" class="if-ib" data-a="edit" data-tip="تعديل الفاتورة" data-kb="Ctrl+E">${I.edit}<span>تعديل</span></button><button type="button" class="if-ib" data-a="print" data-tip="طباعة الفاتورة بتصميمها">${I.prt}<span>طباعة</span></button><button type="button" class="if-ib x" data-a="x" data-tip="إغلاق" data-kb="Esc">${I.x}</button></div></div>
      <div class="if-kpi"><div class="if-k b"><small>الإجمالي</small><b data-kp="tot">0</b></div><div class="if-k g"><small>المدفوع</small><b data-kp="paid">0</b><div class="bar"><i data-kp="pbar" style="width:0"></i></div></div><div class="if-k r"><small>الباقي</small><b data-kp="rem">0</b></div><div class="if-k"><small>الأصناف · الكمية</small><b data-kp="cnt">0</b></div><div class="if-k g"><small>الربح</small><b data-kp="prof">—</b></div></div>
      <div class="if-tabs">${TABS.map((t, i) => `<button type="button" class="if-tab${i ? "" : " on"}" data-t="${t.k}" data-tip="${esc(t.t)}" data-kb="Alt+${i + 1}">${t.ic}<span>${esc(t.t)}</span><em data-n="${t.k}" hidden></em></button>`).join("")}</div>
      <div class="if-body">${TABS.map((t, i) => `<div class="if-pane${i ? "" : " on"}" data-p="${t.k}"></div>`).join("")}<div class="if-load" data-k="load" hidden><div><i></i>جارٍ تحميل ملف الفاتورة…</div></div></div></div>`;
    document.body.appendChild(ov);
    const Q = s => ov.querySelector(s), P = k => Q(`.if-pane[data-p="${k}"]`);
    const U = { ov, Q, P, tab: "items", r: null, M: null, grids: {} };
    const doc = () => U.M ? (U.M.ret ? "مرتجع مبيعات رقم " : "فاتورة مبيعات رقم ") + U.M.head.no : "";
    const docNo = () => U.M ? U.M.head.no : "";
    const sub = () => U.M ? [U.M.head.customer, U.M.head.date + " " + U.M.head.time, U.M.head.branch].filter(Boolean).join(" · ") : "";
    const base = { doc, docNo, sub };
    const openItem = x => { const p = prodOf(x.pid, x.name); if (!p) { say("الصنف «" + x.name + "» غير موجود في الأصناف", "w"); return; } close(); try { window.itLoad(p); window.openTab("item", "إضافة صنف", "item"); } catch (e) { say("تعذّر فتح بطاقة الصنف", "e"); } };
    const itemInfo = (x, at) => { const p = prodOf(x.pid, x.name), A = [["الصنف", x.name], ["الكود", x.code || "—"], ["الرصيد الحالي", x.stock != null ? NQ(x.stock) + " " + (x.unit || "") : p ? NQ(p.stock) : "—"], ["سعر البيع الحالي", p ? N(p.price) : "—"], ["التكلفة", x.cost != null ? N(x.cost) : "—"]];
      menu(at, [{ gt: "بيانات الصنف" }].concat(A.map(a => ({ t: a[0] + ": " + a[1] }))).concat([{ hr: 1 }, { ic: I.box, t: "فتح بطاقة الصنف", f: () => openItem(x) }])); };

    /* الأصناف */
    U.grids.items = Grid(P("items"), Object.assign({ id: "items", title: "أصناف الفاتورة", what: "الأصناف", dbl: openItem, dblTip: "فتح بطاقة الصنف", info: itemInfo, empty: "لا توجد أصناف في هذه الفاتورة",
      hideDef: { disc: 1, tax: 1, stock: 1, note: 1 },
      cols: [{ k: "code", t: "الكود" }, { k: "name", t: "اسم الصنف" }, { k: "qty", t: "الكمية", n: 1, fmt: NQ }, { k: "unit", t: "الوحدة", c: 1 }, { k: "price", t: "السعر", n: 1, fmt: N }, { k: "disc", t: "الخصم", n: 1, fmt: N },
        { k: "tax", t: "الضريبة", n: 1, fmt: N }, { k: "total", t: "اجمالي", n: 1, fmt: N, cls: "gr" }, { k: "stock", t: "الرصيد الحالي", n: 1, fmt: v => v === "" ? "—" : NQ(v) }, { k: "note", t: "ملاحظة" },
        { k: "i", t: "", c: 1, v: () => "", h: () => `<button type="button" class="ib" data-ib="1" title="بيانات الصنف">${I.info}</button>` }],
      foot: l => ({ qty: NQ(l.reduce((a, x) => a + x.qty, 0)), total: N(l.reduce((a, x) => a + x.total, 0)), disc: N(l.reduce((a, x) => a + x.disc, 0)), name: l.length + " صنف" }),
      kpis: l => [["عدد الأصناف", l.length], ["الكمية", NQ(l.reduce((a, x) => a + x.qty, 0))], ["الإجمالي", N(l.reduce((a, x) => a + x.total, 0))]] }, base));

    /* سجل التعاملات */
    U.grids.log = Grid(P("log"), Object.assign({ id: "log", title: "سجل التعاملات", what: "السجل", empty: "لا توجد حركات", dbl: x => { if (x.open) x.open(); }, dblTip: "فتح المستند",
      cols: [{ k: "act", t: "التعامل", h: (v, x) => `<span class="chip ${x.cls || ""}">${esc(v)}</span>` }, { k: "ref", t: "رقم المرجع", c: 1 }, { k: "date", t: "التاريخ", c: 1 }, { k: "time", t: "الوقت", c: 1 }, { k: "user", t: "المستخدم" },
        { k: "party", t: "الجهة" }, { k: "note", t: "الملاحظات" }, { k: "cnt", t: "عدد الأصناف", n: 1 }, { k: "val", t: "قيمة التعامل", n: 1, fmt: N }] }, base));

    /* الأرصدة المفتوحة */
    U.grids.open = Grid(P("open"), Object.assign({ id: "open", title: "الأرصدة المفتوحة", what: "الأصناف", dbl: openItem, dblTip: "فتح بطاقة الصنف",
      top: `<div class="if-note">${I.open}<span>ANOUER يصرف البضاعة من المخزن عند حفظ الفاتورة، فالمرسل = المطلوب ولا يبقى رصيد مفتوح.</span><span style="flex:1"></span><div class="if-chips"><button type="button" data-oc="all" class="on">الكل (<b data-on="all">0</b>)</button><button type="button" data-oc="open">مفتوح (<b data-on="open">0</b>)</button></div></div>`,
      cols: [{ k: "code", t: "الرقم" }, { k: "name", t: "الاسم" }, { k: "req", t: "المطلوب", n: 1, fmt: NQ }, { k: "sent", t: "المرسل", n: 1, fmt: NQ, cls: "gr" }, { k: "rem", t: "الباقي", n: 1, fmt: NQ, cls: v => v > 0 ? "or" : "mu" }, { k: "unit", t: "الوحدة", c: 1 },
        { k: "st", t: "الحالة", c: 1, h: (v, x) => x.rem > 0 ? '<span class="chip edit">مفتوح</span>' : '<span class="chip add">مُسلَّم</span>' }],
      foot: l => ({ req: NQ(l.reduce((a, x) => a + x.req, 0)), sent: NQ(l.reduce((a, x) => a + x.sent, 0)), rem: NQ(l.reduce((a, x) => a + x.rem, 0)) }) }, base));
    P("open").addEventListener("click", e => { const b = e.target.closest("[data-oc]"); if (!b) return; P("open").querySelectorAll("[data-oc]").forEach(x => x.classList.toggle("on", x === b)); U.grids.open.filter(b.dataset.oc === "open" ? x => x.rem > 0 : null); });

    /* الأرصدة المتاحة (الكمية − المرتجع) */
    U.grids.avail = Grid(P("avail"), Object.assign({ id: "avail", title: "الأرصدة المتاحة للإرجاع", what: "الأصناف", dbl: openItem, dblTip: "فتح بطاقة الصنف", info: itemInfo,
      cols: [{ k: "code", t: "الرقم" }, { k: "name", t: "الاسم" }, { k: "qty", t: "الكمية", n: 1, fmt: NQ }, { k: "unit", t: "الوحدة", c: 1 }, { k: "ret", t: "المرتجع", n: 1, fmt: NQ, cls: v => v > 0 ? "rd" : "mu" },
        { k: "bal", t: "الرصيد المتاح", n: 1, fmt: NQ, cls: "gr", h: (v, x) => `<span class="pbar"><i style="width:${x.qty ? Math.max(0, Math.min(100, v / x.qty * 100)) : 0}%"></i></span>${esc(NQ(v))}` },
        { k: "i", t: "", c: 1, v: () => "", h: () => `<button type="button" class="ib" data-ib="1" title="بيانات الصنف">${I.info}</button>` }],
      foot: l => ({ qty: NQ(l.reduce((a, x) => a + x.qty, 0)), ret: NQ(l.reduce((a, x) => a + x.ret, 0)), bal: NQ(l.reduce((a, x) => a + x.bal, 0)) }) }, base));

    /* الأرباح */
    U.grids.prof = Grid(P("prof"), Object.assign({ id: "prof", title: "أرباح الفاتورة", what: "الأصناف", dbl: openItem, dblTip: "فتح بطاقة الصنف",
      cols: [{ k: "code", t: "الرقم" }, { k: "name", t: "الاسم" }, { k: "qty", t: "الكمية", n: 1, fmt: NQ }, { k: "unit", t: "الوحدة", c: 1 }, { k: "net", t: "صافى السعر", n: 1, fmt: N }, { k: "cost", t: "التكلفة", n: 1, fmt: v => v === "" ? "—" : N(v) },
        { k: "pl", t: "الربح أو الخسارة", n: 1, fmt: v => v === "" ? "—" : N(v), cls: v => v === "" ? "mu" : v < 0 ? "rd" : "gr" }, { k: "mg", t: "الهامش %", n: 1, fmt: v => v === "" ? "—" : R2(v) + "%", cls: v => v === "" ? "mu" : v < 0 ? "rd" : "" }],
      foot: l => { const s = l.reduce((a, x) => a + (x.pl === "" ? 0 : x.pl), 0), sv = l.reduce((a, x) => a + x.net * x.qty, 0); return { pl: N(s), net: N(sv), mg: sv ? R2(s / sv * 100) + "%" : "", cls: { pl: s < 0 ? "rd" : "gr" } }; },
      kpis: l => { const s = l.reduce((a, x) => a + (x.pl === "" ? 0 : x.pl), 0), sv = l.reduce((a, x) => a + x.net * x.qty, 0); return [["المبيعات الصافية", N(sv)], ["الربح", N(s), s < 0 ? "r" : "g"], ["الهامش", sv ? R2(s / sv * 100) + "%" : "—"]]; },
      sb: () => U.M && U.M.src === "db" ? "التكلفة = تكلفة الصنف الحالية في بطاقته" : "" }, base));

    ov.addEventListener("click", e => {
      const t = e.target.closest(".if-tab"); if (t) { setTab(t.dataset.t); return; }
      const b = e.target.closest(".if-hd [data-a]"); if (!b) return;
      const a = b.dataset.a, r = U.r;
      if (a === "x") close();
      else if (a === "edit") { close(); try { (window.__srEdit || window.srEdit)(r); } catch (x) { say("تعذّر فتح التعديل", "e"); } }
      else if (a === "print") { try { if (window.__rdSrPrint) window.__rdSrPrint(r, "preview"); else window.srPrint(r, "preview"); } catch (x) { say("تعذّرت الطباعة", "e"); } }
    });
    ov.addEventListener("mousedown", e => { if (e.target === ov) close(); });
    ov.addEventListener("contextmenu", e => e.stopPropagation());
    ov.addEventListener("mouseover", tipOn); ov.addEventListener("mouseout", tipOff);
    function setTab(k) { U.tab = k; ov.querySelectorAll(".if-tab").forEach(x => x.classList.toggle("on", x.dataset.t === k)); ov.querySelectorAll(".if-pane").forEach(x => x.classList.toggle("on", x.dataset.p === k)); closeMenu(); }
    U.setTab = setTab;
    return U;
  }

  /* ============================================================ تعبئة التبويبات */
  function fill(U, M) {
    const h = M.head, Q = U.Q, set = (k, v) => { const el = Q(`[data-h="${k}"]`); el.textContent = v || "—"; el.title = v || ""; };
    U.ov.querySelector(".if-w").classList.toggle("ret", !!M.ret);
    U.Q('.if-hd [data-a="edit"]').hidden = !!M.ret;   /* المرتجع المحفوظ لا يُعدَّل */
    set("type", M.ret ? "مرتجع" : "مبيعات"); Q('[data-h="no"]').textContent = "# " + h.no;
    set("cust", h.customer + (h.phone ? " · " + h.phone : "")); set("dt", h.date + "  " + h.time); set("due", h.due); set("user", h.user); set("br", h.branch); set("wh", h.wh); set("tr", h.treasury); set("notes", h.notes);
    const L = M.lines, qty = L.reduce((a, l) => a + l.qty, 0);
    /* الأرباح: صافي السعر = (إجمالي السطر ÷ الكمية) بعد توزيع خصم الفاتورة بنسبة السطر */
    const lt = L.reduce((a, l) => a + l.total, 0), k = lt > 0 && h.disc > 0 && Math.abs(h.before - lt) < 1 ? (lt - h.disc) / lt : 1;
    const prof = L.map(l => { const net = l.qty ? R2(l.total / l.qty * k) : 0, has = l.cost != null && isFinite(l.cost) && l.cost > 0; const pl = has ? R2((net - l.cost) * l.qty) : "";
      return { pid: l.pid, code: l.code, name: l.name, qty: l.qty, unit: l.unit, net, cost: has ? R2(l.cost) : "", pl, mg: has && net ? (net - l.cost) / net * 100 : "" }; });
    const plT = prof.reduce((a, x) => a + (x.pl === "" ? 0 : x.pl), 0), plKnown = prof.some(x => x.pl !== "");
    const kp = (k2, v) => { const el = Q(`[data-kp="${k2}"]`); if (el) el.textContent = v; };
    kp("tot", N(h.total)); kp("paid", N(h.paid)); kp("rem", N(h.remain)); kp("cnt", L.length + " · " + NQ(qty)); kp("prof", plKnown ? (M.ret ? "−" : "") + N(plT) : "—");
    Q('[data-kp="pbar"]').style.width = (h.total > 0 ? Math.max(0, Math.min(100, h.paid / h.total * 100)) : 100) + "%";
    Q('[data-kp="prof"]').parentNode.classList.toggle("r", plT < 0); Q('[data-kp="prof"]').parentNode.classList.toggle("g", plT >= 0);
    const cnt = (k2, n) => { const e = Q(`[data-n="${k2}"]`); if (!e) return; e.hidden = !n; e.textContent = n; };

    U.grids.items.set(L.map(l => Object.assign({}, l)));
    cnt("items", L.length);

    /* السجل: الإضافة ، إعادة الحفظ (تعديل) ، التحصيلات اللاحقة ، المرتجعات */
    const log = [], cust = h.customer || "تعامل نقدى";
    log.push({ act: M.ret ? "إضافة مرتجع" : "إضافة", cls: "add", ref: h.parentNo || "—", date: h.date, time: h.time, user: h.user || "—", party: cust, note: h.parentNo ? "مرتجع من الفاتورة " + h.parentNo : "", cnt: L.length, val: h.total, ts: h.date + " " + h.time });
    if (h.created) { const c = new Date(h.created.replace(" ", "T")), d = new Date((h.date + "T" + (h.time || "00:00")).trim()); if (isFinite(c) && isFinite(d) && c - d > 3 * 60000) log.push({ act: "تعديل", cls: "edit", ref: "—", date: dPart(h.created), time: tPart(h.created), user: h.user || "—", party: cust, note: "أُعيد حفظ الفاتورة بعد تعديلها", cnt: L.length, val: h.total, ts: h.created }); }
    if (h.updated) log.push({ act: "تحديث", cls: "edit", ref: "—", date: dPart(h.updated), time: tPart(h.updated), user: "—", party: cust, note: "تحديث بيانات الفاتورة", cnt: L.length, val: h.total, ts: h.updated });
    (M.pays || []).forEach(p => { const d = new Date(String(p.at).replace(" ", "T")), d0 = new Date((h.date + "T" + (h.time || "00:00")).trim()); if (isFinite(d) && isFinite(d0) && d - d0 > 3 * 60000) log.push({ act: "تحصيل", cls: "pay", ref: "—", date: dPart(p.at), time: tPart(p.at), user: p.user || "—", party: cust, note: p.method || "", cnt: 0, val: +p.amount || 0, ts: p.at }); });
    (M.rets || []).forEach(x => log.push({ act: "مرتجع", cls: "ret", ref: x.no, date: dPart(x.at), time: tPart(x.at), user: x.user || "—", party: cust, note: "مرتجع مبيعات رقم " + x.no, cnt: x.cnt || 0, val: +x.total || 0, ts: x.at,
      open: () => { try { if (window.ANOUER_OPEN && ANOUER_OPEN.popSale) ANOUER_OPEN.popSale({ id: x.id, no: x.no, date: dPart(x.at), time: tPart(x.at), total: +x.total || 0, paid: +x.total || 0 }, 1); else say("افتح «مراجعة مرتجع المبيعات» للمرتجع رقم " + x.no, "i"); } catch (e) { say("المرتجع رقم " + x.no, "i"); } } }));
    log.sort((a, b) => String(a.ts).localeCompare(String(b.ts)));
    U.grids.log.set(log); cnt("log", log.length);

    /* المدفوعات */
    const pp = U.P("pay"), mv = M.moves || [], py = M.pays || [];
    let cards = mv.map(m => ({ t: m.treasury || "الخزينة", s: [m.user, "حركة خزينة"].filter(Boolean).join(" · "), at: m.at, a: +m.amount || 0 }));
    if (!cards.length) cards = py.map(p => ({ t: p.method || "دفعة", s: [p.user, p.note].filter(Boolean).join(" · "), at: p.at, a: +p.amount || 0 }));
    if (!cards.length && h.paid > 0) cards = [{ t: h.treasury || "الخزينة الرئيسية", s: M.src === "db" ? "مدفوع عند الحفظ" : "مدفوع نقداً", at: h.date + " " + h.time, a: h.paid }];
    pp.innerHTML = `<div class="if-pays"><div class="if-psum"><div class="if-pc"><div class="pi">${I.cash}</div><div class="pt"><b>الإجمالي</b><small>${esc(cust)}</small></div><div class="pa" style="color:#1d4ed8">${N(h.total)}</div></div>
      <div class="if-pc"><div class="pi">${I.ok}</div><div class="pt"><b>المدفوع</b><small>${cards.length} دفعة</small></div><div class="pa">${N(h.paid)}</div></div>
      <div class="if-pc rem"><div class="pi">${I.log}</div><div class="pt"><b>الباقي</b><small>${h.remain > 0 ? (isCash(cust) ? "على تعامل نقدي" : "على حساب العميل") : "مسددة بالكامل ✓"}</small></div><div class="pa">${N(h.remain)}</div></div></div>
      ${cards.length ? cards.map(c => `<div class="if-pc"><div class="pi">${I.cash}</div><div class="pt"><b>${esc(c.t)}</b><small>${esc(dPart(c.at))} ${esc(tPart(c.at))}${c.s ? " · " + esc(c.s) : ""}</small></div><div class="pa">${N(c.a)}</div></div>`).join("")
        : `<div class="if-empty"><div class="ic">${I.pay}</div><b>لا توجد مدفوعات</b><small>الفاتورة آجلة بالكامل — الباقي ${N(h.remain)} على حساب العميل.</small></div>`}</div>`;
    cnt("pay", cards.length);

    /* مقارنة العرض */
    U.P("qct").innerHTML = `<div class="if-empty"><div class="ic">${I.cmp}</div><b>لا يوجد عرض سعر مرتبط</b><small>هذه الفاتورة لم تُحوَّل من «عرض سعر / فاتورة أولية»، فلا توجد أسعار عرض لمقارنتها. عند تحويل عرض سعر إلى فاتورة تظهر هنا الفروق في الكميات والأسعار.</small></div>`;

    /* الأرصدة المفتوحة + المتاحة (بالمرتجعات المرتبطة) */
    const used = {}; const retOf = l => { const base = M.retQ[l.pid] || 0; if (!base) return 0; const left = base - (used[l.pid] || 0); const q = Math.max(0, Math.min(l.qty * l.factor, left)); used[l.pid] = (used[l.pid] || 0) + q; return R2(q / (l.factor || 1)); };
    const av = L.map(l => { const r = retOf(l); return { pid: l.pid, code: l.code, name: l.name, qty: l.qty, unit: l.unit, ret: r, bal: R2(l.qty - r), stock: l.stock, cost: l.cost }; });
    const op = av.map(x => ({ pid: x.pid, code: x.code, name: x.name, req: x.qty, sent: M.ret ? x.qty : x.qty, rem: 0, unit: x.unit }));
    U.grids.open.set(op); const OP = U.P("open"); OP.querySelectorAll("[data-oc]").forEach(x => x.classList.toggle("on", x.dataset.oc === "all"));
    OP.querySelector('[data-on="all"]').textContent = op.length; OP.querySelector('[data-on="open"]').textContent = op.filter(x => x.rem > 0).length;
    U.grids.avail.set(av); cnt("avail", (M.rets || []).length || 0);

    /* الاعتمادات */
    U.P("appr").innerHTML = `<div class="if-empty"><div class="ic">${I.appr}</div><b>لا توجد اعتمادات</b><small>هذه الفاتورة لم تحتج موافقة أي مستخدم. الاعتمادات تظهر هنا عندما تتطلب صلاحيات الكاشير موافقة المدير (خصم أكبر من المسموح، بيع بأقل من التكلفة، تعديل أو حذف).</small></div>`;

    U.grids.prof.set(prof);
  }

  /* ============================================================ فتح / إغلاق */
  function key(e) {
    const U = UI; if (!U) return;
    if (MN && e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); closeMenu(); return; }
    if (document.querySelector(".lx-ov")) return;   /* معاينة الطباعة فوقها */
    if (e.key === "Escape" && document.querySelector(".lx-menu")) { e.preventDefault(); e.stopImmediatePropagation(); document.body.dispatchEvent(new MouseEvent("mousedown", { bubbles: true })); return; }
    if (e.altKey && /^[1-8]$/.test(e.key)) { e.preventDefault(); e.stopImmediatePropagation(); U.setTab(TABS[+e.key - 1].k); return; }
    if (e.ctrlKey && (e.key === "e" || e.key === "E" || e.code === "KeyE")) { e.preventDefault(); e.stopImmediatePropagation(); U.Q('.if-hd [data-a="edit"]').click(); return; }
    const g = U.grids[U.tab];
    if (g && g.key(e)) { e.preventDefault(); e.stopImmediatePropagation(); return; }
    if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); close(); return; }
    if (e.ctrlKey && /^(KeyS|KeyP|KeyA|KeyC|KeyD|KeyN)$/.test(e.code) && !/INPUT|TEXTAREA/.test(e.target.tagName)) { e.preventDefault(); e.stopImmediatePropagation(); }
  }
  function open(r) {
    if (!r) return;
    if (!UI) UI = build();
    const U = UI; U.r = r; U.M = null;
    U.ov.style.display = ""; if (!U.ov.isConnected) document.body.appendChild(U.ov);
    U.setTab("items");
    const ld = U.Q('[data-k="load"]'); ld.hidden = false; U.ov.querySelectorAll(".if-pane").forEach(p => p.style.visibility = "hidden");
    document.removeEventListener("keydown", key, true); document.addEventListener("keydown", key, true);
    load(r).then(M => { if (UI !== U || U.r !== r) return; U.M = M; fill(U, M); })
      .catch(err => { say("تعذّر تحميل ملف الفاتورة كاملاً — " + ((err && err.message) || err) + " — عرض البيانات المتوفرة", "w");
        /* فاتورة من القاعدة: أصنافها الحقيقية فقط (لا بنود تجريبية) */
        const lp = r.dbId && typeof window.srLoadReal === "function" ? window.srLoadReal(r).catch(() => r._items || []) : Promise.resolve(r._items || []);
        return lp.then(items => { if (UI === U && U.r === r) { U.M = localModel(r, items || []); fill(U, U.M); } }); })
      .then(() => { ld.hidden = true; U.ov.querySelectorAll(".if-pane").forEach(p => p.style.visibility = ""); try { U.Q(".if-w").focus({ preventScroll: true }); } catch (e) { } });
  }
  function close() {
    const U = UI; if (!U) return; closeMenu(); if (TIP) TIP.style.display = "none";
    U.ov.style.display = "none"; document.removeEventListener("keydown", key, true);
  }
  window.ANOUER_IF = { open, close, load };
  /* يحل محل النافذة القديمة: أيقونة (i) + «ملف الفاتورة» + أي مستدعٍ لـ invPop */
  window.invPop = open;
  window.srFile = open;
})();
