/* ANOUER — «نقاط الولاء» (الإضافات ← 3-الخدمات) — مفعّلة — 2026
   حسب وصف DEXEF: «وسيلة لتكريم العملاء الأوفياء، وذلك بإعطائهم نقاط على كل عملية شراء يقومون بها، ويتم تحويل هذه النقاط الى خصومات»
   ─ الاكتساب: كل X دج من إجمالي الفاتورة (أو المدفوع) = 1 نقطة × مضاعف مستوى العضوية (برونزي / فضي / ذهبي)
   ─ الاستبدال (F8 «إستبدال النقاط»): النقطة = Y دج خصم ، بحد أدنى للنقاط وحد أقصى (نسبة من الفاتورة)
   ─ المرتجع يسحب النقاط المكتسبة ، «تحويل الباقى الى نقاط» يُضاف للرصيد ، صلاحية اختيارية للنقاط (FIFO)
   ─ «مركز نقاط الولاء»: التفعيل والقواعد والمستويات ، أرصدة العملاء ، سجل الحركات ، تعديل يدوي
   التخزين: الخصائص (Props) في قاعدة ANOUER ← loy.cfg (القواعد) و loy.book (سجل الحركات) */
(function () {
  "use strict";
  if (window.__LOY) return;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const N = n => (Math.round((+n || 0) * 100) / 100).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const T = (m, k) => { try { toast(m, k || "i"); } catch (e) { } };
  const PR = () => window.ANOUER_PROPS;
  const HOST = () => !!(window.Anouer && Anouer.available);
  const ADD_DEF = ["disc", "qdisc", "bonus", "extra"];
  const DEF = {
    earnPer: 100, base: "total", val: 1, minRedeem: 10, maxPct: 50, expDays: 0, welcome: 0, round: "floor",
    tiers: [{ n: "برونزي", min: 0, x: 1, c: "#c2410c" }, { n: "فضي", min: 1000, x: 1.25, c: "#64748b" }, { n: "ذهبي", min: 5000, x: 1.5, c: "#ca8a04" }]
  };
  const cfg = () => { const c = Object.assign({}, DEF, (PR() && PR().get("loy.cfg", {})) || {}); if (!Array.isArray(c.tiers) || !c.tiers.length) c.tiers = DEF.tiers; return c; };
  const enList = () => { try { return (PR() && PR().get("add.enabled", ADD_DEF)) || ADD_DEF; } catch (e) { return ADD_DEF; } };
  const on = () => enList().indexOf("loyal") >= 0 && (!(window.ANOUER_EDITION || {}).dist || !window.ANOUER_LIC || ANOUER_LIC.ok("loyal"));   /* نسخة العملاء: تجربة شهر أو كود تفعيل */
  function setOn(v) { const l = enList().slice(), i = l.indexOf("loyal"); if (v && i < 0) l.push("loyal"); if (!v && i >= 0) l.splice(i, 1); return PR() ? PR().put("add.enabled", l) : Promise.resolve(); }
  const book = () => { const b = (PR() && PR().get("loy.book", null)) || {}; b.tx = Array.isArray(b.tx) ? b.tx : []; return b; };
  const saveBook = b => { if (b.tx.length > 20000) b.tx = b.tx.slice(-20000); return PR() ? PR().put("loy.book", b) : Promise.resolve(); };
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const nowIso = () => { const d = new Date(), p = n => String(n).padStart(2, "0"); return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " + p(d.getHours()) + ":" + p(d.getMinutes()); };
  const ROUND = (x, c) => (c || cfg()).round === "round" ? Math.round(x) : Math.floor(x + 1e-9);

  /* ---------------- العميل ---------------- */
  const CUST = () => window.CUSTOMERS_DATA || [];
  const keyOf = c => c ? (c.id ? "c" + c.id : "n:" + c.name) : null;
  function custNow() {
    const nm = (($("custName") || {}).value || "").trim(); if (!nm || nm === "تعامل نقدى" || nm === "تعامل نقدي") return null;
    return CUST().find(x => x.name === nm && x.id) || CUST().find(x => x.name === nm) || { name: nm };
  }
  const custByKey = k => CUST().find(c => keyOf(c) === k) || null;

  /* ---------------- الرصيد (FIFO مع الصلاحية) ---------------- */
  function stat(key, b, c) {
    b = b || book(); c = c || cfg();
    const tx = b.tx.filter(x => x.k === key).sort((a, z) => String(a.date).localeCompare(String(z.date)));
    const ED = +c.expDays || 0, lots = []; let earn = 0, red = 0, exp = 0, last = "";
    const expire = at => { if (!ED) return; const lim = new Date(new Date(String(at).replace(" ", "T")).getTime() - ED * 864e5); lots.forEach(l => { if (l.left > 0 && new Date(String(l.d).replace(" ", "T")) < lim) { exp += l.left; l.left = 0; } }); };
    tx.forEach(x => {
      expire(x.date); last = x.date;
      if (x.p > 0) { lots.push({ d: x.date, left: x.p }); earn += x.p; }
      else if (x.p < 0) { let need = -x.p; if (x.kind === "redeem") red += need; else earn -= Math.min(need, earn); for (const l of lots) { if (!need) break; const u = Math.min(l.left, need); l.left -= u; need -= u; } }
    });
    expire(nowIso());
    const bal = Math.max(0, lots.reduce((s, l) => s + l.left, 0));
    const tiers = c.tiers.slice().sort((a, z) => a.min - z.min); let tier = tiers[0], next = null;
    tiers.forEach((t, i) => { if (earn >= t.min) { tier = t; next = tiers[i + 1] || null; } });
    return { key, bal, earn, red, exp, last, n: tx.length, tier, next, toNext: next ? Math.max(0, next.min - earn) : 0 };
  }
  const val = () => +cfg().val || 0;
  const balNow = () => { const c = custNow(); return c ? stat(keyOf(c)).bal : 0; };

  /* ---------------- الاكتساب لهذه الفاتورة ---------------- */
  const retMode = () => { const i = document.querySelector(".inv"); return !!(i && i.classList.contains("retmode")); };
  function earnFor(c, total, paid) {
    const C = cfg(); if (!on() || !c || !(+C.earnPer > 0)) return 0;
    let base = C.base === "paid" ? Math.min(+paid || 0, +total || 0) : +total || 0; if (base <= 0) return 0;
    const t = stat(keyOf(c), null, C).tier || { x: 1 };
    return ROUND(base / +C.earnPer * (+t.x || 1), C);
  }
  /* آخر نتيجة لـ calc() — لا نستدعي calc() هنا لأنها تعيد كتابة الإجماليات (يراقبها شريط العميل ← حلقة لا نهائية) */
  let LAST = null;
  function wrapCalc() { if (typeof calc !== "function" || calc.__loy) return; const o = calc; const w = function () { const r = o.apply(this, arguments); LAST = r; return r; }; w.__loy = 1; calc = w; }
  function earnNow() { try { const c = custNow(); if (!c || !LAST) return 0; return earnFor(c, LAST.total, adj.paid); } catch (e) { return 0; } }

  /* ---------------- الحفظ: الحركات بعد نجاح حفظ الفاتورة ---------------- */
  let PEND = null, HOOKED = false;
  function hookAfterSave() {
    if (HOOKED) return; HOOKED = true;
    const prev = window.__sxAfterSave;
    window.__sxAfterSave = function (r) { try { if (PEND) { const p = PEND; PEND = null; commit(p, r && (r.invoiceNo || r.InvoiceNo)); } } catch (e) { console.error(e); } return prev ? prev.apply(this, arguments) : undefined; };
  }
  function commit(p, no) {
    const b = book(), C = cfg(), inv = String(no || p.no || "");
    if (inv) b.tx = b.tx.filter(x => !(x.inv === inv && x.k === p.k && /^(earn|redeem|ret|change)$/.test(x.kind)));    // تعديل فاتورة ← استبدال حركاتها
    const add = (kind, pts, note) => { if (!pts) return; b.tx.push({ id: uid(), k: p.k, name: p.name, inv, date: nowIso(), kind, p: pts, amt: p.total, note: note || "" }); };
    if (p.ret) add("ret", -p.earn, "مرتجع مبيعات");
    else {
      if (C.welcome > 0 && !b.tx.some(x => x.k === p.k)) add("welcome", +C.welcome, "نقاط ترحيب");
      add("redeem", -p.red, "خصم " + N(p.red * (+C.val || 0)) + " دج");
      add("earn", p.earn, "فاتورة مبيعات");
      if (p.chg > 0 && +C.val > 0) add("change", ROUND(p.chg / +C.val, C), "تحويل الباقى (" + N(p.chg) + " دج)");
    }
    return saveBook(b).then(() => {
      const s = stat(p.k);
      if (p.ret) { if (p.earn) T("↩ سُحبت " + N(p.earn) + " نقطة من «" + p.name + "» (مرتجع) — الرصيد " + N(s.bal), "i"); }
      else if (p.earn || p.red || p.chg) celebrate(p, s);
      refreshBar();
    }).catch(e => T("تعذّر حفظ نقاط الولاء: " + (e.message || e), "e"));
  }
  function wrapSave() {
    if (typeof doSave !== "function" || doSave.__loy) return;
    const orig = doSave;
    const w = function () {
      let p = null;
      try {
        const c = on() ? custNow() : null;
        if (c) { const t = calc(), ret = retMode(); p = { k: keyOf(c), name: c.name, ret, total: t.total, earn: earnFor(c, t.total, adj.paid), red: ret ? 0 : Math.max(0, +adj.points || 0), chg: +adj.points2 || 0, no: (($("invNo") || {}).value || "") }; if (!p.earn && !p.red && !p.chg && !(cfg().welcome > 0)) p = null; }
      } catch (e) { p = null; }
      const res = orig.apply(this, arguments);
      if (p) { if (HOST()) { hookAfterSave(); PEND = p; } else commit(p, p.no || "محلي"); }
      return res;
    };
    w.__loy = 1; doSave = w;
  }

  /* ---------------- شريط العميل في شاشة المبيعات ---------------- */
  function refreshBar() {
    const l = $("cbCardL"); if (l) l.textContent = on() ? "رصيد النقاط" : "رصيد البطاقة";
    if (!on()) return; const cb = $("cbCard"), cp = $("cbPts"); try { if (cb) cb.textContent = N(balNow()); if (cp) cp.textContent = N(earnNow()); } catch (e) { }
  }
  function celebrate(p, s) {
    const d = document.createElement("div"); d.className = "loy-toast";
    d.innerHTML = `<div class="ic">${IC.star}</div><div class="tx"><b>${p.earn ? "+" + N(p.earn) + " نقطة" : "تم استبدال النقاط"}</b><span>${esc(p.name)}${p.red ? " · استبدال " + N(p.red) : ""}</span></div>
      <div class="bl"><small>الرصيد</small><b>${N(s.bal)}</b><i style="--c:${s.tier.c}">${esc(s.tier.n)}</i></div>`;
    document.body.appendChild(d); requestAnimationFrame(() => d.classList.add("in"));
    setTimeout(() => { d.classList.remove("in"); setTimeout(() => d.remove(), 300); }, 3800);
  }

  /* ---------------- أيقونات ---------------- */
  const IC = {
    star: '<svg viewBox="0 0 24 24"><path d="M12 2.8l2.8 5.7 6.3.9-4.6 4.4 1.1 6.2L12 17.1 6.4 20l1.1-6.2L2.9 9.4l6.3-.9z" fill="currentColor"/></svg>',
    gift: '<svg viewBox="0 0 24 24"><rect x="3" y="9" width="18" height="4" rx="1" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M5 13v7h14v-7M12 9v11" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 9S10.5 4 8 4.6 7.5 9 12 9zm0 0s1.5-5 4-4.4S16.5 9 12 9z" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>',
    x: '<svg viewBox="0 0 14 14"><path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    users: '<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.4" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M2.8 19c.6-3.4 3.2-5.2 6.2-5.2s5.6 1.8 6.2 5.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M16 4.8a3.2 3.2 0 0 1 0 6.3M18.2 14.2c1.7.7 2.7 2.3 3 4.8" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>',
    coin: '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="7" rx="7.5" ry="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M4.5 7v5c0 1.8 3.4 3.2 7.5 3.2s7.5-1.4 7.5-3.2V7M4.5 12v5c0 1.8 3.4 3.2 7.5 3.2s7.5-1.4 7.5-3.2v-5" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>',
    swap: '<svg viewBox="0 0 24 24"><path d="M4 8h13l-3.5-3.5M20 16H7l3.5 3.5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    list: '<svg viewBox="0 0 24 24"><path d="M8 6h12M8 12h12M8 18h12" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/><circle cx="4" cy="6" r="1.3" fill="currentColor"/><circle cx="4" cy="12" r="1.3" fill="currentColor"/><circle cx="4" cy="18" r="1.3" fill="currentColor"/></svg>',
    plus: '<svg viewBox="0 0 16 16"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    minus: '<svg viewBox="0 0 16 16"><path d="M3 8h10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>'
  };

  /* ---------------- نافذة عامة ---------------- */
  function win(o) {
    const ov = document.createElement("div"); ov.className = "loy-ov";
    ov.innerHTML = `<div class="loy-w ${o.cls || ""}" role="dialog" aria-label="${esc(o.title)}"><div class="loy-h"><span class="ic">${o.icon || IC.star}</span><div class="t"><b>${esc(o.title)}</b>${o.sub ? `<small>${o.sub}</small>` : ""}</div><span class="sp"></span>${o.head || ""}<button type="button" class="x" data-x title="إغلاق (Esc)">${IC.x}</button></div><div class="loy-b">${o.body}</div>${o.foot ? `<div class="loy-f">${o.foot}</div>` : ""}</div>`;
    document.body.appendChild(ov); requestAnimationFrame(() => ov.classList.add("in"));
    const close = () => { ov.classList.remove("in"); document.removeEventListener("keydown", key, true); setTimeout(() => ov.remove(), 180); if (o.onClose) o.onClose(); };
    const key = e => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); } else if (e.key === "Enter" && o.onEnter && e.target.tagName !== "TEXTAREA" && e.target.tagName !== "BUTTON") { e.preventDefault(); e.stopPropagation(); o.onEnter(); } };
    document.addEventListener("keydown", key, true);
    ov.addEventListener("mousedown", e => { if (e.target === ov) close(); });
    ov.querySelector("[data-x]").onclick = close;
    return { el: ov, w: ov.querySelector(".loy-w"), close };
  }

  /* ================= F8 «إستبدال النقاط» ================= */
  function redeem() {
    const c = custNow();
    if (!c) { T("اختر العميل أولاً — نقاط الولاء لا تُحسب لـ «تعامل نقدى»", "w"); try { const n = $("custName"); if (n) n.focus(); } catch (e) { } return; }
    const C = cfg(), s = stat(keyOf(c), null, C), v = +C.val || 0;
    let t; try { t = calc(); } catch (e) { t = { total: 0 }; }
    const gross = (+t.total || 0) + (+adj.points || 0) * v;      // الإجمالي قبل خصم النقاط
    const capVal = gross * Math.max(0, Math.min(100, +C.maxPct || 100)) / 100;
    const max = Math.max(0, Math.min(s.bal, v > 0 ? Math.floor(capVal / v + 1e-9) : 0));
    const minR = Math.max(0, +C.minRedeem || 0), can = max >= Math.max(1, minR);
    let cur = Math.min(+adj.points || 0, max);
    const pct = s.next ? Math.min(100, Math.round((s.earn - s.tier.min) / Math.max(1, s.next.min - s.tier.min) * 100)) : 100;
    const w = win({
      title: "إستبدال النقاط", icon: IC.swap, cls: "loy-rd", sub: esc(c.name),
      body: `<div class="loy-card" style="--tc:${s.tier.c}">
          <div class="lc-top"><span class="lc-tier">${IC.star}${esc(s.tier.n)}</span><span class="lc-no">${esc(c.no || c.card || "")}</span></div>
          <div class="lc-bal"><small>رصيد النقاط</small><b>${N(s.bal)}</b><em>= ${N(s.bal * v)} دج</em></div>
          <div class="lc-prog"><i style="width:${pct}%"></i></div><div class="lc-next">${s.next ? `${N(s.toNext)} نقطة للوصول إلى «${esc(s.next.n)}» (×${s.next.x})` : "أعلى مستوى عضوية"}</div></div>
        <div class="loy-info"><span>قيمة النقطة <b>${N(v)} دج</b></span><span>الحد الأقصى <b>${C.maxPct}%</b> من الفاتورة</span>${minR ? `<span>أقل استبدال <b>${N(minR)}</b> نقطة</span>` : ""}</div>
        ${can ? `<div class="loy-amt"><button type="button" class="st" data-st="-1">${IC.minus}</button><input type="number" min="0" max="${max}" step="1" value="${cur}" class="pts"><button type="button" class="st" data-st="1">${IC.plus}</button></div>
        <input type="range" class="loy-rng" min="0" max="${max}" step="1" value="${cur}">
        <div class="loy-chips">${[25, 50, 75].map(k => `<button type="button" data-q="${k}">${k}%</button>`).join("")}<button type="button" data-q="100">الكل (${N(max)})</button></div>
        <div class="loy-res"><span>خصم على الفاتورة</span><b class="dv">0</b><small>دج</small><span class="sp"></span><span>الباقى من النقاط</span><b class="rv">0</b></div>`
          : `<div class="loy-empty">${IC.gift}<b>${s.bal < Math.max(1, minR) ? "رصيد النقاط غير كافٍ للاستبدال" : "أضف أصنافاً للفاتورة أولاً"}</b><small>${minR ? "أقل عدد للاستبدال " + N(minR) + " نقطة · " : ""}يكسب العميل ${N(earnNow())} نقطة من هذه الفاتورة</small></div>`}`,
      foot: can ? `<button type="button" class="loy-btn pri" data-a="ok">تطبيق الخصم</button>${adj.points ? '<button type="button" class="loy-btn ghost red" data-a="clr">إلغاء الاستبدال</button>' : ""}<span class="sp"></span><button type="button" class="loy-btn ghost" data-a="x">إغلاق</button>`
        : `<span class="sp"></span><button type="button" class="loy-btn ghost" data-a="x">إغلاق</button>`,
      onEnter: () => { const b = w.el.querySelector('[data-a="ok"]'); if (b) b.click(); else w.close(); }
    });
    const inp = w.el.querySelector(".pts"), rng = w.el.querySelector(".loy-rng");
    const set = x => { cur = Math.max(0, Math.min(max, Math.round(+x || 0))); if (inp && +inp.value !== cur) inp.value = cur; if (rng) rng.value = cur; const dv = w.el.querySelector(".dv"), rv = w.el.querySelector(".rv"); if (dv) dv.textContent = N(cur * v); if (rv) rv.textContent = N(s.bal - cur); };
    if (inp) { set(cur); setTimeout(() => { inp.focus(); inp.select(); }, 40); inp.addEventListener("input", () => set(inp.value)); rng.addEventListener("input", () => set(rng.value)); }
    w.el.addEventListener("click", e => {
      const st = e.target.closest("[data-st]"); if (st) { set(cur + +st.dataset.st); return; }
      const q = e.target.closest("[data-q]"); if (q) { set(Math.floor(max * +q.dataset.q / 100)); return; }
      const a = e.target.closest("[data-a]"); if (!a) return;
      if (a.dataset.a === "x") { w.close(); return; }
      if (a.dataset.a === "clr") { adj.points = 0; w.close(); try { calc(); renderRows(); } catch (er) { } T("تم إلغاء استبدال النقاط", "i"); refreshBar(); return; }
      if (a.dataset.a === "ok") {
        if (cur > 0 && cur < minR) { T("أقل عدد نقاط للاستبدال " + N(minR), "w"); inp.focus(); return; }
        adj.points = cur; w.close(); try { calc(); renderRows(); } catch (er) { }
        T(cur ? "✔ تم استبدال " + N(cur) + " نقطة = خصم " + N(cur * v) + " دج" : "لم يتم استبدال نقاط", cur ? "s" : "i"); refreshBar();
      }
    });
  }

  /* ================= مركز نقاط الولاء (الإضافات ← نقاط الولاء) ================= */
  function center(tab) {
    tab = tab || "home";
    const w = win({ title: "نقاط الولاء", icon: IC.star, cls: "loy-cn", sub: "تكريم العملاء الأوفياء — نقاط على كل عملية شراء تتحول الى خصومات",
      head: `<label class="loy-sw" title="تفعيل / إلغاء تفعيل الإضافة"><span class="lb"></span><input type="checkbox"${on() ? " checked" : ""}><i></i></label>`,
      body: `<div class="loy-tabs"><button type="button" data-t="home">${IC.star}نظرة عامة</button><button type="button" data-t="rules">${IC.gear}القواعد</button><button type="button" data-t="mem">${IC.users}العملاء</button><button type="button" data-t="tx">${IC.list}الحركات</button></div><div class="loy-pane"></div>`,
      foot: `<small class="loy-st"></small><span class="sp"></span><button type="button" class="loy-btn ghost" data-a="x">إغلاق</button>` });
    const pane = w.el.querySelector(".loy-pane"), sw = w.el.querySelector(".loy-sw input"), stt = w.el.querySelector(".loy-st");
    const paintSw = () => { w.el.querySelector(".loy-sw .lb").textContent = sw.checked ? "مفعّلة" : "غير مفعّلة"; w.w.classList.toggle("off", !sw.checked); stt.innerHTML = sw.checked ? "● الإضافة مفعّلة — تُحتسب النقاط مع كل فاتورة مبيعات لعميل محدد" : "○ الإضافة غير مفعّلة — لا تُحتسب نقاط"; };
    paintSw();
    sw.addEventListener("change", () => setOn(sw.checked).then(() => { paintSw(); refreshBar(); T(sw.checked ? "✔ تم تفعيل «نقاط الولاء»" : "تم إلغاء تفعيل «نقاط الولاء»", "s"); }));
    w.el.querySelector('[data-a="x"]').onclick = w.close;
    let q = "", qt = "";
    const draw = () => {
      w.el.querySelectorAll(".loy-tabs [data-t]").forEach(b => b.classList.toggle("on", b.dataset.t === tab));
      const C = cfg(), b = book(), keys = Array.from(new Set(b.tx.map(x => x.k))), S = keys.map(k => Object.assign(stat(k, b, C), { name: (custByKey(k) || {}).name || (b.tx.find(x => x.k === k) || {}).name || k }));
      if (tab === "home") {
        const out = S.reduce((s, x) => s + x.bal, 0), earn = S.reduce((s, x) => s + x.earn, 0), red = S.reduce((s, x) => s + x.red, 0);
        const by = C.tiers.map(t => ({ t, n: S.filter(x => x.tier && x.tier.n === t.n).length }));
        const top = S.slice().sort((a, z) => z.bal - a.bal).slice(0, 6);
        pane.innerHTML = `<div class="loy-kpis">
            <div class="k"><span class="i">${IC.users}</span><small>أعضاء البرنامج</small><b>${N(S.length)}</b></div>
            <div class="k g"><span class="i">${IC.star}</span><small>نقاط مكتسبة</small><b>${N(earn)}</b></div>
            <div class="k o"><span class="i">${IC.swap}</span><small>نقاط مستبدلة</small><b>${N(red)}</b><em>${N(red * C.val)} دج خصومات</em></div>
            <div class="k b"><span class="i">${IC.coin}</span><small>رصيد قائم (التزام)</small><b>${N(out)}</b><em>${N(out * C.val)} دج</em></div></div>
          <div class="loy-2">
            <div class="loy-box"><h4>القاعدة الحالية</h4><div class="loy-rule"><div><b>${N(C.earnPer)} دج</b><span>من ${C.base === "paid" ? "المدفوع" : "إجمالي الفاتورة"}</span></div><i>=</i><div><b>1 نقطة</b><span>تُكتسب</span></div></div>
              <div class="loy-rule"><div><b>1 نقطة</b><span>عند الاستبدال</span></div><i>=</i><div><b>${N(C.val)} دج</b><span>خصم</span></div></div>
              <p class="loy-mut">العائد للعميل ≈ <b>${N(C.earnPer > 0 ? C.val / C.earnPer * 100 : 0)}%</b> من مشترياته · الحد الأقصى للاستبدال ${C.maxPct}% من الفاتورة${C.expDays ? " · صلاحية النقاط " + C.expDays + " يوم" : ""}</p></div>
            <div class="loy-box"><h4>مستويات العضوية</h4>${by.map(x => `<div class="loy-tier" style="--c:${x.t.c}"><span class="dot">${IC.star}</span><b>${esc(x.t.n)}</b><small>من ${N(x.t.min)} نقطة · ×${x.t.x}</small><span class="sp"></span><em>${N(x.n)} عميل</em></div>`).join("")}</div></div>
          <div class="loy-box"><h4>أعلى العملاء رصيداً</h4>${top.length ? `<div class="loy-top">${top.map((x, i) => `<div class="r" data-k="${esc(x.key)}"><span class="n">${i + 1}</span><b>${esc(x.name)}</b><i class="tg" style="--c:${x.tier.c}">${esc(x.tier.n)}</i><span class="sp"></span><b class="v">${N(x.bal)}</b><small>نقطة</small></div>`).join("")}</div>` : `<div class="loy-none">${IC.gift}<b>لا توجد نقاط بعد</b><small>ستظهر هنا بعد أول فاتورة مبيعات لعميل محدد</small></div>`}</div>`;
      } else if (tab === "rules") {
        const f = (k, t, h, a) => `<label class="loy-fr"><span><b>${t}</b>${h ? `<small>${h}</small>` : ""}</span><span class="in"><input type="number" data-c="${k}" value="${esc(C[k])}" ${a || 'min="0"'}></span></label>`;
        pane.innerHTML = `<div class="loy-form">
          <h4>اكتساب النقاط</h4>
          ${f("earnPer", "كل (دج) = 1 نقطة", "مثال 100: فاتورة 2,500 دج = 25 نقطة", 'min="1" step="1"')}
          <label class="loy-fr"><span><b>تُحسب النقاط على</b></span><span class="in"><select data-c="base"><option value="total"${C.base !== "paid" ? " selected" : ""}>إجمالي الفاتورة (بعد الخصم)</option><option value="paid"${C.base === "paid" ? " selected" : ""}>المبلغ المدفوع فقط</option></select></span></label>
          <label class="loy-fr"><span><b>تقريب النقاط</b></span><span class="in"><select data-c="round"><option value="floor"${C.round !== "round" ? " selected" : ""}>لأسفل (الكسور لا تُحسب)</option><option value="round"${C.round === "round" ? " selected" : ""}>لأقرب عدد صحيح</option></select></span></label>
          ${f("welcome", "نقاط ترحيب", "تُمنح للعميل مع أول فاتورة (0 = بدون)")}
          <h4>استبدال النقاط (F8)</h4>
          ${f("val", "قيمة النقطة (دج)", "خصم كل نقطة عند الاستبدال", 'min="0" step="0.01"')}
          ${f("minRedeem", "أقل عدد نقاط للاستبدال", "")}
          ${f("maxPct", "الحد الأقصى للخصم بالنقاط (%)", "نسبة من إجمالي الفاتورة", 'min="1" max="100"')}
          ${f("expDays", "صلاحية النقاط (يوم)", "0 = لا تنتهي — النقاط الأقدم تُستهلك أولاً")}
          <h4>مستويات العضوية <small>حسب مجموع النقاط المكتسبة</small></h4>
          <div class="loy-tiers">${C.tiers.map((t, i) => `<div class="tr" data-i="${i}" style="--c:${t.c}"><span class="dot">${IC.star}</span><input class="n" value="${esc(t.n)}"><label>من<input type="number" class="m" min="0" value="${t.min}"${i ? "" : " disabled"}></label><label>مضاعف ×<input type="number" class="x" min="0.1" step="0.05" value="${t.x}"></label><input type="color" class="c" value="${t.c}"></div>`).join("")}</div>
          <div class="loy-prev"></div></div>`;
        const prev = () => { const c2 = read(); const e = c2.earnPer > 0 ? Math.floor(5000 / c2.earnPer) : 0; pane.querySelector(".loy-prev").innerHTML = `${IC.gift}<span>مثال: فاتورة <b>5,000 دج</b> ← <b>${N(e)}</b> نقطة (برونزي) · <b>${N(Math.floor(e * (c2.tiers[c2.tiers.length - 1].x || 1)))}</b> نقطة (${esc(c2.tiers[c2.tiers.length - 1].n)}) — قيمتها عند الاستبدال <b>${N(e * c2.val)} دج</b></span>`; };
        const read = () => { const c2 = cfg(); pane.querySelectorAll("[data-c]").forEach(i => { c2[i.dataset.c] = i.tagName === "SELECT" ? i.value : Math.max(0, +i.value || 0); });
          c2.tiers = Array.from(pane.querySelectorAll(".loy-tiers .tr")).map((r, i) => ({ n: r.querySelector(".n").value.trim() || "مستوى " + (i + 1), min: i ? Math.max(0, +r.querySelector(".m").value || 0) : 0, x: Math.max(.1, +r.querySelector(".x").value || 1), c: r.querySelector(".c").value })); return c2; };
        prev(); pane.oninput = prev; pane.onchange = prev;
        let sv = w.el.querySelector(".loy-save"); if (!sv) { sv = document.createElement("button"); sv.type = "button"; sv.className = "loy-btn pri loy-save"; sv.textContent = "حفظ القواعد"; w.el.querySelector(".loy-f [data-a=x]").before(sv); }
        sv.hidden = false; sv.onclick = () => { const c2 = read(); if (!(c2.earnPer > 0)) { T("أدخل قيمة صحيحة لـ «كل (دج) = 1 نقطة»", "w"); return; } if (PR()) PR().put("loy.cfg", c2).then(() => { T("✔ تم حفظ قواعد نقاط الولاء", "s"); refreshBar(); }); };
        return;
      } else if (tab === "mem") {
        const all = CUST().filter(c => c.name && c.name !== "تعامل نقدى").map(c => Object.assign(stat(keyOf(c), b, C), { name: c.name, no: c.no || "", ph: c.ph || "" }));
        keys.forEach(k => { if (!all.some(x => x.key === k)) all.push(Object.assign(stat(k, b, C), { name: (b.tx.find(x => x.k === k) || {}).name || k, no: "", ph: "" })); });
        const l = all.filter(x => !q || (x.name + " " + x.no + " " + x.ph).toLowerCase().includes(q.toLowerCase())).sort((a, z) => z.bal - a.bal || z.earn - a.earn || a.name.localeCompare(z.name, "ar"));
        pane.innerHTML = `<div class="loy-q"><input placeholder="بحث باسم العميل أو رقمه أو هاتفه…" value="${esc(q)}"><small>${N(l.length)} عميل</small></div>
          <div class="loy-tbl"><div class="th"><span>العميل</span><span>المستوى</span><span>الرصيد</span><span>مكتسب</span><span>مستبدل</span><span>آخر حركة</span><span></span></div>
          ${l.slice(0, 400).map(x => `<div class="tr" data-k="${esc(x.key)}"><span class="nm"><b>${esc(x.name)}</b><small>${esc(x.no || x.ph || "")}</small></span><span><i class="tg" style="--c:${x.tier.c}">${esc(x.tier.n)}</i></span><span class="v">${N(x.bal)}</span><span>${N(x.earn)}</span><span>${N(x.red)}</span><span class="d">${esc(x.last || "—")}</span>
            <span class="ac"><button type="button" data-adj="1" title="إضافة نقاط">${IC.plus}</button><button type="button" data-adj="-1" title="خصم نقاط"${x.bal > 0 ? "" : " disabled"}>${IC.minus}</button></span></div>`).join("") || '<div class="loy-none"><b>لا يوجد عملاء</b></div>'}</div>`;
        const qi = pane.querySelector(".loy-q input"); qi.oninput = () => { q = qi.value; const p = qi.selectionStart; draw(); const n = pane.querySelector(".loy-q input"); n.focus(); n.setSelectionRange(p, p); };
      } else {
        const KN = { earn: ["مكتسبة", "g"], redeem: ["استبدال", "o"], ret: ["مرتجع", "r"], change: ["تحويل باقى", "b"], welcome: ["ترحيب", "g"], adj: ["تعديل يدوي", "b"] };
        const l = b.tx.slice().reverse().filter(x => !qt || (x.name + " " + x.inv + " " + x.note).toLowerCase().includes(qt.toLowerCase()));
        pane.innerHTML = `<div class="loy-q"><input placeholder="بحث بالعميل أو رقم الفاتورة…" value="${esc(qt)}"><small>${N(l.length)} حركة</small></div>
          <div class="loy-tbl tx"><div class="th"><span>التاريخ</span><span>العميل</span><span>الحركة</span><span>الفاتورة</span><span>النقاط</span><span>البيان</span></div>
          ${l.slice(0, 500).map(x => { const k = KN[x.kind] || [x.kind, "b"]; return `<div class="tr"><span class="d">${esc(x.date)}</span><span class="nm"><b>${esc(x.name)}</b></span><span><i class="kd ${k[1]}">${k[0]}</i></span><span>${esc(x.inv || "—")}</span><span class="v ${x.p < 0 ? "neg" : "pos"}">${x.p > 0 ? "+" : ""}${N(x.p)}</span><span class="nt">${esc(x.note || "")}</span></div>`; }).join("") || `<div class="loy-none">${IC.list}<b>لا توجد حركات بعد</b></div>`}</div>`;
        const qi = pane.querySelector(".loy-q input"); qi.oninput = () => { qt = qi.value; const p = qi.selectionStart; draw(); const n = pane.querySelector(".loy-q input"); n.focus(); n.setSelectionRange(p, p); };
      }
      const sv = w.el.querySelector(".loy-save"); if (sv) sv.hidden = true;
    };
    w.el.querySelector(".loy-tabs").addEventListener("click", e => { const b = e.target.closest("[data-t]"); if (b) { tab = b.dataset.t; draw(); } });
    pane.addEventListener("click", e => {
      const tp = e.target.closest(".loy-top .r[data-k]"); if (tp) { tab = "mem"; q = (custByKey(tp.dataset.k) || {}).name || ""; draw(); return; }
      const a = e.target.closest("[data-adj]"); if (!a) return; const k = a.closest("[data-k]").dataset.k; adjust(k, +a.dataset.adj, draw);
    });
    draw();
  }
  /* تعديل يدوي للرصيد */
  function adjust(k, sign, done) {
    const c = custByKey(k), name = c ? c.name : ((book().tx.find(x => x.k === k) || {}).name || k), s = stat(k);
    const w = win({ title: sign > 0 ? "إضافة نقاط" : "خصم نقاط", icon: sign > 0 ? IC.plus : IC.minus, cls: "loy-adj", sub: esc(name) + " · الرصيد " + N(s.bal),
      body: `<label class="loy-fr"><span><b>عدد النقاط</b></span><span class="in"><input type="number" class="n" min="1" ${sign < 0 ? `max="${s.bal}"` : ""} value=""></span></label><label class="loy-fr col"><span><b>السبب</b></span><input class="r" placeholder="مثال: هدية عيد ميلاد / تصحيح"></label>`,
      foot: `<button type="button" class="loy-btn pri" data-a="ok">${sign > 0 ? "إضافة" : "خصم"}</button><span class="sp"></span><button type="button" class="loy-btn ghost" data-a="x">إلغاء</button>`,
      onEnter: () => w.el.querySelector('[data-a="ok"]').click() });
    const n = w.el.querySelector(".n"); setTimeout(() => n.focus(), 40);
    w.el.addEventListener("click", e => { const a = e.target.closest("[data-a]"); if (!a) return; if (a.dataset.a === "x") { w.close(); return; }
      let v = Math.round(+n.value || 0); if (v <= 0) { T("أدخل عدد النقاط", "w"); n.focus(); return; } if (sign < 0) v = Math.min(v, s.bal);
      const b = book(); b.tx.push({ id: uid(), k, name, inv: "", date: nowIso(), kind: "adj", p: sign * v, amt: 0, note: w.el.querySelector(".r").value.trim() || (sign > 0 ? "إضافة يدوية" : "خصم يدوي") });
      saveBook(b).then(() => { w.close(); T("✔ " + (sign > 0 ? "أُضيفت " : "خُصمت ") + N(v) + " نقطة — " + name, "s"); refreshBar(); done && done(); }); });
  }

  /* ---------------- لوحة الإضافات: بطاقة «نقاط الولاء» ← مركز نقاط الولاء ---------------- */
  document.addEventListener("click", e => {
    const c = e.target.closest && e.target.closest('.pp-card[data-a="loyal"]'); if (!c) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); center();
  }, true);
  /* شارة «مفعّلة» على البطاقة عند فتح لوحة الإضافات */
  new MutationObserver(() => { const c = document.querySelector('.pp-card[data-a="loyal"]:not([data-loy])'); if (!c) return; c.dataset.loy = 1; c.classList.add("loy-addon"); c.insertAdjacentHTML("beforeend", `<span class="loy-badge${on() ? "" : " off"}">${IC.star}${on() ? "مفعّلة" : "غير مفعّلة"}</span>`); })
    .observe(document.body, { childList: true, subtree: true });

  /* ---------------- قائمة «الإضافات» في الشريط العلوي ← «نقاط الولاء» (بعد «كوبونات الخصم») ---------------- */
  function addMenu() {
    const M = window.__MENUS, A = M && M["الإضافات"]; if (!A) return false;
    if (A.some(i => i.t === "نقاط الولاء")) return true;
    try { if (window.__NAVIC) window.__NAVIC.loyal = '<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="8.6" fill="#fde68a"/><path d="M10 4.2l1.75 3.55 3.9.57-2.82 2.75.67 3.88L10 13.12l-3.5 1.83.67-3.88L4.35 8.32l3.9-.57z" fill="#ea580c"/></svg>'; } catch (e) { }
    const k = A.findIndex(x => x.t === "كوبونات الخصم");
    A.splice(k < 0 ? A.length : k + 1, 0, { t: "نقاط الولاء", ic: "loyal", run: () => center() });
    return true;
  }
  if (!addMenu()) { let n = 0; const iv = setInterval(() => { if (addMenu() || ++n > 20) clearInterval(iv); }, 500); }

  /* ---------------- الإقلاع: التفعيل الافتراضي ---------------- */
  function boot() {
    wrapCalc(); wrapSave(); refreshBar();
    const P = PR(); if (!P) return;
    Promise.resolve(P.load ? P.load() : null).then(() => {
      if (!P.get("loy.init", false)) {   // أول مرة: تفعيل الإضافة بقواعد افتراضية
        P.put("loy.init", true); if (!P.get("loy.cfg", null)) P.put("loy.cfg", DEF);
        setOn(true).then(refreshBar);
      } else refreshBar();
    }).catch(() => { });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else setTimeout(boot, 0);
  window.addEventListener("anouer:props", e => { if (e.detail && /^(add\.enabled|loy\.)/.test(e.detail.key || "")) setTimeout(refreshBar, 0); });

  window.__LOY = { on, val, balNow, earnNow, redeem, center, stat: k => stat(k), custNow, cfg };
})();
