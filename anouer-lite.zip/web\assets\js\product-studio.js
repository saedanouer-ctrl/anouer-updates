/* ==========================================================================
   استوديو صورة الصنف — ANOUER
   زر بجانب «الصورة» في شاشة الصنف: يفتح الكاميرا (أو الهاتف عبر QR أو ملف)،
   يلتقط صورة المنتج (+ قطعة واحدة اختيارياً)، ثم:
     1) يقرأ من العلبة: الاسم، العلامة، عدد القطع، الوزن، الباركود، الفئة (Gemini مجاني أو Claude)
     2) يعزل المنتج عن الخلفية (قناع Gemini أو خوارزمية محلية بدون إنترنت)
     3) يحسّن الإضاءة والألوان والحدة ويضعه على خلفية بيضاء بظل استوديو (مثل صور الكتالوج)
     4) اختيارياً: توليد صورة كتالوج كاملة بالذكاء الاصطناعي (Gemini Image — يحتاج تفعيل الفوترة في Google)
   ثم «اعتماد» يضع الصورة على الصنف ويملأ الاسم / وحدة العلبة / الباركود حسب اختيارك.
   ========================================================================== */
(function () {
  "use strict";
  if (window.ANOUER_PSTUDIO) return;
  const G = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const say = (m, t) => { try { if (typeof toast === "function") toast(m, t || "i"); else console.log(m); } catch (e) { } };
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const call = (a, p) => Anouer.call(a, p || {});
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
  const isUnknown = e => /Unknown action|غير معروف/i.test(String(e && e.message || e));
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  /* ================================================================== مفاتيح الذكاء الاصطناعي (نفس مفاتيح «قراءة الفاتورة») */
  const GK = "scan.gkey";
  const gKey = () => { try { const v = localStorage.getItem(GK); return v ? decodeURIComponent(escape(atob(v))) : ""; } catch (e) { return ""; } };
  const gSetKey = k => { try { if (k) localStorage.setItem(GK, btoa(unescape(encodeURIComponent(k)))); else localStorage.removeItem(GK); } catch (e) { } };
  let CLAUDE = null;   // null = لم نتحقق، true/false
  async function claudeOK() { if (CLAUDE != null) return CLAUDE; if (!HOST()) return (CLAUDE = false); try { const c = await call("fm.ai.cfg"); CLAUDE = !!(c && c.hasKey); } catch (e) { CLAUDE = false; } return CLAUDE; }

  const GAPI = "https://generativelanguage.googleapis.com/v1beta/";
  let GVIA = "";
  async function gFetch(url, key, body, ms) {
    if (GVIA !== "host") {
      const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), ms || 150000);
      try {
        const r = await fetch(url, body ? { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": key }, body, signal: ctl.signal } : { headers: { "x-goog-api-key": key }, signal: ctl.signal });
        GVIA = "direct"; return { ok: r.ok, status: r.status, j: await r.json().catch(() => ({})) };
      } catch (e) { if (ctl.signal.aborted) return { ok: false, status: 408, j: { error: { message: "انتهت المهلة" } } }; if (!HOST()) throw new Error("تعذّر الاتصال بخدمة Gemini — تحقق من الإنترنت."); }
      finally { clearTimeout(t); }
    }
    let x;
    try { x = await call("fm.ai.http", { url, method: body ? "POST" : "GET", key, body: body || "" }); }
    catch (e) { if (isUnknown(e)) throw new Error("تعذّر الاتصال بخدمة Gemini — تحقق من الإنترنت."); throw e; }
    GVIA = "host"; let j = {}; try { j = JSON.parse(x.text || "{}"); } catch (e) { }
    return { ok: x.status >= 200 && x.status < 300, status: x.status, j };
  }
  function gErr(st, j) {
    const m = (j && j.error && j.error.message) || "";
    if (st === 400 && /API key/i.test(m)) return "مفتاح Gemini غير صحيح.";
    if (st === 403) return "المفتاح لا يملك صلاحية (403).";
    if (st === 429) return /limit: 0|free_tier|billing/i.test(m) ? "يحتاج تفعيل الفوترة في Google AI Studio" : "تجاوزت حد الاستعمال لهذه الدقيقة — أعد المحاولة بعد قليل (429).";
    if (st === 503 || st === 500) return "خدمة Gemini مشغولة حالياً — أعد المحاولة.";
    if (st === 408) return "انتهت مهلة الاتصال بـ Gemini.";
    return "خطأ من Gemini (" + st + "): " + m.slice(0, 160);
  }
  /* كل النماذج المتاحة للمفتاح (مخزنة يوماً) */
  async function gAll(key) {
    const c = lsGet("ps.models", null);
    if (c && c.k === key.slice(-6) && Date.now() - c.at < 864e5 && c.l && c.l.length) return c.l;
    const r = await gFetch(GAPI + "models?pageSize=300", key, null, 30000);
    if (!r.ok) throw new Error(gErr(r.status, r.j));
    const l = (r.j.models || []).filter(m => (m.supportedGenerationMethods || []).includes("generateContent")).map(m => m.name.replace(/^models\//, ""));
    lsSet("ps.models", { k: key.slice(-6), at: Date.now(), l }); return l;
  }
  const ver = n => { const m = /gemini-(\d+(?:\.\d+)?)/.exec(n); return m ? +m[1] : 0; };
  function textModels(l) {
    const rank = n => (/flash(?!-lite)/.test(n) ? 3000 : /flash-lite/.test(n) ? 2000 : /pro/.test(n) ? 1000 : 0) + ver(n) * 10 - (/preview|exp/.test(n) ? 5 : 0) - (/latest/.test(n) ? 2 : 0);
    const ok = lsGet("scan.gok", "");
    const L = l.filter(n => /^gemini-/.test(n) && !/image|tts|audio|live|embedding|robotics|computer|native|aqa|exp-\d{4}/i.test(n)).sort((a, b) => rank(b) - rank(a));
    return (ok && L.includes(ok) ? [ok] : []).concat(L.filter(x => x !== ok)).slice(0, 4);
  }
  function imageModels(l) {
    const rank = n => (/flash/.test(n) ? 2000 : 1000) + ver(n) * 10 - (/preview/.test(n) ? 3 : 0) - (/lite/.test(n) ? 1 : 0);
    const ok = lsGet("ps.gimgok", "");
    const L = l.filter(n => /^gemini-.*image/i.test(n) && !/imagen|tts|audio/i.test(n)).sort((a, b) => rank(b) - rank(a));
    return (ok && L.includes(ok) ? [ok] : []).concat(L.filter(x => x !== ok)).slice(0, 3);
  }
  const b64 = u => String(u).replace(/^data:[^,]+,/, "");
  const mime = u => (/^data:([^;,]+)/.exec(u) || [])[1] || "image/jpeg";
  function parseJSON(t) {
    t = String(t || "").replace(/```(?:json)?/gi, "").trim();
    const a = t.search(/[\[{]/); if (a < 0) return null;
    const open = t[a], close = open === "[" ? "]" : "}", b = t.lastIndexOf(close);
    try { return JSON.parse(t.slice(a, b + 1)); } catch (e) { return null; }
  }
  /* سؤال نصّي (JSON) لـ Gemini مع تجاوز النماذج غير المتاحة */
  async function gJSON(prompt, imgs, opt) {
    const key = gKey(); if (!key) throw new Error("no-key");
    const all = await gAll(key);
    let list = opt && opt.models ? opt.models(all) : textModels(all); if (!list.length) list = ["gemini-2.5-flash"];
    const parts = imgs.map(u => ({ inline_data: { mime_type: mime(u), data: b64(u) } })).concat([{ text: prompt }]);
    let last = null;
    for (const model of list) {
      const gc = { temperature: 0.1, maxOutputTokens: (opt && opt.max) || 4096, responseMimeType: "application/json" };
      if (/gemini-2\.5/.test(model)) gc.thinkingConfig = { thinkingBudget: /pro/.test(model) ? 128 : 0 };
      else if (/gemini-[3-9]/.test(model)) gc.thinkingConfig = { thinkingLevel: "low" };
      let body = JSON.stringify({ contents: [{ role: "user", parts }], generationConfig: gc });
      for (let t = 0; t < 2; t++) {
        const r = await gFetch(GAPI + "models/" + encodeURIComponent(model) + ":generateContent", key, body, 90000);
        if (r.ok) {
          const c = (r.j.candidates || [])[0] || {}, txt = ((c.content && c.content.parts) || []).filter(z => !z.thought).map(z => z.text || "").join("");
          const v = parseJSON(txt); if (v) { if (!(opt && opt.models)) lsSet("scan.gok", model); return { v, model }; }
          last = new Error("رد غير مفهوم من " + model); break;
        }
        last = new Error(gErr(r.status, r.j));
        if (r.status === 400 && /API key/i.test(JSON.stringify(r.j))) throw last;
        if (r.status === 400 && /think/i.test(JSON.stringify(r.j)) && gc.thinkingConfig) { delete gc.thinkingConfig; body = JSON.stringify({ contents: [{ role: "user", parts }], generationConfig: gc }); continue; }
        if ((r.status === 503 || r.status === 500) && t === 0) { await sleep(2500); continue; }
        break;
      }
    }
    throw last || new Error("تعذّر الاتصال بـ Gemini");
  }
  async function claudeJSON(prompt, imgs) {
    const r = await call("fm.ai.ask", { prompt, images: imgs.map(u => ({ data: b64(u), type: mime(u) })), max: 1500 });
    const v = parseJSON(r && r.text); if (!v) throw new Error("رد غير مفهوم من Claude"); return { v, model: r.model || "Claude" };
  }
  /* توليد صورة بـ Gemini Image (Nano Banana) — يرمي {billing:true} إن كان الحساب مجانياً */
  async function gImage(prompt, imgs) {
    const key = gKey(); if (!key) throw new Error("no-key");
    const list = imageModels(await gAll(key)); if (!list.length) { const e = new Error("لا يوجد نموذج توليد صور متاح لهذا المفتاح"); e.billing = true; throw e; }
    const parts = imgs.map(u => ({ inline_data: { mime_type: mime(u), data: b64(u) } })).concat([{ text: prompt }]);
    let last = null, billing = 0;
    for (const model of list) {
      let gc = { responseModalities: ["IMAGE", "TEXT"], imageConfig: { aspectRatio: "1:1" } };
      for (let t = 0; t < 3; t++) {
        const r = await gFetch(GAPI + "models/" + encodeURIComponent(model) + ":generateContent", key, JSON.stringify({ contents: [{ role: "user", parts }], generationConfig: gc }), 180000);
        if (r.ok) {
          const c = (r.j.candidates || [])[0] || {}, p = ((c.content && c.content.parts) || []).find(z => z.inlineData || z.inline_data);
          if (p) { const d = p.inlineData || p.inline_data; lsSet("ps.gimgok", model); lsSet("ps.gen", null); return { url: "data:" + (d.mimeType || d.mime_type || "image/png") + ";base64," + d.data, model }; }
          last = new Error("لم يُرجع النموذج صورة (" + (c.finishReason || "?") + ")"); break;
        }
        const s = JSON.stringify(r.j);
        if (r.status === 400 && /imageConfig|aspect/i.test(s) && gc.imageConfig) { gc = { responseModalities: ["IMAGE", "TEXT"] }; continue; }
        if (r.status === 429 && /limit: 0|free_tier|billing|quota/i.test(s)) { billing++; last = new Error("يحتاج تفعيل الفوترة"); break; }
        if (r.status === 403 || (r.status === 400 && /billing|not available|FAILED_PRECONDITION/i.test(s))) { billing++; last = new Error(gErr(r.status, r.j)); break; }
        last = new Error(gErr(r.status, r.j));
        if ((r.status === 503 || r.status === 500 || (r.status === 429 && t < 1)) && t < 2) { await sleep(3000); continue; }
        break;
      }
    }
    const e = last || new Error("تعذّر التوليد"); if (billing && billing >= list.length) e.billing = true; throw e;
  }

  /* ================================================================== أدوات الصور */
  const mk = (w, h) => { const c = document.createElement("canvas"); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h)); return c; };
  const loadImg = src => new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => no(new Error("تعذّر فتح الصورة")); i.src = src; });
  function fitCanvas(img, max) { const w = img.naturalWidth || img.width, h = img.naturalHeight || img.height, k = Math.min(1, max / Math.max(w, h)); const c = mk(w * k, h * k), x = c.getContext("2d"); x.imageSmoothingQuality = "high"; x.drawImage(img, 0, 0, c.width, c.height); return c; }
  const jpg = (c, q) => c.toDataURL("image/jpeg", q || 0.9);

  /* عزل محلي: ملء من الحواف يعتمد على التدرج المحلي + البعد عن لون الخلفية (يعمل جيداً مع خلفية فاتحة/موحدة) */
  function localMask(cv, box) {
    const W = cv.width, H = cv.height, src = cv.getContext("2d").getImageData(0, 0, W, H).data, N = W * H;
    // تنعيم بسيط 3×3 لتقليل الضجيج
    const L = new Float32Array(N * 3);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      let r = 0, g = 0, b = 0, n = 0;
      for (let dy = -1; dy <= 1; dy++) { const yy = y + dy; if (yy < 0 || yy >= H) continue; for (let dx = -1; dx <= 1; dx++) { const xx = x + dx; if (xx < 0 || xx >= W) continue; const i = (yy * W + xx) * 4; r += src[i]; g += src[i + 1]; b += src[i + 2]; n++; } }
      const o = (y * W + x) * 3; L[o] = r / n; L[o + 1] = g / n; L[o + 2] = b / n;
    }
    const m = Math.round(Math.max(W, H) * 0.025);
    const bx0 = Math.max(0, (box ? box[0] : 0) - m), by0 = Math.max(0, (box ? box[1] : 0) - m), bx1 = Math.min(W - 1, (box ? box[2] : W - 1) + m), by1 = Math.min(H - 1, (box ? box[3] : H - 1) + m);
    const bg = new Uint8Array(N); const q = new Int32Array(N); let qh = 0, qt = 0;
    // لون الخلفية: متوسط حواف المستطيل
    let sr = 0, sg = 0, sb = 0, sn = 0;
    const seed = i => { if (bg[i]) return; bg[i] = 1; q[qt++] = i; };
    for (let x = bx0; x <= bx1; x++) { [by0, by1].forEach(y => { const i = y * W + x; sr += L[i * 3]; sg += L[i * 3 + 1]; sb += L[i * 3 + 2]; sn++; seed(i); }); }
    for (let y = by0; y <= by1; y++) { [bx0, bx1].forEach(x => { const i = y * W + x; sr += L[i * 3]; sg += L[i * 3 + 1]; sb += L[i * 3 + 2]; sn++; seed(i); }); }
    sr /= sn; sg /= sn; sb /= sn;
    // تشتت لون الحواف ← عتبة تكيفية
    let dv = 0; for (let k = 0; k < qt; k++) { const i = q[k] * 3; dv += Math.hypot(L[i] - sr, L[i + 1] - sg, L[i + 2] - sb); } dv /= Math.max(1, qt);
    const TG = Math.max(70, Math.min(150, dv * 2.6 + 55)), TL = 14 + Math.min(10, dv * 0.25);
    while (qh < qt) {
      const i = q[qh++], x = i % W, y = (i - x) / W, a = i * 3;
      const nb = [x > bx0 ? i - 1 : -1, x < bx1 ? i + 1 : -1, y > by0 ? i - W : -1, y < by1 ? i + W : -1];
      for (const j of nb) {
        if (j < 0 || bg[j]) continue; const b = j * 3;
        const dl = Math.hypot(L[a] - L[b], L[a + 1] - L[b + 1], L[a + 2] - L[b + 2]);
        const dgl = Math.hypot(L[b] - sr, L[b + 1] - sg, L[b + 2] - sb);
        if (dl < TL && dgl < TG) { bg[j] = 1; q[qt++] = j; }
      }
    }
    const fg = new Uint8Array(N); let cnt = 0;
    for (let y = by0; y <= by1; y++) for (let x = bx0; x <= bx1; x++) { const i = y * W + x; if (!bg[i]) { fg[i] = 1; cnt++; } }
    // فتح مورفولوجي (إزالة النقاط) ثم إبقاء المكونات الكبيرة فقط
    const er = new Uint8Array(N);
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { const i = y * W + x; er[i] = fg[i] && fg[i - 1] && fg[i + 1] && fg[i - W] && fg[i + W] ? 1 : 0; }
    const di = new Uint8Array(N);
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { const i = y * W + x; di[i] = er[i] || er[i - 1] || er[i + 1] || er[i - W] || er[i + W] ? 1 : 0; }
    const lab = new Int32Array(N), sizes = [0]; let id = 0;
    for (let i = 0; i < N; i++) {
      if (!di[i] || lab[i]) continue; id++; let s = 0; qh = qt = 0; q[qt++] = i; lab[i] = id;
      while (qh < qt) { const k = q[qh++], x = k % W; s++; const nb = [x > 0 ? k - 1 : -1, x < W - 1 ? k + 1 : -1, k - W, k + W]; for (const j of nb) if (j >= 0 && j < N && di[j] && !lab[j]) { lab[j] = id; q[qt++] = j; } }
      sizes.push(s);
    }
    const big = Math.max(0, ...sizes), keep = sizes.map(s => s >= big * 0.06);
    const out = new Uint8Array(N); let area = 0;
    for (let i = 0; i < N; i++) if (lab[i] && keep[lab[i]]) { out[i] = 1; area++; }
    // ملء الثقوب: كل ما لا يصل إليه الخارج = مقدمة
    const reach = new Uint8Array(N); qh = qt = 0;
    for (let x = 0; x < W; x++) { [x, (H - 1) * W + x].forEach(i => { if (!out[i] && !reach[i]) { reach[i] = 1; q[qt++] = i; } }); }
    for (let y = 0; y < H; y++) { [y * W, y * W + W - 1].forEach(i => { if (!out[i] && !reach[i]) { reach[i] = 1; q[qt++] = i; } }); }
    while (qh < qt) { const k = q[qh++], x = k % W; const nb = [x > 0 ? k - 1 : -1, x < W - 1 ? k + 1 : -1, k - W, k + W]; for (const j of nb) if (j >= 0 && j < N && !out[j] && !reach[j]) { reach[j] = 1; q[qt++] = j; } }
    area = 0; for (let i = 0; i < N; i++) { out[i] = reach[i] ? 0 : 1; area += out[i]; }
    // تحدّب متعامد: يسد «العضّات» البيضاء في جوانب العلبة (يوجد منتج يميناً ويساراً وفوقاً وتحتاً)
    const rL = new Int32Array(H).fill(W), rR = new Int32Array(H).fill(-1), cT = new Int32Array(W).fill(H), cB = new Int32Array(W).fill(-1);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (out[y * W + x]) { if (x < rL[y]) rL[y] = x; if (x > rR[y]) rR[y] = x; if (y < cT[x]) cT[x] = y; if (y > cB[x]) cB[x] = y; }
    for (let y = 0; y < H; y++) for (let x = rL[y] + 1; x < rR[y]; x++) { const i = y * W + x; if (!out[i] && y > cT[x] && y < cB[x]) { out[i] = 1; area++; } }
    const boxA = (bx1 - bx0 + 1) * (by1 - by0 + 1);
    return { mask: out, ratio: area / Math.max(1, boxA), W, H };
  }
  function maskCanvas(mask, W, H) { const c = mk(W, H), x = c.getContext("2d"), d = x.createImageData(W, H); for (let i = 0; i < W * H; i++) { d.data[i * 4 + 3] = mask[i] ? 255 : 0; } x.putImageData(d, 0, 0); return c; }
  function rectMask(W, H, box) { const c = mk(W, H), x = c.getContext("2d"); x.fillStyle = "#000"; const r = Math.min(box[2] - box[0], box[3] - box[1]) * 0.02; x.beginPath(); if (x.roundRect) x.roundRect(box[0], box[1], box[2] - box[0], box[3] - box[1], r); else x.rect(box[0], box[1], box[2] - box[0], box[3] - box[1]); x.fill(); return c; }

  /* قص المنتج بدقة عالية: القناع (منخفض الدقة) يحدد المنطقة، ثم تُصقل الحواف على الصورة الأصلية
     بمفتاح لوني محلي (لون الخلفية حول كل جزء من الحافة) ← حواف حادة تتبع حدود المنتج الحقيقية */
  function applyMask(hi, mcv, coarse) {
    const W = hi.width, H = hi.height, N = W * H;
    const up = (blur) => { const t = mk(W, H), x = t.getContext("2d", { willReadFrequently: true }); x.imageSmoothingQuality = "high"; if (blur) x.filter = "blur(" + blur.toFixed(2) + "px)"; x.drawImage(mcv, 0, 0, W, H); return x.getImageData(0, 0, W, H).data; };
    const k = W / mcv.width, band = Math.max(2.5, coarse ? W / 110 : k * 1.6);
    const A = up(Math.max(0.6, k * 0.55)), Bd = up(band);   // القناع الناعم + القناع العريض (يحدد شريط الحافة)
    const ox = hi.getContext("2d", { willReadFrequently: true }), src = ox.getImageData(0, 0, W, H).data;
    // لون الخلفية لكل مربّع 40px من «الحلقة الخارجية» (خارج القناع وقريب منه)
    const T = Math.max(24, Math.round(W / 60)), gw = Math.ceil(W / T), gh = Math.ceil(H / T), G3 = new Float64Array(gw * gh * 4), GQ = new Float64Array(gw * gh);
    for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) {
      const i = y * W + x, a = A[i * 4 + 3], bw = Bd[i * 4 + 3];
      if (a < 6 && bw > 2) { const g = ((y / T) | 0) * gw + ((x / T) | 0), o = i * 4; G3[g * 4] += src[o]; G3[g * 4 + 1] += src[o + 1]; G3[g * 4 + 2] += src[o + 2]; G3[g * 4 + 3]++; GQ[g] += src[o] * src[o] + src[o + 1] * src[o + 1] + src[o + 2] * src[o + 2]; }
    }
    let tot = 0, tq = 0, tn = 0; const M = new Float32Array(gw * gh * 3), has = new Uint8Array(gw * gh);
    for (let g = 0; g < gw * gh; g++) { const n = G3[g * 4 + 3]; if (n >= 6) { has[g] = 1; M[g * 3] = G3[g * 4] / n; M[g * 3 + 1] = G3[g * 4 + 1] / n; M[g * 3 + 2] = G3[g * 4 + 2] / n; tn += n; tq += GQ[g]; tot += G3[g * 4] + G3[g * 4 + 1] + G3[g * 4 + 2]; } }
    // انتشار ألوان الخلفية للمربعات الفارغة (أقرب جار)
    for (let it = 0, left = 1; it < 60 && left; it++) {
      left = 0; const nh = has.slice();
      for (let gy = 0; gy < gh; gy++) for (let gx = 0; gx < gw; gx++) {
        const g = gy * gw + gx; if (has[g]) continue; let r = 0, gg = 0, b = 0, c = 0;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const xx = gx + dx, yy = gy + dy; if (xx < 0 || yy < 0 || xx >= gw || yy >= gh) continue; const q = yy * gw + xx; if (has[q]) { r += M[q * 3]; gg += M[q * 3 + 1]; b += M[q * 3 + 2]; c++; } }
        if (c) { M[g * 3] = r / c; M[g * 3 + 1] = gg / c; M[g * 3 + 2] = b / c; nh[g] = 1; } else left = 1;
      }
      has.set(nh);
    }
    // تشتت الخلفية ← عتبات المفتاح اللوني
    const mean = tn ? tot / (3 * tn) : 0, sd = tn ? Math.sqrt(Math.max(0, tq / (3 * tn) - mean * mean)) : 99;
    const useKey = tn > 50, t0 = Math.max(14, Math.min(46, 10 + sd * 0.35)), t1 = t0 + (coarse ? 30 : 38);
    const out = mk(W, H), cx = out.getContext("2d", { willReadFrequently: true }), d = cx.createImageData(W, H), p = d.data;
    let x0 = W, y0 = H, x1 = -1, y1 = -1;
    for (let y = 0; y < H; y++) {
      const gy = Math.min(gh - 1, (y / T) | 0);
      for (let x = 0; x < W; x++) {
        const i = y * W + x, o = i * 4; let a = A[o + 3] / 255; const bw = Bd[o + 3] / 255;
        p[o] = src[o]; p[o + 1] = src[o + 1]; p[o + 2] = src[o + 2];
        if (useKey && bw > 0.01 && bw < 0.99) {   // شريط الحافة
          const g = gy * gw + Math.min(gw - 1, (x / T) | 0), dr = src[o] - M[g * 3], dg = src[o + 1] - M[g * 3 + 1], db = src[o + 2] - M[g * 3 + 2];
          const dist = Math.sqrt(dr * dr * 0.3 + dg * dg * 0.59 + db * db * 0.11) * 1.7 + Math.abs(dr - dg) * 0.25 + Math.abs(db - dg) * 0.25;
          let kA = (dist - t0) / (t1 - t0); kA = kA < 0 ? 0 : kA > 1 ? 1 : kA; kA = kA * kA * (3 - 2 * kA);
          // داخل القناع بوضوح نثق بالمفتاح فقط إن كان قريباً من الخلفية جداً؛ خارجه لا نقبل إلا ما يختلف بوضوح
          a = bw >= 0.5 ? Math.min(1, Math.max(kA, a > 0.9 && kA > 0.15 ? 1 : kA)) : (kA > 0.85 && a > 0.05 ? kA : Math.min(kA, a));
        } else { a = Math.min(1, Math.max(0, (a - 0.28) / 0.44)); a = a * a * (3 - 2 * a); }
        p[o + 3] = Math.round(a * 255);
        if (a > 0.04) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
      }
    }
    cx.putImageData(d, 0, 0);
    if (x1 < 0) return null;
    return out;
  }
  /* قص الشفافية ← أصغر مستطيل يحوي المنتج */
  function cropAlpha(full) {
    const W = full.width, H = full.height, d = full.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, W, H).data;
    let x0 = W, y0 = H, x1 = -1, y1 = -1;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (d[(y * W + x) * 4 + 3] > 10) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 < 0) return null;
    const c = mk(x1 - x0 + 1, y1 - y0 + 1); c.getContext("2d").drawImage(full, -x0, -y0); return c;
  }
  /* تحسين بثلاث مستويات للتفاصيل: 0 عادي، 1 قوي، 2 أقصى
     مستويات تلقائية + توازن أبيض لطيف + تشبع + «وضوح» (تباين محلي) + حدة دقيقة بعتبة (لا تُضخّم الضجيج) */
  function enhance(c, lvl) {
    lvl = lvl == null ? 1 : lvl;
    const W = c.width, H = c.height, x = c.getContext("2d", { willReadFrequently: true }), d = x.getImageData(0, 0, W, H), p = d.data;
    const hist = [new Uint32Array(256), new Uint32Array(256), new Uint32Array(256)]; let n = 0;
    for (let i = 0; i < p.length; i += 4) if (p[i + 3] > 200) { hist[0][p[i]]++; hist[1][p[i + 1]]++; hist[2][p[i + 2]]++; n++; }
    if (n > 50) {
      const pct = (h, f) => { let s = 0; const t = n * f; for (let v = 0; v < 256; v++) { s += h[v]; if (s >= t) return v; } return 255; };
      const lo = Math.min(pct(hist[0], 0.003), pct(hist[1], 0.003), pct(hist[2], 0.003));
      const hiR = pct(hist[0], 0.997), hiG = pct(hist[1], 0.997), hiB = pct(hist[2], 0.997), hiAll = Math.max(hiR, hiG, hiB);
      const gain = ch => Math.min(1.5, 255 / Math.max(1, (ch * 0.6 + hiAll * 0.4) - lo * 0.85));
      const gR = gain(hiR), gG = gain(hiG), gB = gain(hiB), off = lo * 0.85, sat = [1.05, 1.1, 1.14][lvl], gam = [0.97, 0.94, 0.92][lvl];
      const LUT = [gR, gG, gB].map(g => { const l = new Uint8ClampedArray(256); for (let v = 0; v < 256; v++) { let t = (v - off) * g / 255; t = Math.max(0, Math.min(1, t)); t = Math.pow(t, gam); l[v] = t * 255; } return l; });
      for (let i = 0; i < p.length; i += 4) {
        if (!p[i + 3]) continue;
        let r = LUT[0][p[i]], g = LUT[1][p[i + 1]], b = LUT[2][p[i + 2]];
        const y = 0.299 * r + 0.587 * g + 0.114 * b; r = y + (r - y) * sat; g = y + (g - y) * sat; b = y + (b - y) * sat;
        p[i] = r; p[i + 1] = g; p[i + 2] = b;
      }
      x.putImageData(d, 0, 0);
    }
    const usm = (radius, amount, thr) => {
      const bl = mk(W, H), bx = bl.getContext("2d", { willReadFrequently: true }); bx.filter = "blur(" + radius.toFixed(2) + "px)"; bx.drawImage(c, 0, 0);
      const bd = bx.getImageData(0, 0, W, H).data, d2 = x.getImageData(0, 0, W, H), q = d2.data;
      for (let i = 0; i < q.length; i += 4) {
        if (q[i + 3] < 8) continue;
        const l0 = q[i] * 0.299 + q[i + 1] * 0.587 + q[i + 2] * 0.114, l1 = bd[i] * 0.299 + bd[i + 1] * 0.587 + bd[i + 2] * 0.114, dl = l0 - l1;
        if (Math.abs(dl) < thr) continue;
        const add = dl * amount; q[i] += add; q[i + 1] += add; q[i + 2] += add;   // حدة على الإضاءة فقط (بدون هالات لونية)
      }
      x.putImageData(d2, 0, 0);
    };
    usm(Math.max(6, W / 140), [0.14, 0.26, 0.38][lvl], 1);          // وضوح / تباين محلي
    usm(Math.max(0.7, W / 1800), [0.45, 0.8, 1.15][lvl], [3, 2, 2][lvl]); // حدة التفاصيل والكتابة
    return c;
  }
  const dupC = c0 => { const c = mk(c0.width, c0.height); c.getContext("2d").drawImage(c0, 0, 0); return c; };
  /* تركيب صورة الكتالوج: خلفية + ظل + انعكاس + (قطعة أمام العلبة) */
  function compose(A, B, o) {
    const S = 2000, c = mk(S, S), x = c.getContext("2d");
    if (o.bg === "soft") { const g = x.createRadialGradient(S / 2, S * 0.42, S * 0.1, S / 2, S * 0.5, S * 0.75); g.addColorStop(0, "#ffffff"); g.addColorStop(1, "#e9edf2"); x.fillStyle = g; }
    else if (o.bg === "gray") x.fillStyle = "#f2f3f5"; else x.fillStyle = "#ffffff";
    x.fillRect(0, 0, S, S);
    const fit = (im, mw, mh) => { const k = Math.min(mw / im.width, mh / im.height); return [im.width * k, im.height * k]; };
    const shadow = (cx, bottom, w, h) => {
      if (!o.shadow) return;
      x.save(); x.translate(cx, bottom); x.scale(1, 0.11);
      let g = x.createRadialGradient(0, 0, 0, 0, 0, w * 0.62); g.addColorStop(0, "rgba(20,28,40,.30)"); g.addColorStop(0.55, "rgba(20,28,40,.12)"); g.addColorStop(1, "rgba(20,28,40,0)");
      x.fillStyle = g; x.beginPath(); x.arc(0, 0, w * 0.62, 0, Math.PI * 2); x.fill(); x.restore();
      x.save(); x.translate(cx, bottom - 1); x.scale(1, 0.035);
      g = x.createRadialGradient(0, 0, 0, 0, 0, w * 0.5); g.addColorStop(0, "rgba(10,14,20,.38)"); g.addColorStop(1, "rgba(10,14,20,0)");
      x.fillStyle = g; x.beginPath(); x.arc(0, 0, w * 0.5, 0, Math.PI * 2); x.fill(); x.restore();
    };
    const refl = (im, cx, bottom, w, h) => {
      if (!o.refl) return;
      const t = mk(w, h * 0.32), tx = t.getContext("2d");
      tx.save(); tx.translate(0, h); tx.scale(1, -1); tx.drawImage(im, 0, 0, w, h); tx.restore();
      tx.globalCompositeOperation = "destination-in"; const g = tx.createLinearGradient(0, 0, 0, t.height); g.addColorStop(0, "rgba(0,0,0,.22)"); g.addColorStop(1, "rgba(0,0,0,0)"); tx.fillStyle = g; tx.fillRect(0, 0, w, t.height);
      x.drawImage(t, cx - w / 2, bottom + 2);
    };
    const put = (im, cx, bottom, w, h) => { shadow(cx, bottom, w, h); refl(im, cx, bottom, w, h); x.drawImage(im, cx - w / 2, bottom - h, w, h); };
    if (!B) {
      const [w, h] = fit(A, S * 0.80, S * (o.refl ? 0.66 : 0.74)), bottom = S * (o.refl ? 0.80 : 0.87);
      put(A, S / 2, bottom, w, h);
    } else {
      const [w, h] = fit(A, S * 0.74, S * 0.60), [w2, h2] = fit(B, Math.max(w * 0.92, S * 0.5), S * 0.30);
      const bb = S * 0.70, fb = Math.min(S * 0.93, bb + h2 * 0.75);
      put(A, S * 0.55, bb, w, h);
      put(B, S * 0.45, fb, w2, h2);
    }
    return c;
  }
  /* صورة الذكاء الاصطناعي ← مربع 1200 على أبيض */
  async function squareOf(url) { const im = await loadImg(url), S = 2000, c = mk(S, S), x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, S, S); const k = Math.min(S / im.naturalWidth, S / im.naturalHeight), w = im.naturalWidth * k, h = im.naturalHeight * k; x.imageSmoothingQuality = "high"; x.drawImage(im, (S - w) / 2, (S - h) / 2, w, h); return c; }

  /* ================================================================== الذكاء الاصطناعي: قراءة المنتج + قناع العزل */
  const INFO_PROMPT = `You are helping a grocery/wholesale shop in Algeria register a product in its POS. Look at the photo(s) of the product packaging (first photo = the box / main package; a second photo, if present, = one single piece from inside it).
Read ONLY what is actually printed. Return ONE single JSON object (NOT a list, even when there are two photos), no prose:
{"brand":"brand name as printed (Latin)","product":"product name/flavor as printed","name_ar":"Arabic name if printed, else a short Arabic description (e.g. شوكولاتة بجوز الهند)","pieces":integer number of pieces/units inside the box as printed (from 'x24', '24 pcs', '24×', '24 قطعة'...) or 0 if not printed,"piece":"what one piece is, e.g. 'bar x2 40g' or ''","weight":"net weight / volume printed, e.g. '40g', '1L' or ''","barcode":"EAN/UPC digits only if clearly readable, else ''","category":"one short Arabic category: بسكويت / شوكولاتة / حلويات / شيبس / مشروبات / عصير / ماء / حليب و أجبان / منظفات / مواد غذائية / تجميل / أخرى","suggest":"POS item name in the shop style: BRAND + (pieces then P if pieces>1, e.g. 24P) + short Arabic description, e.g. 'COCOS 24P شوكولاتة جوز الهند'","box":[ymin,xmin,ymax,xmax] tight bounding box (0-1000 normalized) of the main product in the FIRST photo,"piece_box":[ymin,xmin,ymax,xmax] of the single piece in the SECOND photo or [] ,"plain_bg":true if the background around the product is plain/uniform}`;
  const SEG_PROMPT = `Give the segmentation mask for the ONE main retail product package in this photo (the whole box / pack / bottle, including its lid or flaps).
EXCLUDE everything that is not the product: human hands, fingers and arms holding it, the table, shelves, other products and the background.
Output a JSON list with at most 2 entries; each entry contains the 2D bounding box in the key "box_2d", the segmentation mask in key "mask", and the text label in the key "label".`;
  const POLY_PROMPT = `Trace the outer outline of the ONE main retail product package in this photo (box / pack / bottle), as precisely as possible.
The outline must EXCLUDE human hands, fingers and arms holding the product, the table, shelves, other products and the background — if fingers cover part of the product, go around the fingers (do not include them).
Return strict JSON only: {"polygons":[[[y,x],[y,x],...]]} with coordinates normalized 0-1000, 24 to 80 points per polygon, clockwise. Use one polygon unless the product has separate visible parts.`;
  const segModels = l => {
    const R = [/^gemini-2\.5-flash$/, /^gemini-2\.5-flash(?!-lite)(?!.*(image|tts|audio|live))/, /^gemini-2\.5-pro$/, /^gemini-2\.5-flash-lite$/];
    const out = []; R.forEach(re => l.filter(n => re.test(n)).sort((a, b) => (/preview/.test(a) ? 1 : 0) - (/preview/.test(b) ? 1 : 0)).forEach(n => { if (!out.includes(n)) out.push(n); }));
    return out.slice(0, 2);
  };
  const polyModels = l => { const t = textModels(l); const pro = l.filter(n => /^gemini-(2\.5|[3-9][\d.]*)-pro$/.test(n)); return t.slice(0, 2).concat(pro.slice(0, 1)).filter((v, i, a) => a.indexOf(v) === i).slice(0, 3); };
  /* توحيد رد القراءة: قائمة (صورة لكل عنصر) ← دمج، كائن متداخل ← تسطيح، أسماء حقول بديلة */
  function normInfo(v) {
    if (!v || typeof v !== "object") return null;
    const flat = o => { if (!o || typeof o !== "object" || Array.isArray(o)) return {}; let r = Object.assign({}, o); ["product", "info", "result", "data", "item"].forEach(k => { if (r[k] && typeof r[k] === "object" && !Array.isArray(r[k])) { r = Object.assign({}, r[k], r); if (typeof r[k] === "object") delete r[k]; } }); return r; };
    const L = Array.isArray(v) ? v.map(flat) : [flat(v)], o = {};
    L.forEach(x => Object.keys(x).forEach(k => { const val = x[k]; if (o[k] == null || o[k] === "" || (Array.isArray(o[k]) && !o[k].length) || o[k] === 0) o[k] = val; }));
    const pick = (...ks) => { for (const k of ks) { const x = o[k]; if (x != null && x !== "" && !(Array.isArray(x) && !x.length)) return x; } return ""; };
    const str = x => typeof x === "string" ? x.trim() : x == null ? "" : typeof x === "object" ? "" : String(x);
    const n = parseInt(String(pick("pieces", "count", "pcs", "qty", "quantity", "pieces_count", "units") || "").replace(/[^\d]/g, ""), 10) || 0;
    const out = { brand: str(pick("brand", "marque", "company")), product: str(pick("product_name", "product", "name", "title", "flavor")), name_ar: str(pick("name_ar", "arabic", "arabic_name")),
      pieces: n, piece: str(pick("piece", "per_piece", "unit_desc")), weight: str(pick("weight", "net_weight", "volume")), barcode: str(pick("barcode", "ean", "gtin")).replace(/\D/g, ""),
      category: str(pick("category", "type")), suggest: str(pick("suggest", "pos_name", "suggested_name")), box: Array.isArray(o.box) ? o.box : Array.isArray(o.box_2d) ? o.box_2d : null, piece_box: Array.isArray(o.piece_box) ? o.piece_box : null };
    if (typeof o.product === "object") out.product = "";
    return out.brand || out.product || out.name_ar || out.suggest || out.pieces ? out : null;
  }
  async function aiInfo(imgs) {
    let r = null, err = null;
    if (gKey()) { try { r = await gJSON(INFO_PROMPT, imgs); } catch (e) { err = e; console.warn("Gemini info failed", e); } }
    if ((!r || !normInfo(r.v)) && await claudeOK()) { try { r = await claudeJSON(INFO_PROMPT, imgs); } catch (e) { err = err || e; } }
    // محاولة ثانية بصورة العلبة وحدها إن لم يُقرأ شيء
    if ((!r || !normInfo(r.v)) && gKey() && imgs.length > 1) { try { r = await gJSON(INFO_PROMPT, imgs.slice(0, 1)); } catch (e) { err = err || e; } }
    if (!r) throw err || new Error("no-key");
    const v = normInfo(r.v); if (!v) { console.warn("info raw", r.v); throw new Error("لم يُقرأ نص واضح على العلبة"); }
    return { v, model: r.model };
  }
  async function aiMask(url, W, H) {
    if (!gKey()) return null;
    const r = await gJSON(SEG_PROMPT, [url], { models: segModels, max: 32000 });
    const L = Array.isArray(r.v) ? r.v : r.v && (r.v.masks || r.v.items) || [];
    const c = mk(W, H), x = c.getContext("2d"); let n = 0;
    for (const it of L) {
      const b = it.box_2d || it.box; if (!b || b.length < 4 || !it.mask) continue;
      if (/hand|finger|arm|person|table|shelf/i.test(it.label || "")) continue;
      const y0 = b[0] / 1000 * H, x0 = b[1] / 1000 * W, y1 = b[2] / 1000 * H, x1 = b[3] / 1000 * W; if (x1 - x0 < 4 || y1 - y0 < 4) continue;
      const m = await loadImg(/^data:/.test(it.mask) ? it.mask : "data:image/png;base64," + it.mask).catch(() => null); if (!m) continue;
      const t = mk(x1 - x0, y1 - y0), tx = t.getContext("2d"); tx.drawImage(m, 0, 0, t.width, t.height);
      const d = tx.getImageData(0, 0, t.width, t.height); for (let i = 0; i < d.data.length; i += 4) { const v = d.data[i]; d.data[i + 3] = v > 127 ? 255 : 0; d.data[i] = d.data[i + 1] = d.data[i + 2] = 0; } tx.putImageData(d, 0, 0);
      x.drawImage(t, x0, y0); n++;
    }
    if (!n) return null;
    let a = 0; const dd = x.getImageData(0, 0, W, H).data; for (let i = 3; i < dd.length; i += 4) if (dd[i]) a++;
    return a / (W * H) > 0.02 ? c : null;
  }
  /* بديل يعمل مع كل نماذج Gemini (بما فيها 3.x): مضلّع حدود المنتج يستثني اليد */
  async function aiPoly(url, W, H) {
    if (!gKey()) return null;
    const r = await gJSON(POLY_PROMPT, [url], { models: polyModels, max: 6000 });
    const P = (r.v && (r.v.polygons || r.v.polygon && [r.v.polygon])) || (Array.isArray(r.v) ? r.v : []);
    const c = mk(W, H), x = c.getContext("2d"); x.fillStyle = "#000"; let n = 0;
    for (const poly of P) {
      const pts = (poly || []).map(q => Array.isArray(q) ? q : q && [q.y, q.x]).filter(q => q && q.length >= 2 && isFinite(q[0]) && isFinite(q[1]));
      if (pts.length < 4) continue;
      x.beginPath(); pts.forEach((q, i) => { const px = q[1] / 1000 * W, py = q[0] / 1000 * H; if (i) x.lineTo(px, py); else x.moveTo(px, py); }); x.closePath(); x.fill(); n++;
    }
    if (!n) return null;
    let a = 0; const dd = x.getImageData(0, 0, W, H).data; for (let i = 3; i < dd.length; i += 4) if (dd[i]) a++;
    return a / (W * H) > 0.02 ? c : null;
  }
  const boxPx = (b, W, H) => b && b.length === 4 && b[2] > b[0] && b[3] > b[1] ? [b[1] / 1000 * W, b[0] / 1000 * H, b[3] / 1000 * W, b[2] / 1000 * H].map(Math.round) : null;

  /* صورة واحدة ← منتج معزول: قناع Gemini ← مضلّع Gemini ← عزل محلي ← حدود المنتج */
  async function cutout(url, box, useAI, prog) {
    const im = await loadImg(url), hi = fitCanvas(im, 2400), lo = fitCanvas(im, 900);
    let mcv = null, how = "", why = "";
    if (useAI) {
      const small = jpg(fitCanvas(im, 1024), 0.9);
      prog && prog("seg", "run", "قناع الذكاء الاصطناعي…");
      try { mcv = await aiMask(small, lo.width, lo.height); if (mcv) how = "ai"; } catch (e) { why = e.message || String(e); console.warn("AI mask failed", e); }
      if (!mcv) { prog && prog("seg", "run", "تحديد حدود المنتج بالذكاء الاصطناعي…"); try { mcv = await aiPoly(small, lo.width, lo.height); if (mcv) how = "poly"; } catch (e) { why = e.message || String(e); console.warn("AI poly failed", e); } }
    }
    if (!mcv) {
      prog && prog("seg", "run", ""); await sleep(20);
      const b = boxPx(box, lo.width, lo.height), r = localMask(lo, b);
      if (r.ratio > (b ? 0.12 : 0.03) && r.ratio < 0.985) { mcv = maskCanvas(r.mask, lo.width, lo.height); how = "local"; }
      else if (b) { mcv = rectMask(lo.width, lo.height, b); how = "box"; }
      else { mcv = rectMask(lo.width, lo.height, [0, 0, lo.width, lo.height]); how = "none"; }
    }
    await sleep(20);
    const full = applyMask(hi, mcv, how === "ai" || how === "poly") || (() => { const c = dupC(hi); return c; })();
    prog && prog("seg", "ok", how === "ai" ? "قناع الذكاء الاصطناعي" : how === "poly" ? "حدود بالذكاء الاصطناعي" : why ? "عزل محلي (" + why.slice(0, 60) + ")" : "");
    return { full, hi, raw: cropAlpha(full) || hi, how };
  }
  const GEN_PROMPT = (info, two) => {
    const n = info && +info.pieces > 1 ? +info.pieces : 0;
    return `Create a professional high-resolution e-commerce catalog photo of the EXACT product shown in the reference photo${two ? "s (photo 1 = the box, photo 2 = one single piece)" : ""}.
Reproduce the packaging faithfully: identical shape, proportions, colors, logo, brand name, artwork and every printed word — do not translate, change, invent or misspell any text${info && info.brand ? ` (the brand is "${info.brand}")` : ""}.
Composition: ${n || two ? `the retail display box${n ? ` (containing ${n} pieces)` : ""} standing at the back, slightly open showing the pieces inside, and ONE single individual piece lying in front of it at a slight angle — the single piece must look exactly like the piece shown${two ? " in photo 2" : " in the box artwork"}.` : `the product alone, centered, in a flattering 3/4 view.`}
Pure white seamless background (#FFFFFF), soft diffused studio lighting, subtle natural contact shadow, crisp sharp focus, photorealistic, square 1:1, no hands, no props, no extra text, no watermark.`;
  };

  /* ================================================================== تواريخ المنتج (QR / GS1 أو من الصورة) — 2026
     مصدران: 1) رمز QR / DataMatrix / GS1-128 (دقيق 100% — يُفكّ محلياً بلا إنترنت) ، 2) التاريخ المطبوع على العلبة (ذكاء اصطناعي)
     الدقة في القراءة من الصورة: النص يُنسخ حرفياً ثم نحلّله محلياً ونقارنه بتفسير النموذج ، ثم قراءة ثانية على منطقة التاريخ مكبَّرة
     — تطابق القراءتين = «تأكيد مزدوج ✓✓» ، وإلا «تحقّق ⚠» مع صورة مكبّرة للتاريخ بجانب الحقول. */
  const p2 = n => String(n).padStart(2, "0");
  const todayISO = () => { const d = new Date(); return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()); };
  /* عرض التاريخ للمستخدم: يوم/شهر/سنة — معزول الاتجاه حتى لا ينقلب داخل النص العربي */
  const fmtD = iso => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || "")); return m ? "\u2066" + m[3] + "/" + m[2] + "/" + m[1] + "\u2069" : String(iso || ""); };
  const dayDiff = (a, b) => Math.round((new Date(b + "T00:00:00") - new Date(a + "T00:00:00")) / 864e5);
  const lastDay = (y, m) => new Date(y, m, 0).getDate();
  const MONTHS = [["JANVIER", "JANUARY", "JANV", "JAN", "يناير", "جانفي", "كانون الثاني"], ["FEVRIER", "FÉVRIER", "FEBRUARY", "FEVR", "FÉVR", "FEV", "FÉV", "FEB", "فبراير", "فيفري", "شباط"], ["MARS", "MARCH", "MAR", "مارس", "آذار"],
    ["AVRIL", "APRIL", "AVR", "APR", "أبريل", "ابريل", "أفريل", "افريل", "نيسان"], ["MAI", "MAY", "مايو", "ماي", "أيار"], ["JUIN", "JUNE", "JUN", "يونيو", "جوان", "حزيران"], ["JUILLET", "JULY", "JUIL", "JUL", "يوليو", "جويلية", "تموز"],
    ["AOUT", "AOÛT", "AUGUST", "AOU", "AUG", "أغسطس", "اغسطس", "أوت", "اوت", "آب"], ["SEPTEMBRE", "SEPTEMBER", "SEPT", "SEP", "سبتمبر", "أيلول"], ["OCTOBRE", "OCTOBER", "OCT", "أكتوبر", "اكتوبر", "تشرين الأول"],
    ["NOVEMBRE", "NOVEMBER", "NOV", "نوفمبر", "تشرين الثاني"], ["DECEMBRE", "DÉCEMBRE", "DECEMBER", "DEC", "DÉC", "ديسمبر", "كانون الأول"]];
  const validYMD = (y, m, d) => y >= 2000 && y <= 2099 && m >= 1 && m <= 12 && d >= 1 && d <= lastDay(y, m);
  /* نص التاريخ المطبوع ← { iso, prec:"day"|"month", amb } — ترتيب الجزائر/أوروبا: يوم/شهر/سنة ؛ شهر/سنة = آخر يوم في الشهر للصلاحية وأوله للإنتاج */
  function parseDateText(txt, kind) {
    let t = String(txt == null ? "" : txt).trim(); if (!t) return null;
    t = t.replace(/[٠-٩]/g, c => "٠١٢٣٤٥٦٧٨٩".indexOf(c)).replace(/[۰-۹]/g, c => "۰۱۲۳۴۵۶۷۸۹".indexOf(c)).toUpperCase();
    MONTHS.forEach((names, i) => names.forEach(n => { t = t.replace(new RegExp("(^|[^A-ZÀ-Üء-ي])" + n.toUpperCase() + "\\.?(?![A-ZÀ-Üء-ي])", "g"), "$1/" + p2(i + 1) + "/"); }));
    t = t.replace(/\s*[\/.\-]\s*/g, "/").replace(/\/+/g, "/").replace(/(\d)\s+(?=\d)/g, "$1/").replace(/(\d)O(?=\d|\/|$)/g, "$10").replace(/(^|\/)O(?=\d)/g, "$10");
    const Y = y => y < 100 ? 2000 + y : y, mk3 = (y, m, d, amb) => validYMD(y, m, d) ? { iso: y + "-" + p2(m) + "-" + p2(d), prec: "day", amb: amb || false } : null,
      mk2 = (y, m) => validYMD(y, m, 1) ? { iso: y + "-" + p2(m) + "-" + p2(kind === "prod" ? 1 : lastDay(y, m)), prec: "month", amb: false } : null;
    let m, r;
    if ((m = /(?:^|\D)(20\d\d)\/(\d{1,2})\/(\d{1,2})(?!\d)/.exec(t)) && (r = mk3(+m[1], +m[2], +m[3]))) return r;
    if ((m = /(?:^|\D)(\d{1,2})\/(\d{1,2})\/(20\d\d)(?!\d)/.exec(t))) { if ((r = mk3(+m[3], +m[2], +m[1], +m[1] <= 12 && +m[2] <= 12 && +m[1] !== +m[2] ? "order" : false))) return r; if ((r = mk3(+m[3], +m[1], +m[2], "hard"))) return r; }
    if ((m = /(?:^|\D)(\d{1,2})\/(\d{1,2})\/(\d{2})(?!\d)/.exec(t))) { if ((r = mk3(Y(+m[3]), +m[2], +m[1], "hard"))) return r; }
    if ((m = /(?:^|\D)(\d{1,2})\/(20\d\d)(?!\d)/.exec(t)) && (r = mk2(+m[2], +m[1]))) return r;
    if ((m = /(?:^|\D)(20\d\d)\/(\d{1,2})(?!\d)/.exec(t)) && (r = mk2(+m[1], +m[2]))) return r;
    if ((m = /(?:^|\D)(\d{1,2})\/(\d{2})(?!\d)/.exec(t)) && +m[2] >= 20 && (r = mk2(Y(+m[2]), +m[1]))) { r.amb = "hard"; return r; }
    if ((m = /(?:^|\D)(\d{2})(\d{2})(20\d\d)(?!\d)/.exec(t)) && (r = mk3(+m[3], +m[2], +m[1]))) return r;       // DDMMYYYY
    if ((m = /(?:^|\D)(20\d\d)(\d{2})(\d{2})(?!\d)/.exec(t)) && (r = mk3(+m[1], +m[2], +m[3]))) return r;       // YYYYMMDD
    if ((m = /(?:^|\D)(\d{2})(\d{2})(\d{2})(?!\d)/.exec(t))) { if ((r = mk3(Y(+m[3]), +m[2], +m[1], "hard"))) return r; if ((r = mk3(Y(+m[1]), +m[2], +m[3], "hard"))) return r; }   // DDMMYY ثم YYMMDD
    return null;
  }
  const isoOf = (v, kind) => { v = String(v || "").trim(); let m = /^(20\d\d)-(\d{2})-(\d{2})$/.exec(v); if (m && validYMD(+m[1], +m[2], +m[3])) return v; m = /^(20\d\d)-(\d{1,2})$/.exec(v); if (m && validYMD(+m[1], +m[2], 1)) return m[1] + "-" + p2(+m[2]) + "-" + p2(kind === "prod" ? 1 : lastDay(+m[1], +m[2])); const r = parseDateText(v, kind); return r ? r.iso : ""; };
  const addSpan = (iso, txt) => {   // «12 شهر» / «18 months» / «24 mois» / «2 ans» / «90 jours» من تاريخ الإنتاج
    const t = String(txt || "").replace(/[٠-٩]/g, c => "٠١٢٣٤٥٦٧٨٩".indexOf(c)), m = /(\d{1,3})\s*(MONTHS?|MOIS|شهر|أشهر|اشهر|شهرا|YEARS?|ANS?|ANN[EÉ]ES?|سنة|سنوات|عام|DAYS?|JOURS?|يوم|أيام|ايام|WEEKS?|SEMAINES?|أسبوع|اسبوع|أسابيع)/i.exec(t); if (!m || !iso) return "";
    const n = +m[1], u = m[2].toUpperCase(), d = new Date(iso + "T00:00:00");
    if (/MONTH|MOIS|شهر/.test(u)) d.setMonth(d.getMonth() + n); else if (/YEAR|AN|سن|عام/.test(u)) d.setFullYear(d.getFullYear() + n); else if (/WEEK|SEMAINE|سبوع|سابيع/.test(u)) d.setDate(d.getDate() + n * 7); else d.setDate(d.getDate() + n);
    return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate());
  };
  const DATE_PROMPT = `You are reading the DATE MARKING printed on a retail product package for a shop in Algeria (labels may be in Arabic, French or English).
Find the expiry / best-before date, the production (manufacturing) date and the lot/batch number. These are usually ink-jet, dot-matrix, laser-etched or embossed characters, often small, near labels such as:
EXP, EXPIRY, E:, BB, BBE, BEST BEFORE, USE BY, PER, DLC, DDM, DLUO, "A consommer avant", "A consommer de préférence avant", "تاريخ الانتهاء", "تاريخ انتهاء الصلاحية", "صالح لغاية", "ينتهي في", "يستهلك قبل" (expiry)
— FAB, MFG, MFD, PROD, P:, F:, PKD, "Fabriqué le", "Date de fabrication", "تاريخ الإنتاج", "تاريخ الصنع" (production) — LOT, L:, BATCH, B.N., "N° de lot", "رقم الحصة", "التشغيلة", "رقم التشغيلة" (lot).
RULES — accuracy matters more than completeness:
1. First TRANSCRIBE the characters exactly as printed (keep separators, do not reorder, do not fix). Convert Arabic-Indic digits to 0-9. If a character is unreadable write "?" in its place — never guess a digit.
2. Then interpret: the date order in Algeria/Europe is DAY/MONTH/YEAR (never month/day/year). "03/2027" or "03 27" = month/year. A 2-digit year means 20YY.
3. If two dates are printed without labels, the earlier one is production and the later one is expiry.
4. If only a production date plus a shelf life is printed (e.g. "صالح لمدة 12 شهرا من تاريخ الإنتاج", "à consommer dans les 24 mois"), put that in "shelf_life" and leave "expiry" empty.
5. Do NOT confuse dates with barcodes, phone numbers, weights, prices or standards numbers. If no date marking is visible return found=false.
Return ONE JSON object only, no prose:
{"found":true|false,"expiry_text":"exact transcription or ''","expiry":"YYYY-MM-DD, or YYYY-MM when no day is printed, or ''","production_text":"","production":"YYYY-MM-DD or YYYY-MM or ''","lot":"lot/batch as printed or ''","shelf_life":"e.g. '12 months' or ''","photo":index (0-based) of the photo where the date marking is,"box":[ymin,xmin,ymax,xmax] tight box (0-1000 normalized) around the whole date marking area in that photo or [],"confidence":number 0..1 (how sure you are about EVERY digit)}`;
  const DATE_ZOOM_PROMPT = `This is an enlarged crop of the date marking printed on a product package (Algeria: dates are DAY/MONTH/YEAR; "MM/YYYY" when no day; 2-digit year = 20YY; labels may be Arabic/French/English: EXP/PER/DLC/DDM/"تاريخ الانتهاء" = expiry, FAB/MFG/PROD/"تاريخ الإنتاج" = production, LOT/L:/"التشغيلة" = lot).
Transcribe every character exactly as printed (Arabic-Indic digits → 0-9; unreadable character → "?"; never guess), then interpret. If two unlabeled dates: earlier = production, later = expiry.
Return ONE JSON object only: {"expiry_text":"","expiry":"YYYY-MM-DD or YYYY-MM or ''","production_text":"","production":"YYYY-MM-DD or YYYY-MM or ''","lot":"","shelf_life":"","confidence":0..1}`;
  async function askAI(prompt, imgs, max) {
    let r = null, err = null;
    if (gKey()) { try { r = await gJSON(prompt, imgs, { max: max || 1024, models: textModels }); } catch (e) { err = e; console.warn("Gemini dates failed", e); } }
    if (!r && await claudeOK()) { try { r = await claudeJSON(prompt, imgs); } catch (e) { err = err || e; } }
    if (!r) throw err || new Error("no-key");
    let v = r.v; if (Array.isArray(v)) v = v.find(x => x && typeof x === "object" && (x.expiry || x.expiry_text || x.production || x.production_text)) || v[0] || {};
    return { v: v && typeof v === "object" ? v : {}, model: r.model };
  }
  /* قراءة واحدة ← { exp, prod, lot, expText, prodText, amb, bad, conf } */
  function readOne(v) {
    const S1 = x => typeof x === "string" ? x.trim() : x == null || typeof x === "object" ? "" : String(x);
    const o = { expText: S1(v.expiry_text || v.exp_text), prodText: S1(v.production_text || v.prod_text), lot: S1(v.lot || v.batch).replace(/^(?:LOT|BATCH|B\.?N\.?|N°\s*(?:DE\s*)?LOT)\s*[:.\-]?\s*|^L\s*[:\-]\s*/i, ""), life: S1(v.shelf_life), conf: Math.max(0, Math.min(1, +v.confidence || 0)) };
    /* a = تفسير النموذج ، p = تحليلنا المحلي للنص المنسوخ حرفياً
       تطابقا ⇒ موثوق ؛ اختلفا ⇒ ترتيب يوم/شهر يُحسم بعُرف الجزائر (تحليلنا) ، والصيغ الملتبسة فعلاً (سنة برقمين / 6 أرقام) أو حرف غير مقروء «?» ⇒ تفسير النموذج — مع «تحقّق» */
    const side = (iso, text, kind) => {
      const a = isoOf(iso, kind), q = /\?/.test(text), p = text ? parseDateText(text, kind) : null;
      if (p && a && p.iso === a) return { d: a, ok: !q };
      if (p && a) { const useA = q || p.amb === "hard"; return { d: useA ? a : p.iso, ok: false, alt: useA ? p.iso : a }; }
      if (p) return { d: p.iso, ok: !q && p.amb !== "hard" };
      if (a) return { d: a, ok: !q && !text };
      return { d: "", ok: false };
    };
    const E = side(v.expiry, o.expText, "exp"), P = side(v.production, o.prodText, "prod");
    o.exp = E.d; o.prod = P.d; o.expOk = E.ok; o.prodOk = P.ok; o.expAlt = E.alt || "";
    if (!o.exp && o.prod && o.life) { const x = addSpan(o.prod, o.life); if (x) { o.exp = x; o.calc = true; o.expOk = o.prodOk; } }
    if (o.exp && o.prod && o.exp < o.prod) { const t = o.exp; o.exp = o.prod; o.prod = t; o.expOk = o.prodOk = false; }
    if (/\?/.test(o.lot)) o.lotBad = true;
    return o;
  }
  /* قصّ منطقة التاريخ وتكبيرها (للقراءة الثانية ولعرضها بجانب الحقول) */
  async function cropDate(url, box) {
    if (!url || !Array.isArray(box) || box.length !== 4 || !(box[2] > box[0]) || !(box[3] > box[1])) return null;
    const im = await loadImg(url), W = im.naturalWidth, H = im.naturalHeight;
    let y0 = box[0] / 1000 * H, x0 = box[1] / 1000 * W, y1 = box[2] / 1000 * H, x1 = box[3] / 1000 * W;
    const px = Math.max((x1 - x0) * 0.35, W * 0.04), py = Math.max((y1 - y0) * 0.6, H * 0.04);
    x0 = Math.max(0, x0 - px); x1 = Math.min(W, x1 + px); y0 = Math.max(0, y0 - py); y1 = Math.min(H, y1 + py);
    const w = x1 - x0, h = y1 - y0; if (w < 8 || h < 8) return null;
    const k = Math.min(4, Math.max(1, 1400 / Math.max(w, h))), c = mk(w * k, h * k), x = c.getContext("2d"); x.imageSmoothingQuality = "high"; x.drawImage(im, x0, y0, w, h, 0, 0, c.width, c.height);
    try { enhance(c, 1); } catch (e) { }
    return jpg(c, 0.92);
  }
  /* الصور (التاريخ أولاً) ← نتيجة موحّدة */
  async function aiDates(urls, onStep) {
    const imgs = await Promise.all(urls.map(async u => jpg(fitCanvas(await loadImg(u), 2000), 0.9)));
    const r1 = await askAI(DATE_PROMPT, imgs, 1536), v = r1.v;
    if (v.found === false && !v.expiry && !v.expiry_text && !v.production && !v.production_text && !v.lot) return { none: true, model: r1.model };
    const A = readOne(v), out = Object.assign({ src: "ai", model: r1.model, level: "single" }, A);
    const pi = Math.max(0, Math.min(urls.length - 1, parseInt(v.photo, 10) || 0));
    let crop = null; try { crop = await cropDate(urls[pi], v.box || v.box_2d); } catch (e) { }
    out.crop = crop;
    if (crop && (A.exp || A.prod || A.expText || A.prodText)) {
      onStep && onStep("قراءة ثانية على التاريخ مكبَّراً…");
      try {
        const B = readOne((await askAI(DATE_ZOOM_PROMPT, [crop], 768)).v);
        if (B.exp && A.exp && B.exp === A.exp && A.expOk && B.expOk) out.level = "double";
        else if (B.exp && A.exp && B.exp !== A.exp) { out.level = "check"; out.expAlt = B.exp; if (B.expOk && !A.expOk) { out.exp = B.exp; out.expAlt = A.exp; out.expText = B.expText || out.expText; } }
        else if (B.exp && !A.exp) { out.exp = B.exp; out.expText = B.expText; out.level = B.expOk ? "single" : "check"; }
        else if (!A.expOk) out.level = "check";
        if (!out.prod && B.prod) { out.prod = B.prod; out.prodText = B.prodText; } else if (B.prod && out.prod && B.prod !== out.prod) { out.prodAlt = B.prod; if (B.prodOk && !A.prodOk) { out.prod = B.prod; out.prodAlt = A.prod; } }
        if (!out.lot && B.lot) out.lot = B.lot; else if (B.lot && out.lot && B.lot !== out.lot) out.lotBad = true;
        if (!out.expText && B.expText) out.expText = B.expText;
      } catch (e) { console.warn("date zoom failed", e); if (!A.expOk) out.level = "check"; }
    } else if (!A.expOk || A.conf && A.conf < 0.6) out.level = "check";
    if (out.level === "single" && A.conf && A.conf < 0.6) out.level = "check";
    if (out.exp && out.prod && out.exp < out.prod) { const t = out.exp; out.exp = out.prod; out.prod = t; out.level = "check"; }
    if (out.exp) { const y = +out.exp.slice(0, 4), n = new Date().getFullYear(); if (y < n - 6 || y > n + 15) out.level = "check"; }
    if (!out.exp && !out.prod && !out.lot) return { none: true, model: r1.model, crop };
    return out;
  }
  /* دمج: رمز GS1 (دقيق) + قراءة الصورة */
  function mergeDates(code, ai) {
    const c = code && (code.exp || code.prod || code.lot) ? code : null;
    if (!c && !(ai && !ai.none)) return ai && ai.none ? { src: "none", crop: ai.crop || null } : null;
    if (!c) return ai;
    const o = { src: "gs1", level: "exact", exp: c.exp || "", prod: c.prod || "", lot: c.lot || "", qty: c.qty || 0, kind: c.kind, crop: ai && ai.crop || null, expText: ai && ai.expText || "", prodText: ai && ai.prodText || "" };
    if (ai && !ai.none) {
      if (!o.exp && ai.exp) { o.exp = ai.exp; o.mixed = true; o.level = ai.level; }
      if (!o.prod && ai.prod) o.prod = ai.prod;
      if (!o.lot && ai.lot) o.lot = ai.lot;
      if (c.exp && ai.exp) { if (c.exp === ai.exp || c.exp.slice(0, 7) === ai.exp.slice(0, 7)) o.both = true; else o.expAlt = ai.exp; }
    }
    return o;
  }

  /* ================================================================== الواجهة */
  const IC = {
    cam: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><path d="M4 8.5A1.5 1.5 0 0 1 5.5 7h2l1.4-2h6.2L16.5 7h2A1.5 1.5 0 0 1 20 8.5v9A1.5 1.5 0 0 1 18.5 19h-13A1.5 1.5 0 0 1 4 17.5z"/><circle cx="12" cy="12.6" r="3.6"/></svg>',
    spark: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5l1.9 5.3 5.3 1.9-5.3 1.9L12 16.9l-1.9-5.3-5.3-1.9 5.3-1.9zM18.5 14l.9 2.4 2.4.9-2.4.9-.9 2.4-.9-2.4-2.4-.9 2.4-.9zM5.5 15l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8L3 17.5l1.8-.7z"/></svg>',
    phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="7" y="2.8" width="10" height="18.4" rx="2.2"/><path d="M10.5 18h3"/></svg>',
    file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/><path d="M9 14l2 2 4-4"/></svg>',
    ok: '<svg viewBox="0 0 16 16"><path d="M3.5 8.5l3 3 6-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    flip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 12a8 8 0 0 1 13.7-5.7L20 8.5M20 4v4.5h-4.5M20 12a8 8 0 0 1-13.7 5.7L4 15.5M4 20v-4.5h4.5"/></svg>'
  };
  let S = null;   // حالة النافذة المفتوحة
  const K = k => S && S.ov.querySelector('[data-k="' + k + '"]');

  function open(o) {
    if (S) { S.ov.focus(); return; }
    const ad = !!(o && o.ad === true && window.ANOUER_ADSCENE);
    const ov = document.createElement("div"); ov.className = "ps-ov"; ov.tabIndex = -1;
    ov.innerHTML = `<div class="ps-dlg" role="dialog" aria-label="استوديو صورة الصنف">
      <header class="ps-hd"><span class="ps-logo${ad ? " ad" : ""}">${IC.spark}</span><div><b>${ad ? "صورة إعلانية للصنف" : "استوديو صورة الصنف"}</b><small>${ad ? "صوّر المنتج بالكاميرا — نعزله ونضعه على خلفية إعلانية تُرسم من اسمه ووصفه ، لكل صنف شكله" : "صوّر المنتج — صورة كتالوج احترافية + الاسم وعدد القطع + تاريخ الصلاحية (QR أو من الصورة)"}</small></div>
        <div class="ps-steps"><i class="on">1 · التصوير</i><i data-k="st2">2 · النتيجة</i></div><button type="button" class="ps-x" data-a="close" title="إغلاق (Esc)">✕</button></header>
      <div class="ps-bd">
        <section class="ps-main" data-k="cap">
          <div class="ps-src" role="tablist"><button type="button" class="on" data-src="cam">${IC.cam}كاميرا الحاسوب</button><button type="button" data-src="phone">${IC.phone}من الهاتف</button><button type="button" data-src="file">${IC.file}من ملف / لصق</button></div>
          <div class="ps-stage" data-k="stage"></div>
        </section>
        <section class="ps-main" data-k="res" hidden>
          <div class="ps-view"><div class="ps-canvas" data-k="view"></div><div class="ps-prog" data-k="prog"></div></div>
          <div class="ps-vars" data-k="vars"></div>
          <div class="ps-style" data-k="style">
            <span>الخلفية</span><button type="button" data-bg="white" class="on" title="أبيض نقي"><i style="background:#fff"></i></button><button type="button" data-bg="soft" title="تدرج ناعم"><i style="background:radial-gradient(#fff,#dfe4ea)"></i></button><button type="button" data-bg="gray" title="رمادي فاتح"><i style="background:#f2f3f5"></i></button>
            <label><input type="checkbox" data-o="shadow" checked>ظل</label><label><input type="checkbox" data-o="refl">انعكاس</label>
            <span class="sep"></span><button type="button" class="ps-edb" data-a="edit" title="امسح اليد أو بقايا الخلفية بالفرشاة، أو استرجع جزءاً مقصوصاً">✂ تعديل القص</button>
            <span class="sep"></span><span>التفاصيل</span><span class="ps-seg" data-k="lvl"><button type="button" data-lvl="0">عادي</button><button type="button" data-lvl="1">قوي</button><button type="button" data-lvl="2">أقصى</button></span>
          </div>
          <div class="ps-ad" data-k="adbar" hidden>
            <span class="ps-adt">${IC.spark}خلفية إعلانية</span>
            <select data-k="adTheme" title="نمط الخلفية — «تلقائي» يختاره من اسم الصنف ووصفه ومجموعته"></select>
            <button type="button" class="ps-adb" data-a="adNext" title="ترتيب آخر للعناصر والسطح والإضاءة — بنفس النمط">${IC.flip}شكل آخر</button>
            <label><input type="checkbox" data-o="adTitle" checked>عنوان</label>
            <input type="text" data-k="adHead" maxlength="34" placeholder="نص العنوان (اختياري)" autocomplete="off">
          </div>
          <div class="ps-out"><span>دقة الصورة المحفوظة</span><select data-k="size"><option value="1000">1000×1000 — خفيفة</option><option value="1600">1600×1600 — عالية</option><option value="2000">2000×2000 — قصوى</option></select><small data-k="zhint">انقر على الصورة للتكبير 100% وفحص التفاصيل</small></div>
        </section>
        <aside class="ps-side">
          <div data-k="sideCap">
            <div class="ps-slot on" data-slot="0"><span class="th"></span><div><b>1 · العلبة / المنتج</b><small>صوّر الواجهة الأمامية بوضوح</small></div><em class="del" data-del="0" title="حذف">✕</em></div>
            <div class="ps-slot" data-slot="1"><span class="th"></span><div><b>2 · قطعة واحدة <u>اختياري</u></b><small>تظهر أمام العلبة مثل صور الكتالوج</small></div><em class="del" data-del="1" title="حذف">✕</em></div>
            <div class="ps-slot dt" data-slot="2"><span class="th"></span><div><b>3 · التاريخ / QR <u>اختياري</u></b><small>قرّب تاريخ الصلاحية المطبوع أو رمز QR</small></div><em class="del" data-del="2" title="حذف">✕</em></div>
            <div class="ps-code" data-k="code" hidden></div>
            <ul class="ps-tips"><li>إضاءة قوية بدون انعكاس — وخلفية موحدة بلون مخالف للعلبة</li><li>المنتج يملأ الإطار وعلى الطاولة (لا تمسكه بيدك)</li><li>رمز QR / الباركود يُقرأ وحده من الكاميرا أو القارئ — والتاريخ المطبوع من الصورة</li></ul>
            <div class="ps-eng"><label>طريقة الإنشاء</label><select data-k="eng"><option value="auto">تلقائي (الأفضل المتاح)</option><option value="ai">توليد بالذكاء الاصطناعي ✨</option><option value="local">استوديو محلي — مجاني وبدون إنترنت</option></select><small data-k="engNote"></small></div>
            <div class="ps-key" data-k="keyBox" hidden><small>لقراءة الاسم وعدد القطع وتاريخ الصلاحية من الصورة وعزل المنتج بدقة أدخل مفتاح <b>Google Gemini</b> المجاني (من aistudio.google.com):</small><div><input type="password" data-k="key" placeholder="AIza…" autocomplete="off"><button type="button" data-a="saveKey">حفظ</button></div></div>
            <button type="button" class="ps-go" data-a="go" data-k="go" disabled>${IC.spark}<span>إنشاء الصورة</span></button>
          </div>
          <div data-k="sideRes" hidden>
            <div class="ps-info" data-k="info"></div>
            <div class="ps-acts"><button type="button" class="ps-go" data-a="apply">${IC.ok}<span>اعتماد الصورة للصنف</span></button>
              <div><button type="button" class="ps-b" data-a="regen">${IC.flip}إعادة الإنشاء</button><button type="button" class="ps-b" data-a="back">${IC.cam}تصوير من جديد</button></div></div>
          </div>
        </aside>
      </div></div>`;
    document.body.appendChild(ov);
    S = { ov, shots: [null, null, null], slot: 0, code: null, aiD: null, dates: null, scanId: 0, wb: { s: "", at: 0 }, src: "cam", stream: null, phone: false, poll: null, since: "", seen: new Set(), opt: { bg: "white", shadow: true, refl: false, lvl: +lsGet("ps.lvl", 1), size: +lsGet("ps.size", 1600), adTitle: lsGet("ps.adTitle", 1) !== 0, adTheme: "auto", adSeed: 0, adHead: "" }, vars: [], cur: 0, info: null, run: 0, ad };
    if (window.ANOUER_ADSCENE) { K("adTheme").innerHTML = '<option value="auto">✨ تلقائي من الاسم</option>' + ANOUER_ADSCENE.themes().map(t => `<option value="${t[0]}">${t[2]} ${esc(t[1])}</option>`).join(""); ov.querySelector('[data-o="adTitle"]').checked = S.opt.adTitle; }
    let adT = 0; ov.addEventListener("input", e => { if (S && e.target.dataset && e.target.dataset.k === "adHead") { clearTimeout(adT); adT = setTimeout(() => { if (S) { S.opt.adHead = e.target.value.trim(); recompose(); } }, 350); } });
    K("eng").value = lsGet("ps.eng", "auto"); K("size").value = String(S.opt.size); if (!K("size").value) K("size").value = "1600";
    ov.querySelectorAll("[data-lvl]").forEach(b => b.classList.toggle("on", +b.dataset.lvl === S.opt.lvl));
    ov.addEventListener("click", onClick);
    ov.addEventListener("change", onChange);
    ov.addEventListener("keydown", onKey);
    ov.addEventListener("paste", onPaste);
    ov.addEventListener("mousedown", e => { if (e.target === ov) e.preventDefault(); });
    setSrc("cam"); engNote(); keyBox();
    requestAnimationFrame(() => ov.classList.add("show")); ov.focus();
  }
  function close() {
    if (!S) return; stopCam(); stopPhone();
    const ov = S.ov; S.run++; S = null; ov.classList.remove("show"); setTimeout(() => ov.remove(), 180);
    const b = G("itImgBox"); if (b) b.focus();
  }
  function keyBox() { const kb = K("keyBox"); if (!kb) return; claudeOK().then(c => { if (S) kb.hidden = !!(gKey() || c); }); }
  function engNote() {
    const n = K("engNote"); if (!n) return; const v = K("eng").value, g = lsGet("ps.gen", null);
    n.textContent = v === "local" ? "عزل وتحسين محلي للمنتج الحقيقي — النتيجة فورية." :
      v === "ai" ? "يعيد رسم المنتج بجودة استوديو (علبة + قطعة). يحتاج مفتاح Gemini مع تفعيل الفوترة (حوالي 0.04$ للصورة)." :
      (g && g.no && Date.now() - g.no < 3 * 864e5 ? "مفتاحك المجاني لا يدعم توليد الصور ← سنستعمل الاستوديو المحلي + قراءة المنتج بالذكاء الاصطناعي." : "نجرب التوليد بالذكاء الاصطناعي، وإن لم يتوفر نستعمل الاستوديو المحلي.");
  }

  /* ---------------------------------------------------------------- مصادر الصورة */
  function setSrc(src) {
    if (!S) return; S.src = src;
    S.ov.querySelectorAll("[data-src]").forEach(b => b.classList.toggle("on", b.dataset.src === src));
    const st = K("stage"); stopCam(); if (src !== "phone") stopPhone();
    if (src === "cam") {
      st.innerHTML = `<video autoplay playsinline muted></video><div class="ps-guide" data-k="guide"><i></i><i></i><i></i><i></i><span data-k="gtx"></span><b class="ps-scanl"></b></div><div class="ps-hud" data-k="hud" hidden><i></i><span></span></div><div class="ps-camerr" data-k="camerr" hidden></div>
        <div class="ps-cbar"><select data-k="dev" title="الكاميرا" hidden></select><button type="button" class="ps-shot" data-a="shot" title="التقاط (Space)"><i></i></button><span></span></div>`;
      guideText(); startCam();
    } else if (src === "phone") {
      st.innerHTML = `<div class="ps-ph"><div class="qr" data-k="qr"><div class="ps-spin"></div></div><div><b>صوّر المنتج بكاميرا هاتفك</b><ol><li>اربط الهاتف بنفس شبكة <b>Wi-Fi</b>.</li><li>امسح الرمز بكاميرا الهاتف ← تفتح صفحة ANOUER.</li><li>صوّر المنتج — تصل الصورة هنا تلقائياً.</li></ol><div class="url" data-k="url"></div><small>كاميرا الهاتف أوضح بكثير من كاميرا الحاسوب ✓</small></div></div>`;
      startPhone();
    } else {
      st.innerHTML = `<label class="ps-drop" data-k="drop"><input type="file" accept="image/*" data-k="file" hidden>${IC.file}<b>اختر صورة المنتج من الجهاز</b><small>أو اسحبها وأفلتها هنا — أو الصقها بـ Ctrl+V</small></label>`;
      const d = K("drop");
      ["dragenter", "dragover"].forEach(t => d.addEventListener(t, e => { e.preventDefault(); d.classList.add("over"); }));
      d.addEventListener("dragleave", () => d.classList.remove("over"));
      d.addEventListener("drop", e => { e.preventDefault(); d.classList.remove("over"); const f = [...(e.dataTransfer && e.dataTransfer.files || [])].find(x => /^image\//.test(x.type)); if (f) fromBlob(f); });
    }
  }
  function guideText() { const g = K("gtx"); if (g) g.textContent = S.slot === 0 ? "ضع العلبة / المنتج داخل الإطار" : S.slot === 1 ? "ضع قطعة واحدة داخل الإطار" : "قرّب تاريخ الصلاحية أو رمز QR — حتى يملأ الإطار"; const gd = K("guide"); if (gd) gd.classList.toggle("dt", S.slot === 2); }
  async function startCam(devId) {
    const err = m => { const e = K("camerr"); if (e) { e.hidden = false; e.innerHTML = m; } };
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return err("الكاميرا غير متاحة في هذا الجهاز — استعمل <b>من الهاتف</b> أو <b>من ملف</b>.");
    const run = S.run;
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: Object.assign({ width: { ideal: 3840 }, height: { ideal: 2160 } }, devId ? { deviceId: { exact: devId } } : { facingMode: "environment" }), audio: false });
      if (!S || S.run !== run || S.src !== "cam") { s.getTracks().forEach(t => t.stop()); return; }
      S.stream = s; const v = S.ov.querySelector(".ps-stage video"); if (v) { v.srcObject = s; liveScan(v); }
      const devs = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === "videoinput"), sel = K("dev");
      if (sel && devs.length > 1) { const cur = s.getVideoTracks()[0].getSettings().deviceId; sel.innerHTML = devs.map((d, i) => `<option value="${esc(d.deviceId)}"${d.deviceId === cur ? " selected" : ""}>${esc(d.label || "كاميرا " + (i + 1))}</option>`).join(""); sel.hidden = false; }
    } catch (e) { err(/NotFound|DevicesNotFound|Overconstrained/i.test(e && e.name) ? "لا توجد كاميرا متصلة بالحاسوب — استعمل <b>من الهاتف</b> (أوضح) أو <b>من ملف</b>." : "تم رفض إذن الكاميرا أو أنها مستعملة في برنامج آخر."); }
  }
  function stopCam() { if (S) S.scanId++; if (S && S.stream) { S.stream.getTracks().forEach(t => t.stop()); S.stream = null; } }
  async function shot() {
    const v = S && S.ov.querySelector(".ps-stage video"); if (!v || !v.videoWidth) return;
    const st = K("stage"); st.classList.add("flash"); setTimeout(() => st && st.classList.remove("flash"), 260);
    try { window.ShotSound && ShotSound.play(); } catch (e) { }
    // صورة ثابتة بدقة الحساس الكاملة (أعلى من إطار الفيديو) إن كانت الكاميرا تدعم ذلك
    const tr = S.stream && S.stream.getVideoTracks()[0];
    if (tr && window.ImageCapture) {
      try {
        const ic = new ImageCapture(tr); let opt = {};
        try { const caps = await ic.getPhotoCapabilities(); if (caps && caps.imageWidth && caps.imageWidth.max) opt = { imageWidth: caps.imageWidth.max, imageHeight: caps.imageHeight && caps.imageHeight.max || undefined }; } catch (e) { }
        /* بعض الكاميرات لا ترد أبداً على takePhoto ← مهلة 2.5 ثانية ثم نأخذ إطار الفيديو (كان الزر يبدو معطّلاً) */
        const blob = await Promise.race([ic.takePhoto(opt), new Promise(r => setTimeout(() => r(null), 2500))]);
        if (!S) return;
        if (blob && blob.size > 20000) { fromBlob(blob); return; }
      } catch (e) { console.warn("takePhoto", e); }
    }
    const c = mk(v.videoWidth, v.videoHeight); c.getContext("2d").drawImage(v, 0, 0);
    setShot(c.toDataURL("image/png"));
  }
  function startPhone() {
    if (!HOST()) { const q = K("qr"); if (q) q.innerHTML = '<div class="ps-e">متاح داخل برنامج ANOUER فقط</div>'; return; }
    const run = S.run;
    call("fm.scan.phone", { on: 1 }).then(r => {
      if (!S || S.run !== run || S.src !== "phone") return; S.phone = true;
      const ips = r.ips || [], show = ip => { const u = "http://" + ip + ":" + r.port + "/m/" + r.token + "?k=item"; K("qr").innerHTML = window.ANOUER_QR ? ANOUER_QR.svg(u, 176) : ""; K("url").innerHTML = `<code>${esc(u)}</code>${ips.length > 1 ? `<select data-k="ip">${ips.map(i => `<option${i === ip ? " selected" : ""}>${esc(i)}</option>`).join("")}</select>` : ""}`; const s = K("ip"); if (s) s.onchange = () => show(s.value); };
      if (!ips.length) { K("qr").innerHTML = '<div class="ps-e">الحاسوب غير متصل بشبكة</div>'; return; }
      show(ips[0]);
      const pad = n => String(n).padStart(2, "0"), d = new Date(); S.since = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
      S.poll = setInterval(() => {
        if (!S) return;
        call("fm.scan.poll", { since: S.since }).then(x => {
          if (!S || !x) return; S.since = x.now || S.since;
          (x.phone || []).forEach(f => { if (S.seen.has(f.path)) return; S.seen.add(f.path); call("fm.scan.read", { path: f.path }).then(y => { if (S) { setShot("data:" + y.type + ";base64," + y.data); say("📱 وصلت صورة من الهاتف", "s"); } }).catch(() => { }); });
        }).catch(() => { });
      }, 1500);
    }).catch(e => { const q = K("qr"); if (q) q.innerHTML = `<div class="ps-e">${esc(e.message || e)}</div>`; });
  }
  function stopPhone() { if (!S) return; if (S.poll) { clearInterval(S.poll); S.poll = null; } if (S.phone && HOST()) { call("fm.scan.phone", { on: 0 }).catch(() => { }); S.phone = false; } }
  function fromBlob(f) { const slot = S ? S.slot : 0, r = new FileReader(); r.onload = () => setShot(String(r.result), slot); r.onerror = () => say("تعذّر قراءة الملف", "e"); r.readAsDataURL(f); }
  async function setShot(url, slot) {
    if (!S) return; if (slot == null) slot = S.slot;
    // تدوير حسب EXIF يتم تلقائياً في المتصفح؛ نحتفظ بدقة حتى 4000px
    try { const im = await loadImg(url); url = jpg(fitCanvas(im, 4000), 0.95); } catch (e) { say("تعذّر فتح الصورة", "e"); return; }
    if (!S) return;
    S.shots[slot] = url; drawSlots();
    if (S.slot === slot) { const nx = slot === 0 ? (!S.shots[1] ? 1 : !S.shots[2] ? 2 : 0) : slot === 1 && !S.shots[2] ? 2 : slot; if (nx !== slot) { S.slot = nx; drawSlots(); guideText(); } }
    scanStill(url);
  }
  /* ---------------------------------------------------------------- رموز QR / DataMatrix / الباركود (محلياً بلا إنترنت) */
  const QRR = () => window.ANOUER_QRREAD && ANOUER_QRREAD.scanImage ? ANOUER_QRREAD : null;
  let AC = null;
  function beep() { try { AC = AC || new (window.AudioContext || window.webkitAudioContext)(); const t = AC.currentTime; [1320, 1760].forEach((f, i) => { const o = AC.createOscillator(), g = AC.createGain(); o.type = "sine"; o.frequency.value = f; g.gain.setValueAtTime(0, t + i * .08); g.gain.linearRampToValueAtTime(.07, t + i * .08 + .01); g.gain.exponentialRampToValueAtTime(.0008, t + i * .08 + .16); o.connect(g); g.connect(AC.destination); o.start(t + i * .08); o.stop(t + i * .08 + .18); }); } catch (e) { } }
  function hud(cls, txt) { const h = K("hud"); if (!h) return; h.hidden = !txt; h.className = "ps-hud " + (cls || ""); h.querySelector("span").textContent = txt || ""; }
  const codeLine = c => [c.exp && "الصلاحية " + fmtD(c.exp), c.prod && "الإنتاج " + fmtD(c.prod), c.lot && "تشغيلة \u2066" + c.lot + "\u2069", c.gtin && "باركود " + c.gtin].filter(Boolean).join(" · ");
  function gotCode(text, how) {
    if (!S) return; const Q = window.ANOUER_QRREAD; if (!Q) return;
    const R = Q.decode(text); if (!R || !R.raw) return;
    if (!(R.gtin || R.exp || R.lot || R.prod)) { if (how !== "live") say("قُرئ رمز لكنه لا يحمل باركوداً ولا تاريخاً", "i"); else hud("warn", "رمز بدون تاريخ أو باركود"); return; }
    const prev = S.code || {}, nw = {}; ["gtin", "exp", "prod", "lot", "qty", "serial"].forEach(k => { if (R[k]) nw[k] = R[k]; });
    S.code = Object.assign({}, prev, nw, { kind: R.kind === "ean" && prev.kind && prev.kind !== "ean" ? prev.kind : R.kind, how });
    beep(); drawCode(); hud("ok", "✓ " + (S.code.kind === "ean" ? "باركود" : "GS1") + " — " + codeLine(S.code));
    const st = K("stage"); if (st) { st.classList.remove("hit"); void st.offsetWidth; st.classList.add("hit"); }
    if (how !== "live") say("✓ قُرئ الرمز: " + codeLine(S.code), "s");
    if (K("res") && !K("res").hidden) { S.dates = mergeDates(S.code, S.aiD); if (nw.gtin && nw.gtin !== prev.gtin) { if (S.infoDone) drawInfo(); } else drawDates(); }
  }
  function drawCode() {
    const el = K("code"); if (!el) return; const c = S.code; el.hidden = !c; if (!c) return;
    el.innerHTML = `<span class="ic">${c.kind === "ean" ? "▮▯▮" : "QR"}</span><div><b>رمز مقروء ✓ <em>${c.kind === "ean" ? "باركود" : "GS1 — دقيق"}</em></b><small>${esc(codeLine(c))}</small></div><em class="del" data-a="clrCode" title="مسح القراءة">✕</em>`;
  }
  /* صورة ملتقطة/ملف ← نبحث فيها عن رمز */
  async function scanStill(url) {
    const Q = QRR(); if (!Q || !S) return; const run = S.run;
    try { const im = await loadImg(url), t = await Q.scanImage(im); if (t && S && S.run === run) gotCode(t, "photo"); } catch (e) { }
  }
  /* الكاميرا الحيّة: فحص متواصل خفيف (إطار كامل ثم الوسط بالتناوب) + كشف الصورة المظلمة */
  const LIVE_MODES = ["full", "center", "t2", "t3", "full", "center", "t0", "t1"];   // الإطار كامل ثم الوسط ثم الأرباع (الأسفل أولاً: الملصق غالباً تحت)
  function liveScan(v) {
    const id = ++S.scanId; let n = 0, dark = 0, last = "", lastAt = 0, seenAt = 0, off = false;
    const b = mk(48, 27), bx = b.getContext("2d", { willReadFrequently: true });
    hud("", "يبحث عن QR / باركود…");
    const tick = async () => {
      if (!S || S.scanId !== id || S.src !== "cam") return;
      let wait = 420;
      if (v.videoWidth && K("cap") && !K("cap").hidden) {
        n++;
        try { bx.drawImage(v, 0, 0, 48, 27); const d = bx.getImageData(0, 0, 48, 27).data; let sum = 0; for (let i = 0; i < d.length; i += 4) sum += d[i] * .299 + d[i + 1] * .587 + d[i + 2] * .114; dark = sum / (d.length / 4) < 18 ? dark + 1 : 0; } catch (e) { }
        const h = K("hud"), isOk = h && /\bok\b/.test(h.className) && Date.now() - seenAt < 4000;   // يبقى أخضر ما دام الرمز ظاهراً
        if (dark >= 4) { hud("warn", "الصورة مظلمة — انزع غطاء العدسة / زِد الإضاءة" + (K("dev") && !K("dev").hidden ? " أو اختر كاميرا أخرى ↘" : "")); }
        else if (!isOk && !off) hud("", S.slot === 2 ? "يبحث عن QR / باركود… أو التقط صورة التاريخ" : "يبحث عن QR / باركود…");
        const Q = QRR();
        if (Q && !off && dark < 4) {
          try { const t = await Q.scanImage(v, LIVE_MODES[n % LIVE_MODES.length]); if (!S || S.scanId !== id) return;
            if (t) { seenAt = Date.now(); if (t !== last || Date.now() - lastAt > 8000) { last = t; lastAt = Date.now(); gotCode(t, "live"); } wait = 1300; } }
          catch (e) { if (e && e.message === "offline") off = true; }
        }
      }
      setTimeout(tick, wait);
    };
    setTimeout(tick, 700);
  }
  function drawSlots() {
    S.ov.querySelectorAll(".ps-slot").forEach(el => { const i = +el.dataset.slot, u = S.shots[i]; el.classList.toggle("on", i === S.slot); el.classList.toggle("has", !!u); el.querySelector(".th").style.backgroundImage = u ? `url(${u})` : ""; });
    K("go").disabled = !S.shots[0];
  }

  /* ---------------------------------------------------------------- الإنشاء */
  const STEPS = [["info", "قراءة الاسم وعدد القطع"], ["date", "قراءة تاريخ الصلاحية"], ["seg", "عزل المنتج عن الخلفية"], ["enh", "تحسين الإضاءة والألوان والحدة"], ["gen", "توليد صورة الكتالوج بالذكاء الاصطناعي"], ["ad", "رسم الخلفية الإعلانية من اسم الصنف"]];
  function prog(k, st, note) {
    const p = K("prog"); if (!p) return; let li = p.querySelector(`[data-s="${k}"]`);
    if (!li) { const d = STEPS.find(s => s[0] === k); li = document.createElement("div"); li.dataset.s = k; li.innerHTML = `<i></i><span>${esc(d ? d[1] : k)}</span><small></small>`; p.appendChild(li); }
    li.className = "ps-st"; li.dataset.st = st; if (note != null) li.querySelector("small").textContent = note;
    const L = [...p.children], busy = L.some(x => x.dataset.st === "run"), bad = L.some(x => /err|skip|warn/.test(x.dataset.st));
    p.hidden = false; clearTimeout(p.__t); if (!busy && !bad) p.__t = setTimeout(() => { p.hidden = true; }, 1600);
    if (!p.__w) { p.__w = 1; p.title = "انقر للإخفاء"; p.addEventListener("click", () => { p.hidden = true; }); }
  }
  async function go() {
    if (!S || !S.shots[0]) return;
    stopCam(); stopPhone();
    const run = ++S.run, eng = K("eng").value; lsSet("ps.eng", eng);
    K("cap").hidden = true; K("res").hidden = false; K("sideCap").hidden = true; K("sideRes").hidden = false; K("st2").classList.add("on");
    K("prog").innerHTML = ""; K("view").innerHTML = '<div class="ps-ph0"><div class="ps-spin"></div></div>'; S.vars = []; S.cur = 0; drawVars();
    K("info").innerHTML = '<div class="ps-skel"></div><div class="ps-skel"></div><div class="ps-skel s"></div>'; S.infoDone = false;
    const imgs = [S.shots[0], S.shots[1]].filter(Boolean), two = !!S.shots[1];
    /* صور قراءة التاريخ: خانة «التاريخ» أولاً ثم العلبة */
    S.dsrc = (S.shots[2] ? [S.shots[2], S.shots[0]] : imgs).slice(0, 2);
    const hasG = !!gKey(), hasAI = hasG || await claudeOK();
    // 1) القراءة
    prog("info", "run");
    if (!hasAI) prog("info", "skip", "يحتاج مفتاح Gemini المجاني");
    // 1-ب) تاريخ الصلاحية: الرمز (دقيق) + الصورة (ذكاء اصطناعي ، قراءة مزدوجة) — بالتوازي
    readDates(run, hasAI);
    // صور مصغّرة للذكاء الاصطناعي (أسرع وأرخص)
    const small = await Promise.all(imgs.map(async u => jpg(fitCanvas(await loadImg(u), 1280), 0.88)));
    S.small = small; S.infoErr = "";
    const info = hasAI ? await aiInfo(small).then(r => r.v).catch(e => { S.infoErr = e.message === "no-key" ? "لا يوجد مفتاح" : e.message; prog("info", "err", S.infoErr); return null; }) : null;
    if (!S || S.run !== run) return;
    if (info) prog("info", "ok", [info.brand, info.pieces > 1 ? info.pieces + " قطعة" : ""].filter(Boolean).join(" · "));
    S.info = info; S.infoDone = true; drawInfo();
    // 2) التوليد بالذكاء الاصطناعي (بالتوازي مع الاستوديو المحلي)
    const g = lsGet("ps.gen", null), noBill = g && g.no && Date.now() - g.no < 3 * 864e5;
    const wantGen = hasG && (eng === "ai" || (eng === "auto" && !noBill));
    if (eng === "ai" && !hasG) prog("gen", "err", "أدخل مفتاح Gemini أولاً");
    let genP = null;
    if (wantGen) {
      prog("gen", "run", "قد يستغرق 10–30 ثانية");
      addVar({ id: "ai", t: "ذكاء اصطناعي", pending: true });
      genP = gImage(GEN_PROMPT(info, two), small).then(async r => {
        if (!S || S.run !== run) return; const c = await squareOf(r.url);
        setVar("ai", { c, pending: false, note: r.model }); prog("gen", "ok");
        if (eng !== "local" && !S.ad) pick(S.vars.findIndex(v => v.id === "ai"));
      }).catch(e => {
        if (!S || S.run !== run) return;
        if (e.billing) { lsSet("ps.gen", { no: Date.now() }); prog("gen", "skip", "مفتاحك المجاني لا يدعم توليد الصور — فعّل الفوترة في Google AI Studio"); }
        else prog("gen", "err", e.message || String(e));
        dropVar("ai"); engNote();
      });
    }
    // 3) الاستوديو المحلي (المنتج الحقيقي) — يعمل دائماً كاحتياط إن فشل التوليد بالذكاء الاصطناعي
    let localDone = false;
    const runLocal = async () => {
      if (localDone || !S || S.run !== run) return; localDone = true;
      try {
        const A = await cutout(S.shots[0], info && info.box, hasG, prog);
        let Bc = null; if (two) Bc = await cutout(S.shots[1], info && info.piece_box, hasG, null);
        if (!S || S.run !== run) return;
        const B = Bc ? Bc.raw : null;
        S.parts = { A: A.raw, B, src: { A: { full: A.full, hi: A.hi }, B: Bc ? { full: Bc.full, hi: Bc.hi } : null }, e: {} }; S.how = A.how;
        prog("enh", "run"); await sleep(20); const E = enhanced(); prog("enh", "ok");
        const note = (A.how === "ai" ? "عزل بالذكاء الاصطناعي" : A.how === "poly" ? "حدود بالذكاء الاصطناعي" : A.how === "local" ? "عزل تلقائي" : A.how === "box" ? "قص على حدود المنتج" : "بدون عزل") + " · " + A.raw.width + "×" + A.raw.height;
        if (A.how === "none" || A.how === "box") prog("seg", "warn", "الخلفية غير موحدة — استعمل «تعديل القص» لإزالة اليد/الخلفية، أو صوّر على خلفية موحدة");
        addVar({ id: "studio", t: "استوديو", c: compose(E.A, E.B, S.opt), note }, true);
        if (!S.ad && !S.vars.some(v => v.id === "ai" && !v.pending)) pick(S.vars.findIndex(v => v.id === "studio"));
        if (B) addVar({ id: "solo", t: "العلبة فقط", c: compose(E.A, null, S.opt), note });
        /* «خلفية إعلانية»: المنتج نفسه داخل مشهد مرسوم من اسم الصنف ووصفه (ad-scene.js) */
        if (window.ANOUER_ADSCENE) { prog("ad", "run"); await sleep(20); if (!S || S.run !== run) return;
          const o = adOpt(); addVar({ id: "ad", t: "خلفية إعلانية", c: ANOUER_ADSCENE.render(E.A, E.B, o), note: adNote(o) }, S.ad);
          prog("ad", "ok", adNote(o)); if (S.ad) pick(S.vars.findIndex(v => v.id === "ad")); }
      } catch (e) { console.error(e); prog("seg", "err", e.message || String(e)); }
    };
    if (eng !== "ai" || !wantGen) await runLocal();
    if (genP) { await genP; if (S && S.run === run && !S.vars.some(v => v.id === "ai" && v.c)) await runLocal(); }
    if (S && S.run === run && !S.vars.length) { K("view").innerHTML = '<div class="ps-e">تعذّر إنشاء الصورة — جرّب «الاستوديو المحلي» أو صوّر من جديد</div>'; }
  }
  function addVar(v, first) { const i = S.vars.findIndex(x => x.id === v.id); if (i >= 0) S.vars[i] = Object.assign(S.vars[i], v); else if (first) S.vars.unshift(v); else S.vars.push(v); drawVars(); }
  function setVar(id, o) { const v = S.vars.find(x => x.id === id); if (v) Object.assign(v, o); drawVars(); }
  function dropVar(id) { const i = S.vars.findIndex(x => x.id === id); if (i < 0) return; S.vars.splice(i, 1); if (S.cur >= S.vars.length) S.cur = 0; drawVars(); pick(S.cur); }
  function drawVars() {
    const el = K("vars"); if (!el) return;
    el.innerHTML = S.vars.map((v, i) => `<button type="button" class="ps-var${i === S.cur ? " on" : ""}${v.pending ? " pend" : ""}" data-v="${i}" title="${esc(v.note || "")}"><span>${v.c ? `<img src="${v.c.toDataURL("image/jpeg", 0.7)}" alt="">` : '<div class="ps-spin"></div>'}</span><b>${v.id === "ai" ? IC.spark : ""}${esc(v.t)}</b></button>`).join("");
    const cur = S.vars[S.cur], st = K("style"); if (st) st.classList.toggle("dis", !(cur && cur.id !== "ai" && S.parts));
    const isAd = !!(cur && cur.id === "ad"), ab = K("adbar"); if (ab) ab.hidden = !isAd;
    if (st) st.classList.toggle("adm", isAd);   // الخلفية/الظل/الانعكاس لا تخص المشهد الإعلاني
  }
  /* ---------------------------------------------------------------- الخلفية الإعلانية */
  function adOpt() {
    const tx = el => el ? String(el.value != null ? el.value : el.textContent || "").trim() : "", I = S.info || {};
    const name = tx(K("iName")) || nameNow() || I.suggest || [I.brand, I.name_ar || I.product].filter(Boolean).join(" ");
    return { name, text: [nameNow(), I.brand, I.product, I.name_ar, I.category, I.suggest].filter(Boolean).join(" "), group: tx(G("itGroup")) || I.category || "",
      theme: S.opt.adTheme, seed: S.opt.adSeed, title: S.opt.adTitle, head: S.opt.adHead || "" };
  }
  function adNote(o) { const ids = o.theme !== "auto" ? [o.theme] : ANOUER_ADSCENE.detect(o.name + " " + o.text, o.group); return "نمط: " + ids.slice(0, 2).map(ANOUER_ADSCENE.label).join(" + ") + (o.theme === "auto" ? " (من الاسم)" : ""); }
  function pick(i) {
    if (!S || i < 0 || !S.vars[i]) return; S.cur = i; drawVars();
    const v = S.vars[i], view = K("view");
    if (!v.c) { view.innerHTML = '<div class="ps-ph0"><div class="ps-spin"></div><small>جارٍ التوليد…</small></div>'; return; }
    view.innerHTML = ""; view.classList.remove("zoom"); const im = new Image(); im.src = v.c.toDataURL("image/jpeg", 0.93); im.alt = ""; im.title = "انقر للتكبير 100%"; view.appendChild(im);
    zoomWire(view, im);
    if (v.note) { const s = document.createElement("small"); s.className = "ps-badge"; s.textContent = v.note; view.appendChild(s); }
  }
  /* نسخة محسّنة لكل مستوى تفاصيل (مخزنة) */
  function enhanced() {
    const L = S.opt.lvl, P = S.parts;
    if (!P.e[L]) P.e[L] = { A: enhance(dupC(P.A), L), B: P.B ? enhance(dupC(P.B), L) : null };
    return P.e[L];
  }
  /* ---------------------------------------------------------------- تعديل القص يدوياً (ممحاة / استرجاع) */
  function editCut() {
    if (!S || !S.parts || !S.parts.src) { say("التعديل متاح لصورة «استوديو»", "i"); return; }
    const host = K("view").parentNode; let tg = "A";
    const ed = document.createElement("div"); ed.className = "ps-ed";
    ed.innerHTML = `<div class="ps-edbar">${S.parts.src.B ? `<span class="ps-seg" data-e="tg"><button type="button" data-tg="A" class="on">العلبة</button><button type="button" data-tg="B">القطعة</button></span>` : ""}
      <span class="ps-seg" data-e="md"><button type="button" data-md="er" class="on">🧽 ممحاة</button><button type="button" data-md="rs">🖌 استرجاع</button></span>
      <label>الحجم <input type="range" min="6" max="160" value="40" data-e="sz"></label>
      <button type="button" class="ps-b" data-e="undo" title="تراجع (Ctrl+Z)">↶ تراجع</button>
      <span class="sp"></span><button type="button" class="ps-b" data-e="no">إلغاء</button><button type="button" class="ps-go sm" data-e="ok">تم</button></div>
      <div class="ps-edc"><canvas></canvas><i class="cur"></i></div><small class="ps-edh">امسح اليد والخلفية بالممحاة — «استرجاع» يعيد أي جزء من المنتج مُسح بالخطأ. عجلة الفأرة لتغيير حجم الفرشاة.</small>`;
    host.appendChild(ed);
    const cv = ed.querySelector("canvas"), box = ed.querySelector(".ps-edc"), cur = ed.querySelector(".cur"), sz = ed.querySelector('[data-e="sz"]');
    const orig = { A: dupC(S.parts.src.A.full), B: S.parts.src.B ? dupC(S.parts.src.B.full) : null };
    let undo = [], mode = "er", scale = 1, ox = 0, oy = 0, drawing = false, last = null, raf = 0;
    const src = () => S.parts.src[tg];
    const checker = (() => { const c = mk(16, 16), x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, 16, 16); x.fillStyle = "#e4e7ec"; x.fillRect(0, 0, 8, 8); x.fillRect(8, 8, 8, 8); return c; })();
    const layout = () => {
      const r = box.getBoundingClientRect(), f = src().full; cv.width = Math.max(10, r.width); cv.height = Math.max(10, r.height);
      scale = Math.min(cv.width / f.width, cv.height / f.height) * 0.96; ox = (cv.width - f.width * scale) / 2; oy = (cv.height - f.height * scale) / 2; draw();
    };
    const draw = () => {
      raf = 0; const x = cv.getContext("2d"), f = src().full;
      x.fillStyle = x.createPattern(checker, "repeat"); x.fillRect(0, 0, cv.width, cv.height);
      x.save(); x.globalAlpha = 0.18; x.drawImage(src().hi, ox, oy, f.width * scale, f.height * scale); x.restore();   // الأصل باهت للمرجع
      x.drawImage(f, ox, oy, f.width * scale, f.height * scale);
    };
    const later = () => { if (!raf) raf = requestAnimationFrame(draw); };
    const toImg = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left - ox) / scale, (e.clientY - r.top - oy) / scale]; };
    const dab = (px, py) => {
      const f = src().full, x = f.getContext("2d"), rad = +sz.value / scale / 2 * (cv.width / cv.getBoundingClientRect().width);
      x.save();
      if (mode === "er") { x.globalCompositeOperation = "destination-out"; const g = x.createRadialGradient(px, py, rad * 0.55, px, py, rad); g.addColorStop(0, "rgba(0,0,0,1)"); g.addColorStop(1, "rgba(0,0,0,0)"); x.fillStyle = g; x.beginPath(); x.arc(px, py, rad, 0, Math.PI * 2); x.fill(); }
      else { x.beginPath(); x.arc(px, py, rad, 0, Math.PI * 2); x.clip(); x.drawImage(src().hi, 0, 0); }
      x.restore();
    };
    const stroke = (a, b) => { const d = Math.hypot(b[0] - a[0], b[1] - a[1]), st = Math.max(1, (+sz.value / scale) / 6), n = Math.ceil(d / st); for (let i = 0; i <= n; i++) dab(a[0] + (b[0] - a[0]) * i / Math.max(1, n), a[1] + (b[1] - a[1]) * i / Math.max(1, n)); later(); };
    const curPos = e => { const r = box.getBoundingClientRect(), d = +sz.value; cur.style.width = cur.style.height = d + "px"; cur.style.left = (e.clientX - r.left - d / 2) + "px"; cur.style.top = (e.clientY - r.top - d / 2) + "px"; cur.classList.toggle("rs", mode === "rs"); };
    cv.addEventListener("pointerdown", e => { e.preventDefault(); cv.setPointerCapture(e.pointerId); undo.push({ tg, c: dupC(src().full) }); if (undo.length > 6) undo.shift(); drawing = true; last = toImg(e); stroke(last, last); });
    cv.addEventListener("pointermove", e => { curPos(e); if (!drawing) return; const p = toImg(e); stroke(last, p); last = p; });
    const end = () => { drawing = false; last = null; };
    cv.addEventListener("pointerup", end); cv.addEventListener("pointercancel", end);
    cv.addEventListener("pointerleave", () => { cur.style.width = "0"; });
    cv.addEventListener("wheel", e => { e.preventDefault(); sz.value = Math.max(6, Math.min(160, +sz.value + (e.deltaY < 0 ? 6 : -6))); curPos(e); }, { passive: false });
    const doUndo = () => { const u = undo.pop(); if (!u) return; const f = S.parts.src[u.tg].full, x = f.getContext("2d"); x.clearRect(0, 0, f.width, f.height); x.drawImage(u.c, 0, 0); if (u.tg !== tg) { tg = u.tg; syncTg(); layout(); } else draw(); };
    const syncTg = () => ed.querySelectorAll("[data-tg]").forEach(b => b.classList.toggle("on", b.dataset.tg === tg));
    const close = ok => {
      document.removeEventListener("keydown", kd, true); window.removeEventListener("resize", layout);
      if (!ok) { ["A", "B"].forEach(k => { if (orig[k]) { const f = S.parts.src[k].full, x = f.getContext("2d"); x.clearRect(0, 0, f.width, f.height); x.drawImage(orig[k], 0, 0); } }); }
      else { S.parts.A = cropAlpha(S.parts.src.A.full) || S.parts.A; if (S.parts.src.B) S.parts.B = cropAlpha(S.parts.src.B.full) || S.parts.B; S.parts.e = {}; const st = S.vars.findIndex(v => v.id === "studio"); if (st >= 0) S.cur = st; recompose(); say("تم تعديل القص ✓", "s"); }
      ed.remove();
    };
    const kd = e => { if (!ed.isConnected) return; if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(false); } else if (e.ctrlKey && e.code === "KeyZ") { e.preventDefault(); e.stopPropagation(); doUndo(); } };
    document.addEventListener("keydown", kd, true); window.addEventListener("resize", layout);
    ed.addEventListener("click", e => {
      const t = e.target.closest("[data-tg],[data-md],[data-e]"); if (!t) return;
      if (t.dataset.tg) { tg = t.dataset.tg; syncTg(); layout(); }
      else if (t.dataset.md) { mode = t.dataset.md; ed.querySelectorAll("[data-md]").forEach(b => b.classList.toggle("on", b === t)); }
      else if (t.dataset.e === "undo") doUndo();
      else if (t.dataset.e === "no") close(false);
      else if (t.dataset.e === "ok") close(true);
    });
    requestAnimationFrame(layout);
  }
  /* تكبير 100% مع السحب لفحص الحدة والكتابة */
  function zoomWire(view, im) {
    let drag = null, moved = false;
    im.addEventListener("pointerdown", e => { drag = { x: e.clientX, y: e.clientY, l: view.scrollLeft, t: view.scrollTop }; moved = false; if (view.classList.contains("zoom")) im.setPointerCapture(e.pointerId); });
    im.addEventListener("pointermove", e => { if (!drag || !view.classList.contains("zoom")) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (Math.abs(dx) + Math.abs(dy) > 3) moved = true; view.scrollLeft = drag.l - dx; view.scrollTop = drag.t - dy; });
    im.addEventListener("pointerup", e => {
      const d = drag; drag = null; if (moved) return;
      const r = im.getBoundingClientRect(), fx = (e.clientX - r.left) / r.width, fy = (e.clientY - r.top) / r.height, on = view.classList.toggle("zoom");
      if (on && d) requestAnimationFrame(() => { view.scrollLeft = fx * im.naturalWidth - view.clientWidth / 2; view.scrollTop = fy * im.naturalHeight - view.clientHeight / 2; });
    });
  }
  function recompose() {
    if (!S || !S.parts) return;
    const E = enhanced();
    S.vars.forEach(v => { if (v.id === "studio") v.c = compose(E.A, E.B, S.opt); if (v.id === "solo") v.c = compose(E.A, null, S.opt);
      if (v.id === "ad" && window.ANOUER_ADSCENE) { const o = adOpt(); v.c = ANOUER_ADSCENE.render(E.A, E.B, o); v.note = adNote(o); } });
    drawVars(); pick(S.cur);
  }

  /* ---------------------------------------------------------------- بيانات الصنف المقروءة */
  const nameNow = () => { const n = G("itName"); return n ? n.value.trim() : ""; };
  const unitCount = () => { try { if (window.ITC && ITC.state && ITC.state.units) return ITC.state.units.map(r => +String(r.n || "").replace(",", ".") || 0); } catch (e) { } try { return (typeof UNITS !== "undefined" ? UNITS : []).map(r => +r.n || 0); } catch (e) { return []; } };
  function readDates(run, hasAI) {
    S.aiD = null; S.dErr = ""; S.dBusy = !!hasAI; S.dates = mergeDates(S.code, null);
    const codeOk = S.code && S.code.exp;
    if (!hasAI) { prog("date", codeOk ? "ok" : "skip", codeOk ? "من الرمز: " + fmtD(S.code.exp) : "من الصورة يحتاج مفتاح Gemini — رمز QR يُقرأ بدونه"); return Promise.resolve(); }
    prog("date", "run", codeOk ? "الرمز: " + fmtD(S.code.exp) + " — نطابقه مع الصورة…" : "");
    return aiDates(S.dsrc, m => { if (S && S.run === run) prog("date", "run", m); }).then(r => { if (!S || S.run !== run) return; S.aiD = r; })
      .catch(e => { if (!S || S.run !== run) return; S.dErr = e.message === "no-key" ? "لا يوجد مفتاح" : (e.message || String(e)); })
      .then(() => {
        if (!S || S.run !== run) return; S.dBusy = false; const D = S.dates = mergeDates(S.code, S.aiD);
        if (D && D.exp) prog("date", D.level === "check" ? "warn" : "ok", fmtD(D.exp) + (D.src === "gs1" ? " · من الرمز" + (D.both ? " ✓✓ مطابق للصورة" : "") : D.level === "double" ? " · تأكيد مزدوج ✓✓" : D.level === "check" ? " · تحقّق من التاريخ" : " · من الصورة"));
        else if (S.dErr) prog("date", "err", S.dErr);
        else prog("date", "skip", D && (D.prod || D.lot) ? "قُرئ تاريخ الإنتاج/التشغيلة فقط" : "لا يوجد تاريخ ظاهر — صوّره في الخانة 3");
        if (S.infoDone) drawDates();
      });
  }
  const minShelf = () => { const e = G("itMinShelf"); return e ? Math.max(0, parseInt(e.value, 10) || 0) : 0; };
  function dateState(exp, prod) {
    if (!exp) return { k: "none", t: "اكتب تاريخ الانتهاء أو صوّره", pct: 0 };
    const left = dayDiff(todayISO(), exp), ms = minShelf(), o = { left };
    if (left < 0) { o.k = "exp"; o.t = "✖ منتهي منذ " + (-left) + " يوم"; }
    else if (left <= 30) { o.k = "soon"; o.t = (left === 0 ? "⚠ ينتهي اليوم" : "⚠ قريب الانتهاء — باقي " + left + " يوم"); }
    else { o.k = "ok"; o.t = "✔ صالح — باقي " + (left > 120 ? Math.round(left / 30.4) + " شهر (" + left + " يوم)" : left + " يوم"); }
    if (left >= 0 && ms > 0 && left < ms) { o.k = "soon"; o.sub = "أقل من «أقل مدة صلاحية» للصنف (" + ms + " يوم)"; }
    if (prod && prod < exp) { const tot = dayDiff(prod, exp), used = Math.max(0, Math.min(tot, dayDiff(prod, todayISO()))); o.pct = tot > 0 ? used / tot : 0; o.life = "مدة الصلاحية " + (tot >= 60 ? Math.round(tot / 30.4) + " شهر" : tot + " يوم") + " · مضى " + Math.round(o.pct * 100) + "%"; }
    else o.pct = left < 0 ? 1 : 0;
    return o;
  }
  function dateCard() {
    const D = S.dates || {}, busy = S.dBusy, hasAIk = !!(gKey() || CLAUDE);
    const src = D.src === "gs1" ? `<em class="src ok">QR · GS1 ✓ دقيق${D.both ? " · مطابق للصورة ✓✓" : ""}</em>` :
      D.src === "ai" ? (D.level === "double" ? '<em class="src ok">✨ من الصورة · تأكيد مزدوج ✓✓</em>' : D.level === "check" ? '<em class="src warn">⚠ من الصورة — تحقّق</em>' : D.level === "manual" ? '<em class="src">✎ معدَّل يدوياً</em>' : '<em class="src ai">✨ من الصورة</em>') :
      busy ? '<em class="src ai">يقرأ…</em>' : "";
    const st = dateState(D.exp, D.prod);
    const hint = busy && !D.exp ? '<div class="ps-skel s"></div>' :
      D.exp || D.prod || D.lot ? "" :
      `<div class="ps-dtn">${S.dErr ? "تعذّرت قراءة التاريخ (" + esc(S.dErr) + ")" : hasAIk ? "لم نجد تاريخاً ظاهراً — صوّر التاريخ المطبوع عن قرب في <b>الخانة 3</b> أو اكتبه هنا." : "رمز <b>QR / GS1</b> يُقرأ بلا إنترنت. لقراءة التاريخ <b>المطبوع</b> من الصورة أدخل مفتاح Gemini المجاني — أو اكتبه هنا."}</div>`;
    const alt = D.expAlt && D.expAlt !== D.exp ? `<button type="button" class="ps-dta" data-a="dAlt" data-v="${esc(D.expAlt)}" title="استعمال هذه القراءة">${D.src === "gs1" ? "الصورة تقول" : "قراءة أخرى"}: <b dir="ltr">${esc(fmtD(D.expAlt))}</b> ← استعمال</button>` : "";
    const zoom = D.crop ? `<figure class="ps-dtz" title="التاريخ كما هو مطبوع — قارنه بالحقول"><img src="${D.crop}" alt=""><figcaption dir="ltr">${esc([D.prodText, D.expText].filter(Boolean).join("  →  ") || "")}</figcaption></figure>` : (D.expText ? `<div class="ps-dtt" dir="ltr">«${esc([D.prodText, D.expText].filter(Boolean).join("  →  "))}»</div>` : "");
    return `<div class="ps-dt ${st.k}" data-k="dCard"><div class="ps-dth"><span class="ic">⏳</span><b>تواريخ المنتج</b>${src}</div>${zoom}${hint}
      <div class="ps-dtg"><label><span>تاريخ الإنتاج</span><input type="date" data-k="dProd" value="${esc(D.prod || "")}"></label><label><span>تاريخ الانتهاء${D.calc ? " <u>محسوب</u>" : ""}</span><input type="date" data-k="dExp" value="${esc(D.exp || "")}"></label></div>
      ${alt}<div class="ps-dtbar"><i data-k="dBar" style="width:${Math.round((st.pct || 0) * 100)}%"></i></div><div class="ps-dts" data-k="dSt"><b>${esc(st.t)}</b>${st.life ? "<small>" + esc(st.life) + "</small>" : ""}${st.sub ? '<small class="w">' + esc(st.sub) + "</small>" : ""}</div>
      <div class="ps-dtg"><label><span>رقم التشغيلة${D.lotBad ? " <u>تحقّق</u>" : ""}</span><input type="text" data-k="dLot" dir="ltr" value="${esc(D.lot || "")}" placeholder="LOT"></label><label><span>كمية الدفعة</span><input type="number" min="0" data-k="dQty" value="${D.qty ? esc(D.qty) : ""}" placeholder="—"></label></div>
      <label class="ps-dtc"><input type="checkbox" data-ap="batch"${D.exp && D.level !== "check" ? " checked" : ""}${D.exp ? "" : " disabled"}><span>${D.level === "check" ? "تحقّقتُ من التاريخ — " : ""}إضافة كدفعة صلاحية للرصيد الافتتاحي (الصنف يصير «مخزون بصلاحية»)</span></label></div>`;
  }
  function drawDates() { const c = K("dCard"), el = K("info"); if (c && el) { c.outerHTML = dateCard(); wireDates(el); } else if (S && S.infoDone) drawInfo(); }
  function wireDates(el) {
    const ex = K("dExp"), pr = K("dProd"); if (!ex) return;
    const upd = manual => { const st = dateState(ex.value, pr.value), card = K("dCard"); card.className = "ps-dt " + st.k; K("dBar").style.width = Math.round((st.pct || 0) * 100) + "%";
      K("dSt").innerHTML = `<b>${esc(st.t)}</b>${st.life ? "<small>" + esc(st.life) + "</small>" : ""}${st.sub ? '<small class="w">' + esc(st.sub) + "</small>" : ""}`;
      const c = el.querySelector('[data-ap="batch"]'); c.disabled = !ex.value; if (manual) { c.checked = !!ex.value; const sb = card.querySelector(".ps-dth .src"); if (sb) { sb.className = "src"; sb.textContent = "✎ معدَّل يدوياً"; } const al = card.querySelector(".ps-dta"); if (al) al.remove(); S.dates = Object.assign(S.dates || { src: "manual" }, { exp: ex.value, prod: pr.value, level: "manual" }); } };
    ex.addEventListener("input", () => upd(true)); pr.addEventListener("input", () => upd(true));
    const lot = K("dLot"); if (lot) lot.addEventListener("input", () => { if (S.dates) S.dates.lot = lot.value.trim(); });
    const q = K("dQty"); if (q) q.addEventListener("input", () => { if (S.dates) S.dates.qty = +q.value || 0; });
  }
  function drawInfo() {
    const el = K("info"), I = S.info, cbc = S.code && S.code.gtin ? String(S.code.gtin) : "";
    if (!I) {
      const gt0 = G("itGtin"), no0 = G("itNo"), auto0 = gt0 && (!gt0.value.trim() || (no0 && gt0.value.trim() === no0.value.trim()));
      el.innerHTML = `<div class="ps-ih">بيانات المنتج</div>${cbc ? `<label class="ps-f"><span><input type="checkbox" data-ap="bc"${auto0 ? " checked" : ""}>الباركود العالمي <u class="ps-gs">من الرمز ✓</u></span><input type="text" data-k="iBc" value="${esc(cbc)}" dir="ltr"></label>` : ""}<div class="ps-none">${gKey() || CLAUDE ? "لم نتمكن من قراءة النص على العلبة" + (S.infoErr ? " (" + esc(S.infoErr) + ")" : "") + " — صوّرها من الأمام وبإضاءة أفضل، أو أعد القراءة." : "أدخل مفتاح <b>Gemini</b> المجاني ليقرأ البرنامج اسم المنتج وعدد القطع والباركود تلقائياً."}</div>${gKey() || CLAUDE ? '<button type="button" class="ps-b" data-a="reread">↻ إعادة القراءة</button>' : ""}` + dateCard(); wireDates(el); return;
    }
    const pcs = Math.max(0, parseInt(I.pieces, 10) || 0), bc = cbc || String(I.barcode || "").replace(/\D/g, ""), bcOk = /^\d{8}$|^\d{12,14}$/.test(bc);
    const sug = String(I.suggest || [I.brand, pcs > 1 ? pcs + "P" : "", I.name_ar].filter(Boolean).join(" ")).trim();
    const gt = G("itGtin"), no = G("itNo"), gtAuto = gt && (!gt.value.trim() || (no && gt.value.trim() === no.value.trim()));
    const hasUnit = unitCount().includes(pcs);
    const grp = G("itGroup");
    el.innerHTML = `<div class="ps-ih">قرأنا من العلبة ${IC.spark}<button type="button" class="ps-rr" data-a="reread" title="إعادة القراءة">↻</button></div>
      <label class="ps-f"><span><input type="checkbox" data-ap="name"${!nameNow() ? " checked" : ""}>اسم الصنف</span><input type="text" data-k="iName" value="${esc(sug)}"></label>
      <div class="ps-chips">${[I.brand && ["العلامة", I.brand], I.product && ["المنتج", I.product], I.weight && ["الوزن", I.weight], I.piece && ["القطعة", I.piece]].filter(Boolean).map(c => `<span><small>${esc(c[0])}</small>${esc(c[1])}</span>`).join("")}</div>
      <label class="ps-f"><span><input type="checkbox" data-ap="unit"${pcs > 1 && !hasUnit ? " checked" : ""}${pcs > 1 ? "" : " disabled"}>عدد القطع في العلبة</span><div class="ps-u"><input type="number" min="0" data-k="iPcs" value="${pcs || ""}" placeholder="—"><select data-k="iUnit">${["علبة", "كرتونة", "باكيت", "شدة", "صندوق"].map(u => `<option>${u}</option>`).join("")}</select></div><small>${hasUnit ? "الوحدة موجودة مسبقاً في الصنف" : "تُضاف وحدة جديدة = هذا العدد من الحبات"}</small></label>
      ${bcOk ? `<label class="ps-f"><span><input type="checkbox" data-ap="bc"${gtAuto ? " checked" : ""}>الباركود العالمي${cbc ? ' <u class="ps-gs">من الرمز ✓</u>' : ""}</span><input type="text" data-k="iBc" value="${esc(bc)}" dir="ltr"></label>` : ""}
      ${I.category && grp ? `<label class="ps-f"><span><input type="checkbox" data-ap="grp"${!grp.value.trim() ? " checked" : ""}>المجموعة</span><input type="text" data-k="iGrp" value="${esc(I.category)}"></label>` : ""}` + dateCard();
    wireDates(el);
    const pi = K("iPcs"); if (pi) pi.addEventListener("input", () => { const c = el.querySelector('[data-ap="unit"]'); const n = +pi.value || 0; c.disabled = n < 2; c.checked = n > 1 && !unitCount().includes(n); });
  }
  async function reread() {
    if (!S || !S.small) return; const run = S.run;
    K("info").innerHTML = '<div class="ps-skel"></div><div class="ps-skel"></div><div class="ps-skel s"></div>'; prog("info", "run", ""); S.infoErr = "";
    S.infoDone = false; if (S.dsrc) readDates(run, !!(gKey() || CLAUDE));
    const v = await aiInfo(S.small).then(r => r.v).catch(e => { S.infoErr = e.message === "no-key" ? "لا يوجد مفتاح" : e.message; return null; });
    if (!S || S.run !== run) return; S.infoDone = true;
    if (v) { S.info = v; prog("info", "ok", [v.brand, v.pieces > 1 ? v.pieces + " قطعة" : ""].filter(Boolean).join(" · ")); } else { S.info = null; prog("info", "err", S.infoErr); }
    drawInfo();
  }
  function addUnit(name, n) {
    if (window.ITC && typeof ITC.addUnit === "function") return ITC.addUnit(name, n);
    try { if (typeof UNITS !== "undefined" && typeof blankU === "function") { const r = Object.assign(blankU(), { u: name, n: String(n), act: true }); const i = UNITS.findIndex(x => !x.u && !x.n); if (i >= 0) UNITS.splice(i, 0, r); else UNITS.push(r); if (typeof renderUnits === "function") renderUnits(); return true; } } catch (e) { }
    return false;
  }
  function apply() {
    if (!S) return; const v = S.vars[S.cur]; if (!v || !v.c) { say("انتظر حتى تكتمل الصورة", "i"); return; }
    // الصورة النهائية بالدقة المختارة (تُحفظ كاملة في القاعدة، والمصغّرة لشبكة اللمس)
    const Z = S.opt.size || 1600, out = mk(Z, Z), x = out.getContext("2d"); x.imageSmoothingQuality = "high"; x.drawImage(v.c, 0, 0, Z, Z);
    const url = jpg(out, Z >= 1600 ? 0.94 : 0.92);
    if (window.__itImg) __itImg.set(url); else { const im = G("itImgP"); if (im) { im.src = url; im.hidden = false; } }
    const done = ["الصورة"], ap = k => { const c = S.ov.querySelector(`[data-ap="${k}"]`); return c && c.checked && !c.disabled; }, fire = el => el && el.dispatchEvent(new Event("input", { bubbles: true }));
    if (ap("name")) { const n = G("itName"), val = K("iName").value.trim(); if (n && val) { n.value = val; n.classList.remove("err"); fire(n); done.push("الاسم"); } }
    if (ap("unit")) { const n = +K("iPcs").value || 0; if (n > 1 && addUnit(K("iUnit").value, n)) done.push("وحدة " + K("iUnit").value + " = " + n); }
    if (ap("bc")) { const g = G("itGtin"); if (g) { g.value = K("iBc").value.trim(); fire(g); done.push("الباركود"); } }
    if (ap("grp")) { const v = K("iGrp").value.trim(); if (v) { if (window.ITC && ITC.setGroup) ITC.setGroup(v); else { const g = G("itGroup"); if (g) g.value = v; } done.push("المجموعة"); } }   // كانت تفتح قائمة الحسابات وتضيع القيمة عند الخروج
    let needQty = false;
    if (ap("batch") && K("dExp") && K("dExp").value) { const qty = +((K("dQty") || {}).value) || 0, b = { exp: K("dExp").value, lot: ((K("dLot") || {}).value || "").trim(), qty, toExpiry: true, open: !(qty > 0) };
      if (window.ITC && ITC.addBatch && ITC.addBatch(b)) { done.push("دفعة الصلاحية " + fmtD(b.exp)); needQty = !(qty > 0); } }
    close(); say("تم: " + done.join(" ، ") + " ✓ — " + (needQty ? "اكتب كمية الدفعة ثم احفظ" : "لا تنس الحفظ"), "s");
  }

  /* ---------------------------------------------------------------- الأحداث */
  function onClick(e) {
    if (!S) return;
    if (e.target === S.ov) return;
    const a = e.target.closest("[data-a]"), src = e.target.closest("[data-src]"), sl = e.target.closest("[data-slot]"), dl = e.target.closest("[data-del]"), vr = e.target.closest("[data-v]"), bg = e.target.closest("[data-bg]");
    if (dl) { e.stopPropagation(); const i = +dl.dataset.del; S.shots[i] = null; if (i === 0 && S.shots[1]) { S.shots[0] = S.shots[1]; S.shots[1] = null; } S.slot = !S.shots[0] ? 0 : i === 0 ? 1 : i; drawSlots(); guideText(); return; }
    if (src) return setSrc(src.dataset.src);
    if (sl) { S.slot = +sl.dataset.slot; drawSlots(); guideText(); return; }
    if (vr) return pick(+vr.dataset.v);
    const lv = e.target.closest("[data-lvl]");
    if (lv) { S.opt.lvl = +lv.dataset.lvl; lsSet("ps.lvl", S.opt.lvl); S.ov.querySelectorAll("[data-lvl]").forEach(b => b.classList.toggle("on", b === lv)); recompose(); return; }
    if (bg) { S.opt.bg = bg.dataset.bg; S.ov.querySelectorAll("[data-bg]").forEach(b => b.classList.toggle("on", b === bg)); recompose(); return; }
    if (!a) return;
    const k = a.dataset.a;
    if (k === "close") close();
    else if (k === "shot") shot();
    else if (k === "go") go();
    else if (k === "apply") apply();
    else if (k === "regen") go();
    else if (k === "edit") editCut();
    else if (k === "adNext") { S.opt.adSeed++; recompose(); }
    else if (k === "reread") reread();
    else if (k === "clrCode") { S.code = null; drawCode(); if (!K("res").hidden) { S.dates = mergeDates(null, S.aiD); if (S.infoDone) drawInfo(); } }
    else if (k === "dAlt") { const x = K("dExp"); if (x && a.dataset.v) { x.value = a.dataset.v; if (S.dates) { S.dates.expAlt = ""; S.dates.level = "manual"; S.dates.exp = a.dataset.v; } drawDates(); } }
    else if (k === "back") { S.run++; K("cap").hidden = false; K("res").hidden = true; K("sideCap").hidden = false; K("sideRes").hidden = true; K("st2").classList.remove("on"); engNote(); setSrc(S.src); }
    else if (k === "saveKey") { const v = K("key").value.trim(); if (!/^[\w.\-]{24,}$/.test(v)) { say("المفتاح غير صالح — انسخه كاملاً من aistudio.google.com (يبدأ غالباً بـ AIza)", "w"); return; } gSetKey(v); localStorage.removeItem("ps.models"); K("keyBox").hidden = true; engNote(); say("تم حفظ مفتاح Gemini ✓", "s"); }
  }
  function onChange(e) {
    if (!S) return; const t = e.target;
    if (t.dataset.k === "dev") { stopCam(); startCam(t.value); }
    else if (t.dataset.k === "eng") { lsSet("ps.eng", t.value); engNote(); }
    else if (t.dataset.k === "size") { S.opt.size = +t.value; lsSet("ps.size", S.opt.size); }
    else if (t.dataset.k === "adTheme") { S.opt.adTheme = t.value; S.opt.adSeed = 0; recompose(); }
    else if (t.dataset.k === "adHead") { S.opt.adHead = t.value.trim(); recompose(); }
    else if (t.dataset.k === "file") { const f = t.files && t.files[0]; if (f) fromBlob(f); t.value = ""; }
    else if (t.dataset.o) { S.opt[t.dataset.o] = t.checked; if (t.dataset.o === "adTitle") lsSet("ps.adTitle", t.checked ? 1 : 0); recompose(); }
  }
  function onKey(e) {
    if (!S) return; e.stopPropagation();
    if (e.key === "Escape") { e.preventDefault(); close(); return; }
    const typing = /INPUT|SELECT|TEXTAREA/.test(e.target.tagName) && e.target.type !== "checkbox";
    /* قارئ الباركود USB/Bluetooth (يكتب بسرعة ثم Enter): QR / GS1 / EAN ← نفس مسار الكاميرا */
    if (!typing && !e.ctrlKey && !e.altKey && !e.metaKey) { const wb = S.wb, now = Date.now();
      if (e.key.length === 1 && e.key !== " ") { if (now - wb.at > 90) wb.s = ""; wb.s += e.key; wb.at = now; }
      else if (e.key === "Enter" && wb.s.length >= 8 && now - wb.at < 200) { e.preventDefault(); const t = wb.s; wb.s = ""; gotCode(t, "gun"); return; } }
    if (!typing && (e.key === " " || e.key === "Enter") && !K("cap").hidden && S.src === "cam" && !e.target.closest("button")) { e.preventDefault(); shot(); return; }
    if (e.key === "Enter" && e.ctrlKey) { e.preventDefault(); if (!K("res").hidden) apply(); else go(); }
  }
  function onPaste(e) { const f = [...(e.clipboardData ? e.clipboardData.items : [])].find(i => /^image\//.test(i.type)); if (f) { e.preventDefault(); fromBlob(f.getAsFile()); } }

  /* ---------------------------------------------------------------- الزر بجانب إطار الصورة */
  function mount() {
    const box = G("itImgBox"); if (!box || G("itStudio")) return;
    const b = document.createElement("div"); b.id = "itStudio"; b.className = "it-studio"; b.tabIndex = 0; b.setAttribute("role", "button");
    b.title = "استوديو الصورة: صوّر المنتج بالكاميرا فننشئ له صورة احترافية ونقرأ اسمه وعدد قطعه (Ctrl+Shift+C)";
    b.innerHTML = `<span class="ic">${IC.cam}<i>${IC.spark}</i></span><b>تصوير ذكي</b>`;
    const r = parseFloat(box.style.right) || 975; b.style.right = (r + box.offsetWidth + 10 || r + 128) + "px";
    if (!box.offsetWidth) b.style.right = (r + 128) + "px";
    box.parentNode.insertBefore(b, box.nextSibling);
    b.addEventListener("click", () => open());
    b.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } });
    /* مربع «صورة إعلانية»: للصنف الذي لا صورة له على Google — يُصوَّر بالكاميرا ويوضع على خلفية إعلانية من اسمه */
    if (window.ANOUER_ADSCENE && !G("itAdShot")) {
      const a = document.createElement("div"); a.id = "itAdShot"; a.className = "it-adshot"; a.tabIndex = 0; a.setAttribute("role", "button");
      a.title = "صورة إعلانية — الصنف ليس له صورة على Google؟ صوّره بالكاميرا فنضعه على خلفية إعلانية جميلة تُرسم من اسمه ووصفه (Ctrl+Shift+D)";
      a.innerHTML = `<span class="ic">${IC.cam}<i>${IC.spark}</i></span><b>صورة إعلانية</b><small>خلفية من اسم الصنف</small><em></em>`;
      a.style.right = r + "px";   // تحت «الصورة» + «تصوير ذكي» بعرضهما (qr-read.js يعيد ضبطه بعد إزاحتهما)
      b.parentNode.insertBefore(a, b.nextSibling);
      a.addEventListener("click", () => open({ ad: true }));
      a.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open({ ad: true }); } });
      document.addEventListener("keydown", e => { if (e.ctrlKey && e.shiftKey && !e.altKey && e.code === "KeyD" && !S) { const v = G("vItem"); if (v && v.offsetParent) { e.preventDefault(); open({ ad: true }); } } });
      /* يلمع عندما يكون الصنف بلا صورة */
      const mark = () => { let has = false; try { has = !!(window.__itImg && __itImg.get()); } catch (e) { } a.classList.toggle("need", !has); };
      mark(); setInterval(() => { if (a.offsetParent) mark(); }, 1200);
    }
    document.addEventListener("keydown", e => { if (e.ctrlKey && e.shiftKey && !e.altKey && e.code === "KeyC" && !S) { const v = G("vItem"); if (v && v.offsetParent) { e.preventDefault(); open(); } } });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount); else mount();

  window.ANOUER_PSTUDIO = { open, close, ai: { has: () => !!gKey(), json: gJSON },   /* مفتاح Gemini المحفوظ — يستعمله «التعرف بالكاميرا» لقراءة اسم العلبة */
    _t: { parseDateText, readOne, mergeDates, addSpan, gotCode: t => gotCode(t, "test"), normInfo, localMask, compose, enhance, cutout, parseJSON, GEN_PROMPT } };
})();
