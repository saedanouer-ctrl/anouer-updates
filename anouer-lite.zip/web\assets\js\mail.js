/* ANOUER — «البريد الإلكتروني» (تحديثات 2026)
   يخدم في أي شاشة: زر «Mail / Email» في المراجعات والقوائم والمستندات والتقارير يفتح نافذة إرسال احترافية:
   • المرسَل إليه بالاقتراح (العملاء والموردون اللي عندهم بريد + آخر العناوين) ، نسخة CC ، الموضوع ، الرسالة ، التوقيع
   • المرفقات تتجهّز وحدها: PDF بنفس تصميم الطباعة (فاتورة / سند / مشتريات …) ، PDF للقائمة أو التقرير ، Excel (CSV)
   • الإرسال مباشرة من البرنامج عبر SMTP (Gmail ، Outlook ، Yahoo ، Zoho ، أي خادم) — بلا برنامج بريد خارجي
   • «إعدادات البريد»: قوالب جاهزة + إرسال تجريبي + سجل المرسَل
   API: ANOUER_MAIL.compose(o) / settings() / viaPrint(fn, o) / review(o) / table(o) / report(res, name) */
(function () {
  "use strict";
  if (window.ANOUER_MAIL) return;
  const A = () => window.Anouer, HOST = () => !!(A() && A().available && A().call), call = (a, p) => A().call(a, p || {});
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const say = (m, k) => { try { toast(m, k || "i"); } catch (e) { } };
  const snd = k => { try { window.ANOUER_SOUND && ANOUER_SOUND(k); } catch (e) { } };
  const N = v => (Math.round((+v || 0) * 100) / 100).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const RX = /^[^\s@<>,;]+@[^\s@<>,;]+\.[^\s@<>,;]{2,}$/;
  const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } } };
  const RECENT = "anouer.mail.recent";
  const fname = s => String(s || "ANOUER").replace(/[\\/:*?"<>|]+/g, "_").trim().slice(0, 90);
  const today = () => { const d = new Date(), p = n => String(n).padStart(2, "0"); return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()); };

  /* ------------------------------------------------------------ الإعدادات والجهات */
  let CFG = null, CONTACTS = null, CT_AT = 0, CO = null;
  const cfg = force => (!force && CFG) ? Promise.resolve(CFG) : (HOST() ? call("fm.mail.cfg").then(c => (CFG = c || {})) : Promise.resolve(CFG = {}));
  const contacts = () => (CONTACTS && Date.now() - CT_AT < 300000) ? Promise.resolve(CONTACTS) : (HOST() ? call("fm.mail.contacts").then(l => { CONTACTS = Array.isArray(l) ? l : []; CT_AT = Date.now(); return CONTACTS; }).catch(() => []) : Promise.resolve([]));
  const company = () => CO ? Promise.resolve(CO) : (HOST() ? call("fm.settings.get", { prefix: "Company." }).then(d => (CO = { name: (d && (d["Company.Name"] || d["Company.TradeName"])) || "ANOUER", phone: (d && d["Company.Phone"]) || "", mail: (d && d["Company.Email"]) || "", addr: (d && d["Company.Address"]) || "" })).catch(() => ({ name: "ANOUER" })) : Promise.resolve({ name: "ANOUER" }));
  const mailOf = name => contacts().then(l => { const n = String(name || "").trim(); const c = n && l.find(x => x.name === n); return c ? c.mail : ""; });

  /* ------------------------------------------------------------ CSS */
  (function () {
    const st = document.createElement("style"); st.id = "mlCss";
    st.textContent = `
.ml-ov{position:fixed;inset:0;z-index:100070;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,.42);backdrop-filter:blur(6px);animation:mlF .18s;direction:rtl;font:13px "Segoe UI",Tahoma,sans-serif;color:#0f172a}
@keyframes mlF{from{opacity:0}}@keyframes mlIn{from{opacity:0;transform:translateY(14px) scale(.98)}}
.ml-w{width:640px;max-width:calc(100vw - 30px);max-height:calc(100vh - 30px);display:flex;flex-direction:column;border-radius:22px;background:#fff;box-shadow:0 34px 90px -26px rgba(15,23,42,.6);overflow:hidden;animation:mlIn .26s cubic-bezier(.2,1,.3,1)}
.ml-hd{display:flex;align-items:center;gap:12px;padding:16px 20px 14px;background:radial-gradient(120% 140% at 100% 0,#e8f0ff 0,transparent 60%),radial-gradient(120% 140% at 0 0,#fff1e6 0,transparent 55%),#fbfcfe;border-bottom:1px solid #eef1f5}
.ml-ic{width:44px;height:44px;border-radius:14px;flex:none;display:grid;place-items:center;background:linear-gradient(145deg,#3b82f6,#1d4ed8);box-shadow:inset 0 1px 0 rgba(255,255,255,.4),0 10px 22px -10px #1d4ed8}
.ml-ic svg{width:24px;height:24px}
.ml-hd h3{margin:0;font-size:16px}.ml-hd small{display:block;color:#5b6478;font-size:12px;margin-top:2px;direction:ltr;text-align:right;unicode-bidi:plaintext}
.ml-x{margin-right:auto;border:0;background:transparent;color:#94a3b8;font-size:16px;cursor:pointer;width:32px;height:32px;border-radius:9px}.ml-x:hover{background:#f1f5f9;color:#0f172a}
.ml-g{border:0;background:transparent;cursor:pointer;width:32px;height:32px;border-radius:9px;color:#475569;font-size:16px}.ml-g:hover{background:#f1f5f9}
.ml-bd{padding:14px 20px 4px;overflow:auto;display:flex;flex-direction:column;gap:10px}
.ml-row{display:flex;align-items:flex-start;gap:10px}
.ml-row>label{flex:none;width:64px;padding-top:9px;color:#64748b;font-weight:600;font-size:12.5px}
.ml-field{flex:1;min-height:38px;display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:4px 8px;border:1.5px solid #e2e8f0;border-radius:12px;background:#fff;position:relative;cursor:text}
.ml-field:focus-within{border-color:#3b82f6;box-shadow:0 0 0 4px rgba(59,130,246,.12)}
.ml-field input{flex:1;min-width:140px;border:0;outline:0;font:inherit;height:28px;background:transparent;direction:ltr;text-align:left}
.ml-field input.rtl{direction:rtl;text-align:right}
.ml-chip{display:inline-flex;align-items:center;gap:6px;height:26px;padding:0 6px 0 10px;border-radius:999px;background:#eff6ff;color:#1d4ed8;font-weight:600;font-size:12px;direction:ltr}
.ml-chip.bad{background:#fee2e2;color:#b91c1c}.ml-chip b{font-weight:700;direction:rtl}.ml-chip i{font-style:normal;cursor:pointer;opacity:.6;padding:0 3px}.ml-chip i:hover{opacity:1}
.ml-sug{position:absolute;top:calc(100% + 4px);right:0;left:0;z-index:5;background:#fff;border:1px solid #e2e8f0;border-radius:12px;box-shadow:0 18px 40px -16px rgba(15,23,42,.35);max-height:220px;overflow:auto;padding:4px;display:none}
.ml-sug.on{display:block}.ml-sug div{display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:9px;cursor:pointer}
.ml-sug div.on,.ml-sug div:hover{background:#eff6ff}.ml-sug b{font-weight:600}.ml-sug span{margin-right:auto;color:#64748b;direction:ltr;font-size:12px}.ml-sug em{font-style:normal;font-size:10.5px;padding:1px 7px;border-radius:999px;background:#f1f5f9;color:#475569}
.ml-sub{width:100%;height:38px;border:1.5px solid #e2e8f0;border-radius:12px;padding:0 12px;font:inherit;font-weight:600;outline:0}
.ml-sub:focus,.ml-msg:focus{border-color:#3b82f6;box-shadow:0 0 0 4px rgba(59,130,246,.12)}
.ml-msg{width:100%;min-height:150px;resize:vertical;border:1.5px solid #e2e8f0;border-radius:12px;padding:10px 12px;font:13px/1.7 "Segoe UI",Tahoma,sans-serif;outline:0}
.ml-att{display:flex;flex-wrap:wrap;gap:8px}
.ml-a{display:flex;align-items:center;gap:9px;padding:8px 10px 8px 12px;border-radius:12px;border:1px solid #e2e8f0;background:#f8fafc;min-width:190px;max-width:100%}
.ml-a .fi{width:32px;height:38px;border-radius:6px;display:grid;place-items:center;color:#fff;font:800 9.5px "Segoe UI";flex:none}
.ml-a .fi.pdf{background:linear-gradient(160deg,#ef4444,#b91c1c)}.ml-a .fi.xls{background:linear-gradient(160deg,#22c55e,#15803d)}.ml-a .fi.oth{background:#64748b}
.ml-a b{display:block;font-size:12px;max-width:230px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr;text-align:right}.ml-a small{color:#64748b;font-size:11px}.ml-a small.e{color:#b91c1c}
.ml-a .x{margin-right:auto;border:0;background:transparent;cursor:pointer;color:#94a3b8;font-size:13px}
.ml-sp{width:14px;height:14px;border-radius:50%;border:2px solid #cbd5e1;border-top-color:#3b82f6;animation:mlS .8s linear infinite;display:inline-block;vertical-align:-2px}@keyframes mlS{to{transform:rotate(360deg)}}
.ml-warn{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;background:#fff8e6;border:1px solid #fde3a7;color:#7a4b00;font-weight:600}
.ml-warn button{margin-right:auto}
.ml-ft{display:flex;align-items:center;gap:8px;padding:12px 20px 16px;border-top:1px solid #f1f5f9}
.ml-ft .hint{color:#94a3b8;font-size:11px}
.ml-b{height:40px;border-radius:12px;font:inherit;font-weight:700;cursor:pointer;padding:0 16px;border:1px solid #e2e8f0;background:#fff;color:#334155}
.ml-b:hover{background:#f8fafc}
.ml-go{border:0;color:#fff;background:linear-gradient(145deg,#3b82f6,#2563eb 55%,#1d4ed8);box-shadow:inset 0 1px 0 rgba(255,255,255,.35),0 10px 22px -12px #1d4ed8;min-width:150px;display:inline-flex;align-items:center;justify-content:center;gap:8px}
.ml-go:hover{filter:brightness(1.05)}.ml-go:disabled{opacity:.55;cursor:default;filter:none}
.ml-done{padding:36px 24px 30px;text-align:center}.ml-done .ok{width:74px;height:74px;margin:0 auto 14px;border-radius:50%;display:grid;place-items:center;font-size:36px;color:#fff;background:linear-gradient(145deg,#22c55e,#15803d);box-shadow:0 18px 36px -14px #15803d;animation:mlIn .4s cubic-bezier(.2,1.4,.4,1)}
.ml-done h3{margin:0 0 6px;font-size:18px}.ml-done p{margin:0;color:#64748b;direction:ltr;unicode-bidi:plaintext}
.ml-pre{display:flex;flex-wrap:wrap;gap:8px}.ml-pre button{height:36px;padding:0 14px;border-radius:11px;border:1.5px solid #e2e8f0;background:#fff;font:inherit;font-weight:700;cursor:pointer}
.ml-pre button.on{border-color:#3b82f6;background:#eff6ff;color:#1d4ed8}
.ml-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.ml-grid label{display:flex;flex-direction:column;gap:5px;font-weight:600;font-size:12px;color:#475569}
.ml-grid input,.ml-grid textarea{height:38px;border:1.5px solid #e2e8f0;border-radius:11px;padding:0 11px;font:inherit;outline:0}
.ml-grid textarea{height:70px;padding:8px 11px;resize:vertical}.ml-grid input:focus,.ml-grid textarea:focus{border-color:#3b82f6;box-shadow:0 0 0 4px rgba(59,130,246,.12)}
.ml-grid .full{grid-column:1/-1}.ml-grid .ltr{direction:ltr;text-align:left}
.ml-tip{padding:10px 12px;border-radius:12px;background:#f0f7ff;border:1px solid #cfe1ff;color:#1e3a8a;font-size:12px;line-height:1.7}
.ml-tabs{display:flex;gap:4px;padding:0 20px;border-bottom:1px solid #eef1f5}.ml-tabs button{border:0;background:transparent;padding:10px 12px;font:inherit;font-weight:700;color:#64748b;cursor:pointer;border-bottom:3px solid transparent}.ml-tabs button.on{color:#1d4ed8;border-bottom-color:#3b82f6}
.ml-log{width:100%;border-collapse:collapse}.ml-log td,.ml-log th{padding:7px 8px;border-bottom:1px solid #f1f5f9;text-align:right;font-size:12px;vertical-align:top}.ml-log th{color:#64748b}
.ml-st{padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700}.ml-st.ok{background:#dcfce7;color:#15803d}.ml-st.no{background:#fee2e2;color:#b91c1c}
.ml-menu{position:fixed;z-index:100080;min-width:250px;background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 22px 50px -18px rgba(15,23,42,.4);padding:6px;direction:rtl;font:13px "Segoe UI",Tahoma,sans-serif;animation:mlIn .16s}
.ml-menu button{display:flex;align-items:center;gap:10px;width:100%;border:0;background:transparent;padding:9px 10px;border-radius:10px;font:inherit;cursor:pointer;text-align:right;color:#0f172a}
.ml-menu button:hover{background:#eff6ff}.ml-menu button small{display:block;color:#64748b;font-size:11px}.ml-menu .fi{width:26px;height:30px;font-size:8px}
.ml-menu hr{border:0;border-top:1px solid #f1f5f9;margin:4px 6px}
html.dark .ml-w,html.dark .ml-menu,html.dark .ml-sug{background:#111624;color:#eef2fb;border-color:rgba(255,255,255,.08)}
html.dark .ml-hd{background:rgba(255,255,255,.03);border-color:rgba(255,255,255,.06)}
html.dark .ml-field,html.dark .ml-sub,html.dark .ml-msg,html.dark .ml-grid input,html.dark .ml-grid textarea,html.dark .ml-b,html.dark .ml-pre button{background:rgba(255,255,255,.04);color:#eef2fb;border-color:rgba(255,255,255,.12)}
html.dark .ml-a{background:rgba(255,255,255,.04);border-color:rgba(255,255,255,.1)}html.dark .ml-chip{background:rgba(59,130,246,.18);color:#cfe0ff}
html.dark .ml-menu button{color:#eef2fb}html.dark .ml-menu button:hover,html.dark .ml-sug div.on,html.dark .ml-sug div:hover{background:rgba(59,130,246,.14)}
html.dark .ml-tip{background:rgba(59,130,246,.1);border-color:rgba(59,130,246,.25);color:#cfe0ff}html.dark .ml-ft{border-color:rgba(255,255,255,.06)}`;
    document.head.appendChild(st);
  })();
  const ENV = '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/></svg>';
  const fileIc = n => /\.pdf$/i.test(n) ? '<span class="fi pdf">PDF</span>' : /\.(xlsx?|csv)$/i.test(n) ? '<span class="fi xls">XLS</span>' : '<span class="fi oth">FILE</span>';
  function modal(html, w) {
    const ov = document.createElement("div"); ov.className = "ml-ov";
    ov.innerHTML = `<div class="ml-w" role="dialog" aria-modal="true" ${w ? `style="width:${w}px"` : ""}>${html}</div>`;
    document.body.appendChild(ov);
    const close = () => { ov.remove(); document.removeEventListener("keydown", key, true); };
    const key = e => { if (e.key === "Escape") { const s = ov.querySelector(".ml-sug.on"); if (s) { s.classList.remove("on"); } else close(); e.preventDefault(); e.stopPropagation(); } };
    document.addEventListener("keydown", key, true);
    ov.addEventListener("mousedown", e => { if (e.target === ov) close(); });
    ov.querySelectorAll("[data-close]").forEach(b => b.onclick = close);
    return { ov, w: ov.firstElementChild, close };
  }

  /* ------------------------------------------------------------ إعدادات البريد */
  const PRE = {
    gmail: { t: "Gmail", host: "smtp.gmail.com", port: 587, tip: "Gmail: فعّل «التحقق بخطوتين» في حسابك ، ثم أنشئ «كلمة مرور التطبيق» (16 حرف) من: حساب Google ← الأمان ← كلمات مرور التطبيقات ، والصقها هنا (ماشي كلمة سر حسابك)." },
    outlook: { t: "Outlook / Hotmail", host: "smtp.office365.com", port: 587, tip: "Outlook / Hotmail: استعمل بريدك وكلمة السر (إذا كان التحقق بخطوتين مفعّل: كلمة مرور التطبيق)." },
    yahoo: { t: "Yahoo", host: "smtp.mail.yahoo.com", port: 587, tip: "Yahoo: أنشئ «App password» من إعدادات أمان الحساب والصقها هنا." },
    zoho: { t: "Zoho", host: "smtp.zoho.com", port: 587, tip: "Zoho Mail: بريدك وكلمة السر (أو كلمة مرور التطبيق)." },
    custom: { t: "خادم آخر", host: "", port: 587, tip: "خادم SMTP خاص (بريد شركتك / الاستضافة): المنفذ 587 مع STARTTLS." }
  };
  const preOf = (host, user) => { host = String(host || ""); user = String(user || "").toLowerCase();
    for (const k in PRE) if (PRE[k].host && host === PRE[k].host) return k;
    if (/@gmail\.com$/.test(user)) return "gmail"; if (/@(outlook|hotmail|live)\./.test(user)) return "outlook"; if (/@yahoo\./.test(user)) return "yahoo"; return host ? "custom" : "gmail"; };

  function settings(then) {
    if (!HOST()) { say("إعدادات البريد تعمل داخل البرنامج", "w"); return; }
    Promise.all([cfg(true), company()]).then(([c, co]) => {
      let pk = preOf(c.host, c.user);
      const M = modal(`<div class="ml-hd"><span class="ml-ic">${ENV}</span><div><h3>إعدادات البريد الإلكتروني</h3><small>إرسال الفواتير والتقارير مباشرة من البرنامج</small></div><button class="ml-x" data-close>✕</button></div>
        <div class="ml-tabs"><button class="on" data-t="cfg">الحساب</button><button data-t="log">سجل المرسَل</button></div>
        <div class="ml-bd" data-p="cfg"><div class="ml-pre">${Object.keys(PRE).map(k => `<button type="button" data-k="${k}" class="${k === pk ? "on" : ""}">${PRE[k].t}</button>`).join("")}</div>
          <div class="ml-tip" data-tip></div>
          <div class="ml-grid">
            <label>بريدك الإلكتروني<input class="ltr" data-f="user" type="email" placeholder="name@gmail.com" value="${esc(c.user || "")}"></label>
            <label>كلمة مرور التطبيق<input class="ltr" data-f="pass" type="password" autocomplete="new-password" placeholder="${c.hasPass ? "•••••••• (محفوظة — اتركها فارغة)" : "xxxx xxxx xxxx xxxx"}"></label>
            <label>اسم المرسِل<input data-f="fromName" value="${esc(c.fromName || co.name || "")}" placeholder="اسم المحل / الشركة"></label>
            <label>بريد المرسِل (اختياري)<input class="ltr" data-f="from" type="email" value="${esc(c.from || "")}" placeholder="نفس البريد"></label>
            <label data-adv>خادم SMTP<input class="ltr" data-f="host" value="${esc(c.host || PRE[pk].host)}"></label>
            <label data-adv>المنفذ<input class="ltr" data-f="port" value="${esc(c.port || 587)}"></label>
            <label class="full">التوقيع (يظهر تحت كل رسالة)<textarea data-f="sig" placeholder="مثال: محمد — سوبيرات أنوار — 0550 12 34 56">${esc(c.sig || "")}</textarea></label>
            <label class="full" style="flex-direction:row;align-items:center;gap:8px;font-weight:600"><input type="checkbox" data-f="bccMe" style="height:auto" ${c.bccMe ? "checked" : ""}> أرسل لي نسخة من كل رسالة (BCC)</label>
          </div><div data-st></div></div>
        <div class="ml-bd" data-p="log" style="display:none"></div>
        <div class="ml-ft"><button class="ml-b" data-test>✉️ إرسال تجريبي</button><span style="flex:1"></span><button class="ml-b" data-close>إلغاء</button><button class="ml-b ml-go" data-save>حفظ</button></div>`, 600);
      const w = M.w, F = k => w.querySelector(`[data-f="${k}"]`), st = w.querySelector("[data-st]");
      const tip = () => { w.querySelector("[data-tip]").textContent = PRE[pk].tip; w.querySelectorAll("[data-adv]").forEach(x => x.style.display = pk === "custom" ? "" : "none"); };
      tip();
      w.querySelectorAll(".ml-pre button").forEach(b => b.onclick = () => { pk = b.dataset.k; w.querySelectorAll(".ml-pre button").forEach(x => x.classList.toggle("on", x === b)); if (PRE[pk].host) { F("host").value = PRE[pk].host; F("port").value = PRE[pk].port; } tip(); });
      F("user").addEventListener("change", () => { const k = preOf("", F("user").value); if (k !== "custom" && k !== pk) w.querySelector(`.ml-pre [data-k="${k}"]`).click(); });
      w.querySelectorAll(".ml-tabs button").forEach(b => b.onclick = () => {
        w.querySelectorAll(".ml-tabs button").forEach(x => x.classList.toggle("on", x === b));
        w.querySelectorAll("[data-p]").forEach(p => p.style.display = p.dataset.p === b.dataset.t ? "" : "none");
        if (b.dataset.t === "log") {
          const p = w.querySelector('[data-p="log"]'); p.innerHTML = '<div style="padding:30px;text-align:center;color:#94a3b8"><span class="ml-sp"></span></div>';
          call("fm.mail.log").then(l => { l = Array.isArray(l) ? l : [];
            p.innerHTML = l.length ? `<table class="ml-log"><tr><th>الوقت</th><th>إلى</th><th>الموضوع</th><th></th></tr>${l.slice(0, 120).map(x => `<tr><td style="white-space:nowrap">${esc(String(x.at || "").slice(5, 16))}</td><td style="direction:ltr;text-align:right">${esc(x.to)}</td><td>${esc(x.subject)}${x.files && x.files.length ? `<br><small style="color:#94a3b8">📎 ${esc(x.files.join("، "))}</small>` : ""}</td><td>${x.ok ? '<span class="ml-st ok">✓ أُرسل</span>' : `<span class="ml-st no" title="${esc(x.err || "")}">✕ خطأ</span>`}</td></tr>`).join("")}</table>` : '<div style="padding:34px;text-align:center;color:#94a3b8">📭 لا توجد رسائل مرسلة بعد</div>'; });
        }
      });
      const save = () => {
        const o = { host: F("host").value.trim() || PRE[pk].host, port: F("port").value.trim() || "587", ssl: true, user: F("user").value.trim(), pass: F("pass").value, from: F("from").value.trim(), fromName: F("fromName").value.trim(), sig: F("sig").value.trim(), bccMe: F("bccMe").checked };
        if (!RX.test(o.user)) { F("user").focus(); st.innerHTML = '<div class="ml-warn">أدخل بريدك الإلكتروني بشكل صحيح</div>'; return Promise.reject(); }
        if (!c.hasPass && !o.pass) { F("pass").focus(); st.innerHTML = '<div class="ml-warn">أدخل كلمة مرور التطبيق</div>'; return Promise.reject(); }
        return call("fm.mail.saveCfg", o).then(n => { CFG = n; c = n; F("pass").value = ""; F("pass").placeholder = "•••••••• (محفوظة — اتركها فارغة)"; return n; })
          .catch(e => { st.innerHTML = `<div class="ml-warn">${esc(e && e.message || e)}</div>`; throw e; });
      };
      w.querySelector("[data-save]").onclick = () => save().then(() => { say("تم حفظ إعدادات البريد ✓", "s"); M.close(); if (then) then(); }, () => { });
      w.querySelector("[data-test]").onclick = () => {
        const b = w.querySelector("[data-test]"); b.disabled = true; b.innerHTML = '<span class="ml-sp"></span> جارٍ الإرسال …';
        save().then(n => company().then(co => call("fm.mail.send", { to: n.from || n.user, subject: "✓ رسالة تجريبية من ANOUER", html: tpl({ co, hi: "مرحباً 👋", lines: ["هذه رسالة تجريبية — إعدادات البريد في برنامج ANOUER تعمل بنجاح.", "من الآن تقدر تبعث الفواتير والتقارير والقوائم مباشرة من البرنامج."], sig: n.sig }), tag: "test" })))
          .then(() => { st.innerHTML = '<div class="ml-warn" style="background:#ecfdf5;border-color:#bbf7d0;color:#166534">✓ وصلت الرسالة التجريبية لبريدك — كلشي يخدم</div>'; snd("ok"); },
            e => { if (e) st.innerHTML = `<div class="ml-warn">✕ ${esc(e && e.message || e)}</div>`; snd("err"); })
          .finally(() => { b.disabled = false; b.innerHTML = "✉️ إرسال تجريبي"; });
      };
      setTimeout(() => (c.user ? (c.hasPass ? F("fromName") : F("pass")) : F("user")).focus(), 60);
    });
  }

  /* ------------------------------------------------------------ قالب الرسالة (HTML احترافي) */
  function tpl(o) {
    const co = o.co || {}, lines = (o.lines || []).map(l => `<p style="margin:0 0 10px">${esc(l)}</p>`).join("");
    const box = o.box && o.box.length ? `<table role="presentation" style="width:100%;border-collapse:collapse;margin:14px 0;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px">${o.box.map(r => `<tr><td style="padding:8px 14px;color:#64748b;font-size:13px">${esc(r[0])}</td><td style="padding:8px 14px;font-weight:700;font-size:14px;text-align:left">${esc(r[1])}</td></tr>`).join("")}</table>` : "";
    const sig = o.sig ? `<p style="margin:16px 0 0;white-space:pre-line;color:#334155">${esc(o.sig)}</p>` : "";
    return `<!DOCTYPE html><html dir="rtl" lang="ar"><body style="margin:0;padding:0;background:#f1f5f9">
<table role="presentation" width="100%" style="background:#f1f5f9;padding:24px 0"><tr><td align="center">
<table role="presentation" width="600" style="max-width:600px;width:100%;background:#ffffff;border-radius:14px;overflow:hidden;font-family:Segoe UI,Tahoma,Arial,sans-serif;color:#0f172a;direction:rtl;text-align:right">
<tr><td style="background:linear-gradient(135deg,#1d4ed8,#3b82f6);background-color:#1d4ed8;padding:18px 24px;color:#ffffff"><div style="font-size:19px;font-weight:800">${esc(co.name || "ANOUER")}</div>${co.phone || co.mail ? `<div style="font-size:12px;opacity:.85;margin-top:3px;direction:ltr;text-align:right">${esc([co.phone, co.mail].filter(Boolean).join("  ·  "))}</div>` : ""}</td></tr>
<tr><td style="padding:24px 24px 8px;font-size:14px;line-height:1.75">${o.hi ? `<p style="margin:0 0 12px;font-weight:700">${esc(o.hi)}</p>` : ""}${lines}${box}${o.att ? `<p style="margin:10px 0 0;color:#475569">📎 المرفقات: ${esc(o.att)}</p>` : ""}${sig}</td></tr>
<tr><td style="padding:14px 24px 20px;font-size:11px;color:#94a3b8;border-top:1px solid #f1f5f9">أُرسلت من برنامج <b style="color:#ea580c">ANOUER</b> لإدارة المبيعات ونقاط البيع</td></tr>
</table></td></tr></table></body></html>`;
  }

  /* ------------------------------------------------------------ مولّدات المرفقات */
  function pdfHtml(html, name, w, h) {
    if (!HOST()) return Promise.reject(new Error("PDF يعمل داخل البرنامج"));
    return call("print.pdf", { html, w: w || 210, h: h || 297, fileName: fname(name), noOpen: true }).then(r => { if (!r || !r.ok || !r.path) throw new Error("تعذّر إنشاء PDF"); return { path: r.path }; });
  }
  /* مستند بتصميم الطباعة (أفضّل A4 للبريد) */
  function txPdf(o, name) {
    const RD = window.ANOUER_RD; if (!RD) return Promise.reject(new Error("تصميم الطباعة غير متاح"));
    return Promise.all([RD.company(), RD.candidates(o.tx, o.kind, RD.branchName ? RD.branchName() : "")]).then(([co, list]) => {
      list = list || [];
      const a4 = x => (x._A && x._A.a4) || /a4/i.test((x.paper || "") + " " + (x.name || "") + " " + ((x._d && x._d.w) || ""));
      const it = o.item || list.find(x => a4(x) && x.def) || list.find(a4) || list.find(x => x.def) || list[0] || null;
      return (it ? RD.getDesign(it) : Promise.resolve(null)).then(d => {
        if (!d) d = RD.fallbackDesign(o.tx);
        const res = RD.render(d, Object.assign({ company: co }, o.data || {}));
        const H = res.roll ? Math.max.apply(null, res.pages.map(p => p.h)) : res.h;
        return pdfHtml(RD.docHTML(res, name), name, res.w, H);
      });
    });
  }
  function tableHtml(o, co) {
    const cols = o.cols || [], rows = o.rows || [];
    const sums = cols.map(c => c.sum ? rows.reduce((s, r) => s + (parseFloat(String(c.f(r)).replace(/,/g, "")) || 0), 0) : null);
    const land = cols.length > 7;
    return `<!DOCTYPE html><html dir="rtl"><head><meta charset="utf-8"><style>@page{size:A4 ${land ? "landscape" : "portrait"};margin:12mm}body{font-family:Segoe UI,Tahoma,Arial,sans-serif;color:#0f172a;font-size:11px}
h1{font-size:18px;margin:0}.top{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:3px solid #1d4ed8;padding-bottom:8px;margin-bottom:12px}.co{font-size:14px;font-weight:800;color:#1d4ed8}.mt{color:#64748b;font-size:11px}
table{width:100%;border-collapse:collapse}th{background:#1d4ed8;color:#fff;padding:7px 6px;text-align:right;font-size:11px}td{padding:6px;border-bottom:1px solid #e2e8f0}tr:nth-child(even) td{background:#f8fafc}
tfoot td{font-weight:800;background:#eef4ff!important;border-top:2px solid #1d4ed8}.ft{margin-top:12px;color:#94a3b8;font-size:9.5px;text-align:center}</style></head><body>
<div class="top"><div><h1>${esc(o.title || "")}</h1><div class="mt">${esc(o.sub || "")} · ${rows.length} سطر · ${today()}</div></div><div class="co">${esc(co.name || "ANOUER")}</div></div>
<table><thead><tr>${cols.map(c => `<th>${esc(c.t)}</th>`).join("")}</tr></thead><tbody>${rows.map(r => `<tr>${cols.map(c => { let v; try { v = c.f(r); } catch (e) { v = ""; } return `<td>${esc(v == null ? "" : v)}</td>`; }).join("")}</tr>`).join("")}</tbody>
${sums.some(x => x != null) ? `<tfoot><tr>${sums.map((s, i) => `<td>${s != null ? N(s) : i === 0 ? "الإجمالي" : ""}</td>`).join("")}</tr></tfoot>` : ""}</table>
<div class="ft">ANOUER — ${esc(co.name || "")}</div></body></html>`;
  }
  const tablePdf = o => company().then(co => pdfHtml(tableHtml(o, co), o.title || "قائمة", (o.cols || []).length > 7 ? 297 : 210, (o.cols || []).length > 7 ? 210 : 297));
  function csvB64(o) {
    const q = v => { v = String(v == null ? "" : v); return /[",\n;]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    const txt = "﻿" + [o.cols.map(c => q(c.t)).join(",")].concat(o.rows.map(r => o.cols.map(c => { let v; try { v = c.f(r); } catch (e) { v = ""; } return q(v); }).join(","))).join("\r\n");
    const b = new TextEncoder().encode(txt); let s = ""; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
    return Promise.resolve({ b64: btoa(s), type: "text/csv" });
  }

  /* ------------------------------------------------------------ نافذة الإرسال */
  function compose(o) {
    o = o || {};
    if (!HOST()) { say("الإرسال بالبريد يعمل داخل البرنامج", "w"); return; }
    Promise.all([cfg(), company(), contacts()]).then(([c, co, cts]) => {
      const to = [], cc = [];
      (o.to || []).forEach(x => x && to.push(x)); (o.cc || []).forEach(x => x && cc.push(x));
      const att = (o.attach || []).map(a => Object.assign({ st: "wait" }, a));
      const M = modal(`<div class="ml-hd"><span class="ml-ic">${ENV}</span><div><h3>${esc(o.head || "إرسال بالبريد الإلكتروني")}</h3><small data-from>${c.ready ? esc((c.fromName ? c.fromName + " <" : "") + (c.from || c.user) + (c.fromName ? ">" : "")) : "البريد غير مُعدّ"}</small></div><button class="ml-g" data-cfg title="إعدادات البريد">⚙</button><button class="ml-x" data-close>✕</button></div>
        <div class="ml-bd">${c.ready ? "" : '<div class="ml-warn">⚠️ البريد غير مُعدّ بعد — مرة وحدة برك <button class="ml-b" data-cfg2 style="height:32px">إعداد البريد</button></div>'}
          <div class="ml-row"><label>إلى</label><div class="ml-field" data-to><input data-in="to" placeholder="بريد أو اسم عميل / مورد …" autocomplete="off"><div class="ml-sug"></div></div></div>
          <div class="ml-row" data-ccrow style="display:${cc.length ? "flex" : "none"}"><label>نسخة CC</label><div class="ml-field" data-cc><input data-in="cc" placeholder="بريد …" autocomplete="off"><div class="ml-sug"></div></div></div>
          <div class="ml-row"><label>الموضوع</label><input class="ml-sub" data-sub value="${esc(o.subject || "")}"></div>
          <div class="ml-row"><label>الرسالة</label><textarea class="ml-msg" data-msg></textarea></div>
          ${att.length ? '<div class="ml-row"><label>المرفقات</label><div class="ml-att" data-att style="flex:1"></div></div>' : ""}
        </div>
        <div class="ml-ft"><button class="ml-b" data-addcc style="height:34px;padding:0 10px">+ نسخة CC</button><span class="hint">Ctrl+Enter للإرسال</span><span style="flex:1"></span><button class="ml-b" data-close>إلغاء</button><button class="ml-b ml-go" data-send>إرسال ➤</button></div>`, 660);
      const w = M.w, msg = w.querySelector("[data-msg]");
      msg.value = (o.lines || []).join("\n") + (c.sig ? "\n\n" + c.sig : "");
      /* المرسَل إليه: شرائح + اقتراحات */
      function chips(box, arr) {
        const inp = box.querySelector("input"), sug = box.querySelector(".ml-sug");
        const draw = () => { box.querySelectorAll(".ml-chip").forEach(x => x.remove()); arr.forEach((m, i) => { const ct = cts.find(x => x.mail.toLowerCase() === String(m).toLowerCase()); const ch = document.createElement("span"); ch.className = "ml-chip" + (RX.test(m) ? "" : " bad"); ch.innerHTML = `${ct ? `<b>${esc(ct.name)}</b>` : ""}${esc(m)}<i title="حذف">✕</i>`; ch.querySelector("i").onclick = () => { arr.splice(i, 1); draw(); }; box.insertBefore(ch, inp); }); };
        const add = v => { v = String(v || "").trim().replace(/[,;]+$/, ""); if (!v) return; if (!arr.some(x => x.toLowerCase() === v.toLowerCase())) arr.push(v); inp.value = ""; draw(); sug.classList.remove("on"); };
        let L = [], k = 0;
        const show = () => {
          const q = inp.value.trim().toLowerCase(), rec = LS.get(RECENT, []);
          const pool = cts.map(x => ({ n: x.name, m: x.mail, t: x.t === "s" ? "مورد" : "عميل" })).concat(rec.filter(m => !cts.some(x => x.mail === m)).map(m => ({ n: "", m, t: "حديث" })));
          L = pool.filter(x => !arr.includes(x.m) && (!q || x.m.toLowerCase().includes(q) || String(x.n).toLowerCase().includes(q))).slice(0, 8); k = 0;
          sug.innerHTML = L.map((x, i) => `<div data-i="${i}" class="${i ? "" : "on"}"><b>${esc(x.n || x.m)}</b><em>${x.t}</em><span>${esc(x.n ? x.m : "")}</span></div>`).join("");
          sug.classList.toggle("on", !!L.length && (q.length > 0 || document.activeElement === inp));
        };
        inp.addEventListener("input", show); inp.addEventListener("focus", show);
        inp.addEventListener("blur", () => setTimeout(() => { sug.classList.remove("on"); if (inp.value.trim()) add(inp.value); }, 150));
        inp.addEventListener("keydown", e => {
          const on = sug.classList.contains("on") && L.length;
          if (on && (e.key === "ArrowDown" || e.key === "ArrowUp")) { e.preventDefault(); k = (k + (e.key === "ArrowDown" ? 1 : -1) + L.length) % L.length; sug.querySelectorAll("div").forEach((d, i) => d.classList.toggle("on", i === k)); return; }
          if (e.key === "Enter" || e.key === "," || e.key === ";" || (e.key === "Tab" && inp.value.trim())) { if (e.ctrlKey) return; e.preventDefault(); if (on && (!inp.value.includes("@") || e.key === "Enter")) add(L[k].m); else add(inp.value); }
          else if (e.key === "Backspace" && !inp.value && arr.length) { arr.pop(); draw(); }
        });
        sug.addEventListener("mousedown", e => { const d = e.target.closest("[data-i]"); if (d) { e.preventDefault(); add(L[+d.dataset.i].m); inp.focus(); } });
        box.addEventListener("mousedown", e => { if (e.target === box) { e.preventDefault(); inp.focus(); } });
        draw(); return { add, inp };
      }
      const TO = chips(w.querySelector("[data-to]"), to), CC = chips(w.querySelector("[data-cc]"), cc);
      w.querySelector("[data-addcc]").onclick = () => { w.querySelector("[data-ccrow]").style.display = "flex"; CC.inp.focus(); };
      const openCfg = () => settings(() => { cfg().then(n => { c = n; const f = w.querySelector("[data-from]"); f.textContent = (n.fromName ? n.fromName + " <" : "") + (n.from || n.user) + (n.fromName ? ">" : ""); const wr = w.querySelector(".ml-warn"); if (wr && n.ready) wr.remove(); if (n.sig && !msg.value.includes(n.sig)) msg.value += "\n\n" + n.sig; }); });
      w.querySelector("[data-cfg]").onclick = openCfg; const c2 = w.querySelector("[data-cfg2]"); if (c2) c2.onclick = openCfg;
      /* المرفقات: تتجهّز فوراً */
      const ab = w.querySelector("[data-att]");
      const drawAtt = () => { if (!ab) return; ab.innerHTML = att.map((a, i) => `<div class="ml-a">${fileIc(a.name)}<div><b title="${esc(a.name)}">${esc(a.name)}</b>${a.st === "wait" ? '<small><span class="ml-sp"></span> يتجهّز …</small>' : a.st === "err" ? `<small class="e">${esc(a.err)}</small>` : `<small>✓ ${a.size ? a.size : "جاهز"}</small>`}</div><button class="x" data-rm="${i}" title="إزالة">✕</button></div>`).join("");
        ab.querySelectorAll("[data-rm]").forEach(b => b.onclick = () => { att.splice(+b.dataset.rm, 1); drawAtt(); }); };
      att.forEach(a => { a.p = Promise.resolve().then(() => a.make()).then(r => { a.st = "ok"; a.r = r; if (r && r.b64) a.size = Math.max(1, Math.round(r.b64.length * .75 / 1024)) + " KB"; drawAtt(); return r; }, e => { a.st = "err"; a.err = String(e && e.message || e); drawAtt(); }); });
      drawAtt();
      /* الإرسال */
      const go = w.querySelector("[data-send]");
      const send = () => {
        TO.inp.value.trim() && TO.add(TO.inp.value); CC.inp.value.trim() && CC.add(CC.inp.value);
        if (!to.length) { TO.inp.focus(); say("أدخل بريد المرسَل إليه", "w"); return; }
        const bad = to.concat(cc).find(m => !RX.test(m)); if (bad) { say("بريد غير صحيح: " + bad, "w"); return; }
        if (!c.ready) { openCfg(); return; }
        go.disabled = true; go.innerHTML = '<span class="ml-sp" style="border-color:#ffffff55;border-top-color:#fff"></span> جارٍ الإرسال …';
        Promise.all(att.map(a => a.p)).then(() => {
          const bad2 = att.find(a => a.st === "err"); if (bad2) throw new Error("المرفق «" + bad2.name + "»: " + bad2.err);
          let body = msg.value.trim(), sig = "";
          if (c.sig && body.endsWith(c.sig.trim())) { sig = c.sig.trim(); body = body.slice(0, body.length - sig.length).trim(); }
          const parts = body.split(/\n/), text = msg.value.trim();
          const html = tpl({ co, hi: parts[0] || "", lines: parts.slice(1).filter(l => l.trim()), box: o.box, att: att.map(a => a.name).join("، "), sig });
          return call("fm.mail.send", { to, cc, subject: w.querySelector("[data-sub]").value.trim() || o.subject || "", html, text, tag: o.tag || "", attach: att.map(a => Object.assign({ name: a.name }, a.r && a.r.path ? { path: a.r.path } : { b64: a.r.b64, type: a.r.type })) });
        }).then(() => {
          LS.set(RECENT, [...new Set(to.concat(cc).concat(LS.get(RECENT, [])))].slice(0, 20)); snd("ok");
          w.innerHTML = `<div class="ml-done"><div class="ok">✓</div><h3>أُرسلت الرسالة بنجاح</h3><p>${esc(to.join(", "))}</p>${att.length ? `<p style="margin-top:6px;color:#94a3b8;direction:rtl">📎 ${esc(att.map(a => a.name).join("، "))}</p>` : ""}<div style="margin-top:18px"><button class="ml-b" data-close>إغلاق</button></div></div>`;
          w.querySelector("[data-close]").onclick = M.close; setTimeout(() => { if (document.body.contains(M.ov)) M.close(); }, 2600);
          if (o.onSent) try { o.onSent(); } catch (e) { }
        }).catch(e => { go.disabled = false; go.innerHTML = "إرسال ➤"; snd("err"); say("تعذّر الإرسال: " + (e && e.message || e), "e"); });
      };
      go.onclick = send;
      w.addEventListener("keydown", e => { if (e.key === "Enter" && e.ctrlKey) { e.preventDefault(); send(); } e.stopPropagation(); });
      setTimeout(() => (to.length ? w.querySelector("[data-sub]") : TO.inp).focus(), 60);
      if (!c.ready) setTimeout(openCfg, 250);
    });
  }

  /* ------------------------------------------------------------ مستند بتصميم الطباعة → بريد */
  function docMail(o, q) {
    q = q || {};
    const h = (o.data && o.data.header) || {}, title = o.title || ((o.tx || "مستند") + " " + (h.Number || ""));
    const party = q.party || h["Customer Name"] || h["Party Name"] || h["Supplier Name"] || "";
    const isCash = /نقد|cash/i.test(party);
    return company().then(co => (q.to ? Promise.resolve(q.to) : (party && !isCash ? mailOf(party) : Promise.resolve(""))).then(m => {
      const total = h["Net Amount"] != null ? h["Net Amount"] : h.Amount;
      const box = [["رقم المستند", h.Number || ""], ["التاريخ", h.Date || today()]].concat(total != null ? [["الإجمالي", N(total) + " " + (window.ANOUER_RD && ANOUER_RD.currencyName ? ANOUER_RD.currencyName() : "دج")]] : []).concat(h.Remain > 0 ? [["الباقي", N(h.Remain)]] : []);
      compose({ to: m ? [m] : [], subject: title + " — " + (co.name || "ANOUER"), lines: [(party && !isCash ? "السلام عليكم " + party + "،" : "السلام عليكم،"), "تجدون في المرفق «" + title + "».", "نشكركم على ثقتكم ، ولأي استفسار نحن في الخدمة."], box, tag: o.tx || "doc",
        attach: [{ name: fname(title) + ".pdf", make: () => txPdf(o, title) }] });
    }));
  }
  /* اعتراض الطباعة: viaPrint(fn) ← أول printTx بعده يتحوّل لبريد بنفس البيانات والتصميم */
  let MQ = null, MQT = 0;
  function hookRD() {
    const RD = window.ANOUER_RD; if (!RD || !RD.printTx || RD.printTx.__ml) return !!(RD && RD.printTx);
    const orig = RD.printTx;
    RD.printTx = function (o) { if (MQ && Date.now() < MQT) { const q = MQ; MQ = null; return docMail(o, q).then(() => ({ ok: true, mail: true })); } return orig.apply(this, arguments); };
    RD.printTx.__ml = 1; return true;
  }
  if (!hookRD()) { let k = 0; const t = setInterval(() => { if (hookRD() || ++k > 60) clearInterval(t); }, 300); }
  function viaPrint(fn, q) { hookRD(); MQ = q || {}; MQT = Date.now() + 6000; try { fn(); } catch (e) { MQ = null; say(String(e && e.message || e), "e"); } setTimeout(() => { if (MQ === q) MQ = null; }, 6100); }

  /* ------------------------------------------------------------ قوائم / مراجعات / تقارير */
  function table(o) {
    const rows = o.rows || []; if (!rows.length) { say("لا توجد أسطر للإرسال", "w"); return; }
    const t = o.title || "قائمة";
    company().then(co => compose({ subject: t + " — " + (co.name || "ANOUER"), lines: ["السلام عليكم،", "تجدون في المرفق «" + t + "» (" + rows.length + " سطر)."], tag: "list",
      attach: [].concat(o.pdf === false ? [] : [{ name: fname(t) + ".pdf", make: () => tablePdf(o) }]).concat(o.xls ? [{ name: fname(t) + ".csv", make: () => csvB64(o) }] : []) }));
  }
  function menu(btn, items) {
    document.querySelectorAll(".ml-menu").forEach(m => m.remove());
    const m = document.createElement("div"); m.className = "ml-menu";
    m.innerHTML = items.map((it, i) => it === "-" ? "<hr>" : `<button type="button" data-i="${i}">${it.ic || ""}<div>${esc(it.t)}${it.s ? `<small>${esc(it.s)}</small>` : ""}</div></button>`).join("");
    document.body.appendChild(m);
    const r = (btn && btn.getBoundingClientRect) ? btn.getBoundingClientRect() : { left: innerWidth / 2, bottom: innerHeight / 2, right: innerWidth / 2 };
    m.style.top = Math.min(innerHeight - m.offsetHeight - 8, r.bottom + 4) + "px"; m.style.left = Math.max(8, Math.min(innerWidth - m.offsetWidth - 8, r.right - m.offsetWidth)) + "px";
    m.addEventListener("click", e => { const b = e.target.closest("[data-i]"); if (!b) return; m.remove(); items[+b.dataset.i].f(); });
    setTimeout(() => document.addEventListener("mousedown", function f(e) { if (!m.contains(e.target)) { m.remove(); document.removeEventListener("mousedown", f, true); } }, true), 0);
  }
  /* المراجعات العامة (Review): o = {btn, title, cols, rows, sel} */
  function review(o) {
    const cols = (o.cols || []).filter(c => c.f && c.t), rows = o.rows || [], t = o.title || "مراجعة";
    const items = [];
    const isSale = /مراجعة مبيعات/.test(t) && o.sel && typeof window.__rdSrPrint === "function" && window.ANOUER_RD && ANOUER_RD.dataFromSaved;
    if (isSale) items.push({ ic: fileIc("a.pdf"), t: "الفاتورة المحددة رقم " + (o.sel.no || ""), s: "PDF بتصميم الطباعة ← لبريد العميل", f: () => ANOUER_RD.dataFromSaved(o.sel, "مبيعات").then(data => docMail({ tx: "مبيعات", data, title: "فاتورة مبيعات " + o.sel.no })) });
    if (items.length) items.push("-");
    items.push({ ic: fileIc("a.pdf"), t: "القائمة الحالية (PDF)", s: rows.length + " سطر · مع الإجماليات", f: () => table({ title: t, cols, rows }) });
    items.push({ ic: fileIc("a.csv"), t: "القائمة الحالية (PDF + Excel)", s: "ملفين في رسالة وحدة", f: () => table({ title: t, cols, rows, xls: 1 }) });
    items.push("-"); items.push({ ic: '<span class="fi oth" style="background:#475569">⚙</span>', t: "إعدادات البريد", s: "الحساب · السجل", f: () => settings() });
    menu(o.btn, items);
  }
  /* تقرير من «تصميم التقارير» (rd-manager): res جاهز */
  function report(res, name) {
    const RD = window.ANOUER_RD; if (!RD || !res) { say("لا يوجد تقرير لإرساله", "w"); return; }
    const H = res.roll ? Math.max.apply(null, res.pages.map(p => p.h)) : res.h;
    company().then(co => compose({ subject: name + " — " + (co.name || "ANOUER"), lines: ["السلام عليكم،", "تجدون في المرفق تقرير «" + name + "»."], tag: "report", attach: [{ name: fname(name) + ".pdf", make: () => pdfHtml(RD.docHTML(res, name), name, res.w, H) }] }));
  }

  window.ANOUER_MAIL = { compose, settings, viaPrint, review, table, report, docMail, menu, fileIc, tablePdf, csvB64 };
})();
