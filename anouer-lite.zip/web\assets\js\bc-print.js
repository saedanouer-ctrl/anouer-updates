/* ANOUER — «طباعة الباركود» (أيقونة قارئ الباركود في الشريط الأيسر لشاشة المبيعات)
   مطابق لـ DEXEF ONE (Dexef.Item › frmbarcodedesign) بكل تبويباته:
     • بالصنف       : الرقم ، اسم الصنف ، الباركود | عدد الملصقات + الرصيد الحالي ، السعر ، النوع (Linear / QR) ،
                      رقم التشغيلة ، تاريخ الصلاحية | ابتداءاً من السطر / العمود
     • فاتورة        : التعامل ، فترة البحث ، البحث بـ (رقم الفاتورة / الاسم / رقم التليفون / الاجمالي / المستخدم) + اختيار الفاتورة
                      ⇒ الشبكة: كود الصنف | اسم الصنف | الوحدة | الكمية | السعر  (السعر = سعر بيع الوحدة الحالي كما في DEXEF U.sale)
     • اختيار أصناف : «إختيار الأصناف» (نافذة اختيار متعدد) + كيفية ملأ خانة الكميه (برصيد الصنف الحالي / قطعة واحده / بدون كمية)
                      + وحدات الصنف (تحميل وحده واحده / تحميل جميع وحدات الصنف) + سعر الصنف المستخدم (سعر الشراء / سعر البيع / سعر 1..8)
                      ⇒ الشبكة: كود الصنف | اسم الصنف | الكمية | الوحدة | السعر + «Click here to add a new row»
     • يدوياً        : الشبكة: الكود | الكمية | السعر + سطر جديد
   أعلى النافذة: الفرع ، المخزن ، التصميم (يُدار من bc-design-pick.js بالرقم id + ✓ «جعل التصميم هو التصميم الافتراضي»).
   طباعة / عرض للطباعه / إغلاق — بتصميم «تصميم التقارير» أو القوالب العامة. */
(function () {
  "use strict";
  if (window.__BCP2) return;
  window.__BCP2 = 1;
  const E = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const g = id => document.getElementById(id);
  const $ = (s, r) => (r || document).querySelector(s);
  const RM = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
  const num = v => { const n = parseFloat(v); return isFinite(n) ? n : 0; };
  const fmt = v => (Math.round(num(v) * 100) / 100).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const AN = s => String(s || "").toLowerCase().replace(/[أإآا]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/[ً-ْـ]/g, "").replace(/\s+/g, " ").trim();
  const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} } };
  const P = () => window.products || (typeof products !== "undefined" ? products : []);
  const say = (m, k) => { try { inToast(m, k); } catch (_) { try { toast(m, k); } catch (__) {} } };

  const BRS = ["الفرع الرئيسي"], WHS = ["المخزن الرئيسي"];
  const TPL = [{ n: "A4 — 3 أعمدة × 8 صفوف (24 ملصق)", c: 3, r: 8, w: 210, h: 297 }, { n: "A4 — 4 أعمدة × 12 صفاً (48 ملصق)", c: 4, r: 12, w: 210, h: 297 }, { n: "ملصق مفرد 50×30 مم (طابعة ملصقات)", c: 1, r: 1, w: 50, h: 30 }];
  /* أيقونات التبويبات بألوان DEXEF */
  const TABS = [
    ["item", "بالصنف", '<rect x="5" y="3" width="18" height="22" rx="1.5" fill="#f37021"/><path d="M9 9h10M9 13h10M9 17h10M9 21h6" stroke="#fff" stroke-width="1.8"/>'],
    ["inv", "فاتورة", '<path d="M6 2h11l5 5v19H6z" fill="#fff" stroke="#8a95a3" stroke-width="1.4"/><path d="M17 2v5h5" fill="#e9edf2" stroke="#8a95a3" stroke-width="1.4"/><path d="M10 12h8M10 16h8M10 20h5" stroke="#8a95a3" stroke-width="1.5"/>'],
    ["sel", "اختيار أصناف", '<rect x="2" y="4" width="24" height="6" fill="#0d4a8f"/><g fill="#7b8794"><rect x="2" y="12" width="7" height="5"/><rect x="10.5" y="12" width="7" height="5"/><rect x="19" y="12" width="7" height="5"/><rect x="2" y="19" width="7" height="5"/><rect x="10.5" y="19" width="7" height="5"/><rect x="19" y="19" width="7" height="5"/></g>'],
    ["man", "يدوياً", '<rect x="8" y="5" width="16" height="21" rx="2" fill="#fff" stroke="#0d4a8f" stroke-width="1.8"/><rect x="12" y="2" width="8" height="5" rx="1" fill="#0d4a8f"/><rect x="3" y="8" width="3.5" height="14" fill="#f37021"/><path d="M12 13h8M12 17h8M12 21h5" stroke="#0d4a8f" stroke-width="1.6"/>']];
  const DEALS = [["Sale", "مبيعات"], ["SaleReturn", "مرتجع مبيعات"], ["Purchase", "مشتريات"], ["PurchaseReturn", "مرتجع مشتريات"], ["cur", "الفاتورة الحالية (على الشاشة)"]];
  const PERIODS = ["اليوم", "الأسبوع الحالى", "الشهر الحالى", "الثلاث شهور السابقة", "السنة الحالية", "الكل"], PDAYS = [0, 6, 30, 90, 365, 1e5];
  const FILTERS = [["no", "رقم الفاتورة"], ["name", "الاسم"], ["phone", "رقم التليفون"], ["total", "الاجمالي"], ["user", "المستخدم"]];
  const QFILL = [["Qty", "برصيد الصنف الحالي"], ["1Qty", "قطعة واحده"], ["0Qty", "بدون كمية"]];
  const UNITS = [["Unite", "تحميل وحده واحده"], ["AllUnite", "تحميل جميع وحدات الصنف"]];
  function priceLevels() {
    const L = [["buy", "سعر الشراء"]];
    try { if (window.ANOUER_PL) ANOUER_PL.visible().filter(x => x.u).forEach(x => L.push([x.id, x.name])); } catch (_) {}
    if (L.length === 1) L.push(["1", "سعر البيع"]);
    return L;
  }

  /* ---------- وحدات/أسعار/رصيد الصنف ---------- */
  const unitsOf = p => (p && p._u && p._u.length) ? p._u : [{ name: (p && p.unit) || "قطعة", bc: String((p && p.code) || ""), price: (p && p.price) || 0, factor: 1, def: true, base: true }];
  const defUnit = p => { const us = unitsOf(p); return us.find(u => u.def) || us.find(u => u.base) || us[0]; };
  const unitByName = (p, n) => unitsOf(p).find(u => u.name === n) || defUnit(p);
  const unitByBc = (p, bc) => unitsOf(p).find(u => String(u.bc) === String(bc) || (u.xb || []).includes(String(bc)));
  function priceOf(p, u, lv) {
    if (!p) return 0; u = u || defUnit(p); const f = +u.factor || 1;
    if (lv === "buy") return Math.round(((+p.cost || +p.lastBuy || 0) * f) * 100) / 100;
    if (!lv || lv === "1") return +u.price || (f === 1 ? +p.price || 0 : 0);
    let L = null; try { L = window.ANOUER_PL && ANOUER_PL.DEF.find(x => x.id === lv); } catch (_) {}
    if (!L) return +u.price || 0;
    const v = +u[L.u] || 0; if (v) return v;
    return (u.base || f === 1) ? (+p[L.p] || 0) : 0;
  }
  const stockOf = (p, u) => Math.max(0, Math.floor((+p.stock || 0) / ((u && +u.factor) || 1)));
  const findByCode = c => { c = String(c || "").trim(); if (!c) return null; for (const p of P()) { if (String(p.code) === c) return { p, u: defUnit(p) }; const u = unitByBc(p, c); if (u) return { p, u }; } return null; };

  /* ---------- الأنماط ---------- */
  const CSS = `
.bcp-ov{position:fixed;inset:0;background:rgba(15,23,42,.18);display:none;z-index:119}.bcp-ov.show{display:block;animation:bcpFade .2s ease}
@keyframes bcpFade{from{background:rgba(15,23,42,0)}}
.bcp-w{position:absolute;left:50%;top:5vh;width:min(1100px,calc(100vw - 24px));height:min(650px,90vh);margin-left:calc(min(1100px,calc(100vw - 24px))/-2);background:#fff;border:1px solid #9aa4b0;box-shadow:0 24px 60px -18px rgba(15,23,42,.55),0 2px 8px rgba(0,0,0,.18);display:flex;flex-direction:column;direction:rtl;font:13px "Droid Arabic Kufi","Segoe UI",Tahoma,sans-serif;color:#222;border-radius:4px;overflow:hidden}
.bcp-ov.show .bcp-w{animation:bcpIn .42s cubic-bezier(.2,1.2,.35,1)}
@keyframes bcpIn{from{opacity:0;transform:translateY(14px) scale(.97)}}
.bcp-tb{height:30px;display:flex;align-items:center;direction:ltr;padding:0 6px;flex-shrink:0;cursor:move;user-select:none;background:linear-gradient(#fbfcfd,#f3f5f8);border-bottom:1px solid #e3e7ec}
.bcp-tb .bcp-ti{margin-left:auto;display:flex;align-items:center;gap:6px;font-size:12px;font-weight:700;direction:rtl}
.bcp-tb button{width:42px;height:24px;border:0;background:none;color:#444;font-size:13px;cursor:pointer;border-radius:3px}.bcp-tb button:hover{background:#e5e8ec}.bcp-tb .x:hover{background:#e81123;color:#fff}
.bcp-top{display:flex;gap:18px;padding:10px 16px 6px;flex-shrink:0;align-items:flex-end}
.bcp-top select{flex:1;min-width:0;border:0;border-bottom:1px solid #b9c0c9;background:none;padding:4px 2px;font:inherit;direction:rtl;outline:0;cursor:pointer}.bcp-top select:focus{border-color:#1a8cff}
.bcp-bd{flex:1;display:flex;min-height:0;padding:8px 16px 0;gap:14px}
/* شريط التبويبات (NavBar «التقارير») */
.bcp-nav{width:122px;background:#e8ebef;flex-shrink:0;display:flex;flex-direction:column;overflow:hidden;transition:width .35s cubic-bezier(.3,1.2,.4,1);border-radius:2px}
.bcp-nav .hd{height:26px;display:flex;align-items:center;justify-content:flex-start;padding:0 8px;border-bottom:1px solid #d6dbe1;flex-shrink:0}
.bcp-nav .hd button{border:0;background:none;cursor:pointer;color:#333;font-size:13px;width:22px;height:22px;border-radius:4px;transition:transform .35s,background .15s}.bcp-nav .hd button:hover{background:#d6dbe1}
.bcp-nav .bcp-t{position:relative;padding:12px 4px 10px;text-align:center;cursor:pointer;font-size:12.5px;border-bottom:2px solid transparent;transition:background .15s;white-space:nowrap}
.bcp-nav .bcp-t svg{display:block;margin:0 auto 6px;transition:transform .3s cubic-bezier(.3,1.6,.5,1)}
.bcp-nav .bcp-t:hover{background:#dde2e8}.bcp-nav .bcp-t:hover svg{transform:translateY(-2px)}
.bcp-nav .bcp-t.on{background:#d3d8df;border-bottom-color:#5b9bd5}
.bcp-nav .bcp-t:focus-visible{outline:2px solid #1a8cff;outline-offset:-2px}
.bcp-nav.mini{width:46px}.bcp-nav.mini .hd button{transform:rotate(180deg)}.bcp-nav.mini .bcp-t{font-size:0;padding:9px 2px}.bcp-nav.mini .bcp-t svg{margin-bottom:0}
.bcp-main{flex:1;min-width:0;overflow-y:auto;overflow-x:hidden;padding:4px 6px 0;position:relative}
.bcp-pane{animation:bcpPane .32s cubic-bezier(.2,1,.3,1)}
@keyframes bcpPane{from{opacity:0;transform:translateX(-14px)}}
.bcp-sec{display:flex;margin-bottom:12px}.bcp-lab{width:56px;flex-shrink:0;color:#fff;display:flex;align-items:center;justify-content:center;text-align:center;font-size:13px}
.bcp-fl{flex:1;min-width:0;padding:6px 14px 6px 24px;display:flex;flex-direction:column;gap:12px}
.bcp-r{display:flex;align-items:center;gap:10px;direction:rtl;flex-wrap:wrap}.bcp-r>label{width:110px;flex-shrink:0;font-size:13px}.bcp-r .req{color:#d22;width:10px;text-align:center}
.bcp-r input[type=text],.bcp-r input[type=number],.bcp-r input[type=date],.bcp-r select{border:0;border-bottom:1px solid #b9c0c9;background:none;padding:4px 2px;font:inherit;outline:0;direction:rtl;min-width:0;transition:border-color .15s,box-shadow .15s}
.bcp-r input:focus,.bcp-r select:focus{border-color:#1a8cff;box-shadow:0 1px 0 #1a8cff}.bcp-r input.err,.bcp-cb.err{border-color:#d22!important;animation:bcpShake .3s}
@keyframes bcpShake{25%,75%{transform:translateX(-3px)}50%{transform:translateX(3px)}}
.bcp-r .w1{width:360px}.bcp-r .w2{width:130px;text-align:center}.bcp-r .lk{color:#0d5bb5;text-decoration:underline;cursor:pointer;font-size:12px}
.bcp-r .rd{display:flex;align-items:center;gap:6px;cursor:pointer}
.bcp-cb{position:relative;display:flex;align-items:center;border-bottom:1px solid #b9c0c9;width:380px}.bcp-cb:focus-within{border-color:#1a8cff}.bcp-cb input{flex:1;border:0!important;background:none;padding:4px 2px;font:inherit;outline:0;direction:rtl;min-width:0;box-shadow:none!important}
.bcp-ar{width:16px;height:16px;flex-shrink:0;background:#e6e9ed;border:1px solid #c9cfd6;display:flex;align-items:center;justify-content:center;font-size:9px;color:#444;cursor:pointer;margin-left:1px}.bcp-ar:hover{background:#d8dde3}
.bcp-dd{position:absolute;top:100%;right:0;left:0;margin-top:1px;background:#fff;border:1px solid #9aa4b0;box-shadow:0 12px 30px -10px rgba(15,23,42,.45);z-index:6;display:none;direction:rtl}.bcp-dd.show{display:block;animation:bcpDd .18s ease}
@keyframes bcpDd{from{opacity:0;transform:translateY(-4px)}}
.bcp-dh{display:flex;gap:2px;padding:3px 3px 2px}.bcp-dh div{background:#dbe8f8;border-radius:3px;padding:6px 4px;text-align:center;font-size:12px}.bcp-dh .c1{width:150px}.bcp-dh .c2{flex:1}.bcp-dh .sp{width:14px;padding:0}
.bcp-dl{height:270px;overflow-y:auto}.bcp-dr{display:flex;align-items:center;min-height:27px;border-bottom:1px solid #e6e9ed;cursor:pointer;font-size:12px}.bcp-dr:hover{background:#eef5fd}.bcp-dr.sel{background:#0a78d1;color:#fff}
.bcp-dr .c1{width:150px;flex-shrink:0;text-align:center;padding:0 6px;direction:ltr;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.bcp-dr .c2{flex:1;text-align:right;padding:0 8px;direction:rtl;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.bcp-dr.none{justify-content:center;color:#888;cursor:default}
.bcp-df{display:flex;align-items:center;justify-content:space-between;border-top:1px solid #c5cbd2;padding:2px 8px;height:22px;background:#fafbfc}.bcp-df .xx{color:#d22;cursor:pointer;font-size:12px;font-weight:700}
/* رأس التبويبات الثلاثة */
.bcp-opts{display:flex;gap:22px;align-items:flex-end;flex-wrap:wrap;margin:6px 4px 14px}
.bcp-f{display:flex;flex-direction:column;gap:4px;min-width:150px}
.bcp-f>label{font-size:12.5px;font-weight:600;color:#2f3a45}
.bcp-f select,.bcp-f input{border:0;border-bottom:1px solid #b9c0c9;background:none;padding:4px 2px;font:inherit;outline:0;direction:rtl;min-width:0;transition:border-color .15s}
.bcp-f select:focus,.bcp-f input:focus{border-color:#1a8cff}
.bcp-pick{display:inline-flex;align-items:center;gap:8px;color:#0d5bb5;cursor:pointer;font-weight:600;font-size:13px;border:0;background:none;padding:4px 2px;font-family:inherit;margin:4px 4px 2px}
.bcp-pick:hover span{text-decoration:underline}
.bcp-pick svg{transition:transform .3s cubic-bezier(.3,1.6,.5,1)}.bcp-pick:hover svg{transform:translateY(-2px) rotate(-6deg)}
.bcp-pick:focus-visible{outline:2px solid #1a8cff;outline-offset:2px;border-radius:4px}
/* اختيار الفاتورة (TxtBill) */
.bcp-bill{position:relative;display:flex;align-items:center;gap:6px;border-bottom:1px solid #b9c0c9;min-width:250px}.bcp-bill:focus-within{border-color:#1a8cff}
.bcp-bill input{flex:1;border:0!important;padding:4px 2px;font:inherit;outline:0;background:none;min-width:0}
.bcp-bill .ar{width:18px;height:18px;flex:0 0 auto;display:grid;place-items:center;border:1px solid #c9cfd6;background:#e6e9ed;border-radius:3px;color:#444;cursor:pointer;font-size:9px}
.bcp-bdd{position:absolute;top:calc(100% + 3px);right:0;width:min(620px,70vw);background:#fff;border:1px solid #9aa4b0;box-shadow:0 18px 40px -12px rgba(15,23,42,.45);z-index:12;display:none;border-radius:3px;overflow:hidden}
.bcp-bdd.show{display:block;animation:bcpDd .2s ease}
.bcp-bh,.bcp-brw{display:grid;grid-template-columns:20px 90px 120px minmax(0,1fr) 110px 70px;align-items:center}
.bcp-bh{gap:2px;padding:3px}.bcp-bh div{background:#dbe8f8;border-radius:3px;height:28px;display:flex;align-items:center;justify-content:center;font-size:12px}
.bcp-bl{max-height:290px;overflow:auto}
.bcp-brw{height:30px;border-bottom:1px solid #e6e9ed;cursor:pointer;font-size:12.5px}.bcp-brw:hover{background:#eef5fd}.bcp-brw.sel{background:#0a78d1;color:#fff}
.bcp-brw>span{padding:0 6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center}.bcp-brw .nm{text-align:right}.bcp-brw .no{font-family:Consolas,monospace;font-weight:600;direction:ltr}
.bcp-brw mark{background:#ffe58f;color:inherit;border-radius:2px}.bcp-brw.sel mark{background:rgba(255,255,255,.3)}
.bcp-bf{display:flex;justify-content:space-between;align-items:center;padding:3px 8px;border-top:1px solid #c5cbd2;background:#fafbfc;font-size:11px;color:#8a95a3;height:24px}
.bcp-sk{height:30px;margin:4px 6px;border-radius:5px;background:linear-gradient(90deg,#eef1f5 25%,#f8fafc 50%,#eef1f5 75%);background-size:200% 100%;animation:bcpSk 1.1s linear infinite}
@keyframes bcpSk{to{background-position:-200% 0}}
/* الشبكات */
.bcp-grid{border:0;margin:0 4px}
.bcp-gh,.bcp-gr{display:grid;align-items:center;gap:2px}
.bcp-gh{padding:2px 0 4px}.bcp-gh div{background:#dbe8f8;border-radius:4px;height:32px;display:flex;align-items:center;justify-content:center;font-size:12.5px;color:#222;cursor:pointer;user-select:none;gap:5px;transition:background .15s}
.bcp-gh div:hover{background:#cfe0f5}.bcp-gh div.ns{cursor:default}.bcp-gh div.ns:hover{background:#dbe8f8}
.bcp-gh i{font-style:normal;font-size:10px;color:#5b6573}
.bcp-gb{max-height:calc(90vh - 330px);min-height:60px;overflow:auto}
.bcp-gr{min-height:31px;border-bottom:1px solid #eceff3;font-size:12.5px;transition:background .12s}
.bcp-gr:hover{background:#f5f9ff}.bcp-gr.fo{background:#e9f2fd}
.bcp-gr>span{padding:0 6px;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.bcp-gr>span.t{text-align:right}.bcp-gr>span.cd{direction:ltr;font-family:Consolas,"Segoe UI",monospace}
.bcp-gr input,.bcp-gr select{width:100%;border:1px solid transparent;background:transparent;padding:4px 6px;font:inherit;text-align:center;outline:0;border-radius:4px;transition:border-color .15s,background .15s}
.bcp-gr input:hover,.bcp-gr select:hover{border-color:#d5dce4;background:#fff}
.bcp-gr input:focus,.bcp-gr select:focus{border-color:#1a8cff;background:#fff;box-shadow:0 0 0 3px rgba(26,140,255,.12)}
.bcp-gr input.cd{direction:ltr;font-family:Consolas,"Segoe UI",monospace}
.bcp-gr .dl{width:24px;height:24px;margin:0 auto;border:0;border-radius:6px;background:none;color:#c7ccd3;cursor:pointer;display:grid;place-items:center;transition:color .15s,background .15s}
.bcp-gr:hover .dl{color:#d22}.bcp-gr .dl:hover{background:#fdecec;color:#c00}
.bcp-gr.add{animation:bcpRow .35s cubic-bezier(.2,1,.3,1)}
@keyframes bcpRow{from{opacity:0;transform:translateY(-6px);background:#fff8d6}}
.bcp-gr.out{animation:bcpOut .22s ease forwards}
@keyframes bcpOut{to{opacity:0;transform:translateX(30px)}}
.bcp-new{display:grid;align-items:center;min-height:30px;border-bottom:1px solid #eceff3;color:#8a95a3;font-size:11.5px;cursor:text}
.bcp-new>span:first-child{text-align:center;color:#6b7684}
.bcp-new>.hint{text-align:center}
.bcp-new:hover{background:#fafcff}
.bcp-new .srch{position:relative}
.bcp-new .srch input{width:100%;border:1px solid #1a8cff;border-radius:4px;padding:4px 8px;font:inherit;outline:0;box-shadow:0 0 0 3px rgba(26,140,255,.12)}
.bcp-ac{position:absolute;top:calc(100% + 2px);right:0;left:0;background:#fff;border:1px solid #9aa4b0;box-shadow:0 14px 30px -10px rgba(15,23,42,.45);z-index:14;max-height:240px;overflow:auto;border-radius:3px}
.bcp-ac div{display:grid;grid-template-columns:130px minmax(0,1fr) 70px;gap:6px;padding:6px 8px;cursor:pointer;font-size:12.5px;color:#222;border-bottom:1px solid #f0f2f5}
.bcp-ac div span:first-child{direction:ltr;font-family:Consolas,monospace;text-align:left}
.bcp-ac div span:last-child{color:#6b7684;text-align:left}
.bcp-ac div.sel{background:#0a78d1;color:#fff}.bcp-ac div.sel span{color:#fff}
.bcp-ac .no{padding:10px;color:#8a95a3;display:block;cursor:default}
.bcp-emp{padding:26px 10px;text-align:center;color:#8a95a3;font-size:12.5px;display:flex;flex-direction:column;align-items:center;gap:8px}
.bcp-emp svg{opacity:.5}
.bcp-sum{display:flex;gap:10px;align-items:center;margin:10px 6px 4px;font-size:12px;color:#56616d;flex-wrap:wrap}
.bcp-sum .sp{flex:1}
.bcp-chip{display:inline-flex;align-items:center;gap:5px;height:28px;padding:0 12px;border-radius:999px;border:1px solid #d5dbe3;background:#f4f6f9;color:#56616d;font:600 11.5px "Segoe UI",Tahoma,sans-serif;cursor:pointer;transition:background .15s,border-color .15s,color .15s,box-shadow .2s,transform .15s}
.bcp-chip:hover{transform:translateY(-1px)}
.bcp-chip.on{background:linear-gradient(135deg,#2f8ae3,#7c3aed);border-color:transparent;color:#fff;box-shadow:0 6px 14px -6px rgba(79,70,229,.7)}
.bcp-chip.bcp-nfc.on{background:linear-gradient(135deg,#ef4444,#b91c1c);box-shadow:0 6px 14px -6px rgba(185,28,28,.7)}
.bcp-chip.bcp-nfc i{font-style:normal;font-size:12px}.bcp-chip.bcp-nfc b{display:inline-grid;place-items:center;min-width:18px;height:18px;padding:0 4px;border-radius:9px;background:rgba(255,255,255,.28);font:800 10.5px "Segoe UI",Arial}
.bcp-chip.bcp-nfc:not(.on) b{background:#e6eaf0;color:#b91c1c}
.bcp-nf{display:inline-flex;align-items:center;height:17px;margin-inline-end:7px;padding:0 7px;border-radius:9px;background:#fde8e8;color:#c62828;border:1px solid #f5c2c2;font:800 10.5px "Segoe UI",Tahoma,sans-serif;vertical-align:middle;letter-spacing:.2px}
.bcp-gr.nf{background:repeating-linear-gradient(135deg,#fff 0 8px,#fff6f6 8px 16px)}
.bcp-gr.nf span.t,.bcp-gr.nf span.cd{color:#9aa4ae}
.bcp-gr.nf input[data-f="qty"]{color:#c62828;font-weight:700}
.bcp-gr.nf.in .bcp-nf{background:#fff4e5;color:#b45309;border-color:#f8d7a8}
.bcp-chip[data-smart].on{background:linear-gradient(135deg,#e8409a,#f59e0b)}
.bcp-chip.bcp-au b{font:800 10.5px "Segoe UI",Arial;letter-spacing:.6px;padding:1px 6px;border-radius:6px;background:linear-gradient(135deg,#ff4fa3,#7c5cff 60%,#22d3ee);background-size:200% 200%;color:#fff;animation:bcpAu 3s ease infinite}
.bcp-chip.bcp-au.on{background:linear-gradient(135deg,#ff4fa3,#7c5cff 60%,#22d3ee);background-size:200% 200%;animation:bcpAu 3s ease infinite;box-shadow:0 6px 16px -6px rgba(124,92,255,.85)}.bcp-chip.bcp-au.on b{background:rgba(255,255,255,.25);animation:none}
@keyframes bcpAu{50%{background-position:100% 100%}}
.bcp-sum b{font:700 13px Arial;color:#1d2731}
.bcp-sum span{background:#f4f6f9;border:1px solid #e6eaef;border-radius:8px;padding:3px 10px}
.bcp-ft{display:flex;gap:14px;padding:12px 16px 14px;flex-shrink:0;direction:rtl;align-items:center}
.bcp-ft button{flex:0 0 135px;height:38px;border:1px solid #1580d8;border-radius:4px;background:linear-gradient(#45b5ff,#0a82e3);color:#fff;font:inherit;font-size:13px;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.35),0 4px 10px -6px rgba(10,130,227,.9);transition:filter .15s,transform .08s}
.bcp-ft button:hover{filter:brightness(1.08)}.bcp-ft button:active{transform:translateY(1px)}
.bcp-ft .cnt{margin-right:auto;font-size:12px;color:#56616d;background:#f4f6f9;border:1px solid #e6eaef;border-radius:9px;padding:5px 12px}
.bcp-ft .cnt b{font:700 14px Arial;color:#1d2731;margin-inline-start:4px}
.bcp-pv{position:fixed;inset:0;z-index:121;background:rgba(0,0,0,.55);display:none;flex-direction:column;direction:rtl}.bcp-pv.show{display:flex}
.bcp-pvb{display:flex;gap:10px;padding:8px 14px;background:#2b2f36}.bcp-pvb button{height:30px;padding:0 22px;border:1px solid #1580d8;border-radius:3px;background:linear-gradient(#37adff,#0a82e3);color:#fff;font:inherit;cursor:pointer}.bcp-pv iframe{flex:1;border:0;background:#777}
.bcp-tst{position:absolute;bottom:70px;left:50%;transform:translateX(-50%);z-index:30;background:#1f2933;color:#fff;padding:8px 16px;border-radius:9px;font-size:12.5px;box-shadow:0 10px 30px -8px rgba(0,0,0,.4);white-space:nowrap;animation:bcpT .3s cubic-bezier(.2,1.3,.4,1)}
.bcp-tst.w{background:#b45309}.bcp-tst.e{background:#b42318}.bcp-tst.s{background:#15803d}
@keyframes bcpT{from{opacity:0;transform:translate(-50%,10px)}}
/* نافذة «إختيار الأصناف» */
.bsi{position:fixed;inset:0;margin:auto;width:max-content;height:max-content;padding:0;border:0;background:transparent;max-width:none;max-height:none;direction:rtl;font:13px "Droid Arabic Kufi","Segoe UI",Tahoma,sans-serif;color:#222;outline:0}
.bsi::backdrop{background:rgba(15,23,42,.35);backdrop-filter:blur(3px)}
.bsi-c{width:min(820px,94vw);height:min(600px,86vh);background:#fff;border-radius:14px;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 30px 80px -16px rgba(15,23,42,.55)}
.bsi[open] .bsi-c{animation:bcpIn .42s cubic-bezier(.2,1.2,.35,1)}
.bsi-h{display:flex;align-items:center;gap:10px;padding:14px 18px;border-bottom:1px solid #eef1f4;background:linear-gradient(#fbfcfd,#f4f6f9)}
.bsi-h h3{margin:0;font-size:15px;flex:1}
.bsi-h .x{border:0;background:none;width:30px;height:30px;border-radius:8px;cursor:pointer;color:#7b8794}.bsi-h .x:hover{background:#fdecec;color:#c00}
.bsi-s{display:flex;gap:10px;padding:12px 18px;align-items:center;flex-wrap:wrap}
.bsi-s .q{flex:1;min-width:220px;position:relative}
.bsi-s .q input{width:100%;height:38px;border:1px solid #cfd6de;border-radius:10px;padding:0 36px 0 12px;font:inherit;outline:0;transition:border-color .15s,box-shadow .15s}
.bsi-s .q input:focus{border-color:#1a8cff;box-shadow:0 0 0 3px rgba(26,140,255,.15)}
.bsi-s .q svg{position:absolute;right:11px;top:11px;color:#8a95a3}
.bsi-s select{height:38px;border:1px solid #cfd6de;border-radius:10px;padding:0 10px;font:inherit;background:#fff;outline:0}
.bsi-chk{display:flex;align-items:center;gap:6px;font-size:12.5px;color:#3d4753;cursor:pointer;user-select:none}
.bsi-gh,.bsi-r{display:grid;grid-template-columns:40px 150px minmax(0,1fr) 90px 80px 90px;align-items:center}
.bsi-gh{margin:0 18px;gap:2px}.bsi-gh div{background:#dbe8f8;border-radius:4px;height:30px;display:flex;align-items:center;justify-content:center;font-size:12px}
.bsi-l{flex:1;overflow:auto;margin:2px 18px 0}
.bsi-r{height:34px;border-bottom:1px solid #eef1f4;cursor:pointer;font-size:12.5px;transition:background .12s}
.bsi-r:hover{background:#f5f9ff}.bsi-r.on{background:#e7f1fd}.bsi-r.fo{box-shadow:inset -3px 0 0 #1a8cff}
.bsi-r>span{padding:0 6px;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bsi-r .nm{text-align:right}.bsi-r .cd{direction:ltr;font-family:Consolas,monospace}
.bsi-r input{width:16px;height:16px;accent-color:#1a8cff;cursor:pointer}
.bsi-r mark{background:#ffe58f;color:inherit;border-radius:2px}
.bsi-f{display:flex;align-items:center;gap:10px;padding:12px 18px;border-top:1px solid #eef1f4}
.bsi-f .sp{flex:1}.bsi-f .n{font-size:12.5px;color:#56616d}.bsi-f .n b{font:700 14px Arial;color:#1d2731}
.bsi-b{height:38px;padding:0 18px;border-radius:9px;border:1px solid #1580d8;background:linear-gradient(#45b5ff,#0a82e3);color:#fff;font:600 13px "Segoe UI",Tahoma;cursor:pointer}
.bsi-b:disabled{opacity:.5;cursor:not-allowed}.bsi-b.gh{background:#fff;color:#2f3a45;border-color:#c9d1da}
@media (prefers-reduced-motion:reduce){.bcp-ov *,.bsi *{animation:none!important;transition:none!important}}`;

  /* ---------- الحالة ---------- */
  let mode = LS.get("bcp.mode", "item"), cur = null, tpl = 0, rdTpl = null, autoTpl = false, offTpl = null;   /* offTpl: تيكت العروض A5 (bc-offer.js) */
  const INV = { skip: LS.get("bcp.skipOut", true) !== false, one: LS.get("bcp.one", true) !== false, deal: LS.get("bcp.deal", "Sale"), per: LS.get("bcp.per", 3), flt: LS.get("bcp.flt", "no"), list: null, listKey: "", bill: null, rows: [], sort: null, loading: false };
  const SEL = { rows: [], fill: LS.get("bcp.fill", "Qty"), units: LS.get("bcp.units", "Unite"), price: LS.get("bcp.price", "1"), sort: null };
  const MAN = { rows: [] };
  let uid = 0;

  /* ---------- رسم الباركود (القوالب العامة) ---------- */
  function linSvg(t) { const w = code128Bars(t); if (!w) return ""; const q = 10; let x = q, r = ""; w.forEach((n, i) => { if (i % 2 == 0) r += `M${x} 0h${n}v1h-${n}z`; x += n; }); return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${x + q} 1" preserveAspectRatio="none" shape-rendering="crispEdges"><path d="${r}" fill="#000"/></svg>`; }
  function qrSvg(t) { const m = qrMatrix(t); if (!m) return ""; const n = m.length, q = 2; let r = ""; m.forEach((row, y) => row.forEach((b, x) => { if (b) r += `M${x + q} ${y + q}h1v1h-1z`; })); return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n + 2 * q} ${n + 2 * q}" shape-rendering="crispEdges"><path d="${r}" fill="#000"/></svg>`; }

  /* ---------- رسالة داخل النافذة ---------- */
  function inToast(m, k) {
    const w = $("#bcpOv .bcp-w"); if (!w || !$("#bcpOv").classList.contains("show")) { try { toast(m, k); } catch (_) {} return; }
    const t = document.createElement("div"); t.className = "bcp-tst " + (k || ""); t.textContent = m; w.appendChild(t); setTimeout(() => t.remove(), 2800);
  }

  /* ---------- بناء النافذة ---------- */
  function build() {
    if (g("bcpOv")) return;
    const st = document.createElement("style"); st.id = "bcpStyle"; st.textContent = CSS; document.head.appendChild(st);
    const o = document.createElement("div"); o.id = "bcpOv"; o.className = "bcp-ov";
    o.innerHTML = `<div class="bcp-w" role="dialog" aria-label="طباعة الباركود">
 <div class="bcp-tb" id="bcpTb"><span class="bcp-ti"><svg width="15" height="15" viewBox="0 0 32 30"><rect width="32" height="30" rx="3" fill="#1a6fd0"/><path d="M7 8v14M10 8v14M13 8v14M17 8v14M20 8v14M24 8v14" stroke="#fff" stroke-width="1.8"/><path d="M5 24L27 6" stroke="#9fd0ff" stroke-width="1.6"/></svg>طباعة الباركود</span><button class="mn" title="تصغير">&#8211;</button><button class="mx" title="تكبير">&#9633;</button><button class="x" title="إغلاق (Esc)">&#10005;</button></div>
 <div class="bcp-top"><select id="bcpBr" aria-label="الفرع">${BRS.map(x => `<option>${E(x)}</option>`).join("")}</select><select id="bcpWh" aria-label="المخزن">${WHS.map(x => `<option>${E(x)}</option>`).join("")}</select><select id="bcpTpl" title="قالب الملصقات" aria-label="التصميم">${TPL.map((t, i) => `<option value="${i}">${E(t.n)}</option>`).join("")}</select></div>
 <div class="bcp-bd"><nav class="bcp-nav" id="bcpNav" aria-label="التقارير"><div class="hd"><button type="button" id="bcpNavT" title="طي / توسيع">&#8249;</button></div>${TABS.map(t => `<div class="bcp-t t" data-m="${t[0]}" role="tab" tabindex="0" title="${t[1]}"><svg width="28" height="28" viewBox="0 0 28 28" fill="none">${t[2]}</svg>${t[1]}</div>`).join("")}</nav>
 <div class="bcp-main" id="bcpMain"></div></div>
 <div class="bcp-ft"><button id="bcpPrint">طباعة</button><button id="bcpView">عرض للطباعه</button><button id="bcpClose">إغلاق</button><span class="cnt" id="bcpCntAll">عدد الملصقات<b>0</b></span></div></div>`;
    document.body.appendChild(o);
    const w = o.querySelector(".bcp-w"), tb = g("bcpTb");
    tb.addEventListener("pointerdown", e => {
      if (e.button !== 0 || e.target.closest("button")) return; const r = w.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top; tb.setPointerCapture(e.pointerId);
      const mv = ev => { w.style.left = Math.min(Math.max(ev.clientX - dx, -r.width + 80), innerWidth - 80) + "px"; w.style.top = Math.min(Math.max(ev.clientY - dy, 0), innerHeight - 30) + "px"; w.style.marginLeft = "0"; };
      const up = () => { tb.removeEventListener("pointermove", mv); tb.removeEventListener("pointerup", up); }; tb.addEventListener("pointermove", mv); tb.addEventListener("pointerup", up); e.preventDefault();
    });
    o.querySelector(".x").onclick = o.querySelector(".mn").onclick = close; g("bcpClose").onclick = close;
    o.querySelector(".mx").onclick = () => { const m = w.dataset.max === "1"; w.dataset.max = m ? "0" : "1"; Object.assign(w.style, m ? { left: "50%", top: "5vh", width: "", height: "", marginLeft: "calc(min(1100px,calc(100vw - 24px))/-2)" } : { left: "0", top: "0", width: "100vw", height: "100vh", marginLeft: "0" }); };
    g("bcpNav").addEventListener("click", e => { const t = e.target.closest(".bcp-t"); if (t) setMode(t.dataset.m); });
    g("bcpNav").addEventListener("keydown", e => { const t = e.target.closest(".bcp-t"); if (t && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); setMode(t.dataset.m); } });
    g("bcpNavT").onclick = () => { const n = g("bcpNav"); n.classList.toggle("mini"); LS.set("bcp.mini", n.classList.contains("mini")); };
    if (LS.get("bcp.mini", false)) g("bcpNav").classList.add("mini");
    g("bcpTpl").onchange = e => { const v = e.target.value; offTpl = window.__BCO && __BCO.isKey(v) ? v : null; autoTpl = v === "auto"; if (autoTpl || offTpl) rdTpl = null; if (offTpl) { LS.set("bcp.noauto", v); } else if (autoTpl) { } else { LS.set("bcp.noauto", v); if (String(v).indexOf("rd:") === 0) rdTpl = v.slice(3); else { rdTpl = null; tpl = +v; } } if (mode === "inv") drawInv(); };
    g("bcpPrint").onclick = () => run(false); g("bcpView").onclick = () => run(true);
    document.addEventListener("mousedown", e => { if (!e.target.closest("#bcpCb")) ddHide(); if (!e.target.closest(".bcp-bill")) billHide(); if (!e.target.closest(".bcp-new")) acHide(); });
    document.addEventListener("keydown", e => {
      if (e.key !== "Escape") return; if (document.querySelector(".rdp-ov.show,.rdm-dov,.rdx-ov.show,dialog[open],.bcs-ov.show,.rcs-ov.show,.rcs-pvg.show")) return;
      const dd = g("bcpDd"); if (dd && dd.classList.contains("show")) { e.preventDefault(); e.stopPropagation(); ddHide(); return; }
      const bd = g("bcpBdd"); if (bd && bd.classList.contains("show")) { e.preventDefault(); e.stopPropagation(); billHide(); return; }
      if (g("bcpAc")) { e.preventDefault(); e.stopPropagation(); acHide(); return; }
      const pv = g("bcpPv"); if (pv && pv.classList.contains("show")) { e.preventDefault(); e.stopPropagation(); pv.classList.remove("show"); return; }
      if (o.classList.contains("show")) { e.preventDefault(); e.stopPropagation(); close(); }
    }, true);
    const pv = document.createElement("div"); pv.id = "bcpPv"; pv.className = "bcp-pv"; pv.innerHTML = '<div class="bcp-pvb"><button id="bcpPvP">طباعة</button><button id="bcpPvX">إغلاق</button></div><iframe id="bcpFr"></iframe>'; document.body.appendChild(pv);
    g("bcpPvX").onclick = () => pv.classList.remove("show"); g("bcpPvP").onclick = () => {
      /* معاينة AUTO: نفس الطباعة المضبوطة (نافذة الطباعة الصغيرة بمقاس التيكت) — لا نافذة المتصفح الكبيرة */
      if (window.__BCO && __BCO.hasLast) { pv.classList.remove("show"); __BCO.printLast().then(n => { if (n) say("تم إرسال " + n + " تيكت عروض A5 للطباعة", "s"); }).catch(e => say("تعذّرت الطباعة: " + ((e && e.message) || e), "e")); return; }
      if (window.__BCA && __BCA.hasLast) { pv.classList.remove("show"); __BCA.printLast().then(n => { if (n) say("تم إرسال " + n + " تيكت AUTO للطباعة", "s"); }).catch(e => say("تعذّرت الطباعة: " + ((e && e.message) || e), "e")); return; }
      try { g("bcpFr").contentWindow.focus(); g("bcpFr").contentWindow.print(); } catch (_) {}
    };
    // الفروع والمخازن الحقيقية (إن وُجدت)
    try { if (window.__FH && __FH.DB) { __FH.DB.list("wh").then(l => { const n = (l || []).map(x => x.name).filter(Boolean); if (n.length) g("bcpWh").innerHTML = n.map(x => `<option>${E(x)}</option>`).join(""); }).catch(() => {}); } } catch (_) {}
    try { const b = [...document.querySelectorAll(".status span,.sb-item")].map(x => (x.textContent || "").trim()).find(t => /^الفرع\s/.test(t) && t.length < 40); if (b) g("bcpBr").innerHTML = `<option>${E(b)}</option>`; } catch (_) {}
  }

  /* ---------- تبديل التبويب ---------- */
  function setMode(m) {
    mode = m; LS.set("bcp.mode", m);
    document.querySelectorAll("#bcpNav .bcp-t").forEach(t => { const on = t.dataset.m === m; t.classList.toggle("on", on); t.setAttribute("aria-selected", on); });
    const M = g("bcpMain"); M.innerHTML = '<div class="bcp-pane" id="bcpA"></div>';
    if (m === "item") paneItem(); else if (m === "inv") paneInv(); else if (m === "sel") paneSel(); else paneMan();
    count();
  }

  /* ======================= بالصنف ======================= */
  let ddSel = 0, ddList = [];
  function paneItem() {
    const A = g("bcpA");
    A.innerHTML = `<div class="bcp-sec"><div class="bcp-lab" style="background:#ff7f0e">الصنف</div><div class="bcp-fl">
  <div class="bcp-r"><label>الرقم</label><input type="text" class="w1" id="bcpNo" autocomplete="off"><span class="req">*</span></div>
  <div class="bcp-r"><label>اسم الصنف</label><div class="bcp-cb" id="bcpCb"><input type="text" id="bcpNm" autocomplete="off"><span class="bcp-ar" id="bcpAr" title="قائمة الأصناف">&#9660;</span>
   <div class="bcp-dd" id="bcpDd"><div class="bcp-dh"><div class="c1">كود الصنف</div><div class="c2">اسم الصنف</div><div class="sp"></div></div><div class="bcp-dl" id="bcpDl"></div><div class="bcp-df"><span class="xx" id="bcpDx" title="إغلاق">&#10005;</span><span style="font-size:11px;color:#8a95a3" id="bcpDn"></span></div></div></div><span class="req">*</span></div>
  <div class="bcp-r"><label>الباركود</label><select class="w1" id="bcpBc"></select><span class="req">*</span></div></div></div>
 <div class="bcp-sec"><div class="bcp-lab" style="background:#1e90ff">الخصائص</div><div class="bcp-fl">
  <div class="bcp-r"><label>عدد الملصقات</label><input type="number" class="w2" id="bcpCnt" min="1" value="1"><span class="req">*</span><span>الرصيد الحالي</span><span class="lk" id="bcpStk" title="استخدم الرصيد كعدد للملصقات">0</span></div>
  <div class="bcp-r"><label>السعر</label><input type="number" class="w2" id="bcpPr" min="0" step="any" value="0"><span class="req"></span><select id="bcpPl" style="width:150px" title="مستوى السعر">${priceLevels().map(x => `<option value="${x[0]}"${x[0] === "1" ? " selected" : ""}>${E(x[1])}</option>`).join("")}</select></div>
  <div class="bcp-r"><label>النوع</label><label class="rd"><input type="radio" name="bcpTy" value="lin" checked>Linear Barcode</label><label class="rd"><input type="radio" name="bcpTy" value="qr">QR Barcode</label></div>
  <div class="bcp-r"><label>رقم التشغيلة</label><input type="text" class="w2" id="bcpOp" autocomplete="off" style="width:180px;text-align:right"><label style="width:auto;margin-inline-start:18px">تاريخ الصلاحية</label><input type="date" id="bcpEx" style="width:150px"></div></div></div>
 <div class="bcp-sec"><div class="bcp-lab" style="background:#1e90ff">الباركود</div><div class="bcp-fl">
  <div class="bcp-r"><label>ابتداءاً من السطر</label><input type="number" class="w2" id="bcpSr" min="1" value="1"></div>
  <div class="bcp-r"><label>ابتداءاً من العمود</label><input type="number" class="w2" id="bcpSc" min="1" value="1"></div></div></div>`;
    const nm = g("bcpNm");
    nm.addEventListener("input", () => { const p = P().find(x => x.name === nm.value.trim()); if (p) pick(p); else { if (cur) { cur = null; g("bcpNo").value = ""; g("bcpBc").innerHTML = ""; g("bcpStk").textContent = "0"; } ddShow(nm.value.trim()); } });
    nm.addEventListener("keydown", e => { const d = g("bcpDd"), open = d.classList.contains("show");
      if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); if (!open) ddShow(""); else ddMove(e.key === "ArrowDown" ? 1 : -1); }
      else if (e.key === "Enter" && open) { e.preventDefault(); ddPick(); } });
    g("bcpAr").addEventListener("mousedown", e => { e.preventDefault(); const d = g("bcpDd"); if (d.classList.contains("show")) ddHide(); else { nm.focus(); ddShow(""); } });
    g("bcpDx").onclick = ddHide;
    g("bcpDl").addEventListener("mousedown", e => { const r = e.target.closest(".bcp-dr[data-id]"); if (!r) return; e.preventDefault(); const p = P().find(x => String(x.id) === r.dataset.id); if (p) { pick(p); ddHide(); } });
    g("bcpNo").addEventListener("change", () => { const v = g("bcpNo").value.trim(); const p = P().find(x => String(x.id) === v || String(x.code) === v) || (findByCode(v) || {}).p; if (p) pick(p); else if (v) { g("bcpNo").classList.add("err"); say("لا يوجد صنف بهذا الرقم", "w"); } });
    g("bcpNo").addEventListener("input", () => g("bcpNo").classList.remove("err"));
    g("bcpBc").onchange = () => { if (!cur) return; const u = unitByBc(cur, g("bcpBc").value) || defUnit(cur); g("bcpPr").value = priceOf(cur, u, g("bcpPl").value); g("bcpStk").textContent = stockOf(cur, u); };
    g("bcpPl").onchange = () => { if (!cur) return; const u = unitByBc(cur, g("bcpBc").value) || defUnit(cur); g("bcpPr").value = priceOf(cur, u, g("bcpPl").value); };
    g("bcpStk").onclick = () => { const v = +g("bcpStk").textContent; if (v > 0) { g("bcpCnt").value = v; count(); } };
    A.addEventListener("input", count);
    if (cur) pick(cur, true); else g("bcpStk").textContent = "0";
    setTimeout(() => g("bcpNm") && g("bcpNm").focus(), 30);
  }
  function ddShow(q) {
    const d = g("bcpDd"); if (!d) return; const k = AN(q);
    ddList = P().filter(p => !k || AN(p.name).includes(k) || String(p.code).toLowerCase().includes(k) || String(p.barcode || "").includes(k)); ddSel = 0;
    g("bcpDl").innerHTML = ddList.length ? ddList.slice(0, 400).map((p, i) => `<div class="bcp-dr${i ? "" : " sel"}" data-id="${p.id}"><div class="c1">${E(p.code)}</div><div class="c2" title="${E(p.name)}">${E(p.name)}</div></div>`).join("") : '<div class="bcp-dr none">لا توجد نتائج</div>';
    g("bcpDn").textContent = ddList.length + " صنف"; d.classList.add("show");
  }
  function ddHide() { const d = g("bcpDd"); if (d) d.classList.remove("show"); }
  function ddMove(n) { if (!ddList.length) return; const L = g("bcpDl").children; L[ddSel].classList.remove("sel"); ddSel = (ddSel + n + Math.min(ddList.length, 400)) % Math.min(ddList.length, 400); L[ddSel].classList.add("sel"); L[ddSel].scrollIntoView({ block: "nearest" }); }
  function ddPick() { const p = ddList[ddSel]; if (p) { pick(p); ddHide(); } }
  function pick(p, keep) {
    cur = p; g("bcpNo").value = p.id; g("bcpNm").value = p.name; g("bcpCb").classList.remove("err");
    const us = unitsOf(p), du = defUnit(p);
    g("bcpBc").innerHTML = us.map(u => `<option value="${E(u.bc || p.code)}"${u === du ? " selected" : ""}>${E(u.bc || p.code)} — ${E(u.name)}</option>`).join("");
    if (!keep) g("bcpPr").value = priceOf(p, du, g("bcpPl").value);
    g("bcpStk").textContent = stockOf(p, du); count();
  }

  /* ======================= الشبكة العامة ======================= */
  const ICO_X = '<svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 2l8 8M10 2L2 10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
  const ICO_EMPTY = '<svg width="46" height="46" viewBox="0 0 46 46"><rect x="6" y="8" width="34" height="30" rx="4" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M6 16h34M16 8v30" stroke="currentColor" stroke-width="2.2"/></svg>';
  /* cols: [{k, t, w, ed:"num"|"txt"|"unit", cls}] — S: {rows, sort} ; o: {del, confirmDel, newRow:{hint, onClick}, empty} */
  function grid(host, cols, S, o) {
    const tpl = cols.map(c => c.w || "minmax(0,1fr)").join(" ") + (o.del ? " 34px" : "");
    const lead = '22px ';
    const T = lead + tpl;
    const rows = S.rows.slice();
    if (S.sort) { const { k, d } = S.sort; rows.sort((a, b) => { const x = a[k], y = b[k]; return (typeof x === "number" && typeof y === "number" ? x - y : String(x || "").localeCompare(String(y || ""), "ar", { numeric: true })) * d; }); }
    host.innerHTML = `<div class="bcp-grid"><div class="bcp-gh" style="grid-template-columns:${T}"><div class="ns"></div>${cols.map(c => `<div data-k="${c.k}"${c.ns ? ' class="ns"' : ""}>${E(c.t)}${S.sort && S.sort.k === c.k ? `<i>${S.sort.d > 0 ? "▲" : "▼"}</i>` : c.ns ? "" : '<i style="opacity:.35">⇅</i>'}</div>`).join("")}${o.del ? '<div class="ns"></div>' : ""}</div>
<div class="bcp-gb">${o.newRow ? `<div class="bcp-new" style="grid-template-columns:22px 1fr" data-new="1"><span>&#10033;</span><span class="hint">Click here to add a new row</span></div>` : ""}
${rows.length ? rows.map(r => `<div class="bcp-gr${o.rowCls ? o.rowCls(r) : ""}" style="grid-template-columns:${T}" data-u="${r._id}"><span style="color:#9aa4ae;font-size:11px">${S.rows.indexOf(r) + 1}</span>${cols.map(c => cell(c, r)).join("")}${o.del ? `<span><button type="button" class="dl" data-del="${r._id}" title="حذف السطر">${ICO_X}</button></span>` : ""}</div>`).join("")
        : (o.newRow ? "" : `<div class="bcp-emp">${ICO_EMPTY}<span>${E(o.empty || "لا توجد أصناف")}</span></div>`)}</div></div>`;
    host.querySelectorAll(".bcp-gh div[data-k]").forEach(d => d.onclick = () => { const k = d.dataset.k, c = cols.find(x => x.k === k); if (c && c.ns) return; S.sort = S.sort && S.sort.k === k ? (S.sort.d > 0 ? { k, d: -1 } : null) : { k, d: 1 }; o.redraw(); });
    host.querySelectorAll("[data-del]").forEach(b => b.onclick = () => {
      const id = +b.dataset.del, rw = b.closest(".bcp-gr");
      const go = () => { const done = () => { S.rows = S.rows.filter(x => x._id !== id); o.redraw(); count(); }; if (RM()) done(); else { rw.classList.add("out"); setTimeout(done, 200); } };
      if (o.confirmDel && typeof askConfirm === "function") askConfirm("هل تريد حذف هذا السطر ؟", go); else go();
    });
    host.querySelectorAll(".bcp-gr [data-f]").forEach(inp => {
      const id = +inp.closest(".bcp-gr").dataset.u, r = S.rows.find(x => x._id === id), f = inp.dataset.f;
      const set = () => { if (!r) return; if (f === "unit") { o.onUnit && o.onUnit(r, inp.value); } else if (inp.type === "number") r[f] = Math.max(0, num(inp.value)); else { r[f] = inp.value; if (f === "code" && o.onCode) o.onCode(r, inp); } count(); };
      inp.addEventListener(inp.tagName === "SELECT" ? "change" : "input", set);
      inp.addEventListener("focus", () => { inp.closest(".bcp-gr").classList.add("fo"); if (inp.select) try { inp.select(); } catch (_) {} });
      inp.addEventListener("blur", () => inp.closest(".bcp-gr").classList.remove("fo"));
      inp.addEventListener("keydown", e => {
        if (e.key !== "Enter" && e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
        const all = [...host.querySelectorAll(".bcp-gr [data-f]")], i = all.indexOf(inp);
        if (e.key === "Enter") { e.preventDefault(); if (f === "code" && o.onCode) o.onCode(r, inp, true); const nx = all[i + 1]; if (nx) nx.focus(); else if (o.newRow) o.newRow.onClick(); return; }
        if (inp.tagName === "SELECT") return;
        e.preventDefault(); const per = cols.filter(c => c.ed).length, nx = all[i + (e.key === "ArrowDown" ? per : -per)]; if (nx) nx.focus();
      });
    });
    const nr = host.querySelector("[data-new]"); if (nr && o.newRow) nr.onclick = e => { if (!e.target.closest("input")) o.newRow.onClick(nr); };
  }
  function cell(c, r) {
    const v = r[c.k];
    if (c.ed === "num") return `<span><input type="number" min="0" step="any" data-f="${c.k}" value="${E(v == null ? "" : v)}" aria-label="${E(c.t)}"></span>`;
    if (c.ed === "txt") return `<span><input type="text" data-f="${c.k}" class="${c.cls || ""}" value="${E(v == null ? "" : v)}" aria-label="${E(c.t)}" autocomplete="off"></span>`;
    if (c.ed === "unit") { const p = P().find(x => x.id === r.pid); const us = p ? unitsOf(p) : [{ name: r.unit }]; return `<span><select data-f="unit" aria-label="الوحدة">${us.map(u => `<option${u.name === r.unit ? " selected" : ""}>${E(u.name)}</option>`).join("")}</select></span>`; }
    if (c.html) return `<span class="${c.cls || ""}" title="${E(v)}">${c.html(v, r)}</span>`;
    return `<span class="${c.cls || ""}" title="${E(v)}">${E(c.fmt ? c.fmt(v, r) : v)}</span>`;
  }
  const mkRow = o => Object.assign({ _id: ++uid }, o);

  /* ======================= فاتورة ======================= */
  function paneInv() {
    const A = g("bcpA");
    A.innerHTML = `<div class="bcp-opts">
  <div class="bcp-f"><label for="bcpDeal">التعامل</label><select id="bcpDeal">${DEALS.map(d => `<option value="${d[0]}"${d[0] === INV.deal ? " selected" : ""}>${E(d[1])}</option>`).join("")}</select></div>
  <div class="bcp-f" id="bcpPerW"><label for="bcpPer">فترة البحث</label><select id="bcpPer">${PERIODS.map((x, i) => `<option value="${i}"${i === +INV.per ? " selected" : ""}>${E(x)}</option>`).join("")}</select></div>
 </div>
 <div class="bcp-opts" id="bcpBillW" style="margin-top:-2px">
  <div class="bcp-f" style="min-width:130px"><select id="bcpFlt" aria-label="البحث بـ">${FILTERS.map(f => `<option value="${f[0]}"${f[0] === INV.flt ? " selected" : ""}>${E(f[1])}</option>`).join("")}</select></div>
  <div class="bcp-bill"><input id="bcpBill" autocomplete="off" placeholder="اكتب للبحث ثم اختر الفاتورة…" role="combobox" aria-expanded="false"><span class="ar" id="bcpBillAr">&#9660;</span>
   <div class="bcp-bdd" id="bcpBdd"><div class="bcp-bh"><div></div><div>الرقم</div><div>التاريخ</div><div>الاسم</div><div>الاجمالي</div><div>الأصناف</div></div><div class="bcp-bl" id="bcpBl"></div><div class="bcp-bf"><span class="xx" id="bcpBx" style="color:#d22;cursor:pointer;font-weight:700">&#10005;</span><span id="bcpBn"></span></div></div></div>
 </div>
 <div id="bcpIG"></div><div class="bcp-sum" id="bcpISum"></div>`;
    const deal = g("bcpDeal"), per = g("bcpPer"), flt = g("bcpFlt"), inp = g("bcpBill");
    const sync = () => { const c = INV.deal === "cur"; g("bcpPerW").style.display = c ? "none" : ""; g("bcpBillW").style.display = c ? "none" : ""; };
    deal.onchange = () => { INV.deal = deal.value; LS.set("bcp.deal", INV.deal); INV.list = null; INV.bill = null; inp.value = ""; if (INV.deal === "cur") loadCurrent(); else { INV.rows = []; drawInv(); } sync(); };
    per.onchange = () => { INV.per = +per.value; LS.set("bcp.per", INV.per); INV.list = null; if (g("bcpBdd").classList.contains("show")) billLoad(); };
    flt.onchange = () => { INV.flt = flt.value; LS.set("bcp.flt", INV.flt); billPaint(); inp.focus(); };
    inp.addEventListener("focus", () => billShow());
    inp.addEventListener("input", () => { billShow(); billPaint(); });
    inp.addEventListener("keydown", e => {
      const L = INV._f || []; if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); billShow(); INV._hi = Math.max(0, Math.min(L.length - 1, (INV._hi || 0) + (e.key === "ArrowDown" ? 1 : -1))); billPaint(true); }
      else if (e.key === "Enter") { e.preventDefault(); const x = L[INV._hi || 0]; if (x) billPick(x); }
    });
    g("bcpBillAr").addEventListener("mousedown", e => { e.preventDefault(); if (g("bcpBdd").classList.contains("show")) billHide(); else { inp.focus(); billShow(); } });
    g("bcpBx").onclick = billHide;
    g("bcpBl").addEventListener("mousedown", e => { const r = e.target.closest(".bcp-brw[data-i]"); if (!r) return; e.preventDefault(); billPick((INV._f || [])[+r.dataset.i]); });
    sync();
    if (INV.deal === "cur") loadCurrent(); else drawInv();
    if (INV.bill) inp.value = INV.bill.no + " — " + (INV.bill.name || "");
  }
  function perRange() { const d = PDAYS[+INV.per] || 0, to = new Date(), f = new Date(); f.setDate(f.getDate() - Math.min(d, 36500)); const s = x => x.toISOString().slice(0, 10); return { from: +INV.per === 5 ? "2000-01-01" : s(f), to: s(to) }; }
  async function billLoad() {
    const key = INV.deal + "|" + INV.per; if (INV.list && INV.listKey === key) { billPaint(); return; }
    INV.loading = true; billPaint();
    let L = [];
    try {
      if (window.Anouer && Anouer.invoicesList) {
        const r = perRange(), res = await Anouer.invoicesList({ from: r.from, to: r.to, type: INV.deal, q: "", top: 1000 });
        L = (res || []).map(x => ({ id: x.InvoiceId, no: String(x.InvoiceNo || ""), date: String(x.InvoiceDate || "").slice(0, 10), name: x.PartyName || "", total: +x.GrandTotal || 0, cnt: +x.ItemCount || 0, user: x.CreatedByName || x.UserName || "", phone: x.Phone || "" }));
      }
    } catch (_) {}
    if (!L.length && INV.deal === "Sale") { try { L = (SAVED_INV || []).map(x => ({ id: "s:" + x.no, no: String(x.no), date: x.date, name: x.name, total: +x.total || 0, cnt: x.cnt || (x.rows || []).length, local: x })); } catch (_) {} }
    INV.list = L; INV.listKey = key; INV.loading = false; INV._hi = 0; billPaint();
  }
  function billShow() { const d = g("bcpBdd"); if (!d) return;
    { const m = g("bcpMain").getBoundingClientRect(), b = d.parentNode.getBoundingClientRect(); d.style.width = Math.max(360, Math.min(640, b.right - m.left - 10)) + "px"; }
    if (!d.classList.contains("show")) { d.classList.add("show"); g("bcpBill").setAttribute("aria-expanded", "true"); billLoad(); } }
  function billHide() { const d = g("bcpBdd"); if (d) { d.classList.remove("show"); const i = g("bcpBill"); if (i) i.setAttribute("aria-expanded", "false"); } }
  function billPaint(keepHi) {
    const B = g("bcpBl"); if (!B) return;
    if (INV.loading) { B.innerHTML = '<div class="bcp-sk"></div><div class="bcp-sk"></div><div class="bcp-sk"></div>'; g("bcpBn").textContent = "جارٍ التحميل…"; return; }
    const raw = g("bcpBill").value.trim(), q = /—/.test(raw) && INV.bill ? "" : raw, nq = AN(q);
    const F = { no: x => x.no, name: x => x.name, phone: x => x.phone, total: x => String(x.total), user: x => x.user }[INV.flt] || (x => x.no);
    const L = (INV.list || []).filter(x => !q || AN(F(x)).includes(nq)).sort((a, b) => (INV.flt === "no" && q ? (a.no === q ? -1 : b.no === q ? 1 : 0) : 0) || String(b.date).localeCompare(String(a.date)) || (+b.no - +a.no));
    INV._f = L; if (!keepHi) INV._hi = 0;
    const hl = t => { t = String(t || ""); if (!q) return E(t); const i = AN(t).indexOf(nq); return i < 0 || AN(t).length !== t.length ? E(t) : E(t.slice(0, i)) + "<mark>" + E(t.slice(i, i + q.length)) + "</mark>" + E(t.slice(i + q.length)); };
    B.innerHTML = L.length ? L.slice(0, 300).map((x, i) => `<div class="bcp-brw${i === INV._hi ? " sel" : ""}" data-i="${i}"><span>${i === INV._hi ? "&#8592;" : ""}</span><span class="no">${INV.flt === "no" ? hl(x.no) : E(x.no)}</span><span>${E(x.date)}</span><span class="nm">${INV.flt === "name" ? hl(x.name) : E(x.name)}</span><span>${INV.flt === "total" ? hl(fmt(x.total)) : fmt(x.total)}</span><span>${x.cnt || ""}</span></div>`).join("")
      : `<div class="bcp-emp" style="padding:18px">${q ? "لا توجد فاتورة مطابقة" : "لا توجد فواتير «" + E((DEALS.find(d => d[0] === INV.deal) || [])[1] || "") + "» في " + E(PERIODS[+INV.per])}</div>`;
    g("bcpBn").textContent = L.length + " فاتورة";
    const s = B.querySelector(".bcp-brw.sel"); if (s) s.scrollIntoView({ block: "nearest" });
  }
  /* TxtBill_EditValueChanged ⇒ loadInvoiceBarcodeItems */
  async function billPick(x) {
    if (!x) return; INV.bill = x; billHide(); g("bcpBill").value = x.no + " — " + (x.name || "");
    g("bcpIG").innerHTML = '<div class="bcp-sk"></div><div class="bcp-sk"></div><div class="bcp-sk"></div>';
    let lines = [];
    try {
      if (x.local) lines = (x.local.rows || []).map(r => ({ pid: r.pid, name: r.name, unit: r.unit, qty: r.qty, price: r.price }));
      else if (window.Anouer && Anouer.invoiceDetail) { const d = await Anouer.invoiceDetail(x.id); lines = ((d && d.Lines) || []).map(l => ({ pid: l.ProductId, code: l.ProductCode, name: l.ProductName, unit: l.UnitName, qty: +l.Qty || 0, price: +l.UnitPrice || 0 })); }
    } catch (e) { say("تعذّر تحميل أصناف الفاتورة: " + ((e && e.message) || e), "e"); }
    INV.rows = linesToRows(lines); drawInv(true);
    if (!INV.rows.length) say("الفاتورة لا تحتوي على أصناف", "w"); else outNote();
  }
  function linesToRows(lines) {
    return lines.map(l => {
      const p = P().find(q => q.id === l.pid) || P().find(q => String(q.code) === String(l.code));
      const u = p ? (unitsOf(p).find(z => z.name === l.unit) || defUnit(p)) : null;
      const iq = Math.max(0, Math.round(+l.qty || 0)), r = mkRow({ pid: p ? p.id : l.pid, code: u ? String(u.bc || p.code) : String(l.code || ""), name: p ? p.name : l.name, unit: u ? u.name : (l.unit || ""), qty: INV.one ? (+l.qty > 0 ? 1 : 0) : iq, price: p ? priceOf(p, u, "1") || +l.price || 0 : +l.price || 0 });
      r.iq = iq || (+l.qty > 0 ? 1 : 0);
      /* صنف نفد (رصيده 0 أو أقل): لا يُطبع له تيكت — حتى لا يضيع تيكت باطل على الرف */
      r.out = !!p && (+p.stock || 0) <= 0; r.qty = invQ(r); return r;
    }).filter(r => r.code);
  }
  function invQ(r) { if (r.out && INV.skip) return 0; const q = r.iq != null ? r.iq : +r.qty || 0; return INV.one ? (q > 0 ? 1 : 0) : q; }
  function outNote() { const n = INV.rows.filter(r => r.out).length; if (n && INV.skip) say("🚫 تم تخطّي " + n + (n === 1 ? " صنف نفد" : " أصناف نفدت") + " (الرصيد 0) — لن يُطبع لها تيكت", "i"); }
  function loadCurrent() {
    let rs = []; try { rs = (rows || []).filter(r => r && r.pid && r.qty > 0).map(r => ({ pid: r.pid, name: r.name, unit: r.unit, qty: r.qty, price: r.price })); } catch (_) {}
    INV.rows = linesToRows(rs); drawInv(true); outNote();
  }
  function drawInv(anim) {
    const host = g("bcpIG"); if (!host) return;
    grid(host, [{ k: "code", t: "كود الصنف", w: "132px", cls: "cd" }, { k: "name", t: "اسم الصنف", cls: "t", html: (v, r) => (r.out ? `<b class="bcp-nf" title="رصيد الصنف 0 — ${INV.skip ? "لن يُطبع له تيكت (اكتب كمية لطباعته)" : "سيُطبع"}">نفد</b>` : "") + E(v) }, { k: "unit", t: "الوحدة", w: "118px", ed: "unit" }, { k: "qty", t: "الكمية", w: "78px", ed: "num" }, { k: "price", t: "السعر", w: "90px", ed: "num" }], INV,
      { del: true, confirmDel: true, rowCls: r => r.out ? (INV.skip && !(+r.qty > 0) ? " nf" : " nf in") : "", empty: INV.deal === "cur" ? "الفاتورة الحالية فارغة — أضف أصنافاً أولاً" : "اختر الفاتورة لتحميل أصنافها", redraw: () => drawInv(), onUnit: (r, n) => { const p = P().find(x => x.id === r.pid); if (!p) return; const u = unitByName(p, n); r.unit = u.name; r.code = String(u.bc || p.code); r.price = priceOf(p, u, "1"); drawInv(); } });
    if (anim && !RM()) host.querySelectorAll(".bcp-gr").forEach((r, i) => r.animate([{ opacity: 0, transform: "translateY(-6px)" }, { opacity: 1, transform: "none" }], { duration: 300, delay: 25 * i, fill: "backwards", easing: "cubic-bezier(.2,1,.3,1)" }));
    sumLine("bcpISum", INV.rows); count();
    { const el = g("bcpISum"); if (el && INV.rows.length) { const sm = LS.get("bcp.smart", true) !== false;
      el.insertAdjacentHTML("beforeend", `<span class="sp"></span>${INV.rows.some(r => r.out) ? `<button type="button" class="bcp-chip bcp-nfc${INV.skip ? " on" : ""}" data-skip title="الأصناف التي نفدت (رصيد 0) لا يُطبع لها تيكت — حتى لا يضيع تيكت باطل"><i>🚫</i> تخطّي النافد <b>${INV.rows.filter(r => r.out).length}</b></button>` : ""}<button type="button" class="bcp-chip${INV.one ? " on" : ""}" data-one title="كل صنف في الفاتورة = تيكت واحد (بدل عدد القطع المباعة)">🎫 تيكت واحد لكل صنف</button><button type="button" class="bcp-chip bcp-au${autoTpl ? " on" : ""}" data-auto title="AUTO: تيكت ذكي واحد لكل صنف — اسم الصنف، سعر القطعة، سعر الوحدة الكبرى باسمها، سعر القطعة داخلها (أو السعر و5 ومافوق للوحدة الواحدة) — بمقاس تيكت DEXEF"><b>AUTO</b> تيكت ذكي</button><button type="button" class="bcp-chip${sm ? " on" : ""}" data-smart title="كل سعر في التيكت يُملأ حسب الشارة التي بجانبه: سعر القطعة، سعر الفاردو/الكرتونة، سعر القطعة داخلها، 5 ومافوق…">✨ أسعار حقيقية حسب الشارة</button>`);
      if (!el.__chips) { el.__chips = 1; el.addEventListener("click", e => {
        if (e.target.closest("[data-auto]")) {
          const B2 = window.__BDZ; const on = !autoTpl;
          if (B2 && B2.commit) { if (on) B2.commit("auto"); else { const k = LS.get("bcp.noauto", null); B2.commit(k && k !== "auto" ? k : (B2.list().find(x => !x.auto && !x.tpl && x.def) || B2.list().find(x => !x.auto && !x.tpl) || {}).key); } }
          else { const sl = g("bcpTpl"); if (sl && on) { sl.value = "auto"; sl.dispatchEvent(new Event("change", { bubbles: true })); } }
          say(on ? "AUTO ✨ — تيكت ذكي واحد لكل صنف بأسعاره الحقيقية" : "رجعت لتصميم التيكت السابق", "i"); return;
        }
        if (e.target.closest("[data-one]")) { INV.one = !INV.one; LS.set("bcp.one", INV.one); INV.rows.forEach(r => { r.qty = invQ(r); }); drawInv(); say(INV.one ? "تيكت واحد لكل صنف — " + INV.rows.length + " تيكت" : "عدد التيكت = الكمية المباعة", "i"); }
        else if (e.target.closest("[data-skip]")) { INV.skip = !INV.skip; LS.set("bcp.skipOut", INV.skip); INV.rows.forEach(r => { if (r.out) r.qty = invQ(r); }); drawInv(); const n = INV.rows.filter(r => r.out).length; say(INV.skip ? "🚫 " + n + " صنف نفد — لن يُطبع لها تيكت" : "سيُطبع تيكت للأصناف النافدة أيضاً (" + n + ")", "i"); }
        else if (e.target.closest("[data-smart]")) { const v = !(LS.get("bcp.smart", true) !== false); LS.set("bcp.smart", v); drawInv(); try { window.dispatchEvent(new CustomEvent("anouer:bcpsmart")); } catch (x) { } say(v ? "الأسعار تُملأ حسب الشارات (القطعة / الفاردو / داخل الكرتونة …)" : "الأسعار كما في تصميم التيكت الأصلي", "i"); }
      }); } } }
  }
  function sumLine(id, rs) { const el = g(id); if (!el) return; const n = rs.reduce((s, r) => s + Math.max(0, Math.floor(+r.qty || 0)), 0); el.innerHTML = rs.length ? `<span>الأصناف <b>${rs.length}</b></span><span>الملصقات <b>${n}</b></span>` + (rs.some(r => !(+r.qty > 0)) ? `<span style="color:#b45309">أسطر بكمية صفر لن تُطبع</span>` : "") : ""; }

  /* ======================= اختيار أصناف ======================= */
  function paneSel() {
    const A = g("bcpA");
    A.innerHTML = `<button type="button" class="bcp-pick" id="bcpPickBtn"><svg width="26" height="22" viewBox="0 0 26 22"><path d="M2 8h22l-3 12H5z" fill="#1a6fd0"/><path d="M8 8l4-6M18 8l-4-6" stroke="#1a6fd0" stroke-width="2" stroke-linecap="round"/><circle cx="10" cy="14" r="1.6" fill="#fff"/><circle cx="16" cy="14" r="1.6" fill="#fff"/></svg><span>إختيار الأصناف</span></button>
 <div class="bcp-opts">
  <div class="bcp-f"><label for="bcpQf">كيفية ملأ خانة الكميه</label><select id="bcpQf">${QFILL.map(x => `<option value="${x[0]}"${x[0] === SEL.fill ? " selected" : ""}>${x[1]}</option>`).join("")}</select></div>
  <div class="bcp-f"><label for="bcpUn">وحدات الصنف</label><select id="bcpUn">${UNITS.map(x => `<option value="${x[0]}"${x[0] === SEL.units ? " selected" : ""}>${x[1]}</option>`).join("")}</select></div>
  <div class="bcp-f"><label for="bcpSp">سعر الصنف المستخدم</label><select id="bcpSp">${priceLevels().map(x => `<option value="${x[0]}"${x[0] === SEL.price ? " selected" : ""}>${E(x[1])}</option>`).join("")}</select></div>
 </div><div id="bcpSG"></div><div class="bcp-sum" id="bcpSSum"></div>`;
    g("bcpPickBtn").onclick = () => openPicker(list => { list.forEach(p => addSel(p)); drawSel(true); });
    /* CmbQtyFillType_SelectedIndexChanged */
    g("bcpQf").onchange = e => { SEL.fill = e.target.value; LS.set("bcp.fill", SEL.fill); SEL.rows.forEach(r => r.qty = fillQty(r)); drawSel(); };
    g("bcpUn").onchange = e => { SEL.units = e.target.value; LS.set("bcp.units", SEL.units); };
    /* TxtPrice_SelectedIndexChanged */
    g("bcpSp").onchange = e => { SEL.price = e.target.value; LS.set("bcp.price", SEL.price); SEL.rows.forEach(r => { const p = P().find(x => x.id === r.pid); if (p) r.price = priceOf(p, unitByName(p, r.unit), SEL.price); }); drawSel(); };
    drawSel();
  }
  function fillQty(r) { if (SEL.fill === "1Qty") return 1; if (SEL.fill === "0Qty") return 0; const p = P().find(x => x.id === r.pid); return p ? stockOf(p, unitByName(p, r.unit)) : 0; }
  function addSel(p, only) {
    const us = SEL.units === "AllUnite" && !only ? unitsOf(p) : [defUnit(p)];
    us.forEach(u => { if (SEL.rows.some(r => r.pid === p.id && r.unit === u.name)) return; const r = mkRow({ pid: p.id, code: String(u.bc || p.code), name: p.name, unit: u.name, price: priceOf(p, u, SEL.price) }); r.qty = fillQty(r); SEL.rows.push(r); });
  }
  function drawSel(anim) {
    const host = g("bcpSG"); if (!host) return; const before = new Set([...host.querySelectorAll(".bcp-gr")].map(x => x.dataset.u));
    grid(host, [{ k: "code", t: "كود الصنف", w: "132px", cls: "cd" }, { k: "name", t: "اسم الصنف", cls: "t" }, { k: "qty", t: "الكمية", w: "78px", ed: "num" }, { k: "unit", t: "الوحدة", w: "118px", ed: "unit" }, { k: "price", t: "السعر", w: "90px", ed: "num" }], SEL,
      { del: true, redraw: () => drawSel(), newRow: { onClick: nr => acOpen(nr || host.querySelector("[data-new]")) }, onUnit: (r, n) => { const p = P().find(x => x.id === r.pid); if (!p) return; const u = unitByName(p, n); r.unit = u.name; r.code = String(u.bc || p.code); r.price = priceOf(p, u, SEL.price); r.qty = fillQty(r); drawSel(); } });
    if (anim) host.querySelectorAll(".bcp-gr").forEach(r => { if (!before.has(r.dataset.u)) r.classList.add("add"); });
    sumLine("bcpSSum", SEL.rows); count();
  }
  /* «Click here to add a new row» ⇒ بحث مباشر عن صنف */
  let acL = [], acI = 0, acCb = null;
  function acOpen(nr, cb) {
    if (!nr) return; acCb = cb || (p => { const n0 = SEL.rows.length; addSel(p); if (SEL.rows.length === n0) say("«" + p.name + "» موجود بالفعل في القائمة", "w"); drawSel(true); });
    nr.innerHTML = `<span>&#10033;</span><span class="srch"><input id="bcpAcI" placeholder="اكتب اسم الصنف أو الكود أو امسح الباركود…" autocomplete="off"></span>`;
    const i = g("bcpAcI"); i.focus();
    i.addEventListener("input", acPaint);
    i.addEventListener("keydown", e => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); acI = Math.max(0, Math.min(acL.length - 1, acI + (e.key === "ArrowDown" ? 1 : -1))); acPaint(true); }
      else if (e.key === "Enter") { e.preventDefault(); const v = i.value.trim(), ex = findByCode(v); const p = ex ? ex.p : acL[acI]; if (p) { const keep = acCb; acCb(p); setTimeout(() => { const n2 = document.querySelector("#bcpA [data-new]"); if (n2) acOpen(n2, keep); }, 30); } }
    });
    acPaint();
  }
  function acPaint(keep) {
    const i = g("bcpAcI"); if (!i) return; const q = AN(i.value);
    if (!keep) acI = 0;
    acL = P().filter(p => !q || AN(p.name).includes(q) || String(p.code).toLowerCase().includes(q) || String(p.barcode || "").includes(q)).slice(0, 60);
    let box = g("bcpAc"); if (!box) { box = document.createElement("div"); box.className = "bcp-ac"; box.id = "bcpAc"; i.parentNode.appendChild(box); box.addEventListener("mousedown", e => { const d = e.target.closest("div[data-i]"); if (!d) return; e.preventDefault(); const p = acL[+d.dataset.i]; if (p) { const keep = acCb; acCb(p); setTimeout(() => { const n2 = document.querySelector("#bcpA [data-new]"); if (n2) acOpen(n2, keep); }, 30); } }); }
    box.innerHTML = acL.length ? acL.map((p, k) => `<div data-i="${k}" class="${k === acI ? "sel" : ""}"><span>${E(p.code)}</span><span>${E(p.name)}</span><span>${fmt(p.price)}</span></div>`).join("") : '<span class="no">لا توجد نتائج</span>';
    const s = box.querySelector(".sel"); if (s) s.scrollIntoView({ block: "nearest" });
  }
  function acHide() { const b = g("bcpAc"); if (b) { b.remove(); if (mode === "sel") drawSel(); else if (mode === "man") drawMan(); } }

  /* نافذة «إختيار الأصناف» (Dexef.DataEntry: اختيار متعدد) */
  function openPicker(done) {
    let d = g("bsi"); if (d) d.remove();
    d = document.createElement("dialog"); d.className = "bsi"; d.id = "bsi"; document.body.appendChild(d);
    const cats = [...new Set(P().map(p => p.cat || p.group || "").filter(Boolean))];
    const S = { q: "", cat: "", stk: false, on: new Set(), fo: 0, list: [] };
    d.innerHTML = `<div class="bsi-c"><div class="bsi-h"><svg width="22" height="20" viewBox="0 0 26 22"><path d="M2 8h22l-3 12H5z" fill="#1a6fd0"/><path d="M8 8l4-6M18 8l-4-6" stroke="#1a6fd0" stroke-width="2" stroke-linecap="round"/></svg><h3>إختيار الأصناف</h3><button class="x" type="button" data-a="x" aria-label="إغلاق">&#10005;</button></div>
 <div class="bsi-s"><div class="q"><svg width="16" height="16" viewBox="0 0 16 16"><circle cx="7" cy="7" r="5.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M11 11l4 4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg><input id="bsiQ" placeholder="بحث بالاسم أو الكود أو الباركود…" autocomplete="off"></div>
  ${cats.length ? `<select id="bsiCat"><option value="">كل المجموعات</option>${cats.map(c => `<option>${E(c)}</option>`).join("")}</select>` : ""}
  <label class="bsi-chk"><input type="checkbox" id="bsiStk">برصيد فقط</label><label class="bsi-chk"><input type="checkbox" id="bsiAll">تحديد الكل</label></div>
 <div class="bsi-gh"><div></div><div>كود الصنف</div><div>اسم الصنف</div><div>الوحدة</div><div>الرصيد</div><div>السعر</div></div>
 <div class="bsi-l" id="bsiL"></div>
 <div class="bsi-f"><span class="n">المحدد <b id="bsiN">0</b> صنف</span><span class="sp"></span><button class="bsi-b gh" type="button" data-a="x">إلغاء</button><button class="bsi-b" type="button" data-a="ok" id="bsiOk" disabled>إضافة</button></div></div>`;
    const paint = () => {
      const q = AN(S.q); S.list = P().filter(p => (!q || AN(p.name).includes(q) || String(p.code).toLowerCase().includes(q) || String(p.barcode || "").includes(q)) && (!S.cat || (p.cat || p.group) === S.cat) && (!S.stk || +p.stock > 0));
      S.fo = Math.min(S.fo, Math.max(0, S.list.length - 1));
      const hl = t => { t = String(t || ""); if (!q) return E(t); const i = AN(t).indexOf(q); return i < 0 || AN(t).length !== t.length ? E(t) : E(t.slice(0, i)) + "<mark>" + E(t.slice(i, i + q.length)) + "</mark>" + E(t.slice(i + q.length)); };
      g("bsiL").innerHTML = S.list.length ? S.list.slice(0, 800).map((p, i) => `<div class="bsi-r${S.on.has(p.id) ? " on" : ""}${i === S.fo ? " fo" : ""}" data-i="${i}"><span><input type="checkbox" tabindex="-1"${S.on.has(p.id) ? " checked" : ""}></span><span class="cd">${hl(p.code)}</span><span class="nm">${hl(p.name)}</span><span>${E(defUnit(p).name)}</span><span>${fmt(p.stock)}</span><span>${fmt(p.price)}</span></div>`).join("") : '<div class="bcp-emp">لا توجد أصناف مطابقة</div>';
      g("bsiN").textContent = S.on.size; g("bsiOk").disabled = !S.on.size; g("bsiOk").textContent = S.on.size ? "إضافة (" + S.on.size + ")" : "إضافة";
      const a = g("bsiAll"); a.checked = S.list.length > 0 && S.list.every(p => S.on.has(p.id));
      const f = g("bsiL").querySelector(".fo"); if (f) f.scrollIntoView({ block: "nearest" });
    };
    const fin = ok => { const sel = P().filter(p => S.on.has(p.id)); d.close(); d.remove(); if (ok && sel.length) done(sel); };
    d.addEventListener("click", e => { const a = e.target.closest("[data-a]"); if (a) { fin(a.dataset.a === "ok"); return; } const r = e.target.closest(".bsi-r"); if (r) { const p = S.list[+r.dataset.i]; S.fo = +r.dataset.i; if (S.on.has(p.id)) S.on.delete(p.id); else S.on.add(p.id); paint(); } });
    d.addEventListener("cancel", e => { e.preventDefault(); fin(false); });
    g("bsiQ").addEventListener("input", e => { S.q = e.target.value; S.fo = 0; paint(); });
    g("bsiQ").addEventListener("keydown", e => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); S.fo = Math.max(0, Math.min(S.list.length - 1, S.fo + (e.key === "ArrowDown" ? 1 : -1))); paint(); }
      else if (e.key === " " && e.ctrlKey || e.key === "Enter" && !e.ctrlKey) { e.preventDefault(); const p = S.list[S.fo]; if (p) { if (S.on.has(p.id)) S.on.delete(p.id); else S.on.add(p.id); paint(); } }
      else if (e.key === "Enter" && e.ctrlKey) { e.preventDefault(); fin(true); }
    });
    if (g("bsiCat")) g("bsiCat").onchange = e => { S.cat = e.target.value; paint(); };
    g("bsiStk").onchange = e => { S.stk = e.target.checked; paint(); };
    g("bsiAll").onchange = e => { S.list.forEach(p => e.target.checked ? S.on.add(p.id) : S.on.delete(p.id)); paint(); };
    d.showModal(); paint(); setTimeout(() => g("bsiQ").focus(), 30);
  }
  // مفاتيح نافذة الاختيار تمر عبر حاجز الصفحة
  { const prev = window.__viewKey; window.__viewKey = function (e) { const d = g("bsi"); if (d && d.open) { if (e.key === "Escape") { d.dispatchEvent(new Event("cancel", { cancelable: true })); return true; } return false; } return prev ? prev(e) : false; }; }

  /* ======================= يدوياً ======================= */
  function paneMan() {
    const A = g("bcpA"); A.innerHTML = '<div id="bcpMG"></div><div class="bcp-sum" id="bcpMSum"></div>';
    drawMan();
  }
  function drawMan(focusLast) {
    const host = g("bcpMG"); if (!host) return;
    grid(host, [{ k: "code", t: "الكود", ed: "txt", cls: "cd" }, { k: "qty", t: "الكمية", w: "170px", ed: "num" }, { k: "price", t: "السعر", w: "170px", ed: "num" }], MAN,
      { del: true, redraw: () => drawMan(), newRow: { onClick: () => { MAN.rows.push(mkRow({ code: "", qty: 1, price: 0 })); drawMan(true); } },
        onCode: (r, inp, commit) => { const f = findByCode(inp.value); if (f) { r.pid = f.p.id; r.name = f.p.name; if (commit || !r.price) { r.price = priceOf(f.p, f.u, "1"); const pi = inp.closest(".bcp-gr").querySelector('[data-f="price"]'); if (pi) pi.value = r.price; } inp.title = f.p.name + " — " + f.u.name; } else { r.pid = null; r.name = ""; inp.title = ""; } } });
    if (focusLast) { const ins = host.querySelectorAll('.bcp-gr [data-f="code"]'); const l = ins[ins.length - 1]; if (l) { l.closest(".bcp-gr").classList.add("add"); l.focus(); } }
    // اسم الصنف كتلميح أسفل الكود
    MAN.rows.forEach(r => { const f = r.code && findByCode(r.code); if (f) { r.pid = f.p.id; r.name = f.p.name; } });
    sumLine("bcpMSum", MAN.rows); count();
  }

  /* ======================= الطباعة ======================= */
  function count() {
    let n = 0;
    try {
      if (mode === "item") n = cur ? Math.max(0, Math.floor(+((g("bcpCnt") || {}).value) || 0)) : 0;
      else { const R = mode === "inv" ? INV.rows : mode === "sel" ? SEL.rows : MAN.rows; n = R.filter(r => r.code).reduce((s, r) => s + Math.max(0, Math.floor(+r.qty || 0)), 0); }
    } catch (_) {}
    const c = g("bcpCntAll"); if (c) c.innerHTML = "عدد الملصقات<b>" + n + "</b>";
  }
  /* ValidateData */
  function jobs() {
    if (mode === "item") {
      if (!cur) { g("bcpCb").classList.add("err"); say("اختر الصنف أولاً", "w"); g("bcpNm").focus(); return null; }
      const n = Math.floor(+g("bcpCnt").value); if (!(n >= 1)) { g("bcpCnt").classList.add("err"); say("عدد الملصقات غير صحيح", "w"); g("bcpCnt").focus(); return null; }
      const bc = g("bcpBc").value || String(cur.code), u = unitByBc(cur, bc) || defUnit(cur);
      return [{ name: cur.name, code: bc, price: +g("bcpPr").value || 0, n, unit: u.name, batch: g("bcpOp").value.trim(), exp: g("bcpEx").value }];
    }
    const R = mode === "inv" ? INV.rows : mode === "sel" ? SEL.rows : MAN.rows;
    if (mode === "man") R.forEach(r => { const f = findByCode(r.code); if (f) { r.name = f.p.name; r.unit = f.u.name; } });
    const out = R.filter(r => String(r.code || "").trim() && Math.floor(+r.qty || 0) >= 1).map(r => ({ name: r.name || "", code: String(r.code).trim(), price: +r.price || 0, n: Math.floor(+r.qty), unit: r.unit || "" }));
    if (!out.length) {
      say(!R.length ? (mode === "inv" ? "اختر الفاتورة أولاً — لا توجد أصناف للطباعة" : mode === "sel" ? "اضغط «إختيار الأصناف» أو أضف سطراً جديداً" : "أضف سطراً بالكود والكمية") : "لا توجد أسطر بكمية أكبر من صفر", "w");
      return null;
    }
    return out;
  }
  function sheet(js) {
    const T = TPL[tpl] || TPL[0], ty = document.querySelector('input[name=bcpTy]:checked'), type = ty ? ty.value : "lin";
    const sr = Math.max(1, Math.floor(+((g("bcpSr") || {}).value)) || 1), sc = Math.max(1, Math.floor(+((g("bcpSc") || {}).value)) || 1);
    const per = T.c * T.r, single = per === 1;
    if (!single && (sr > T.r || sc > T.c)) { say(`قيمة السطر/العمود خارج القالب (${T.r} سطر × ${T.c} عمود)`, "w"); return null; }
    const cells = []; if (!single) for (let i = 0; i < (sr - 1) * T.c + (sc - 1); i++) cells.push(null);
    js.forEach(j => { const svg = type === "qr" ? qrSvg(j.code) : linSvg(j.code); if (!svg) return; for (let i = 0; i < j.n; i++) cells.push({ j, svg }); });
    if (!cells.some(Boolean)) { say("تعذّر توليد الباركود لهذه القيمة", "e"); return null; }
    const pages = []; for (let i = 0; i < cells.length; i += per) pages.push(cells.slice(i, i + per));
    const fs = single ? 7 : T.c >= 4 ? 7 : 8.5;
    const lb = c => !c ? '<div class="lb"></div>' : `<div class="lb${type === "qr" ? " qr" : ""}">${c.j.name ? `<div class="nm">${E(c.j.name)}</div>` : ""}<div class="bc">${c.svg}</div><div class="cd">${E(c.j.code)}</div>${c.j.price > 0 ? `<div class="pr">${E(fmt(c.j.price))} دج</div>` : ""}${c.j.exp || c.j.batch ? `<div class="ex">${c.j.batch ? "LOT " + E(c.j.batch) : ""}${c.j.batch && c.j.exp ? " · " : ""}${c.j.exp ? "EXP " + E(c.j.exp) : ""}</div>` : ""}</div>`;
    return `<!doctype html><html dir="rtl" lang="ar"><meta charset="utf-8"><title>طباعة الباركود</title><style>
@page{size:${T.w}mm ${T.h}mm;margin:0}*{box-sizing:border-box}body{margin:0;background:#777;font-family:"Droid Arabic Kufi","Segoe UI",Tahoma,sans-serif}
.pg{width:${T.w}mm;height:${T.h}mm;background:#fff;margin:10px auto;display:grid;grid-template-columns:repeat(${T.c},1fr);grid-template-rows:repeat(${T.r},1fr);overflow:hidden;page-break-after:always;break-after:page;direction:ltr}
.lb{overflow:hidden;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:1.2mm 1.5mm;gap:.4mm;outline:.1mm dashed #ddd;direction:rtl;min-width:0;min-height:0}
.nm{font-size:${fs}pt;font-weight:700;line-height:1.15;max-height:2.4em;overflow:hidden;width:100%}.bc{width:92%;flex:1 1 0;min-height:0;display:flex;justify-content:center}.bc svg{width:100%;height:100%}.lb.qr .bc{width:auto;aspect-ratio:1/1}
.cd{font-size:${fs - 1}pt;letter-spacing:.3mm;direction:ltr;line-height:1.1}.pr{font-size:${fs + 1.5}pt;font-weight:700;line-height:1.1}.ex{font-size:${fs - 1.5}pt;direction:ltr;color:#333}
@media print{body{background:#fff}.pg{margin:0}.lb{outline:0}}</style><body>${pages.map(p => { const fill = p.concat(Array(per - p.length).fill(null)); return `<div class="pg">${fill.map(lb).join("")}</div>`; }).join("")}</body></html>`;
  }
  function run(preview) {
    const js = jobs(); if (!js) return;
    /* 🏷️ تيكت العروض A5 (3 تصاميم ملوّنة) */
    if (offTpl && window.__BCO) {
      try { if (window.__BCA) __BCA.clearLast(); } catch (_) {}
      __BCO.print(js, preview, offTpl).then(n => { if (!preview && n) say("تم إرسال " + n + " تيكت عروض A5 للطباعة", "s"); }).catch(e => say("تعذّرت الطباعة: " + ((e && e.message) || e), "e"));
      return;
    }
    try { if (window.__BCO) __BCO.clearLast(); } catch (_) {}
    /* ✨ AUTO: تيكت ذكي واحد لكل صنف بمقاس تيكت DEXEF */
    if (autoTpl && window.__BCA) {
      __BCA.print(js, preview).then(n => { if (!preview && n) say("تم إرسال " + n + " تيكت AUTO للطباعة", "s"); }).catch(e => say("تعذّرت الطباعة: " + ((e && e.message) || e), "e"));
      return;
    }
    if (rdTpl && window.ANOUER_RD && ANOUER_RD.printLabels) {
      ANOUER_RD.load().then(idx => { const it = idx.items.find(x => x.id === rdTpl); return ANOUER_RD.printLabels(js, { item: it, preview, r0: Math.max(1, Math.floor(+((g("bcpSr") || {}).value)) || 1), c0: Math.max(1, Math.floor(+((g("bcpSc") || {}).value)) || 1) }); })
        .then(() => { if (!preview) say("تم إرسال " + js.reduce((s, j) => s + j.n, 0) + " ملصق للطباعة", "s"); }).catch(e => say("تعذّرت الطباعة: " + ((e && e.message) || e), "e"));
      return;
    }
    try { if (window.__BCA) __BCA.clearLast(); } catch (_) {}
    const html = sheet(js); if (!html) return;
    if (preview) { const f = g("bcpFr"); f.srcdoc = html; g("bcpPv").classList.add("show"); return; }
    let f = g("bcpPf"); if (f) f.remove(); f = document.createElement("iframe"); f.id = "bcpPf"; f.style.cssText = "position:fixed;width:0;height:0;border:0;right:0;bottom:0"; document.body.appendChild(f);
    f.onload = () => { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (_) { say("تعذّرت الطباعة", "e"); } }; f.srcdoc = html;
  }

  /* عيّنة للمعاينة الحيّة في bc-design-pick */
  window.__bcpSample = function () {
    try {
      if (mode === "item" && cur) return { name: cur.name, code: (g("bcpBc") || {}).value || String(cur.code), price: +((g("bcpPr") || {}).value) || cur.price || 0, n: 1, unit: (unitByBc(cur, (g("bcpBc") || {}).value) || defUnit(cur)).name, batch: ((g("bcpOp") || {}).value || "").trim(), exp: (g("bcpEx") || {}).value || "" };
      const R = mode === "inv" ? INV.rows : mode === "sel" ? SEL.rows : mode === "man" ? MAN.rows : [];
      const r = R.find(x => x.code); if (r) { const f = findByCode(r.code); return { name: r.name || (f && f.p.name) || "", code: String(r.code), price: +r.price || 0, n: 1, unit: r.unit || "" }; }
    } catch (_) {}
    return null;
  };

  function open() {
    build(); const o = g("bcpOv"); o.classList.add("show"); setMode(mode);
    const w = o.querySelector(".bcp-w"); w.dataset.max = "0";
    if (window.ANOUER_RD && ANOUER_RD.labelDesigns) ANOUER_RD.labelDesigns().then(l => {
      const s = g("bcpTpl"); s.querySelectorAll("optgroup[data-rd]").forEach(x => x.remove()); if (!l.length) return;
      const og = document.createElement("optgroup"); og.label = "تصاميم الباركود (تصميم التقارير)"; og.dataset.rd = "1"; og.innerHTML = l.map(i => `<option value="rd:${E(i.id)}">${E(i.name)}${i.def ? " ✔" : ""}</option>`).join(""); s.appendChild(og);
      if (rdTpl && s.querySelector(`option[value="rd:${CSS.escape(rdTpl)}"]`)) s.value = "rd:" + rdTpl; else if (rdTpl) { rdTpl = null; s.value = String(tpl); }
    }).catch(() => {});
  }
  function close() { const o = g("bcpOv"); if (o) o.classList.remove("show"); ddHide(); billHide(); }
  window.bcpOpen = open; window.bcpClose = close;
  /* مراجعة الفواتير ← طباعة ← «طباعة باركود الأصناف»: يفتح «بالفاتورة» وأصناف الفاتورة محمّلة */
  window.bcpOpenBill = function (x, deal) {
    if (!x) return; open();
    if (deal && INV.deal !== deal) { INV.deal = deal; INV.list = null; INV.listKey = ""; }
    setMode("inv"); setTimeout(() => billPick(x), 40);
  };
  window.__bcpToast = (m, k) => inToast(m, k);
  window.__BCP = { setMode, INV, SEL, MAN, jobs, get mode() { return mode; }, priceOf, findByCode, linSvg, qrSvg, defUnit, unitsOf };
})();
