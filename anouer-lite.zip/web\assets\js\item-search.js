/* ANOUER — نافذة «البحث عن الأصناف» (مطابقة DEXEF ONE: F5 في شاشة البيع/اللمس، و«إضافة صنف» في المشتريات)
   - البحث: F1، طريقة البحث F2 (يبدأ بـ / يحتوى / ينتهى بـ)، أرصدة المخازن F3.
   - شجرة المجموعات الحقيقية (الفهرس ← المجموعات: رئيسية/فرعية) مع بحث وطيّ/فتح، واختيار مجموعة يعرض أصنافها وأصناف فروعها.
   - ≡ : تخصيص الأعمدة (Customization) — اضغط عموداً لإضافته، واسحب رأس عمود إلى اللوحة لإخفائه.
   - زر الشجرة / سهم الفاصل: إخفاء وإظهار المجموعات.
   - تحديد عدة أصناف (☐) ثم «موافق» يضيفها بالكمية المحددة أسفل النافذة، والنقر المزدوج أو Enter يضيف الصنف مباشرة.
   ITEM_SEARCH.open({ stock(p), onPick(list, qty), q }) */
(function () {
  "use strict";
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const norm = s => String(s == null ? "" : s).toLowerCase().replace(/[أإآا]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/[ً-ْ]/g, "").trim();
  const F = v => { v = Math.round((+v || 0) * 100) / 100; return v.toLocaleString("en-US", { maximumFractionDigits: 2 }); };
  const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } } };
  const PRODS = () => { try { const l = (typeof products !== "undefined" && Array.isArray(products) ? products : []).filter(p => p.active !== false); return window.__flvCollapse ? __flvCollapse(l) : l; } catch (e) { return []; } };
  /* لمسة صوتية: نقرة «ماريمبا» ناعمة تعلو نغمتها مع كل زيادة (سلّم خماسي) وتنخفض مع الإنقاص، ورنّة عند «موافق» */
  const SND = (() => {
    let ac = null; const on = () => LS.get("isrch.snd", true) !== false;
    const ctx = () => { try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === "suspended") ac.resume(); return ac; } catch (e) { return null; } };
    const PENTA = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24, 26, 28];
    function tone(f, at, dur, vol) {
      const a = ctx(); if (!a) return; const t = a.currentTime + (at || 0);
      const g = a.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      const lp = a.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 4200; g.connect(lp); lp.connect(a.destination);
      [[1, 1, "sine"], [3.99, 0.18, "sine"], [2, 0.12, "triangle"]].forEach(([m, v, ty]) => {
        const o = a.createOscillator(), og = a.createGain(); o.type = ty; o.frequency.setValueAtTime(f * m, t); og.gain.value = v; o.connect(og); og.connect(g); o.start(t); o.stop(t + dur + 0.02);
      });
    }
    const hz = st => 587.33 * Math.pow(2, st / 12); /* D5 */
    return {
      up(n) { if (!on()) return; const i = Math.max(0, Math.min(PENTA.length - 1, Math.round(n) - 2)); tone(hz(PENTA[i]), 0, 0.22, 0.17); tone(hz(PENTA[i] + 12), 0.035, 0.12, 0.05); },
      down(n) { if (!on()) return; const i = Math.max(0, Math.min(PENTA.length - 1, Math.round(n) - 1)); tone(hz(PENTA[i] - 5), 0, 0.16, 0.13); },
      ok() { if (!on()) return; [0, 4, 7, 12].forEach((s, k) => tone(hz(s - 2), k * 0.07, 0.42 - k * 0.04, 0.12)); }
    };
  })();
  const toast_ = (m, k) => { try { if (typeof toast === "function") toast(m, k || "i"); else if (window.__FH) __FH.say(m, k); } catch (e) { } };

  const IC = {
    srch: '<svg viewBox="0 0 20 20" width="19" height="19" fill="none" stroke="#333" stroke-width="1.8"><circle cx="8.5" cy="8.5" r="6"/><path d="M13 13l5 5"/></svg>',
    srchS: '<svg viewBox="0 0 16 16" width="11" height="11" fill="none" stroke="#666" stroke-width="1.6"><circle cx="6.5" cy="6.5" r="4.5"/><path d="M10 10l4 4"/></svg>',
    tree: '<svg viewBox="0 0 20 20" width="17" height="17" fill="none" stroke="#fff" stroke-width="1.7"><path d="M6 3v13M6 7h5M6 12h5"/><rect x="11.5" y="5" width="4" height="4" rx=".6" fill="#fff" stroke="none"/><rect x="11.5" y="10" width="4" height="4" rx=".6" fill="#fff" stroke="none"/><rect x="4" y="2" width="4" height="3" rx=".6" fill="#fff" stroke="none"/></svg>',
    menu: '<svg viewBox="0 0 20 20" width="17" height="17" fill="none" stroke="#fff" stroke-width="2"><path d="M4 5h12M4 10h12M4 15h12"/></svg>',
    fold: '<svg viewBox="0 0 24 20" width="22" height="18"><path d="M1 4.5C1 3.1 2.1 2 3.5 2h5.2l2.2 2.4h9.6c1.4 0 2.5 1.1 2.5 2.5v9.6c0 1.4-1.1 2.5-2.5 2.5h-17C2.1 19 1 17.9 1 16.5z" fill="#f2c318"/><path d="M1 7.5h22v9c0 1.4-1.1 2.5-2.5 2.5h-17C2.1 19 1 17.9 1 16.5z" fill="#f7d33a"/></svg>',
    info: '<svg viewBox="0 0 20 20" width="18" height="18"><rect x="1" y="1" width="18" height="18" rx="3" fill="#1f73d1"/><path d="M6 14V10M10 14V6M14 14V8.5" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>',
    back: '<svg viewBox="0 0 24 24" width="26" height="26"><circle cx="12" cy="12" r="10.5" fill="#fff" stroke="#1f73d1" stroke-width="1.6"/><path d="M7 12h10M13 8l4 4-4 4" stroke="#1f73d1" stroke-width="1.9" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    m: {
      starts: '<svg viewBox="0 0 18 18" width="17" height="17"><rect x="2" y="2" width="11" height="13" rx="1.5" fill="#fff" stroke="#555"/><path d="M4.5 6h6M4.5 9h6M4.5 12h3" stroke="#555"/><path d="M10 16l6-6v6z" fill="#2e9b48"/></svg>',
      contains: '<svg viewBox="0 0 18 18" width="17" height="17"><circle cx="5" cy="5" r="2.2" fill="#f0821f"/><circle cx="13" cy="5" r="2.2" fill="#2f7ed8"/><circle cx="9" cy="9.5" r="2.2" fill="#e04a6a"/><circle cx="5" cy="14" r="2.2" fill="#2f7ed8"/><circle cx="13" cy="14" r="2.2" fill="#f0821f"/></svg>',
      ends: '<svg viewBox="0 0 18 18" width="17" height="17"><path d="M2 16L10 3l2 3-6 10z" fill="#f0821f"/><path d="M8 16l6-9 2 3-4 6z" fill="#2e9b48"/></svg>'
    }
  };
  const MODES = [["starts", "يبدأ بـ"], ["contains", "يحتوى"], ["ends", "ينتهى بـ"]];
  /* الأعمدة (مطابقة قائمة Customization في DEXEF) */
  const unitOf = p => p._d || (p._u || []).find(u => u.def) || (p._u || [])[0] || null;
  /* سعر الوحدة الصغرى (أزرق) + سعر الوحدة الكبرى (برتقالي) — لبطاقات «الأصناف بالصور» */
  function unitPair(p) {
    const us = (p._u || []).filter(u => u && u.name);
    const fc = u => +u.factor || 1;
    const small = us.find(u => fc(u) === 1) || us.slice().sort((a, b) => fc(a) - fc(b))[0] || null;
    const bigs = us.filter(u => u !== small && fc(u) > (small ? fc(small) : 1));
    const big = bigs.sort((a, b) => fc(b) - fc(a))[0] || null;
    return { small, big };
  }
  function priceHTML(p) {
    const { small, big } = unitPair(p);
    const sp = small && +small.price ? +small.price : +p.price || 0, sn = small ? small.name : (p.unit || "");
    let h = `<span class="pz"><span class="p1" title="سعر ${esc(sn || "الوحدة الصغرى")}"><b>${F(sp)}</b>${sn ? `<small>${esc(sn)}</small>` : ""}</span>`;
    if (big) h += `<span class="p2" title="سعر ${esc(big.name)} (${F(+big.factor || 1)} ${esc(sn || "")})"><b>${F(+big.price || 0)}</b><small>${esc(big.name)}</small></span>`;
    return h + "</span>";
  }
  const XV = (p, k) => { try { const x = p.x || {}; return x[k] != null ? x[k] : ""; } catch (e) { return ""; } };
  const COLS = {
    code: { t: "الكود", w: "150px", v: p => p.code || "" },
    name: { t: "الاسم", w: "minmax(220px,1fr)", v: p => p.name || "" },
    price: { t: "السعر", w: "110px", v: p => F(p.price), n: 1 },
    stock: { t: "الرصيد", w: "100px", v: (p, o) => { const q = +o.stock(p) || 0; return q < 0 ? "[" + F(-q) + "]" : F(q); }, n: 1 },   /* الرصيد السالب بين قوسين (مثل DEXEF) */
    opts: { t: "اخيارات", w: "100px", v: p => XV(p, "opts") },
    retail: { t: "التجزئة", w: "90px", v: p => F(p.retail || p.price), n: 1 },
    whole: { t: "الجملة", w: "90px", v: p => F(p.whole || p.price), n: 1 },
    tax: { t: "الضريبة", w: "80px", v: p => p.tax ? F(p.tax) + "%" : "0", n: 1 },
    cur: { t: "العملة", w: "70px", v: () => "DZD" },
    grp: { t: "المجموعة", w: "140px", v: p => p.cat || "" },
    unit: { t: "الوحدة", w: "100px", v: p => { const u = unitOf(p); return u ? u.name : (p.unit || ""); } },
    desc: { t: "الوصف", w: "160px", v: p => p.desc || XV(p, "desc") },
    sdisc: { t: "خصم البيع", w: "80px", v: p => F(p.sdisc || 0), n: 1 },
    pdisc: { t: "خصم الشراء", w: "80px", v: p => F(p.pdisc || 0), n: 1 },
    q5: { t: "سعر 5ومافوق", w: "95px", v: p => F(p.q5 || p.price), n: 1 },
    survey: { t: "سعر استطلاع", w: "95px", v: p => F(p.survey || p.price), n: 1 },
    cost: { t: "سعر الشراء", w: "95px", v: p => F(p.cost), n: 1 },
    passer: { t: "عابر سبيل", w: "90px", v: p => F(p.passer || p.price), n: 1 },
    factor: { t: "عدد القطع", w: "80px", v: p => { const u = unitOf(p); return F(u ? u.factor || 1 : 1); }, n: 1 },
    labor: { t: "مصنعية الوحدة", w: "95px", v: p => F(XV(p, "labor") || 0), n: 1 },
    loc0: { t: "مكان التخزين", w: "100px", v: p => XV(p, "loc0") },
    loc1: { t: "مكان التخزين 1", w: "100px", v: p => XV(p, "loc1") },
    loc2: { t: "مكان التخزين 2", w: "100px", v: p => XV(p, "loc2") }
  };
  const DEF_COLS = ["code", "name", "price", "stock"];

  /* شجرة المجموعات: الفهرس ← المجموعات (igrp) + مجموعات الأصناف غير المعرّفة */
  function groupTree() {
    const DB = window.FH_DB || (window.__FH && __FH.DB);
    const p = DB ? DB.list("igrp").catch(() => []) : Promise.resolve([]);
    return p.then(l => {
      const hidden = new Set((l || []).filter(x => x.active === false).map(x => String(x.name || "").trim()));   // مجموعات غير نشطة (الحالة بدون ✓)
      const nodes = (l || []).filter(x => x.active !== false).map(x => { const d = x.data || {}; return { id: "g" + x.id, gid: x.id, name: String(x.name || "").trim(), pid: x.parentId ? "g" + x.parentId : null, kids: [], img: d.img || x.img || "", hideTouch: !!d.hideTouch, ord: +d.order || 0 }; });
      const byName = {}; nodes.forEach(n => { byName[n.name] = n; });
      PRODS().forEach(pr => { const c = String(pr.cat || "").trim(); if (c && c !== "عام" && !byName[c] && !hidden.has(c)) { const n = { id: "c:" + c, name: c, pid: null, kids: [] }; nodes.push(n); byName[c] = n; } });
      const byId = {}; nodes.forEach(n => { byId[n.id] = n; });
      const roots = [];
      nodes.forEach(n => { const par = n.pid && byId[n.pid]; if (par && par !== n) { par.kids.push(n); n.par = par; } else roots.push(n); });
      const cmp = (a, b) => a.name.localeCompare(b.name, "ar");
      const sortR = arr => { arr.sort(cmp); arr.forEach(n => sortR(n.kids)); };
      sortR(roots);
      return { roots, byName, byId, hidden };
    });
  }

  let CUR = null;
  function open(o) {
    if (CUR) { CUR.focus(); return CUR; }
    o = Object.assign({ stock: p => +p.stock || 0, onPick: null, q: "" }, o || {});
    const st = { mode: LS.get("isrch.mode", "contains"), grp: null, cols: (LS.get("isrch.cols", DEF_COLS) || DEF_COLS).filter(k => COLS[k]), tree: LS.get("isrch.tree", true), hz: LS.get("isrch.hz", false), sel: new Set(), hi: 0, list: [], open: new Set(LS.get("isrch.open", [])), info: null, rq: new Map() };
    if (!st.cols.includes("name")) st.cols.splice(1, 0, "name");
    const ov = document.createElement("div"); ov.className = "isr-ov";
    ov.innerHTML = `<div class="isr" role="dialog" aria-modal="true">
      <div class="isr-x"><button type="button" class="x" title="إغلاق (Esc)">✕</button></div>
      <div class="isr-tb">
        <div class="isr-q"><input class="qi" placeholder="ادخل الكود ، اسم الصنف ، الوصف" autocomplete="off" spellcheck="false"><span class="k">F1</span><span class="ic">${IC.srch}</span></div>
        <div class="isr-md"><button type="button" class="mb" title="طريقة البحث (F2)"></button><div class="ml" hidden>${MODES.map(m => `<button type="button" data-m="${m[0]}">${IC.m[m[0]]}<span>${m[1]}</span></button>`).join("")}</div></div>
        <span class="sp"></span>
        <button type="button" class="isr-bt cz" title="تخصيص الأعمدة">${IC.menu}</button>
        <button type="button" class="isr-bt tg" title="إظهار / إخفاء المجموعات">${IC.tree}</button>
      </div>
      <div class="isr-b">
        <div class="isr-g"><div class="gh"></div><div class="gb" tabindex="-1"></div><div class="gcz" hidden><div class="h"><b>Customization</b><button type="button" class="cx">✕</button></div><div class="s"><input placeholder="Search for a column..." dir="ltr"><span>${IC.srchS}</span></div><div class="l"></div></div><div class="ginfo"></div></div>
        <div class="isr-sp" title="إظهار / إخفاء المجموعات"><i>‹</i></div>
        <div class="isr-t"><div class="ts"><input placeholder="Enter text to search..." dir="ltr"><span>${IC.srchS}</span></div><div class="tl"></div></div>
      </div>
      <div class="isr-f"><button type="button" class="ok">موافق</button><button type="button" class="cl">إغلاق</button><label class="hz"><input type="checkbox"> إخفاء الأصناف بدون رصيد</label><span class="sp"></span><span class="isr-sum" hidden></span>
        <div class="isr-qty" title="الكمية الافتراضية للأصناف التي لم تُحدَّد كميتها"><span class="cu">DZD</span><i>⌄</i><input class="qv" value="1" inputmode="decimal"><span class="spn"><b data-s="1">▲</b><b data-s="-1">▼</b></span></div></div>
    </div>`;
    document.body.appendChild(ov);
    const D = ov.querySelector(".isr"), $ = s => D.querySelector(s);
    const qi = $(".qi"), gh = $(".gh"), gb = $(".gb"), tl = $(".tl"), ti = $(".ts input"), cz = $(".gcz"), ginfo = $(".ginfo");
    let TREE = { roots: [], byName: {}, byId: {} };
    requestAnimationFrame(() => ov.classList.add("in"));

    /* ---------- طريقة البحث ---------- */
    const paintMode = () => { const m = MODES.find(x => x[0] === st.mode) || MODES[1]; $(".mb").innerHTML = `${IC.m[m[0]]}<span class="t">${m[1]}</span><span class="k">F2</span><i class="dd">⌄</i>`; $(".ml").querySelectorAll("[data-m]").forEach(b => b.classList.toggle("on", b.dataset.m === st.mode)); };
    paintMode();
    const modeMenu = show => { const ml = $(".ml"); ml.hidden = show == null ? !ml.hidden : !show; };
    $(".mb").addEventListener("click", e => { e.stopPropagation(); modeMenu(); });
    $(".ml").addEventListener("click", e => { const b = e.target.closest("[data-m]"); if (!b) return; st.mode = b.dataset.m; LS.set("isrch.mode", st.mode); paintMode(); modeMenu(false); draw(); qi.focus(); });

    /* ---------- المجموعات ---------- */
    const inGroup = (p, node) => { if (!node) return true; const c = String(p.cat || "").trim(); if (!c) return false; const names = new Set(); (function walk(n) { names.add(n.name); n.kids.forEach(walk); })(node); return names.has(c); };
    function drawTree() {
      const q = norm(ti.value), rows = [];
      const vis = n => !q || norm(n.name).includes(q) || n.kids.some(vis);
      (function walk(arr, lv) { arr.forEach(n => { if (!vis(n)) return; const op = q ? true : st.open.has(n.id); rows.push({ n, lv, op }); if (n.kids.length && op) walk(n.kids, lv + 1); }); })(TREE.roots, 0);
      tl.innerHTML = rows.map(({ n, lv, op }) => `<div class="tn${st.grp === n.id ? " on" : ""}" data-id="${esc(n.id)}" style="padding-right:${4 + lv * 18}px">${n.kids.length ? `<b class="ex${op ? " op" : ""}" data-ex="${esc(n.id)}">⌄</b>` : '<b class="ex nx"></b>'}<span class="ifd">${IC.fold}</span><span class="nm" title="${esc(n.name)}">${esc(n.name)}</span></div>`).join("") || '<div class="te">لا توجد مجموعات</div>';
    }
    tl.addEventListener("click", e => {
      const ex = e.target.closest("[data-ex]"); if (ex) { const id = ex.dataset.ex; if (st.open.has(id)) st.open.delete(id); else st.open.add(id); LS.set("isrch.open", [...st.open]); drawTree(); return; }
      const n = e.target.closest(".tn"); if (!n) return; const id = n.dataset.id;
      st.grp = st.grp === id ? null : id; st.hi = 0; hideInfo(); drawTree(); draw();
    });
    tl.addEventListener("dblclick", e => { const n = e.target.closest(".tn"); if (!n) return; const id = n.dataset.id, node = TREE.byId[id]; if (node && node.kids.length) { if (st.open.has(id)) st.open.delete(id); else st.open.add(id); LS.set("isrch.open", [...st.open]); drawTree(); } });
    ti.addEventListener("input", drawTree);
    const setTree = v => { st.tree = v; LS.set("isrch.tree", v); D.classList.toggle("notree", !v); $(".tg").classList.toggle("on", !v); };
    $(".tg").addEventListener("click", () => setTree(!st.tree));
    $(".isr-sp").addEventListener("click", () => setTree(!st.tree));
    setTree(st.tree);

    /* ---------- الجدول ---------- */
    /* لمسة: لكل صنف وحدته (قطعة ↔ وحدة كبرى) وكميته (− / +) داخل الجدول — يُحدَّد الصنف تلقائياً عند التغيير */
    const unitsOfP = p => { const us = (p._u || []).filter(u => u && u.name); return us.length ? us.slice().sort((a, b) => (+a.factor || 1) - (+b.factor || 1)) : [{ name: p.unit || "قطعة", factor: 1, price: +p.price || 0 }]; };
    const defU = p => { const us = unitsOfP(p), d = o.defUnit ? o.defUnit(p) : unitOf(p); return (d && us.find(u => u.name === d.name)) || us[0]; };
    const rq = p => st.rq.get(p.id) || { u: defU(p).name, q: null };
    const curU = p => { const n = rq(p).u; return unitsOfP(p).find(u => u.name === n) || defU(p); };
    const curQ = p => { const r = rq(p); return r.q != null ? r.q : qty(); };
    const uPrice = (p, u) => o.priceOf ? +o.priceOf(p, u) || 0 : (+u.price || (+p.price || 0) * (+u.factor || 1));
    const r3 = v => Math.round(v * 1000) / 1000;
    function unitHTML(p) {
      const us = unitsOfP(p), cu = curU(p);
      if (us.length < 2) return `<span class="un1">${esc(cu.name)}</span>`;
      if (us.length > 3) return `<button type="button" class="ucy" data-ucy="1" title="تبديل الوحدة (F4)"><b>${esc(cu.name)}</b>${(+cu.factor || 1) > 1 ? `<i>×${F(cu.factor)}</i>` : ""}<em>⇆</em></button>`;
      return `<span class="useg" role="radiogroup">${us.map(u => `<button type="button" data-un="${esc(u.name)}" class="${u.name === cu.name ? "on" : ""}" title="${esc(u.name)}${(+u.factor || 1) > 1 ? " = " + F(u.factor) + " " + esc(us[0].name) : ""} — ${F(uPrice(p, u))}"><span class="ut">${esc(u.name)}</span>${(+u.factor || 1) > 1 ? `<i>×${F(u.factor)}</i>` : ""}</button>`).join("")}</span>`;
    }
    const qtyHTML = p => `<span class="qst${rq(p).q != null ? " set" : ""}"><button type="button" data-qs="1" tabindex="-1" aria-label="زيادة" title="زيادة (+)">+</button><input data-qv value="${F(curQ(p))}" inputmode="decimal" aria-label="الكمية"><button type="button" data-qs="-1" tabindex="-1" aria-label="إنقاص" title="إنقاص (−)">−</button></span>`;
    function setRq(i, ch, keepFocus) {
      const p = st.list[i]; if (!p) return;
      const q0 = curQ(p), r = Object.assign({}, rq(p), ch); if (r.q != null) r.q = Math.max(0.001, r3(r.q));
      st.rq.set(p.id, r);
      const dq = ch.q != null ? r3(r.q - q0) : 0;
      if (dq) { try { dq > 0 ? SND.up(r.q) : SND.down(r.q); } catch (e) { } }
      if (!st.sel.has(p.id)) toggle(i);
      const row = gb.querySelector(`.r[data-i="${i}"]`);
      if (row) {
        row.querySelector(".c.uu").innerHTML = unitHTML(p);
        const qs = row.querySelector(".c.qq"); if (!keepFocus) qs.innerHTML = qtyHTML(p); else qs.querySelector(".qst").classList.add("set");
        const pc = row.querySelector(".c[data-pc]"); if (pc) pc.textContent = F(uPrice(p, curU(p)));
        row.classList.remove("bump"); void row.offsetWidth; row.classList.add("bump");
        if (dq) { const qst = qs.querySelector(".qst"); qst.classList.remove("pop", "up", "dn"); void qst.offsetWidth; qst.classList.add("pop", dq > 0 ? "up" : "dn");
          const c = document.createElement("i"); c.className = "qfx " + (dq > 0 ? "up" : "dn"); c.textContent = (dq > 0 ? "+" : "−") + F(Math.abs(dq)); qs.appendChild(c); setTimeout(() => c.remove(), 700); }
      }
      paintSum();
    }
    function paintSum() {
      const box = $(".isr-sum"); if (!box) return;
      const ps = PRODS().filter(p => st.sel.has(p.id));
      if (!ps.length) { box.innerHTML = ""; box.hidden = true; return; }
      let n = 0, t = 0; ps.forEach(p => { const q = curQ(p), u = curU(p); n += q; t += q * uPrice(p, u); });
      box.hidden = false;
      box.innerHTML = `<b>${ps.length}</b> صنف · <b>${F(n)}</b> وحدة · الإجمالي <b class="t">${F(t)}</b>`;
    }
    /* الأعمدة تتقاسم العرض بالنسبة (بدون شريط أفقي) + عمودا الوحدة والكمية */
    const fitW = w => { let m = /^minmax\((\d+)px,\s*1fr\)$/.exec(w); if (m) return `minmax(${Math.round(+m[1] * .6)}px,${+m[1] + 80}fr)`; m = /^(\d+)px$/.exec(w); if (m) return `minmax(${Math.max(46, Math.round(+m[1] * .5))}px,${m[1]}fr)`; return w; };
    const tpl = () => "34px " + st.cols.map(k => fitW(COLS[k].w)).join(" ") + " minmax(178px,230fr) 106px 42px";
    function match(p, s) {
      if (!s) return true;
      const f = [p.name, p.code, p.barcode, p.desc].map(norm);
      if (st.mode === "starts") return f.some(x => x.startsWith(s)) || f[0].split(/\s+/).some(w => w.startsWith(s));
      if (st.mode === "ends") return f.some(x => x.endsWith(s));
      return f.some(x => x.includes(s));
    }
    function draw() {
      const s = norm(qi.value), node = st.grp ? TREE.byId[st.grp] : null;
      /* مثل DEXEF: الجدول فارغ حتى تكتب في البحث أو تختار مجموعة */
      st.list = (!s && !node) ? [] : PRODS().filter(p => inGroup(p, node) && match(p, s) && (!st.hz || o.stock(p) > 0)).slice(0, 600);
      if (st.hi >= st.list.length) st.hi = Math.max(0, st.list.length - 1);
      const T = tpl(), all = st.list.length && st.list.every(p => st.sel.has(p.id));
      gh.style.gridTemplateColumns = T;
      gh.innerHTML = `<div class="c ck"><span class="cb${all ? " on" : ""}" data-all="1"></span></div>${st.cols.map(k => `<div class="c" draggable="true" data-col="${k}" title="اسحب العمود إلى «Customization» لإخفائه">${esc(COLS[k].t)}</div>`).join("")}<div class="c uh" title="تبديل الوحدة: قطعة ↔ وحدة كبرى (F4)">الوحدة</div><div class="c qh" title="الكمية: + / − (أو أزرار + و − في لوحة الأرقام)">الكمية</div><div class="c f3" title="أرصدة المخازن (F3)">F3</div>`;
      gb.innerHTML = st.list.map((p, i) => `<div class="r${i === st.hi ? " hi" : ""}${st.sel.has(p.id) ? " on" : ""}${(+o.stock(p) || 0) < 0 ? " sneg" : ""}" data-i="${i}" style="grid-template-columns:${T}"><div class="c ck"><span class="cb${st.sel.has(p.id) ? " on" : ""}"></span></div>${st.cols.map(k => k === "price" ? `<div class="c n" data-pc="1">${F(uPrice(p, curU(p)))}</div>` : `<div class="c${COLS[k].n ? " n" : ""}${k === "name" ? " nm" : ""}">${k === "name" && window.ANOUER_NC ? ANOUER_NC.html(COLS[k].v(p, o)) : esc(COLS[k].v(p, o))}</div>`).join("")}<div class="c uu">${unitHTML(p)}</div><div class="c qq">${qtyHTML(p)}</div><div class="c f3"><button type="button" class="ib" data-info="${i}" title="أرصدة المخازن (F3)">${IC.info}</button></div></div>`).join("")
        || `<div class="ge">${!s && !node ? "اكتب الكود أو اسم الصنف أو اختر مجموعة من الشجرة" : "لا توجد أصناف مطابقة"}</div>`;
      paintOk();
    }
    const paintOk = () => { const n = st.sel.size; $(".ok").title = n ? "إضافة " + n + " صنف محدد" : "إضافة الصنف المحدد"; };
    const hiTo = i => { if (!st.list.length) return; st.hi = Math.max(0, Math.min(st.list.length - 1, i)); gb.querySelectorAll(".r").forEach((r, j) => r.classList.toggle("hi", j === st.hi)); const r = gb.querySelector(".r.hi"); if (r) r.scrollIntoView({ block: "nearest" }); };
    const toggle = i => { const p = st.list[i]; if (!p) return; if (st.sel.has(p.id)) st.sel.delete(p.id); else st.sel.add(p.id); const r = gb.querySelector(`.r[data-i="${i}"]`); if (r) { r.classList.toggle("on", st.sel.has(p.id)); r.querySelector(".cb").classList.toggle("on", st.sel.has(p.id)); } const all = st.list.length && st.list.every(x => st.sel.has(x.id)); const h = gh.querySelector("[data-all]"); if (h) h.classList.toggle("on", !!all); paintOk(); paintSum(); };
    gh.addEventListener("click", e => { if (!e.target.closest("[data-all]")) return; const all = st.list.length && st.list.every(p => st.sel.has(p.id)); st.list.forEach(p => { if (all) st.sel.delete(p.id); else st.sel.add(p.id); }); draw(); });
    gb.addEventListener("click", e => {
      const rr = e.target.closest(".r"), ri = rr ? +rr.dataset.i : -1;
      const un = e.target.closest("[data-un]"); if (un) { hiTo(ri); setRq(ri, { u: un.dataset.un }); return; }
      if (e.target.closest("[data-ucy]")) { hiTo(ri); cycleUnit(ri); return; }
      const qs = e.target.closest("[data-qs]"); if (qs) { hiTo(ri); const p = st.list[ri]; setRq(ri, { q: Math.max(1, r3(curQ(p) + (+qs.dataset.qs))) }); return; }
      if (e.target.closest("[data-qv]")) { hiTo(ri); return; }
      const ib = e.target.closest("[data-info]"); if (ib) { hiTo(+ib.dataset.info); showInfo(st.list[+ib.dataset.info]); return; }
      const r = e.target.closest(".r"); if (!r) return; const i = +r.dataset.i; hiTo(i); toggle(i);
    });
    gb.addEventListener("mousedown", e => { if (e.target.closest("[data-un],[data-ucy],[data-qs]")) { e.preventDefault(); if (document.activeElement === document.body || !D.contains(document.activeElement)) gb.focus({ preventScroll: true }); } });
    gb.addEventListener("input", e => { const t = e.target.closest("[data-qv]"); if (!t) return; const i = +t.closest(".r").dataset.i, v = parseFloat(String(t.value).replace(",", ".")); if (v > 0) setRq(i, { q: v }, true); });
    gb.addEventListener("focusin", e => { const t = e.target.closest("[data-qv]"); if (t) { hiTo(+t.closest(".r").dataset.i); t.select(); } });
    gb.addEventListener("focusout", e => { const t = e.target.closest("[data-qv]"); if (!t) return; const p = st.list[+t.closest(".r").dataset.i]; if (p) t.value = F(curQ(p)); });
    function cycleUnit(i, dir) { const p = st.list[i]; if (!p) return; const us = unitsOfP(p); if (us.length < 2) { toast_("«" + p.name + "» له وحدة واحدة فقط", "i"); return; } const k = us.findIndex(u => u.name === curU(p).name); setRq(i, { u: us[(k + (dir || 1) + us.length) % us.length].name }); }
    gb.addEventListener("dblclick", e => { const r = e.target.closest(".r"); if (!r || e.target.closest("[data-info],.uu,.qq")) return; const p = st.list[+r.dataset.i]; if (p) pick([p]); });

    /* ---------- تخصيص الأعمدة (Customization) ---------- */
    function drawCz() {
      const q = norm(cz.querySelector(".s input").value);
      const hid = Object.keys(COLS).filter(k => !st.cols.includes(k) && (!q || norm(COLS[k].t).includes(q))).sort((a, b) => COLS[a].t.localeCompare(COLS[b].t, "ar"));
      cz.querySelector(".l").innerHTML = hid.map(k => `<button type="button" class="it" data-add="${k}" draggable="true" title="اضغط أو اسحب لإضافة العمود">${esc(COLS[k].t)}</button>`).join("") || '<div class="e">كل الأعمدة ظاهرة</div>';
    }
    const saveCols = () => { LS.set("isrch.cols", st.cols); draw(); drawCz(); };
    $(".cz").addEventListener("click", () => { cz.hidden = !cz.hidden; $(".cz").classList.toggle("on", !cz.hidden); if (!cz.hidden) { drawCz(); cz.querySelector(".s input").focus(); } });
    cz.querySelector(".cx").addEventListener("click", () => { cz.hidden = true; $(".cz").classList.remove("on"); });
    cz.querySelector(".s input").addEventListener("input", drawCz);
    cz.querySelector(".l").addEventListener("click", e => { const b = e.target.closest("[data-add]"); if (!b) return; st.cols.push(b.dataset.add); saveCols(); });
    let DRAG = null;
    gh.addEventListener("dragstart", e => { const c = e.target.closest("[data-col]"); if (!c) return; DRAG = { col: c.dataset.col }; e.dataTransfer.effectAllowed = "move"; try { e.dataTransfer.setData("text/plain", c.dataset.col); } catch (x) { } c.classList.add("drag"); });
    cz.querySelector(".l").addEventListener("dragstart", e => { const b = e.target.closest("[data-add]"); if (!b) return; DRAG = { add: b.dataset.add }; try { e.dataTransfer.setData("text/plain", b.dataset.add); } catch (x) { } });
    D.addEventListener("dragend", () => { DRAG = null; gh.querySelectorAll(".drag,.dropL,.dropR").forEach(x => x.classList.remove("drag", "dropL", "dropR")); cz.classList.remove("drop"); });
    cz.addEventListener("dragover", e => { if (DRAG && DRAG.col) { e.preventDefault(); cz.classList.add("drop"); } });
    cz.addEventListener("dragleave", () => cz.classList.remove("drop"));
    cz.addEventListener("drop", e => { e.preventDefault(); cz.classList.remove("drop"); if (!DRAG || !DRAG.col) return; if (DRAG.col === "name") { toast_("لا يمكن إخفاء عمود الاسم", "w"); return; } st.cols = st.cols.filter(k => k !== DRAG.col); saveCols(); });
    gh.addEventListener("dragover", e => { const c = e.target.closest("[data-col]"); if (!DRAG || !c) return; e.preventDefault(); const r = c.getBoundingClientRect(), before = e.clientX > r.left + r.width / 2; gh.querySelectorAll(".dropL,.dropR").forEach(x => x.classList.remove("dropL", "dropR")); c.classList.add(before ? "dropR" : "dropL"); });
    gh.addEventListener("drop", e => {
      const c = e.target.closest("[data-col]"); if (!DRAG || !c) return; e.preventDefault();
      const r = c.getBoundingClientRect(), before = e.clientX > r.left + r.width / 2, k = DRAG.col || DRAG.add;
      st.cols = st.cols.filter(x => x !== k); let at = st.cols.indexOf(c.dataset.col); if (at < 0) at = st.cols.length; else if (!before) at++;
      st.cols.splice(at, 0, k); saveCols();
    });
    gh.addEventListener("contextmenu", e => { const c = e.target.closest("[data-col]"); if (!c) return; e.preventDefault(); if (c.dataset.col === "name") return; st.cols = st.cols.filter(k => k !== c.dataset.col); saveCols(); toast_("تم إخفاء العمود «" + COLS[c.dataset.col].t + "» — أعده من ≡", "i"); });

    /* ---------- أرصدة المخازن (F3) ---------- */
    function showInfo(p) {
      if (!p) return; st.info = p.id;
      const whs = (window.ANOUER_WH && ANOUER_WH.all) ? ANOUER_WH.all(p.id) : [{ name: "المخزن الرئيسي", qty: +p.stock || 0 }];
      const br = ((window.__FH && __FH.BR) || ["الفرع الرئيسي"])[0];
      ginfo.innerHTML = `<div class="ih"><button type="button" class="bk" title="رجوع (F3 / Esc)">${IC.back}</button><b>${esc(p.name)}</b></div><div class="it"><div class="h"><span></span><span>اسم الفرع</span><span>اسم المخزن</span><span>الرصيد</span></div>${whs.map((w, i) => `<div class="r${i === 0 ? " hi" : ""}"><span>${i === 0 ? "←" : ""}</span><span>${esc(w.br || br)}</span><span>${esc(w.name)}</span><span>${F(w.qty)}</span></div>`).join("")}</div>`;
      ginfo.classList.add("show"); requestAnimationFrame(() => requestAnimationFrame(() => ginfo.classList.add("in")));
      ginfo.querySelector(".bk").onclick = hideInfo;
    }
    function hideInfo() { if (st.info == null) return; st.info = null; ginfo.classList.remove("in"); setTimeout(() => { if (st.info == null) ginfo.classList.remove("show"); }, 380); }

    /* ---------- الكمية / الرصيد ---------- */
    const qv = $(".qv");
    const qty = () => Math.max(0.001, parseFloat(String(qv.value).replace(",", ".")) || 1);
    $(".isr-qty").addEventListener("click", e => { const b = e.target.closest("[data-s]"); if (!b) return; qv.value = String(Math.max(1, Math.round((qty() + (+b.dataset.s)) * 1000) / 1000)); });
    qv.addEventListener("keydown", e => { if (e.key === "ArrowUp" || e.key === "ArrowDown") { e.preventDefault(); qv.value = String(Math.max(1, qty() + (e.key === "ArrowUp" ? 1 : -1))); } });
    qv.addEventListener("change", () => { qv.value = String(qty()); });
    const hz = $(".hz input"); hz.checked = st.hz; hz.addEventListener("change", () => { st.hz = hz.checked; LS.set("isrch.hz", st.hz); draw(); });

    /* ---------- الاختيار / الإغلاق ---------- */
    function pick(list) {
      list = (list || []).filter(Boolean); if (!list.length) { toast_("حدد صنفاً أولاً (☐)", "w"); return; }
      const q = qty(), meta = {};
      list.forEach(p => { const u = curU(p), d = defU(p), r = st.rq.get(p.id); meta[p.id] = { unit: u, qty: r && r.q != null ? r.q : q, unitChanged: u.name !== d.name, qtySet: !!(r && r.q != null) }; });
      close();
      try { SND.ok(); } catch (e) { }
      try { if (o.onPick) o.onPick(list, q, meta); } catch (e) { toast_("تعذّرت الإضافة: " + (e.message || e), "e"); }
    }
    const okPick = () => { if (st.sel.size) pick(PRODS().filter(p => st.sel.has(p.id))); else pick([st.list[st.hi]]); };
    $(".isr-qty").addEventListener("input", paintSum); $(".isr-qty").addEventListener("click", () => setTimeout(() => { gb.querySelectorAll(".qst:not(.set) [data-qv]").forEach(x => { const p = st.list[+x.closest(".r").dataset.i]; if (p) x.value = F(curQ(p)); }); paintSum(); }, 0));
    $(".ok").addEventListener("click", okPick);
    $(".cl").addEventListener("click", close);
    $(".isr-x .x").addEventListener("click", close);
    ov.addEventListener("mousedown", e => { if (e.target === ov) { D.animate([{ transform: "scale(1)" }, { transform: "scale(1.008)" }, { transform: "scale(1)" }], { duration: 180 }); } });
    D.addEventListener("click", e => { if (!e.target.closest(".isr-md")) modeMenu(false); });
    function close() { if (!CUR) return; ov.classList.remove("in"); ov.classList.add("out"); document.removeEventListener("keydown", key, true); CUR = null; setTimeout(() => ov.remove(), 160); if (o.onClose) try { o.onClose(); } catch (e) { } }

    /* ---------- المفاتيح ---------- */
    function key(e) {
      const k = e.key;
      if (k === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); if (!$(".ml").hidden) modeMenu(false); else if (st.info != null) hideInfo(); else if (!cz.hidden) { cz.hidden = true; $(".cz").classList.remove("on"); } else close(); return; }
      if (k === "F1") { e.preventDefault(); e.stopImmediatePropagation(); qi.focus(); qi.select(); return; }
      if (k === "F2") { e.preventDefault(); e.stopImmediatePropagation(); modeMenu(); return; }
      if (k === "F3") { e.preventDefault(); e.stopImmediatePropagation(); if (st.info != null) hideInfo(); else showInfo(st.list[st.hi]); return; }
      if (k === "F4") { e.preventDefault(); e.stopImmediatePropagation(); cycleUnit(st.hi, e.shiftKey ? -1 : 1); return; }
      if (/^F\d+$/.test(k)) { e.preventDefault(); e.stopImmediatePropagation(); return; }
      if (st.list[st.hi] && !e.ctrlKey && !e.altKey && (e.code === "NumpadAdd" || e.code === "NumpadSubtract" || ((k === "+" || k === "-") && document.activeElement === gb))) {
        e.preventDefault(); e.stopImmediatePropagation(); const p = st.list[st.hi]; setRq(st.hi, { q: Math.max(1, r3(curQ(p) + (k === "+" || e.code === "NumpadAdd" ? 1 : -1))) }); return;
      }
      if (document.activeElement === gb && (k === "ArrowLeft" || k === "ArrowRight") && st.list[st.hi]) { e.preventDefault(); e.stopImmediatePropagation(); cycleUnit(st.hi, k === "ArrowLeft" ? 1 : -1); return; }
      if (e.target.matches && e.target.matches("[data-qv]")) {
        if (k === "ArrowUp" || k === "ArrowDown") { e.preventDefault(); e.stopImmediatePropagation(); const i = +e.target.closest(".r").dataset.i, p = st.list[i]; setRq(i, { q: Math.max(1, r3(curQ(p) + (k === "ArrowUp" ? 1 : -1))) }, true); e.target.value = F(curQ(p)); return; }
        if (k === "Enter") { e.preventDefault(); e.stopImmediatePropagation(); qi.focus(); return; }
        return;
      }
      const inQ = document.activeElement === qi || document.activeElement === gb;
      if (!$(".ml").hidden && (k === "ArrowDown" || k === "ArrowUp" || k === "Enter")) {
        e.preventDefault(); e.stopImmediatePropagation(); const i = MODES.findIndex(m => m[0] === st.mode);
        if (k === "Enter") { modeMenu(false); draw(); return; } st.mode = MODES[(i + (k === "ArrowDown" ? 1 : MODES.length - 1)) % MODES.length][0]; LS.set("isrch.mode", st.mode); paintMode(); return;
      }
      if (inQ && (k === "ArrowDown" || k === "ArrowUp" || k === "PageDown" || k === "PageUp")) { e.preventDefault(); e.stopImmediatePropagation(); const d = k === "ArrowDown" ? 1 : k === "ArrowUp" ? -1 : k === "PageDown" ? 12 : -12; hiTo(st.hi + d); return; }
      if (inQ && k === " " && (document.activeElement === gb || e.ctrlKey)) { e.preventDefault(); e.stopImmediatePropagation(); toggle(st.hi); return; }
      if (k === "Enter" && (inQ || e.target === D || e.target.closest(".isr-g"))) { e.preventDefault(); e.stopImmediatePropagation(); okPick(); return; }
      if (k === "Enter" && e.target === qv) { e.preventDefault(); e.stopImmediatePropagation(); okPick(); }
    }
    document.addEventListener("keydown", key, true);
    qi.addEventListener("input", () => { st.hi = 0; hideInfo(); draw(); });

    CUR = { close, focus() { qi.focus(); qi.select(); }, el: ov };
    qi.value = o.q || "";
    draw();
    groupTree().then(t => { TREE = t; drawTree(); }).catch(() => drawTree());
    setTimeout(() => { qi.focus(); qi.select(); }, 30);
    return CUR;
  }
  window.ITEM_SEARCH = { open, isOpen: () => !!CUR };

  /* ================================================================ «الأصناف بالصور» (F10) — مطابقة شاشة اللمس في DEXEF ONE
     - يميناً: «الكل» (برتقالي ✓) ثم المجموعات الرئيسية بصورها وعدد أصنافها (ترتيب الظهور / إخفاء من شاشة اللمس من بطاقة المجموعة).
     - الوسط: كل مجموعة مندرجة (Pizza, Cans, Machine…) قسم بعنوانه، وتحته الأصناف كمربعات ملونة بصورها والسعر في الزاوية.
     - الضغط على صنف بوحدة واحدة ← يدخل الفاتورة مباشرة؛ صنف بأكثر من وحدة ← نافذة اختيار الوحدة (صغرى / كبرى) مثل فاتورة اللمس.
     - زر الفأرة الأيمن: الحجم واللون. الضغط المطوّل: ترتيب البطاقات داخل القسم (يُحفظ). شريط التكبير: حجم المربعات. */
  let PIC = null;
  const SIZES = [["s", "صغير"], ["m", "عريض"], ["l", "كبير"], ["xl", "كبير جداً"]];
  const AREA = { s: 1, m: 2, l: 4, xl: 9 };
  const COLORS = ["#1f7ae6", "#1fa13a", "#4b134f", "#8e86f0", "#3f5f8f", "#e8780e", "#7c7f84", "#13898c", "#c9372c", "#d81b60", "#6d4c41", "#2b3a55"];
  const PROPS = () => window.ANOUER_PROPS;
  const layGet = () => { let v = null; try { v = PROPS() && PROPS().get("pics.layout", null); } catch (e) { } return v || LS.get("ipics.layout", { order: {}, size: {}, zoom: 104 }); };
  const laySet = v => { LS.set("ipics.layout", v); try { if (PROPS()) PROPS().put("pics.layout", v); } catch (e) { } };
  const AD = s => String(s);   // أرقام عادية (190) — لا أرقام هندية
  const hashC = id => { let h = 0; String(id).split("").forEach(c => { h = (h * 31 + c.charCodeAt(0)) | 0; }); return COLORS[Math.abs(h) % COLORS.length]; };
  const IC2 = {
    chk: '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5l5 5L20 6.5"/></svg>',
    grp: '<svg viewBox="0 0 40 32" width="40" height="32"><path d="M2 6c0-2.2 1.8-4 4-4h9l4 4h15c2.2 0 4 1.8 4 4v16c0 2.2-1.8 4-4 4H6c-2.2 0-4-1.8-4-4z" fill="#f2c318"/><path d="M2 11h36v15c0 2.2-1.8 4-4 4H6c-2.2 0-4-1.8-4-4z" fill="#f7d33a"/></svg>',
    close: '<svg viewBox="0 0 20 20" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M5 5l10 10M15 5L5 15"/></svg>'
  };
  function pics(o) {
    if (PIC) { PIC.focus(); return PIC; }
    o = Object.assign({ stock: p => +p.stock || 0, onPick: null }, o || {});
    const L0 = layGet(); L0.order = L0.order || {}; L0.size = L0.size || {}; L0.color = L0.color || {}; L0.zoom = L0.zoom && L0.zoom <= 160 ? L0.zoom : 104;
    const st = { root: LS.get("ipics.root", "*"), added: {}, edit: false, lay: L0, all: LS.get("ipics.all2", true), nAdd: 0 };
    const img = p => { try { return window.__pimg ? __pimg(p) : ""; } catch (e) { return ""; } };
    const ov = document.createElement("div"); ov.className = "isr-ov ipx-ov";
    ov.innerHTML = `<div class="isr ipx tx" role="dialog" aria-modal="true">
      <div class="ipx-h"><b class="ttl">الأصناف بالصور</b><span class="cnt"></span><span class="sp"></span>
        <label class="zm" title="حجم المربعات"><span>🔍</span><input type="range" min="78" max="160" step="6"></label>
        <label class="ap" title="إظهار الأصناف التي ليس لها صورة"><input type="checkbox" class="allp"> بدون صور</label>
        <button type="button" class="ed" title="ترتيب البطاقات (أو اضغط مطوّلاً على أي بطاقة)">ترتيب</button>
        <div class="isr-q"><input class="qi" placeholder="ادخل الكود ، اسم الصنف ، الوصف" autocomplete="off"><span class="ic">${IC.srch}</span></div>
        <button type="button" class="x" title="إغلاق (Esc)">✕</button></div>
      <div class="tx-w"><aside class="tx-gl"></aside><div class="tx-m"><div class="tx-secs"></div>
        <button type="button" class="tx-hand l" hidden title="اسحب لعرض المزيد"><span class="ring"></span><span class="tr"><i></i><i></i><i></i></span><svg viewBox="0 0 64 64" class="hd"><defs><linearGradient id="txhg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#dfe9ff"/></linearGradient></defs><path d="M27 30V13.5a4.5 4.5 0 0 1 9 0V28l.2-3.3a4.3 4.3 0 0 1 8.6.4l-.1 4.2a4.2 4.2 0 0 1 8.3.9v3.1a4 4 0 0 1 7.9.8v8.4C61 52.4 54.4 59 46.3 59h-7.5c-5 0-9.6-2.5-12.4-6.7l-9.6-14.5a4.6 4.6 0 0 1 7.2-5.7z" fill="url(#txhg)" stroke="#1f5fd0" stroke-width="2.4" stroke-linejoin="round"/><path d="M36 28v8M44.7 29.3v7M53 34v4" stroke="#1f5fd0" stroke-width="2.2" stroke-linecap="round"/></svg><span class="lb">اسحب</span></button>
        <button type="button" class="tx-hand r" hidden title="رجوع"><span class="ring"></span><span class="tr"><i></i><i></i><i></i></span><svg viewBox="0 0 64 64" class="hd"><path d="M27 30V13.5a4.5 4.5 0 0 1 9 0V28l.2-3.3a4.3 4.3 0 0 1 8.6.4l-.1 4.2a4.2 4.2 0 0 1 8.3.9v3.1a4 4 0 0 1 7.9.8v8.4C61 52.4 54.4 59 46.3 59h-7.5c-5 0-9.6-2.5-12.4-6.7l-9.6-14.5a4.6 4.6 0 0 1 7.2-5.7z" fill="url(#txhg)" stroke="#1f5fd0" stroke-width="2.4" stroke-linejoin="round"/><path d="M36 28v8M44.7 29.3v7M53 34v4" stroke="#1f5fd0" stroke-width="2.2" stroke-linecap="round"/></svg><span class="lb">رجوع</span></button>
        <div class="ipx-done" role="toolbar" aria-label="ترتيب البطاقات"><span>✥ اسحب البطاقة لمكانها الجديد</span><button type="button" class="rs" title="إرجاع ترتيب هذه المجموعات كما كان">↺ الترتيب الأصلي</button><button type="button" class="ok">تم ✓</button></div>
        <div class="tx-unit" hidden><div class="tx-ub"><div class="tx-uh"><span class="im"></span><div><b class="nm"></b><small>اختر الوحدة</small></div><button type="button" class="tx-uclose">${IC2.close}<span>إغلاق</span></button></div><div class="tx-uls"></div></div></div></div></div>
      <div class="isr-f"><span class="ipx-msg"></span><span class="sp"></span><span class="hint">زر الفأرة الأيمن: الحجم واللون — اضغط مطوّلاً على بطاقة ثم اسحبها: الترتيب — اسحب بإصبعك أو بالفأرة: التمرير</span><button type="button" class="cl">إغلاق</button></div></div>`;
    document.body.appendChild(ov);
    const D = ov.querySelector(".ipx"), $ = s => D.querySelector(s), qi = $(".qi"), gl = $(".tx-gl"), secs = $(".tx-secs"), mainEl = $(".tx-m"), uov = $(".tx-unit");
    requestAnimationFrame(() => ov.classList.add("in"));
    let TREE = { roots: [], byId: {}, byName: {} };
    D.addEventListener("change", e => { if (e.target.classList.contains("allp")) { st.all = e.target.checked; LS.set("ipics.all2", st.all); draw(); } });
    const zm = $(".zm input"); zm.value = st.lay.zoom; D.style.setProperty("--c", st.lay.zoom + "px");
    zm.addEventListener("input", () => { st.lay.zoom = +zm.value; D.style.setProperty("--c", zm.value + "px"); layout(); });
    zm.addEventListener("change", () => laySet(st.lay));

    /* ---------- البيانات ---------- */
    const vis = () => PRODS().filter(p => st.all || !!img(p));
    const ordSort = arr => arr.slice().sort((a, b) => ((a.ord || 999) - (b.ord || 999)) || a.name.localeCompare(b.name, "ar"));
    const walk = (n, f) => { f(n); ordSort(n.kids).forEach(k => walk(k, f)); };
    const shown = n => !n.hideTouch;
    function itemsOf(name, P) { return P.filter(p => String(p.cat || "").trim() === name); }
    function subtreeCount(n, P) { let c = 0; walk(n, x => { if (shown(x)) c += itemsOf(x.name, P).length; }); return c; }
    function sections() {
      /* فقط المجموعات وأصنافها: الأصناف بلا مجموعة (أو بمجموعة غير موجودة/مخفية) لا تظهر هنا */
      const P = vis(), q = norm(qi.value), roots = ordSort(TREE.roots).filter(shown);
      const inG = new Set(); roots.forEach(r => walk(r, n => { if (shown(n)) inG.add(n.name); }));
      if (q) return [{ k: "q", name: "نتائج البحث", items: PRODS().filter(p => inG.has(String(p.cat || "").trim()) && [p.name, p.code, p.barcode, p.desc].some(x => norm(x).includes(q))).slice(0, 400) }];
      const out = [], take = n => { if (!shown(n)) return; const it = itemsOf(n.name, P); if (it.length) out.push({ k: n.id, name: n.name, items: it }); };
      if (st.root === "*") roots.forEach(r => walk(r, take));
      else { const r = TREE.byId[st.root]; if (r) walk(r, take); }
      // ترتيب الأصناف داخل كل قسم (حسب الترتيب المحفوظ)
      out.forEach(s => { const ord = st.lay.order[s.k] || [], pos = {}; ord.forEach((k, i) => { pos[k] = i; });
        s.items = s.items.map((p, i) => ({ p, i })).sort((a, b) => (("p:" + a.p.id) in pos ? pos["p:" + a.p.id] : 1e6 + a.i) - (("p:" + b.p.id) in pos ? pos["p:" + b.p.id] : 1e6 + b.i)).map(x => x.p); });
      return out;
    }
    const sizeOf = k => st.lay.size[k] || "s";
    const colorOf = p => st.lay.color["p:" + p.id] || hashC(p.id);
    const units = p => (p._u || []).filter(u => u && u.name);
    function tileHTML(p, j) {
      const k = "p:" + p.id, z = sizeOf(k), im = img(p), q = +o.stock(p) || 0, us = units(p), n = st.added[p.id] || 0;
      const pr = (us.find(u => u.def) || us[0] || {}).price; const price = pr != null ? +pr : +p.price || 0;
      return `<button type="button" class="tx-t z-${z}${q < 0 ? " sneg" : ""}${im ? "" : " noim"}" data-k="${esc(k)}" style="--bg:${colorOf(p)};--d:${Math.min(j, 30) * 18}ms" title="${esc(p.name)} — الرصيد ${q < 0 ? "[" + F(-q) + "]" : F(q)}${us.length > 1 ? " — " + us.length + " وحدات" : ""}">
        <span class="pr"><b>${AD(F(price))}</b><small>دج</small></span>${us.length > 1 ? `<span class="mu" title="${us.length} وحدات">${AD(us.length)}</span>` : ""}
        <span class="im">${im ? `<img src="${esc(im)}" alt="" draggable="false">` : `<i>${esc((String(p.name || "").match(/\p{L}/gu) || ["?"]).slice(0, 2).join(""))}</i>`}</span>
        <span class="nm">${esc(p.name)}</span>${n ? `<span class="bd">${AD(n)}</span>` : ""}</button>`;
    }
    function groupsHTML() {
      const P = vis(), roots = ordSort(TREE.roots).filter(shown).map(r => ({ r, n: subtreeCount(r, P) })).filter(x => x.n);
      const gimg = r => { if (r.img) return r.img; let u = ""; walk(r, x => { if (!u) { const p = itemsOf(x.name, P).find(img); if (p) u = img(p); } }); return u; };
      return `<button type="button" class="tx-g all${st.root === "*" ? " on" : ""}" data-g="*"><span class="ck">${IC2.chk}</span><span class="nm">الكل</span></button>`
        + roots.map((x, i) => { const u = gimg(x.r); return `<button type="button" class="tx-g${st.root === x.r.id ? " on" : ""}" data-g="${esc(x.r.id)}" style="--d:${i * 35}ms"><span class="n">${AD(x.n)}</span><span class="nm">${esc(x.r.name)}</span><span class="im">${u ? `<img src="${esc(u)}" alt="">` : IC2.grp}</span></button>`; }).join("");
    }
    /* ---------- الرسم ---------- */
    function draw() {
      gl.innerHTML = groupsHTML();
      const S = sections();
      secs.innerHTML = S.map((s, si) => `<section class="tx-s" data-s="${esc(s.k)}" style="--d:${si * 50}ms"><h4>${esc(s.name)}</h4><div class="tx-gr">${s.items.map(tileHTML).join("")}</div></section>`).join("")
        || `<div class="ipx-e"><div class="ipx-ei">🖼️</div><b>${qi.value.trim() ? "لا توجد أصناف مطابقة للبحث" : "لا توجد أصناف في هذه المجموعة"}</b>${!st.all ? `<p>الأصناف التي ليس لها صورة مخفية — فعّل «بدون صور» لإظهارها.</p>` : ""}</div>`;
      $(".allp").checked = !!st.all;
      const n = S.reduce((a, s) => a + s.items.length, 0);
      $(".cnt").textContent = AD(n) + " صنف" + (S.length > 1 ? " • " + AD(S.length) + " مجموعة" : "");
      D.classList.toggle("editing", st.edit);
      layout();
      secs.scrollTo({ left: 0 }); requestAnimationFrame(hands);
    }
    /* كل قسم: عدد صفوف ثابت يملأ الارتفاع، والأعمدة حسب عدد المربعات (والأقسام تتتالى أفقياً مثل DEXEF) */
    function layout() {
      const c = st.lay.zoom, gap = 7, h = mainEl.clientHeight - 46;
      const R = Math.max(1, Math.floor((h + gap) / (c + gap)));
      secs.querySelectorAll(".tx-s").forEach(s => {
        const ts = [...s.querySelectorAll(".tx-t")], area = ts.reduce((a, t) => a + AREA[sizeOf(t.dataset.k)], 0);
        const maxW = Math.max(...ts.map(t => ({ s: 1, m: 2, l: 2, xl: 3 })[sizeOf(t.dataset.k)]), 1);
        const C = Math.max(maxW, Math.ceil(area / R), ts.length < R && area === ts.length ? 1 : 2);
        s.querySelector(".tx-gr").style.gridTemplateColumns = `repeat(${C}, var(--c))`;
      });
    }
    const ro = new ResizeObserver(() => { layout(); hands(); }); ro.observe(mainEl);
    /* ---------- بدون أشرطة تمرير: السحب باليد (مع انزلاق بالقصور الذاتي) + يد مضيئة تدل على وجود المزيد ---------- */
    const hL = $(".tx-hand.l"), hR = $(".tx-hand.r");
    function hands() {
      const max = secs.scrollWidth - secs.clientWidth, x = Math.abs(secs.scrollLeft);
      const moreL = max > 4 && x < max - 4, moreR = x > 4;
      hL.hidden = !moreL; hR.hidden = !moreR; secs.classList.toggle("ml", moreL); secs.classList.toggle("mr", moreR);
      const gmax = gl.scrollHeight - gl.clientHeight; gl.classList.toggle("mb", gmax > 4 && gl.scrollTop < gmax - 4); gl.classList.toggle("mt", gl.scrollTop > 4);
    }
    secs.addEventListener("scroll", hands, { passive: true }); gl.addEventListener("scroll", hands, { passive: true });
    hL.addEventListener("click", () => { stopMo(); secs.scrollBy({ left: -secs.clientWidth * .8, behavior: "smooth" }); });
    hR.addEventListener("click", () => { stopMo(); secs.scrollBy({ left: secs.clientWidth * .8, behavior: "smooth" }); });
    let MO = 0; const stopMo = () => { cancelAnimationFrame(MO); MO = 0; };
    function kinetic(el, axis, onPanStart) {
      let P = null;
      const pos = e => axis === "x" ? e.clientX : e.clientY, get = () => axis === "x" ? el.scrollLeft : el.scrollTop, set = v => { if (axis === "x") el.scrollLeft = v; else el.scrollTop = v; };
      el.addEventListener("pointerdown", e => { if ((e.button !== 0 && e.pointerType === "mouse") || st.edit) return; stopMo(); P = { id: e.pointerId, a: pos(e), b: axis === "x" ? e.clientY : e.clientX, s: get(), act: false, h: [] }; });
      el.addEventListener("pointermove", e => {
        if (!P || P.id !== e.pointerId || st.edit || PT.drag) return;
        const d = pos(e) - P.a, o2 = (axis === "x" ? e.clientY : e.clientX) - P.b;
        if (!P.act) { if (Math.abs(d) < 7 || Math.abs(d) < Math.abs(o2)) return; P.act = true; el.classList.add("panning"); try { el.setPointerCapture(e.pointerId); } catch (x) { } if (onPanStart) onPanStart(); }
        e.preventDefault(); set(P.s - d); P.h.push([performance.now(), pos(e)]); if (P.h.length > 6) P.h.shift();
      });
      const up = e => {
        if (!P || P.id !== e.pointerId) return; const w = P; P = null; if (!w.act) return;
        el.classList.remove("panning"); el.__nc = Date.now();
        const h = w.h; if (h.length < 2) return; const [t1, x1] = h[0], [t2, x2] = h[h.length - 1]; let v = (x2 - x1) / Math.max(8, t2 - t1);
        if (performance.now() - t2 > 90) return;
        let last = performance.now();
        const step = now => { const dt = Math.min(40, now - last); last = now; set(get() - v * dt); v *= Math.pow(.94, dt / 16); if (Math.abs(v) > .02) MO = requestAnimationFrame(step); else MO = 0; };
        MO = requestAnimationFrame(step);
      };
      el.addEventListener("pointerup", up); el.addEventListener("pointercancel", up);
    }
    kinetic(secs, "x", () => { PT.moved = true; clearTimeout(PT.timer); });
    kinetic(gl, "y");
    secs.addEventListener("wheel", e => { if (e.ctrlKey || Math.abs(e.deltaX) > Math.abs(e.deltaY)) return; if (secs.scrollWidth <= secs.clientWidth) return; e.preventDefault(); stopMo(); secs.scrollBy({ left: -e.deltaY * 1.2, behavior: "smooth" }); }, { passive: false });
    gl.addEventListener("click", e => { if (gl.__nc && Date.now() - gl.__nc < 250) return; const b = e.target.closest(".tx-g"); if (!b) return; st.root = b.dataset.g; LS.set("ipics.root", st.root); if (qi.value) qi.value = ""; if (st.edit) setEdit(false, true); secs.classList.remove("tx-go"); void secs.offsetWidth; secs.classList.add("tx-go"); draw(); });
    qi.addEventListener("input", () => { if (st.edit) setEdit(false); draw(); });

    /* ---------- الإضافة للفاتورة ---------- */
    function addP(p, u, t) {
      try { if (o.onPick) o.onPick([p], 1, u || null); } catch (er) { toast_("تعذّرت الإضافة: " + (er.message || er), "e"); return; }
      st.added[p.id] = (st.added[p.id] || 0) + 1; st.nAdd++;
      if (t) { t.classList.remove("hit"); void t.offsetWidth; t.classList.add("hit"); let b = t.querySelector(".bd"); if (!b) { b = document.createElement("span"); b.className = "bd"; t.appendChild(b); } b.textContent = AD(st.added[p.id]); b.classList.remove("pop"); void b.offsetWidth; b.classList.add("pop"); }
      $(".ipx-msg").innerHTML = `<b>✓</b> تمت إضافة: ${esc(p.name)}${u ? " — " + esc(u.name) : ""}${st.nAdd > 1 ? `  <em>(${AD(st.nAdd)} إضافة)</em>` : ""}`;
    }
    function activate(t) {
      const p = PRODS().find(x => "p:" + x.id === t.dataset.k); if (!p) return;
      const us = units(p);
      if (us.length > 1) { unitDlg(p, t); return; }
      addP(p, us[0] || null, t);
    }
    /* نافذة الوحدات (مثل فاتورة اللمس): بطاقة لكل وحدة بسعرها وعدد قطعها */
    function unitDlg(p, t) {
      const us = units(p).slice().sort((a, b) => (+a.factor || 1) - (+b.factor || 1)), im = img(p);
      uov.querySelector(".im").innerHTML = im ? `<img src="${esc(im)}" alt="">` : `<i style="background:${colorOf(p)}">${esc((String(p.name || "").match(/\p{L}/gu) || ["?"]).slice(0, 2).join(""))}</i>`;
      uov.querySelector(".nm").textContent = p.name;
      const base = us[0] && us[0].name;
      uov.querySelector(".tx-uls").innerHTML = us.map((u, i) => `<button type="button" class="tx-ut${(+u.factor || 1) > 1 ? " big" : ""}" data-i="${i}" style="--d:${i * 60}ms"><span class="k">${AD(i + 1)}</span><span class="pr">${AD(F(+u.price || 0))}</span><span class="un">${esc(u.name)}</span><span class="fc">${(+u.factor || 1) > 1 ? AD(F(+u.factor)) + " " + esc(base || "") : "الوحدة الصغرى"}</span></button>`).join("");
      uov.hidden = false; uov.__p = p; uov.__u = us; uov.__t = t; uov.classList.remove("in"); void uov.offsetWidth; uov.classList.add("in");
      setTimeout(() => { const b = uov.querySelector(".tx-ut"); if (b) b.focus(); }, 30);
    }
    const unitClose = () => { uov.hidden = true; uov.__p = null; };
    uov.addEventListener("click", e => { const b = e.target.closest(".tx-ut"); if (b) { const p = uov.__p, u = uov.__u[+b.dataset.i], t = uov.__t; b.classList.add("hit"); setTimeout(() => { unitClose(); addP(p, u, t && t.isConnected ? t : null); }, 120); return; } if (e.target.closest(".tx-uclose") || e.target === uov) unitClose(); });

    /* ---------- الحجم واللون: زر الفأرة الأيمن ---------- */
    let MENU = null;
    const menuClose = () => { if (MENU) { MENU.remove(); MENU = null; } };
    function sizeMenu(t, x, y) {
      menuClose(); const k = t.dataset.k, z = sizeOf(k), p = PRODS().find(pp => "p:" + pp.id === k);
      MENU = document.createElement("div"); MENU.className = "ipx-menu";
      MENU.innerHTML = `<div class="h">الحجم</div>${SIZES.map(([v, l]) => `<button type="button" data-z="${v}" class="${v === z ? "on" : ""}"><i class="zi z-${v}"></i>${l}</button>`).join("")}<div class="h">اللون</div><div class="tx-pal">${COLORS.map(c => `<button type="button" data-c="${c}" style="background:${c}" class="${p && colorOf(p) === c ? "on" : ""}"></button>`).join("")}</div><hr><button type="button" data-z="reorder">ترتيب البطاقات</button>`;
      document.body.appendChild(MENU);
      const w = MENU.offsetWidth, h = MENU.offsetHeight; MENU.style.left = Math.max(4, Math.min(x - w, innerWidth - w - 4)) + "px"; MENU.style.top = Math.max(4, Math.min(y, innerHeight - h - 4)) + "px";
      MENU.addEventListener("click", e => {
        const c = e.target.closest("[data-c]"); if (c) { st.lay.color[k] = c.dataset.c; laySet(st.lay); t.style.setProperty("--bg", c.dataset.c); menuClose(); return; }
        const b = e.target.closest("[data-z]"); if (!b) return; const v = b.dataset.z; menuClose();
        if (v === "reorder") { setEdit(true); return; }
        const first = rects(); st.lay.size[k] = v; if (v === "s") delete st.lay.size[k]; laySet(st.lay);
        SIZES.forEach(([s2]) => t.classList.remove("z-" + s2)); t.classList.add("z-" + v); layout(); flip(first);
      });
    }
    secs.addEventListener("contextmenu", e => { const t = e.target.closest(".tx-t"); e.preventDefault(); if (!t || PT.touchLong) { PT.touchLong = false; return; } sizeMenu(t, e.clientX, e.clientY); });
    document.addEventListener("mousedown", e => { if (MENU && !MENU.contains(e.target)) menuClose(); }, true);

    /* ---------- FLIP: حركة انسيابية ---------- */
    const rects = () => { const m = new Map(); secs.querySelectorAll(".tx-t").forEach(el => m.set(el, el.getBoundingClientRect())); return m; };
    function flip(first, skip) {
      secs.querySelectorAll(".tx-t").forEach(el => {
        if (el === skip) return; const a = first.get(el); if (!a) return; const b = el.getBoundingClientRect();
        const dx = a.left - b.left, dy = a.top - b.top, sx = a.width / (b.width || 1), sy = a.height / (b.height || 1);
        if (!dx && !dy && sx === 1 && sy === 1) return;
        el.style.transition = "none"; el.style.transformOrigin = "top right"; el.style.transform = `translate(${dx}px,${dy}px) scale(${sx},${sy})`;
        requestAnimationFrame(() => { el.style.transition = "transform .28s cubic-bezier(.2,.8,.2,1)"; el.style.transform = ""; setTimeout(() => { el.style.transition = ""; el.style.transformOrigin = ""; }, 300); });
      });
    }
    /* ---------- وضع الترتيب (سحب داخل القسم) ---------- */
    function setEdit(on, quiet) {
      st.edit = !!on; D.classList.toggle("editing", st.edit); $(".ed").textContent = st.edit ? "تم" : "ترتيب"; $(".ed").classList.toggle("on", st.edit);
      if (!st.edit && !quiet) saveOrder();
      $(".ipx-msg").textContent = st.edit ? "اسحب البطاقات لترتيبها داخل كل مجموعة، ثم اضغط «تم»" : "";
    }
    D.querySelector(".ipx-done .ok").addEventListener("click", () => setEdit(false));
    D.querySelector(".ipx-done .rs").addEventListener("click", () => {
      const first = rects();
      secs.querySelectorAll(".tx-s").forEach(s => { if (s.dataset.s !== "q") delete st.lay.order[s.dataset.s]; });
      laySet(st.lay); draw(); flip(first); toast_("رجع ترتيب البطاقات كما كان", "i");
    });
    function saveOrder() { secs.querySelectorAll(".tx-s").forEach(s => { if (s.dataset.s !== "q") st.lay.order[s.dataset.s] = [...s.querySelectorAll(".tx-t")].map(el => el.dataset.k); }); laySet(st.lay); }
    $(".ed").addEventListener("click", () => { if (qi.value.trim()) { toast_("امسح البحث أولاً لترتيب البطاقات", "w"); return; } setEdit(!st.edit); });
    const PT = { id: null, t: null, sx: 0, sy: 0, timer: 0, drag: false, ghost: null, dx: 0, dy: 0, touchLong: false, moved: false };
    secs.addEventListener("pointerdown", e => {
      if (e.button !== 0 && e.pointerType === "mouse") return;
      const t = e.target.closest(".tx-t"); if (!t) { if (st.edit && !e.target.closest(".tx-t")) setEdit(false); return; }
      Object.assign(PT, { id: e.pointerId, t, sx: e.clientX, sy: e.clientY, drag: false, moved: false });
      clearTimeout(PT.timer); secs.querySelectorAll(".tx-t.lp").forEach(x => x.classList.remove("lp"));
      if (st.edit) { try { secs.setPointerCapture(e.pointerId); } catch (x) { } }
      if (!st.edit && !qi.value.trim()) { t.classList.add("lp"); PT.timer = setTimeout(() => { t.classList.remove("lp"); if (PT.t === t && !PT.moved) { PT.touchLong = e.pointerType !== "mouse"; setEdit(true); try { navigator.vibrate && navigator.vibrate(18); } catch (x) { } startDrag(PT.lx || e.clientX, PT.ly || e.clientY); } }, 480); }
    });
    function startDrag(x, y) {
      const t = PT.t; if (!t) return; PT.drag = true;
      const r = t.getBoundingClientRect(); PT.dx = x - r.left; PT.dy = y - r.top;
      const g = t.cloneNode(true); g.classList.add("ghost"); g.style.width = r.width + "px"; g.style.height = r.height + "px"; g.style.left = r.left + "px"; g.style.top = r.top + "px";
      document.body.appendChild(g); PT.ghost = g; t.classList.add("ph");
      try { secs.setPointerCapture(PT.id); } catch (er) { }
    }
    secs.addEventListener("pointermove", e => {
      if (PT.id !== e.pointerId || !PT.t) return;
      const mv = Math.hypot(e.clientX - PT.sx, e.clientY - PT.sy); PT.lx = e.clientX; PT.ly = e.clientY;
      if (!PT.drag) { if (mv > 8) { PT.moved = true; clearTimeout(PT.timer); PT.t.classList.remove("lp"); if (st.edit) startDrag(e.clientX, e.clientY); } if (!PT.drag) return; }
      e.preventDefault();
      PT.ghost.style.left = (e.clientX - PT.dx) + "px"; PT.ghost.style.top = (e.clientY - PT.dy) + "px";
      const br = secs.getBoundingClientRect(); if (e.clientX < br.left + 40) secs.scrollLeft -= 14; else if (e.clientX > br.right - 40) secs.scrollLeft += 14;
      const under = document.elementFromPoint(e.clientX, e.clientY), tgt = under && under.closest && under.closest(".tx-t");
      if (!tgt || tgt === PT.t || !secs.contains(tgt) || tgt.classList.contains("ghost") || tgt.parentNode !== PT.t.parentNode) return;
      const r = tgt.getBoundingClientRect(), before = e.clientX > r.left + r.width / 2;
      const ref = before ? tgt : tgt.nextSibling; if (ref === PT.t || PT.t.nextSibling === ref) return;
      const first = rects(); tgt.parentNode.insertBefore(PT.t, ref); flip(first, PT.ghost);
    });
    const endPtr = e => {
      if (PT.id !== e.pointerId) return; clearTimeout(PT.timer); if (PT.t) PT.t.classList.remove("lp");
      const t = PT.t, wasDrag = PT.drag; PT.lx = PT.ly = 0; PT.id = null; PT.t = null; PT.drag = false;
      if (wasDrag) { const g = PT.ghost, r = t.getBoundingClientRect(); PT.ghost = null;
        g.style.transition = "left .2s ease, top .2s ease, transform .2s"; g.style.left = r.left + "px"; g.style.top = r.top + "px"; g.style.transform = "none";
        setTimeout(() => { g.remove(); t.classList.remove("ph"); }, 200); saveOrder(); try { navigator.vibrate && navigator.vibrate(10); } catch (x) { } return; }
      if (e.type === "pointerup" && t && !PT.moved && !st.edit) activate(t);
    };
    secs.addEventListener("pointerup", endPtr); secs.addEventListener("pointercancel", endPtr);
    secs.addEventListener("keydown", e => { const t = e.target.closest(".tx-t"); if (t && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); activate(t); } });

    /* ---------- المفاتيح / الإغلاق ---------- */
    function close() { if (!PIC) return; if (st.edit) setEdit(false); menuClose(); ro.disconnect(); ov.classList.remove("in"); ov.classList.add("out"); document.removeEventListener("keydown", key, true); PIC = null; setTimeout(() => ov.remove(), 160); if (o.onClose) try { o.onClose(); } catch (e) { } }
    function key(e) {
      if (!uov.hidden) {
        if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); unitClose(); return; }
        const n = +String(e.key).replace(/[٠-٩]/, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d)); if (n >= 1 && n <= (uov.__u || []).length) { e.preventDefault(); e.stopImmediatePropagation(); const b = uov.querySelector(`.tx-ut[data-i="${n - 1}"]`); if (b) b.click(); return; }
        if (e.key === "ArrowLeft" || e.key === "ArrowRight") { e.preventDefault(); const bs = [...uov.querySelectorAll(".tx-ut")], i = bs.indexOf(document.activeElement); const j = Math.max(0, Math.min(bs.length - 1, i + (e.key === "ArrowLeft" ? 1 : -1))); if (bs[j]) bs[j].focus(); return; }
      }
      if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); if (MENU) menuClose(); else if (st.edit) setEdit(false); else if (qi.value) { qi.value = ""; draw(); } else close(); return; }
      if (e.key === "F10") { e.preventDefault(); e.stopImmediatePropagation(); close(); return; }
      if (e.key === "F1") { e.preventDefault(); e.stopImmediatePropagation(); qi.focus(); qi.select(); return; }
      if (/^F\d+$/.test(e.key)) { e.preventDefault(); e.stopImmediatePropagation(); return; }
      if ((e.key === "ArrowDown" || e.key === "ArrowUp") && document.activeElement && document.activeElement.closest && document.activeElement.closest(".tx-gl")) { e.preventDefault(); const bs = [...gl.querySelectorAll(".tx-g")], i = bs.indexOf(document.activeElement.closest(".tx-g")); const b = bs[Math.max(0, Math.min(bs.length - 1, i + (e.key === "ArrowDown" ? 1 : -1)))]; if (b) { b.focus(); b.click(); setTimeout(() => { const x = gl.querySelector(`.tx-g[data-g="${CSS.escape(b.dataset.g)}"]`); if (x) x.focus(); }, 0); } return; }
      if (e.key === "Enter" && document.activeElement === qi) { e.preventDefault(); e.stopImmediatePropagation(); const t = secs.querySelector(".tx-t"); if (t) { activate(t); qi.select(); } }
    }
    document.addEventListener("keydown", key, true);
    $(".x").addEventListener("click", close); $(".cl").addEventListener("click", close);
    ov.addEventListener("mousedown", e => { if (e.target === ov) close(); });
    PIC = { close, focus() { qi.focus(); }, el: ov };
    draw();
    groupTree().then(t => { TREE = t; if (st.root !== "*" && !TREE.byId[st.root]) st.root = "*"; draw(); }).catch(() => { });
    setTimeout(() => qi.focus(), 30);
    return PIC;
  }
  window.ITEM_PICS = { open: pics, isOpen: () => !!PIC };
})();
