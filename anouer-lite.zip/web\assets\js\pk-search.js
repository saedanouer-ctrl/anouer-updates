/* ANOUER — بحث احترافي في نافذة «اختيار صنف» (Click here to add a new row) — تحديثات 2026
   • خانة البحث الكبيرة: اسم · كود · باركود · باركود الوحدات (كرتون/علبة…) · رقم الملصق — كلمات بأي ترتيب (bon cece = Cece BON)
   • الباركود المطابق تماماً يطلع الأوّل بعلامة ⚡ + اسم الوحدة ، و Enter يدخّل الصنف بتلك الوحدة مباشرة (يخدم مع قارئ الباركود)
   • فلتر «الكود» يبحث في كل الأكواد والباركودات (ماشي غير الكود الرئيسي) ويُظهر الباركود اللي طابق
   • فلتر السعر / الرصيد: = 200 · > 100 · <= 50 · 100-300 (مجال) · != 0
   • لوحة المفاتيح غالطة؟ (ؤثؤث بدل cece) ← يصحّحها وحده ويقولك
   • خطأ في الكتابة؟ (cocacola ← Coca Cola / حلبب ← حليب) ← «أقرب الأصناف»
   • بلا بحث: آخر الأصناف اللي اخترتها تطلع فوق 🕘
   • عدّاد النتائج ، أكثر من 250 نتيجة ← «عرض الكل» ، PgUp / PgDn ، Ctrl+Home / End ، Esc يمسح البحث أولاً ثم يغلق */
(function () {
  "use strict";
  if (window.__PKX) return; window.__PKX = 1;
  if (typeof pkRender !== "function" || !document.getElementById("pk")) return;
  const $ = id => document.getElementById(id), PK = $("pk");
  PK.setAttribute("data-ipick-off", "");   /* نافذتنا عندها بحثها — النافذة الموحّدة ما تتفتحش فوقها */
  const N = s => norm(String(s == null ? "" : s));
  const CK = v => codeKey(v);
  const LSK = "anouer.pk.recent";
  const lsGet = () => { try { const a = JSON.parse(localStorage.getItem(LSK) || "[]"); return Array.isArray(a) ? a : []; } catch (e) { return []; } };
  const remember = id => { try { const a = lsGet().filter(x => x !== id); a.unshift(id); localStorage.setItem(LSK, JSON.stringify(a.slice(0, 12))); } catch (e) { } };

  /* ------------------------------------------------------------ واجهة */
  (function css() {
    const st = document.createElement("style"); st.id = "pkxCss";
    st.textContent = `
#pk .pk-top{position:relative;gap:8px}
#pk .pk-top input#pkq{flex:1 1 auto;padding-inline-start:26px;background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%231a6fd0' stroke-width='2.4' stroke-linecap='round'%3E%3Ccircle cx='10.5' cy='10.5' r='6.5'/%3E%3Cpath d='m20 20-4.5-4.5'/%3E%3C/svg%3E") no-repeat right 4px center/15px}
#pk .pk-top input#pkq::placeholder{color:#94a3b8;font-size:12px}
.pkx-n{flex:none;min-width:22px;height:20px;padding:0 9px;border-radius:999px;display:inline-flex;align-items:center;gap:4px;background:#eef4fd;color:#1a5fb4;font:700 11px "Segoe UI",Tahoma,sans-serif;white-space:nowrap}
.pkx-n.z{background:#fdeceb;color:#b42318}.pkx-n.bc{background:#fff4e5;color:#b45309}
.pkx-hint{display:none;align-items:center;gap:8px;margin:6px 6px 0;padding:6px 10px;border-radius:9px;background:#fff8e6;border:1px solid #fde3a7;color:#7a4b00;font-size:11.5px;line-height:1.4}
.pkx-hint.on{display:flex}.pkx-hint b{font-weight:800;direction:ltr;unicode-bidi:isolate}
.pkx-hint button{margin-inline-start:auto;border:0;background:transparent;color:#1a6fd0;font:600 11px inherit;cursor:pointer;text-decoration:underline}
.pk-r .pkx-b{display:inline-grid;place-items:center;min-width:16px;height:16px;padding:0 3px;margin-inline-end:5px;border-radius:5px;font-size:10px;font-style:normal;vertical-align:1px}
.pk-r .pkx-b.x{background:linear-gradient(145deg,#fbbf24,#f59e0b);color:#fff}
.pk-r .pkx-b.r{background:#eef2f7;color:#64748b}
.pk-r .pkx-b.f{background:#ede9fe;color:#6d28d9}
.pk-r .pkx-u{display:inline-block;margin-inline-start:5px;padding:0 6px;border-radius:6px;background:#e8f5ec;color:#15803d;font-size:10px;font-weight:700;line-height:15px;vertical-align:1px}
.pk-r.on .pkx-u{background:rgba(255,255,255,.25);color:#fff}.pk-r.on .pkx-b.r{background:rgba(255,255,255,.22);color:#fff}
.pk-r.pkx-ex:not(.on){background:linear-gradient(90deg,#fff7e0,#fff 70%)}
.pk-r mark{background:#ffe59a;color:#000;border-radius:2px;padding:0 1px}
.pk-r.on mark{background:#ffd54a;color:#111}
.pkx-more{display:flex;justify-content:center;padding:8px}.pkx-more button{border:1px dashed #9cc0ee;background:#f5f9ff;color:#1a5fb4;border-radius:8px;padding:4px 14px;font:600 11px inherit;cursor:pointer}
.pkx-sep{padding:3px 10px;font-size:10px;font-weight:700;color:#94a3b8;letter-spacing:.2px;background:#fafbfc;border-top:1px solid #f0f2f5}
#pk .pk-bot{justify-content:space-between;align-items:center;gap:10px}
.pkx-k{font-size:10.5px;color:#94a3b8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pkx-k kbd{font:600 10px Consolas,monospace;padding:0 4px;border:1px solid #dfe3ea;border-bottom-width:2px;border-radius:4px;background:#fff;color:#475569}
#pk .pk-f .pkx-eq{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);font-size:13px;font-weight:700;color:#a3adbd;pointer-events:none}
#pk .pk-f input:focus+.pkx-eq,#pk .pk-f input:not(:placeholder-shown)+.pkx-eq{display:none}
#pk .pk-f input:focus{box-shadow:inset 0 -2px 0 #1a6fd0}
#pk .pk-f input.pkx-on{background:#f0f7ff;font-weight:700;color:#0b4a99}
html.dark .pkx-n{background:rgba(120,170,255,.16);color:#cfe0ff}html.dark .pkx-n.z{background:rgba(255,120,100,.18);color:#ffc2b8}html.dark .pkx-n.bc{background:rgba(251,191,36,.18);color:#ffe2a1}
html.dark .pkx-hint{background:rgba(251,191,36,.1);border-color:rgba(251,191,36,.3);color:#ffe7b0}
html.dark .pk-r.pkx-ex:not(.on){background:linear-gradient(100deg,rgba(251,191,36,.16),rgba(214,226,255,.04) 70%)!important}
html.dark .pk-r .pkx-u{background:rgba(74,222,128,.15);color:#a7f3d0}html.dark .pk-r .pkx-b.r{background:rgba(255,255,255,.1);color:#cbd5e1}
html.dark .pkx-sep{background:transparent;color:#7c8aa5;border-color:rgba(255,255,255,.06)}
html.dark .pkx-more button{background:rgba(120,170,255,.08);border-color:rgba(120,170,255,.35);color:#cfe0ff}
html.dark .pkx-k kbd{background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.15);color:#cbd5e1}
html.dark #pk .pk-f input.pkx-on{background:rgba(120,170,255,.1);color:#e3ecff}`;
    document.head.appendChild(st);
  })();
  const q0 = $("pkq");
  q0.placeholder = "ابحث: الاسم · الكود · الباركود · رقم الملصق";
  const cnt = document.createElement("span"); cnt.className = "pkx-n"; q0.after(cnt);
  const hint = document.createElement("div"); hint.className = "pkx-hint"; PK.querySelector(".pk-top").after(hint);
  const bot = PK.querySelector(".pk-bot");
  if (bot) { const k = document.createElement("span"); k.className = "pkx-k"; k.innerHTML = "<kbd>↑</kbd><kbd>↓</kbd> تنقّل · <kbd>Enter</kbd> إضافة · <kbd>PgUp</kbd><kbd>PgDn</kbd> · <kbd>Esc</kbd> مسح ثم إغلاق"; bot.prepend(k); }
  PK.querySelectorAll(".pk-f input").forEach(i => {
    const t = { name: "كلمات من الاسم بأي ترتيب", code: "الكود / الباركود / باركود الوحدة / رقم الملصق", price: "= 200 · > 100 · <= 50 · 100-300 · != 0", stock: "= 0 · > 10 · < 0 · 1-5" }[i.dataset.f];
    if (t) i.title = t;
    i.setAttribute("data-anytext", "");
    const fe = i.nextElementSibling; if (fe && fe.classList.contains("fe")) fe.className = "pkx-eq";   /* «=» كانت تطير فوق النافذة (تصادم مع ستايل .fe عام) */   /* حارس الأرقام كان يمنع = > < - في فلتر السعر والرصيد */
  });

  /* ------------------------------------------------------------ الفهرس */
  let IDX = null, IDXN = -1, IDXR = null;
  function index() {
    const P = typeof products !== "undefined" && Array.isArray(products) ? products : [];
    if (IDX && IDXR === P && IDXN === P.length) return IDX;
    IDX = []; IDXR = P; IDXN = P.length;
    P.forEach((p, o) => {
      if (!p || p.active === false) return;
      const M = nmap(p.name), codes = [], seen = new Set();
      const add = (v, t, u) => { const k = CK(v); if (!k || seen.has(k)) return; seen.add(k); codes.push({ k, v: String(v).trim(), t, u: u || null }); };
      add(p.code, "code");
      String(p.barcode || "").split(/[\s,;|]+/).forEach(b => add(b, "bc"));
      (p._u || []).forEach(u => { if (!u) return; add(u.bc, "unit", u); (u.xb || []).forEach(b => add(b, "unit", u)); });
      IDX.push({ p, o, M, W: words(M.t), codes });
    });
    return IDX;
  }

  /* ------------------------------------------------------------ أدوات المطابقة */
  const R = (M, a, b) => [M.idx[a], M.idx[b - 1] + 1];
  /* كل كلمة من البحث لازم تلقى بلاصتها في الاسم (بداية كلمة أحسن) — تُرجع الدرجة والتلوين */
  function nameTokens(e, toks) {
    let sc = 0; const rs = [];
    for (const t of toks) {
      const w = e.W.find(x => x.w.startsWith(t));
      if (w) { rs.push(R(e.M, w.a, w.a + t.length)); sc += e.W.indexOf(w) * .01; continue; }
      const i = e.M.t.indexOf(t);
      if (i < 0) return null;
      rs.push(R(e.M, i, i + t.length)); sc += 1;
    }
    return { sc, rs };
  }
  function codeFind(e, k) {
    let best = null;
    for (const c of e.codes) {
      const i = c.k.indexOf(k); if (i < 0) continue;
      const r = c.k === k ? 0 : i === 0 ? 1 : 2;
      if (!best || r < best.r || (r === best.r && c.t === "code" && best.c.t !== "code")) best = { c, r, i, L: k.length };
    }
    return best;
  }
  function numOk(v, x) {
    v = String(v || "").trim().replace(/,/g, "."); if (!v) return true;
    let m = v.match(/^(-?[\d.]+)\s*(?:-|\.\.|–|~)\s*(-?[\d.]+)$/);
    if (m) { const a = +m[1], b = +m[2]; return x >= Math.min(a, b) && x <= Math.max(a, b); }
    m = v.match(/^(>=|<=|!=|<>|>|<|=)?\s*(-?[\d.]+)$/); if (!m) return true;
    const n = +m[2];
    switch (m[1]) { case ">": return x > n; case "<": return x < n; case ">=": return x >= n; case "<=": return x <= n; case "!=": case "<>": return x != n; default: return x == n; }
  }
  /* لوحة المفاتيح: عربية ⇄ لاتينية (مثل ؤثؤث ← cece) */
  const AE = { "ض": "q", "ص": "w", "ث": "e", "ق": "r", "ف": "t", "غ": "y", "ع": "u", "ه": "i", "خ": "o", "ح": "p", "ج": "[", "د": "]", "ش": "a", "س": "s", "ي": "d", "ب": "f", "ل": "g", "ا": "h", "ت": "j", "ن": "k", "م": "l", "ك": ";", "ط": "'", "ئ": "z", "ء": "x", "ؤ": "c", "ر": "v", "ى": "n", "ة": "m", "و": ",", "ز": ".", "ظ": "/", "ذ": "`", "أ": "h", "إ": "h", "آ": "h" };
  const EA = {}; Object.keys(AE).forEach(k => { if (!"أإآ".includes(k) && !EA[AE[k]]) EA[AE[k]] = k; });
  function swapKb(q) {
    const ar = (q.match(/[؀-ۿ]/g) || []).length, la = (q.match(/[a-z]/gi) || []).length;
    if (ar && !la) return q.replace(/لا/g, "b").split("").map(c => AE[c] || c).join("");
    if (la && !ar) return q.toLowerCase().split("").map(c => c === "b" ? "لا" : (EA[c] || c)).join("");
    return null;
  }
  /* أخطاء الكتابة: مسافة تحرير ≤ 1 (≤ 2 للكلمات الطويلة) */
  function lev(a, b, max) {
    if (Math.abs(a.length - b.length) > max) return max + 1;
    let prev = Array.from({ length: b.length + 1 }, (_, j) => j);
    for (let i = 1; i <= a.length; i++) {
      const cur = [i]; let mn = i;
      for (let j = 1; j <= b.length; j++) { cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); if (cur[j] < mn) mn = cur[j]; }
      if (mn > max) return max + 1; prev = cur;
    }
    return prev[b.length];
  }
  function fuzzy(e, toks) {
    let sc = 0; const rs = [];
    const glued = e.M.t.replace(/\s+/g, "");
    for (const t of toks) {
      if (t.length < 3) { const i = e.M.t.indexOf(t); if (i < 0) return null; rs.push(R(e.M, i, i + t.length)); continue; }
      const max = t.length >= 7 ? 2 : 1; let best = null;
      for (const w of e.W) {
        const d = Math.min(lev(t, w.w, max), w.w.length > t.length ? lev(t, w.w.slice(0, t.length), max) : max + 1);
        if (d <= max && (!best || d < best.d)) best = { d, w };
      }
      if (!best) { if (t.length >= 5 && lev(t, glued.slice(0, t.length + 1), max) <= max) { sc += 2; continue; } return null; }
      sc += best.d; rs.push(R(e.M, best.w.a, best.w.b));
    }
    return { sc, rs };
  }

  /* ------------------------------------------------------------ المحرّك */
  function run(q, F, mode) {
    const qn = N(q), toks = qn.split(" ").filter(Boolean), qk = CK(q);
    const fn = N(F.name).split(" ").filter(Boolean), fk = CK(F.code || "");
    const out = [];
    for (const e of index()) {
      const p = e.p;
      if (!numOk(F.price, +p.price || 0)) continue;
      let st; try { st = +SWQ(p) || 0; } catch (x) { st = +p.stock || 0; }
      if (!numOk(F.stock, st)) continue;
      let n = [], c = null, x = null, s = 50;
      if (fn.length) { const m = nameTokens(e, fn); if (!m) continue; n = n.concat(m.rs); }
      if (fk) { const b = codeFind(e, fk); if (!b) continue; c = b; if (b.r === 0) x = b.c; }
      if (toks.length) {
        if (mode === "fuzzy") { const m = fuzzy(e, toks); if (!m) continue; n = n.concat(m.rs); s = 40 + m.sc; }
        else {
          const ex = qk && e.codes.find(cc => cc.k === qk);
          if (ex) { x = ex; c = { c: ex, r: 0, i: 0, L: ex.k.length }; s = 0; }
          else if (e.M.t.startsWith(qn)) { n.push(R(e.M, 0, qn.length)); s = 10; }
          else {
            const cb = qk && qk.length >= 2 ? codeFind(e, qk) : null;
            if (cb && cb.r === 1) { c = c || cb; s = 15; }
            else {
              /* كلمات بأي ترتيب: كل كلمة في الاسم أو في الكود */
              let sc = 0, ok = true;
              for (const t of toks) {
                const m = nameTokens(e, [t]);
                if (m) { n = n.concat(m.rs); sc += m.sc; continue; }
                const b = codeFind(e, CK(t)); if (b) { c = c || b; sc += 1.5; continue; }
                ok = false; break;
              }
              if (!ok) { if (cb) { c = c || cb; s = 35; } else continue; }
              else s = 20 + sc;
            }
          }
        }
      } else if (fk && c) s = c.r * 5;
      out.push({ p, r: { n, c: [] }, o: e.o, s, x, cm: c, st });
    }
    out.sort((a, b) => a.s - b.s || a.o - b.o);
    return out;
  }

  /* ------------------------------------------------------------ العرض */
  let CAP = 250, LAST = { msg: "" };
  function filters() { const F = {}; PK.querySelectorAll(".pk-f input").forEach(i => { F[i.dataset.f] = i.value; i.classList.toggle("pkx-on", !!i.value.trim()); }); return F; }
  function codeCell(it) {
    const p = it.p, m = it.cm, code = String(p.code == null ? "" : p.code);
    if (!m || !m.c) return `<div>${esc(code)}</div>`;
    const v = m.c.v, simple = CK(v) === v.toLowerCase(), rg = simple ? [[m.i, Math.min(v.length, m.i + m.L)]] : [];
    const u = m.c.t === "code" ? "" : `<span class="pkx-u">${esc((m.c.u && m.c.u.name) || "باركود")}</span>`;
    return `<div title="${esc(v)}${m.c.t !== "code" ? " — الكود: " + esc(code) : ""}">${hl(v, rg)}${u}</div>`;
  }
  function row(it, k) {
    const p = it.p, b = it.x ? '<i class="pkx-b x" title="باركود مطابق تماماً — Enter للإضافة">⚡</i>' : it.rc ? '<i class="pkx-b r" title="من آخر الأصناف المختارة">🕘</i>' : it.fz ? '<i class="pkx-b f" title="نتيجة تقريبية">≈</i>' : "";
    return `<div class="pk-cols pk-r${k == pkIdx ? " on" : ""}${it.x ? " pkx-ex" : ""}" data-k="${k}" onmousedown="event.preventDefault()" onclick="pkPick(${k})"><div title="${esc(p.name)}">${b}${hl(p.name, it.r.n)}</div>${codeCell(it)}<div>${fmt(p.price)}</div><div class="${it.st <= 0 ? "neg" : ""}">${fmt(it.st)}</div></div>`;
  }
  function setHint(h) { hint.innerHTML = h || ""; hint.classList.toggle("on", !!h); }

  const RENDER = function () {
    const q = $("pkq").value, F = filters(), any = q.trim() || Object.values(F).some(v => String(v).trim());
    let l, h = "";
    if (!any) {
      const ids = lsGet(), all = run("", F), byId = new Map(all.map(x => [x.p.id, x])), rec = [];
      ids.forEach(id => { const it = byId.get(id); if (it) { it.rc = 1; rec.push(it); byId.delete(id); } });
      l = rec.concat(all.filter(x => byId.has(x.p.id)));
    } else {
      l = run(q, F);
      if (!l.length && q.trim()) {
        const sw = swapKb(q.trim());
        if (sw) { const l2 = run(sw, F); if (l2.length) { l = l2; h = `⌨️ لوحة المفاتيح كانت على لغة أخرى — بحثنا عن <b>${esc(sw)}</b><button type="button" data-pkx="sw">استعمل هذا البحث</button>`; LAST.sw = sw; } }
        if (!l.length) { const l3 = run(q, F, "fuzzy"); if (l3.length) { l3.forEach(x => x.fz = 1); l = l3; h = `≈ ما لقيناش «<b>${esc(q.trim())}</b>» بالضبط — هذه أقرب الأصناف`; } }
      }
    }
    if (pkSort.k) { const k = pkSort.k; l = [...l].sort((a, b) => { const x = k === "stock" ? a.st : a.p[k], y = k === "stock" ? b.st : b.p[k]; return (typeof x == "number" ? x - y : String(x).localeCompare(String(y), "ar")) * pkSort.d; }); }
    pkList = l; if (pkIdx >= l.length) pkIdx = l.length - 1; if (pkIdx < 0 && l.length) pkIdx = 0;
    PK.querySelectorAll(".pk-h div").forEach(d => d.querySelector("i").textContent = d.dataset.s == pkSort.k ? (pkSort.d > 0 ? "▲" : "▼") : d.dataset.s == "name" ? "⇅" : "");
    setHint(h);
    const ex = l.length && l[0].x;
    cnt.className = "pkx-n" + (!l.length && any ? " z" : ex ? " bc" : "");
    cnt.textContent = ex ? "⚡ باركود" : any ? (l.length ? l.length.toLocaleString("en-US") + " صنف" : "0") : l.length.toLocaleString("en-US") + " صنف";
    const show = l.slice(0, CAP);
    let html = "";
    const recN = !any ? show.filter(x => x.rc).length : 0;
    show.forEach((it, k) => {
      if (recN && k === 0) html += '<div class="pkx-sep">🕘 آخر الأصناف المختارة</div>';
      if (recN && k === recN) html += '<div class="pkx-sep">كل الأصناف</div>';
      html += row(it, k);
    });
    if (l.length > CAP) html += `<div class="pkx-more"><button type="button" data-pkx="all">عرض الكل (${l.length.toLocaleString("en-US")}) — أو حدّد البحث أكثر</button></div>`;
    $("pkb").innerHTML = l.length ? html : `<div class="pk-none">لا توجد أصناف مطابقة${any ? ` — <span style="color:#1a6fd0;cursor:pointer;text-decoration:underline" data-pkx="clr">مسح البحث</span>` : ""}</div>`;
    const on = $("pkb").querySelector(".pk-r.on"); if (on && pkIdx > 6) on.scrollIntoView({ block: "nearest" });
  };
  window.pkRender = pkRender = RENDER;

  /* الاختيار: باركود وحدة ← تُضاف بتلك الوحدة */
  window.pkPick = pkPick = function (k) {
    const it = pkList[k]; if (!it) return;
    remember(it.p.id); closePick(); adding = false;
    const u = it.x && it.x.u;
    if (u && it.p._d && u.name && u.name !== it.p._d.name && typeof aiAddUnit === "function") aiAddUnit(it.p, u);
    else addProduct(it.p.id);
    try { showSel(); } catch (e) { }
  };
  const _open = openPick;
  window.openPick = openPick = function () { CAP = 250; IDX = null; setHint(""); return _open.apply(this, arguments); };

  function go(i) {
    if (!pkList.length) return;
    pkIdx = Math.max(0, Math.min(pkList.length - 1, i));
    if (pkIdx >= CAP) { CAP = pkIdx + 50; RENDER(); }
    $("pkb").querySelectorAll(".pk-r").forEach(x => x.classList.toggle("on", +x.dataset.k === pkIdx));
    const on = $("pkb").querySelector(".pk-r.on"); if (on) on.scrollIntoView({ block: "nearest" });
  }
  PK.addEventListener("keydown", e => {
    const anyF = () => [$("pkq"), ...PK.querySelectorAll(".pk-f input")].some(i => i.value.trim());
    if (e.key === "Escape" && anyF()) { e.preventDefault(); e.stopImmediatePropagation(); pkClear(); return; }
    if (e.key === "PageDown" || e.key === "PageUp") { e.preventDefault(); e.stopImmediatePropagation(); go(pkIdx + (e.key === "PageDown" ? 10 : -10)); return; }
    if (e.ctrlKey && (e.key === "Home" || e.key === "End")) { e.preventDefault(); e.stopImmediatePropagation(); go(e.key === "Home" ? 0 : pkList.length - 1); return; }
    if ((e.ctrlKey && (e.key === "f" || e.key === "F")) || e.key === "F3") { e.preventDefault(); e.stopImmediatePropagation(); $("pkq").focus(); $("pkq").select(); return; }
  }, true);
  /* اختصارات الفاتورة (− + * للكمية) ما تاكلش الحروف اللي تكتبها في خانات البحث هنا (مثل 100-300) */
  window.addEventListener("keydown", e => {
    if (!PK.classList.contains("open") || !e.target || !e.target.closest || !e.target.closest("#pk") || e.ctrlKey || e.altKey) return;
    if (e.key.length === 1 && /[-+*\/=<>!.~]/.test(e.key)) e.stopPropagation();
  }, true);
  PK.addEventListener("click", e => {
    const b = e.target.closest("[data-pkx]"); if (!b) return;
    const a = b.dataset.pkx;
    if (a === "all") { CAP = Infinity; RENDER(); }
    else if (a === "clr") pkClear();
    else if (a === "sw" && LAST.sw) { $("pkq").value = LAST.sw; pkIdx = 0; RENDER(); $("pkq").focus(); }
  });
  /* الماوس فوق سطر = تحديده (مثل DEXEF) */
  $("pkb").addEventListener("mousemove", e => { const r = e.target.closest(".pk-r"); if (!r) return; const k = +r.dataset.k; if (k !== pkIdx) { pkIdx = k; $("pkb").querySelectorAll(".pk-r.on").forEach(x => x.classList.remove("on")); r.classList.add("on"); } });
  if (PK.classList.contains("open")) RENDER();
})();
