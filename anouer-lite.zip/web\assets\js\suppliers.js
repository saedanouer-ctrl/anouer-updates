/* ANOUER — شاشة الموردين (مطابقة DEXEF ONE): مراجعة الموردين + نافذة المورد + قائمة الزر الأيمن + كشف الحساب.
   تعمل على قاعدة الشركة عبر إجراءات fm.suppliers.* في HostBridge. */
(function () {
  "use strict";
  var RV = window.__RV;
  if (!RV) { console.warn("suppliers: __RV غير متاح"); return; }
  var G = function (id) { return document.getElementById(id); };
  var B = function () { return !!(window.Anouer && Anouer.available && Anouer.call); };
  var call = function (a, p) { return Anouer.call(a, p || {}); };
  var say = function (m, t) { try { RV.say(m, t); } catch (e) { } };
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return "&#" + c.charCodeAt(0) + ";"; }); };
  var fmt = function (n) { return (Math.round((+n || 0) * 100) / 100).toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 2 }); };
  var fmtB = function (n) { n = +n || 0; return n < 0 ? "[" + fmt(-n) + "]" : fmt(n); }; // السالب بين قوسين كما في DEXEF
  var num = function (v) { var n = parseFloat(String(v == null ? "" : v).replace(/[,\s]/g, "")); return isFinite(n) ? n : 0; };
  var today = function () { return new Date().toISOString().slice(0, 10); };
  var main = document.querySelector(".main");
  if (!main) return;

  var IC = {
    new: '<svg viewBox="0 0 20 20"><rect x="2" y="4" width="16" height="13" rx="1.5" fill="none" stroke="#1f7ad8" stroke-width="1.8"/><path d="M5 8h10" stroke="#1f7ad8" stroke-width="2"/><circle cx="15" cy="4.5" r="3.5" fill="#1f7ad8"/><path d="M15 3v3M13.5 4.5h3" stroke="#fff" stroke-width="1.3"/></svg>',
    edit: '<svg viewBox="0 0 20 20"><path d="M3 17l1-4L14 3l3 3L7 16z" fill="none" stroke="#1f7ad8" stroke-width="1.8" stroke-linejoin="round"/><path d="M12 5l3 3" stroke="#1f7ad8" stroke-width="1.8"/></svg>',
    ref: '<svg viewBox="0 0 20 20" fill="#1f7ad8"><circle cx="10" cy="3" r="1.6"/><circle cx="15" cy="5" r="1.4" opacity=".9"/><circle cx="17" cy="10" r="1.3" opacity=".8"/><circle cx="15" cy="15" r="1.2" opacity=".7"/><circle cx="10" cy="17" r="1.1" opacity=".6"/><circle cx="5" cy="15" r="1" opacity=".5"/><circle cx="3" cy="10" r="1" opacity=".4"/><circle cx="5" cy="5" r="1" opacity=".3"/></svg>',
    dup: '<svg viewBox="0 0 20 20" fill="#33414f"><rect x="3" y="4" width="14" height="2"/><rect x="3" y="9" width="14" height="2"/><rect x="3" y="14" width="10" height="2"/></svg>',
    del: '<svg viewBox="0 0 20 20"><path d="M5 5l10 10M15 5L5 15" stroke="#1f7ad8" stroke-width="2.6" stroke-linecap="round"/></svg>',
    stm: '<svg viewBox="0 0 20 20"><rect x="2" y="3" width="13" height="14" rx="1" fill="#1f7ad8"/><g fill="#fff"><rect x="4" y="6" width="9" height="1.6"/><rect x="4" y="9.2" width="6" height="1.6"/><rect x="4" y="12.4" width="7" height="1.6"/></g><circle cx="15" cy="14" r="3.5" fill="#fff" stroke="#1f7ad8" stroke-width="1.6"/><path d="M17.5 16.5l1.8 1.8" stroke="#1f7ad8" stroke-width="1.8"/></svg>',
    file: '<svg viewBox="0 0 20 20" fill="none" stroke="#1f7ad8" stroke-width="2.2"><circle cx="8.5" cy="8.5" r="5.5"/><path d="M12.6 12.6L18 18" stroke-linecap="round"/></svg>',
    close: '<svg viewBox="0 0 20 20"><rect x="2" y="2" width="16" height="16" rx="2" fill="#1f7ad8"/><path d="M6.5 6.5l7 7M13.5 6.5l-7 7" stroke="#fff" stroke-width="2"/></svg>',
    save: '<svg viewBox="0 0 20 20"><path d="M2 2h13l3 3v13H2z" fill="#8a76c8"/><rect x="5" y="2" width="9" height="5" fill="#ece8f8"/><rect x="5" y="11" width="10" height="7" fill="#fff"/></svg>',
    spin: '<svg viewBox="0 0 20 20" fill="#1f7ad8"><circle cx="10" cy="3" r="1.7"/><circle cx="15" cy="5" r="1.5" opacity=".85"/><circle cx="17" cy="10" r="1.4" opacity=".7"/><circle cx="15" cy="15" r="1.3" opacity=".55"/><circle cx="10" cy="17" r="1.2" opacity=".45"/><circle cx="5" cy="15" r="1.1" opacity=".35"/><circle cx="3" cy="10" r="1" opacity=".25"/></svg>',
    user: '<svg viewBox="0 0 22 22" width="18" height="18"><circle cx="11" cy="7" r="4.6" fill="#2b7de0"/><path d="M2.5 21c0-5.2 3.8-8 8.5-8s8.5 2.8 8.5 8z" fill="#2b7de0"/></svg>',
    bars: '<svg viewBox="0 0 16 12" width="16" height="12"><rect x="0" y="7" width="3" height="5" fill="#8a76c8"/><rect x="4.5" y="4" width="3" height="8" fill="#8a76c8"/><rect x="9" y="1" width="3" height="11" fill="#8a76c8"/></svg>'
  };

  // ------------------------------------------------------------------ البيانات
  var SUPS = [], BRANCHES = null;
  function parseX(s) { try { var o = s ? JSON.parse(s) : {}; return o && typeof o === "object" ? o : {}; } catch (e) { return {}; } }
  function mapRow(r) {
    var x = parseX(r.Extra);
    return { id: r.SupplierId, name: r.Name || "", no: r.Code || "", ph: r.Phone || "", addr: r.Address || "", bal: +r.Balance || 0,
             lim: +r.CreditLimit || 0, last: r.LastDeal || "", active: r.IsActive !== false, open: +r.OpeningBalance || 0,
             openDate: r.OpenDate || "", x: x, inv: r.Invoices || 0 };
  }
  var loading = null;
  function load() {
    if (!B()) return Promise.resolve();
    if (loading) return loading;
    loading = call("fm.suppliers.list").then(function (l) {
      SUPS = (l || []).map(mapRow);
      if (SR) SR.render();
      try { window.dispatchEvent(new Event("anouer:suppliers")); } catch (e) { }
    }).catch(function (e) { say("تعذّر تحميل الموردين: " + e.message, "e"); }).then(function () { loading = null; });
    return loading;
  }
  function branches() {
    if (BRANCHES) return Promise.resolve(BRANCHES);
    if (!B()) return Promise.resolve(BRANCHES = RV.BR.slice());
    return call("fm.branches.list").then(function (l) {
      BRANCHES = (l || []).filter(function (b) { return b.IsActive; }).map(function (b) { return b.Name; });
      if (!BRANCHES.length) BRANCHES = RV.BR.slice();
      return BRANCHES;
    }).catch(function () { return (BRANCHES = RV.BR.slice()); });
  }

  // ------------------------------------------------------------------ مراجعة الموردين
  var el = document.createElement("div");
  el.className = "vw"; el.id = "vSuRev"; el.tabIndex = -1; el.setAttribute("aria-label", "مراجعة الموردين");
  main.appendChild(el);
  var SR = null;

  RV.VIEW_SHOW.surev = function () {
    if (!SR) {
      SR = RV.Review(el, {
        title: "مراجعة الموردين",
        filters: '<label class="rv-chk"><input type="checkbox" checked data-act="1"><span>نشط</span></label>' + RV.ddSel(RV.BR, RV.BR[0]) + RV.ddSel(RV.PERIODS, RV.PERIODS[3]),
        head: '<div class="rv-dd" style="width:160px"><span class="lb"></span><span>⋯</span><span class="ck">✓</span><span style="font-size:9px;color:#777">⌄</span></div><div style="flex:1"></div><div class="rv-search" style="width:260px"><span>' + RV.SRCH + '</span><input placeholder="Enter text to search..."></div>',
        side: [],
        cols: [
          { w: "44px", h: function () { return RV.CI.user; } },
          { t: "الاسم", w: "minmax(200px,1fr)", f: function (r) { return r.name; }, txt: 1, cnt: 1 },
          { t: "الرقم", w: "190px", f: function (r) { return r.no; } },
          { t: "تليفون 1", w: "160px", f: function (r) { return r.ph; } },
          { t: "الرصيد", w: "165px", f: function (r) { return r.bal ? fmtB(r.bal) : 0; }, v: function (r) { return r.bal; }, tot: 1 },
          { t: "العملة", w: "130px", f: function (r) { return r.x.cur || "DZD"; } },
          { t: "حد الإئتمان", w: "170px", f: function (r) { return r.lim ? fmt(r.lim) : 0; }, v: function (r) { return r.lim; } },
          { t: "المجموعة", w: "135px", f: function (r) { return r.x.group || ""; } },
          { t: "اخر تعامل", w: "190px", f: function (r) { return r.last; } },
          { t: "نشط", w: "52px", f: function (r) { return r.active === false ? 0 : 1; }, h: function (r) { return '<input type="checkbox"' + (r.active === false ? "" : " checked") + ' style="accent-color:#2b7de0;pointer-events:none" tabindex="-1">'; } },
          { w: "44px", h: function () { return '<span data-stm="1" class="pc-ico" title="بطاقة المورد">' + RV.CHART + "</span>"; } },
          { t: "Whats…", w: "52px", h: function () { return '<span data-wa="1" title="واتساب">' + RV.CI.wa + "</span>"; } }
        ],
        icon: RV.CHART, totals: 1,
        data: function () { return SUPS; },
        pass: function (r) { var c = el.querySelector("[data-act]"); return !c || !c.checked || r.active !== false; },
        onNew: function () { openForm(null); },
        onOpen: function (r) { openForm(r); },
        onDel: function (r) { delSupplier(r); }
      });
      el.classList.add("crev", "surev");
      fixTotals();
      // الإجمالي يُعاد رسمه عند كل بحث/ترتيب: نعيد تنسيقه (السالب بين قوسين)
      var totEl = el.querySelector(".rv-tot");
      if (totEl && window.MutationObserver) new MutationObserver(fixTotals).observe(totEl, { childList: true });
      // زر «تحديث» يعيد التحميل من القاعدة
      el.querySelector(".rv-tb").addEventListener("click", function (e) {
        var b = e.target.closest("button"); if (!b) return;
        if (b.dataset.a === "refresh") load();
        // «تعديل» كما في DEXEF: رسالة «هل تريد التعديل ؟» بصوتها قبل فتح النافذة
        if (b.dataset.a === "edit") { e.stopImmediatePropagation(); var r = cur(); if (r) editAsk(r); else say("اختر سطراً أولاً", "w"); }
        // «رفع» = استيراد الموردين من إكسيل (نفس نافذة الاستيراد بقائمة ملف)
        if (b.title === "رفع" && window.ANOUER_FILE_MENU) { e.stopImmediatePropagation(); ANOUER_FILE_MENU.importWin("suppliers"); }
      }, true);
      var rows = el.querySelector(".rv-rows");
      rows.addEventListener("click", function (e) {
        var r = cur();
        if (e.target.closest("[data-stm]") && r) pcard(r, "ov");
        else if (e.target.closest("[data-wa]") && r) say(r.ph ? "واتساب: " + r.ph : "لا يوجد رقم هاتف لهذا المورد", r.ph ? "i" : "w");
      });
      rows.addEventListener("contextmenu", function (e) {
        var d = e.target.closest(".rv-d"); if (!d) return;
        e.preventDefault(); e.stopPropagation();
        d.dispatchEvent(new MouseEvent("click", { bubbles: true }));
        ctxMenu(e.clientX, e.clientY);
      });
      el.addEventListener("mousedown", function () { setTimeout(function () { if (!el.contains(document.activeElement)) el.focus(); }, 0); });
      el.addEventListener("keydown", onKeys);
      if (!B()) say("وضع المعاينة: الموردون يُحمَّلون من قاعدة البيانات داخل البرنامج", "w");
    }
    load().then(fixTotals);
    SR.render(); fixTotals();
    setTimeout(function () { el.focus(); }, 0);
  };
  // إجمالي الرصيد بنفس تنسيق DEXEF (السالب بين قوسين)
  function fixTotals() {
    if (!SR) return;
    var tot = el.querySelector(".rv-tot"); if (!tot) return;
    var cells = tot.children, l = SR.cur || [];
    if (cells[4]) cells[4].textContent = fmtB(l.reduce(function (s, r) { return s + (r.bal || 0); }, 0));
  }
  function cur() { return SR && SR.cur ? SR.cur[SR.sel] : null; }
  function openReview() { openTab("surev", "مراجعة الموردين", "surev"); }
  window.openSuppliers = openReview;

  // ------------------------------------------------------------------ اختصارات لوحة المفاتيح (داخل المراجعة)
  function onKeys(e) {
    if (formEl && formEl.parentNode) return;
    var k = (e.key || "").toLowerCase(), r = cur();
    var go = function (fn) { e.preventDefault(); e.stopPropagation(); fn(); };
    if (e.key === "F5") go(function () { load(); SR.refresh(); });
    else if (e.ctrlKey && e.altKey && (k === "m" || e.code === "KeyM")) go(function () { if (r) pcard(r, "ov"); });
    else if (e.ctrlKey && !e.altKey && (k === "e" || e.code === "KeyE")) go(function () { if (r) editAsk(r); else say("اختر سطراً أولاً", "w"); });
    else if (e.ctrlKey && !e.altKey && (k === "d" || e.code === "KeyD")) go(function () { if (r) delSupplier(r); });
    else if (e.ctrlKey && !e.altKey && (k === "m" || e.code === "KeyM")) go(function () { if (r) pcard(r, "stm"); });
    else if (e.key === "Enter" && r) go(function () { openForm(r); });
    else if (e.key === "ArrowDown" || e.key === "ArrowUp") go(function () {
      var l = SR.cur || []; if (!l.length) return;
      SR.sel = Math.max(0, Math.min(l.length - 1, SR.sel + (e.key === "ArrowDown" ? 1 : -1)));
      SR.render(); fixTotals();
      var row = el.querySelector(".rv-d.cur"); if (row && row.scrollIntoView) row.scrollIntoView({ block: "nearest" });
    });
  }
  // اختصارات القوائم العامة (Ctrl+M مرتجع ...) لا تعمل داخل شاشة الموردين — لها اختصاراتها كما في DEXEF
  window.__kbOwner = function () { return !!(formEl && formEl.parentNode) || main.dataset.view === "surev"; };
  // Ctrl+N داخل الموردين = مورد جديد (بدل فاتورة مبيعات جديدة)
  window.__ctrlN = function () {
    if (formEl && formEl.parentNode) { formNew(); return true; }
    if (main.dataset.view === "surev") { openForm(null); return true; }
    return false;
  };

  // بطاقة المورد (party-card.js) — كشف الحساب / ملف الحساب؛ وإلا كشف الحساب القديم
  function pcard(r, v) { if (window.ANOUER_PCARD) ANOUER_PCARD.open("su", r, v); else statement(r); }

  // ------------------------------------------------------------------ قائمة الزر الأيمن (مثل DEXEF)
  var menuEl = null;
  function closeMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }
  function ctxMenu(x, y) {
    closeMenu();
    var r = cur();
    var items = [
      ["جديد", "Ctrl+N", IC.new, function () { openForm(null); }],
      ["تعديل", "Ctrl+E", IC.edit, function () { if (r) editAsk(r); }],
      ["تحديث البيانات", "F5", IC.ref, function () { load(); SR.refresh(); }],
      ["تكرار", "", IC.dup, function () { if (r) openForm(r, true); }],
      ["حذف", "Ctrl+D", IC.del, function () { if (r) delSupplier(r); }],
      ["كشف الحساب", "Ctrl+M", IC.stm, function () { if (r) pcard(r, "stm"); }],
      ["ملف الحساب", "Ctrl+Alt+M", IC.file, function () { if (r) pcard(r, "ov"); }],
      ["أغلاق الصفحة", "", IC.close, function () { try { closeTab("surev"); } catch (e) { } }]
    ];
    menuEl = document.createElement("div");
    menuEl.className = "su-ctx"; menuEl.setAttribute("role", "menu");
    menuEl.innerHTML = items.map(function (it, i) {
      return '<div class="su-ci" role="menuitem" data-i="' + i + '"><span class="ic">' + it[2] + '</span><span class="t">' + it[0] + '</span><span class="k">' + it[1] + "</span></div>";
    }).join("");
    document.body.appendChild(menuEl);
    var w = menuEl.offsetWidth, h = menuEl.offsetHeight;
    menuEl.style.left = Math.max(4, Math.min(x - w, innerWidth - w - 4)) + "px";
    menuEl.style.top = Math.max(4, Math.min(y, innerHeight - h - 4)) + "px";
    menuEl.addEventListener("mousedown", function (e) { e.stopPropagation(); });
    menuEl.addEventListener("contextmenu", function (e) { e.preventDefault(); });
    menuEl.addEventListener("click", function (e) {
      var c = e.target.closest(".su-ci"); if (!c) return;
      var fn = items[+c.dataset.i][3]; closeMenu(); fn();
    });
  }
  document.addEventListener("mousedown", closeMenu);
  window.addEventListener("blur", closeMenu);
  document.addEventListener("keydown", function (e) { if (menuEl && e.key === "Escape") { e.preventDefault(); closeMenu(); } }, true);

  // ------------------------------------------------------------------ حذف
  function delSupplier(r) {
    if (!B()) { say("الحذف متاح داخل البرنامج فقط", "w"); return; }
    askConfirm("هل تريد حذف المورد «" + r.name + "» ؟", function () {
      call("fm.suppliers.delete", { id: r.id }).then(function (x) {
        say(x && x.deleted ? "تم حذف المورد" : "للمورد حركات — تم إيقافه وإخفاؤه من القائمة", "s");
        if (formEl && formEl.parentNode && edit && edit.id === r.id) closeForm();
        load();
      }).catch(function (e) { say(e.message, "e"); });
    });
  }

  // ------------------------------------------------------------------ نافذة المورد
  var formEl = null, edit = null, dirty = false;
  var ACC =
    '<div class="it-sec"><div class="it-st">التصنيف</div><div class="it-sb">' +
    ' <div class="it-r"><label>اسم الفرع</label><span class="it-sel" style="width:235px"><select data-f="branch"></select></span><span class="it-req">*</span><label class="cu-inl" style="margin-right:12px"><input type="checkbox" data-f="allBr">كل الفروع</label></div>' +
    ' <div class="it-r"><label>يوجد بداخل</label><span class="qx-cb" data-qx="grp" style="width:236px"><input class="it-in" data-f="group" autocomplete="off" spellcheck="false" placeholder="ابحث أو اختر مجموعة…" aria-haspopup="listbox"><i class="qx-dd"></i></span><button type="button" class="qx-plus" data-qx-add title="مجموعة جديدة (Ins)" tabindex="-1">+</button></div>' +
    ' <div class="it-r"><label>العملة الافتراضية</label><span class="it-sel" style="width:90px"><select data-f="cur"><option>DZD</option><option>EUR</option><option>USD</option></select></span><span class="it-num"><input data-f="rate" value="1" inputmode="decimal"></span><span class="it-num" style="width:50px"><input data-f="dec" value="0" inputmode="numeric"></span></div>' +
    ' <div class="it-r"><label>حساب الاستاذ</label><span class="it-sel" style="width:236px"><select data-f="ledger"><option>موردون</option></select></span><span class="it-req">*</span></div>' +
    '</div></div>' +
    '<div class="it-sec"><div class="it-st">سياسة التعامل</div><div class="it-sb">' +
    ' <div class="it-r"><label>التعامل الافتراضى</label><span class="it-sel su-bars" style="width:236px"><select data-f="terms"><option>أجل</option><option>كاش</option></select></span></div>' +
    ' <div class="it-r"><label>حد الإئتمان</label><span class="it-sel fill" style="width:236px"><input class="it-in su-lim" data-f="lim" autocomplete="off" inputmode="decimal" value="0"></span></div>' +
    ' <div class="it-r"><label>جهة التعامل</label><span class="qx-cb" data-qx="party" style="width:236px"><input class="it-in" data-f="party" autocomplete="off" spellcheck="false" placeholder="ابحث أو اختر جهة…" aria-haspopup="listbox"><i class="qx-dd"></i></span><button type="button" class="qx-plus" data-qx-add title="جهة تعامل جديدة (Ins)" tabindex="-1">+</button></div>' +
    ' <div class="it-r"><label>الحساب المكمل</label><span class="it-sel" style="width:236px"><select data-f="contra"><option></option><option>الأرصدة الافتتاحية</option></select></span><span class="it-req">*</span></div>' +
    '</div></div>' +
    '<div class="it-sec"><div class="it-st">الإضافات</div><div class="it-sb">' +
    ' <div class="it-r"><label>شروط الدفع</label><span class="it-sel fill" style="width:236px"><select data-f="pay"><option></option><option>فورى</option><option>15 يوم</option><option>30 يوم</option><option>60 يوم</option></select></span></div>' +
    ' <div class="it-r"><label>شرائح الخصم</label><span class="it-sel fill" style="width:236px"><select data-f="disc"><option>0</option><option>خصم 5%</option><option>خصم 10%</option></select></span></div>' +
    ' <div class="it-r"><label>مندوب المبيعات</label><span class="it-sel fill" style="width:236px"><select data-f="rep"><option></option><option>المندوب 1</option><option>المندوب 2</option></select></span></div>' +
    ' <div class="it-r"><label>مركز التكلفة</label><span class="it-sel fill" style="width:236px"><select data-f="cc"><option></option><option>المركز الرئيسي</option></select></span></div>' +
    '</div></div>';
  var ATT =
    '<div class="it-sec"><div class="it-st">المرفقات</div><div class="it-sb">' +
    ' <div class="su-att"><button type="button" class="su-att-add" id="suAttAdd">+ إضافة مرفق</button><input type="file" id="suAttF" multiple hidden>' +
    '  <div class="su-att-list" id="suAttList"></div></div>' +
    '</div></div>';

  function buildForm() {
    var src = G("vCust") && G("vCust").querySelector(".it-wrap");
    if (!src) { say("تعذّر بناء نموذج المورد", "e"); return null; }
    var wrap = src.cloneNode(true);
    wrap.querySelectorAll("[id]").forEach(function (n) { n.id = n.id.replace(/^cu/, "su"); });
    wrap.querySelectorAll("[onclick]").forEach(function (n) { n.removeAttribute("onclick"); });
    wrap.querySelectorAll("input,select,textarea").forEach(function (n) { if (n.list && n.getAttribute("list") === "itGroups") n.setAttribute("list", "suGroups"); });
    var tabs = wrap.querySelector("#suTabs");
    var t = document.createElement("div"); t.className = "it-stab"; t.dataset.p = "att"; t.textContent = "المرفقات"; tabs.appendChild(t);
    wrap.querySelector('.it-pn[data-p="acc"]').innerHTML = ACC;
    /* رقم هاتف / واتساب المورد إجباري (يُستعمل في «التوريد التلقائي» عند نفاد رصيد صنف) */
    var phI = wrap.querySelector('[data-f="ph"]');
    if (phI) { phI.placeholder = "واتساب"; phI.title = "رقم هاتف / واتساب المورد — إجباري (طلبات التوريد التلقائي)"; var rq = document.createElement("span"); rq.className = "it-req"; rq.textContent = "*"; phI.parentNode.appendChild(rq); }
    var att = document.createElement("div"); att.className = "it-pn"; att.dataset.p = "att"; att.innerHTML = ATT;
    wrap.appendChild(att);
    wrap.querySelectorAll('.it-pn[data-p="web"] label').forEach(function (l) { if (l.textContent.trim() === "اسم العميل") l.textContent = "اسم المورد"; });
    var dl = document.createElement("datalist"); dl.id = "suGroups"; wrap.appendChild(dl);

    var ov = document.createElement("div");
    ov.className = "su-ov";
    ov.innerHTML =
      '<div class="su-win" role="dialog" aria-modal="true" aria-label="الموردين" tabindex="-1">' +
      ' <div class="su-tb"><span class="su-ti">' + IC.user + '<b>الموردين</b></span><span class="sp"></span>' +
      '  <button type="button" class="su-wb" data-w="min" title="تصغير">—</button><button type="button" class="su-wb" data-w="max" title="تكبير">☐</button><button type="button" class="su-wb x" data-w="close" title="إغلاق">✕</button></div>' +
      ' <div class="su-tool">' +
      '  <div class="su-fm"><button type="button" class="su-tbtn" data-t="file">ملف <i>▾</i></button></div>' +
      '  <button type="button" class="su-tbtn" data-t="prev"><span class="ic">' + IC.spin + '</span>السابق</button>' +
      '  <button type="button" class="su-tbtn" data-t="next">التالي</button><span class="su-sep"></span>' +
      '  <button type="button" class="su-tbtn" data-t="save"><span class="ic">' + IC.save + '</span>حفظ</button>' +
      ' </div>' +
      ' <div class="su-bd"></div>' +
      '</div>';
    ov.querySelector(".su-bd").appendChild(wrap);
    return ov;
  }

  function $f(sel) { return formEl.querySelector(sel); }
  function $$f(sel) { return Array.prototype.slice.call(formEl.querySelectorAll(sel)); }

  function ensureForm() {
    if (formEl && formEl.parentNode) return true;
    if (!formEl) {
      formEl = buildForm(); if (!formEl) return false;
      wireForm();
    }
    document.body.appendChild(formEl);
    return true;
  }

  function wireForm() {
    formEl.addEventListener("mousedown", function (e) { e.stopPropagation(); });
    // تبويبات
    $f("#suTabs").addEventListener("click", function (e) {
      var t = e.target.closest(".it-stab"); if (!t) return;
      $$f("#suTabs .it-stab").forEach(function (x) { x.classList.toggle("on", x === t); });
      $$f(".it-pn").forEach(function (p) { p.classList.toggle("on", p.dataset.p === t.dataset.p); });
    });
    // مفاتيح نعم/لا
    formEl.addEventListener("click", function (e) {
      var tg = e.target.closest(".it-tg"); if (!tg) return;
      var c = tg.querySelector("input"); if (e.target !== c) { c.checked = !c.checked; e.preventDefault(); }
      sync(); dirty = true;
    });
    formEl.addEventListener("input", function () { dirty = true; });
    formEl.addEventListener("change", function () { dirty = true; sync(); });
    // الصورة
    var box = $f("#suImgBox"), fi = $f("#suImgF");
    if (box && fi) {
      box.addEventListener("click", function () { fi.click(); });
      fi.addEventListener("change", function () {
        var f = fi.files && fi.files[0]; fi.value = ""; if (!f) return;
        var rd = new FileReader();
        rd.onload = function () { var im = $f("#suImgP"); im.src = rd.result; im.hidden = false; $f("#suImgLbl").hidden = true; dirty = true; };
        rd.readAsDataURL(f);
      });
    }
    // المرفقات (أسماء الملفات تُحفظ مع بيانات المورد)
    $f("#suAttAdd").addEventListener("click", function () { $f("#suAttF").click(); });
    $f("#suAttF").addEventListener("change", function () {
      var fs = Array.prototype.slice.call(this.files || []); this.value = "";
      fs.forEach(function (f) { ATTS.push({ n: f.name, s: f.size, d: today() }); });
      renderAtt(); dirty = true;
    });
    $f("#suAttList").addEventListener("click", function (e) {
      var x = e.target.closest("[data-rm]"); if (!x) return;
      ATTS.splice(+x.dataset.rm, 1); renderAtt(); dirty = true;
    });
    // أزرار النافذة
    formEl.querySelector(".su-tb").addEventListener("click", function (e) {
      var b = e.target.closest("[data-w]"); if (!b) return;
      var w = formEl.querySelector(".su-win");
      if (b.dataset.w === "close") tryClose();
      else if (b.dataset.w === "max") w.classList.toggle("maxi");
      else if (b.dataset.w === "min") w.classList.toggle("mini");
    });
    formEl.querySelector(".su-tb").addEventListener("dblclick", function (e) { if (!e.target.closest("[data-w]")) formEl.querySelector(".su-win").classList.toggle("maxi"); });
    formEl.querySelector(".su-tool").addEventListener("click", function (e) {
      var b = e.target.closest("[data-t]"); if (!b) return;
      var t = b.dataset.t;
      if (t === "save") save();
      else if (t === "prev") step(-1);
      else if (t === "next") step(1);
      else if (t === "file") fileMenu(b);
    });
    $f(".it-save").addEventListener("click", save);
    formEl.addEventListener("keydown", function (e) {
      var k = (e.key || "").toLowerCase();
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); if (fmMenu) closeFm(); else tryClose(); }
      else if (e.key === "F2" || (e.ctrlKey && (k === "s" || e.code === "KeyS"))) { e.preventDefault(); e.stopPropagation(); save(); }
      else if (e.ctrlKey && !e.altKey && (k === "m" || e.code === "KeyM")) { e.preventDefault(); e.stopPropagation(); if (edit) statement(edit); }
      else if (e.key === "PageDown") { e.preventDefault(); step(1); }
      else if (e.key === "PageUp") { e.preventDefault(); step(-1); }
    });
  }

  var fmMenu = null;
  function closeFm() { if (fmMenu) { fmMenu.remove(); fmMenu = null; } }
  function fileMenu(btn) {
    if (fmMenu) { closeFm(); return; }
    var items = [["جديد", "Ctrl+N", IC.new, formNew], ["حفظ", "Ctrl+S", IC.save, save], ["حذف", "", IC.del, function () { if (edit) delSupplier(edit); }],
                 ["كشف الحساب", "Ctrl+M", IC.stm, function () { if (edit) statement(edit); }], ["إغلاق", "Esc", IC.close, tryClose]];
    fmMenu = document.createElement("div");
    fmMenu.className = "su-ctx su-ctx-fm";
    fmMenu.innerHTML = items.map(function (it, i) { return '<div class="su-ci" data-i="' + i + '"><span class="ic">' + it[2] + '</span><span class="t">' + it[0] + '</span><span class="k">' + it[1] + "</span></div>"; }).join("");
    btn.parentNode.appendChild(fmMenu);
    fmMenu.addEventListener("click", function (e) { var c = e.target.closest(".su-ci"); if (!c) return; var fn = items[+c.dataset.i][3]; closeFm(); fn(); });
    setTimeout(function () { document.addEventListener("mousedown", function h(ev) { if (!fmMenu || fmMenu.contains(ev.target)) return; closeFm(); document.removeEventListener("mousedown", h, true); }, true); }, 0);
  }

  var ATTS = [];
  function renderAtt() {
    $f("#suAttList").innerHTML = ATTS.length ? ATTS.map(function (a, i) {
      return '<div class="su-att-i"><span class="n">' + esc(a.n) + '</span><span class="s">' + (a.s > 1048576 ? (a.s / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(a.s / 1024)) + " KB") + '</span><span class="d">' + esc(a.d) + '</span><button type="button" data-rm="' + i + '" title="حذف">✕</button></div>';
    }).join("") : '<div class="su-att-empty">لا توجد مرفقات</div>';
  }

  function sync() {
    $$f(".it-tg").forEach(function (l) { var c = l.querySelector("input"); l.classList.toggle("on", c.checked); var b = l.querySelector("b"); if (b) b.textContent = c.checked ? "نعم" : "لا"; });
    var t = $f("[data-f=taxOn]"), tx = $f(".cu-tx"); if (t && tx) tx.classList.toggle("off", !t.checked);
  }

  function nextCode() {
    var m = 19999;
    SUPS.forEach(function (r) { if (/^\d{1,15}$/.test(r.no) && +r.no > m) m = +r.no; });
    return String(m + 1);
  }

  function fillBranches(sel) {
    return branches().then(function (list) {
      var s = $f("[data-f=branch]");
      s.innerHTML = list.map(function (b) { return "<option>" + esc(b) + "</option>"; }).join("");
      if (sel && list.indexOf(sel) < 0) s.insertAdjacentHTML("beforeend", "<option>" + esc(sel) + "</option>");
      if (sel) s.value = sel;
    });
  }

  function reset() {
    $$f("[data-f]").forEach(function (x) {
      if (x.type === "checkbox") x.checked = /^w[1-7]$/.test(x.dataset.f);
      else if (x.tagName === "SELECT") x.selectedIndex = 0;
      else x.value = x.dataset.f === "rate" ? "1" : x.dataset.f === "dec" ? "0" : x.dataset.f === "lim" ? "0" : "";
    });
    /* طبيعة التعامل الافتراضية للمورد الجديد (خصائص العملاء و الموردين) */
    try { var dd = window.ANOUER_PROPS && (ANOUER_PROPS.get("cust.gen", {}) || {}).newSupDeal, ts = $f("[data-f=terms]"); if (dd && ts) { var nn = function (t) { return String(t).replace(/[آإ]/g, "أ").trim(); }; [].some.call(ts.options, function (o) { if (nn(o.textContent) === nn(dd)) { ts.value = o.value; return true; } }); } } catch (e) { }
    var nm = $f("#suName"); nm.value = ""; nm.classList.remove("err");
    $f("#suActive").checked = true; $f("#suOpen").value = "0"; $f("#suDate").value = today();
    var no = $f("#suNo"); no.readOnly = false; no.value = nextCode();
    var im = $f("#suImgP"); im.hidden = true; im.removeAttribute("src"); $f("#suImgLbl").hidden = false;
    ATTS = []; renderAtt();
    $$f("#suTabs .it-stab").forEach(function (x, i) { x.classList.toggle("on", i === 0); });
    $$f(".it-pn").forEach(function (p) { p.classList.toggle("on", p.dataset.p === "acc"); });
    var groups = {}; SUPS.forEach(function (r) { if (r.x.group) groups[r.x.group] = 1; });
    $f("#suGroups").innerHTML = Object.keys(groups).map(function (g) { return '<option value="' + esc(g) + '">'; }).join("");
    sync();
  }

  function fill(r, copy) {
    reset();
    var x = r.x || {};
    $f("#suName").value = copy ? r.name + " - نسخة" : r.name;
    if (!copy) $f("#suNo").value = r.no;
    $f("#suActive").checked = r.active !== false;
    $f("#suOpen").value = r.open || 0;
    $f("#suDate").value = r.openDate || today();
    $$f("[data-f]").forEach(function (f) {
      var k = f.dataset.f, v = k === "ph" ? r.ph : k === "lim" ? r.lim : k === "addr" ? (x.addr != null ? x.addr : r.addr) : x[k];
      if (v == null || v === "") return;
      if (f.type === "checkbox") f.checked = !!v; else f.value = v;
    });
    if (x.img) { var im = $f("#suImgP"); im.src = x.img; im.hidden = false; $f("#suImgLbl").hidden = true; }
    ATTS = Array.isArray(x.att) ? x.att.slice() : []; renderAtt();
    sync();
    return fillBranches(x.branch);
  }

  function title() {
    var t = formEl.querySelector(".su-ti b");
    t.textContent = edit ? "الموردين — " + edit.name : "الموردين — مورد جديد";
  }

  /** التعديل (زر تعديل / Ctrl+E / القائمة): تأكيد DEXEF أولاً ثم فتح المورد للتعديل */
  var confirmed = false;
  function editAsk(r) { askEdit(function () { openForm(r); confirmed = true; }); }

  function openForm(r, copy) {
    if (!ensureForm()) return;
    confirmed = false;
    edit = r && !copy ? r : null;
    if (window.__cfApply) window.__cfApply(formEl, "sup");   // الحقول الإضافية للموردين (الخصائص)
    if (r) fill(r, copy); else { reset(); fillBranches(); if (window.__cfDefaults) window.__cfDefaults(formEl); }
    dirty = !!copy;
    title();
    setTimeout(function () { var n = $f("#suName"); n.focus(); if (!r) n.select(); }, 30);
  }
  function formNew() { edit = null; if (window.__cfApply) window.__cfApply(formEl, "sup"); reset(); fillBranches(); if (window.__cfDefaults) window.__cfDefaults(formEl); dirty = false; title(); setTimeout(function () { $f("#suName").focus(); }, 20); }
  function closeForm() { closeFm(); if (formEl && formEl.parentNode) formEl.remove(); edit = null; dirty = false; if (main.dataset.view === "surev") el.focus(); }
  function tryClose() {
    if (dirty) askConfirm("يوجد تعديلات لم تُحفظ .. هل تريد إغلاق النافذة ؟", closeForm);
    else closeForm();
  }
  function step(d) {
    var l = (SR && SR.cur) || SUPS; if (!l.length) return;
    var i = edit ? l.indexOf(edit) : -1;
    if (i < 0) i = d > 0 ? -1 : l.length;
    var n = i + d;
    if (n < 0 || n >= l.length) { say(d > 0 ? "هذا آخر مورد" : "هذا أول مورد", "i"); return; }
    var go = function () { if (SR) { SR.sel = n; SR.render(); fixTotals(); } openForm(l[n]); };
    if (dirty) askConfirm("يوجد تعديلات لم تُحفظ .. هل تريد الانتقال ؟", go); else go();
  }

  function collect() {
    var x = {};
    $$f("[data-f]").forEach(function (f) { x[f.dataset.f] = f.type === "checkbox" ? f.checked : f.value.trim(); });
    var im = $f("#suImgP"); if (!im.hidden && im.src && im.src.length < 350000) x.img = im.src;
    if (ATTS.length) x.att = ATTS;
    return {
      SupplierId: edit ? edit.id : 0,
      Code: $f("#suNo").value.trim(),
      Name: $f("#suName").value.trim(),
      Phone: x.ph || "",
      Address: x.addr || "",
      OpeningBalance: num($f("#suOpen").value),
      OpenDate: $f("#suDate").value,
      CreditLimit: num(x.lim),
      IsActive: $f("#suActive").checked,
      Extra: JSON.stringify(x)
    };
  }

  function save() {
    var nm = $f("#suName"), p = collect();
    if (!p.Name) { nm.classList.add("err"); nm.focus(); say("اسم المورد مطلوب", "w"); return; }
    nm.classList.remove("err");
    var phE = $f('[data-f="ph"]'), phD = String(p.Phone || "").replace(/\D/g, "");
    if (phD.length < 9 || phD.length > 15) {
      if (phE) { var pn = phE.closest(".it-pn"), tb = pn && formEl.querySelector('.it-stab[data-p="' + pn.dataset.p + '"]'); if (tb && !pn.classList.contains("on")) tb.click(); phE.classList.add("err"); setTimeout(function () { phE.focus(); }, 30);
        phE.addEventListener("input", function f() { phE.classList.remove("err"); phE.removeEventListener("input", f); }); }
      say(phD.length ? "رقم هاتف المورد غير صالح" : "رقم هاتف / واتساب المورد إجباري — يُرسل له طلب التوريد تلقائياً عند نفاد الأصناف", "w"); return;
    }
    if (SUPS.some(function (r) { return r !== edit && r.name === p.Name; })) { nm.classList.add("err"); nm.focus(); say("يوجد مورد بنفس الاسم", "w"); return; }
    if (window.__reqCheck && !window.__reqCheck(formEl, "sup")) return;   // الخانات اجبارية الادخال (الخصائص)
    if (!B()) { say("الحفظ متاح داخل البرنامج فقط", "w"); return; }
    var doSave = function () {
      call("fm.suppliers.save", p).then(function (id) {
        var wasEdit = !!edit;
        say(wasEdit ? "تم حفظ تعديلات المورد" : "تم حفظ المورد «" + p.Name + "»", "s");
        dirty = false;
        return load().then(function () {
          if (wasEdit) {
            edit = SUPS.filter(function (r) { return r.id === id; })[0] || null;
            if (edit) { var l = (SR && SR.cur) || []; var i = l.indexOf(edit); if (SR && i >= 0) { SR.sel = i; SR.render(); fixTotals(); } }
            title();
          } else formNew();   // بعد حفظ مورد جديد: نموذج جديد فارغ (كما في DEXEF)
        });
      }).catch(function (e) { say(e.message, "e"); });
    };
    if (edit && !confirmed) askEdit(function () { confirmed = true; doSave(); }); else doSave();
  }

  // ------------------------------------------------------------------ كشف حساب المورد
  function statement(r) {
    if (!B()) { say("كشف الحساب متاح داخل البرنامج فقط", "w"); return; }
    call("fm.suppliers.statement", { id: r.id }).then(function (d) {
      var bal = +d.opening || 0, deb = 0, cre = 0;
      var rows = '<tr class="op"><td>' + esc(d.openDate || "") + '</td><td>رصيد افتتاحى</td><td></td><td></td><td></td><td class="n">' + fmtB(bal) + "</td></tr>" +
        (d.lines || []).map(function (l) {
          bal += (+l.Credit || 0) - (+l.Debit || 0); deb += +l.Debit || 0; cre += +l.Credit || 0;
          return "<tr><td>" + esc(l.Date) + "</td><td>" + esc(l.Type) + '</td><td class="n">' + esc(l.No) + '</td><td class="n">' + (l.Debit ? fmt(l.Debit) : "") + '</td><td class="n">' + (l.Credit ? fmt(l.Credit) : "") + '</td><td class="n">' + fmtB(bal) + "</td></tr>";
        }).join("");
      var ov = document.createElement("div");
      ov.className = "su-ov";
      ov.innerHTML = '<div class="su-win su-stm" tabindex="-1"><div class="su-tb"><span class="su-ti">' + IC.stm + "<b>كشف حساب — " + esc(d.name) + " (" + esc(d.code) + ')</b></span><span class="sp"></span>' +
        '<button type="button" class="su-wb" data-p="1" title="طباعة">⎙</button><button type="button" class="su-wb x" data-x="1" title="إغلاق">✕</button></div>' +
        '<div class="su-bd"><table class="su-st"><thead><tr><th>التاريخ</th><th>البيان</th><th>الرقم</th><th>مدين</th><th>دائن</th><th>الرصيد</th></tr></thead><tbody>' + rows +
        '</tbody><tfoot><tr><td colspan="3">الإجمالي</td><td class="n">' + fmt(deb) + '</td><td class="n">' + fmt(cre) + '</td><td class="n">' + fmtB(bal) + "</td></tr></tfoot></table>" +
        (!(d.lines || []).length ? '<div class="su-st-empty">لا توجد حركات لهذا المورد</div>' : "") + "</div></div>";
      document.body.appendChild(ov);
      var close = function () { ov.remove(); if (formEl && formEl.parentNode) formEl.querySelector(".su-win").focus(); else el.focus(); };
      ov.querySelector("[data-x]").addEventListener("click", close);
      ov.querySelector("[data-p]").addEventListener("click", function () {
        var w = window.open("", "_blank"); if (!w) return;
        w.document.write('<html dir="rtl"><head><meta charset="utf-8"><title>كشف حساب ' + esc(d.name) + '</title><style>body{font-family:Tahoma,Arial;font-size:12px}h2{text-align:center}table{border-collapse:collapse;width:100%}th,td{border:1px solid #bbb;padding:4px 6px;text-align:center}th{background:#e1ebff}</style></head><body><h2>كشف حساب المورد: ' + esc(d.name) + "</h2>" + ov.querySelector("table").outerHTML + "</body></html>");
        w.document.close(); w.focus(); setTimeout(function () { w.print(); }, 250);
      });
      ov.addEventListener("keydown", function (e) { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); } });
      ov.addEventListener("mousedown", function (e) { e.stopPropagation(); if (e.target === ov) close(); });
      ov.querySelector(".su-win").focus();
    }).catch(function (e) { say(e.message, "e"); });
  }

  // ------------------------------------------------------------------ الربط بالقوائم والرئيسية
  function find(list, t) { return (list || []).filter(function (x) { return x.t === t; })[0]; }
  var FEH = window.__FEH;
  if (FEH) {
    var it = find(FEH, "الموردين"); if (it) it.run = openReview;
    var g = find(FEH, "دليل العملاء و الموردين"); var a = g && find(g.sub, "إضافة مورد");
    if (a) a.run = function () { openReview(); setTimeout(function () { openForm(null); }, 60); };
  }
  // مربع «إضافة مورد» في الرئيسية: الضغط = مورد جديد، الشريط السفلي «مراجعة» = مراجعة الموردين
  var tile = document.querySelector('.ht[data-k="supp"]');
  if (tile) tile.addEventListener("keydown", function (e) {
    if (e.target === tile && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); e.stopImmediatePropagation(); openReview(); setTimeout(function () { openForm(null); }, 60); }
  }, true);
  if (tile) tile.addEventListener("click", function (e) {
    e.stopImmediatePropagation(); e.preventDefault();
    var b = e.target.closest(".ht-b");
    openReview();
    if (!b || b.dataset.sub !== "list") setTimeout(function () { openForm(null); }, 60);
  }, true);

  window.ANOUER_SUPPLIERS = { list: function () { return SUPS; }, form: function () { openForm(null); }, edit: function (id) { var r = SUPS.filter(function (x) { return x.id === id; })[0]; if (r) openForm(r); else load().then(function () { var q = SUPS.filter(function (x) { return x.id === id; })[0]; if (q) openForm(q); }); }, open: openReview, add: function () { openReview(); setTimeout(function () { openForm(null); }, 60); }, reload: load, statement: statement };
})();
