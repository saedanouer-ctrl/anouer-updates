/* ANOUER — «طباعة الباركود»: اختيار تصميم الملصق بالرقم (id) — مطابق لـ DEXEF ONE
   DEXEF (Dexef.Item › frmbarcodedesign.LoadBarcodeDesign):
     SELECT R.id, R.Name, R.ReportName FROM dbo.ReportDesign R WHERE R.ReportType='Barcode'
     CmbDesign = DexeflookupEdit (GridLookUpEdit) : DisplayMember=Name ، ValueMember=id ، أعمدة الشبكة id | Name | Report Name
     تكتب الرقم في الخانة ⇒ تُفلتر الشبكة ⇒ Enter ⇒ يُحمَّل الملصق للطباعة (وعند وجود تصميم واحد يُختار تلقائياً).
   ANOUER: نفس الشبكة بنفس الأرقام (dexId المنقولة من DEXEF) + لمسات 2026:
     • الرقم المطابق تماماً يُحدَّد فوراً وتتحدث المعاينة الحيّة قبل الضغط على Enter
     • شرائح «الأخيرة» لأكثر التصاميم استعمالاً ، تمييز النص المطابق ، تذكّر آخر تصميم
     • معاينة حيّة للملصق بالصنف الحالي (نفس محرّك «تصميم التقارير») مع المقاس بالملّيمتر */
(function () {
  "use strict";
  if (window.__BDZ) return;
  const $ = (s, r) => (r || document).querySelector(s);
  const E = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const LS = { get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} } };
  const RM = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
  const AN = s => String(s || "").toLowerCase().replace(/[أإآا]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/[ً-ْـ]/g, "").replace(/\s+/g, " ").trim();
  const RD = () => window.ANOUER_RD;

  const css = `
.bdz{position:relative;flex:1;min-width:0;display:flex;align-items:center;gap:6px;border-bottom:1px solid #b9c0c9;transition:border-color .15s,box-shadow .2s}
.bdz:focus-within{border-color:#1a8cff;box-shadow:0 1px 0 #1a8cff}
.bdz .pill{flex:0 0 auto;min-width:34px;height:22px;padding:0 7px;border-radius:7px;background:linear-gradient(180deg,#2f8ae3,#1f78d6);color:#fff;font:700 12px/22px Consolas,"Segoe UI",monospace;text-align:center;direction:ltr;box-shadow:0 2px 6px -2px rgba(31,120,214,.7);transition:transform .25s cubic-bezier(.3,1.6,.5,1)}
.bdz .pill.t{background:#eef1f5;color:#56616d;box-shadow:none;font-family:"Segoe UI",Tahoma}
.bdz .pill.pop{animation:bdzPop .4s cubic-bezier(.3,1.6,.5,1)}
@keyframes bdzPop{40%{transform:scale(1.22)}}
.bdz input{flex:1;min-width:0;border:0;background:none;padding:4px 2px;font:inherit;outline:0;direction:rtl}
.bdz input::placeholder{color:#9aa4ae}
.bdz .ar{width:18px;height:18px;flex:0 0 auto;display:grid;place-items:center;border:1px solid #c9cfd6;background:#e6e9ed;border-radius:3px;color:#444;cursor:pointer;font-size:9px;transition:background .15s,transform .25s}
.bdz .ar:hover{background:#d8dde3}
.bdz.open .ar{transform:rotate(180deg)}
.bdz-def{flex:0 0 auto;width:24px;height:22px;border:0;background:none;color:#1a6fd0;cursor:pointer;border-radius:5px;display:grid;place-items:center;transition:background .15s,color .15s,transform .25s}
.bdz-def:hover{background:#e7f1fd}.bdz-def.on{color:#16a34a}.bdz-def.pop{animation:bdzPop .45s cubic-bezier(.3,1.6,.5,1)}
.bdz-def:focus-visible{outline:2px solid #1a8cff;outline-offset:1px}
.bdz-dd{position:absolute;top:calc(100% + 3px);left:0;width:min(560px,92vw);background:#fff;border:1px solid #9aa4b0;box-shadow:0 18px 40px -12px rgba(15,23,42,.45),0 2px 6px rgba(0,0,0,.12);z-index:30;direction:rtl;display:none;transform-origin:top left;border-radius:3px;overflow:hidden}
.bdz-dd.show{display:block;animation:bdzIn .22s cubic-bezier(.2,1,.3,1)}
@keyframes bdzIn{from{opacity:0;transform:translateY(-6px) scale(.98)}}
.bdz-rc{display:flex;align-items:center;gap:6px;padding:7px 8px 5px;border-bottom:1px solid #eef1f4;flex-wrap:wrap;font-size:11.5px;color:#6b7684}
.bdz-rc b{font-weight:600;margin-inline-end:2px}
.bdz-rc button{height:24px;border:1px solid #d3e3f6;background:#f3f8ff;border-radius:12px;padding:0 9px 0 4px;font:12px "Segoe UI",Tahoma;color:#1d4f8f;cursor:pointer;display:inline-flex;align-items:center;gap:6px;max-width:170px;transition:background .15s,transform .1s}
.bdz-rc button:hover{background:#e3effd}.bdz-rc button:active{transform:scale(.96)}
.bdz-rc button i{font:700 11px Consolas,monospace;font-style:normal;background:#1f78d6;color:#fff;border-radius:9px;padding:1px 6px;direction:ltr}
.bdz-rc button span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bdz-h,.bdz-r{display:grid;grid-template-columns:22px 86px minmax(0,1fr) 150px 12px;align-items:center}
.bdz-h{gap:2px;padding:3px 3px 2px}
.bdz-h div{background:#dbe8f8;border-radius:3px;height:28px;display:flex;align-items:center;justify-content:center;font-size:12px;color:#222}
.bdz-h .c1{justify-content:flex-start;padding:0 8px}
.bdz-h div.e{background:#dbe8f8}
.bdz-l{max-height:300px;overflow-y:auto;scrollbar-width:thin}
.bdz-r{height:31px;border-bottom:1px solid #e6e9ed;cursor:pointer;font-size:12.5px;transition:background .12s}
.bdz-r:hover{background:#eef5fd}
.bdz-r>span{padding:0 8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;height:100%;display:flex;align-items:center}
.bdz-r .in{justify-content:center;color:#1a6fd0;padding:0}
.bdz-r .c1{direction:ltr;justify-content:flex-start;font:600 12.5px Consolas,"Segoe UI",monospace;border-inline-start:1px solid #e6e9ed;border-inline-end:1px solid #e6e9ed}
.bdz-r .c2{justify-content:center}
.bdz-r .c3{color:#6b7684;font-size:11.5px;justify-content:center;border-inline-start:1px solid #e6e9ed}
.bdz-r.sel{background:#0a78d1;color:#fff}
.bdz-r.sel .in{color:#fff}
.bdz-r.sel .c3{color:#dbeafe}
.bdz-r.sel .c1,.bdz-r.sel .c3{border-color:rgba(255,255,255,.35)}
.bdz-r mark{background:#ffe58f;color:inherit;border-radius:2px;padding:0 1px}
.bdz-r.sel mark{background:rgba(255,255,255,.3)}
.bdz-r.ex .c1:after{content:"✓";margin-inline-start:6px;font-size:11px;color:#16a34a}
.bdz-r.sel.ex .c1:after{color:#bbf7d0}
.bdz-r.g{height:24px;cursor:default;background:#f6f8fa;color:#6b7684;font-size:11px}
.bdz-r.g>span{grid-column:1/-1;justify-content:flex-start;padding:0 10px}
.bdz-rc button.au{border-color:transparent;background:linear-gradient(135deg,#fff0f8,#f1edff);color:#6d28d9;font-weight:700;box-shadow:0 0 0 1px rgba(124,92,255,.35)}
.bdz-rc button.au i{background:linear-gradient(135deg,#ff4fa3,#7c5cff 60%,#22d3ee);background-size:200% 200%;animation:bdzAu 3s ease infinite;font-family:"Segoe UI",Arial;letter-spacing:.5px}
.bdz-r.g.ga{background:linear-gradient(90deg,#fff4fb,#f3f0ff);color:#a21caf;font-weight:700}
.bdz-r.au .c1{color:#fff;font:800 11px "Segoe UI",Arial;letter-spacing:.6px}
.bdz-r.au .c1{background:linear-gradient(135deg,#ff4fa3,#7c5cff 60%,#22d3ee);background-size:200% 200%;animation:bdzAu 3s ease infinite;justify-content:center;border-radius:6px;margin:4px 6px;height:calc(100% - 8px);box-shadow:0 3px 10px -4px rgba(124,92,255,.8)}
.bdz-r.au .c2{font-weight:700;color:#5b21b6}.bdz-r.au.sel .c2{color:#fff}
@keyframes bdzAu{50%{background-position:100% 100%}}
.bdz .pill.au{background:linear-gradient(135deg,#ff4fa3,#7c5cff 60%,#22d3ee);background-size:200% 200%;animation:bdzAu 3s ease infinite;font-family:"Segoe UI",Arial;letter-spacing:.5px}
.bdz-none{padding:22px;text-align:center;color:#8a95a3;font-size:12.5px}
.bdz-f{display:flex;align-items:center;gap:12px;white-space:nowrap;border-top:1px solid #c5cbd2;padding:2px 8px;height:26px;background:#fafbfc;font-size:11px;color:#8a95a3}
.bdz-f .xx{color:#d22;cursor:pointer;font-size:12px;font-weight:700;padding:0 4px}
.bdz-f kbd{font:10.5px Arial;border:1px solid #d5dbe2;border-bottom-width:2px;border-radius:4px;padding:0 4px;background:#fff;color:#56616d}
.bdz-f .bdz-ht{flex:1;text-align:center;overflow:hidden;text-overflow:ellipsis}
.bdz-f .bdz-gr{flex:0 0 auto;display:block;min-height:0;cursor:ns-resize;letter-spacing:-2px;direction:ltr;user-select:none;touch-action:none;font-size:13px}
/* المعاينة الحيّة */
.bdv{width:236px;flex:0 0 236px;align-self:flex-start;margin-top:6px;border:1px solid #dfe4ea;border-radius:12px;background:#fff;box-shadow:0 10px 30px -18px rgba(15,23,42,.5);overflow:hidden;display:flex;flex-direction:column}
.bdv-h{display:flex;align-items:center;gap:8px;padding:9px 12px;border-bottom:1px solid #eef1f4;background:linear-gradient(#fbfcfd,#f4f6f9)}
.bdv-h b{font-size:12.5px;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bdv-h i{font:700 11px Consolas,monospace;font-style:normal;background:#1f78d6;color:#fff;border-radius:7px;padding:2px 7px;direction:ltr}
.bdv-h i.t{background:#eef1f5;color:#56616d}
.bdv-s{position:relative;height:210px;background:repeating-conic-gradient(#f3f5f8 0 25%,#fff 0 50%) 0 0/14px 14px;display:grid;place-items:center;overflow:hidden}
.bdv-s .fr{position:absolute;top:0;left:0;border:0;background:#fff;transform-origin:0 0;box-shadow:0 6px 18px -6px rgba(15,23,42,.45);pointer-events:none;transition:opacity .25s}
.bdv-s .fr.ld{opacity:0}
.bdv-s .sk{position:absolute;inset:16px;border-radius:8px;background:linear-gradient(90deg,#eef1f5 25%,#f8fafc 50%,#eef1f5 75%);background-size:200% 100%;animation:bdvSk 1.1s linear infinite}
@keyframes bdvSk{to{background-position:-200% 0}}
.bdv-s .em{color:#8a95a3;font-size:12px;text-align:center;padding:14px}
.bdv-f{display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:8px 12px;border-top:1px solid #eef1f4;font-size:11.5px;color:#56616d}
.bdv-f span{background:#f4f6f9;border:1px solid #e6eaef;border-radius:8px;padding:2px 8px}
.bdv-f b{font-family:Arial;color:#1d2731}
@media (prefers-reduced-motion:reduce){.bdz *,.bdv *,.bdz-dd{animation:none!important;transition:none!important}}
`;

  /* ---------- قائمة التصاميم ---------- */
  let LIST = [];                 // {key, id, name, rep, it?, tplIdx?}
  async function loadList() {
    const sel = $("#bcpTpl"); const out = [];
    let rd = [];
    try { if (RD() && RD().labelDesigns) rd = await RD().labelDesigns(); } catch (_) {}
    // أرقام ثابتة: رقم DEXEF (dexId) ، وللتصاميم الجديدة رقم يُحجز مرة واحدة
    let max = 0, dirty = false; rd.forEach(i => { max = Math.max(max, +i.dexId || 0, +i.num || 0); });
    rd.forEach(i => { if (!(+i.dexId) && !(+i.num)) { i.num = ++max; dirty = true; } });
    if (dirty) { try { RD().saveIdx(); } catch (_) {} }
    rd.slice().sort((a, b) => (+(a.dexId || a.num) - +(b.dexId || b.num))).forEach(i => out.push({ key: "rd:" + i.id, id: String(+(i.dexId || i.num)), name: i.name || "", rep: i.reportName || i.rname || "", it: i, def: !!i.def }));
    if (sel) [...sel.querySelectorAll(":scope > option")].forEach((o, k) => out.push({ key: o.value, id: "ق" + (k + 1), name: o.textContent, rep: "قالب ANOUER", tpl: true }));
    /* ✨ AUTO — تيكت ذكي تلقائي لكل صنف (أول القائمة) */
    /* 🏷️ تيكت العروض A5 — 3 تصاميم (bc-offer.js) */
    if (window.__BCO) out.unshift.apply(out, __BCO.STYLES.map(x => ({ key: x.k, id: x.id, name: x.name, rep: "ANOUER عروض A5 · 2026", off: true })));
    if (window.__BCA) out.unshift({ key: "auto", id: "AUTO", name: "✨ تيكت ذكي تلقائي لكل صنف", rep: "ANOUER AUTO 2026", auto: true });
    LIST = out;
    // تأكد أن كل تصميم موجود كخيار في القائمة الأصلية (تُستخدم في الطباعة)
    if (sel && window.__BCA && !sel.querySelector('option[value="auto"]')) { const o = document.createElement("option"); o.value = "auto"; o.textContent = "AUTO"; sel.insertBefore(o, sel.firstChild); }
    if (sel && window.__BCO) __BCO.STYLES.slice().reverse().forEach(x => { if (!sel.querySelector(`option[value="${x.k}"]`)) { const o = document.createElement("option"); o.value = x.k; o.textContent = x.name; sel.insertBefore(o, sel.firstChild.nextSibling || null); } });
    if (sel) {
      let og = sel.querySelector("optgroup[data-rd]");
      rd.forEach(i => { if (!sel.querySelector(`option[value="rd:${CSS.escape(i.id)}"]`)) { if (!og) { og = document.createElement("optgroup"); og.label = "تصاميم الباركود"; og.dataset.rd = "1"; sel.appendChild(og); } const o = document.createElement("option"); o.value = "rd:" + i.id; o.textContent = i.name; og.appendChild(o); } });
    }
    return out;
  }
  const byKey = k => LIST.find(x => x.key === k);

  /* ---------- الحالة ---------- */
  const S = { cur: null, hi: 0, rows: [], q: "", open: false, prevKey: null, pv: 0 };
  const recent = () => (LS.get("bcp.recent", []) || []).map(byKey).filter(Boolean).slice(0, 6);
  function remember(k) { const r = (LS.get("bcp.recent", []) || []).filter(x => x !== k); r.unshift(k); LS.set("bcp.recent", r.slice(0, 8)); LS.set("bcp.design", k); }

  /* ---------- البناء ---------- */
  function build() {
    if ($("#bdz")) return true;
    const sel = $("#bcpTpl"); if (!sel) return false;
    if (!$("#bdzStyle")) { const st = document.createElement("style"); st.id = "bdzStyle"; st.textContent = css; document.head.appendChild(st); }
    sel.style.display = "none";
    const w = document.createElement("div"); w.className = "bdz"; w.id = "bdz";
    w.innerHTML = `<span class="pill t" id="bdzId">—</span><input id="bdzIn" type="text" autocomplete="off" spellcheck="false" placeholder="رقم التصميم (id) أو اسمه…" title="اكتب رقم التصميم (id) ثم Enter — مثل DEXEF" role="combobox" aria-expanded="false" aria-controls="bdzDd" aria-autocomplete="list"><span class="ar" id="bdzAr" title="قائمة التصاميم">&#9660;</span><button type="button" class="bdz-def" id="bdzDef" title="جعل التصميم هو التصميم الافتراضي" aria-label="جعل التصميم هو التصميم الافتراضي"><svg width="14" height="14" viewBox="0 0 14 14"><path d="M2.5 7.4l3 3 6-6.6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
<div class="bdz-dd" id="bdzDd" role="listbox"><div class="bdz-rc" id="bdzRc"></div><div class="bdz-h"><div class="e"></div><div class="c1">id</div><div>Name</div><div>Report Name</div><div class="e"></div></div><div class="bdz-l" id="bdzL"></div>
<div class="bdz-f"><span class="xx" id="bdzX" title="إغلاق">&#10005;</span><span id="bdzCnt"></span><span class="bdz-ht">اكتب الرقم ثم <kbd>Enter</kbd></span><span class="bdz-gr" id="bdzGr" title="تغيير الحجم">&#8942;&#8942;</span></div></div>`;
    sel.parentNode.insertBefore(w, sel);
    const inp = $("#bdzIn");
    inp.addEventListener("input", () => { S.q = inp.value; filter(); show(); });
    // أول حرف بعد التركيز يستبدل الاسم المعروض (اكتب الرقم مباشرة)
    inp.addEventListener("focus", () => { S.fresh = true; setTimeout(() => { if (document.activeElement === inp && S.fresh) inp.select(); }, 0); });
    inp.addEventListener("mouseup", () => { if (S.fresh) inp.select(); });
    inp.addEventListener("keydown", e => {
      if (S.fresh && e.key && e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey) inp.value = "";
      if (e.key !== "Shift") S.fresh = false;
      if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); e.stopPropagation(); if (!S.open) { S.q = ""; filter(); show(); } else move(e.key === "ArrowDown" ? 1 : -1); return; }
      if (e.key === "PageDown" || e.key === "PageUp") { e.preventDefault(); move(e.key === "PageDown" ? 8 : -8); return; }
      if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); if (S.open) commit(S.rows[S.hi]); else { S.q = ""; filter(); show(); } return; }
      if (e.key === "Escape" && S.open) { e.preventDefault(); e.stopPropagation(); revert(); hide(); return; }
      if (e.key === "Tab" && S.open) { const ex = exact(); if (ex) commit(ex, true); else { revert(); hide(); } }
    });
    inp.addEventListener("blur", () => setTimeout(() => { if (!S.open || w.contains(document.activeElement)) return; const ex = exact(); if (ex) commit(ex, true); else { revert(); hide(); } }, 120));
    $("#bdzAr").addEventListener("mousedown", e => { e.preventDefault(); if (S.open) { revert(); hide(); } else { inp.focus(); S.q = ""; filter(); show(); } });
    $("#bdzX").onclick = () => { revert(); hide(); };
    /* ✓ «جعل التصميم هو التصميم الافتراضي» (CmbDesign.Buttons[1] في DEXEF) */
    $("#bdzDef").onclick = () => {
      const x = S.cur; if (!x) return;
      if (x.it) { try { const idx = RD().idx(); idx.items.forEach(i => { if (i.kind === "bc") i.def = i.id === x.it.id; }); RD().saveIdx(); } catch (_) {} LIST.forEach(i => i.def = i === x); }
      LS.set("bcp.design", x.key); showCur();
      const b = $("#bdzDef"); b.classList.remove("pop"); void b.offsetWidth; b.classList.add("pop");
      try { (window.__bcpToast || window.toast)("«" + x.name + "» هو التصميم الافتراضي للباركود", "s"); } catch (_) {}
    };
    $("#bdzL").addEventListener("mousedown", e => { const r = e.target.closest(".bdz-r[data-k]"); if (!r) return; e.preventDefault(); commit(byKey(r.dataset.k)); });
    $("#bdzL").addEventListener("mousemove", e => { const r = e.target.closest(".bdz-r[data-i]"); if (r && +r.dataset.i !== S.hi) { S.hi = +r.dataset.i; paintSel(false); } });
    $("#bdzRc").addEventListener("mousedown", e => { const b = e.target.closest("button[data-k]"); if (!b) return; e.preventDefault(); commit(byKey(b.dataset.k)); });
    document.addEventListener("mousedown", e => { if (S.open && !w.contains(e.target)) { const ex = exact(); if (ex) commit(ex, true); else { revert(); hide(); } } }, true);
    { const gr = $("#bdzGr"), l = $("#bdzL"); gr.addEventListener("pointerdown", e => { const y0 = e.clientY, h0 = l.offsetHeight; gr.setPointerCapture(e.pointerId);
      const mv = ev => { l.style.maxHeight = Math.min(Math.max(h0 + ev.clientY - y0, 90), 520) + "px"; }; const up = () => { gr.removeEventListener("pointermove", mv); gr.removeEventListener("pointerup", up); }; gr.addEventListener("pointermove", mv); gr.addEventListener("pointerup", up); e.preventDefault(); }); }
    // Esc داخل القائمة لا يغلق نافذة الباركود
    window.addEventListener("keydown", e => { if (e.key === "Escape" && S.open && document.activeElement === inp) { e.preventDefault(); e.stopImmediatePropagation(); revert(); hide(); } }, true);
    buildPreview();
    return true;
  }

  /* ---------- البحث بالرقم أو الاسم ---------- */
  function exact() { const q = S.q.trim(); if (!q) return null; return LIST.find(x => x.id === q || (x.auto && /^auto$/i.test(q))) || null; }
  function filter() {
    const q = S.q.trim(), dig = /^\d+$/.test(q), nq = AN(q);
    let rows;
    if (!q) rows = LIST.slice();
    else if (dig) {
      const byId = LIST.filter(x => x.id.startsWith(q)).sort((a, b) => (a.id === q ? -1 : b.id === q ? 1 : a.id.length - b.id.length || +a.id - +b.id));
      const byNm = LIST.filter(x => !x.id.startsWith(q) && AN(x.name).includes(nq));
      rows = byId.concat(byNm);
    } else rows = LIST.filter(x => AN(x.name).includes(nq) || AN(x.rep).includes(nq) || AN(x.id).includes(nq));
    S.rows = rows;
    const ci = S.cur ? rows.indexOf(S.cur) : -1;
    S.hi = q ? 0 : (ci >= 0 ? ci : 0);
    paint();
    // الرقم المطابق تماماً: معاينة فورية قبل Enter
    const ex = exact(); if (ex) preview(ex);
  }
  function hl(t, q) {
    t = String(t || ""); q = q.trim(); if (!q) return E(t);
    const a = AN(t), b = AN(q), i = a.indexOf(b);
    if (i < 0 || a.length !== t.toLowerCase().length) { const j = t.toLowerCase().indexOf(q.toLowerCase()); return j < 0 ? E(t) : E(t.slice(0, j)) + "<mark>" + E(t.slice(j, j + q.length)) + "</mark>" + E(t.slice(j + q.length)); }
    return E(t.slice(0, i)) + "<mark>" + E(t.slice(i, i + b.length)) + "</mark>" + E(t.slice(i + b.length));
  }
  function paint() {
    const L = $("#bdzL"), q = S.q.trim(), dig = /^\d+$/.test(q);
    if (!S.rows.length) { L.innerHTML = `<div class="bdz-none">لا يوجد تصميم بالرقم أو الاسم «${E(q)}»</div>`; }
    else {
      let h = "", grp = null;
      S.rows.forEach((x, i) => {
        const g = x.auto ? "a" : x.off ? "o" : x.tpl ? "t" : "d"; if (!q && g !== grp) { h += `<div class="bdz-r g${g === "a" || g === "o" ? " ga" : ""}"><span>${g === "a" ? "✨ ANOUER AUTO — بدون إعداد" : g === "o" ? "🏷️ تيكت العروض A5 — سوبرماركت 2026" : g === "t" ? "قوالب ANOUER العامة" : "تصاميم الباركود (DEXEF / تصميم التقارير)"}</span></div>`; grp = g; }
        const idH = dig && x.id.startsWith(q) ? "<mark>" + E(q) + "</mark>" + E(x.id.slice(q.length)) : E(x.id);
        h += `<div class="bdz-r${x.auto ? " au" : ""}${i === S.hi ? " sel" : ""}${q && x.id === q ? " ex" : ""}" data-i="${i}" data-k="${E(x.key)}" role="option" aria-selected="${i === S.hi}" title="${E(x.name)}"><span class="in">${i === S.hi ? "&#8592;" : ""}</span><span class="c1">${idH}${x.def ? ' <small style="opacity:.7">✔</small>' : ""}</span><span class="c2">${dig ? E(x.name) : hl(x.name, q)}</span><span class="c3">${E(x.rep)}</span><span></span></div>`;
      });
      L.innerHTML = h;
    }
    $("#bdzCnt").textContent = q ? `${S.rows.length} من ${LIST.length}` : `${LIST.length} تصميم`;
    const rc = recent().filter(x => !x.auto), au = LIST.find(x => x.auto);
    /* AUTO دائماً أول شريحة (ظاهرة حتى لو كانت القائمة منزّلة على تصميم آخر) */
    $("#bdzRc").innerHTML = (rc.length || au) && !q ? (au ? `<button type="button" class="au" data-k="auto" title="${E(au.name)}"><i>AUTO</i><span>تيكت ذكي لكل صنف</span></button>` : "") + (rc.length ? `<b>الأخيرة</b>` + rc.map(x => `<button type="button" data-k="${E(x.key)}" title="${E(x.name)}"><i>${E(x.id)}</i><span>${E(x.name)}</span></button>`).join("") : "") : "";
    $("#bdzRc").style.display = (rc.length || au) && !q ? "" : "none";
    scrollSel();
  }
  function paintSel(scroll) {
    $("#bdzL").querySelectorAll(".bdz-r[data-i]").forEach(r => { const on = +r.dataset.i === S.hi; r.classList.toggle("sel", on); r.setAttribute("aria-selected", on); r.querySelector(".in").innerHTML = on ? "&#8592;" : ""; });
    if (scroll !== false) scrollSel();
  }
  function scrollSel() { const r = $(`#bdzL .bdz-r[data-i="${S.hi}"]`); if (r) r.scrollIntoView({ block: "nearest" }); }
  function move(n) { if (!S.rows.length) return; S.hi = Math.max(0, Math.min(S.rows.length - 1, S.hi + n)); paintSel(); preview(S.rows[S.hi]); }
  function show() { if (S.open) return; S.open = true; S.prevKey = S.cur && S.cur.key; $("#bdzDd").classList.add("show"); $("#bdz").classList.add("open"); $("#bdzIn").setAttribute("aria-expanded", "true"); scrollSel(); }
  function hide() { S.open = false; const d = $("#bdzDd"); if (d) d.classList.remove("show"); const w = $("#bdz"); if (w) w.classList.remove("open"); const i = $("#bdzIn"); if (i) i.setAttribute("aria-expanded", "false"); }
  function revert() { S.q = ""; showCur(); if (S.cur) preview(S.cur); }

  /* ---------- الاختيار ---------- */
  function showCur(pop) {
    const x = S.cur, inp = $("#bdzIn"), pill = $("#bdzId");
    const db = $("#bdzDef"); if (db) { db.classList.toggle("on", !!(x && x.def)); db.title = x && x.def ? "هذا هو التصميم الافتراضي" : "جعل التصميم هو التصميم الافتراضي"; }
    inp.value = x ? x.name : ""; S.fresh = true; if (document.activeElement === inp) inp.select(); pill.textContent = x ? x.id : "—"; pill.classList.toggle("t", !x || !!x.tpl); pill.classList.toggle("au", !!(x && x.auto));
    if (pop && !RM()) { pill.classList.remove("pop"); void pill.offsetWidth; pill.classList.add("pop"); }
  }
  function commit(x, silent) {
    if (!x) return;
    S.cur = x; S.q = ""; hide(); showCur(true); remember(x.key);
    const sel = $("#bcpTpl");
    if (sel && sel.value !== x.key) { sel.value = x.key; sel.dispatchEvent(new Event("change", { bubbles: true })); }
    preview(x);
    if (!silent) { const n = $("#bcpCnt") || $("#bcpNm"); /* يبقى التركيز في خانة التصميم للطباعة السريعة */ }
  }
  function applySaved() {
    const sel = $("#bcpTpl"), k = (sel && sel.value && String(sel.value).startsWith("rd:")) ? sel.value : LS.get("bcp.design", null);
    let x = (k && byKey(k)) || LIST.find(i => i.def) || null;
    if (!x && LIST.filter(i => !i.tpl).length === 1) x = LIST.find(i => !i.tpl);   // DEXEF: تصميم واحد ⇒ يُختار تلقائياً
    if (!x && sel) x = byKey(sel.value) || LIST.find(i => i.tpl);
    if (x) { S.cur = x; if (sel && sel.value !== x.key) { sel.value = x.key; sel.dispatchEvent(new Event("change", { bubbles: true })); } }
    showCur(); preview(S.cur);
  }

  /* ---------- المعاينة الحيّة ---------- */
  function buildPreview() {
    const bd = $("#bcpOv .bcp-bd"); if (!bd || $("#bdv")) return;
    const v = document.createElement("aside"); v.className = "bdv"; v.id = "bdv"; v.setAttribute("aria-label", "معاينة الملصق");
    v.innerHTML = `<div class="bdv-h"><b id="bdvN">معاينة الملصق</b><i id="bdvI" class="t">—</i></div><div class="bdv-s" id="bdvS"><div class="em">اختر تصميماً لعرض الملصق</div></div><div class="bdv-f" id="bdvF"></div>`;
    bd.appendChild(v);
    // تحديث المعاينة عند تغيّر الصنف/السعر/النوع/التبويب
    let t = null; const kick = () => { clearTimeout(t); t = setTimeout(() => preview(S.cur), 220); };
    const ov = $("#bcpOv");
    ov.addEventListener("input", e => { if (e.target.closest("#bdz")) return; kick(); });
    ov.addEventListener("change", e => { if (e.target.closest("#bdz") || e.target.id === "bcpTpl") return; kick(); });
    ov.addEventListener("click", e => { if (e.target.closest("#bcpNav .bcp-t,#bcpNav .t,.bcp-dr,.bcp-brw,.bsi-r,[data-del]")) kick(); });
    ov.addEventListener("mousedown", e => { if (e.target.closest(".bcp-dr")) setTimeout(kick, 30); });
  }
  function sampleJob() {
    try { const j = window.__bcpSample && window.__bcpSample(); if (j) return j; } catch (_) {}
    const P = window.products || (typeof products !== "undefined" ? products : []);
    const m = ($("#bcpNav .t.on") || {}).dataset ? $("#bcpNav .t.on").dataset.m : "item";
    if (m === "man") { const c = ($("#bcpMb") || {}).value; if (c) return { name: ($("#bcpMn") || {}).value || "", code: c, price: +(($("#bcpPr") || {}).value) || 0, n: 1 }; }
    if (m === "inv" || m === "sel") { const tr = $("#bcpA tr[data-id]"); if (tr) { const p = P.find(x => String(x.id) === tr.dataset.id); if (p) return { name: p.name, code: String(p.code), price: p.price, n: 1 }; } }
    const nm = ($("#bcpNm") || {}).value, p = nm && P.find(x => x.name === nm.trim());
    if (p) return { name: p.name, code: ($("#bcpBc") || {}).value || String(p.code), price: +(($("#bcpPr") || {}).value) || p.price || 0, n: 1 };
    const q = P.find(x => x.code && x.price > 0) || {};
    return { name: q.name || "اسم الصنف", code: String(q.code || "6130000000017"), price: q.price || 120, n: 1, sample: true };
  }
  async function preview(x) {
    const S2 = $("#bdvS"); if (!S2) return;
    const tok = ++S.pv;
    $("#bdvN").textContent = x ? x.name : "معاينة الملصق"; const ii = $("#bdvI"); ii.textContent = x ? x.id : "—"; ii.className = x && !x.tpl ? "" : "t";
    const F = $("#bdvF");
    if (!x) { S2.innerHTML = '<div class="em">اختر تصميماً لعرض الملصق</div>'; F.innerHTML = ""; return; }
    const job = sampleJob();
    if ((x.auto && window.__BCA) || (x.off && window.__BCO)) {
      if (!S2.querySelector(".fr")) S2.innerHTML = '<div class="sk"></div>';
      try {
        const o = x.off ? await __BCO.one(job, x.key) : await __BCA.one(job); if (tok !== S.pv) return;
        const html = `<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;overflow:hidden;background:#fff}</style></head><body>${o.html}</body></html>`;
        const fr = document.createElement("iframe"); fr.className = "fr ld"; fr.setAttribute("sandbox", "allow-same-origin"); fr.setAttribute("aria-hidden", "true"); fr.tabIndex = -1;
        fr.onload = () => { if (tok !== S.pv) { fr.remove(); return; } try { const b = fr.contentDocument.documentElement, pg = fr.contentDocument.querySelector(".rdp"), W = Math.max(pg ? pg.offsetWidth : b.scrollWidth, 40), H = Math.max(pg ? pg.offsetHeight : b.scrollHeight, 30); fr.style.width = W + "px"; fr.style.height = H + "px"; const k = Math.min((S2.clientWidth - 24) / W, (S2.clientHeight - 24) / H, 3); fr.style.transform = `translate(${(S2.clientWidth - W * k) / 2}px,${(S2.clientHeight - H * k) / 2}px) scale(${k})`; } catch (_) {} [...S2.children].forEach(c => { if (c !== fr) c.remove(); }); requestAnimationFrame(() => fr.classList.remove("ld")); };
        S2.appendChild(fr); fr.srcdoc = html;
        if (x.off) { F.innerHTML = `<span>A5 <b>148×210</b> مم</span><span>${o.info.pct ? "تخفيض −" + o.info.pct + "%" : /^offa5:[789]$/.test(x.key) ? "اكتب سعر 5 ومافوق في السطر" : "اكتب سعر العرض في السطر"}</span>${job.sample ? "<span>بيانات تجريبية</span>" : ""}`; } else
        F.innerHTML = `<span>الملصق <b>${o.sz.w}×${o.sz.h}</b> مم</span>${o.sz.from ? `<span title="نفس مقاس وطابعة هذا التصميم">مقاس #${E(o.sz.from)}</span>` : ""}<span>${o.info.single ? "وحدة واحدة" : "قطعة + " + E(o.info.big)}</span>${job.sample ? "<span>بيانات تجريبية</span>" : ""}`;
      } catch (e) { if (tok === S.pv) S2.innerHTML = '<div class="em">تعذّرت المعاينة</div>'; }
      return;
    }
    if (x.tpl) {
      const m = /(\d+)\s*أعمدة\s*×\s*(\d+)/.exec(x.name), c = m ? +m[1] : 1, r = m ? +m[2] : 1;
      const cells = Array.from({ length: Math.min(c * r, 48) }, (_, i) => `<div style="border:1px dashed #cfd6de;border-radius:2px;display:grid;place-items:center;font:7px Arial;color:#98a2ae">${i === 0 ? "▮▮▯▮" : ""}</div>`).join("");
      S2.innerHTML = `<div style="width:${c === 1 ? 150 : 128}px;height:${c === 1 ? 90 : 180}px;background:#fff;box-shadow:0 6px 18px -6px rgba(15,23,42,.45);display:grid;grid-template-columns:repeat(${c},1fr);grid-template-rows:repeat(${r},1fr);gap:2px;padding:5px">${cells}</div>`;
      F.innerHTML = `<span>قالب عام</span><span><b>${c}×${r}</b> ملصق</span>`; return;
    }
    if (!RD() || !RD().getDesign || !RD().render || !RD().docHTML) { S2.innerHTML = '<div class="em">محرّك التصاميم غير متاح</div>'; return; }
    if (!S2.querySelector(".fr")) S2.innerHTML = '<div class="sk"></div>';
    try {
      const [d, co] = await Promise.all([RD().getDesign(x.it), RD().company ? RD().company().catch(() => ({})) : {}]);
      if (tok !== S.pv) return;
      if (!d) { S2.innerHTML = '<div class="em">تعذّر تحميل التصميم</div>'; return; }
      const items = RD().labelItems ? RD().labelItems([job]) : [{ "Item Name": job.name, Barcode: job.code, "Item Code": job.code, Price: job.price, copies: 1 }];
      items.forEach(i => i.copies = 1);
      const res = RD().render(d, { company: co || {}, header: { "Print Date": new Date().toISOString().slice(0, 10) }, items }, { keepIndex: true });
      if (res && res.pages && res.pages.length > 1) res.pages = res.pages.slice(0, 1);
      const html = RD().docHTML(res, x.name).replace("</head>", "<style>html,body{overflow:hidden!important;background:#fff}</style></head>");
      const fr = document.createElement("iframe"); fr.className = "fr ld"; fr.setAttribute("sandbox", "allow-same-origin"); fr.setAttribute("aria-hidden", "true"); fr.tabIndex = -1;
      fr.onload = () => {
        if (tok !== S.pv) { fr.remove(); return; }
        try {
          const b = fr.contentDocument.documentElement, W = Math.max(b.scrollWidth, 40), H = Math.max(b.scrollHeight, 30);
          fr.style.width = W + "px"; fr.style.height = H + "px";
          const k = Math.min((S2.clientWidth - 24) / W, (S2.clientHeight - 24) / H, 3);
          fr.style.transform = `translate(${(S2.clientWidth - W * k) / 2}px,${(S2.clientHeight - H * k) / 2}px) scale(${k})`;
        } catch (_) {}
        [...S2.children].forEach(c => { if (c !== fr) c.remove(); });
        requestAnimationFrame(() => fr.classList.remove("ld"));
      };
      S2.appendChild(fr); fr.srcdoc = html;
      const w = res && res.w, h = res && (res.roll ? null : res.h), lab = d.label || {};
      const mm = v => Math.round(v * 10) / 10;
      F.innerHTML = (lab.w ? `<span>الملصق <b>${mm(lab.w)}×${mm(lab.h)}</b> مم</span>` : w ? `<span>المقاس <b>${mm(w)}${h ? "×" + mm(h) : ""}</b> مم</span>` : "")
        + (x.it && x.it.printer ? `<span title="الطابعة">🖨 ${E(x.it.printer)}</span>` : "")
        + (job.sample ? `<span>بيانات تجريبية</span>` : `<span>${E(job.name).slice(0, 26)}</span>`);
    } catch (e) { if (tok === S.pv) S2.innerHTML = '<div class="em">تعذّرت المعاينة</div>'; }
  }

  /* ---------- الربط بنافذة الباركود ---------- */
  const orig = window.bcpOpen;
  if (typeof orig !== "function") return;
  window.bcpOpen = function () {
    const r = orig.apply(this, arguments);
    if (!build()) return r;
    loadList().then(() => { applySaved(); if (S.open) filter(); });
    return r;
  };
  window.__BDZ = { state: S, list: () => LIST, commit: k => commit(byKey(k)), filter: q => { S.q = q; filter(); } };
})();
