/* ANOUER — «ربط المتجر الإلكتروني» (دكّان فريدون)
   ملف ← ربط المتجر الإلكتروني:
   • الربط مرة واحدة: رابط المتجر + رمز دخول الإدارة ← مفتاح ربط دائم (لا يُحفظ الرمز).
   • الطلبيات الجديدة من المتجر ← «فاتورة مبيعات» بضغطة (الأصناف بالكود/الباركود ، الكمية بالقطعة ، اسم وهاتف الزبون) ثم تُعلَّم «مستوردة».
   • مزامنة الأسعار والمخزون من ANOUER إلى المتجر مع معاينة الفروقات قبل الإرسال (سعر القطعة / سعر الكرتونة / المخزون).
   • QR المتجر للطباعة (على الواجهة ، الكاشير ، أكياس الزبائن).
   • متابعة تلقائية: تنبيه عند وصول طلبية جديدة (كل دقيقتين). */
(function () {
  "use strict";
  if (window.ANOUER_STORE) return;
  const X = () => window.__FMX;
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const call = (a, p) => Anouer.call(a, p || {});
  const T = (m, k) => { try { toast(m, k || "i"); } catch (e) { console.log(m); } };
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmt = n => (Math.round((+n || 0) * 100) / 100).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/ | /g, " ");
  const snd = k => { try { if (window.ANOUER_SOUND) ANOUER_SOUND(k); } catch (e) { } };
  const P = () => { try { return typeof products !== "undefined" ? products : []; } catch (e) { return []; } };
  const ck = v => String(v == null ? "" : v).replace(/[٠-٩]/g, c => c.charCodeAt(0) - 1632).replace(/\s/g, "").toLowerCase();
  const I = {
    store: '<svg viewBox="0 0 20 20"><path d="M2 7.5l1.6-5h12.8L18 7.5" fill="#f7941d"/><path d="M2 7.5h16v1.2a2.6 2.6 0 0 1-5.3 0 2.6 2.6 0 0 1-5.4 0A2.6 2.6 0 0 1 2 8.7z" fill="#e2760a"/><rect x="3" y="10.5" width="14" height="8" rx="1" fill="#1f7ad8"/><rect x="8" y="13" width="4" height="5.5" fill="#fff"/></svg>',
    link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/></svg>',
    cart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h2l2.4 11h10.2L20 7H6.2"/><circle cx="9" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/></svg>',
    sync: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 0 1-14.3 4.9M4 12A8 8 0 0 1 18.3 7.1"/><path d="M18.5 3v4.3h-4.3M5.5 21v-4.3h4.3"/></svg>',
    qr: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v.01M17 20h4M20 17v4"/></svg>',
    open: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
    mir: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="4" width="7.5" height="16" rx="1.6"/><rect x="14" y="4" width="7.5" height="16" rx="1.6"/><path d="M5 9h2.5M5 12.5h2.5M16.5 9H19M16.5 12.5H19M11 15.5h2M12 14.5v2"/></svg>',
    inv: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M6 2.5h9l3.5 3.5v15.5H6z"/><path d="M9 10h6M9 13.5h6M9 17h4"/></svg>'
  };
  const S = { flv: {}, url: "", key: "", adm: "", auto: true, invQr: true, seen: null, timer: 0, win: null };
  try { if (!document.getElementById("slFlvCss")) { const c = document.createElement("style"); c.id = "slFlvCss"; c.textContent = ".sl-flv{display:block;margin-top:3px;font-size:11px;font-weight:700;color:#b45309;white-space:nowrap}"; document.head.appendChild(c); } } catch (e) { }
  const resetPrintCache = () => { try { if (window.ANOUER_RD && ANOUER_RD.resetCompany) ANOUER_RD.resetCompany(); } catch (e) { } };

  /* ---------------------------------------------------------------- الإعدادات */
  function loadSettings() {
    if (!HOST()) return Promise.resolve();
    return call("fm.settings.get", { prefix: "Store." }).then(s => {
      s = s || {}; S.url = (s["Store.Url"] || "").replace(/\/+$/, ""); S.key = s["Store.Key"] || ""; S.auto = s["Store.Auto"] !== "0"; S.invQr = s["Store.Qr"] !== "0"; S.adm = s["Store.Adm"] || ""; try { S.flv = JSON.parse(s["Store.FlvSig"] || "{}") || {}; } catch (e) { S.flv = {}; }
    }).catch(() => { });
  }
  const saveSettings = v => call("fm.settings.set", { values: v });

  /* ---------------------------------------------------------------- الاتصال بالمتجر */
  function api(path, opt) {
    opt = opt || {};
    const h = { "X-Anouer-Key": S.key };
    if (opt.body !== undefined) h["Content-Type"] = "application/json";
    const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), opt.timeout || 25000);
    return fetch(S.url + path, { method: opt.method || (opt.body !== undefined ? "POST" : "GET"), headers: h, body: opt.body !== undefined ? JSON.stringify(opt.body) : undefined, signal: ctl.signal, cache: "no-store" })
      .then(r => r.json().catch(() => ({})).then(d => { clearTimeout(t); if (!r.ok) { const e = new Error((d && d.error) || ("HTTP " + r.status)); e.code = d && d.code; e.status = r.status; throw e; } return d; }))
      .catch(e => { clearTimeout(t); if (e.name === "AbortError") throw new Error("المتجر لا يرد (تحقق من الإنترنت)"); if (e instanceof TypeError) throw new Error("تعذّر الوصول إلى المتجر — تحقق من الرابط والإنترنت"); throw e; });
  }
  function normUrl(u) {
    u = String(u || "").trim();
    if (!u) return "";
    if (!/^https?:\/\//i.test(u)) u = "https://" + u;
    try { const x = new URL(u); return x.origin; } catch (e) { return ""; }
  }

  /* ---------------------------------------------------------------- مطابقة الأصناف */
  function findLocal(it) {
    const keys = [it.code, it.barcode, it.id].map(ck).filter(Boolean);
    if (!keys.length) return null;
    const ps = P();
    for (const k of keys) {
      const p = ps.find(x => ck(x.code) === k) || ps.find(x => (x._u || []).some(u => u && [u.bc].concat(u.xb || []).some(b => b && ck(b) === k)));
      if (p) return p;
    }
    return null;
  }
  const baseUnit = p => { const us = (p && p._u) || []; return us.find(u => u && (+u.factor || 1) === 1) || (p && p._d) || { name: (p && p.unit) || "قطعة", factor: 1, price: p && p.price }; };
  const unitOfFactor = (p, f) => f > 1 ? ((p && p._u) || []).find(u => u && +u.factor === f) || null : null;
  const stockOf = p => { try { if (typeof SWQ === "function") return +SWQ(p) || 0; } catch (e) { } return +(p && p.stock) || 0; };
  /* ---------------------------------------------------------------- «الأذواق» في المتجر
     العائلة في ANOUER (نفس الاسم + نفس السعر + ذوق مختلف — flavors.js) ← صنف واحد في المتجر:
     • «القائد» (له صورة حقيقية في المتجر إن أمكن) يحمل اسم العائلة + قائمة الأذواق (flavors) + الرصيد المشترك
     • باقي الأذواق تُخفى من المتجر (بلا حذف) — ترجع وحدها إذا انفصلت العائلة (سعر مختلف / إيقاف التجميع)
     • الطلبية: ذوق مختار ← الصنف بالضبط؛ بدون ذوق ← العائلة (تُوزّع الكمية حسب الأرصدة عند الحفظ مثل البيع) */
  const FLV = () => { try { const f = window.ANOUER_FLV; return f && f.cfg && f.cfg().on ? f : null; } catch (e) { return null; } };
  const flvN = v => String(v || "").toLowerCase().replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/[\s+،,\/|&·]+/g, "");
  const famOf = p => { const f = FLV(); if (!f || !p) return null; try { return f.groupOf(p.id); } catch (e) { return null; } };
  const flvLabel = x => (x && x.flv || []).join(" + ");
  const famName = g => g.base + " (" + g.m.slice().sort((a, b) => (+a.p.id || 0) - (+b.p.id || 0)).map(flvLabel).join(" / ") + ")";
  const famFlavors = g => g.m.slice().sort((a, b) => (+a.p.id || 0) - (+b.p.id || 0)).map(flvLabel);
  const famSig = g => famName(g) + "|" + famFlavors(g).join("¦");
  /* قائد كل عائلة: صنف المتجر المطابق بصورة حقيقية أولاً ، ثم الأقدم */
  let LEAD = new Map();   // g.key ← p
  function leadsOf(mt) {
    const f = FLV(); LEAD = new Map(); if (!f) return LEAD;
    let G; try { G = f.groups(); } catch (e) { return LEAD; }
    (G.list || []).forEach(g => {
      const sc = x => { const m = mt && mt.get(x.p), s = m && m.s; return (s ? 4 : 0) + (s && s.hasImage && !NOREAL.has(String(s.id)) ? 2 : 0) + (s && s.isActive !== false ? 1 : 0); };
      const best = g.m.slice().sort((a, b) => (sc(b) - sc(a)) || ((+a.p.id || 0) - (+b.p.id || 0)))[0];
      if (best) LEAD.set(g.key, best.p);
    });
    return LEAD;
  }
  const isLead = p => { const g = famOf(p); return !g || LEAD.get(g.key) === p || (!LEAD.has(g.key)); };
  const stockFam = p => { const g = famOf(p); if (!g) return stockOf(p); return g.m.reduce((t, x) => t + Math.max(0, stockOf(x.p)), 0); };
  /* صنف الطلبية في ANOUER مع ذوقه: { p, pin } */
  function localOf(it) {
    const p = findLocal(it); if (!p) return { p: null };
    const g = famOf(p), fl = flvN(it.flavor);
    if (!g) return { p };
    if (fl) { const x = g.m.find(y => flvN(flvLabel(y)) === fl) || g.m.find(y => y.flv.some(f => flvN(f) === fl)); if (x) return { p: x.p, pin: 1, flavor: flvLabel(x) }; }
    return { p, fam: g };
  }

  /* الفرق بين صنف المتجر s وصنف ANOUER p: سعر القطعة ، سعر الكرتونة (أو سعر القطعة إذا لم تكن هناك كرتونة) ، المخزون بالقطعة */
  function diffOf(s, p) {
    const bu = baseUnit(p), ppc = +s.piecesPerCarton || 1, cu = unitOfFactor(p, ppc);
    const a = { piece: +bu.price || +p.price || 0, carton: ppc > 1 ? (cu ? +cu.price || 0 : null) : (+bu.price || +p.price || 0), stock: Math.max(0, Math.round(stockFam(p) * 1000) / 1000) };
    const o = { id: s.id }; let n = 0;
    if (a.piece > 0 && Math.abs(a.piece - (+s.unitPrice || 0)) > 0.009) { o.unitPrice = a.piece; n++; }
    if (a.carton != null && a.carton > 0 && Math.abs(a.carton - (+s.price || 0)) > 0.009) { o.price = a.carton; n++; }
    if (Math.abs(a.stock - (+s.stock || 0)) > 0.0001) { o.stock = a.stock; n++; }
    return n ? o : null;
  }

  /* ---------------------------------------------------------------- مطابقة المتجر = ANOUER (مشتركة بين النافذة والمزامنة التلقائية) */
  const nm = v => ck(v).replace(/[إأآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/[^0-9a-zء-ي]/g, "");
  /* المطابقة على 3 مراحل حتى لا «يخطف» صنفٌ بالاسم صنفاً آخر يملك الكود نفسه:
     1) الكود/الباركود لكل الأصناف أولاً  2) الاسم المطابق تماماً (بعد التوحيد)  3) اسم شبه مطابق (كلمات مشتركة ≥ 80% وبدون تعارض) */
  const toks = v => String(v || "").toLowerCase().replace(/[٠-٩]/g, c => c.charCodeAt(0) - 1632).replace(/[إأآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي")
    .split(/[^0-9a-zء-ي]+/).filter(Boolean);
  const simil = (a, b) => { const A = new Set(toks(a)), B = new Set(toks(b)); if (!A.size || !B.size) return 0; let n = 0; A.forEach(t => { if (B.has(t)) n++; }); return n / Math.max(A.size, B.size); };
  function planOf(sp, O) {
    sp = sp || []; const idx = new Map(), byName = new Map(), used = new Set(), mt = new Map();
    sp.forEach(x => { [x.id, x.code, x.barcode].forEach(k => { k = ck(k); if (k && !idx.has(k)) idx.set(k, x); }); const n = nm(x.name); if (n) { if (!byName.has(n)) byName.set(n, []); byName.get(n).push(x); } });
    const ps = P().filter(p => p && String(p.name || "").trim());
    const keysOf = p => [p.code].concat(((p._u) || []).reduce((a, u) => a.concat([u && u.bc].concat((u && u.xb) || [])), [])).map(ck).filter(Boolean);
    ps.forEach(p => { for (const k of keysOf(p)) { const x = idx.get(k); if (x && !used.has(x.id)) { used.add(x.id); mt.set(p, { s: x, by: "code" }); break; } } });
    ps.forEach(p => { if (mt.has(p)) return; const x = (byName.get(nm(p.name)) || []).find(y => !used.has(y.id)); if (x) { used.add(x.id); mt.set(p, { s: x, by: "name" }); } });
    const restS = sp.filter(x => !used.has(x.id));
    ps.forEach(p => {
      if (mt.has(p) || !restS.length) return;
      let best = null, b1 = 0, b2 = 0;
      restS.forEach(x => { if (used.has(x.id)) return; const v = simil(p.name, x.name); if (v > b1) { b2 = b1; b1 = v; best = x; } else if (v > b2) b2 = v; });
      if (best && b1 >= 0.8 && b1 - b2 >= 0.15) { used.add(best.id); mt.set(p, { s: best, by: "fuzzy" }); }
    });
    const add = [], show = [], same = [], hide = [], link = [], seenCode = new Set(), fam = [];
    leadsOf(mt);
    ps.forEach(p => {
      const m = mt.get(p), s = m && m.s, on = p.active !== false || O.inact;
      if (!on) { if (s && s.isActive !== false) hide.push({ s, p, why: "موقوف في ANOUER" }); return; }
      const g = famOf(p);
      if (g && !isLead(p)) { if (s && s.isActive !== false) hide.push({ s, p, why: "ذوق مجمّع في «" + g.base + "»" }); return; }
      if (g && s) { const sig = famSig(g); if (S.flv[s.id] !== sig || nm(s.name) !== nm(famName(g))) fam.push({ s, p, g, sig }); }
      if (!s) { const c = ck(p.code) || keysOf(p)[0] || ""; if (c && seenCode.has(c)) return; if (c) seenCode.add(c); add.push({ p }); return; }
      const r = { s, p, by: m.by };
      if (m.by !== "code") link.push(r); else if (s.isActive === false) show.push(r); else same.push(r);
    });
    sp.forEach(x => { if (!used.has(x.id) && x.isActive !== false) hide.push({ s: x, p: null, why: "غير موجود في ANOUER" }); });
    /* عائلة انفصلت (أو أُوقف التجميع) ← القائد السابق يرجع لاسمه وبلا أذواق */
    const unfam = [];
    Object.keys(S.flv || {}).forEach(sid => { const x = sp.find(y => String(y.id) === String(sid)); if (!x) return; const p = [...mt.keys()].find(q => mt.get(q).s === x); if (!p) return; const g = famOf(p); if (!g || !isLead(p)) unfam.push({ s: x, p }); });
    const visNow = sp.filter(x => x.isActive !== false).length, tot = same.length + show.length + add.length + link.length;
    const upd = same.concat(show, link).map(x => { const d = diffOf(x.s, x.p); return d ? Object.assign({ d }, x) : null; }).filter(Boolean);
    return { add, show, same, hide, link, upd, fam, unfam, visNow, after: tot, anouer: tot };
  }
  function fieldsOf(p, news) {
    const us = ((p._u) || []).filter(u => u && u.name), bu = baseUnit(p), big = us.filter(u => (+u.factor || 1) > 1).sort((a, b) => b.factor - a.factor)[0];
    const piece = +bu.price || +p.price || 0, code = String(p.code || bu.bc || "").trim();
    const g = famOf(p);
    const f = { name: g ? famName(g) : String(p.name).trim(), code, barcode: String(bu.bc || code).trim(), category: "عام", unitPrice: piece, stock: Math.max(0, Math.round(stockFam(p) * 1000) / 1000), isActive: true, flavors: g ? famFlavors(g) : [],
      pieceName: bu.name || "قطعة", piecesPerCarton: big ? +big.factor : 1, price: big ? (+big.price || piece * big.factor) : piece, cartonName: big ? big.name : "كرتونة", isStockLimited: true };
    if (!news) { f.createdAt = "2026-01-01T00:00:00.000Z"; f.showNewBadge = false; } else { f.createdAt = new Date().toISOString(); f.showNewBadge = true; }
    return f;
  }

  /* عمليات «الأذواق» للمتجر + حفظ البصمة بعد النجاح */
  const famOps = M => [].concat(
    (M.fam || []).map(x => ({ id: x.s.id, updates: { name: famName(x.g), flavors: famFlavors(x.g) } })),
    (M.unfam || []).map(x => ({ id: x.s.id, updates: { name: String(x.p.name).trim(), flavors: [] } })));
  function famDone(M) {
    let ch = false;
    (M.fam || []).forEach(x => { S.flv[x.s.id] = x.sig; ch = true; });
    (M.unfam || []).forEach(x => { delete S.flv[x.s.id]; ch = true; });
    if (ch && HOST()) saveSettings({ "Store.FlvSig": JSON.stringify(S.flv) }).catch(() => { });
  }
  /* ---------------------------------------------------------------- النافذة */
  function open(tab) {
    const F = X(); if (!F) return;
    if (!HOST()) { T("ربط المتجر متاح داخل برنامج ANOUER فقط", "w"); return; }
    if (S.win) { S.win.el.querySelector(".fm-win").focus(); if (tab) S.win.go(tab); return; }
    const w = F.win({ title: "ربط المتجر الإلكتروني", icon: I.store, width: 1000, body: '<div class="sl"><div class="sl-load"><i></i>جارٍ التحميل …</div></div>', buttons: [], onClose: () => { S.win = null; } });
    w.el.classList.add("sl-ov"); S.win = w;
    const B = w.$(".sl");
    const V = { tab: tab || "orders", info: null, orders: null, showAll: false, sp: null, mf: "add", mo: { inact: false, news: true }, mq: "", run: null, opts: { piece: true, carton: true, stock: true, diff: true }, q: "" };
    w.go = t => { V.tab = t; render(); };

    function render() {
      if (!S.key || !S.url) return renderPair();
      const inf = V.info || {};
      const pend = (V.orders || []).filter(o => !o.imported).length;
      B.innerHTML = `<div class="sl-top">
          <span class="sl-logo">${I.store}</span>
          <div class="sl-ti"><b>${esc(inf.name || "المتجر الإلكتروني")}</b><a href="#" data-a="site" dir="ltr">${esc(S.url.replace(/^https?:\/\//, ""))}${I.open}</a></div>
          <div class="sl-kp"><span><i>${inf.products != null ? inf.products : "…"}</i>صنف</span><span class="${pend ? "hot" : ""}"><i>${V.orders ? pend : "…"}</i>طلبية جديدة</span><span title="آخر مزامنة">${I.sync}<i>${inf.lastSync ? new Date(inf.lastSync).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" }) : "—"}</i></span></div>
          <span class="sl-live${inf.name ? " on" : ""}" title="${inf.name ? "متصل" : "غير متصل"}"></span>
        </div>
        <div class="sl-tabs" role="tablist">
          ${[["orders", I.cart, "طلبيات المتجر" + (pend ? ` <em>${pend}</em>` : "")], ["mirror", I.mir, "مطابقة الأصناف"], ["sync", I.sync, "مزامنة الأسعار والمخزون"], ["qr", I.qr, "QR المتجر"]].map(t => `<button type="button" role="tab" data-tab="${t[0]}" class="${V.tab === t[0] ? "on" : ""}" aria-selected="${V.tab === t[0]}">${t[1]}<span>${t[2]}</span></button>`).join("")}
        </div>
        <div class="sl-body" data-body></div>`;
      const body = B.querySelector("[data-body]");
      if (V.tab === "orders") renderOrders(body); else if (V.tab === "mirror") renderMirror(body); else if (V.tab === "sync") renderSync(body); else renderQr(body);
      w.setButtons([{ t: "تحديث", cls: "sl-rf", fn: () => refresh(true) }, { t: "إلغاء الربط", cls: "no sl-un", fn: unlink }, "|", { t: "إغلاق", cls: "no", fn: w => w.close() }]);
    }

    /* ---------- الربط */
    function renderPair(err) {
      B.innerHTML = `<div class="sl-pair">
          <div class="sl-hero">${I.store}<b>اربط ANOUER بمتجرك الإلكتروني</b>
            <p>طلبيات الزبائن تصل إلى البرنامج وتتحوّل إلى فاتورة مبيعات بضغطة ، والأسعار والمخزون تُرسَل من البرنامج إلى المتجر.</p></div>
          <label class="sl-f"><span>رابط المتجر (بعد النشر Publish)</span><input dir="ltr" data-k="url" placeholder="https://faridoun-store-xxxx.run.app" value="${esc(V.dUrl != null ? V.dUrl : S.url)}" autocomplete="off" data-anytext></label>
          <label class="sl-f"><span>رمز دخول الإدارة في المتجر (PIN)</span><input type="password" inputmode="numeric" data-k="pin" maxlength="8" autocomplete="off" data-anytext></label>
          ${err ? `<div class="sl-err">${esc(err)}</div>` : ""}
          <p class="sl-note">🔒 الرمز لا يُحفظ في البرنامج — يُستعمل مرة واحدة للحصول على مفتاح ربط خاص بهذا الجهاز. يمكن إلغاؤه من هنا أو من المتجر.</p>
        </div>`;
      w.setButtons([{ t: "ربط المتجر", cls: "ok sl-go", fn: pair }, "|", { t: "إغلاق", cls: "no", fn: w => w.close() }]);
      setTimeout(() => { const i = B.querySelector((V.dUrl || S.url) ? "[data-k=pin]" : "[data-k=url]"); if (i) i.focus(); }, 40);
      B.querySelectorAll("input").forEach(i => i.addEventListener("keydown", e => { if (e.key === "Enter") pair(); }));
    }
    function pair() {
      V.dUrl = B.querySelector("[data-k=url]").value;
      const url = normUrl(V.dUrl), pin = B.querySelector("[data-k=pin]").value.trim();
      if (!url) return renderPair("أدخل رابط المتجر الصحيح");
      if (!pin) return renderPair("أدخل رمز دخول الإدارة");
      w.busy(true);
      const dev = (window.__USER_NAME || "ANOUER") + " · " + (navigator.userAgent.indexOf("Windows") >= 0 ? "Windows" : "PC");
      fetch(url + "/api/anouer/pair", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pin, device: dev }) })
        .then(r => r.json().catch(() => ({})).then(d => { if (!r.ok) throw new Error(d.error || (r.status === 404 ? "هذا المتجر لا يدعم الربط بعد — حدّث كود المتجر أولاً" : "HTTP " + r.status)); return d; }))
        .then(d => { S.url = url; S.key = d.key; return saveSettings({ "Store.Url": url, "Store.Key": d.key, "Store.Auto": "1" }).then(() => { resetPrintCache(); return d; }); })
        .then(d => { w.busy(false); V.info = d.store; T("✔ تم ربط المتجر الإلكتروني", "s"); snd("ok"); render(); refresh(); startAuto(); })
        .catch(e => { w.busy(false); renderPair(e instanceof TypeError ? "تعذّر الوصول إلى المتجر — تحقق من الرابط والإنترنت" : e.message); });
    }
    function unlink() {
      const go = () => saveSettings({ "Store.Key": "" }).then(() => { S.key = ""; V.info = V.orders = V.sp = null; stopAuto(); T("تم إلغاء ربط المتجر", "i"); render(); });
      try { askConfirm("إلغاء ربط المتجر الإلكتروني من هذا الجهاز ؟", go); } catch (e) { if (confirm("إلغاء ربط المتجر ؟")) go(); }
    }

    /* ---------- الطلبيات */
    function renderOrders(body) {
      if (!V.orders) { body.innerHTML = '<div class="sl-load"><i></i>جارٍ جلب الطلبيات …</div>'; return; }
      const list = V.orders.filter(o => V.showAll || !o.imported);
      body.innerHTML = `<div class="sl-bar"><label class="sl-ck"><input type="checkbox" data-a="all"${V.showAll ? " checked" : ""}><i></i>عرض الطلبيات المستوردة أيضاً</label><span class="sl-hint">الكمية في المتجر بالقطعة — تُضاف بالوحدة الصغرى في ANOUER</span></div>
        ${list.length ? `<div class="sl-ol">${list.map(orderCard).join("")}</div>` : `<div class="sl-empty">${I.cart}<b>لا توجد طلبيات جديدة</b><span>كل طلبية جديدة من المتجر تظهر هنا (وتنبيه في البرنامج).</span></div>`}`;
    }
    function orderCard(o) {
      const its = (o.items || []).map(it => { const L = localOf(it); return { it, p: L.p, L }; });
      const miss = its.filter(x => !x.p).length;
      const d = o.createdAt ? new Date(o.createdAt) : null;
      return `<article class="sl-o${o.imported ? " done" : ""}" data-o="${esc(o.id)}">
        <header><b>#${esc(String(o.id).replace(/^ord-/, "").slice(-6))}</b><span class="st st-${esc(o.status)}">${({ pending: "جديدة", shipped: "مشحونة", delivered: "مسلّمة" })[o.status] || esc(o.status)}</span>
          <time>${d ? d.toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" }) : ""}</time>${o.imported ? `<em>✔ مستوردة</em>` : ""}<strong><bdi>${fmt(o.total)}</bdi> ${esc(o.currency || "DZD")}</strong></header>
        <div class="sl-cu"><span>👤 <b>${esc(o.customerName)}</b></span><span dir="ltr">📞 ${esc(o.customerPhone)}</span><span>📍 ${esc(o.customerAddress)}</span>${o.shippingTitle ? `<span>🚚 ${esc(o.shippingTitle)} (${fmt(o.shippingCost)})</span>` : ""}</div>
        <table class="sl-it"><thead><tr><th>الصنف</th><th>الكمية</th><th>السعر</th><th>المجموع</th><th>في ANOUER</th></tr></thead><tbody>
          ${its.map(({ it, p, L }) => `<tr class="${p ? "" : "miss"}"><td>${esc(it.name)}${it.flavor ? ` <small>· ${esc(it.flavor)}</small>` : ""}${it.note ? ` <small>· ${esc(it.note)}</small>` : ""}</td><td>${fmt(it.qty).replace(/,00$/, "")} <small>${esc(it.unit || "")}${it.piecesPerCarton > 1 && it.qty >= it.piecesPerCarton ? ` (${Math.floor(it.qty / it.piecesPerCarton)} ${esc(it.cartonName || "كرتونة")}${it.qty % it.piecesPerCarton ? " + " + it.qty % it.piecesPerCarton : ""})` : ""}</small></td><td>${fmt(it.price)}</td><td>${fmt(it.price * it.qty)}</td><td>${p ? `<span class="sl-okc">✔ ${esc(p.code)}</span>${L.fam ? `<small class="sl-flv">🍬 ${esc(L.fam.base)} — حسب الأرصدة</small>` : L.pin ? `<small class="sl-flv">🍬 ${esc(L.flavor)}</small>` : ""}` : `<span class="sl-noc">✘ غير موجود</span>`}</td></tr>`).join("")}
        </tbody></table>
        <footer>${miss ? `<span class="sl-warn">⚠ ${miss} صنف غير موجود في ANOUER — سيُترك خارج الفاتورة</span>` : ""}<span class="sp"></span>
          ${o.imported ? "" : `<button type="button" class="sl-b2" data-a="ign" data-id="${esc(o.id)}">تمّت (بدون فاتورة)</button>`}
          <button type="button" class="sl-b1" data-a="inv" data-id="${esc(o.id)}">${I.inv}فاتورة مبيعات</button></footer>
      </article>`;
    }
    function toInvoice(o) {
      /* نفس طريقة «تحويل لفاتورة مبيعات» في المشتريات: فاتورة جديدة ثم الأسطر */
      if (typeof window.newInvoice !== "function") { T("شاشة المبيعات غير متاحة", "w"); return; }
      const src = (o.items || []).map(it => { const L = localOf(it); return { it, p: L.p, L }; }).filter(x => x.p && x.it.qty > 0).map(({ it, p, L }) => {
        const u = baseUnit(p);
        const r = { pid: p.id, name: p.name, qty: +it.qty || 1, unit: u.name || (p._d && p._d.name) || "حبة", price: +it.price || +u.price || +p.price || 0 };
        if (L.pin) r._flvPin = 1;   /* ذوق اختاره الزبون: لا يُوزَّع على باقي الأذواق */
        return r;
      });
      if (!src.length) { T("لا يوجد أي صنف من هذه الطلبية في ANOUER", "w"); return; }
      const n0 = document.querySelector("#tabs .tab.active"), k0 = n0 && n0.dataset.key;
      w.close();
      try { window.newInvoice(); } catch (e) { T("تعذّر فتح فاتورة مبيعات: " + (e.message || e), "e"); return; }
      const n1 = document.querySelector("#tabs .tab.active"), main = document.querySelector(".main");
      if (!n1 || n1.dataset.key === k0 || !main || main.dataset.view !== "sales") return;   /* الحد الأقصى للفواتير المفتوحة (رسالة من شاشة المبيعات) */
      try {
        rows = src; sel = 0; renderRows(); if (typeof calc === "function") calc();
        const cn = document.getElementById("custName");
        if (cn) { cn.value = (o.customerName || "") + (o.customerPhone ? " — " + o.customerPhone : ""); cn.dispatchEvent(new Event("input", { bubbles: true })); }
        const ds = document.getElementById("desc");
        if (ds && !ds.value.trim()) ds.value = "طلبية المتجر #" + String(o.id).replace(/^ord-/, "") + (o.customerAddress ? " — " + o.customerAddress : "");
        T("🛒 طلبية المتجر في فاتورة مبيعات (" + src.length + " صنف) — راجعها ثم احفظ", "s"); snd("ok");
        ack([o.id]);
      } catch (e) { T("تعذّر نسخ أصناف الطلبية: " + (e.message || e), "e"); }
    }
    function ack(ids) { return api("/api/anouer/orders/ack", { body: { ids } }).then(() => { (V.orders || []).forEach(o => { if (ids.indexOf(o.id) >= 0) o.imported = new Date().toISOString(); }); if (S.win === w) render(); }).catch(e => T("لم تُعلَّم الطلبية: " + e.message, "w")); }

    /* ---------- المزامنة */
    function syncRows() {
      return (V.sp || []).map(s => {
        const p = findLocal(s); if (!p) return { s, p: null };
        const bu = baseUnit(p), cu = unitOfFactor(p, s.piecesPerCarton);
        const a = { piece: +bu.price || +p.price || 0, carton: cu ? +cu.price || 0 : null, stock: stockFam(p) };
        const d = { piece: Math.abs(a.piece - s.unitPrice) > 0.009, carton: a.carton != null && Math.abs(a.carton - s.price) > 0.009, stock: Math.abs(a.stock - s.stock) > 0.0001 };
        return { s, p, a, d, cu, bu };
      });
    }
    function renderSync(body) {
      if (!V.sp) { body.innerHTML = '<div class="sl-load"><i></i>جارٍ جلب أصناف المتجر ومطابقتها …</div>'; loadSP(); return; }
      const all = syncRows(), m = all.filter(x => x.p), O = V.opts;
      const want = x => x.p && ((O.piece && x.d.piece) || (O.carton && x.d.carton) || (O.stock && x.d.stock));
      const q = ck(V.q);
      const vis = m.filter(x => (!O.diff || want(x)) && (!q || ck(x.s.name).indexOf(q) >= 0 || ck(x.s.code).indexOf(q) >= 0));
      const n = m.filter(want).length;
      body.innerHTML = `<div class="sl-bar">
          <label class="sl-ck"><input type="checkbox" data-o="piece"${O.piece ? " checked" : ""}><i></i>سعر القطعة</label>
          <label class="sl-ck"><input type="checkbox" data-o="carton"${O.carton ? " checked" : ""}><i></i>سعر الكرتونة</label>
          <label class="sl-ck"><input type="checkbox" data-o="stock"${O.stock ? " checked" : ""}><i></i>المخزون</label>
          <label class="sl-ck sep"><input type="checkbox" data-o="diff"${O.diff ? " checked" : ""}><i></i>الفروقات فقط</label>
          <input class="sl-q" data-q placeholder="بحث بالاسم أو الكود" value="${esc(V.q)}" data-anytext>
          <span class="sl-sum">مطابق <b>${m.length}</b> / ${all.length} · فروقات <b class="${n ? "hot" : ""}">${n}</b></span>
        </div>
        <div class="sl-gw"><table class="sl-g"><thead><tr><th rowspan="2">الصنف</th><th rowspan="2">الكود</th><th colspan="2">سعر القطعة</th><th colspan="2">سعر الكرتونة</th><th colspan="2">المخزون (قطعة)</th></tr>
          <tr><th>المتجر</th><th>ANOUER</th><th>المتجر</th><th>ANOUER</th><th>المتجر</th><th>ANOUER</th></tr></thead><tbody>
          ${vis.slice(0, 400).map(x => `<tr>
            <td>${esc(x.s.name)}</td><td dir="ltr">${esc(x.p.code)}</td>
            <td class="${x.d.piece && O.piece ? "old" : ""}">${fmt(x.s.unitPrice)}</td><td class="${x.d.piece && O.piece ? "new" : ""}">${fmt(x.a.piece)}</td>
            <td class="${x.d.carton && O.carton ? "old" : ""}">${x.s.piecesPerCarton > 1 ? fmt(x.s.price) : "—"}</td><td class="${x.d.carton && O.carton ? "new" : ""}">${x.a.carton != null ? fmt(x.a.carton) + `<small> ${esc(x.cu.name)}</small>` : "—"}</td>
            <td class="${x.d.stock && O.stock ? "old" : ""}">${fmt(x.s.stock).replace(/,00$/, "")}</td><td class="${x.d.stock && O.stock ? "new" : ""}">${fmt(x.a.stock).replace(/,00$/, "")}</td></tr>`).join("") || `<tr><td colspan="8" class="sl-none">${n ? "" : "✔ أسعار ومخزون المتجر مطابقة لـ ANOUER"}</td></tr>`}
          </tbody></table>${vis.length > 400 ? `<div class="sl-more">+ ${vis.length - 400} صنف آخر (تُرسل كلها)</div>` : ""}</div>
        <div class="sl-act"><span>الأصناف غير الموجودة في ANOUER (${all.length - m.length}) لا تتغيّر. القيم بالأخضر تُرسل إلى المتجر.</span><button type="button" class="sl-b1" data-a="push"${n ? "" : " disabled"}>${I.sync}إرسال ${n} تحديث إلى المتجر</button></div>`;
    }
    function loadSP() { Promise.all([api("/api/anouer/products"), refreshNoReal().catch(() => 0)]).then(([l]) => { V.sp = Array.isArray(l) ? l : []; if (V.tab === "sync" || V.tab === "mirror") render(); }).catch(e => { V.sp = []; T("تعذّر جلب أصناف المتجر: " + e.message, "e"); render(); }); }
    function push() {
      const O = V.opts, items = syncRows().filter(x => x.p).map(x => {
        const o = { id: x.s.id }; let any = false;
        if (O.piece && x.d.piece) { o.unitPrice = x.a.piece; any = true; }
        if (O.carton && x.d.carton) { o.price = x.a.carton; any = true; }
        if (O.stock && x.d.stock) { o.stock = Math.max(0, x.a.stock); any = true; }
        return any ? o : null;
      }).filter(Boolean);
      if (!items.length) return;
      w.busy(true);
      api("/api/anouer/products/sync", { body: { items }, timeout: 60000 })
        .then(r => { w.busy(false); T("✔ تم تحديث " + (r.changed || 0) + " صنف في المتجر", "s"); snd("ok"); V.sp = null; refresh(); })
        .catch(e => { w.busy(false); T("فشلت المزامنة: " + e.message, "e"); });
    }

    /* ---------- مطابقة الأصناف: المتجر = أصناف ANOUER بالضبط
       • صنف في ANOUER وغير موجود في المتجر ← يُضاف (الاسم ، الكود والباركود ، سعر القطعة والكرتونة ، المخزون)
       • صنف موجود لكنه مخفي في المتجر ← يُعاد إظهاره
       • صنف في المتجر وغير موجود في ANOUER (أو موقوف في ANOUER) ← يُخفى (لا يُحذف: يرجع بضغطة إذا عاد للبرنامج)
       الأسعار والمخزون للأصناف الموجودة تبقى من تبويب «مزامنة الأسعار والمخزون». */
    const mirrorPlan = () => planOf(V.sp, V.mo), newFields = p => fieldsOf(p, V.mo.news);
    function renderMirror(body) {
      if (!V.sp) { body.innerHTML = '<div class="sl-load"><i></i>جارٍ جلب أصناف المتجر ومطابقتها مع ANOUER …</div>'; loadSP(); return; }
      const NI = noImg(V.sp).length + unitOps(V.sp).filter(o => !UNIT_DONE.has(String(o.id))).length;
      const M = mirrorPlan(), F = V.mf, q = ck(V.mq), todo = M.add.length + M.show.length + M.hide.length + M.link.length + M.upd.length;
      const L = { add: M.add, show: M.show, hide: M.hide, same: M.same, link: M.link, upd: M.upd }[F] || [];
      const vis = L.filter(x => !q || [x.p && x.p.name, x.p && x.p.code, x.s && x.s.name, x.s && x.s.code].some(v => v && ck(v).indexOf(q) >= 0));
      const chip = (k, n, t, c) => `<button type="button" class="sm-chip ${c}${F === k ? " on" : ""}" data-mf="${k}"><b>${n}</b><span>${t}</span></button>`;
      const R0 = V.run;
      body.innerHTML = `<div class="sm-kpi">
          <div class="sm-k a"><span>أصناف ANOUER${V.mo.inact ? "" : " النشطة"}</span><b>${M.anouer}</b></div>
          <div class="sm-arw">${I.mir}</div>
          <div class="sm-k s"><span>الظاهرة في المتجر الآن</span><b>${M.visNow}</b><small>${(V.sp || []).length - M.visNow ? (V.sp.length - M.visNow) + " مخفي" : ""}</small></div>
          <div class="sm-eq ${M.visNow === M.anouer && !todo ? "ok" : ""}">${M.visNow === M.anouer && !todo ? "✔ متطابق" : "بعد المطابقة"}<b>${M.after}</b><small>= ANOUER بالضبط</small></div>
        </div>
        <div class="sl-bar sm-bar">
          ${chip("add", M.add.length, "سيُضاف للمتجر", "g")}${chip("link", M.link.length, "رُبط بالاسم", "y")}${chip("show", M.show.length, "سيُعاد إظهاره", "b")}${chip("hide", M.hide.length, "سيُخفى من المتجر", "r")}${chip("upd", M.upd.length, "تحديث السعر / المخزون", "v")}${chip("same", M.same.length, "مطابق", "n")}
          <input class="sl-q" data-mq placeholder="بحث بالاسم أو الكود" value="${esc(V.mq)}" data-anytext>
        </div>
        <div class="sl-gw sm-gw"><table class="sl-g sm-g"><thead><tr><th>الصنف</th><th>الكود</th>${F === "add" ? "<th>سعر القطعة</th><th>الكرتونة</th><th>المخزون</th>" : F === "hide" ? "<th>السبب</th><th>المخزون في المتجر</th>" : F === "link" ? "<th>الاسم في المتجر</th><th>الكود في المتجر ← ANOUER</th>" : F === "upd" ? "<th>سعر القطعة</th><th>سعر الكرتونة</th><th>المخزون (قطعة)</th>" : "<th>في المتجر</th><th>المخزون</th>"}</tr></thead><tbody>
          ${vis.slice(0, 500).map(x => {
            if (F === "add") { const f = newFields(x.p); return `<tr class="sm-add"><td><i class="sm-dot g"></i>${esc(f.name)}</td><td dir="ltr">${esc(f.code)}</td><td><bdi dir="ltr">${fmt(f.unitPrice)}</bdi> <small>${esc(f.pieceName)}</small></td><td>${f.piecesPerCarton > 1 ? `<bdi dir="ltr">${fmt(f.price)}</bdi> <small>${esc(f.cartonName)} × ${f.piecesPerCarton}</small>` : "—"}</td><td><bdi dir="ltr">${fmt(f.stock).replace(/,00$/, "")}</bdi></td></tr>`; }
            if (F === "hide") return `<tr><td><i class="sm-dot r"></i>${esc(x.s.name)}</td><td dir="ltr">${esc(x.s.code || x.s.id)}</td><td><span class="sm-why">${esc(x.why)}</span></td><td>${fmt(x.s.stock).replace(/,00$/, "")}</td></tr>`;
            if (F === "upd") { const d = x.d, c = (k, v) => d[k] !== undefined ? `<s><bdi dir="ltr">${fmt(v).replace(/,00$/, "")}</bdi></s> <b class="sm-nv"><bdi dir="ltr">${fmt(d[k]).replace(/,00$/, "")}</bdi></b>` : `<bdi dir="ltr">${fmt(v).replace(/,00$/, "")}</bdi>`;
              return `<tr><td><i class="sm-dot v"></i>${esc(x.p.name)}</td><td dir="ltr">${esc(x.p.code)}</td><td>${c("unitPrice", x.s.unitPrice)}</td><td>${c("price", x.s.price)}</td><td>${c("stock", x.s.stock)}</td></tr>`; }
            if (F === "link") return `<tr><td><i class="sm-dot y"></i>${esc(x.p.name)}</td><td dir="ltr">${esc(x.p.code)}</td><td>${esc(x.s.name)}${x.by === "fuzzy" ? ' <span class="sm-fz">اسم مشابه</span>' : ""}</td><td dir="ltr">${esc(x.s.code || x.s.id)} → ${esc(x.p.code)}</td></tr>`;
            return `<tr><td><i class="sm-dot ${F === "show" ? "b" : "n"}"></i>${esc(x.p.name)}</td><td dir="ltr">${esc(x.p.code)}</td><td>${esc(x.s.name)}</td><td>${fmt(x.s.stock).replace(/,00$/, "")}</td></tr>`;
          }).join("") || `<tr><td colspan="5" class="sl-none">${F === "same" ? "—" : "✔ لا شيء هنا"}</td></tr>`}
        </tbody></table>${vis.length > 500 ? `<div class="sl-more">+ ${vis.length - 500} صنف آخر (تُنفّذ كلها)</div>` : ""}</div>
        <div class="sl-act sm-act">
          <div class="sm-opt">
            <label class="sl-ck"><input type="checkbox" data-mo="inact"${V.mo.inact ? " checked" : ""}><i></i>تضمين الأصناف الموقوفة في ANOUER</label>
            <label class="sl-ck"><input type="checkbox" data-mo="news"${V.mo.news ? " checked" : ""}><i></i>الأصناف المضافة والمُعاد إظهارها تظهر في «المجموعة الجديدة 🌟»</label>
            <span class="sl-hint">الإخفاء لا يحذف شيئاً: الصنف يرجع ظاهراً إذا رجع إلى ANOUER.</span>
          </div>
          ${R0 ? `<div class="sm-run"><div class="sm-pb"><i style="width:${Math.round(R0.done / Math.max(1, R0.total) * 100)}%"></i></div><span>${esc(R0.msg)}</span></div>`
            : `${S.adm || !(M.add.length + M.show.length + M.hide.length + M.link.length + NI) ? "" : `<label class="sm-pin"><span>رمز دخول الإدارة في المتجر</span><input type="password" inputmode="numeric" maxlength="8" data-mpin autocomplete="off" data-anytext placeholder="PIN"></label>`}
               ${NI ? `<button type="button" class="sl-b1 sm-go sm-img" data-a="imgs" title="صور ناقصة في المتجر + أسماء وحدات مختلفة عن ANOUER (مثل «فاردو» بدل «قطعة»)">🖼️ الصور والوحدات (${NI})</button>` : ""}
               <button type="button" class="sl-b1 sm-go" data-a="mirror"${todo ? "" : " disabled"}>${I.mir}${todo ? `مطابقة الآن (${todo})` : "متطابق ✔"}</button>`}
        </div>`;
    }
    /* جلسة إدارة المتجر (7 أيام) — الرمز نفسه لا يُحفظ */
    /* واجهات إدارة المتجر بدون CORS ← الطلب يمر عبر المضيف (store.http: رابط المتجر المربوط فقط) */
    function hx(path, body, hdr) {
      const done = (st, d) => { if (st < 200 || st >= 300) { const e = new Error((d && d.error) || ("HTTP " + st)); e.status = st; e.code = d && d.code; throw e; } return d; };
      if (HOST()) return call("store.http", { url: S.url + path, method: body ? "POST" : "GET", headers: hdr || {}, body: body ? JSON.stringify(body) : "" })
        .then(r => { let d = {}; try { d = JSON.parse((r && r.body) || "{}"); } catch (e) { } return done(+(r && r.status) || 0, d); });
      return fetch(S.url + path, { method: body ? "POST" : "GET", headers: Object.assign({}, hdr || {}, body ? { "Content-Type": "application/json" } : {}), body: body ? JSON.stringify(body) : undefined, cache: "no-store" })
        .then(r => r.json().catch(() => ({})).then(d => done(r.status, d)));
    }
    const admApi = (path, body) => hx(path, body, { "X-Admin-Token": S.adm });
    function admSession(pin) {
      const chk = S.adm ? admApi("/api/admin/session").then(d => !!(d && d.admin)).catch(() => false) : Promise.resolve(false);
      return chk.then(ok => {
        if (ok) return true;
        if (!pin) { S.adm = ""; throw new Error("أدخل رمز دخول الإدارة في المتجر"); }
        return hx("/api/admin/login", { pin }).then(d => { if (!d || !d.token) throw new Error("رمز الدخول غير صحيح"); S.adm = d.token; return saveSettings({ "Store.Adm": d.token }).catch(() => { }).then(() => true); });
      });
    }
    function runImages() {
      const pinI = B.querySelector("[data-mpin]"), pin = pinI ? pinI.value.trim() : "", L = noImg(V.sp);
      V.run = { done: 0, total: L.length, msg: "جارٍ الدخول إلى المتجر …" }; render();
      admSession(pin).then(() => syncImages(V.sp, true, Math.max(1, L.length), (d, t) => { V.run.done = d; V.run.total = t; V.run.msg = `صور الأصناف … ${d} / ${t}`; if (S.win === w) render(); }))
        .then(n => { V.run = null; V.sp = null; if (L.length) T(n ? `✔ أُرسلت صور ${n} صنف إلى المتجر` : "لا توجد صور في ANOUER لهذه الأصناف — أضف الصورة من بطاقة الصنف", n ? "s" : "w"); if (S.win === w) render(); })
        .catch(e => { V.run = null; T(e.message, "e"); if (S.win === w) render(); });
    }
    function runMirror() {
      const M = mirrorPlan(), pinI = B.querySelector("[data-mpin]"), pin = pinI ? pinI.value.trim() : "";
      const ops = [].concat(
        M.add.map(x => { const f = newFields(x.p); return { id: f.code || undefined, updates: f, isNewProduct: true }; }),
        M.show.map(x => ({ id: x.s.id, updates: V.mo.news ? { isActive: true, createdAt: new Date().toISOString(), showNewBadge: true } : { isActive: true } })),
        M.link.map(x => { const bu = baseUnit(x.p), c = String(x.p.code || bu.bc || "").trim(); return { id: x.s.id, updates: { code: c, barcode: String(bu.bc || c).trim(), isActive: true } }; }),
        M.hide.map(x => ({ id: x.s.id, updates: { isActive: false } })), famOps(M));
      const upd = M.upd.map(x => x.d);
      if (!ops.length && !upd.length) return;
      const go = () => {
        V.run = { done: 0, total: ops.length || 1, msg: ops.length ? "جارٍ الدخول إلى المتجر …" : "تحديث الأسعار والمخزون …" }; render();
        (ops.length ? admSession(pin) : Promise.resolve()).then(() => {
          const CH = 120; let i = 0;
          const step = () => {
            if (i >= ops.length) return Promise.resolve();
            const part = ops.slice(i, i + CH);
            V.run.msg = `جارٍ الإرسال … ${Math.min(ops.length, i + part.length)} / ${ops.length}`; if (S.win === w) render();
            return admApi("/api/products/bulk-update", { updates: part }).then(() => { i += part.length; V.run.done = i; return step(); });
          };
          return step();
        }).then(() => {
          famDone(M);
          if (!upd.length) return;
          V.run.msg = `تحديث الأسعار والمخزون … ${upd.length} صنف`; if (S.win === w) render();
          return api("/api/anouer/products/sync", { body: { items: upd }, timeout: 120000 });
        }).then(() => {
          V.run.msg = "إرسال صور الأصناف …"; if (S.win === w) render();
          return Promise.all([api("/api/anouer/products"), refreshNoReal(true).catch(() => 0)]).then(([l]) => syncImages(Array.isArray(l) ? l : [], true, 400)).catch(() => 0);
        }).then(() => {
          V.run = null; V.sp = null; snd("ok");
          T(`✔ تمت المطابقة: +${M.add.length} صنف جديد · ${M.link.length} رُبط بالاسم · ${M.show.length} أُعيد إظهاره · ${M.hide.length} أُخفي · ${(M.fam || []).length} عائلة أذواق · ${M.upd.length} سعر/مخزون — المتجر = ${M.after} صنف مثل ANOUER`, "s");
          api("/api/anouer/info").then(inf => { V.info = inf; }).catch(() => { }).then(() => { if (S.win === w) render(); });
        }).catch(e => {
          const was = V.run ? V.run.done : 0; V.run = null;
          if (e.status === 401 || e.code === "ADMIN_REQUIRED") { S.adm = ""; saveSettings({ "Store.Adm": "" }).catch(() => { }); }
          T((was ? `توقفت المطابقة بعد ${was} عملية: ` : "") + e.message, "e"); V.sp = was ? null : V.sp; if (S.win === w) render();
        });
      };
      const msg = `مطابقة المتجر مع ANOUER:\n+ إضافة ${M.add.length} صنف\n⇄ ربط بالاسم (تصحيح الكود) ${M.link.length}\n↺ إعادة إظهار ${M.show.length}\n− إخفاء ${M.hide.length} صنف (بدون حذف)\n⟳ تحديث السعر/المخزون ${M.upd.length} صنف\n\nالمتجر سيصبح ${M.after} صنف. متابعة ؟`;
      try { askConfirm(msg, go); } catch (e) { if (confirm(msg)) go(); }
    }

    /* ---------- QR */
    function renderQr(body) {
      let qr = ""; try { qr = window.ANOUER_QR ? ANOUER_QR.svg(S.url, 230, "H") : ""; } catch (e) { }
      body.innerHTML = `<div class="sl-qrw"><div class="sl-qr"><div class="q">${qr}<span>ف</span></div><b>امسح واطلب من ${esc((V.info && V.info.name) || "المتجر")}</b><small dir="ltr">${esc(S.url.replace(/^https?:\/\//, ""))}</small></div>
        <div class="sl-qs"><p>اطبع هذا الرمز وضعه على الواجهة أو بجانب الكاشير أو على أكياس الزبائن: يفتح المتجر مباشرة على الموبايل والطلبيات تصل إلى ANOUER.</p>
          <label class="sl-chk sl-invqr"><input type="checkbox" data-a="invqr"${S.invQr ? " checked" : ""}><span><b>QR المتجر في كل الفواتير</b><small>يُطبع في إيصالات الكاشير وفواتير A4 للزبائن: «امسح وتسوّق أونلاين»</small></span></label>
          <button type="button" class="sl-b1" data-a="qrprint">${I.qr}طباعة الرمز</button><button type="button" class="sl-b2" data-a="copy">نسخ الرابط</button></div></div>`;
    }
    function printQr() {
      let qr = ""; try { qr = ANOUER_QR.svg(S.url, 520, "H"); } catch (e) { return; }
      const nm = esc((V.info && V.info.name) || "المتجر الإلكتروني");
      const html = `<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>QR ${nm}</title><style>@page{size:A5;margin:12mm}body{font-family:Tahoma,Arial;text-align:center;margin:0}h1{font-size:30px;margin:8mm 0 2mm}p{font-size:16px;margin:0 0 6mm;color:#444}.q{display:inline-block;padding:4mm;border:3px solid #111;border-radius:6mm}.u{margin-top:5mm;font:600 14px Consolas,monospace;direction:ltr}</style></head><body><h1>${nm}</h1><p>امسح الرمز بكاميرا الموبايل واطلب الآن 🛒</p><div class="q">${qr}</div><div class="u">${esc(S.url.replace(/^https?:\/\//, ""))}</div><script>onload=function(){setTimeout(function(){print()},250)}<\/script></body></html>`;
      const f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0;right:0;bottom:0"; document.body.appendChild(f);
      f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close(); setTimeout(() => f.remove(), 60000);
    }

    /* ---------- الأحداث */
    B.addEventListener("click", e => {
      const t = e.target.closest("[data-tab],[data-a],[data-mf]"); if (!t) return;
      if (t.dataset.tab) { V.tab = t.dataset.tab; render(); return; }
      if (t.dataset.mf) { V.mf = t.dataset.mf; render(); return; }
      const a = t.dataset.a, id = t.dataset.id, o = id && (V.orders || []).find(x => x.id === id);
      if (a === "site") { e.preventDefault(); try { window.open(S.url, "_blank"); } catch (x) { } }
      else if (a === "inv" && o) toInvoice(o);
      else if (a === "ign" && o) ack([o.id]);
      else if (a === "push") push();
      else if (a === "mirror") runMirror();
      else if (a === "imgs") runImages();
      else if (a === "qrprint") printQr();
      else if (a === "copy") { try { navigator.clipboard.writeText(S.url).then(() => T("تم نسخ رابط المتجر", "s")); } catch (x) { } }
    });
    B.addEventListener("keydown", e => { if (e.key === "Enter" && e.target.dataset && e.target.dataset.mpin !== undefined) { e.preventDefault(); runMirror(); } });
    B.addEventListener("change", e => {
      const t = e.target;
      if (t.dataset.a === "all") { V.showAll = t.checked; refreshOrders(); }
      else if (t.dataset.a === "invqr") { const on = t.checked; saveSettings({ "Store.Qr": on ? "1" : "0" }).then(() => { S.invQr = on; resetPrintCache(); T(on ? "✔ QR المتجر يظهر في الفواتير" : "أُخفي QR المتجر من الفواتير", "s"); }).catch(x => { t.checked = !on; T("تعذّر الحفظ: " + x.message, "e"); }); }
      else if (t.dataset.o) { V.opts[t.dataset.o] = t.checked; render(); }
      else if (t.dataset.mo) { V.mo[t.dataset.mo] = t.checked; render(); }
    });
    B.addEventListener("input", e => { if (e.target.dataset.mq !== undefined) { V.mq = e.target.value; clearTimeout(V.qt); V.qt = setTimeout(() => { const p = e.target.selectionStart; render(); const i = B.querySelector("[data-mq]"); if (i) { i.focus(); try { i.setSelectionRange(p, p); } catch (x) { } } }, 220); return; }
      if (e.target.dataset.q !== undefined) { V.q = e.target.value; clearTimeout(V.qt); V.qt = setTimeout(() => { const p = e.target.selectionStart; render(); const i = B.querySelector("[data-q]"); if (i) { i.focus(); try { i.setSelectionRange(p, p); } catch (x) { } } }, 250); } });

    function refreshOrders() { return api("/api/anouer/orders" + (V.showAll ? "?all=1" : "")).then(l => { V.orders = Array.isArray(l) ? l : []; markSeen(V.orders); if (S.win === w) render(); }); }
    function refresh(manual) {
      if (!S.key) return render();
      Promise.all([api("/api/anouer/info").then(i => { V.info = i; }), refreshOrders()]).then(() => { if (manual) T("تم التحديث", "s"); render(); if ((V.tab === "sync" || V.tab === "mirror") && manual) { V.sp = null; render(); } })
        .catch(e => { if (e.code === "BAD_KEY") { S.key = ""; saveSettings({ "Store.Key": "" }); renderPair("انتهى مفتاح الربط (أُلغي من المتجر) — اربط من جديد"); } else { V.orders = V.orders || []; render(); T(e.message, "w"); } });
    }
    loadSettings().then(() => { render(); refresh(); });
  }

  /* ---------------------------------------------------------------- متابعة الطلبيات الجديدة */
  function markSeen(l) { S.seen = S.seen || new Set(); (l || []).forEach(o => S.seen.add(o.id)); }
  function check() {
    if (!S.key || !S.url || !S.auto) return;
    api("/api/anouer/orders").then(l => {
      if (!Array.isArray(l)) return;
      const first = !S.seen; S.seen = S.seen || new Set();
      const fresh = l.filter(o => !S.seen.has(o.id)); fresh.forEach(o => S.seen.add(o.id));
      if (first || !fresh.length) return;
      snd("ok");
      const o = fresh[0];
      notify(fresh.length === 1 ? `🛒 طلبية جديدة من المتجر: ${o.customerName} — ${fmt(o.total)} DZD` : `🛒 ${fresh.length} طلبيات جديدة من المتجر`);
    }).catch(() => { });
  }
  function notify(msg) {
    let n = document.getElementById("slToast");
    if (!n) { n = document.createElement("button"); n.id = "slToast"; n.type = "button"; n.className = "sl-toast"; document.body.appendChild(n); n.addEventListener("click", () => { n.classList.remove("on"); open("orders"); }); }
    n.innerHTML = I.cart + "<span>" + esc(msg) + "</span><em>فتح</em>";
    n.classList.remove("on"); void n.offsetWidth; n.classList.add("on");
    clearTimeout(n._t); n._t = setTimeout(() => n.classList.remove("on"), 15000);
  }
  /* مزامنة تلقائية: مخزون وأسعار المتجر = ANOUER (كل 5 دقائق + بعد كل حفظ فاتورة) — بمفتاح الربط فقط */
  let aBusy = false, aNext = 0;
  function autoSync(force) {
    if (!S.key || !S.url || !S.auto || aBusy || S.syncOff) return Promise.resolve(0);
    if (!force && Date.now() < aNext) return Promise.resolve(0);
    if (!P().length) return Promise.resolve(0);
    aBusy = true; aNext = Date.now() + 60000;
    return api("/api/anouer/products").then(l => {
      const sp = Array.isArray(l) ? l : [];
      return autoMirror(sp).then(() => sp);
    }).then(l => {
      const items = l.filter(x => x && x.isActive !== false).map(x => { const p = findLocal(x); return p ? diffOf(x, p) : null; }).filter(Boolean);
      if (!items.length) return 0;
      return api("/api/anouer/products/sync", { body: { items }, timeout: 120000 }).then(r => { S.lastAuto = { t: Date.now(), n: (r && r.changed) || items.length }; return S.lastAuto.n; });
    }).catch(() => 0).then(n => { aBusy = false; return n; });
  }
  /* إضافة / إظهار / إخفاء تلقائي: صنف جديد أو أُعيد تنشيطه في ANOUER ← يظهر في المتجر (و«وصل حديثاً») بلا تدخل
     يحتاج جلسة إدارة المتجر (تُفتح مرة بالرمز من نافذة الربط وتدوم 7 أيام) */
  let mBusy = false, mWarned = false;
  function hxTop(path, body) {
    const h = { "X-Admin-Token": S.adm };
    const done = (st, d) => { if (st < 200 || st >= 300) { const e = new Error((d && d.error) || ("HTTP " + st)); e.status = st; e.code = d && d.code; throw e; } return d; };
    if (HOST()) return call("store.http", { url: S.url + path, method: body ? "POST" : "GET", headers: h, body: body ? JSON.stringify(body) : "" }).then(r => { let d = {}; try { d = JSON.parse((r && r.body) || "{}"); } catch (e) { } return done(+(r && r.status) || 0, d); });
    return fetch(S.url + path, { method: body ? "POST" : "GET", headers: Object.assign(h, body ? { "Content-Type": "application/json" } : {}), body: body ? JSON.stringify(body) : undefined, cache: "no-store" }).then(r => r.json().catch(() => ({})).then(d => done(r.status, d)));
  }
  function autoMirror(sp) {
    if (mBusy || !S.key || !S.url || !S.auto || S.syncOff || !P().length) return Promise.resolve(null);
    const M = planOf(sp, { inact: false, news: true });
    const ops = [].concat(
      M.add.map(x => { const f = fieldsOf(x.p, true); f.createdAt = new Date().toISOString(); f.showNewBadge = true; return { id: f.code || undefined, updates: f, isNewProduct: true }; }),
      M.show.map(x => ({ id: x.s.id, updates: { isActive: true, createdAt: new Date().toISOString(), showNewBadge: true } })),
      M.hide.filter(x => x.p).map(x => ({ id: x.s.id, updates: { isActive: false } })), famOps(M));
    if (!ops.length) return refreshNoReal().catch(() => 0).then(() => syncImages(sp, false)).then(() => null);
    if (!S.adm) { if (!mWarned) { mWarned = true; notify(`🛒 ${M.add.length + M.show.length} صنف جديد/مُنشّط في ANOUER لم يظهر بعد في المتجر — افتح «ربط المتجر الإلكتروني» ← المطابقة وأدخل رمز الإدارة مرة واحدة`); } return Promise.resolve(null); }
    mBusy = true;
    return hxTop("/api/products/bulk-update", { updates: ops.slice(0, 120) }).then(() => {
      if (ops.length <= 120) famDone(M);
      const nF = (M.fam || []).length; if (nF) T(`🍬 المتجر: ${nF} ${nF > 1 ? "عائلات أذواق" : "عائلة أذواق"} في بطاقة واحدة — ${M.fam.slice(0, 2).map(x => x.g.base).join("، ")}`, "s");
      /* صنف أُضيف (ولا رجع) للمتجر ← يحتاج صورته من جديد حتى لو بعثناها قبل في نفس الجلسة */
      M.add.concat(M.show).forEach(x => { if (x.p) IMG_SENT.delete(String(x.p.id)); });
      const nA = M.add.length, nS = M.show.length, nH = M.hide.filter(x => x.p).length;
      const names = M.add.concat(M.show).slice(0, 3).map(x => x.p.name).join("، ");
      if (nA + nS) { snd("ok"); T(`🛒 المتجر: ${nA ? "+" + nA + " صنف جديد" : ""}${nA && nS ? " · " : ""}${nS ? nS + " أُعيد إظهاره" : ""}${names ? " — " + names : ""}`, "s"); }
      else if (nH) T(`🛒 المتجر: أُخفي ${nH} صنف موقوف في ANOUER`, "i");
      return Promise.all([api("/api/anouer/products"), refreshNoReal(true).catch(() => 0)]).then(([l]) => syncImages(Array.isArray(l) ? l : [], false)).catch(() => 0).then(() => ops.length);
    }).catch(e => {
      if (e.status === 401 || e.code === "ADMIN_REQUIRED") { S.adm = ""; saveSettings({ "Store.Adm": "" }).catch(() => { }); if (!mWarned) { mWarned = true; notify("🛒 انتهت جلسة إدارة المتجر — افتح «ربط المتجر الإلكتروني» ← المطابقة وأدخل الرمز لتُضاف الأصناف الجديدة تلقائياً"); } }
      return null;
    }).then(r => { mBusy = false; return r; });
  }
  /* صور الأصناف: صورة الصنف في ANOUER (fm.pimg) ← صورة الصنف في المتجر
     • صنف في المتجر بلا صورة وله صورة في ANOUER ← تُرسل
     • صورة غُيّرت في ANOUER (حفظ من بطاقة الصنف / الاستوديو) ← تُرسل من جديد */
  const IMG_MISS = new Set(), IMG_DIRTY = new Set(), IMG_SENT = new Set(); let iBusy = false, iWarned = false;
  function shrink(dataUrl, max, q) {
    return new Promise(res => { const im = new Image(); im.onload = () => { const r = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement("canvas"); c.width = Math.round(im.naturalWidth * r); c.height = Math.round(im.naturalHeight * r); const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL("image/jpeg", q)); }; im.onerror = () => res(""); im.src = dataUrl; });
  }
  function localImage(p) {
    if (!HOST()) return Promise.resolve("");
    return call("fm.pimg.get", { id: +p.id || p.id }).then(r => r && r.data ? shrink("data:" + (r.type || "image/jpeg") + ";base64," + r.data, 640, 0.84) : "").catch(() => "");
  }
  /* صورة «وهمية» في المتجر (شعار افتراضى / placeholder) = بلا صورة */
  const NOREAL = new Set(); let nrAt = 0;
  const fakeImg = v => !v || /placeholder|defaultStoreLogo|store_logo/i.test(String(v));
  function refreshNoReal(force) {
    if (!force && Date.now() - nrAt < 90000) return Promise.resolve(NOREAL.size);
    const get = HOST() ? call("store.http", { url: S.url + "/api/products", method: "GET", headers: {}, body: "" }).then(r => JSON.parse((r && r.body) || "[]"))
      : fetch(S.url + "/api/products", { cache: "no-store" }).then(r => r.json());
    return get.then(L => { NOREAL.clear(); (Array.isArray(L) ? L : []).forEach(x => { if (x && x.isActive !== false && fakeImg(x.image)) NOREAL.add(String(x.id)); }); nrAt = Date.now(); return NOREAL.size; });
  }
  const lacks = x => !x.hasImage || NOREAL.has(String(x.id));
  function noImg(sp) { return (sp || []).filter(x => x && x.isActive !== false && lacks(x)).map(x => ({ s: x, p: findLocal(x) })).filter(c => c.p && !IMG_MISS.has(String(c.p.id))); }
  /* اسم الوحدة: صنف بوحدة واحدة في ANOUER (قطعة ، طابلة …) يظهر في المتجر بنفس الاسم
     — كان يظهر «فاردو» لأن اسم الكرتونة في المتجر فارغ / "undefined" */
  const BADC = v => { const t = String(v == null ? "" : v).trim(); return !t || t === "undefined" || t === "null"; };
  function unitOps(sp) {
    const out = [];
    (sp || []).forEach(x => {
      if (!x || x.isActive === false) return;
      const p = findLocal(x); if (!p) return;
      const us = ((p._u) || []).filter(u => u && u.name);
      if (us.some(u => (+u.factor || 1) > 1)) return;          // له وحدة كبرى: تبقى كما في المتجر
      if ((+x.piecesPerCarton || 1) > 1) return;
      const nmU = String(baseUnit(p).name || "قطعة").trim(); if (!nmU) return;
      const cn = String(x.cartonName == null ? "" : x.cartonName).trim(), pn = String(x.pieceName || "").trim();
      const generic = v => !v || v === "قطعة" || v === "حبة";
      const shown = !generic(pn) ? pn : (!BADC(cn) && cn !== "فاردو" && cn !== "كرتونة") ? cn : (pn || (BADC(cn) ? "فاردو" : cn));
      if (shown === nmU && !BADC(cn)) return;
      out.push({ id: x.id, name: p.name, updates: { pieceName: nmU, cartonName: nmU, piecesPerCarton: 1 } });
    });
    return out;
  }
  let uBusy = false, UNIT_DONE = new Set();
  async function syncUnits(sp) {
    if (uBusy || !S.adm || !S.key || !S.url) return 0;
    const ops = unitOps(sp).filter(o => !UNIT_DONE.has(String(o.id)));
    if (!ops.length) return 0;
    uBusy = true; let n = 0;
    try {
      for (let i = 0; i < ops.length; i += 100) {
        const part = ops.slice(i, i + 100);
        await hxTop("/api/products/bulk-update", { updates: part.map(o => ({ id: o.id, updates: o.updates })) });
        part.forEach(o => UNIT_DONE.add(String(o.id))); n += part.length;
      }
      if (n) T(`📦 المتجر: صُحّح اسم الوحدة لـ ${n} صنف (مثل ANOUER)${ops[0] ? " — " + ops.slice(0, 2).map(o => o.name + " ← " + o.updates.pieceName).join("، ") : ""}`, "s");
    } catch (e) { if (e.status === 401 || e.code === "ADMIN_REQUIRED") { S.adm = ""; saveSettings({ "Store.Adm": "" }).catch(() => { }); } }
    uBusy = false; return n;
  }
  async function syncImages(sp, manual, limit, prog) {
    try { await syncUnits(sp); } catch (e) { }
    if (iBusy || !S.key || !S.url || !HOST()) return 0;
    const cand = [];
    (sp || []).forEach(x => { if (!x || x.isActive === false) return; const p = findLocal(x); if (!p) return; if (IMG_DIRTY.has(String(p.id)) || (lacks(x) && !IMG_MISS.has(String(p.id)) && !IMG_SENT.has(String(p.id)))) cand.push({ s: x, p }); });
    if (!cand.length) return 0;
    cand.sort((a, b) => (IMG_DIRTY.has(String(b.p.id)) - IMG_DIRTY.has(String(a.p.id))) || ((+b.p.id || 0) - (+a.p.id || 0)));
    if (!S.adm) return 0;
    iBusy = true; let sent = 0;
    try {
      const batch = [];
      const todo = cand.slice(0, limit || 60); let k = 0;
      for (const c of todo) {
        const id = String(c.p.id); let img = await localImage(c.p); if (!img) { const g = famOf(c.p); if (g) for (const x of g.m) { if (x.p === c.p) continue; img = await localImage(x.p); if (img) break; } } k++; if (prog && k % 10 === 0) prog(k, todo.length);
        IMG_DIRTY.delete(id);
        if (!img) { IMG_MISS.add(id); continue; }
        batch.push({ id: c.s.id, pid: id, updates: { image: img }, name: c.p.name });
      }
      for (let i = 0; i < batch.length; i += 8) {
        const part = batch.slice(i, i + 8);
        await hxTop("/api/products/bulk-update", { updates: part.map(x => ({ id: x.id, updates: x.updates })) });
        sent += part.length; part.forEach(x => { IMG_SENT.add(x.pid); NOREAL.delete(String(x.id)); });
      }
      if (sent) { snd("ok"); T(`🖼️ المتجر: أُرسلت صور ${sent} صنف${batch[0] ? " — " + batch.slice(0, 2).map(x => x.name).join("، ") : ""}`, "s"); }
    } catch (e) {
      if (e.status === 401 || e.code === "ADMIN_REQUIRED") { S.adm = ""; saveSettings({ "Store.Adm": "" }).catch(() => { }); }
    }
    iBusy = false; return sent;
  }
  function startAuto() { stopAuto(); if (S.key && S.auto) { check(); S.timer = setInterval(check, 120000); setTimeout(() => autoSync(true), 20000); S.timer2 = setInterval(() => autoSync(true), 300000); } }
  function stopAuto() { clearInterval(S.timer); clearInterval(S.timer2); S.timer = S.timer2 = 0; }
  /* بعد أي عملية تغيّر المخزون (حفظ فاتورة …) ← مزامنة بعد 15 ثانية */
  let aT = 0; const kick = () => { clearTimeout(aT); aT = setTimeout(() => autoSync(false), 15000); };
  try { ["anouer:sale-saved", "anouer:whstock", "anouer:stock"].forEach(ev => window.addEventListener(ev, kick)); } catch (e) { }
  /* حفظ / تنشيط / إضافة صنف ← المتجر يتحدّث بعد 15 ثانية (بعد إعادة تحميل الأصناف) */
  try { const oc = window.Anouer && Anouer.call; if (oc && !oc.__stk) { const w = function (a, p) { const r = oc.apply(this, arguments); if (/^fm\.(item\.(save|quickAdd|active|delete)|pimg\.put)/.test(a || "")) Promise.resolve(r).then(() => { if (a === "fm.pimg.put" && p && p.id) { IMG_DIRTY.add(String(p.id)); IMG_MISS.delete(String(p.id)); } aNext = 0; kick(); }, () => { }); return r; }; w.__stk = 1; Object.keys(oc).forEach(k => { w[k] = oc[k]; }); Anouer.call = w; } } catch (e) { }

  /* ---------------------------------------------------------------- قائمة «ملف» */
  function addMenu() {
    try {
      if (typeof IC !== "undefined" && !IC.fStore) IC.fStore = I.store;
      const F = window.__FILE; if (!F || F.some(x => x && x.t === "ربط المتجر الإلكتروني")) return;
      const i = F.findIndex(x => x && x.t === "ربط البرنامج بالموبايل");
      F.splice(i >= 0 ? i + 1 : F.length - 1, 0, { t: "ربط المتجر الإلكتروني", ic: "fStore", run: () => open() });
    } catch (e) { }
  }
  addMenu();
  setTimeout(() => { if (HOST()) loadSettings().then(startAuto); }, 6000);

  window.ANOUER_STORE = { open, check, autoSync, kick, plan: planOf, fields: fieldsOf, local: localOf, syncImages, refreshNoReal, unitOps, _S: S };
})();
