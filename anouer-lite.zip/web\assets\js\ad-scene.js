/* ANOUER — «خلفية إعلانية» لصورة الصنف (2026)
   يأخذ المنتج المعزول (من استوديو التصوير) ويضعه في مشهد إعلاني مرسوم بالكامل على Canvas — بدون إنترنت ولا صور جاهزة:
     ▸ النمط يُستخرج من اسم الصنف / مجموعته: شوكولاتة ، فراولة ، نعناع ، بطيخ ، حمضيات ، كراميل ، حليب ، قهوة ، حلوى ومصاصات ،
       بسكويت ، مشروبات ، شيبس ، منظفات ، تجميل ، مواد غذائية ، شاي ، توابل ، أطفال … وإن لم يُعرف ← نمط «فاخر» بألوان العلبة نفسها.
     ▸ نكهتان في الاسم (نعناع + فراولة) ← المشهد يمزج عناصر الاثنتين.
     ▸ كل صنف له شكله: ترتيب العناصر ونوع السطح (خشب / لامع / منصة / رخام) والإضاءة من بذرة مشتقة من الاسم — «شكل آخر» يغيّرها.
   ANOUER_ADSCENE.render(A, B, { name, group, theme, seed, title }) ← canvas 2000×2000 */
(function () {
  "use strict";
  if (window.ANOUER_ADSCENE) return;
  const S = 2000, TAU = Math.PI * 2;
  const mk = (w, h) => { const c = document.createElement("canvas"); c.width = Math.round(w); c.height = Math.round(h); return c; };
  const hash = s => { let h = 2166136261; s = String(s || ""); for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return h >>> 0; };
  const rng = seed => () => { seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  const hsl = (h, s, l, a) => `hsla(${((h % 360) + 360) % 360},${s}%,${l}%,${a == null ? 1 : a})`;
  const lin = (x, x0, y0, x1, y1, st) => { const g = x.createLinearGradient(x0, y0, x1, y1); st.forEach((c, i) => g.addColorStop(Array.isArray(c) ? c[0] : i / (st.length - 1), Array.isArray(c) ? c[1] : c)); return g; };
  const rad = (x, cx, cy, r0, r1, st) => { const g = x.createRadialGradient(cx, cy, r0, cx, cy, r1); st.forEach((c, i) => g.addColorStop(Array.isArray(c) ? c[0] : i / (st.length - 1), Array.isArray(c) ? c[1] : c)); return g; };

  /* ============================================================ الأنماط */
  const T = {
    choco: { dark: 1, t: "شوكولاتة", e: "🍫", kw: /شو?كولا|شكلاط|كاكاو|chocolat|choco|cacao|cocoa|nutella|نوتيلا|brownie|golden|غولدن|قولدن/i, bg: ["#7a4420", "#3b1a09", "#170803"], surf: "gloss", floor: ["#4a2410", "#1a0a04"], acc: "#f3cf7a", ink: "#fff3d6", tag: "طعم الشوكولاتة الحقيقي", fl: "شوكولاتة", back: ["chocoP", "dust"], fore: ["chocoP", "chocoP", "hazel"], swirl: ["#7b3f1c", "#2e1307", "#b06a35"], ribbon: 1 },
    hazel: { dark: 1, t: "بندق", e: "🌰", kw: /بندق|noisette|hazelnut/i, bg: ["#9a6a3a", "#5a3415", "#22110a"], surf: "wood", acc: "#f3cf7a", ink: "#fff3d6", tag: "غني بالمكسرات", fl: "بندق", back: ["hazel", "dust"], fore: ["hazel", "hazel", "leaf"], ribbon: 1 },
    almond: { t: "لوز", e: "🌰", kw: /لوز|amande|almond/i, bg: ["#fff6e6", "#ecd0a2", "#b07a40"], surf: "wood", acc: "#8a4a16", ink: "#ffffff", tag: "لوز طبيعي مقرمش", fl: "لوز", back: ["almond", "dust"], fore: ["almond", "almond", "almond", "leaf"] },
    pistachio: { t: "فستق", e: "🥜", kw: /فستق|pistach/i, bg: ["#f6fae6", "#cfe0a0", "#7f9a45"], surf: "wood", acc: "#5c7a1f", ink: "#ffffff", tag: "فستق فاخر", fl: "فستق", back: ["pistachio", "dust"], fore: ["pistachio", "pistachio", "pistachio", "leaf"] },
    walnut: { t: "جوز", e: "🌰", kw: /(?<![؀-ۿ])جوز(?!\s*(ال)?هند)|noix(?! de coco)|walnut|قرقاع/i, bg: ["#f7ead6", "#d9b98c", "#8a5a2e"], surf: "wood", acc: "#6b3f1a", ink: "#ffffff", tag: "جوز طازج", fl: "جوز", back: ["walnut", "dust"], fore: ["walnut", "walnut", "walnut", "leaf"] },
    peanut: { t: "فول سوداني", e: "🥜", kw: /فول سوداني|كاوكاو|cacahu[eè]te|arachide|peanut/i, bg: ["#fff3d6", "#f0cf8a", "#b8862e"], surf: "wood", acc: "#9a5a12", ink: "#ffffff", tag: "قرمشة الفول السوداني", fl: "فول سوداني", back: ["peanut", "dust"], fore: ["peanut", "peanut", "peanut", "leaf"] },
    coconut: { t: "جوز الهند", e: "🥥", kw: /جوز\s*(ال)?هند|نارجيل|noix de coco|\bcoco(?!a)|coconut/i, bg: ["#ffffff", "#e3f3f6", "#8fc8d6"], surf: "gloss", floor: ["#e9f7fa", "#8fc8d6"], acc: "#6b3f1a", ink: "#ffffff", tag: "نكهة جوز الهند", fl: "جوز الهند", back: ["coconut", "bubble"], fore: ["coconut", "coconut", "leaf", "wdrop"] },
    nuts: { t: "مكسرات مشكلة", e: "🥜", kw: /مكسرات|fruits? secs|mixed nuts|كاجو|cajou|cashew/i, bg: ["#fff4e0", "#e6c690", "#9c6a34"], surf: "wood", acc: "#7a4212", ink: "#ffffff", tag: "تشكيلة مكسرات فاخرة", fl: "مكسرات", back: ["almond", "hazel", "dust"], fore: ["almond", "walnut", "pistachio", "hazel", "peanut"] },
    date: { dark: 1, t: "تمور", e: "🌴", kw: /(?<![؀-ۿ])تمر|تمور|دقلة|datte|deglet|\bdates?\b/i, bg: ["#c98a4a", "#6e3a14", "#241006"], surf: "wood", acc: "#f3cf7a", ink: "#fff3d6", tag: "تمور أصيلة", fl: "تمر", back: ["date", "dust"], fore: ["date", "date", "date", "leaf"], ribbon: 1 },
    strawberry: { t: "فراولة", e: "🍓", kw: /فراول|فريز|fraise|strawberry/i, bg: ["#ffe3ec", "#ff9dbb", "#e8457c"], surf: "gloss", floor: ["#ffc2d6", "#e8457c"], acc: "#e11d63", ink: "#ffffff", tag: "طعم الفراولة المنعش", fl: "فراولة", back: ["strawb", "bubble", "mint"], fore: ["strawb", "strawbH", "mint", "wdrop"] },
    mint: { t: "نعناع", e: "🌿", kw: /نعناع|menthe|mint|menthol|منثول/i, bg: ["#effcf3", "#a9e8c2", "#3fae78"], surf: "gloss", floor: ["#c9f2da", "#3fae78"], acc: "#0f8a54", ink: "#ffffff", tag: "انتعاش النعناع", fl: "نعناع", back: ["mint", "bubble", "bubble"], fore: ["mint", "mint", "ice", "wdrop"] },
    watermelon: { t: "بطيخ", e: "🍉", kw: /بطيخ|دلاع|past[eè]que|watermelon/i, bg: ["#e9f3df", "#b9cfa6", "#6f8f62"], surf: "wood", acc: "#1f8f3a", ink: "#ffffff", tag: "انتعاش البطيخ", fl: "بطيخ", back: ["mint", "bubble"], fore: ["wmelon", "wslice", "wslice", "mint"] },
    citrus: { t: "حمضيات", e: "🍋", kw: /ليمون|citron|lemon|\blime\b|برتقال|orange|حمضي|agrume|مندرين|mandarin|clémentine|يوسفي/i, bg: ["#fffbe0", "#ffe27a", "#ffa62b"], surf: "gloss", floor: ["#ffe9a3", "#ff9a1f"], acc: "#e86a00", ink: "#ffffff", tag: "انتعاش الحمضيات", fl: "ليمون", back: ["citrus", "bubble", "leaf"], fore: ["citrus", "citrus", "leaf", "wdrop"] },
    cherry: { t: "كرز", e: "🍒", kw: /كرز|cerise|cherry|حب الملوك/i, bg: ["#ffe1e6", "#f78aa0", "#a3122f"], surf: "gloss", floor: ["#f7a8b8", "#a3122f"], acc: "#a3122f", ink: "#fff", tag: "حلاوة الكرز", fl: "كرز", back: ["cherry", "bubble"], fore: ["cherry", "cherry", "leaf"] },
    fruit: { t: "فواكه", e: "🍎", kw: /تفاح|pomme|apple|خوخ|p[eê]che|peach|مشمش|abricot|موز|banan|عنب|raisin|grape|أناناس|ananas|مانجو|mangue|mango|توت|berry|framboise|فواكه|fruit|tutti|كوكتيل|cocktail|تروبيك|tropic/i, bg: ["#fff4d9", "#ffc978", "#f0762b"], surf: "wood", acc: "#e0511a", ink: "#fff", tag: "طعم الفواكه الطازجة", fl: "فواكه", back: ["rfruit", "leaf", "bubble"], fore: ["rfruit", "rfruit", "citrus", "leaf"] },
    caramel: { dark: 1, t: "كراميل", e: "🍮", kw: /كرا?ميل|caramel|toffee|توفي/i, bg: ["#ffe7b8", "#e8a23c", "#7a430d"], surf: "gloss", floor: ["#e8a23c", "#5e3208"], acc: "#fff0c9", ink: "#fff8e6", tag: "لذّة الكراميل", fl: "كراميل", back: ["cube", "dust"], fore: ["cube", "cube", "hazel"], swirl: ["#f0a93a", "#a35e10", "#ffd98a"], ribbon: 1 },
    honey: { t: "عسل", e: "🍯", kw: /عسل|miel|honey/i, bg: ["#ffe7a8", "#e8a23c", "#7a430d"], surf: "wood", acc: "#b45309", ink: "#fff8e6", tag: "عسل طبيعي صافٍ", fl: "عسل", back: ["cube", "dust"], fore: ["cube", "hazel", "leaf"], swirl: ["#f0a93a", "#a35e10", "#ffd98a"], ribbon: 1 },
    milk: { t: "حليب وألبان", e: "🥛", kw: /حليب|\blait\b|milk|(?<![؀-ۿ])لبن|رايب|ياغورت|ياوورت|yaourt|yogurt|جبن|fromage|cheese|كريم[ةه]|cr[eè]me|فانيلا|vanill|زبدة|beurre|butter/i, bg: ["#ffffff", "#dcefff", "#8fc4f0"], surf: "gloss", floor: ["#e9f5ff", "#8fc4f0"], acc: "#1d6fd6", ink: "#ffffff", tag: "غنيّ بالحليب", fl: "حليب", back: ["bubble", "wdrop"], fore: ["wdrop", "wdrop", "mint"], swirl: ["#ffffff", "#dbeaf7", "#ffffff"] },
    coffee: { dark: 1, t: "قهوة", e: "☕", kw: /قهوة|caf[eé]|coffee|cappuccino|كابتشينو|نسكافي|nescaf|espresso|موكا|mocha/i, bg: ["#d9b48a", "#6b3f20", "#22110a"], surf: "wood", acc: "#f1d7a8", ink: "#fff3df", tag: "نكهة القهوة الأصيلة", fl: "قهوة", back: ["bean", "dust"], fore: ["bean", "bean", "bean", "bean"], steam: 1 },
    candy: { t: "حلوى ومصاصات", e: "🍭", kw: /مصاص|sucette|lollipop|حلو[ىيه]|bonbon|candy|علك|chewing|\bgum\b|شوينغ|شوين قوم|ملبس|drag[eé]e|مارشميلو|marshmallow|جيلي|jelly|gelée|toffy/i, bg: ["#fdf0ff", "#d9a7ff", "#7a3fe0"], surf: "gloss", floor: ["#e7c6ff", "#6a2fd0"], acc: "#ff3d9a", ink: "#ffffff", tag: "عالم من الحلوى", fl: "", back: ["lolli", "candy", "bubble", "confetti"], fore: ["lolli", "candy", "candy", "candy"] },
    biscuit: { t: "بسكويت وويفر", e: "🍪", kw: /بسكو?يت|بسكوت|biscuit|wafer|ويفر|gaufrett|قوفريط|كعك|g[aâ]teau|cake|كيك|cookie|كوكيز|مادلين|madeleine|croissant|كرواسون|تارت|tarte|lamina|لامينا/i, bg: ["#fff3dc", "#ebc48a", "#a8703a"], surf: "wood", acc: "#8a4a16", ink: "#fff", tag: "قرمشة تُسعدك", fl: "", back: ["cookie", "dust"], fore: ["cookie", "wafer", "wafer", "chocoP"] },
    drink: { t: "مشروبات", e: "🥤", kw: /عصير|\bjus\b|juice|مشروب|boisson|drink|soda|صودا|\bcola|(?<![؀-ۿ])كولا|غازي|gazeu|(?<![؀-ۿ])ماء(?![؀-ۿ])|\beau\b|water|energy|طاقة|شراب|sirop/i, bg: ["#e8fbff", "#8fdcf5", "#1f8fd0"], surf: "gloss", floor: ["#bfeeff", "#1777b8"], acc: "#0b6fb5", ink: "#ffffff", tag: "انتعاش في كل رشفة", fl: "", back: ["bubble", "bubble", "ice"], fore: ["ice", "ice", "wdrop", "mint"] },
    snack: { t: "شيبس ومملحات", e: "🥔", kw: /شيبس|chips|snack|سناك|فشار|pop.?corn|مقرمش|cracker|كراكر|بطاطا/i, bg: ["#fff6c9", "#ffc531", "#e8590c"], surf: "wood", acc: "#c2410c", ink: "#fff", tag: "قرمشة لا تُقاوم", fl: "", back: ["chip", "dust"], fore: ["chip", "chip", "chip", "chili"] },
    clean: { t: "منظفات", e: "🧴", kw: /منظف|صابون|savon|soap|d[eé]tergent|lessive|مسحوق|شامبو|shampo|جافيل|javel|معقم|désinfect|غسول|مطهر|liquide vaisselle|مناديل|mouchoir|ورق صحي|papier/i, bg: ["#f2fbff", "#a8dcff", "#2b7fe0"], surf: "gloss", floor: ["#d4eeff", "#2b7fe0"], acc: "#0b57c2", ink: "#ffffff", tag: "نظافة ولمعان", fl: "", back: ["bubble", "bubble", "spark"], fore: ["bubble", "bubble", "wdrop", "spark"] },
    beauty: { t: "عناية وتجميل", e: "🌸", kw: /عطر|parfum|كريم(?![؀-ۿ])|cr[eè]me (de|visage|main)|تجميل|cosm[eé]t|مكياج|maquillage|عناية|\bsoins?\b|لوشن|lotion|مزيل|d[eé]odorant|معجون أسنان|dentifrice/i, bg: ["#fff5f7", "#f9c9d6", "#c26a8a"], surf: "marble", acc: "#b8860b", ink: "#ffffff", tag: "عناية تليق بك", fl: "", back: ["petal", "spark"], fore: ["petal", "petal", "petal", "spark"], ribbon: 1 },
    pantry: { t: "مواد غذائية", e: "🫒", kw: /زيت|huile|oil|سكر|sucre|طحين|فرينة|farine|سميد|semoule|(?<![؀-ۿ])[أا]رز|\briz\b|\brice\b|معكرون|p[aâ]tes|pasta|كسكس|couscous|طماطم|tomate|مصبر|conserve|(?<![؀-ۿ])عدس|lentill|(?<![؀-ۿ])حمص|فاصولي|(?<![؀-ۿ])تون[ةه]?(?![؀-ۿ])|thon|(?<![؀-ۿ])ملح(?![؀-ۿ])|\bsel\b|(?<![؀-ۿ])خل(?![؀-ۿ])|vinaigre|مايونيز|mayonn|كاتشب|ketchup|مرق/i, bg: ["#fbf3e2", "#e6cfa5", "#9c7a4a"], surf: "wood", acc: "#5c7a1f", ink: "#fff", tag: "من مطبخك اليومي", fl: "", back: ["leaf", "dust"], fore: ["tomato", "leaf", "leaf", "wdrop"] },
    tea: { t: "شاي وأعشاب", e: "🍵", kw: /شاي|\bth[eé]\b|\btea\b|[أا]تاي|أعشاب|tisane|infusion|زعتر|قرفة/i, bg: ["#f3f7e3", "#bcd58a", "#55741f"], surf: "wood", acc: "#3e5a12", ink: "#fff", tag: "لحظة شاي", fl: "", back: ["leaf", "mint"], fore: ["leaf", "leaf", "mint"], steam: 1 },
    spice: { dark: 1, t: "توابل وحار", e: "🌶", kw: /توابل|[eé]pice|spice|فلفل|piment|(?<![؀-ۿ])حار(?![؀-ۿ])|حريف|harissa|هريس|كمون|cumin|راس الحانوت|كاري|curry|بهار/i, bg: ["#ffd9a8", "#e0561c", "#5c1206"], surf: "wood", acc: "#ffd27a", ink: "#fff3df", tag: "نكهة قوية", fl: "", back: ["chili", "dust"], fore: ["chili", "chili", "leaf"] },
    baby: { t: "أطفال", e: "🍼", kw: /حفاض|couche|b[eé]b[eé]|baby|رضيع|رضّاع|biberon|أطفال/i, bg: ["#f4fbff", "#cfe9ff", "#ffd3e8"], surf: "marble", acc: "#4a90d9", ink: "#ffffff", tag: "حنان لطفلك", fl: "", back: ["star", "bubble"], fore: ["star", "star", "bubble"] },
    premium: { dark: 1, t: "فاخر (ألوان العلبة)", e: "✨", kw: null, bg: null, surf: "podium", acc: "#f3cf7a", ink: "#ffffff", tag: "جودة لا تُقاوم", fl: "", back: ["spark", "bokeh"], fore: ["spark"], ribbon: 1 }
  };
  const ORDER = ["strawberry", "mint", "watermelon", "citrus", "cherry", "choco", "hazel", "almond", "pistachio", "coconut", "walnut", "peanut", "nuts", "date", "honey", "caramel", "coffee", "candy", "biscuit", "milk", "fruit", "drink", "snack", "clean", "beauty", "tea", "spice", "pantry", "baby"];
  function detect(name, group) {
    const n = String(name || ""), g = String(group || ""); let ids = [];
    ORDER.forEach(id => { if (T[id].kw.test(n)) ids.push(id); });
    if (!ids.length) ORDER.forEach(id => { if (T[id].kw.test(g)) ids.push(id); });
    if (ids.includes("nuts")) ids = ["nuts"].concat(ids.filter(i => !/^(nuts|almond|hazel|walnut|pistachio|peanut)$/.test(i)));   // «مكسرات مشكلة» تغني عن أنواعها
    return ids.length ? ids.slice(0, 3) : ["premium"];
  }

  /* ============================================================ عناصر الديكور (كلها مرسومة — مركزها 0,0 وحجمها s) */
  const D = {
    strawb(x, s, R, half) {
      const body = () => { x.beginPath(); x.moveTo(0, -.40 * s); x.bezierCurveTo(.58 * s, -.62 * s, .62 * s, .08 * s, 0, .55 * s); x.bezierCurveTo(-.62 * s, .08 * s, -.58 * s, -.62 * s, 0, -.40 * s); x.closePath(); };
      body(); x.fillStyle = rad(x, -.14 * s, -.2 * s, .02 * s, .78 * s, ["#ff7a7a", "#e3233f", "#8d0c22"]); x.fill();
      if (half) { x.save(); body(); x.clip(); x.fillStyle = rad(x, 0, 0, .02 * s, .46 * s, ["#fff5f2", "#ffc4c4", "#f0556a"]); x.beginPath(); x.ellipse(0, .03 * s, .36 * s, .44 * s, 0, 0, TAU); x.fill(); x.strokeStyle = "rgba(255,255,255,.75)"; x.lineWidth = .014 * s; for (let i = -3; i <= 3; i++) { x.beginPath(); x.moveTo(0, -.2 * s); x.quadraticCurveTo(i * .07 * s, .1 * s, i * .1 * s, .36 * s); x.stroke(); } x.restore(); }
      else { x.save(); body(); x.clip(); x.fillStyle = "#ffe69a"; for (let r = 0; r < 6; r++) for (let c = -3; c <= 3; c++) { const px = (c + (r % 2 ? .5 : 0)) * .15 * s, py = -.3 * s + r * .14 * s; x.beginPath(); x.ellipse(px, py, .018 * s, .03 * s, 0, 0, TAU); x.fill(); } x.fillStyle = "rgba(255,255,255,.22)"; x.beginPath(); x.ellipse(-.2 * s, -.18 * s, .1 * s, .2 * s, -.5, 0, TAU); x.fill(); x.restore(); }
      x.fillStyle = lin(x, 0, -.6 * s, 0, -.3 * s, ["#58c96b", "#1f8a3d"]);
      for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + (i - 2) * .55; x.beginPath(); x.moveTo(0, -.42 * s); x.quadraticCurveTo(Math.cos(a - .25) * .2 * s, -.42 * s + Math.sin(a - .25) * .2 * s, Math.cos(a) * .34 * s, -.42 * s + Math.sin(a) * .26 * s); x.quadraticCurveTo(Math.cos(a + .25) * .2 * s, -.42 * s + Math.sin(a + .25) * .2 * s, 0, -.42 * s); x.fill(); }
    },
    strawbH(x, s, R) { D.strawb(x, s, R, true); },
    leafShape(x, s, c1, c2, vein) {
      x.beginPath(); x.moveTo(0, -.5 * s); x.bezierCurveTo(.42 * s, -.3 * s, .4 * s, .25 * s, 0, .5 * s); x.bezierCurveTo(-.4 * s, .25 * s, -.42 * s, -.3 * s, 0, -.5 * s); x.closePath();
      x.fillStyle = lin(x, -.3 * s, -.4 * s, .3 * s, .4 * s, [c1, c2]); x.fill();
      x.strokeStyle = vein; x.lineWidth = .016 * s; x.lineCap = "round"; x.beginPath(); x.moveTo(0, -.46 * s); x.lineTo(0, .46 * s); x.stroke(); x.lineWidth = .009 * s;
      for (let i = -3; i <= 3; i++) { const y = i * .11 * s, w = (.3 - Math.abs(i) * .05) * s; x.beginPath(); x.moveTo(0, y + .04 * s); x.quadraticCurveTo(w * .5, y - .02 * s, w, y - .08 * s); x.moveTo(0, y + .04 * s); x.quadraticCurveTo(-w * .5, y - .02 * s, -w, y - .08 * s); x.stroke(); }
      x.fillStyle = "rgba(255,255,255,.14)"; x.beginPath(); x.ellipse(-.12 * s, -.12 * s, .07 * s, .22 * s, -.25, 0, TAU); x.fill();
    },
    mint(x, s) { D.leafShape(x, s, "#8ff0a8", "#1c9a52", "rgba(10,90,45,.55)"); },
    leaf(x, s) { D.leafShape(x, s * .95, "#a9cf5a", "#4f7d1c", "rgba(40,70,10,.5)"); },
    petal(x, s, R) { x.beginPath(); x.moveTo(0, -.5 * s); x.bezierCurveTo(.4 * s, -.2 * s, .3 * s, .4 * s, 0, .5 * s); x.bezierCurveTo(-.3 * s, .4 * s, -.4 * s, -.2 * s, 0, -.5 * s); x.fillStyle = lin(x, 0, -.5 * s, 0, .5 * s, ["#fff0f4", "#f7a8c0", "#e0668f"]); x.fill(); x.strokeStyle = "rgba(255,255,255,.5)"; x.lineWidth = .012 * s; x.beginPath(); x.moveTo(0, -.4 * s); x.quadraticCurveTo(.05 * s, 0, 0, .44 * s); x.stroke(); },
    bubble(x, s) {
      const r = s * .5; x.fillStyle = rad(x, 0, 0, r * .55, r, ["rgba(255,255,255,0)", "rgba(255,255,255,.10)", "rgba(255,255,255,.55)"]); x.beginPath(); x.arc(0, 0, r, 0, TAU); x.fill();
      x.strokeStyle = "rgba(255,255,255,.7)"; x.lineWidth = r * .035; x.stroke();
      x.strokeStyle = "rgba(255,255,255,.9)"; x.lineWidth = r * .09; x.lineCap = "round"; x.beginPath(); x.arc(0, 0, r * .72, Math.PI * 1.08, Math.PI * 1.42); x.stroke();
      x.fillStyle = "rgba(255,255,255,.85)"; x.beginPath(); x.arc(r * .38, r * .42, r * .07, 0, TAU); x.fill();
      x.strokeStyle = "rgba(255,160,220,.35)"; x.lineWidth = r * .05; x.beginPath(); x.arc(0, 0, r * .86, .2, 1.3); x.stroke();
    },
    wdrop(x, s) { const r = s * .32; x.save(); x.scale(1, .55); x.fillStyle = rad(x, -r * .2, -r * .2, r * .1, r, ["rgba(255,255,255,.75)", "rgba(255,255,255,.18)", "rgba(255,255,255,.4)"]); x.beginPath(); x.arc(0, 0, r, 0, TAU); x.fill(); x.strokeStyle = "rgba(255,255,255,.65)"; x.lineWidth = r * .06; x.stroke(); x.restore(); x.fillStyle = "rgba(255,255,255,.95)"; x.beginPath(); x.ellipse(-r * .35, -r * .2, r * .16, r * .08, -.4, 0, TAU); x.fill(); },
    ice(x, s) { const w = s * .42; x.save(); x.rotate(.2); const rr = w * .28; x.beginPath(); x.roundRect(-w, -w, w * 2, w * 2, rr); x.fillStyle = lin(x, -w, -w, w, w, ["rgba(255,255,255,.85)", "rgba(200,235,255,.35)", "rgba(255,255,255,.6)"]); x.fill(); x.strokeStyle = "rgba(255,255,255,.9)"; x.lineWidth = w * .07; x.stroke(); x.strokeStyle = "rgba(255,255,255,.55)"; x.lineWidth = w * .05; x.beginPath(); x.moveTo(-w * .55, -w * .5); x.lineTo(w * .2, -w * .5); x.moveTo(-w * .55, -w * .5); x.lineTo(-w * .55, w * .25); x.stroke(); x.restore(); },
    chocoP(x, s, R) {
      const w = s * .5, h = s * .36, d = s * .13; x.save(); x.transform(1, 0, -.28, 1, 0, 0);
      x.fillStyle = "#2b1206"; x.beginPath(); x.roundRect(-w, -h + d, w * 2, h * 2, s * .05); x.fill();
      x.fillStyle = lin(x, -w, -h, w, h, ["#8a4a22", "#5a2c12", "#3d1c0a"]); x.beginPath(); x.roundRect(-w, -h, w * 2, h * 2, s * .05); x.fill();
      for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { const cx = -w + w * (i + .5), cy = -h + h * (j + .5); x.fillStyle = lin(x, cx - w * .4, cy - h * .4, cx + w * .4, cy + h * .4, ["#a05a2c", "#5e2e13"]); x.beginPath(); x.roundRect(cx - w * .4, cy - h * .38, w * .8, h * .76, s * .035); x.fill(); x.strokeStyle = "rgba(255,220,170,.22)"; x.lineWidth = s * .012; x.stroke(); }
      x.restore();
    },
    cube(x, s) { const w = s * .34; x.save(); x.rotate(-.15); x.fillStyle = "#8a4a0c"; x.beginPath(); x.roundRect(-w, -w + s * .12, w * 2, w * 2, s * .06); x.fill(); x.fillStyle = lin(x, -w, -w, w, w, ["#ffd98a", "#e79a2c", "#b96a12"]); x.beginPath(); x.roundRect(-w, -w, w * 2, w * 2, s * .06); x.fill(); x.fillStyle = "rgba(255,255,255,.35)"; x.beginPath(); x.ellipse(-w * .3, -w * .45, w * .42, w * .14, -.2, 0, TAU); x.fill(); x.restore(); },
    hazel(x, s) { const r = s * .4; x.fillStyle = rad(x, -r * .3, -r * .3, r * .05, r * 1.1, ["#e2a968", "#a8662b", "#6a3a14"]); x.beginPath(); x.moveTo(0, r * 1.05); x.bezierCurveTo(r * 1.15, r * .5, r * 1.0, -r * .9, 0, -r * .85); x.bezierCurveTo(-r * 1.0, -r * .9, -r * 1.15, r * .5, 0, r * 1.05); x.fill(); x.fillStyle = lin(x, 0, -r, 0, -r * .4, ["#f2d2a0", "#c99556"]); x.beginPath(); x.ellipse(0, -r * .72, r * .62, r * .24, 0, 0, TAU); x.fill(); x.fillStyle = "rgba(255,255,255,.3)"; x.beginPath(); x.ellipse(-r * .38, -r * .1, r * .12, r * .3, -.4, 0, TAU); x.fill(); },
    almond(x, s, R) {
      const a = s * .5, b = s * .3; x.save(); x.rotate(((R ? R() : .5) - .5) * .8);
      const sh = () => { x.beginPath(); x.moveTo(-a, 0); x.bezierCurveTo(-a * .7, -b * 1.25, a * .55, -b * 1.1, a, 0); x.bezierCurveTo(a * .55, b * 1.1, -a * .7, b * 1.25, -a, 0); x.closePath(); };
      x.translate(0, s * .05); sh(); x.fillStyle = "#6e3d18"; x.fill(); x.translate(0, -s * .05);
      sh(); x.fillStyle = rad(x, -a * .25, -b * .5, a * .05, a * 1.15, ["#e9b57a", "#c58545", "#8f5422"]); x.fill();
      x.save(); sh(); x.clip(); x.strokeStyle = "rgba(95,48,14,.42)"; x.lineWidth = s * .012; x.lineCap = "round";
      for (let i = -4; i <= 4; i++) { x.beginPath(); x.moveTo(-a * .95, i * b * .03); x.quadraticCurveTo(0, i * b * .27, a * .95, i * b * .03); x.stroke(); }
      x.fillStyle = "rgba(255,255,255,.26)"; x.beginPath(); x.ellipse(-a * .15, -b * .5, a * .45, b * .16, -.08, 0, TAU); x.fill(); x.restore(); x.restore();
    },
    walnut(x, s) {
      const r = s * .42; x.fillStyle = "#6b4420"; x.beginPath(); x.ellipse(0, r * .1, r * 1.02, r * .9, 0, 0, TAU); x.fill();
      x.fillStyle = rad(x, -r * .3, -r * .35, r * .05, r * 1.15, ["#e7c08a", "#c2935a", "#8a5f30"]); x.beginPath(); x.ellipse(0, 0, r, r * .88, 0, 0, TAU); x.fill();
      x.save(); x.beginPath(); x.ellipse(0, 0, r, r * .88, 0, 0, TAU); x.clip(); x.strokeStyle = "rgba(92,56,20,.6)"; x.lineCap = "round";
      x.lineWidth = s * .03; x.beginPath(); x.moveTo(0, -r); x.bezierCurveTo(r * .12, -r * .3, -r * .12, r * .3, 0, r); x.stroke(); x.lineWidth = s * .016;
      [-1, 1].forEach(k => { for (let i = 0; i < 4; i++) { const y = -r * .6 + i * r * .38; x.beginPath(); x.moveTo(k * r * .1, y); x.bezierCurveTo(k * r * .4, y - r * .22, k * r * .62, y + r * .22, k * r * .92, y - r * .04); x.stroke(); } });
      x.fillStyle = "rgba(255,255,255,.2)"; x.beginPath(); x.ellipse(-r * .4, -r * .42, r * .3, r * .14, -.5, 0, TAU); x.fill(); x.restore();
    },
    pistachio(x, s, R) {
      const a = s * .44, b = s * .3; x.save(); x.rotate(((R ? R() : .5) - .5) * 1.2);
      x.fillStyle = "#8e7a4e"; x.beginPath(); x.ellipse(0, s * .05, a, b, 0, 0, TAU); x.fill();
      x.fillStyle = rad(x, -a * .3, -b * .4, a * .05, a * 1.1, ["#fbf1d6", "#e6d3a3", "#bfa56c"]); x.beginPath(); x.ellipse(0, 0, a, b, 0, 0, TAU); x.fill();
      x.fillStyle = rad(x, 0, 0, a * .05, a * .8, ["#b6d86a", "#7fae35", "#4f7d1c"]); x.beginPath(); x.moveTo(-a * .8, 0); x.quadraticCurveTo(0, -b * .55, a * .86, 0); x.quadraticCurveTo(0, b * .5, -a * .8, 0); x.fill();
      x.strokeStyle = "rgba(120,95,45,.55)"; x.lineWidth = s * .014; x.beginPath(); x.moveTo(-a * .8, 0); x.quadraticCurveTo(0, -b * .55, a * .86, 0); x.quadraticCurveTo(0, b * .5, -a * .8, 0); x.stroke();
      x.fillStyle = "rgba(255,255,255,.4)"; x.beginPath(); x.ellipse(-a * .3, -b * .6, a * .3, b * .1, -.1, 0, TAU); x.fill(); x.restore();
    },
    peanut(x, s, R) {
      const r = s * .22; x.save(); x.rotate(((R ? R() : .5) - .5) * 1.4);
      const sh = dy => { x.beginPath(); x.moveTo(-r * 2, dy); x.bezierCurveTo(-r * 2, -r * 1.25 + dy, -r * .5, -r * 1.2 + dy, 0, -r * .72 + dy); x.bezierCurveTo(r * .5, -r * 1.2 + dy, r * 2, -r * 1.25 + dy, r * 2, dy); x.bezierCurveTo(r * 2, r * 1.25 + dy, r * .5, r * 1.2 + dy, 0, r * .72 + dy); x.bezierCurveTo(-r * .5, r * 1.2 + dy, -r * 2, r * 1.25 + dy, -r * 2, dy); x.closePath(); };
      sh(s * .05); x.fillStyle = "#9a7434"; x.fill(); sh(0); x.fillStyle = rad(x, -r * .6, -r * .5, r * .1, r * 2.4, ["#f3dba0", "#dcb970", "#b38c44"]); x.fill();
      x.save(); sh(0); x.clip(); x.strokeStyle = "rgba(140,100,40,.4)"; x.lineWidth = s * .012;
      for (let i = -7; i <= 7; i++) { x.beginPath(); x.moveTo(i * r * .3 - r * .5, -r * 1.3); x.lineTo(i * r * .3 + r * .5, r * 1.3); x.moveTo(i * r * .3 + r * .5, -r * 1.3); x.lineTo(i * r * .3 - r * .5, r * 1.3); x.stroke(); }
      x.fillStyle = "rgba(255,255,255,.25)"; x.beginPath(); x.ellipse(-r * .9, -r * .55, r * .6, r * .2, -.1, 0, TAU); x.fill(); x.restore(); x.restore();
    },
    coconut(x, s) {
      const r = s * .44; x.fillStyle = rad(x, -r * .3, -r * .3, r * .1, r * 1.2, ["#9a6a3c", "#6b4420", "#3d240f"]); x.beginPath(); x.arc(0, 0, r, 0, TAU); x.fill();
      x.strokeStyle = "rgba(40,22,8,.35)"; x.lineWidth = s * .012; for (let i = 0; i < 26; i++) { const a = i / 26 * TAU; x.beginPath(); x.moveTo(Math.cos(a) * r * .84, Math.sin(a) * r * .84); x.lineTo(Math.cos(a + .05) * r, Math.sin(a + .05) * r); x.stroke(); }
      x.fillStyle = rad(x, -r * .1, -r * .15, r * .05, r * .84, ["#ffffff", "#f6f3ec", "#e3ddd0"]); x.beginPath(); x.arc(0, 0, r * .82, 0, TAU); x.fill();
      x.fillStyle = rad(x, r * .05, r * .08, r * .05, r * .6, ["#d9d2c2", "#efeadf", "rgba(255,255,255,0)"]); x.beginPath(); x.arc(0, 0, r * .62, 0, TAU); x.fill();
    },
    date(x, s, R) {
      const a = s * .46, b = s * .24; x.save(); x.rotate(((R ? R() : .5) - .5) * 1.1);
      x.fillStyle = "#2a1206"; x.beginPath(); x.ellipse(0, s * .05, a, b, 0, 0, TAU); x.fill();
      x.fillStyle = rad(x, -a * .3, -b * .5, a * .05, a * 1.1, ["#b8733a", "#7a3f18", "#3b1a09"]); x.beginPath(); x.ellipse(0, 0, a, b, 0, 0, TAU); x.fill();
      x.save(); x.beginPath(); x.ellipse(0, 0, a, b, 0, 0, TAU); x.clip(); x.strokeStyle = "rgba(40,18,6,.45)"; x.lineWidth = s * .012; x.lineCap = "round";
      for (let i = -3; i <= 3; i++) { x.beginPath(); x.moveTo(-a * .9, i * b * .2); x.bezierCurveTo(-a * .3, i * b * .34 - b * .06, a * .3, i * b * .22 + b * .06, a * .9, i * b * .2); x.stroke(); }
      x.fillStyle = "rgba(255,225,180,.38)"; x.beginPath(); x.ellipse(-a * .15, -b * .5, a * .5, b * .14, -.05, 0, TAU); x.fill(); x.restore();
      x.fillStyle = "#c9a26a"; x.beginPath(); x.ellipse(a * .98, 0, s * .03, s * .045, 0, 0, TAU); x.fill(); x.restore();
    },
    bean(x, s) { const a = s * .42, b = s * .28; x.fillStyle = rad(x, -a * .3, -b * .4, a * .05, a * 1.1, ["#9a5a30", "#5b3118", "#2e160a"]); x.beginPath(); x.ellipse(0, 0, a, b, 0, 0, TAU); x.fill(); x.strokeStyle = "#1f0e06"; x.lineWidth = s * .035; x.lineCap = "round"; x.beginPath(); x.moveTo(-a * .82, 0); x.bezierCurveTo(-a * .3, -b * .5, a * .3, b * .5, a * .82, 0); x.stroke(); x.fillStyle = "rgba(255,255,255,.16)"; x.beginPath(); x.ellipse(-a * .25, -b * .5, a * .35, b * .14, -.15, 0, TAU); x.fill(); },
    wmelon(x, s) { const a = s * .5, b = s * .42; x.save(); x.beginPath(); x.ellipse(0, 0, a, b, 0, 0, TAU); x.fillStyle = rad(x, -a * .3, -b * .4, a * .1, a * 1.1, ["#6fcf6a", "#2f9d3c", "#145c22"]); x.fill(); x.clip(); x.strokeStyle = "rgba(12,60,22,.75)"; x.lineWidth = s * .05; for (let i = -3; i <= 3; i++) { x.beginPath(); for (let t = -1; t <= 1.001; t += .1) { const px = i * a * .3 * Math.sqrt(Math.max(0, 1 - t * t * .6)) + Math.sin(t * 14 + i) * s * .012, py = t * b; if (t === -1) x.moveTo(px, py); else x.lineTo(px, py); } x.stroke(); } x.fillStyle = "rgba(255,255,255,.22)"; x.beginPath(); x.ellipse(-a * .35, -b * .45, a * .28, b * .14, -.3, 0, TAU); x.fill(); x.restore(); },
    wslice(x, s) { const r = s * .5; x.save(); x.translate(0, -r * .35); x.beginPath(); x.moveTo(-r, 0); x.arc(0, 0, r, Math.PI, 0, true); x.closePath(); x.fillStyle = "#1f8f3a"; x.fill(); x.beginPath(); x.moveTo(-r * .93, 0); x.arc(0, 0, r * .93, Math.PI, 0, true); x.closePath(); x.fillStyle = "#e9f7d0"; x.fill(); x.beginPath(); x.moveTo(-r * .85, 0); x.arc(0, 0, r * .85, Math.PI, 0, true); x.closePath(); x.fillStyle = rad(x, 0, 0, r * .1, r * .85, ["#ff6b6b", "#ef3b4a", "#d42036"]); x.fill(); x.fillStyle = "#231010"; [[-.5, .25], [-.2, .45], [.15, .3], [.45, .28], [0, .16], [.3, .55], [-.35, .6]].forEach(p => { x.save(); x.translate(p[0] * r, p[1] * r); x.rotate(p[0]); x.beginPath(); x.ellipse(0, 0, r * .028, r * .055, 0, 0, TAU); x.fill(); x.restore(); }); x.fillStyle = "rgba(255,255,255,.18)"; x.fillRect(-r * .85, 0, r * 1.7, r * .05); x.restore(); },
    citrus(x, s, R) { const r = s * .46, hue = R && R() > .5 ? 28 : 50; x.fillStyle = hsl(hue, 95, 52); x.beginPath(); x.arc(0, 0, r, 0, TAU); x.fill(); x.fillStyle = "#fff6d8"; x.beginPath(); x.arc(0, 0, r * .9, 0, TAU); x.fill(); for (let i = 0; i < 9; i++) { const a0 = i / 9 * TAU + .04, a1 = (i + 1) / 9 * TAU - .04; x.beginPath(); x.moveTo(Math.cos((a0 + a1) / 2) * r * .08, Math.sin((a0 + a1) / 2) * r * .08); x.arc(0, 0, r * .84, a0, a1); x.closePath(); x.fillStyle = rad(x, 0, 0, r * .1, r * .84, [hsl(hue, 100, 72), hsl(hue, 96, 56)]); x.fill(); } x.fillStyle = "rgba(255,255,255,.25)"; x.beginPath(); x.ellipse(-r * .3, -r * .35, r * .3, r * .14, -.6, 0, TAU); x.fill(); },
    cherry(x, s) { const r = s * .24; x.strokeStyle = "#3f7a22"; x.lineWidth = s * .03; x.lineCap = "round"; x.beginPath(); x.moveTo(-r * 1.1, r * .2); x.quadraticCurveTo(-r * .4, -r * 1.6, r * .3, -r * 2); x.moveTo(r * 1.1, r * .5); x.quadraticCurveTo(r * .9, -r * 1.2, r * .3, -r * 2); x.stroke(); [[-r * 1.1, r * .5], [r * 1.1, r * .8]].forEach(p => { x.fillStyle = rad(x, p[0] - r * .3, p[1] - r * .3, r * .05, r * 1.1, ["#ff6b81", "#c4122f", "#6a0518"]); x.beginPath(); x.arc(p[0], p[1], r, 0, TAU); x.fill(); x.fillStyle = "rgba(255,255,255,.5)"; x.beginPath(); x.ellipse(p[0] - r * .35, p[1] - r * .4, r * .18, r * .1, -.6, 0, TAU); x.fill(); }); x.save(); x.translate(r * .9, -r * 1.9); x.rotate(1.1); D.leafShape(x, s * .42, "#8fd36a", "#2f8a2a", "rgba(10,70,20,.5)"); x.restore(); },
    rfruit(x, s, R) { const r = s * .42, hue = [2, 18, 95, 38, 285][Math.floor((R ? R() : 0) * 5)]; x.fillStyle = rad(x, -r * .3, -r * .35, r * .05, r * 1.15, [hsl(hue, 95, 70), hsl(hue, 85, 48), hsl(hue, 80, 28)]); x.beginPath(); x.moveTo(0, -r * .82); x.bezierCurveTo(r * 1.25, -r * 1.2, r * 1.2, r * 1.05, 0, r); x.bezierCurveTo(-r * 1.2, r * 1.05, -r * 1.25, -r * 1.2, 0, -r * .82); x.fill(); x.strokeStyle = "#5a3a1a"; x.lineWidth = s * .035; x.lineCap = "round"; x.beginPath(); x.moveTo(0, -r * .8); x.quadraticCurveTo(r * .1, -r * 1.15, r * .2, -r * 1.3); x.stroke(); x.save(); x.translate(r * .42, -r * 1.12); x.rotate(1.0); D.leafShape(x, s * .36, "#9be07a", "#2f8a2a", "rgba(10,70,20,.5)"); x.restore(); x.fillStyle = "rgba(255,255,255,.35)"; x.beginPath(); x.ellipse(-r * .4, -r * .3, r * .16, r * .34, -.4, 0, TAU); x.fill(); },
    tomato(x, s) { const r = s * .42; x.fillStyle = rad(x, -r * .3, -r * .35, r * .05, r * 1.15, ["#ff7a5c", "#e02d1b", "#8f1208"]); x.beginPath(); x.ellipse(0, 0, r * 1.05, r * .92, 0, 0, TAU); x.fill(); x.fillStyle = "#2f8a2a"; for (let i = 0; i < 5; i++) { x.save(); x.translate(0, -r * .78); x.rotate(i / 5 * TAU); x.beginPath(); x.moveTo(0, 0); x.quadraticCurveTo(r * .12, -r * .2, 0, -r * .42); x.quadraticCurveTo(-r * .12, -r * .2, 0, 0); x.fill(); x.restore(); } x.fillStyle = "rgba(255,255,255,.35)"; x.beginPath(); x.ellipse(-r * .4, -r * .3, r * .16, r * .3, -.4, 0, TAU); x.fill(); },
    lolli(x, s, R) { const r = s * .3, hue = Math.floor((R ? R() : .3) * 360); x.strokeStyle = "#fff"; x.lineWidth = s * .045; x.lineCap = "round"; x.beginPath(); x.moveTo(0, r * .6); x.lineTo(0, s * .62); x.stroke(); x.strokeStyle = "rgba(0,0,0,.08)"; x.lineWidth = s * .012; x.stroke(); x.save(); x.translate(0, -r * .2); x.beginPath(); x.arc(0, 0, r, 0, TAU); x.fillStyle = hsl(hue, 90, 62); x.fill(); x.clip(); x.strokeStyle = hsl(hue + 150, 95, 88); x.lineWidth = r * .24; x.beginPath(); for (let t = 0; t < 26; t += .15) { const rr = t * r * .045, px = Math.cos(t) * rr, py = Math.sin(t) * rr; if (!t) x.moveTo(px, py); else x.lineTo(px, py); } x.stroke(); x.fillStyle = "rgba(255,255,255,.35)"; x.beginPath(); x.ellipse(-r * .35, -r * .4, r * .32, r * .16, -.6, 0, TAU); x.fill(); x.restore(); },
    candy(x, s, R) { const a = s * .26, b = s * .19, hue = Math.floor((R ? R() : .6) * 360); x.fillStyle = hsl(hue, 90, 70); [[-1, 1], [1, 1]].forEach(d => { x.beginPath(); x.moveTo(d[0] * a * .9, 0); x.lineTo(d[0] * a * 1.9, -b * 1.05); x.quadraticCurveTo(d[0] * a * 1.6, 0, d[0] * a * 1.9, b * 1.05); x.closePath(); x.fill(); }); x.fillStyle = rad(x, -a * .3, -b * .4, a * .05, a * 1.2, [hsl(hue, 95, 78), hsl(hue, 88, 55), hsl(hue, 85, 38)]); x.beginPath(); x.ellipse(0, 0, a, b, 0, 0, TAU); x.fill(); x.save(); x.beginPath(); x.ellipse(0, 0, a, b, 0, 0, TAU); x.clip(); x.strokeStyle = "rgba(255,255,255,.55)"; x.lineWidth = a * .16; for (let i = -2; i <= 2; i++) { x.beginPath(); x.moveTo(i * a * .45 - b * .4, -b); x.lineTo(i * a * .45 + b * .4, b); x.stroke(); } x.restore(); x.fillStyle = "rgba(255,255,255,.4)"; x.beginPath(); x.ellipse(-a * .3, -b * .45, a * .34, b * .16, -.2, 0, TAU); x.fill(); },
    cookie(x, s, R) { const r = s * .42; x.fillStyle = "#8a5a22"; x.beginPath(); for (let i = 0; i <= 40; i++) { const a = i / 40 * TAU, rr = r * (1 + Math.sin(a * 9) * .025), px = Math.cos(a) * rr, py = Math.sin(a) * rr * .96 + r * .08; if (!i) x.moveTo(px, py); else x.lineTo(px, py); } x.fill(); x.fillStyle = rad(x, -r * .3, -r * .3, r * .1, r * 1.1, ["#f0c078", "#d1954a", "#a86a25"]); x.beginPath(); for (let i = 0; i <= 40; i++) { const a = i / 40 * TAU, rr = r * (1 + Math.sin(a * 9) * .025), px = Math.cos(a) * rr, py = Math.sin(a) * rr * .96; if (!i) x.moveTo(px, py); else x.lineTo(px, py); } x.fill(); x.fillStyle = "#4a2410"; [[-.4, -.3], [.25, -.45], [.5, .1], [-.1, .1], [-.5, .35], [.15, .5], [-.15, -.6]].forEach(p => { x.beginPath(); x.ellipse(p[0] * r, p[1] * r, r * .1, r * .08, p[0], 0, TAU); x.fill(); }); },
    wafer(x, s) { const L = s * .62, w = s * .1; x.save(); x.rotate(-.5); x.fillStyle = lin(x, 0, -w, 0, w, ["#f2c98a", "#d9a35a", "#a66f2c"]); x.beginPath(); x.roundRect(-L, -w, L * 2, w * 2, w); x.fill(); x.save(); x.beginPath(); x.roundRect(-L, -w, L * 2, w * 2, w); x.clip(); x.strokeStyle = "rgba(110,60,20,.55)"; x.lineWidth = w * .34; for (let i = -9; i <= 9; i++) { x.beginPath(); x.moveTo(i * L * .12 - w, -w); x.lineTo(i * L * .12 + w, w); x.stroke(); } x.restore(); x.fillStyle = "#4a2410"; x.beginPath(); x.ellipse(L, 0, w * .5, w, 0, 0, TAU); x.fill(); x.fillStyle = "rgba(255,255,255,.25)"; x.beginPath(); x.roundRect(-L * .9, -w * .8, L * 1.8, w * .35, w * .2); x.fill(); x.restore(); },
    chip(x, s, R) { const a = s * .42, b = s * .3; x.save(); x.rotate(((R ? R() : .5) - .5) * 1.2); x.fillStyle = "#b8721a"; x.beginPath(); x.ellipse(0, b * .14, a, b, 0, 0, TAU); x.fill(); x.fillStyle = rad(x, -a * .3, -b * .3, a * .1, a * 1.1, ["#ffe08a", "#f6b93b", "#d98a1a"]); x.beginPath(); x.ellipse(0, 0, a, b, 0, 0, TAU); x.fill(); x.strokeStyle = "rgba(180,110,20,.45)"; x.lineWidth = s * .014; for (let i = -3; i <= 3; i++) { x.beginPath(); x.moveTo(i * a * .25, -b * Math.sqrt(1 - i * i * .0625) * .9); x.quadraticCurveTo(i * a * .25 + a * .06, 0, i * a * .25, b * Math.sqrt(1 - i * i * .0625) * .9); x.stroke(); } x.restore(); },
    chili(x, s) { x.save(); x.rotate(.5); x.fillStyle = lin(x, -s * .4, 0, s * .5, 0, ["#ff5a3c", "#d81e12", "#7a0a06"]); x.beginPath(); x.moveTo(-s * .38, -s * .09); x.bezierCurveTo(-s * .1, -s * .2, s * .3, -s * .12, s * .52, s * .12); x.bezierCurveTo(s * .25, s * .08, -s * .1, s * .16, -s * .38, s * .1); x.closePath(); x.fill(); x.fillStyle = "#3a8a2a"; x.beginPath(); x.ellipse(-s * .4, 0, s * .06, s * .11, 0, 0, TAU); x.fill(); x.strokeStyle = "#3a8a2a"; x.lineWidth = s * .035; x.lineCap = "round"; x.beginPath(); x.moveTo(-s * .43, 0); x.quadraticCurveTo(-s * .52, -s * .06, -s * .56, -s * .16); x.stroke(); x.strokeStyle = "rgba(255,255,255,.35)"; x.lineWidth = s * .02; x.beginPath(); x.moveTo(-s * .25, -s * .08); x.quadraticCurveTo(s * .1, -s * .1, s * .32, 0); x.stroke(); x.restore(); },
    star(x, s, R) { const r = s * .42, hue = [45, 200, 330, 150][Math.floor((R ? R() : 0) * 4)]; x.fillStyle = hsl(hue, 90, 72); x.beginPath(); for (let i = 0; i < 10; i++) { const a = i / 10 * TAU - Math.PI / 2, rr = i % 2 ? r * .46 : r; x.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } x.closePath(); x.fill(); x.strokeStyle = "rgba(255,255,255,.8)"; x.lineWidth = s * .03; x.lineJoin = "round"; x.stroke(); },
    spark(x, s) { const r = s * .45; x.fillStyle = rad(x, 0, 0, 0, r, ["rgba(255,255,255,.95)", "rgba(255,255,255,.25)", "rgba(255,255,255,0)"]); x.beginPath(); x.arc(0, 0, r * .55, 0, TAU); x.fill(); x.fillStyle = "#fff"; x.beginPath(); for (let i = 0; i < 8; i++) { const a = i / 8 * TAU, rr = i % 2 ? r * .1 : r; x.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } x.closePath(); x.fill(); },
    bokeh(x, s) { x.fillStyle = "rgba(255,255,255,.16)"; x.beginPath(); x.arc(0, 0, s * .5, 0, TAU); x.fill(); },
    dust(x, s, R) { x.fillStyle = "rgba(255,225,170,.5)"; for (let i = 0; i < 14; i++) { x.beginPath(); x.arc(((R ? R() : .5) - .5) * s * 1.6, ((R ? R() : .5) - .5) * s * 1.6, s * (.01 + (R ? R() : .5) * .03), 0, TAU); x.fill(); } },
    confetti(x, s, R) { for (let i = 0; i < 9; i++) { x.save(); x.translate(((R ? R() : .5) - .5) * s * 1.5, ((R ? R() : .5) - .5) * s * 1.5); x.rotate((R ? R() : .5) * 6); x.fillStyle = hsl(Math.floor((R ? R() : .5) * 360), 95, 65); x.fillRect(-s * .05, -s * .02, s * .1, s * .04); x.restore(); } }
  };
  const put = (x, name, cx, cy, s, rot, R, o) => { const f = D[name]; if (!f) return; o = o || {}; x.save(); x.translate(cx, cy); x.rotate(rot || 0); if (o.a != null) x.globalAlpha = o.a; if (o.shadow) { x.shadowColor = "rgba(0,0,0,.32)"; x.shadowBlur = s * .12; x.shadowOffsetY = s * .06; } f(x, s, R); x.restore(); };

  /* ============================================================ الخلفية والأسطح */
  function backdrop(x, th, R, glow) {
    const c = th.bg; x.fillStyle = lin(x, 0, 0, 0, S, c); x.fillRect(0, 0, S, S);
    x.fillStyle = rad(x, S * .5, S * .46, S * .05, S * .8, [glow || "rgba(255,255,255,.55)", "rgba(255,255,255,.12)", "rgba(255,255,255,0)"]); x.fillRect(0, 0, S, S);
  }
  /* الطبقة الناعمة (أشعة + بوكيه): تُرسم على لوحة صغيرة ثم تُكبَّر ← ضبابية طبيعية بلا filter (أسرع بكثير) */
  function softLight(x, R) {
    const left = R() > .5; x.save(); x.globalAlpha = .1; x.fillStyle = "#fff";
    for (let i = 0; i < 4; i++) { const a = (left ? .55 : Math.PI - .55) + (left ? 1 : -1) * i * .16; x.beginPath(); x.moveTo(left ? -60 : S + 60, -60); x.lineTo((left ? 0 : S) + Math.cos(a) * S * 1.5, Math.sin(a) * S * 1.5); x.lineTo((left ? 0 : S) + Math.cos(a + (left ? .07 : -.07)) * S * 1.5, Math.sin(a + (left ? .07 : -.07)) * S * 1.5); x.closePath(); x.fill(); }
    x.restore();
    /* بوكيه */
    x.save(); for (let i = 0; i < 16; i++) { x.globalAlpha = .06 + R() * .14; x.fillStyle = "#fff"; x.beginPath(); x.arc(R() * S, R() * S * .62, 24 + R() * 90, 0, TAU); x.fill(); } x.restore();
  }
  function swirlBand(x, cols, y0, amp, thick, R, flip) {
    const k = flip ? -1 : 1, pts = t => [t * S * 1.2 - S * .1, y0 + Math.sin(t * 5.2 + (flip ? 2 : 0)) * amp * k + Math.sin(t * 11) * amp * .25];
    x.save(); x.shadowColor = "rgba(0,0,0,.35)"; x.shadowBlur = 40; x.shadowOffsetY = 18;
    x.beginPath(); for (let t = 0; t <= 1.001; t += .02) { const p = pts(t); if (!t) x.moveTo(p[0], p[1]); else x.lineTo(p[0], p[1]); }
    for (let t = 1; t >= -.001; t -= .02) { const p = pts(t), w = thick * (.55 + .45 * Math.sin(t * 7 + 1)); x.lineTo(p[0], p[1] + w); }
    x.closePath(); x.fillStyle = lin(x, 0, y0 - amp, 0, y0 + amp + thick, [cols[0], cols[1]]); x.fill(); x.restore();
    x.save(); x.strokeStyle = cols[2]; x.globalAlpha = .38; x.lineWidth = thick * .08; x.lineCap = "round"; x.beginPath(); for (let t = 0; t <= 1.001; t += .02) { const p = pts(t); if (!t) x.moveTo(p[0], p[1] + thick * .12); else x.lineTo(p[0], p[1] + thick * .12); } x.stroke(); x.restore();
  }
  function ribbon(x, R, side) {
    const g = lin(x, 0, 0, S, S, ["#fbe7a6", "#d6a63c", "#8f6417", "#f6dd8f", "#b98a26"]), w = 46 + R() * 22;
    const y0 = side ? S * (.1 + R() * .1) : S * (.9 + R() * .03), x0 = side ? -80 : (R() > .5 ? S * .5 : -S * .12), k = side ? 1 : .4;
    const P = [[x0, y0], [x0 + S * .22, y0 - S * .16 * k], [x0 + S * .36, y0 + S * .1 * k], [x0 + S * .62, y0 - S * .04 * k]];
    const seg = (a, b, c, d, dark) => { x.beginPath(); x.moveTo(a[0], a[1]); x.bezierCurveTo(b[0], b[1], c[0], c[1], d[0], d[1]); x.lineTo(d[0], d[1] + w); x.bezierCurveTo(c[0], c[1] + w * 1.3, b[0], b[1] + w * .7, a[0], a[1] + w); x.closePath(); x.fillStyle = g; x.fill(); if (dark) { x.fillStyle = "rgba(60,35,0,.28)"; x.fill(); } };
    x.save(); x.shadowColor = "rgba(0,0,0,.3)"; x.shadowBlur = 24; x.shadowOffsetY = 10;
    seg(P[0], [P[0][0] + S * .08, P[0][1] - S * .12 * k], [P[1][0] - S * .06, P[1][1] - S * .02], P[1], 0);
    seg(P[1], [P[1][0] + S * .07, P[1][1] + S * .02], [P[2][0] - S * .07, P[2][1] + S * .03], P[2], 1);
    seg(P[2], [P[2][0] + S * .08, P[2][1] - S * .03], [P[3][0] - S * .1, P[3][1] - S * .1 * k], P[3], 0);
    x.restore();
  }
  function surface(x, th, kind, hy, R) {
    if (kind === "wood") {
      x.fillStyle = lin(x, 0, hy, 0, S, ["#c79a63", "#a8743d", "#7d5226"]); x.fillRect(0, hy, S, S - hy);
      x.save(); x.beginPath(); x.rect(0, hy, S, S - hy); x.clip();
      let y = hy, i = 0; while (y < S) { const h = 46 + i * 34; x.fillStyle = `rgba(${i % 2 ? "255,225,180" : "70,40,10"},.07)`; x.fillRect(0, y, S, h); x.fillStyle = "rgba(50,25,5,.5)"; x.fillRect(0, y + h - 4, S, 4); x.fillStyle = "rgba(255,230,190,.18)"; x.fillRect(0, y, S, 2); const off = R() * S; for (let k = 0; k < 2; k++) x.fillRect((off + k * S * .55) % S, y, 4, h); y += h; i++; }
      x.lineCap = "round"; for (let g = 0; g < 320; g++) { const gy = hy + Math.pow(R(), .8) * (S - hy), gx = R() * S, len = 60 + R() * 380; x.strokeStyle = `rgba(${R() > .5 ? "60,30,8" : "255,225,180"},${.04 + R() * .08})`; x.lineWidth = 1 + R() * 2.5; x.beginPath(); x.moveTo(gx, gy); x.quadraticCurveTo(gx + len * .5, gy + (R() - .5) * 10, gx + len, gy + (R() - .5) * 5); x.stroke(); }
      x.restore(); x.fillStyle = lin(x, 0, hy, 0, hy + 90, ["rgba(0,0,0,.28)", "rgba(0,0,0,0)"]); x.fillRect(0, hy, S, 90);
    } else if (kind === "marble") {
      x.fillStyle = lin(x, 0, hy, 0, S, ["#ffffff", "#f1ece9", "#ddd3cf"]); x.fillRect(0, hy, S, S - hy);
      x.save(); x.beginPath(); x.rect(0, hy, S, S - hy); x.clip();
      for (let v = 0; v < 9; v++) { x.strokeStyle = `rgba(150,130,125,${.12 + R() * .16})`; x.lineWidth = 1.5 + R() * 4; x.beginPath(); let px = R() * S, py = hy; x.moveTo(px, py); for (let k = 0; k < 6; k++) { px += (R() - .5) * 420; py += 70 + R() * 60; x.lineTo(px, py); } x.stroke(); } x.restore();
      x.fillStyle = lin(x, 0, hy, 0, hy + 70, ["rgba(0,0,0,.14)", "rgba(0,0,0,0)"]); x.fillRect(0, hy, S, 70);
    } else {
      const f = th.floor || [th.bg[1], th.bg[2]];
      x.fillStyle = lin(x, 0, hy, 0, S, [f[0], f[1]]); x.fillRect(0, hy, S, S - hy);
      x.fillStyle = rad(x, S * .5, hy + 40, 10, S * .7, ["rgba(255,255,255,.5)", "rgba(255,255,255,.08)", "rgba(255,255,255,0)"]); x.save(); x.beginPath(); x.rect(0, hy, S, S - hy); x.clip(); x.fillRect(0, hy - 300, S, S); x.restore();
      x.fillStyle = lin(x, 0, hy - 14, 0, hy + 26, ["rgba(255,255,255,0)", "rgba(255,255,255,.35)", "rgba(255,255,255,0)"]); x.fillRect(0, hy - 14, S, 40);
    }
  }
  function podium(x, th, cy, rx, R) {
    const ry = rx * .22, h = S * .085, c = th.pod || (th.dark ? [th.bg[0], th.bg[1], th.bg[2]] : ["#ffffff", th.bg[0], th.bg[1]]);
    x.save(); x.translate(S * .5, cy + h + 34); x.scale(1, ry * 1.25 / (rx * 1.15)); x.fillStyle = rad(x, 0, 0, rx * .55, rx * 1.15, ["rgba(0,0,0,.34)", "rgba(0,0,0,.2)", "rgba(0,0,0,0)"]); x.beginPath(); x.arc(0, 0, rx * 1.15, 0, TAU); x.fill(); x.restore();
    x.fillStyle = lin(x, S * .5 - rx, 0, S * .5 + rx, 0, [c[2], c[1], c[0], c[1], c[2]]);
    x.beginPath(); x.ellipse(S * .5, cy + h, rx, ry, 0, 0, Math.PI); x.lineTo(S * .5 - rx, cy); x.ellipse(S * .5, cy, rx, ry, 0, Math.PI, 0, true); x.closePath(); x.fill();
    x.fillStyle = lin(x, 0, cy - ry, 0, cy + ry, [c[0], c[1]]); x.beginPath(); x.ellipse(S * .5, cy, rx, ry, 0, 0, TAU); x.fill();
    x.strokeStyle = th.acc; x.globalAlpha = .7; x.lineWidth = 6; x.beginPath(); x.ellipse(S * .5, cy, rx * .985, ry * .985, 0, 0, TAU); x.stroke(); x.globalAlpha = 1;
  }

  /* ============================================================ المنتج */
  const fit = (im, mw, mh) => { const k = Math.min(mw / im.width, mh / im.height); return [im.width * k, im.height * k]; };
  function product(x, im, cx, bottom, w, h, o) {
    x.save(); x.translate(cx, bottom); x.scale(1, .12); x.fillStyle = rad(x, 0, 0, 0, w * .62, ["rgba(0,0,0,.5)", "rgba(0,0,0,.18)", "rgba(0,0,0,0)"]); x.beginPath(); x.arc(0, 0, w * .62, 0, TAU); x.fill(); x.restore();
    if (o.refl) { const t = mk(w, h * .34), tx = t.getContext("2d"); tx.save(); tx.translate(0, h); tx.scale(1, -1); tx.drawImage(im, 0, 0, w, h); tx.restore(); tx.globalCompositeOperation = "destination-in"; tx.fillStyle = lin(tx, 0, 0, 0, t.height, ["rgba(0,0,0,.3)", "rgba(0,0,0,0)"]); tx.fillRect(0, 0, w, t.height); x.drawImage(t, cx - w / 2, bottom + 2); }
    x.save(); x.shadowColor = "rgba(0,0,0,.34)"; x.shadowBlur = 46; x.shadowOffsetX = o.left ? 22 : -22; x.shadowOffsetY = 20; x.drawImage(im, cx - w / 2, bottom - h, w, h); x.restore();
  }
  /* الصورة كاملة بلا عزل: بطاقة بحواف مستديرة وإطار أبيض (عندما لا يريد المستخدم قص المنتج أو كانت الخلفية غير موحدة) */
  function photoCard(im) {
    const m = Math.max(im.width, im.height), bd = Math.round(m * .028), r = Math.round(m * .06), c = mk(im.width + bd * 2, im.height + bd * 2), x = c.getContext("2d");
    x.fillStyle = "#fff"; x.beginPath(); x.roundRect(0, 0, c.width, c.height, r + bd); x.fill();
    x.save(); x.beginPath(); x.roundRect(bd, bd, im.width, im.height, r); x.clip(); x.drawImage(im, bd, bd); x.restore();
    x.strokeStyle = "rgba(0,0,0,.08)"; x.lineWidth = Math.max(2, m * .003); x.beginPath(); x.roundRect(bd, bd, im.width, im.height, r); x.stroke();
    return c;
  }
  /* اللون الغالب على العلبة (للنمط «فاخر» ولتوهّج الخلفية) */
  function dominant(im) {
    try {
      const c = mk(40, 40), x = c.getContext("2d", { willReadFrequently: true }); x.drawImage(im, 0, 0, 40, 40); const d = x.getImageData(0, 0, 40, 40).data; const bins = new Array(12).fill(0); let sat = 0, n = 0;
      for (let i = 0; i < d.length; i += 4) { if (d[i + 3] < 200) continue; const r = d[i] / 255, g = d[i + 1] / 255, b = d[i + 2] / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), dl = mx - mn; n++; if (dl < .18 || mx < .2) continue; let h = mx === r ? ((g - b) / dl) % 6 : mx === g ? (b - r) / dl + 2 : (r - g) / dl + 4; h = (h * 60 + 360) % 360; bins[Math.floor(h / 30) % 12] += dl; sat += dl; }
      if (!n || sat / n < .04) return null; let bi = 0; bins.forEach((v, i) => { if (v > bins[bi]) bi = i; }); return bi * 30 + 15;
    } catch (e) { return null; }
  }

  /* ============================================================ العنوان */
  function title(x, th, l1, l2) {
    x.save(); x.textAlign = "center"; x.textBaseline = "middle"; try { x.direction = "rtl"; } catch (e) { }
    const F = '"Segoe UI","Tahoma","Arial",sans-serif';
    let fs = 150; x.font = `900 ${fs}px ${F}`; const w1 = x.measureText(l1).width; if (w1 > S * .84) { fs = Math.max(70, Math.floor(fs * S * .84 / w1)); x.font = `900 ${fs}px ${F}`; }
    const y1 = S * .105;
    x.lineJoin = "round"; x.strokeStyle = th.acc2 || (th.dark ? "rgba(30,12,2,.55)" : th.acc); x.lineWidth = fs * .16; x.shadowColor = "rgba(0,0,0,.3)"; x.shadowBlur = 26; x.shadowOffsetY = 10; x.strokeText(l1, S / 2, y1);
    x.shadowColor = "transparent"; x.fillStyle = th.ink; x.fillText(l1, S / 2, y1);
    if (l2) { let f2 = 76; x.font = `800 ${f2}px ${F}`; let w2 = x.measureText(l2).width; if (w2 > S * .7) { f2 = Math.max(44, Math.floor(f2 * S * .7 / w2)); x.font = `800 ${f2}px ${F}`; w2 = x.measureText(l2).width; }
      const y2 = y1 + fs * .62 + f2 * .75, pw = w2 + f2 * 1.3, ph = f2 * 1.55;
      x.shadowColor = "rgba(0,0,0,.25)"; x.shadowBlur = 18; x.shadowOffsetY = 8; x.fillStyle = th.acc; x.beginPath(); x.roundRect(S / 2 - pw / 2, y2 - ph / 2, pw, ph, ph / 2); x.fill();
      x.shadowColor = "transparent"; x.fillStyle = th.pillInk || "#fff"; x.fillText(l2, S / 2, y2 + f2 * .04); }
    x.restore();
  }
  const short = (s, n) => { s = String(s || "").replace(/\s+/g, " ").trim(); if (s.length <= n) return s; const w = s.slice(0, n + 1); const k = w.lastIndexOf(" "); return (k > n * .5 ? w.slice(0, k) : s.slice(0, n)).trim(); };

  /* ============================================================ التركيب */
  function render(A, B, o) {
    o = o || {}; const name = String(o.name || ""), txt = name + " " + String(o.text || ""), ids = o.theme && o.theme !== "auto" && T[o.theme] ? [o.theme] : detect(txt, o.group);
    const base = T[ids[0]], th = Object.assign({}, base), two = ids[1] && T[ids[1]];
    const R = rng(hash(name + "|" + ids[0]) + (o.seed | 0) * 7919);
    const hue = A ? dominant(A) : null;
    if (o.card && A) { A = photoCard(A); B = null; }
    if (!th.bg) { const h = hue == null ? 255 : hue; th.bg = [hsl(h, 55, 34), hsl(h + 12, 60, 18), hsl(h + 24, 65, 8)]; th.floor = [hsl(h, 50, 26), hsl(h + 20, 60, 8)]; th.pod = [hsl(h, 30, 96), hsl(h, 35, 84), hsl(h, 40, 62)]; th.acc2 = hsl(h + 20, 60, 12, .5); th.pillInk = "#3b2a05"; }
    if (["#f3cf7a", "#fff0c9", "#f1d7a8", "#ffd27a"].includes(th.acc)) th.pillInk = "#3b2305";
    /* نوع السطح: الافتراضي للنمط + تنويع حسب البذرة */
    const alt = { gloss: ["gloss", "gloss", "podium"], wood: ["wood", "wood", "podium"], podium: ["podium", "gloss"], marble: ["marble", "podium", "gloss"] }[th.surf] || ["gloss"];
    const surf = alt[Math.floor(R() * alt.length)], hy = S * (surf === "wood" || surf === "marble" ? .66 : .7);
    const c = mk(S, S); let x = c.getContext("2d"); x.imageSmoothingQuality = "high";
    backdrop(x, th, R, hue != null && !base.bg ? hsl(hue, 80, 70, .5) : null);
    /* الطبقة الناعمة: أشعة + بوكيه + عناصر خلفية ضبابية (عمق الميدان) — على لوحة 1/6 ثم تكبير */
    const back = (th.back || []).concat(two ? two.back.slice(0, 2) : []);
    const K = 6, lo = mk(S / K, S / K), lx = lo.getContext("2d"); lx.scale(1 / K, 1 / K);
    softLight(lx, R);
    for (let i = 0; i < 9; i++) { const nm = back[Math.floor(R() * back.length)], side = i % 2, px = side ? S * (.7 + R() * .28) : S * (.02 + R() * .28), py = S * (.2 + R() * .42), s = S * (.07 + R() * .1); put(lx, nm, px, py, s, (R() - .5) * 2.4, R, { a: .6 + R() * .3 }); }
    x.imageSmoothingEnabled = true; x.imageSmoothingQuality = "high"; x.drawImage(lo, 0, 0, S, S);
    if (th.swirl) swirlBand(x, th.swirl, S * (.36 + R() * .1), S * .07, S * .2, R, R() > .5);
    if (th.ribbon && R() > .35) ribbon(x, R, 1);
    surface(x, th, surf === "podium" ? "gloss" : surf, hy, R);
    if (th.swirl && surf !== "wood") { x.save(); x.globalAlpha = .9; for (let k = 3; k >= 1; k--) { x.strokeStyle = k % 2 ? th.swirl[2] : th.swirl[0]; x.globalAlpha = .18; x.lineWidth = 18; x.beginPath(); x.ellipse(S * .5, S * .9, S * .2 * k, S * .035 * k, 0, 0, TAU); x.stroke(); } x.restore(); }
    /* المنتج */
    let bottom = S * .835; const maxW = S * (B ? .56 : .64), maxH = S * (o.title === false ? .68 : .585);
    if (surf === "podium") { bottom = S * .80; podium(x, th, bottom - 6, S * .37, R); }
    /* توهّج خلف المنتج */
    x.fillStyle = rad(x, S * .5, bottom - maxH * .5, 20, S * .5, ["rgba(255,255,255,.42)", "rgba(255,255,255,.1)", "rgba(255,255,255,0)"]); x.fillRect(0, 0, S, S);
    if (th.steam) { const st = mk(S / 10, S / 10), sx2 = st.getContext("2d"); sx2.scale(.1, .1); sx2.strokeStyle = "rgba(255,255,255,.34)"; sx2.lineWidth = 46; sx2.lineCap = "round"; for (let i = -1; i <= 1; i++) { sx2.beginPath(); const sx = S * .5 + i * S * .11, sy = bottom - maxH * .96; sx2.moveTo(sx, sy); sx2.bezierCurveTo(sx - 70, sy - 120, sx + 80, sy - 220, sx - 10, sy - 360); sx2.stroke(); } x.drawImage(st, 0, 0, S, S); }
    const refl = surf !== "wood" && !o.card, left = R() > .5;
    /* وضع الطبقات (محرر «صورة إعلانية»): الخلفية وحدها + طبقة أمامية شفافة ، والمنتج يضعه المحرر بينهما */
    let fc = null; if (o.layers) { fc = mk(S, S); x = fc.getContext("2d"); x.imageSmoothingQuality = "high"; }
    else if (!B) { const [w, h] = fit(A, maxW, maxH); product(x, A, S * .5, bottom, w, h, { refl, left }); }
    else { const [w, h] = fit(A, maxW, maxH); const [w2, h2] = fit(B, Math.max(w * .8, S * .34), S * .24); product(x, A, S * .54, bottom - S * .02, w, h, { refl, left }); product(x, B, S * .38, Math.min(S * .93, bottom + h2 * .42), w2, h2, { refl, left }); }
    /* عناصر أمامية: عنقودان على الجانبين + قطع صغيرة في الوسط */
    const fore = (two && ids[0] === "choco" ? th.fore.filter(n => n !== "hazel") : th.fore || []).concat(two ? two.fore.slice(0, 3) : []), pick = () => fore[Math.floor(R() * fore.length)];
    const flat = n => n === "wdrop" || n === "dust" || n === "confetti" || n === "spark" || n === "bubble";
    [0, 1].forEach(side => { const n = 3 + Math.floor(R() * 2), cx0 = side ? S * .87 : S * .13;
      for (let i = 0; i < n; i++) { const nm = pick(), s = S * (flat(nm) ? .07 + R() * .06 : .12 + R() * .075), px = cx0 + (R() - .5) * S * .17, py = bottom + S * (.005 + R() * .1) - (flat(nm) ? 0 : s * .32); put(x, nm, px, py, s, (R() - .5) * (nm === "lolli" ? .7 : 1.6), R, { shadow: !flat(nm) }); } });
    for (let i = 0; i < 3; i++) { const nm = pick(), s = S * (.05 + R() * .05); put(x, nm, S * (.3 + R() * .4), bottom + S * (.085 + R() * .06), s, (R() - .5) * 2, R, { shadow: !flat(nm) }); }
    if (fore.includes("bubble") || back.includes("bubble")) for (let i = 0; i < 6; i++) put(x, "bubble", i % 2 ? S * (.8 + R() * .17) : S * (.03 + R() * .17), S * (.24 + R() * .5), S * (.05 + R() * .08), 0, R, { a: .9 });
    if (th.ribbon && R() > .3) ribbon(x, R, 0);
    for (let i = 0; i < 6; i++) put(x, "spark", i % 2 ? S * (.74 + R() * .22) : S * (.04 + R() * .22), S * (.22 + R() * .6), S * (.025 + R() * .04), R(), R, { a: .85 });
    /* العنوان */
    if (o.title !== false) {
      const fl = [th.fl, two && two.fl].filter(Boolean);
      const l1 = o.head || (fl.length === 2 ? "بطعمين!" : th.tag), l2 = o.sub != null ? o.sub : (fl.length === 2 ? fl[0] + " + " + fl[1] : short(name, 34));
      title(x, th, l1, l2);
    }
    /* تعتيم الأطراف + إطار رفيع */
    x.fillStyle = rad(x, S * .5, S * .5, S * .45, S * .78, ["rgba(0,0,0,0)", "rgba(0,0,0,.26)"]); x.fillRect(0, 0, S, S);
    if (R() > .5) { x.strokeStyle = "rgba(255,255,255,.55)"; x.lineWidth = 6; x.strokeRect(46, 46, S - 92, S - 92); }
    if (o.layers) return { back: c, front: fc, slot: { cx: S * .5, bottom, maxW, maxH, refl, left, surf }, ids, size: S };
    return c;
  }
  /* ============================================================ خلفية حقيقية (صورة فوتوغرافية مولَّدة) — 2026
     prompt(): وصف إنجليزي للمشهد من نمط الصنف (لا يُرسل اسم الصنف ولا صورته) + بذرة من الاسم ← لكل صنف خلفيته.
     renderPhoto(): المنتج الحقيقي فوق الصورة مع ظل تلامس وعنوان. */
  const EN = {
    choco: ["broken chocolate bar pieces and cocoa powder", "dark chocolate brown"], hazel: ["whole hazelnuts", "warm brown"], almond: ["whole almonds", "warm beige"],
    pistachio: ["pistachio nuts in their shells", "soft green"], walnut: ["whole and cracked walnuts", "warm beige"], peanut: ["peanuts in their shells", "warm yellow"],
    coconut: ["coconut halves and coconut flakes", "light turquoise"], nuts: ["mixed nuts", "warm beige"], date: ["dates fruit and green palm leaves", "warm golden brown"],
    strawberry: ["fresh red strawberries", "soft pink"], mint: ["fresh mint leaves and ice cubes", "fresh mint green"], watermelon: ["watermelon slices", "light green"],
    citrus: ["orange and lemon slices", "sunny yellow"], cherry: ["fresh red cherries", "soft pink red"], fruit: ["assorted fresh fruits", "warm orange"],
    caramel: ["caramel candies and caramel drizzle", "golden caramel"], honey: ["honeycomb and a wooden honey dipper", "warm golden amber"], milk: ["a splash of milk and a glass of milk", "light blue and white"], coffee: ["roasted coffee beans", "dark coffee brown"],
    candy: ["colorful candies and lollipops", "pastel purple and pink"], biscuit: ["cookies and biscuit crumbs", "warm beige"], drink: ["ice cubes and water droplets", "fresh light blue"],
    snack: ["crispy potato chips", "warm yellow orange"], clean: ["soap bubbles and folded white towels", "clean light blue"], beauty: ["pink flower petals and silk fabric", "soft rose"],
    pantry: ["fresh vegetables, herbs and a small bowl of olive oil", "warm kitchen beige"], tea: ["green tea leaves and a cup of tea", "soft olive green"], spice: ["red chili peppers and colorful spices", "warm red orange"],
    baby: ["soft pastel baby toys", "pastel blue and pink"], premium: ["elegant golden ribbons", "deep"]
  };
  const HUE = ["red", "orange", "golden yellow", "lime green", "green", "teal", "cyan", "blue", "indigo", "purple", "magenta", "pink"];
  function prompt(o, A) {
    o = o || {}; const name = String(o.name || ""), txt = name + " " + String(o.text || ""), ids = o.theme && o.theme !== "auto" && T[o.theme] ? [o.theme] : detect(txt, o.group);
    const th = T[ids[0]], R = rng(hash(name + "|" + ids[0]) + (o.seed | 0) * 7919), pk = a => a[Math.floor(R() * a.length)];
    const surf = th.surf === "wood" ? pk(["rustic wooden table top", "light oak wooden table top", "dark walnut wooden table top"]) : th.surf === "marble" ? "white marble counter top" : pk(["glossy reflective studio table top", "smooth clean studio table top", "light wooden table top"]);
    let mood = EN[ids[0]][1]; if (ids[0] === "premium") { const h = A ? dominant(A) : null; mood = (h == null ? "deep purple" : "deep " + HUE[Math.floor(h / 30) % 12]) + " luxury"; }
    const things = ids.slice(0, 2).map(i => EN[i][0]).join(" and ");
    const p = "commercial advertising product photography background, " + surf + " filling the bottom third of the image, empty free space in the center, " + things + " lying on the table at the far left and far right edges, softly blurred " + mood + " backdrop with bokeh lights, soft studio lighting, photorealistic, high detail, no text, no letters, no logo, no packaging, no box, no bottle, no people";
    const seed = 1000 + hash(name + "|" + ids.join("+")) % 90000 + (o.seed | 0) * 37;
    return { prompt: p, seed, key: p + "#" + seed, ids };
  }
  /* متوسط لون منطقة من الخلفية (r,g,b) */
  function avgCol(src, fx, fy, fw, fh) {
    try { const c = mk(8, 8), x = c.getContext("2d", { willReadFrequently: true }), W = src.naturalWidth || src.width, H = src.naturalHeight || src.height; x.drawImage(src, fx * W, fy * H, fw * W, fh * H, 0, 0, 8, 8);
      const d = x.getImageData(0, 0, 8, 8).data; let r = 0, g = 0, b = 0; for (let i = 0; i < d.length; i += 4) { r += d[i]; g += d[i + 1]; b += d[i + 2]; } const n = d.length / 4; return [r / n, g / n, b / n]; } catch (e) { return [128, 128, 128]; }
  }
  /* دمج المنتج مع إضاءة المشهد: صبغة محيطة خفيفة + تدرّج ضوء من الأعلى + تعتيم عند القاعدة (ملامسة الطاولة) + «التفاف الضوء» على الحواف */
  function blendIn(im, w, h, amb, floor, bgBlur, px, py) {
    const c = mk(w, h), x = c.getContext("2d"); x.imageSmoothingQuality = "high"; x.drawImage(im, 0, 0, w, h);
    x.globalCompositeOperation = "source-atop";
    x.fillStyle = `rgba(${amb[0] | 0},${amb[1] | 0},${amb[2] | 0},.10)`; x.fillRect(0, 0, w, h);                                    // صبغة لون المشهد
    x.fillStyle = lin(x, 0, 0, 0, h, ["rgba(255,255,255,.10)", "rgba(255,255,255,0)", "rgba(0,0,0,0)", "rgba(0,0,0,.22)"]); x.fillRect(0, 0, w, h);   // ضوء علوي + ظل سفلي
    x.fillStyle = lin(x, 0, h * .9, 0, h, [`rgba(${floor[0] | 0},${floor[1] | 0},${floor[2] | 0},0)`, `rgba(${floor[0] * .55 | 0},${floor[1] * .55 | 0},${floor[2] * .55 | 0},.30)`]); x.fillRect(0, h * .9, w, h * .1);   // انعكاس لون الطاولة على القاعدة
    /* التفاف الضوء: الخلفية الضبابية تتسرب على حافة المنتج */
    const k = Math.max(6, Math.round(w * .02));
    for (let j = 1; j <= 3; j++) {                                                                                                   // ثلاث حلقات متداخلة ← تدرّج ناعم من الحافة للداخل
      const e = mk(w, h), ex = e.getContext("2d"), d = k * j / 3; ex.drawImage(im, 0, 0, w, h); ex.globalCompositeOperation = "destination-out"; ex.drawImage(im, d, d, w - 2 * d, h - 2 * d);
      ex.globalCompositeOperation = "source-in"; ex.drawImage(bgBlur, px, py, w, h, 0, 0, w, h);
      x.globalAlpha = .1; x.drawImage(e, 0, 0);
    }
    x.globalAlpha = 1; x.globalCompositeOperation = "source-over";
    return c;
  }
  function productReal(x, im, cx, bottom, w, h, o) {
    /* ظل ممتد ناعم + ظل تلامس ضيق داكن ← المنتج «جالس» على الطاولة لا عائم */
    const sh = (rx, ry, a, dy) => { x.save(); x.translate(cx + (o.left ? w * .05 : -w * .05), bottom + dy); x.scale(1, ry / rx); x.fillStyle = rad(x, 0, 0, 0, rx, [`rgba(0,0,0,${a})`, `rgba(0,0,0,${a * .45})`, "rgba(0,0,0,0)"]); x.beginPath(); x.arc(0, 0, rx, 0, TAU); x.fill(); x.restore(); };
    sh(w * .78, w * .13, .36, w * .02); sh(w * .5, w * .035, .62, 0);
    /* انعكاس خافت على السطح */
    const t = mk(w, h * .22), tx = t.getContext("2d"); tx.save(); tx.translate(0, h); tx.scale(1, -1); tx.drawImage(im, 0, 0, w, h); tx.restore(); tx.globalCompositeOperation = "destination-in"; tx.fillStyle = lin(tx, 0, 0, 0, t.height, ["rgba(0,0,0,.16)", "rgba(0,0,0,0)"]); tx.fillRect(0, 0, w, t.height); x.drawImage(t, cx - w / 2, bottom + 1);
    x.save(); x.shadowColor = "rgba(0,0,0,.28)"; x.shadowBlur = 34; x.shadowOffsetX = o.left ? 12 : -12; x.shadowOffsetY = 6; x.drawImage(im, cx - w / 2, bottom - h); x.restore();
  }
  function renderPhoto(bg, A, B, o) {
    o = o || {}; const name = String(o.name || ""), txt = name + " " + String(o.text || ""), ids = o.theme && o.theme !== "auto" && T[o.theme] ? [o.theme] : detect(txt, o.group);
    const th = Object.assign({}, T[ids[0]], { dark: 1, acc2: "rgba(0,0,0,.5)", ink: "#ffffff" }), two = ids[1] && T[ids[1]], R = rng(hash(name + "|" + ids[0]) + (o.seed | 0) * 7919);
    if (o.card) { A = photoCard(A); B = null; }
    const c = mk(S, S), x = c.getContext("2d"); x.imageSmoothingEnabled = true; x.imageSmoothingQuality = "high";
    const bw = bg.naturalWidth || bg.width, bh = bg.naturalHeight || bg.height, k = Math.max(S / bw, S / bh), w0 = bw * k, h0 = bh * k;
    x.drawImage(bg, (S - w0) / 2, (S - h0) / 2, w0, h0);
    if (o.title !== false) { x.fillStyle = lin(x, 0, 0, 0, S * .34, ["rgba(0,0,0,.42)", "rgba(0,0,0,0)"]); x.fillRect(0, 0, S, S * .34); }
    const bottom = S * .868, maxW = S * (B ? .5 : .56), maxH = S * (o.title === false ? .66 : .56);
    x.fillStyle = rad(x, S * .5, bottom - maxH * .5, 20, S * .46, ["rgba(255,255,255,.3)", "rgba(255,255,255,.08)", "rgba(255,255,255,0)"]); x.fillRect(0, 0, S, S);
    const left = R() > .5, amb = avgCol(bg, .2, .25, .6, .4), floor = avgCol(bg, .2, .78, .6, .16);
    const bl = mk(S / 16, S / 16); bl.getContext("2d").drawImage(c, 0, 0, bl.width, bl.height); const bgBlur = mk(S, S), bx = bgBlur.getContext("2d"); bx.imageSmoothingQuality = "high"; bx.drawImage(bl, 0, 0, S, S);
    const place = (im, cx, bt, mw, mh) => { let [w, h] = fit(im, mw, mh); w = Math.round(w); h = Math.round(h); const px = Math.round(cx - w / 2), py = Math.round(bt - h); productReal(x, o.card ? im : blendIn(im, w, h, amb, floor, bgBlur, px, py), cx, bt, w, h, { left }); return [w, h]; };
    if (o.card) { const [w, h] = fit(A, maxW, maxH); const t = mk(w, h); t.getContext("2d").drawImage(A, 0, 0, w, h); productReal(x, t, S * .5, bottom, Math.round(w), Math.round(h), { left }); }
    else if (!B) place(A, S * .5, bottom, maxW, maxH);
    else { const [w] = place(A, S * .54, bottom - S * .02, maxW, maxH); place(B, S * .37, S * .93, Math.max(w * .8, S * .3), S * .22); }
    /* طبقة لون موحِّدة خفيفة فوق الكل ← المنتج والخلفية بنفس «التدرج اللوني» */
    x.save(); x.globalCompositeOperation = "soft-light"; x.fillStyle = `rgba(${amb[0] | 0},${amb[1] | 0},${amb[2] | 0},.16)`; x.fillRect(0, 0, S, S); x.restore();
    if (o.title !== false) {
      const fl = [th.fl, two && two.fl].filter(Boolean);
      title(x, th, o.head || (fl.length === 2 ? "بطعمين!" : th.tag), o.sub != null ? o.sub : (fl.length === 2 ? fl[0] + " + " + fl[1] : short(name, 34)));
    }
    x.fillStyle = rad(x, S * .5, S * .5, S * .5, S * .8, ["rgba(0,0,0,0)", "rgba(0,0,0,.22)"]); x.fillRect(0, 0, S, S);
    return c;
  }
  window.ANOUER_ADSCENE = { render, renderPhoto, prompt, detect, hash, blendIn, avgCol, short,
    themeOf: id => Object.assign({}, T[id] || T.premium),
    drawTitle: (x, l1, l2, th) => title(x, Object.assign({ acc: "#e0478c", ink: "#ffffff", dark: 1 }, th || {}), l1, l2), themes: () => ORDER.concat(["premium"]).map(id => [id, T[id].t, T[id].e]), label: id => (T[id] || T.premium).t };
})();
