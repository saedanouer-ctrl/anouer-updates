/* ANOUER — «المصروفات» Ctrl+K، «الإيرادات» Alt+I، «قيود المحاسبة» Ctrl+T، «تحويل النقدية»، «سداد الضرائب» و«تسويات ضريبية» — مطابقة DEXEF ONE */
(function () {
  "use strict";
  const A = window.__AC, H = window.__FH;
  if (!A || !H) return;
  const { esc, fmt, r2, num, say, today, tabOpen, Dlg } = H;
  let G_NB_CSS = 0;
  const { I } = A;
  const CC = ["", "مركز التكلفة الرئيسي"];
  const TAXES = [["", ""], ["vat19", "ضريبة القيمة المضافة 19%", 19], ["vat9", "ضريبة القيمة المضافة 9%", 9], ["stamp", "ضريبة الطابع 1%", 1]];
  const taxRate = k => { const t = TAXES.find(x => x[0] === k); return t ? +t[2] || 0 : 0; };
  const EXPT = [["gen", "مصروف عام", "eitm"], ["cred", "مصروف على الإعتماد", "dtax"], ["asset", "مصروف على الأصول", "bk"]];
  const ALLV = ["التاريخ", "البيان"];

  /* ================================================================== «مصروف مدفوع مقدماً» (2026-11-24)
     مثال: إيجار 3 أشهر = 90,000 ← الشهر 30 يوماً (مثل الرواتب) ← 1,000 يومياً في الأرباح والخسائر.
     ─ شجرة الحسابات: الدفع = مدين 126 «مصروفات مدفوعة مقدما» / دائن الخزينة (أصل ، لا يمس الأرباح)
       ثم قيد إطفاء آلي لكل شهر يتحدّث يوماً بيوم: مدين بند المصروف (الإيجار) / دائن 126 بحصة الأيام المنقضية.
     ─ التقارير (reports.js): المستند الموزّع لا يدخل كاملاً ، بل حصة أيام الفترة فقط (ANOUER_PREPAID.cost).
     ─ الحصص تراكمية (cum) فمجموع الأيام = المبلغ بالضبط بلا فرق تقريب. */
  const PP = (() => {
    const DAY = 864e5, tN = x => Math.round(Date.parse(String(x).slice(0, 10) + "T00:00:00Z") / DAY), iso = n => new Date(n * DAY).toISOString().slice(0, 10);
    const MN = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
    const ACC_NO = "126";
    const on = d => !!(d && d.data && d.data.spread && d.data.spread.on && +d.data.spread.days > 0 && d.data.spread.from);
    const N = s => Math.max(1, Math.round(+s.days || 0));
    const endOf = s => iso(tN(s.from) + N(s) - 1);
    const cum = (s, x) => Math.max(0, Math.min(N(s), tN(x) - tN(s.from) + 1));
    const share = (amt, s, a, b) => { const n = N(s), hi = cum(s, b), lo = cum(s, iso(tN(a) - 1)); return hi <= lo ? 0 : r2(r2(amt * hi / n) - r2(amt * lo / n)); };
    const ymNext = ym => { let [y, m] = ym.split("-").map(Number); m++; if (m > 12) { m = 1; y++; } return y + "-" + String(m).padStart(2, "0"); };
    const mEnd = ym => { const [y, m] = ym.split("-").map(Number); return iso(tN(ymNext(ym) + "-01") - 1) || (y + "-" + m); };
    const mName = ym => MN[+ym.slice(5, 7) - 1] + " " + ym.slice(0, 4);
    const daysOf = (n, unit) => unit === "d" ? Math.max(1, Math.round(+n || 0)) : Math.max(1, Math.round(+n || 0)) * 30;
    function acc() { if (!A.coaTree) return Promise.resolve(null);
      return A.coaTree().then(t => { let n = t.byNo[ACC_NO]; while (n && n.kids && n.kids.length) n = n.kids[0]; return n ? { id: n.id, no: n.no, name: n.name } : null; }).catch(() => null); }
    function calc(list, from, to) {
      const R = { on: false, total: 0, items: [], byName: {}, days: {} };
      (list || []).filter(on).forEach(d => { const s = d.data.spread, end = endOf(s); if (end < from || s.from > to) return;
        const a = s.from > from ? s.from : from, b = end < to ? end : to, nd = tN(b) - tN(a) + 1;
        (d.data.rows || []).forEach(rw => { const amt = +rw.amt || 0; if (!(amt > 0)) return; const v = share(amt, s, a, b); if (!v) return; const nm = rw.name || "مصروفات";
          R.on = true; R.items.push({ name: nm, amt: v, days: nd, perDay: r2(amt / N(s)), no: d.no, from: s.from, to: end, total: amt, stmt: d.data.stmt || "" });
          R.byName[nm] = r2((R.byName[nm] || 0) + v); R.total = r2(R.total + v);
          for (let k = tN(a); k <= tN(b); k++) { const ds = iso(k); R.days[ds] = r2((R.days[ds] || 0) + share(amt, s, ds, ds)); } }); });
      return R;
    }
    function cost(from, to) { return A.docs("exp", true).catch(() => []).then(l => calc(l, from, to)); }
    /* قيد الإطفاء الشهري: واحد لكل شهر ، يُعاد حسابه كلما تغيّر شيء (حفظ/حذف/مرور الأيام) */
    let SY = null;
    function sync() {
      if (SY) return SY;
      SY = Promise.all([A.docs("exp", true).catch(() => []), A.docs("je", true).catch(() => []), acc()]).then(([ex, je, ac]) => {
        const sp = ex.filter(on), now = today(), months = new Set();
        sp.forEach(d => { const s = d.data.spread; if (s.from > now) return; let e = endOf(s); if (e > now) e = now; for (let ym = s.from.slice(0, 7); ym <= e.slice(0, 7); ym = ymNext(ym)) months.add(ym); });
        (je || []).forEach(j => { if (j.data && j.data.pp) months.add(j.data.pp); });
        if (!months.size) return 0;
        if (!ac) return { err: "حساب «مصروفات مدفوعة مقدما» (" + ACC_NO + ") غير موجود في شجرة الحسابات" };
        let chain = Promise.resolve(0);
        Array.from(months).sort().forEach(ym => { chain = chain.then(n => one(ym, sp, je, ac, now).then(c => n + (c || 0))); });
        return chain.then(n => { if (n) { try { A.invalidate(); if (window.__AC_REFRESH) __AC_REFRESH("je"); } catch (e) { } } return n; });
      }).catch(e => ({ err: e.message || String(e) })).finally(() => { SY = null; });
      return SY;
    }
    function one(ym, sp, je, ac, now) {
      const from = ym + "-01", me = mEnd(ym), to = me < now ? me : now, per = {};
      sp.forEach(d => { const s = d.data.spread, e = endOf(s); if (e < from || s.from > to) return; const a = s.from > from ? s.from : from, b = e < to ? e : to;
        (d.data.rows || []).forEach(rw => { if (!rw.iid) return; const v = share(+rw.amt || 0, s, a, b); if (!v) return; const o = per[rw.iid] || (per[rw.iid] = { iid: rw.iid, name: rw.name, no: rw.no || "", amt: 0 }); o.amt = r2(o.amt + v); }); });
      const L = Object.values(per).filter(o => o.amt > 0), amt = r2(L.reduce((a, o) => a + o.amt, 0));
      const docs = (je || []).filter(j => j.data && j.data.pp === ym), doc = docs[0];
      const sig = L.map(o => o.iid + "=" + o.amt).join("|") + "@" + to;
      if (amt <= 0) return docs.length ? Promise.all(docs.map(j => A.delDoc("je", j.id))).then(() => 1) : Promise.resolve(0);
      if (doc && docs.length === 1 && doc.data.sig === sig) return Promise.resolve(0);
      const stmt = "إطفاء المصروفات المدفوعة مقدماً — " + mName(ym) + " (حصة الأيام المنقضية)";
      const rows = L.map(o => ({ t: "exp", no: o.no, name: o.name, aid: o.iid, dr: o.amt, cr: 0, note: "حصة أيام " + mName(ym) })).concat([{ t: "gl", no: ac.no, name: ac.name, aid: ac.id, dr: 0, cr: amt, note: "من المدفوع مقدماً" }]);
      const lg = L.map(o => ({ t: "exp", id: o.iid, d: o.amt, name: o.name, what: "قيد" })).concat([{ t: "gl", id: ac.id, d: -amt, name: ac.name, what: "قيد" }]);
      const data = { date: to, time: A.nowT(), br: (sp[0] && sp[0].data.br) || "", stmt, cc: "", notes: "آلي — المصروفات الموزّعة على مدة (يتحدّث تلقائياً)", rows, dr: amt, cr: amt, total: amt, fx: [], lg, user: (window.__USER_NAME || "ANOUER"), pp: ym, sig };
      const extra = docs.slice(1).map(j => A.delDoc("je", j.id));
      return Promise.all(extra).then(() => doc ? A.saveDoc("je", { id: doc.id, no: doc.no, data }) : A.nextNo("je").then(no => A.saveDoc("je", { id: 0, no, data }))).then(() => 1);
    }
    return { on, endOf, share, cost, calc, sync, acc, daysOf, cum, N, ACC_NO, tN, iso };
  })();
  window.ANOUER_PREPAID = PP;
  (function css() { if (document.getElementById("acPpCss")) return; const st = document.createElement("style"); st.id = "acPpCss"; st.textContent = `
.ac-pp{margin:6px 0 8px;border:1px solid #e3e8ef;border-radius:12px;background:linear-gradient(180deg,#fbfcfe,#f6f8fb);overflow:hidden;transition:border-color .2s,box-shadow .25s,background .25s;direction:rtl}
.ac-pp.on{border-color:#f3b08a;background:linear-gradient(135deg,#fffaf6,#fff 60%);box-shadow:0 10px 26px -18px rgba(217,72,15,.55)}
.ac-pp .pp-h{display:flex;align-items:center;gap:12px;padding:9px 14px;cursor:pointer;user-select:none}
.ac-pp .pp-ic{width:34px;height:34px;border-radius:10px;display:grid;place-items:center;background:#eef2f7;color:#64748b;flex:none;transition:all .25s}
.ac-pp.on .pp-ic{background:linear-gradient(135deg,#ff8a3d,#e8590c);color:#fff;box-shadow:0 6px 14px -6px #e8590c}
.ac-pp .pp-ic svg{width:18px;height:18px}
.ac-pp .pp-t{flex:1;min-width:0}.ac-pp .pp-t b{display:block;font-size:13.5px;color:#1f2937}.ac-pp .pp-t small{display:block;font-size:11.5px;color:#7b8794;margin-top:1px}
.ac-pp .pp-sw{position:relative;width:40px;height:22px;border-radius:12px;background:#cbd5e1;flex:none;transition:background .2s}
.ac-pp .pp-sw:after{content:"";position:absolute;top:3px;right:3px;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.25);transition:right .22s cubic-bezier(.3,1.4,.5,1)}
.ac-pp.on .pp-sw{background:#e8590c}.ac-pp.on .pp-sw:after{right:21px}
.ac-pp .pp-b{display:none;padding:2px 14px 12px;gap:14px;align-items:stretch}
.ac-pp.on .pp-b{display:flex;animation:ppIn .3s ease}
@keyframes ppIn{from{opacity:0;transform:translateY(-4px)}}
.ac-pp .pp-f{display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap}
.ac-pp label{display:flex;flex-direction:column;gap:3px;font-size:11.5px;color:#5b6573}
.ac-pp input,.ac-pp select{height:30px;border:1px solid #d5dce5;border-radius:8px;padding:0 8px;font:13px "Segoe UI",Tahoma;background:#fff;outline:0}
.ac-pp input:focus,.ac-pp select:focus{border-color:#f08a4b;box-shadow:0 0 0 3px rgba(240,138,75,.15)}
.ac-pp input[type=number]{width:70px;text-align:center;font-weight:700}
.ac-pp .pp-end{height:30px;display:flex;align-items:center;padding:0 10px;border-radius:8px;background:#f1f5f9;font:600 13px "Segoe UI",Tahoma;color:#334155;white-space:nowrap}
.ac-pp .pp-s{flex:1;min-width:260px;display:flex;flex-direction:column;gap:8px;justify-content:center}
.ac-pp .pp-chips{display:flex;gap:8px;flex-wrap:wrap}
.ac-pp .pp-c{display:flex;flex-direction:column;padding:5px 12px;border-radius:10px;background:#fff;border:1px solid #f1d7c6;min-width:92px}
.ac-pp .pp-c small{font-size:10.5px;color:#8a6f5e}.ac-pp .pp-c b{font:800 16px Arial,sans-serif;color:#c2410c;direction:ltr;text-align:right}
.ac-pp .pp-c.k{border-color:#dbe4ee}.ac-pp .pp-c.k b{color:#1f2937}
.ac-pp .pp-tl{position:relative;height:8px;border-radius:6px;background:#eef2f7;overflow:visible;margin-top:16px}
.ac-pp .pp-tl i{position:absolute;inset-block:0;right:0;border-radius:6px;background:linear-gradient(270deg,#ff9a52,#e8590c);transition:width .5s cubic-bezier(.2,.9,.2,1)}
.ac-pp .pp-tl em{position:absolute;top:-5px;width:2px;height:18px;background:#1f2937;border-radius:2px;font-style:normal}
.ac-pp .pp-tl em:after{content:"اليوم";position:absolute;top:-16px;left:50%;transform:translateX(-50%);font:600 10px "Segoe UI";color:#1f2937;white-space:nowrap}
.ac-pp .pp-cap{display:flex;justify-content:space-between;font-size:11px;color:#7b8794}
.ac-pp .pp-note{font-size:11.5px;color:#5b6573}.ac-pp .pp-note b{color:#c2410c}
html.dk .ac-pp{background:#1f2429;border-color:#3a4450}html.dk .ac-pp.on{background:linear-gradient(135deg,#2a2320,#1f2429)}html.dk .ac-pp .pp-t b{color:#e5e7eb}
html.dk .ac-pp .pp-c{background:#262c33;border-color:#4a3a30}html.dk .ac-pp .pp-c.k b{color:#e5e7eb}html.dk .ac-pp input,html.dk .ac-pp select{background:#262c33;color:#e5e7eb;border-color:#3a4450}
html.dk .ac-pp .pp-end{background:#2a3038;color:#e5e7eb}html.dk .ac-pp .pp-tl{background:#2a3038}html.dk .ac-pp .pp-tl em,html.dk .ac-pp .pp-tl em:after{background:#e5e7eb;color:#e5e7eb}html.dk .ac-pp .pp-tl em:after{background:none}`;
    document.head.appendChild(st); })();

  /* شبكة سطور قابلة للتعديل بنمط DEXEF (سهم ← + خلايا + ✕) */
  /* ✦ (2026-11-26) سطر الإدخال الجديد بتصميم 2026: بدل الشريط الأزرق الكامل — سطر ناعم بإطار متقطع و«＋» ، يضيء عند التركيز */
  function lgCss() {
    if (document.getElementById("acLgCss")) return; const st = document.createElement("style"); st.id = "acLgCss";
    st.textContent = `.ac-lg .r.new{background:linear-gradient(90deg,rgba(59,130,246,.06),rgba(99,102,241,.08));border:1.5px dashed #93c5fd;border-radius:8px;margin:2px 2px;transition:background .2s,border-color .2s,box-shadow .2s}
.ac-lg .r.new input,.ac-lg .r.new select,.ac-lg .r.new>span:first-of-type+span input{background:transparent;color:#1e293b;border-color:transparent}
.ac-lg .r.new input::placeholder{color:#94a3b8;font-style:italic}
.ac-lg .r.new .ind{color:#3b82f6;font-weight:800;font-size:15px}
.ac-lg .r.new:focus-within{background:#fff;border-style:solid;border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,.15),0 6px 16px -10px rgba(37,99,235,.5)}
.ac-lg .r.new:focus-within input:focus{background:#eff6ff;box-shadow:none}
.ac-lg .r.new.lg-in{animation:lgIn .45s cubic-bezier(.2,1.2,.35,1)}
@keyframes lgIn{0%{transform:translateY(-10px);opacity:.2}100%{transform:none;opacity:1}}
.ac-lg .r.f{cursor:text}
@media (prefers-reduced-motion:reduce){.ac-lg .r.new.lg-in{animation:none}}`;
    document.head.appendChild(st);
  }
  function LGrid(host, cfg) {
    const G = { rows: [] };
    function render() {
      host.innerHTML = `<div class="ac-lg" style="--tpl:${cfg.tpl}"><div class="h"><span></span>${cfg.cols.map(c => `<span>${esc(c.t)}</span>`).join("")}<span></span></div><div class="b">${G.rows.map((r, i) => row(r, i)).join("")}${row(null, G.rows.length)}${Array.from({ length: Math.max(0, (cfg.min || 9) - G.rows.length - 1) }, (_, k) => `<div class="r f${(G.rows.length + k + 1) % 2 ? " alt" : ""}"></div>`).join("")}</div>
        <div class="t"><span></span>${cfg.cols.map(c => `<span class="n">${c.sum ? fmt(G.rows.reduce((s, r) => s + (+r[c.k] || 0), 0)) : ""}</span>`).join("")}<span></span></div></div>`;
      if (cfg.onRender) cfg.onRender();
    }
    function row(r, i) {
      const nr = !r; r = r || {};
      lgCss();
      return `<div class="r${i % 2 ? " alt" : ""}${nr ? " new" : ""}" data-i="${i}"><span class="ind">${nr ? "＋" : ""}</span>${cfg.cols.map(c => `<span>${c.ro ? `<b class="ro${c.n ? " n" : ""}">${esc(c.f ? c.f(r) : r[c.k] || "")}</b>` : c.sel ? `<select data-c="${c.k}">${(typeof c.sel === "function" ? c.sel(r) : c.sel).map(o => A.opt(o[0], o[1], String(o[0]) === String(r[c.k] == null ? "" : r[c.k]))).join("")}</select>` : `<input data-c="${c.k}"${c.n ? ' class="n" inputmode="decimal"' : ""}${c.list ? ` list="${c.list}"` : ""}${nr && c.list ? ` placeholder="${esc("اكتب أو اختر " + c.t + "…")}"` : ""} value="${esc(r[c.k] == null || r[c.k] === 0 && c.n ? "" : r[c.k])}" autocomplete="off">`}</span>`).join("")}<span>${nr ? "" : `<button type="button" data-del="${i}" title="حذف السطر">${I.xr}</button>`}</span></div>`;
    }
    host.addEventListener("change", e => {
      const el = e.target, rr = el.closest(".r[data-i]"); if (!rr || !el.dataset.c) return; const i = +rr.dataset.i;
      const born = i >= G.rows.length && String(el.value || "").trim() !== "";
      if (i >= G.rows.length) G.rows.push(cfg.blank ? cfg.blank() : {});
      const r = G.rows[i], c = cfg.cols.find(x => x.k === el.dataset.c), old = r[el.dataset.c];
      r[el.dataset.c] = c && c.n ? r2(num(el.value)) : el.value;
      /* ✦ سطر جديد دخل الجدول ، أو مبلغ جديد اعتُمد ← «قطرة ناعمة» + دخول السطر بانسياب (نفس نغمة مصروفات المبيعات/المشتريات) */
      const sing = !!(c && c.sum && +r[el.dataset.c] > 0 && +r[el.dataset.c] !== +old);   /* نغمة واحدة للسطر: عند اعتماد مبلغه */
      Promise.resolve(cfg.onChange ? cfg.onChange(r, el.dataset.c, i) : 0).then(() => calmRender(sing ? i : -1));
    });
    /* ✦ (2026-11-26) إعادة الرسم بهدوء: الجدول لا يقفز ولا يفقد مكان المؤشر.
       الضغط على خانة أخرى (أو في الفراغ تحت الأسطر) بعد كتابة المبلغ: نرسم بعد أن يستقر التركيز ، ثم نعيد نفس الخانة ونفس التمرير */
    function scrollers() { const out = []; let el = host; while (el && el !== document.documentElement) { if (el.scrollHeight > el.clientHeight + 1 || el.scrollTop) out.push([el, el.scrollTop, el.scrollLeft]); el = el.parentElement; } return out; }
    function calmRender(chime) {
      setTimeout(() => {
        const a = document.activeElement, inH = a && host.contains(a) && a.dataset && a.dataset.c, ar = inH ? a.closest(".r[data-i]") : null;
        const pos = ar ? { i: +ar.dataset.i, c: a.dataset.c, s: a.selectionStart, e: a.selectionEnd, nw: ar.classList.contains("new") } : null;
        const b0 = host.querySelector(".b"), bs = b0 ? b0.scrollTop : 0, sc = scrollers();
        render();
        const b1 = host.querySelector(".b"); if (b1) b1.scrollTop = bs;
        sc.forEach(([el, t, l]) => { if (el !== b0 && el.isConnected) { el.scrollTop = t; el.scrollLeft = l; } });
        if (pos) { const el = host.querySelector(`.r[data-i="${pos.i}"] [data-c="${pos.c}"]`); if (el) { try { el.focus({ preventScroll: true }); if (el.setSelectionRange && pos.s != null) el.setSelectionRange(pos.s, pos.e); } catch (e) { } } }
        if (chime >= 0) { const rw = host.querySelector(`.r[data-i="${chime}"]`); if (rw) { try { if (window.ANOUER_CHIME) ANOUER_CHIME("expense", rw); } catch (e) { } } }
        const nw = host.querySelector(".r.new"); if (nw && chime >= 0) { nw.classList.remove("lg-in"); void nw.offsetWidth; nw.classList.add("lg-in"); }
      }, 0);
    }
    /* الضغط في الفراغ تحت الأسطر ← المؤشر في خانة «نوع المصروف» للسطر الجديد ، بدون تمرير ولا صوت */
    host.addEventListener("mousedown", e => {
      const f = e.target.closest(".r.f, .r.new > .ind"); if (!f || e.button !== 0) return;
      e.preventDefault();
      const nw = host.querySelector(".r.new"), el = nw && (nw.querySelector('[data-c="name"]') || nw.querySelector("input[data-c],select[data-c]"));
      const a = document.activeElement; if (a && host.contains(a) && a.dataset && a.dataset.c) a.dispatchEvent(new Event("change", { bubbles: true }));
      setTimeout(() => { const nw2 = host.querySelector(".r.new"), el2 = nw2 && (nw2.querySelector('[data-c="name"]') || nw2.querySelector("input[data-c],select[data-c]")) || el; if (el2) try { el2.focus({ preventScroll: true }); } catch (x) { } }, 10);
    });
    host.addEventListener("click", e => { const d = e.target.closest("[data-del]"); if (d) { G.rows.splice(+d.dataset.del, 1); render(); if (cfg.onDel) cfg.onDel(); } });
    host.addEventListener("keydown", e => { if (e.key !== "Enter" || !e.target.dataset.c) return; e.preventDefault(); const ins = [...host.querySelectorAll("input[data-c],select[data-c]")]; const j = ins.indexOf(e.target); e.target.dispatchEvent(new Event("change", { bubbles: true })); setTimeout(() => { const ins2 = [...host.querySelectorAll("input[data-c],select[data-c]")]; if (ins2[j + 1]) ins2[j + 1].focus(); }, 0); });
    return Object.assign(G, { set(r) { G.rows = r || []; render(); }, render });
  }
  function dl(id, items) { let d = document.getElementById(id); if (!d) { d = document.createElement("datalist"); d.id = id; document.body.appendChild(d); } d.innerHTML = items.map(x => `<option value="${esc(x)}">`).join(""); return id; }

  /* ================================================================== المصروفات / الإيرادات */
  function itemsDoc(kind, id) {
    if (id) { const ex = Object.values(A.DOCS).find(d => d.kind === kind && d.id === id); if (ex) { tabOpen(ex.key, ex.title, ex.view); return ex; } }
    const exp = kind === "exp", view = "ac" + kind, key = view + ":" + A.nextSeq(), title = A.TITLE[kind];
    const page = A.docPage(view, title, key);
    const D = A.DOCS[key] = { key, kind, view, page, title, id: 0, fx: [], lg: [], dirtyF: false };
    const tb = exp ? A.toolbar([["prev", "", I.prev], ["next", "", I.next], ["save", "حفظ", I.save, 0, "", 1], ["print", "طباعة", I.print, 0, "", 1], ["mail", "Email", I.mail], ["reload", "تحديث البيانات", I.spin], ["copy", "نسخ التعامل", I.dup], ["xls", "تصدير إلى Xls", I.xls, 0, "", 1], ["del", "حذف", I.del, 1], ["close", "إغلاق", I.close], ["att", "المرفقات", I.clip, 1]], [["cols", "إختيار الحقول", I.cols]])
      : A.toolbar([["save", "حفظ", I.save], ["savePrint", "حفظ و طباعة", I.print]], [["cols", "اختيار الحقول", I.cols]]);
    page.innerHTML = (exp ? '<div class="ac-tabs"><button type="button" class="on">عام</button><button type="button" data-a="fmt">تنسيق الإدخال</button></div>' : "") + tb + A.header() + `<div class="ac-body ac-items">
      <div class="ac-ir1">${exp ? `<div class="ac-fr v"><span class="lb">نوع المصروف</span><span class="ac-ap"><button type="button" class="ac-ty" data-a="etype">${I.eitm}<i>⌄</i></button><span class="ac-etxt" data-k="etxt">مصروف عام</span></span></div>` : ""}
        <div class="ac-banner ${exp ? "red" : "green"}">${esc(title)}</div><div class="ac-fr v vm"><span class="lb">طريقة العرض</span><span class="ac-cb"><input value="" readonly><i class="ok">✓</i><button type="button" class="dd" tabindex="-1">⌄</button></span></div></div>
      <div class="ac-ir2"><div class="ac-fr v w"><span class="lb">البيان</span><input data-k="stmt" autocomplete="off"><i class="req">${exp ? "" : "*"}</i></div>
        <div class="ac-fr v"><span class="lb">الضريبة</span>${A.selH("tax", TAXES.map(t => [t[0], t[1]]), "")}</div><div class="ac-fr v"><span class="lb">مركز التكلفة</span>${A.selH("cc", CC, "")}</div>
        ${exp ? `<div class="ac-fr v"><span class="lb">الاعتماد</span>${A.selH("credit", ["", "اعتماد مستندى"], "")}</div>` : ""}<div class="ac-fr v"><span class="lb">رقم المرجع #</span><input data-k="ref" autocomplete="off"></div></div>
      ${exp ? `<div class="ac-pp" data-pp="1"><div class="pp-h" data-pp-t="1" role="switch" aria-checked="false" tabindex="0"><span class="pp-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="17" rx="3"/><path d="M3 9h18M8 2v4M16 2v4M8 14h2M14 14h2M8 17.5h2"/></svg></span><span class="pp-t"><b>توزيع على مدة — مصروف مدفوع مقدماً</b><small>مثل إيجار المحل: يُخصم من الأرباح والخسائر يوماً بيوم بدل المبلغ كاملاً يوم الدفع</small></span><span class="pp-sw"></span></div>
        <div class="pp-b"><div class="pp-f"><label>يبدأ من<input type="date" data-pp-k="from"></label><label>المدة<span style="display:flex;gap:6px"><input type="number" min="1" step="1" data-pp-k="n" value="3"><select data-pp-k="u"><option value="m">أشهر</option><option value="d">أيام</option></select></span></label><label>ينتهي في<span class="pp-end" data-pp-o="end">—</span></label></div>
          <div class="pp-s"><div class="pp-chips"><span class="pp-c"><small>يومياً في الأرباح</small><b data-pp-o="day">0</b></span><span class="pp-c"><small>شهرياً (30 يوماً)</small><b data-pp-o="mon">0</b></span><span class="pp-c k"><small>عدد الأيام</small><b data-pp-o="days">0</b></span></div>
            <div class="pp-tl" data-pp-o="tl"><i style="width:0"></i><em style="display:none"></em></div><div class="pp-cap"><span data-pp-o="c1"></span><span data-pp-o="c2"></span></div>
            <div class="pp-note" data-pp-o="note"></div></div></div></div>` : ""}
      <div class="ac-grid" data-g="1"></div>
      <div class="ac-ifoot"><div class="ac-it"><div class="ac-tl"><span>الاجمالى قبل الضريبة:</span><b data-k="tb">0</b></div><div class="ac-tl"><span>الضرائب :</span><b data-k="tt">0</b></div><div class="ac-bigt" data-k="tot">0</div></div>
        <div class="ac-ipm"><div class="ac-fr"><span class="lb">طريقة الدفع</span><span class="ac-mt"><small>النوع</small><small>اسم الحساب</small><span data-ap="1"></span></span></div>
          <div class="ac-fr"><span class="lb">العمله</span><span class="ac-cur">${A.selH("cur", ["DZD"], "DZD")}<span class="spin"><input data-k="rate" value="1"><i>⌃</i><i>⌄</i></span></span><i class="req">*</i></div>
          <div class="ac-fr"><span class="lb">الملاحظات</span><textarea data-k="notes" rows="2"></textarea></div></div></div>
      <div class="ac-btns"><button type="button" class="ac-btn blue" data-a="save2">حفظ</button><button type="button" class="ac-btn blue" data-a="sp2">حفظ و طباعة</button><button type="button" class="ac-btn blue" data-a="close2">اغلاق</button></div></div>`;
    const Q = s => page.querySelector(s), K = k => page.querySelector(`[data-k="${k}"]`);
    const HD = A.wireHeader(page, kind, D);
    const AP = A.accPicker(Q("[data-ap]"), { type: "tr" });
    let ITEMS = [], etype = "gen";
    const lid = "acitm_" + kind;
    A.accounts(kind).then(l => { ITEMS = l; dl(lid, l.map(x => x.name)); if (!l.length) say("لا توجد بنود " + (exp ? "مصروفات" : "إيرادات") + " — أضفها من «الفهرس ← بنود " + (exp ? "المصروفات" : "الإيرادات") + "»", "i"); });
    /* مطابقة متسامحة: المسافات، أ/إ/آ، ة/ه، ى/ي */
    const norm2 = v => String(v || "").trim().replace(/\s+/g, " ").replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").toLowerCase();
    const findItem = v => { const n = norm2(v); return n ? ITEMS.find(x => norm2(x.name) === n) || ITEMS.find(x => String(x.no) === String(v).trim()) : null; };
    /* بند جديد من داخل المستند (بدل رسالة «اختر من البنود»): الاسم + حساب الأستاذ (شجرة الحسابات) + النوع */
    function newItemDlg(name, done) {
      const ik = exp ? "exp" : "rev", pre = exp ? "3" : "4", DB = H.DB;
      Promise.all([DB.list(ik, true).catch(() => []), DB.list("gla").catch(() => [])]).then(([all, gla]) => {
        const gl = (gla || []).filter(a => String(a.no).startsWith(pre) && String(a.no).length > 1).sort((a, b) => String(a.no).localeCompare(String(b.no)));
        const cnt = {}; (all || []).forEach(x => { const g = ((typeof x.data === "string" ? (() => { try { return JSON.parse(x.data); } catch (e) { return {}; } })() : x.data) || {}).gl; if (g) cnt[g] = (cnt[g] || 0) + 1; });
        /* الحساب المقترح: كلمة من اسم البند (كراء ← إيجارات …) ، ثم الحساب الأكثر استعمالاً في البنود ، ثم أول حساب «مصروفات» فرعي — ولا «تكلفة البضاعة المباعة» أبداً كاقتراح */
        const leaf = gl.filter(a => !gl.some(b => b !== a && String(b.no).startsWith(String(a.no)) && String(b.no).length > String(a.no).length));
        const okG = a => !/تكلف[ةه]\s*البضاع/.test(norm2(a.name).replace(/ه/g, "ة")) && !/تكلفه البضاعه/.test(norm2(a.name));
        const KW = [[/كراء|ايجار|إيجار/, /ايجار|كراء/], [/كهرب/, /كهرب/], [/ماء|مياه/, /مياه|ماء/], [/هاتف|انترنت|اتصال|فليكسي/, /اتصال|هاتف|انترنت/], [/راتب|رواتب|اجر|اجور|خلاص/, /رواتب|اجور/], [/نقل|بنزين|وقود|مازوت/, /نقل|وقود|محروق/], [/صيان|تصليح/, /صيان/], [/ضريب|رسوم/, /ضرائب|رسوم/], [/اشهار|اعلان|دعاي/, /اشهار|اعلان|دعاي/]];
        const nn = norm2(name); let kwG = "";
        KW.some(([k, g]) => { if (!k.test(nn)) return false; const a = leaf.find(x => g.test(norm2(x.name)) && okG(x)) || gl.find(x => g.test(norm2(x.name)) && okG(x)); if (a) kwG = a.no; return !!a; });
        const most = Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a]).find(no => { const a = gl.find(x => String(x.no) === String(no)); return !a || okG(a); });
        const firstExp = leaf.find(x => okG(x) && /مصروف/.test(norm2(x.name))) || leaf.find(okG) || gl.find(okG);
        const defGl = kwG || most || (firstExp && firstExp.no) || "";
        const ttl = exp ? "بند مصروف جديد" : "بند إيراد جديد";
        const d = Dlg({ title: ttl, w: 520, okText: "إضافة البند ومتابعة الحفظ", closeText: "رجوع", onOk: x => go(x) });
        d.body.innerHTML = `<div class="nbx"><div class="nbx-h">${I.eitm || ""}<div><b>«${esc(name)}» ليس من ${exp ? "بنود المصروفات" : "بنود الإيرادات"}</b><small>أضفه بنداً جديداً مربوطاً بحساب في شجرة الحسابات، أو ارجع واختر بنداً موجوداً من القائمة.</small></div></div>
          <label><span>اسم البند</span><input data-nb="name" value="${esc(name)}"></label>
          <label><span>حساب الأستاذ <i>*</i></span><select data-nb="gl">${gl.length ? gl.map(a => `<option value="${esc(a.no)}"${String(a.no) === String(defGl) ? " selected" : ""}>${esc(a.no + " - " + a.name)}</option>`).join("") : `<option value="${esc(defGl)}">${esc(defGl || "يُربط لاحقاً من «الفهرس ← بنود " + (exp ? "المصروفات" : "الإيرادات") + "»")}</option>`}</select></label>
          ${exp ? `<label><span>النوع</span><select data-nb="type">${["مصروف عام", "مصروف على الإعتماد", "مصروف على الأصول"].map(t => `<option>${t}</option>`).join("")}</select></label>` : ""}
          ${ITEMS.length ? `<div class="nbx-s"><small>أو بند موجود قريب:</small>${ITEMS.filter(x => { const a = norm2(x.name), b = norm2(name).split(" ")[0]; return b && b.length > 1 && a.includes(b); }).slice(0, 6).map(x => `<button type="button" data-use="${x.id}">${esc(x.name)}</button>`).join("") || "<em>لا يوجد</em>"}</div>` : ""}</div>`;
        if (!G_NB_CSS) { G_NB_CSS = 1; const st = document.createElement("style"); st.textContent = `.nbx{display:flex;flex-direction:column;gap:12px;padding:6px 4px 2px;font-size:13px}.nbx-h{display:flex;gap:12px;align-items:flex-start;padding:12px 14px;border-radius:12px;background:#fff7ed;border:1px solid #fed7aa}.nbx-h svg{width:26px;height:26px;flex:none;color:#ea580c}.nbx-h b{display:block;font-size:14px;color:#9a3412}.nbx-h small{display:block;color:#7c2d12;margin-top:3px;line-height:1.6}
.nbx label{display:flex;flex-direction:column;gap:5px}.nbx label span{font-weight:700;color:#334155}.nbx label i{color:#dc2626;font-style:normal}.nbx input,.nbx select{height:36px;border:1px solid #cbd5e1;border-radius:9px;padding:0 10px;font:inherit;background:#fff}.nbx input:focus,.nbx select:focus{outline:0;border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,.15)}
.nbx-s{display:flex;flex-wrap:wrap;gap:6px;align-items:center}.nbx-s small{color:#64748b;margin-inline-end:4px}.nbx-s em{color:#94a3b8;font-style:normal;font-size:12px}.nbx-s button{height:30px;padding:0 11px;border-radius:999px;border:1px solid #bfdbfe;background:#eff6ff;color:#1d4ed8;font:inherit;font-size:12.5px;cursor:pointer}.nbx-s button:hover{background:#dbeafe}`; document.head.appendChild(st); }
        const nb = k => d.body.querySelector(`[data-nb="${k}"]`);
        setTimeout(() => { try { nb("gl").focus(); } catch (e) { } }, 60);
        d.body.addEventListener("click", e => { const b = e.target.closest("[data-use]"); if (!b) return; const it = ITEMS.find(x => String(x.id) === b.dataset.use); if (!it) return;
          G.rows.forEach(r => { if (!r.iid && norm2(r.name) === norm2(name)) { r.iid = it.id; r.no = it.no; r.name = it.name; } }); d.close(); G.set(G.rows); say("✓ اعتُمد البند «" + it.name + "»", "s"); D.save(); });
        let busy = false;
        function go(x) {
          if (busy) return; const nm = nb("name").value.trim(), g = nb("gl").value;
          if (!nm) { say("اكتب اسم البند", "w"); nb("name").focus(); return; }
          if (!g && gl.length) { say("اختر حساب الأستاذ من شجرة الحسابات", "w"); nb("gl").focus(); return; }
          const ex = findItem(nm); if (ex) { x.close(); done(ex); return; }
          busy = true;
          DB.next(ik).then(no => DB.save(ik, { id: 0, no: String(no), name: nm, parentId: 0, active: true, data: { gl: g, type: exp ? nb("type").value : undefined, branch: (H.BR || [])[0] || "", cc: "ليس من الضروري", notes: "أُضيف من مستند " + title } }))
            .then(() => { delete A.AC[ik]; return A.accounts(ik, true); })
            .then(l => { ITEMS = l; dl(lid, l.map(z => z.name)); const it = findItem(nm); busy = false; x.close(); if (!it) { say("حُفظ البند — اختره من القائمة", "w"); return; } say("✓ أُضيف البند «" + it.name + "» إلى " + (exp ? "بنود المصروفات" : "بنود الإيرادات"), "s"); done(it); })
            .catch(e => { busy = false; say("تعذّر إضافة البند: " + ((e && e.message) || e), "e"); });
        }
      });
    }
    const G = LGrid(Q("[data-g]"), { tpl: "40px 180px minmax(220px,1.6fr) 1fr minmax(220px,1.8fr) 34px", min: 10, blank: () => ({ no: "", name: "", amt: 0, note: "" }),
      cols: [{ k: "no", t: "الرقم" }, { k: "name", t: exp ? "نوع المصروف" : "نوع الايراد", list: lid }, { k: "amt", t: "المبلغ", n: 1, sum: 1 }, { k: "note", t: "الشرح" }],
      onChange: (r, k) => { D.dirtyF = true; if (k === "name") { const it = findItem(r.name); r.iid = it ? it.id : 0; if (it) { r.no = it.no; r.name = it.name; } } else if (k === "no") { const it = ITEMS.find(x => String(x.no) === String(r.no)); if (it) { r.name = it.name; r.iid = it.id; } } },
      onRender: tot, onDel: () => { D.dirtyF = true; } });
    function tot() { const b = r2(G.rows.reduce((s, r) => s + (+r.amt || 0), 0)), t = r2(b * taxRate(K("tax").value) / 100); K("tb").textContent = fmt(b); K("tt").textContent = fmt(t); K("tot").textContent = fmt(b + t); if (typeof ppPaint === "function" && exp) try { ppPaintSoon(); } catch (e) { } return { b, t, tot: r2(b + t) }; }
    let ppT = 0; function ppPaintSoon() { clearTimeout(ppT); ppT = setTimeout(() => { try { ppPaint(); } catch (e) { } }, 0); }
    K("tax").addEventListener("change", tot);
    if (exp) Q('[data-a="etype"]').addEventListener("click", e => H.ctxMenu(EXPT.map(x => [x[1], "", I[x[2]], () => { etype = x[0]; K("etxt").textContent = x[1]; Q('[data-a="etype"]').innerHTML = I[x[2]] + "<i>⌄</i>"; }]), e.currentTarget.getBoundingClientRect()));
    /* «توزيع على مدة»: حالة المستند + المعاينة الحية (يومياً / شهرياً / شريط الأيام المنقضية) */
    const PPB = exp ? Q("[data-pp]") : null, PK = k => PPB.querySelector(`[data-pp-k="${k}"]`), PO = k => PPB.querySelector(`[data-pp-o="${k}"]`);
    let spread = null;
    function ppSet(sp) { if (!PPB) return; spread = sp && sp.on ? Object.assign({}, sp) : null; PPB.classList.toggle("on", !!spread); PPB.querySelector("[data-pp-t]").setAttribute("aria-checked", spread ? "true" : "false");
      if (spread) { PK("from").value = spread.from || HD.get().date || today(); PK("n").value = spread.n || (spread.u === "d" ? spread.days : Math.round(spread.days / 30)) || 3; PK("u").value = spread.u || "m"; } ppPaint(); }
    function ppRead() { if (!spread) return null; const n = Math.max(1, Math.round(num(PK("n").value) || 0)), u = PK("u").value, from = PK("from").value || HD.get().date || today(); return { on: true, from, n, u, days: PP.daysOf(n, u) }; }
    function ppPaint() { if (!PPB || !spread) return; const sp = ppRead(), b = r2(G.rows.reduce((s2, r) => s2 + (+r.amt || 0), 0)), end = PP.endOf(sp), now = today();
      const done = sp.from > now ? 0 : PP.cum(sp, now), used = b ? PP.share(b, sp, sp.from, now < end ? now : end) : 0, pct = Math.min(100, done / sp.days * 100);
      PO("end").textContent = end.split("-").reverse().join("/"); PO("days").textContent = fmt(sp.days); PO("day").textContent = fmt(r2(b / sp.days)); PO("mon").textContent = fmt(r2(b / sp.days * 30));
      const tl = PO("tl"); tl.querySelector("i").style.width = pct + "%"; const em = tl.querySelector("em"); em.style.display = sp.from <= now && now <= end ? "" : "none"; em.style.right = "calc(" + pct + "% - 1px)";
      PO("c1").textContent = "من " + sp.from.split("-").reverse().join("/"); PO("c2").textContent = "إلى " + end.split("-").reverse().join("/");
      PO("note").innerHTML = !b ? "أدخل مبلغ المصروف في الجدول لترى التوزيع" : sp.from > now ? `يبدأ الخصم من الأرباح يوم <b>${sp.from.split("-").reverse().join("/")}</b> — حتى ذلك الحين المبلغ كله «مدفوع مقدماً»` : `دخل الأرباح والخسائر حتى اليوم <b>${fmt(used)}</b> (${fmt(done)} يوم) · المتبقي مقدماً <b>${fmt(r2(b - used))}</b>`; }
    if (PPB) {
      const tog = () => { ppSet(spread ? null : { on: true, from: HD.get().date || today(), n: 3, u: "m", days: 90 }); D.dirtyF = true; };
      PPB.querySelector("[data-pp-t]").addEventListener("click", tog);
      PPB.querySelector("[data-pp-t]").addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); tog(); } });
      PPB.addEventListener("input", () => { D.dirtyF = true; ppPaint(); }); PPB.addEventListener("change", () => { D.dirtyF = true; ppPaint(); });
    }
    function reset() { D.id = 0; D.fx = []; D.lg = []; D.dirtyF = false; D.title = title; HD.set("", today()); A.nextNo(kind).then(n => { if (!D.id) K("no").value = n; }); ["stmt", "ref", "notes"].forEach(k => K(k).value = ""); K("tax").value = ""; K("cc").value = ""; G.set([]); if (exp) ppSet(null); const del = Q('[data-a="del"]'); if (del) del.disabled = true; }
    function fill(d) { const x = d.data; D.id = d.id; D.fx = x.fx || []; D.lg = x.lg || []; D.dirtyF = false; HD.set(d.no, x.date, x.br); K("stmt").value = x.stmt || ""; K("ref").value = x.ref || ""; K("notes").value = x.notes || ""; K("tax").value = x.tax || ""; K("cc").value = x.cc || "";
      if (exp && x.etype) { const t = EXPT.find(z => z[0] === x.etype) || EXPT[0]; etype = t[0]; K("etxt").textContent = t[1]; }
      G.set((x.rows || []).map(r => Object.assign({}, r))); D.sp = !!(x.spread && x.spread.on); if (exp) ppSet(x.spread || null); AP.set((x.acc || {}).type || "tr", (x.acc || {}).id); const del = Q('[data-a="del"]'); if (del) del.disabled = false; D.title = title + " - " + d.no; tabOpen(D.key, D.title, view); }
    D.open = id => A.docs(kind, true).then(l => { const d = l.find(z => z.id === id); if (d) fill(d); });
    D.dirty = () => D.dirtyF && G.rows.length > 0;
    D.reload = () => { if (D.id) D.open(D.id); else { delete A.AC[kind]; A.accounts(kind, true).then(l => { ITEMS = l; dl(lid, l.map(x => x.name)); }); AP.refresh(); } };
    D.save = after => {
      const h = HD.get(), t = tot(), rows = G.rows.filter(r => r.name || r.amt);
      if (!exp && !K("stmt").value.trim()) { say("البيان حقل إجباري", "w"); K("stmt").focus(); return; }
      if (!rows.length || !(t.b > 0)) { say("أدخل " + (exp ? "المصروفات" : "الإيرادات") + " في الجدول", "w"); return; }
      rows.forEach(r => { if (!r.iid && r.name) { const it = findItem(r.name); if (it) { r.iid = it.id; r.no = it.no; r.name = it.name; } } });
      /* اسم مكتوب ليس بنداً بعد ← نقترح إضافته بنداً جديداً في «بنود ${exp ? "المصروفات" : "الإيرادات"}» مربوطاً بحساب أستاذ من شجرة الحسابات، ثم نكمل الحفظ */
      const unk = rows.findIndex(r => !r.iid && String(r.name || "").trim());
      if (unk >= 0) { newItemDlg(String(rows[unk].name).trim(), it => { rows.forEach(r => { if (!r.iid && norm2(r.name) === norm2(it.name)) { r.iid = it.id; r.no = it.no; r.name = it.name; } }); G.set(G.rows); D.save(after); }); return; }
      const bad = rows.findIndex(r => !r.iid || !(r.amt > 0)); if (bad >= 0) { say("السطر " + (bad + 1) + ": " + (!rows[bad].iid ? "اختر " + (exp ? "نوع المصروف" : "نوع الإيراد") + " من البنود" : "أدخل المبلغ"), "w"); return; }
      if (!AP.acc) { say("اختر طريقة الدفع (اسم الحساب)", "w"); return; }
      const sign = exp ? -1 : 1, sp = exp ? ppRead() : null;
      if (sp && !/^\d{4}-\d{2}-\d{2}$/.test(sp.from)) { say("اختر تاريخ بداية التوزيع", "w"); PK("from").focus(); return; }
      const go = (no, pre) => { const notes = title + " رقم " + no + (K("stmt").value ? " - " + K("stmt").value : "");
        const af = A.accFx(AP.acc, sign * t.tot, { party: K("stmt").value, notes, what: title });
        /* موزّع: المبلغ يذهب لحساب «مصروفات مدفوعة مقدما» (أصل) — وبنود المصروف تأخذ حصتها بقيد الإطفاء الشهري */
        const lg = af.lg.concat(sp && pre ? [{ t: "gl", id: pre.id, d: r2(t.b), name: pre.name, what: title + " (مدفوع مقدماً)" }] : rows.map(r => ({ t: kind, id: r.iid, d: r2(r.amt), name: r.name, what: title })));
        const data = { date: h.date, time: A.nowT(), br: h.br, etype, stmt: K("stmt").value.trim(), ref: K("ref").value.trim(), tax: K("tax").value, cc: K("cc").value, rows, before: t.b, taxv: t.t, total: t.tot, acc: AP.acc, notes: K("notes").value.trim(), fx: af.fx, lg, user: (window.__USER_NAME || "ANOUER") };
        if (sp) data.spread = Object.assign({}, sp, { to: PP.endOf(sp), perDay: r2(t.b / sp.days), acc: pre ? pre.no : "" });
        return A.post(af.fx, D.fx, { date: h.date, no: String(no), notes }).then(() => A.saveDoc(kind, { id: D.id, no, data }))
          .then(r => { A.invalidate(); A.snd("save"); say(sp ? "تم حفظ " + title + " رقم " + (r.no || no) + " — يُوزَّع " + fmt(data.spread.perDay) + " يومياً على " + fmt(sp.days) + " يوم" : "تم حفظ " + title + " رقم " + (r.no || no), "s"); delete A.AC.tr; if (after === "print") printIt(r.no || no, data); const was = D.id, wasSp = D.sp; D.id = r.id; D.fx = af.fx; D.sp = !!sp; D.dirtyF = false; if (!was) reset(); else D.open(r.id); if (window.__AC_REFRESH) __AC_REFRESH(kind); if (sp || wasSp) PP.sync().then(x => { if (x && x.err) say(x.err, "w"); }); }); };
      const pre = sp ? PP.acc() : Promise.resolve(null);
      Promise.all([h.no ? Promise.resolve(h.no) : A.nextNo(kind), pre]).then(([no, ac]) => { if (sp && !ac) say("حساب «مصروفات مدفوعة مقدما» (126) غير موجود في شجرة الحسابات — سيُسجَّل المصروف كاملاً", "w"); return go(no, ac); }).catch(e => { A.snd("err"); say("لم يتم الحفظ: " + (e.message || e), "e"); });
    };
    D.remove = () => { if (!D.id) return; A.ask("هل تريد حذف " + title + " رقم " + K("no").value + " ؟", () => A.post([], D.fx, { date: HD.get().date, no: K("no").value, notes: "حذف " + title }).then(() => A.delDoc(kind, D.id)).then(() => { const wasSp = D.sp; A.invalidate(); A.snd("del"); say("تم الحذف", "s"); D.sp = false; reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); if (wasSp) PP.sync(); }).catch(e => say(e.message, "e"))); };
    function printIt(no, x) { x = x || { stmt: K("stmt").value, rows: G.rows, before: tot().b, taxv: tot().t, total: tot().tot };
      /* «تصميم التقارير»: مصروفات / ايرادات بالتصميم الافتراضي */
      if (window.ANOUER_RD && !window.__rdOff) {
        const tx = exp ? "مصروفات" : "ايرادات", h = HD.get(), amt = +x.total || 0;
        const hd = { Number: no || K("no").value, Transaction: tx, Date: h.date, Time: "", "Party Name": "", Amount: amt, "Amount In Words": ANOUER_RD.tafqit(amt, ANOUER_RD.currencyName()), Statement: x.stmt || "", Account: (AP.acc || {}).name || "", "Payment Method": (AP.acc || {}).name || "", WrittenBy: ANOUER_RD.userName(), Branch: h.br || "", Notes: "", "Previous Balance": 0, "Current Balance": 0 };
        const items = (x.rows || []).map((r, i) => ({ Index: i + 1, Account: r.name, Amount: +r.amt || 0, Notes: r.note || "" }));
        ANOUER_RD.printTx({ tx, data: { header: hd, items }, mode: "preview", title: tx + " " + hd.Number }).catch(e => say("تعذّرت الطباعة: " + ((e && e.message) || e), "e"));
        return;
      }
      A.printDoc(title, A.kvHtml([["الرقم", no || K("no").value], ["التاريخ", HD.get().date], ["البيان", x.stmt], ["طريقة الدفع", (AP.acc || {}).name || ""]]), `<table><tr><th>${exp ? "نوع المصروف" : "نوع الايراد"}</th><th>المبلغ</th><th>الشرح</th></tr>${(x.rows || []).map(r => `<tr><td>${esc(r.name)}</td><td>${fmt(r.amt)}</td><td>${esc(r.note || "")}</td></tr>`).join("")}<tr><th>الاجمالى قبل الضريبة</th><th>${fmt(x.before)}</th><th></th></tr><tr><th>الضرائب</th><th>${fmt(x.taxv)}</th><th></th></tr><tr><th>الإجمالى</th><th>${fmt(x.total)}</th><th></th></tr></table>`); }
    function step(dir) { A.docs(kind, true).then(l => { if (!l.length) return say("لا توجد مستندات محفوظة", "i"); l.sort((a, b) => (+a.no || 0) - (+b.no || 0)); const c = l.findIndex(x => x.id === D.id), n = c < 0 ? (dir < 0 ? l.length - 1 : 0) : c + dir; if (n < 0 || n >= l.length) return say(dir < 0 ? "هذا أول مستند" : "هذا آخر مستند", "i"); fill(l[n]); }); }
    page.addEventListener("click", e => { const b = e.target.closest("button[data-a]"); if (!b || b.disabled) return; const a = b.dataset.a;
      if (a === "file") A.fileMenu(b, D, [["طباعة", "Ctrl+P", I.print, () => printIt()]]);
      else if (a === "save" || a === "save2") D.save(); else if (a === "savePrint" || a === "sp2") D.save("print"); else if (a === "print") printIt();
      else if (a === "close" || a === "close2") A.closeDoc(D); else if (a === "del") D.remove(); else if (a === "reload") D.reload();
      else if (a === "prev") step(-1); else if (a === "next") step(1);
      else if (a === "copy") { D.id = 0; D.fx = []; A.nextNo(kind).then(n => { K("no").value = n; }); D.title = title; tabOpen(D.key, title, view); say("تم نسخ التعامل — عدّل ثم احفظ كمستند جديد", "i"); const del = Q('[data-a="del"]'); if (del) del.disabled = true; }
      else if (a === "xls") { const csv = "﻿" + [["الرقم", "النوع", "المبلغ", "الشرح"]].concat(G.rows.map(r => [r.no, r.name, r.amt, r.note || ""])).map(r => r.join(",")).join("\r\n"); const x = document.createElement("a"); x.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" })); x.download = title + ".csv"; x.click(); }
      else if (a === "mail" && window.ANOUER_MAIL) ANOUER_MAIL.viaPrint(() => printIt());
      else if (a === "mail") { const t = tot(); location.href = "mailto:?subject=" + encodeURIComponent(title + " رقم " + K("no").value) + "&body=" + encodeURIComponent(G.rows.map(r => r.name + ": " + fmt(r.amt)).join("\n") + "\nالإجمالى: " + fmt(t.tot)); }
      else if (a === "fmt") say("تنسيق الإدخال: Enter ينتقل للحقل التالي، والسطر الجديد يُضاف تلقائياً", "i");
      else if (a === "cols") A.fieldChooser(page, kind, b); });
    page.addEventListener("input", e => { if (e.target.dataset && e.target.dataset.k) D.dirtyF = true; });
    reset(); tabOpen(key, title, view); if (id) D.open(id);
    return D;
  }

  /* ================================================================== قيود المحاسبة */
  const JET = [["gl", "حساب استاذ", "gl"], ["cu", "العملاء", "cu"], ["su", "الموردين", "su"], ["tr", "الخزينة", "tr"], ["bk", "البنوك", "bk"], ["pos", "فيزا", "pos"], ["emp", "عهد الموظفين", "cust"], ["oth", "جهات أخرى", "oth"], ["zm", "الزمم", "zm"], ["taxa", "الضرائب", "pct"], ["wtax", "ضرائب الخصم", "dtax"], ["exp", "المصروفات", "eitm"], ["rev", "الإيرادات", "ritm"]];
  function jeList(t) { if (t === "cu" || t === "su") return A.parties(t); if (["tr", "bk", "pos", "gl", "emp", "exp", "rev"].includes(t)) return A.accounts(t); if (t === "taxa") return Promise.resolve([{ id: 2132, no: "2132", name: "ضريبة القيمة المضافة" }, { id: 2133, no: "2133", name: "مصلحة الضرائب العامة" }].concat(TAXES.filter(x => x[0]).map((x, i) => ({ id: i + 1, no: x[0], name: x[1] })))); if (t === "wtax") return Promise.resolve([{ id: 1, no: "wt1", name: "ضرائب الخصم والإضافة" }]); return Promise.resolve(H.lsGet("ac.jeo." + t, [])); }
  function jeDoc(id) {
    if (id) { const ex = Object.values(A.DOCS).find(d => d.kind === "je" && d.id === id); if (ex) { tabOpen(ex.key, ex.title, ex.view); return ex; } }
    const kind = "je", view = "acje", key = view + ":" + A.nextSeq(), title = A.TITLE.je;
    const page = A.docPage(view, title, key);
    const D = A.DOCS[key] = { key, kind, view, page, title, id: 0, fx: [], dirtyF: false };
    page.innerHTML = A.toolbar([["save", "حفظ", I.save], ["savePrint", "حفظ و طباعة", ""]], [["cols", "اختيار الحقول", I.cols]]) + A.header() + `<div class="ac-body ac-je">
      <div class="ac-side3"><div class="t or">بيانات اساسية</div><div class="t bl grow">القيود</div><div class="t bl">الملاحظا ت</div></div>
      <div class="ac-jm"><div class="ac-jr1"><div class="ac-fr"><span class="lb">بيان القيد</span><input data-k="stmt" class="wide" autocomplete="off"><i class="req">*</i></div><div class="ac-fr v"><span class="lb">مركز التكلفة</span>${A.selH("cc", CC, "")}</div></div>
        <div class="ac-jr2"><div class="ac-fr"><span class="lb">العملة</span><span class="ac-cur">${A.selH("cur", ["DZD"], "DZD")}<span class="spin"><input data-k="rate" value="1"><i>⌃</i><i>⌄</i></span></span><i class="req">*</i></div><button type="button" class="ac-rev" data-a="flip">عكس القيد</button></div>
        <div class="ac-grid" data-g="1"></div>
        <div class="ac-jf"><textarea data-k="notes" rows="2" placeholder=""></textarea><div class="ac-jt"><div><span>مدين</span><b data-k="dr">0</b></div><div><span>دائن</span><b data-k="cr">0</b></div></div></div>
        <div class="ac-btns"><button type="button" class="ac-btn green" data-a="save2">حفظ</button><button type="button" class="ac-btn blue" data-a="sp2">حفظ و طباعة</button><button type="button" class="ac-btn blue" data-a="close2">إغلاق</button></div></div></div>`;
    const Q = s => page.querySelector(s), K = k => page.querySelector(`[data-k="${k}"]`);
    const HD = A.wireHeader(page, kind, D);
    const LISTS = {};
    function ensure(t) { if (LISTS[t]) return Promise.resolve(LISTS[t]); return jeList(t).then(l => { LISTS[t] = l || []; dl("acje_" + t, LISTS[t].map(x => x.name)); return LISTS[t]; }); }
    ensure("gl");
    const G = LGrid(Q("[data-g]"), { tpl: "40px 150px 140px minmax(220px,1.6fr) 1fr 1fr minmax(200px,1.5fr) 34px", min: 12, blank: () => ({ t: "gl", no: "", name: "", dr: 0, cr: 0, note: "" }),
      cols: [{ k: "t", t: "النوع", sel: JET.map(x => [x[0], x[1]]) }, { k: "no", t: "الرقم" }, { k: "name", t: "الاسم" }, { k: "dr", t: "مدين", n: 1, sum: 1 }, { k: "cr", t: "دائن", n: 1, sum: 1 }, { k: "note", t: "الشرح" }],
      onRender: () => { Q("[data-g]").querySelectorAll('.r[data-i] input[data-c="name"]').forEach(inp => { const i = +inp.closest(".r").dataset.i, r = G.rows[i] || { t: "gl" }; inp.setAttribute("list", "acje_" + r.t); }); tot(); },
      onChange: (r, k) => { D.dirtyF = true; if (k === "t") { r.no = ""; r.name = ""; r.aid = 0; return ensure(r.t); }
        return ensure(r.t || "gl").then(l => { if (k === "name") { const a = l.find(x => x.name === r.name); r.aid = a ? a.id : 0; if (a) r.no = a.no || a.id; } else if (k === "no") { const a = l.find(x => String(x.no) === String(r.no)); if (a) { r.name = a.name; r.aid = a.id; } }
          else if (k === "dr" && r.dr) r.cr = 0; else if (k === "cr" && r.cr) r.dr = 0; }); },
      onDel: () => { D.dirtyF = true; tot(); } });
    function tot() { const dr = r2(G.rows.reduce((s, r) => s + (+r.dr || 0), 0)), cr = r2(G.rows.reduce((s, r) => s + (+r.cr || 0), 0)); K("dr").textContent = fmt(dr); K("cr").textContent = fmt(cr); K("dr").parentNode.classList.toggle("bad", dr !== cr); K("cr").parentNode.classList.toggle("bad", dr !== cr); return { dr, cr }; }
    Q('[data-a="flip"]').addEventListener("click", () => { G.rows.forEach(r => { const d = r.dr; r.dr = r.cr; r.cr = d; }); G.render(); D.dirtyF = true; });
    function reset() { D.id = 0; D.fx = []; D.dirtyF = false; D.title = title; HD.set("", today()); A.nextNo(kind).then(n => { if (!D.id) K("no").value = n; }); K("stmt").value = ""; K("notes").value = ""; K("cc").value = ""; G.set([]); }
    function fill(d) { const x = d.data; D.id = d.id; D.fx = x.fx || []; D.dirtyF = false; HD.set(d.no, x.date, x.br); K("stmt").value = x.stmt || ""; K("notes").value = x.notes || ""; K("cc").value = x.cc || ""; Promise.all((x.rows || []).map(r => ensure(r.t))).then(() => G.set((x.rows || []).map(r => Object.assign({}, r)))); D.title = title + " - " + d.no; tabOpen(D.key, D.title, view); }
    D.open = id => A.docs(kind, true).then(l => { const d = l.find(z => z.id === id); if (d) fill(d); });
    D.dirty = () => D.dirtyF && G.rows.length > 0;
    D.save = after => {
      const h = HD.get(), t = tot(), rows = G.rows.filter(r => r.name || r.dr || r.cr);
      if (!K("stmt").value.trim()) { say("بيان القيد حقل إجباري", "w"); K("stmt").focus(); return; }
      if (rows.length < 2) { say("القيد يحتاج سطرين على الأقل (مدين ودائن)", "w"); return; }
      const bad = rows.findIndex(r => !r.aid || !((+r.dr || 0) > 0 || (+r.cr || 0) > 0)); if (bad >= 0) { say("السطر " + (bad + 1) + ": اختر الحساب من القائمة وأدخل مدين أو دائن", "w"); return; }
      if (t.dr !== t.cr) { say("القيد غير متوازن: مدين " + fmt(t.dr) + " ≠ دائن " + fmt(t.cr), "w"); return; }
      const go = no => { const notes = "قيد رقم " + no + " - " + K("stmt").value.trim(); const fx = [], lg = [];
        rows.forEach(r => { const dr = +r.dr || 0, cr = +r.cr || 0;
          if (r.t === "tr") fx.push({ t: "tr", id: r.aid, d: r2(dr - cr), party: r.name, notes });
          else if (r.t === "cu") fx.push({ t: "cu", id: r.aid, d: r2(cr - dr) });
          else if (r.t === "su") fx.push({ t: "su", id: r.aid, d: r2(cr - dr) });
          else lg.push({ t: r.t, id: r.aid, d: r2(dr - cr), name: r.name, what: "قيد" }); });
        const data = { date: h.date, time: A.nowT(), br: h.br, stmt: K("stmt").value.trim(), cc: K("cc").value, notes: K("notes").value.trim(), rows, dr: t.dr, cr: t.cr, total: t.dr, fx, lg, user: (window.__USER_NAME || "ANOUER") };
        return A.post(fx, D.fx, { date: h.date, no: String(no), notes }).then(() => A.saveDoc(kind, { id: D.id, no, data }))
          .then(r => { A.invalidate(); A.snd("save"); say("تم حفظ القيد رقم " + (r.no || no), "s"); delete A.PC.cu; delete A.PC.su; delete A.AC.tr; if (after === "print") A.printDoc("قيد محاسبى", A.kvHtml([["الرقم", r.no || no], ["التاريخ", h.date], ["البيان", data.stmt], ["", ""]]), `<table><tr><th>النوع</th><th>الحساب</th><th>مدين</th><th>دائن</th><th>الشرح</th></tr>${rows.map(x => `<tr><td>${esc((JET.find(j => j[0] === x.t) || [])[1] || "")}</td><td>${esc(x.name)}</td><td>${fmt(x.dr)}</td><td>${fmt(x.cr)}</td><td>${esc(x.note || "")}</td></tr>`).join("")}<tr><th></th><th>الإجمالى</th><th>${fmt(t.dr)}</th><th>${fmt(t.cr)}</th><th></th></tr></table>`);
            const was = D.id; D.id = r.id; D.fx = fx; D.dirtyF = false; if (!was) reset(); else D.open(r.id); if (window.__AC_REFRESH) __AC_REFRESH(kind); }); };
      (h.no ? Promise.resolve(h.no) : A.nextNo(kind)).then(go).catch(e => { A.snd("err"); say("لم يتم الحفظ: " + (e.message || e), "e"); });
    };
    D.remove = () => { if (!D.id) return; A.ask("هل تريد حذف القيد رقم " + K("no").value + " ؟", () => A.post([], D.fx, { date: HD.get().date, no: K("no").value, notes: "حذف قيد" }).then(() => A.delDoc(kind, D.id)).then(() => { A.invalidate(); say("تم الحذف", "s"); reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); }).catch(e => say(e.message, "e"))); };
    page.addEventListener("click", e => { const b = e.target.closest("button[data-a]"); if (!b) return; const a = b.dataset.a;
      if (a === "file") A.fileMenu(b, D); else if (a === "save" || a === "save2") D.save(); else if (a === "savePrint" || a === "sp2") D.save("print"); else if (a === "close2") A.closeDoc(D); else if (a === "cols") A.fieldChooser(page, kind, b); });
    page.addEventListener("input", e => { if (e.target.dataset && e.target.dataset.k) D.dirtyF = true; });
    reset(); tabOpen(key, title, view); if (id) D.open(id);
    return D;
  }

  /* ================================================================== تحويل النقدية */
  function xferDoc(id) {
    if (id) { const ex = Object.values(A.DOCS).find(d => d.kind === "xfer" && d.id === id); if (ex) { tabOpen(ex.key, ex.title, ex.view); return ex; } }
    const kind = "xfer", view = "acxfer", key = view + ":" + A.nextSeq(), title = A.TITLE.xfer;
    const page = A.docPage(view, title, key);
    const D = A.DOCS[key] = { key, kind, view, page, title, id: 0, fx: [], dirtyF: false };
    page.innerHTML = A.toolbar([["spin", "", I.spin], ["save", "حفظ", I.save], ["savePrint", "حفظ و طباعة", I.print]], []) + A.header() + `<div class="ac-body ac-xf">
      <div class="ac-xrow"><div class="ac-xs or">بيانات<br>أساسية</div><div class="ac-xc"><div class="ac-fr v w"><span class="lb">البيان</span><span class="in"><input data-k="stmt" autocomplete="off"><i class="req">*</i></span></div>
        <div class="ac-fr v"><span class="lb">التحويل إلى</span>${A.selH("tobr", BR(), BR()[0])}</div></div><div class="ac-xic">${I.money}</div></div>
      <div class="ac-xrow"><div class="ac-xs bl tall">بيانات<br>التحويل</div><div class="ac-xc two">
        <div class="ac-xh"><div class="ac-fr v"><span class="lb">من حساب</span><span data-ap="from"></span></div><div class="ac-fr v"><span class="lb">المبلغ المدفوع</span><span class="ac-amt"><input data-k="paid" class="n" value="0.000"><span>DZD</span></span><i class="req">*</i></div></div>
        <div class="ac-xarr">${I.arrowL}</div>
        <div class="ac-xh"><div class="ac-fr v"><span class="lb">إلى حساب</span><span data-ap="to"></span></div><div class="ac-xr2"><div class="ac-fr v"><span class="lb">المبلغ المستلم</span><span class="ac-amt"><input data-k="recv" class="n" value="0.000"><span>DZD</span></span><i class="req">*</i></div><div class="ac-fr v"><span class="lb">المعامل</span><input data-k="rate" class="n sm" value="1"></div></div></div></div></div>
      <div class="ac-xrow"><div class="ac-xs bl">العمولة</div><div class="ac-xc two"><div class="ac-xh row"><div class="ac-fr v"><span class="lb">عمولة التحويل</span><input data-k="comm" class="n" value="0"></div><div class="ac-fr v"><span class="lb">الضريبة على العمولة</span><input data-k="ctax" class="n" value="0"></div></div><div></div>
        <label class="ac-chk"><input type="checkbox" data-k="fromTo"> خصم العمولة من المحول إليه</label></div></div>
      <div class="ac-xrow"><div class="ac-xs bl">أخرى</div><div class="ac-xc"><div class="ac-fr v"><span class="lb">رقم المرجع #</span><input data-k="ref" autocomplete="off"></div><div class="ac-fr v w"><span class="lb">الملاحظات</span><textarea data-k="notes" rows="2"></textarea></div></div></div>
      <div class="ac-btns c"><button type="button" class="ac-btn green" data-a="save2">حفظ</button><button type="button" class="ac-btn blue" data-a="sp2">حفظ و طباعة</button><button type="button" class="ac-btn blue" data-a="cancel">الغاء</button></div>
      <div class="ac-xfoot"><div class="ac-fr v"><span class="lb">حساب التحويل <i class="req">*</i></span>${A.selH("xacc", ["تحويلات النقدية بين الفروع", "تحويلات نقدية داخلية"], "تحويلات النقدية بين الفروع")}</div><div class="ac-fr v"><span class="lb">حساب عمولة التحويل <i class="req">*</i></span>${A.selH("cacc", ["مصروفات بنكية وعمولات"], "مصروفات بنكية وعمولات")}</div><div class="ac-fr v"><span class="lb">الضريبة <i class="req">*</i></span>${A.selH("taxk", TAXES.map(t => [t[0], t[1]]), "")}</div></div></div>`;
    const Q = s => page.querySelector(s), K = k => page.querySelector(`[data-k="${k}"]`);
    const HD = A.wireHeader(page, kind, D);
    const FA = A.accPicker(Q('[data-ap="from"]'), { type: "tr" }), TA = A.accPicker(Q('[data-ap="to"]'), { type: "tr" });
    const fmt3 = v => (+v || 0).toFixed(3);
    K("paid").addEventListener("change", () => { K("paid").value = fmt3(num(K("paid").value)); K("recv").value = fmt3(num(K("paid").value) * (num(K("rate").value) || 1)); D.dirtyF = true; });
    K("rate").addEventListener("change", () => { K("recv").value = fmt3(num(K("paid").value) * (num(K("rate").value) || 1)); });
    K("recv").addEventListener("change", () => { K("recv").value = fmt3(num(K("recv").value)); });
    function reset() { D.id = 0; D.fx = []; D.dirtyF = false; D.title = title; HD.set("", today()); A.nextNo(kind).then(n => { if (!D.id) K("no").value = n; }); ["stmt", "ref", "notes"].forEach(k => K(k).value = ""); K("paid").value = K("recv").value = "0.000"; K("comm").value = K("ctax").value = "0"; K("rate").value = "1"; K("fromTo").checked = false; setTimeout(() => K("stmt").focus(), 50); }
    function fill(d) { const x = d.data; D.id = d.id; D.fx = x.fx || []; D.dirtyF = false; HD.set(d.no, x.date, x.br); K("stmt").value = x.stmt || ""; K("ref").value = x.ref || ""; K("notes").value = x.notes || ""; K("paid").value = fmt3(x.paid); K("recv").value = fmt3(x.recv); K("comm").value = x.comm || 0; K("ctax").value = x.ctax || 0; K("fromTo").checked = !!x.fromTo; if (x.tobr) K("tobr").value = x.tobr;
      FA.set((x.from || {}).type, (x.from || {}).id); TA.set((x.to || {}).type, (x.to || {}).id); D.title = title + " - " + d.no; tabOpen(D.key, D.title, view); }
    D.open = id => A.docs(kind, true).then(l => { const d = l.find(z => z.id === id); if (d) fill(d); });
    D.dirty = () => D.dirtyF && num(K("paid").value) > 0;
    D.save = after => {
      const h = HD.get(), paid = r2(num(K("paid").value)), rec = r2(num(K("recv").value)), comm = r2(num(K("comm").value)), ctax = r2(num(K("ctax").value)), fromTo = K("fromTo").checked;
      if (!K("stmt").value.trim()) { say("البيان حقل إجباري", "w"); K("stmt").focus(); return; }
      if (!FA.acc || !TA.acc) { say("اختر حساب التحويل منه وإليه", "w"); return; }
      if (FA.acc.type === TA.acc.type && String(FA.acc.id) === String(TA.acc.id)) { say("لا يمكن التحويل إلى نفس الحساب", "w"); return; }
      if (!(paid > 0) || !(rec > 0)) { say("أدخل المبلغ المدفوع والمستلم", "w"); return; }
      const go = no => { const notes = "تحويل نقدية رقم " + no + " - " + K("stmt").value.trim(), cm = r2(comm + ctax);
        const f = A.accFx(FA.acc, -(paid + (fromTo ? 0 : cm)), { party: TA.acc.name, notes, what: title }), t = A.accFx(TA.acc, rec - (fromTo ? cm : 0), { party: FA.acc.name, notes, what: title });
        const fx = f.fx.concat(t.fx), lg = f.lg.concat(t.lg);
        const data = { date: h.date, time: A.nowT(), br: h.br, tobr: K("tobr").value, stmt: K("stmt").value.trim(), from: FA.acc, to: TA.acc, paid, recv: rec, rate: num(K("rate").value) || 1, comm, ctax, fromTo, ref: K("ref").value.trim(), notes: K("notes").value.trim(), xacc: K("xacc").value, cacc: K("cacc").value, total: paid, fx, lg, user: (window.__USER_NAME || "ANOUER") };
        return A.post(fx, D.fx, { date: h.date, no: String(no), notes }).then(() => A.saveDoc(kind, { id: D.id, no, data }))
          .then(r => { A.invalidate(); A.snd("save"); say("تم حفظ تحويل النقدية رقم " + (r.no || no), "s"); delete A.AC.tr; if (after === "print") A.printDoc(title, A.kvHtml([["الرقم", r.no || no], ["التاريخ", h.date], ["البيان", data.stmt], ["التحويل إلى", data.tobr], ["من حساب", FA.acc.name], ["المبلغ المدفوع", fmt(paid)], ["إلى حساب", TA.acc.name], ["المبلغ المستلم", fmt(rec)], ["عمولة التحويل", fmt(comm)], ["الضريبة على العمولة", fmt(ctax)]]));
            const was = D.id; D.id = r.id; D.fx = fx; D.dirtyF = false; FA.refresh(); TA.refresh(); if (!was) reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); }); };
      (h.no ? Promise.resolve(h.no) : A.nextNo(kind)).then(go).catch(e => { A.snd("err"); say("لم يتم الحفظ: " + (e.message || e), "e"); });
    };
    D.remove = () => { if (!D.id) return; A.ask("هل تريد حذف التحويل رقم " + K("no").value + " ؟", () => A.post([], D.fx, { date: HD.get().date, no: K("no").value }).then(() => A.delDoc(kind, D.id)).then(() => { A.invalidate(); say("تم الحذف", "s"); reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); })); };
    page.addEventListener("click", e => { const b = e.target.closest("button[data-a]"); if (!b) return; const a = b.dataset.a;
      if (a === "file") A.fileMenu(b, D); else if (a === "save" || a === "save2") D.save(); else if (a === "savePrint" || a === "sp2") D.save("print"); else if (a === "cancel") A.closeDoc(D); else if (a === "spin") { FA.refresh(); TA.refresh(); } });
    page.addEventListener("input", e => { if (e.target.dataset && e.target.dataset.k) D.dirtyF = true; });
    reset(); tabOpen(key, title, view); if (id) D.open(id);
    return D;
  }
  function BR() { return H.BR || ["الفرع الرئيسي"]; }

  /* ================================================================== سداد الضرائب / تسويات الضرائب (DEXEF ONE + لمسة 2026)
     • اسم الحساب: شجرة الحسابات الحيّة (الخصوم: 2132 ضريبة القيمة المضافة ، 2133 مصلحة الضرائب العامة ، … ، 214 حسابات دائنة أخرى ، 22 …)
     • المبلغ: حاسبة ▾ مثل DEXEF ، الفترة: اختصارات سريعة ، التسويات: مدين / دائن (اختيار إلزامي مثل DEXEF)
     • «ملخص الفترة الضريبية»: ضريبة المبيعات − ضريبة المشتريات − المسدد ± التسويات = المستحق ، وزر «استخدام المبلغ» */
  const VAT_NO = "2132", VAT_NAME = "ضريبة القيمة المضافة";
  const TX_OLD = { vat19: [VAT_NO, VAT_NAME], vat9: [VAT_NO, VAT_NAME], stamp: ["2133", "مصلحة الضرائب العامة"] };
  const ymdL = d => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  function txPeriod(k) {
    const d = new Date(), y = d.getFullYear(), m = d.getMonth(), q = Math.floor(m / 3);
    if (k === "cm") return [ymdL(new Date(y, m, 1)), ymdL(new Date(y, m + 1, 0))];
    if (k === "pm") return [ymdL(new Date(y, m - 1, 1)), ymdL(new Date(y, m, 0))];
    if (k === "pq") return [ymdL(new Date(y, (q - 1) * 3, 1)), ymdL(new Date(y, q * 3, 0))];
    if (k === "cy") return [y + "-01-01", y + "-12-31"];
    return null;
  }
  /* ملخص ضريبة الفترة (يُستعمل أيضاً في تقرير ضريبة القيمة المضافة) */
  function taxSummary(f1, f2, accNo, exceptId, kindNow) {
    const R = window.ANOUER_REPORTS, isVat = !accNo || accNo === VAT_NO;
    const inv = isVat && R && R.data ? R.data(f1, f2).then(D => D.inv).catch(() => []) : Promise.resolve([]);
    const ov = d => d.data && !(d.data.f2 < f1 || d.data.f1 > f2) && String(d.data.taccNo || (TX_OLD[d.data.tacc] || [])[0] || VAT_NO) === String(accNo || VAT_NO);
    return Promise.all([inv, A.docs("taxp").catch(() => []), A.docs("taxs").catch(() => [])]).then(([L, P, S]) => {
      const sum = (t, f) => r2(L.filter(x => x.t === t).reduce((a, x) => a + f(x), 0));
      const sTax = r2(sum("Sale", x => +x.tax || 0) - sum("SaleReturn", x => +x.tax || 0));
      const pTax = r2(sum("Purchase", x => +x.tax || 0) - sum("PurchaseReturn", x => +x.tax || 0));
      const notMe = (d, k) => !(k === kindNow && d.id === exceptId);
      const paid = r2(P.filter(d => ov(d) && notMe(d, "taxp")).reduce((a, d) => a + (+d.data.amt || 0), 0));
      const adjDr = r2(S.filter(d => ov(d) && notMe(d, "taxs") && d.data.dc !== "cr").reduce((a, d) => a + (+d.data.amt || 0), 0));
      const adjCr = r2(S.filter(d => ov(d) && notMe(d, "taxs") && d.data.dc === "cr").reduce((a, d) => a + (+d.data.amt || 0), 0));
      return { isVat, sTax, pTax, gross: r2(sTax - pTax), paid, adjDr, adjCr, due: r2(sTax - pTax - paid - adjDr + adjCr), nS: L.filter(x => x.t === "Sale" || x.t === "SaleReturn").length, nP: L.filter(x => x.t === "Purchase" || x.t === "PurchaseReturn").length };
    });
  }
  const TXI = {
    sum: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2z"/><path d="M9 8h6M9 12h6M9 16h3"/></svg>',
    use: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12H5M11 6l-6 6 6 6"/></svg>',
    rpt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>'
  };
  function taxDoc(kind, id) {
    if (id) { const ex = Object.values(A.DOCS).find(d => d.kind === kind && d.id === id); if (ex) { tabOpen(ex.key, ex.title, ex.view); return ex; } }
    const adj = kind === "taxs", view = "ac" + kind, key = view + ":" + A.nextSeq(), title = A.TITLE[kind];
    const page = A.docPage(view, title, key);
    const D = A.DOCS[key] = { key, kind, view, page, title, id: 0, fx: [], dirtyF: false };
    page.innerHTML = A.toolbar([["save", "حفظ", I.save], ["savePrint", "حفظ و طباعة", I.print]], [["cols", "اختيار الحقول", I.cols]]) + A.header() + `<div class="ac-body ac-tx tx26">
      <div class="ac-xrow"><div class="ac-xs or">بيانات<br>أساسية</div><div class="ac-tc">
        <div class="ac-fr"><span class="lb">اسم الحساب</span><span class="tx-acc" data-tp="1"></span><b class="tx-ok" data-okacc title="حساب صحيح">✓</b><i class="req">*</i></div>
        <div class="ac-fr"><span class="lb">المبلغ</span><span class="ac-cb n tx-amt"><input data-k="amt" inputmode="decimal" autocomplete="off"><button type="button" class="dd" data-a="calc" tabindex="-1" title="الحاسبة (Alt+↓)">⌄</button></span><i class="req">*</i>${adj ? '<span class="tx-dc"><label class="ac-rd"><input type="radio" name="dc' + key + '" value="dr"> مدين</label><label class="ac-rd"><input type="radio" name="dc' + key + '" value="cr"> دائن</label></span>' : ""}</div>
        <div class="ac-fr"><span class="lb">عن الفترة بين</span><input type="date" data-k="f1"><input type="date" data-k="f2"><i class="req">*</i></div>
        <div class="tx-pq">${[["cm", "هذا الشهر"], ["pm", "الشهر الماضي"], ["pq", "الربع الماضي"], ["cy", "هذه السنة"]].map(x => `<button type="button" data-per="${x[0]}">${x[1]}</button>`).join("")}</div></div>
        <div class="ac-tref"><div class="ac-fr v"><span class="lb">رقم المرجع #</span><input data-k="ref" class="box"></div>
          <div class="tx-card" data-sum><div class="tx-ch">${TXI.sum}<b>ملخص الفترة الضريبية</b><span data-per-l></span></div><div class="tx-cb" data-sb><div class="tx-ld"><i></i>جارٍ الحساب …</div></div></div></div></div>
      <div class="ac-xrow"><div class="ac-xs bl tall">التفاصيل</div><div class="ac-tc">
        <div class="ac-fr"><span class="lb">الدفع من</span><span data-ap="1"></span></div>
        <div class="ac-fr"><span class="lb">العمله</span><span class="ac-cur">${A.selH("cur", ["DZD"], "DZD")}<span class="spin"><input data-k="rate" value="1"><i>⌃</i><i>⌄</i></span></span><i class="req">*</i></div>
        <div class="ac-fr"><span class="lb">الملاحظات</span><textarea data-k="notes" rows="3"></textarea></div></div></div>
      <div class="ac-btns t"><button type="button" class="ac-btn green" data-a="save2">حفظ</button><button type="button" class="ac-btn blue" data-a="sp2">حفظ و طباعة</button><button type="button" class="ac-btn blue" data-a="close2">اغلاق</button></div></div>`;
    const Q = s => page.querySelector(s), K = k => page.querySelector(`[data-k="${k}"]`);
    const HD = A.wireHeader(page, kind, D);
    const AP = A.accPicker(Q("[data-ap]"), { type: "tr" });
    const TP = A.treePicker(Q("[data-tp]"), { key: "tacc", root: "2", hide: ["21", "213"], value: VAT_NAME, ph: "اختر حساب الضريبة", onChange: () => { D.dirtyF = true; okAcc(); sumSoon(); } });
    const accNo = () => (TP.node && TP.node.no) || (TP.get() === VAT_NAME ? VAT_NO : "");
    const okAcc = () => { const o = Q("[data-okacc]"); if (o) o.style.visibility = TP.get() ? "" : "hidden"; };
    const dc = () => { const r = page.querySelector('input[type=radio]:checked'); return r ? r.value : ""; };
    /* ---------- الملخص الذكي */
    let sumT = 0, sumSeq = 0;
    const sumSoon = () => { clearTimeout(sumT); sumT = setTimeout(drawSum, 250); };
    function drawSum() {
      const box = Q("[data-sb]"), f1 = K("f1").value, f2 = K("f2").value, no = accNo(), seq = ++sumSeq;
      const pl = Q("[data-per-l]"); if (pl) pl.textContent = f1 && f2 ? f1 + " ← " + f2 : "";
      if (!f1 || !f2 || f1 > f2) { box.innerHTML = '<div class="tx-em">حدّد الفترة لعرض الملخص</div>'; return; }
      box.innerHTML = '<div class="tx-ld"><i></i>جارٍ الحساب …</div>';
      taxSummary(f1, f2, no, D.id, kind).then(S => {
        if (seq !== sumSeq) return;
        const row = (t, v, cls, hint) => `<div class="tx-r ${cls || ""}"${hint ? ` title="${esc(hint)}"` : ""}><span>${t}</span><b>${fmt(v)}</b></div>`;
        const due = S.due, st = due > 0.009 ? "due" : due < -0.009 ? "cred" : "zero";
        box.innerHTML = (S.isVat ? row("ضريبة المبيعات (المحصّلة)", S.sTax, "", S.nS + " فاتورة مبيعات / مرتجع") + row("− ضريبة المشتريات (القابلة للخصم)", -S.pTax, "", S.nP + " فاتورة مشتريات / مرتجع") + row("الضريبة عن الفترة", S.gross, "sub") : `<div class="tx-em sm">حساب «${esc(TP.get())}»: الملخص من المستندات المسجلة فقط</div>`)
          + row("− المسدد عن نفس الفترة", -S.paid) + (S.adjDr || S.adjCr ? row("± التسويات (مدين / دائن)", r2(S.adjCr - S.adjDr)) : "")
          + `<div class="tx-due ${st}"><span>${st === "cred" ? "رصيد دائن (مسترد)" : st === "zero" ? "لا يوجد مستحق ✓" : "المستحق للسداد"}</span><b>${fmt(Math.abs(due))} <small>DZD</small></b></div>
          <div class="tx-act">${st === "due" && !adj ? `<button type="button" class="tx-use" data-a="use">${TXI.use}استخدام المبلغ</button>` : ""}${S.isVat ? `<button type="button" class="tx-rp" data-a="vat">${TXI.rpt}تقرير ضريبة القيمة المضافة</button>` : ""}</div>`;
        D.sugg = st === "due" ? due : 0;
      }).catch(() => { if (seq === sumSeq) box.innerHTML = '<div class="tx-em">تعذّر حساب الملخص</div>'; });
    }
    function reset() { D.id = 0; D.fx = []; D.dirtyF = false; D.title = title; HD.set("", today()); A.nextNo(kind).then(n => { if (!D.id) K("no").value = n; }); ["amt", "ref", "notes"].forEach(k => K(k).value = ""); const p = txPeriod("pm"); K("f1").value = p[0]; K("f2").value = p[1]; TP.set(VAT_NAME); okAcc(); page.querySelectorAll("input[type=radio]").forEach(r => r.checked = false); sumSoon(); }
    function fill(d) { const x = d.data; D.id = d.id; D.fx = x.fx || []; D.dirtyF = false; HD.set(d.no, x.date, x.br); TP.set(x.taccName || (TX_OLD[x.tacc] || [])[1] || VAT_NAME); okAcc(); K("amt").value = x.amt || ""; K("ref").value = x.ref || ""; K("notes").value = x.notes || ""; K("f1").value = x.f1 || ""; K("f2").value = x.f2 || "";
      if (adj) { const r = page.querySelector(`input[type=radio][value="${x.dc || "dr"}"]`); if (r) r.checked = true; } AP.set((x.acc || {}).type, (x.acc || {}).id); D.title = title + " - " + d.no; tabOpen(D.key, D.title, view); sumSoon(); }
    D.open = id => A.docs(kind, true).then(l => { const d = l.find(z => z.id === id); if (d) fill(d); });
    D.dirty = () => D.dirtyF && num(K("amt").value) > 0;
    D.save = after => {
      const h = HD.get(), amt = r2(num(K("amt").value)), tname = TP.get().trim();
      if (!tname) { say("اختر اسم الحساب", "w"); TP.input.focus(); return; }
      if (!(amt > 0)) { say("أدخل المبلغ", "w"); K("amt").focus(); return; }
      if (adj && !dc()) { say("اختر مدين أو دائن", "w"); return; }
      if (!K("f1").value || !K("f2").value) { say("أدخل الفترة", "w"); return; }
      if (K("f1").value > K("f2").value) { say("بداية الفترة بعد نهايتها", "w"); return; }
      if (!AP.acc) { say("اختر حساب الدفع", "w"); return; }
      const sign = adj && dc() === "cr" ? 1 : -1, tno = accNo();
      const go = no => { const notes = title + " رقم " + no + " (" + K("f1").value + " - " + K("f2").value + ")";
        const af = A.accFx(AP.acc, sign * amt, { party: tname, notes, what: title });
        const lg = af.lg.concat([{ t: "taxa", id: +tno || 1, d: r2(-sign * amt), name: tname, what: title }]);
        const data = { date: h.date, time: A.nowT(), br: h.br, tacc: tno || "vat19", taccNo: tno, taccName: tname, amt, dc: adj ? dc() : "dr", f1: K("f1").value, f2: K("f2").value, acc: AP.acc, ref: K("ref").value.trim(), notes: K("notes").value.trim(), total: amt, cur: "DZD", rate: num(K("rate").value) || 1, fx: af.fx, lg, user: (window.__USER_NAME || "ANOUER"), mod: A.nowT ? h.date + " " + A.nowT() : "" };
        if (D.id) data.modBy = window.__USER_NAME || "ANOUER";
        return A.post(af.fx, D.fx, { date: h.date, no: String(no), notes }).then(() => A.saveDoc(kind, { id: D.id, no, data }))
          .then(r => { A.invalidate(); A.snd("save"); say("تم حفظ " + title + " رقم " + (r.no || no), "s"); delete A.AC.tr; if (after === "print") printTax(kind, { no: r.no || no, data });
            const was = D.id; D.id = r.id; D.fx = af.fx; D.dirtyF = false; AP.refresh(); if (!was) reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); }); };
      (h.no ? Promise.resolve(h.no) : A.nextNo(kind)).then(go).catch(e => { A.snd("err"); say("لم يتم الحفظ: " + (e.message || e), "e"); });
    };
    D.remove = () => { if (!D.id) return; A.ask("هل تريد حذف المستند رقم " + K("no").value + " ؟", () => A.post([], D.fx, { date: HD.get().date, no: K("no").value }).then(() => A.delDoc(kind, D.id)).then(() => { A.invalidate(); say("تم الحذف", "s"); reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); })); };
    const calc = () => { const b = Q('[data-a="calc"]'); if (window.ANOUER_CALC) ANOUER_CALC.open(b.parentElement, num(K("amt").value) || 0, v => { K("amt").value = r2(v) || ""; D.dirtyF = true; K("amt").focus(); }, { title: "المبلغ" }); };
    page.addEventListener("click", e => { const b = e.target.closest("button[data-a],button[data-per]"); if (!b) return;
      if (b.dataset.per) { const p = txPeriod(b.dataset.per); K("f1").value = p[0]; K("f2").value = p[1]; D.dirtyF = true; page.querySelectorAll(".tx-pq button").forEach(x => x.classList.toggle("on", x === b)); sumSoon(); return; }
      const a = b.dataset.a;
      if (a === "file") A.fileMenu(b, D); else if (a === "save" || a === "save2") D.save(); else if (a === "savePrint" || a === "sp2") D.save("print"); else if (a === "close2") A.closeDoc(D); else if (a === "cols") A.fieldChooser(page, kind, b);
      else if (a === "calc") calc();
      else if (a === "use") { if (D.sugg > 0) { K("amt").value = r2(D.sugg); D.dirtyF = true; K("amt").classList.add("tx-flash"); setTimeout(() => K("amt").classList.remove("tx-flash"), 900); A.snd && A.snd("click"); } }
      else if (a === "vat") openVat(K("f1").value, K("f2").value); });
    page.addEventListener("keydown", e => { if (e.target === K("amt") && e.altKey && e.key === "ArrowDown") { e.preventDefault(); calc(); } });
    page.addEventListener("input", e => { if (e.target.dataset && e.target.dataset.k) D.dirtyF = true; });
    page.addEventListener("change", e => { const k = e.target.dataset && e.target.dataset.k; if (k === "f1" || k === "f2") { page.querySelectorAll(".tx-pq button").forEach(x => x.classList.remove("on")); sumSoon(); } if (e.target.type === "radio") D.dirtyF = true; });
    reset(); tabOpen(key, title, view); if (id) D.open(id);
    return D;
  }
  /* طباعة إيصال سداد / تسوية ضريبية (من الشاشة أو من المراجعة) */
  function printTax(kind, d) {
    const x = d.data || {}, adj = kind === "taxs";
    A.printDoc(A.TITLE[kind] + " رقم " + d.no, A.kvHtml([["الرقم", d.no], ["التاريخ", x.date], ["اسم الحساب", (x.taccNo ? x.taccNo + " - " : "") + (x.taccName || "")], ["المبلغ", fmt(+x.amt || 0) + " DZD" + (adj ? (x.dc === "cr" ? " (دائن)" : " (مدين)") : "")], ["عن الفترة", (x.f1 || "") + " ← " + (x.f2 || "")], [adj ? "الحساب المقابل" : "الدفع من", (x.acc || {}).name || ""], ["رقم المرجع", x.ref || ""], ["الملاحظات", x.notes || ""], ["بواسطة", x.user || ""]]));
  }
  /* طباعة قيد التعامل */
  function printTaxJe(kind, d) {
    const x = d.data || {}, amt = r2(+x.amt || 0), acc = (x.acc || {}).name || "الخزينة", tn = (x.taccNo ? x.taccNo + " - " : "") + (x.taccName || "");
    const crSide = kind === "taxs" && x.dc === "cr";
    const L = crSide ? [[acc, amt, 0], [tn, 0, amt]] : [[tn, amt, 0], [acc, 0, amt]];
    A.printDoc("قيد " + A.TITLE[kind] + " رقم " + d.no, A.kvHtml([["رقم القيد", d.no], ["التاريخ", x.date], ["البيان", A.TITLE[kind] + " رقم " + d.no + " (" + (x.f1 || "") + " - " + (x.f2 || "") + ")"], ["بواسطة", x.user || ""]]),
      `<table><tr><th>الحساب</th><th>مدين</th><th>دائن</th></tr>${L.map(z => `<tr><td>${esc(z[0])}</td><td>${z[1] ? fmt(z[1]) : ""}</td><td>${z[2] ? fmt(z[2]) : ""}</td></tr>`).join("")}<tr><th>الاجمالي</th><th>${fmt(amt)}</th><th>${fmt(amt)}</th></tr></table>`);
  }
  function openVat(f1, f2) { const R = window.ANOUER_REPORTS; if (R && R.vat) R.vat(f1, f2); else if (R && R.run) R.run(482); }

  window.ANOUER_ACDOCS = { exp: id => itemsDoc("exp", id), rev: id => itemsDoc("rev", id), je: id => jeDoc(id), xfer: id => xferDoc(id), taxp: id => taxDoc("taxp", id), taxs: id => taxDoc("taxs", id), LGrid, TAXES, JET, printTax, printTaxJe, taxSummary, txPeriod };
})();
