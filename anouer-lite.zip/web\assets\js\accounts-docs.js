/* ANOUER — «المصروفات» Ctrl+K، «الإيرادات» Alt+I، «قيود المحاسبة» Ctrl+T، «تحويل النقدية»، «سداد الضرائب» و«تسويات ضريبية» — مطابقة DEXEF ONE */
(function () {
  "use strict";
  const A = window.__AC, H = window.__FH;
  if (!A || !H) return;
  const { esc, fmt, r2, num, say, today, tabOpen, Dlg } = H;
  const { I } = A;
  const CC = ["", "مركز التكلفة الرئيسي"];
  const TAXES = [["", ""], ["vat19", "ضريبة القيمة المضافة 19%", 19], ["vat9", "ضريبة القيمة المضافة 9%", 9], ["stamp", "ضريبة الطابع 1%", 1]];
  const taxRate = k => { const t = TAXES.find(x => x[0] === k); return t ? +t[2] || 0 : 0; };
  const EXPT = [["gen", "مصروف عام", "eitm"], ["cred", "مصروف على الإعتماد", "dtax"], ["asset", "مصروف على الأصول", "bk"]];
  const ALLV = ["التاريخ", "البيان"];

  /* شبكة سطور قابلة للتعديل بنمط DEXEF (سهم ← + خلايا + ✕) */
  function LGrid(host, cfg) {
    const G = { rows: [] };
    function render() {
      host.innerHTML = `<div class="ac-lg" style="--tpl:${cfg.tpl}"><div class="h"><span></span>${cfg.cols.map(c => `<span>${esc(c.t)}</span>`).join("")}<span></span></div><div class="b">${G.rows.map((r, i) => row(r, i)).join("")}${row(null, G.rows.length)}${Array.from({ length: Math.max(0, (cfg.min || 9) - G.rows.length - 1) }, (_, k) => `<div class="r f${(G.rows.length + k + 1) % 2 ? " alt" : ""}"></div>`).join("")}</div>
        <div class="t"><span></span>${cfg.cols.map(c => `<span class="n">${c.sum ? fmt(G.rows.reduce((s, r) => s + (+r[c.k] || 0), 0)) : ""}</span>`).join("")}<span></span></div></div>`;
      if (cfg.onRender) cfg.onRender();
    }
    function row(r, i) {
      const nr = !r; r = r || {};
      return `<div class="r${i % 2 ? " alt" : ""}${nr ? " new" : ""}" data-i="${i}"><span class="ind">${nr ? "←" : ""}</span>${cfg.cols.map(c => `<span>${c.ro ? `<b class="ro${c.n ? " n" : ""}">${esc(c.f ? c.f(r) : r[c.k] || "")}</b>` : c.sel ? `<select data-c="${c.k}">${(typeof c.sel === "function" ? c.sel(r) : c.sel).map(o => A.opt(o[0], o[1], String(o[0]) === String(r[c.k] == null ? "" : r[c.k]))).join("")}</select>` : `<input data-c="${c.k}"${c.n ? ' class="n" inputmode="decimal"' : ""}${c.list ? ` list="${c.list}"` : ""} value="${esc(r[c.k] == null || r[c.k] === 0 && c.n ? "" : r[c.k])}" autocomplete="off">`}</span>`).join("")}<span>${nr ? "" : `<button type="button" data-del="${i}" title="حذف السطر">${I.xr}</button>`}</span></div>`;
    }
    host.addEventListener("change", e => {
      const el = e.target, rr = el.closest(".r[data-i]"); if (!rr || !el.dataset.c) return; const i = +rr.dataset.i;
      if (i >= G.rows.length) G.rows.push(cfg.blank ? cfg.blank() : {});
      const r = G.rows[i], c = cfg.cols.find(x => x.k === el.dataset.c);
      r[el.dataset.c] = c && c.n ? r2(num(el.value)) : el.value;
      Promise.resolve(cfg.onChange ? cfg.onChange(r, el.dataset.c, i) : 0).then(() => { render(); const nx = host.querySelector(`.r[data-i="${i}"] [data-c="${el.dataset.c}"]`); });
    });
    host.addEventListener("click", e => { const d = e.target.closest("[data-del]"); if (d) { G.rows.splice(+d.dataset.del, 1); render(); if (cfg.onDel) cfg.onDel(); } });
    host.addEventListener("keydown", e => { if (e.key !== "Enter" || !e.target.dataset.c) return; e.preventDefault(); const ins = [...host.querySelectorAll("input[data-c],select[data-c]")]; const j = ins.indexOf(e.target); e.target.dispatchEvent(new Event("change", { bubbles: true })); setTimeout(() => { const ins2 = [...host.querySelectorAll("input[data-c],select[data-c]")]; if (ins2[j + 1]) ins2[j + 1].focus(); }, 0); });
    return Object.assign(G, { set(r) { G.rows = r || []; render(); }, render });
  }
  function dl(id, items) { let d = document.getElementById(id); if (!d) { d = document.createElement("datalist"); d.id = id; document.body.appendChild(d); } d.innerHTML = items.map(x => `<option value="${esc(x)}">`).join(""); return id; }

  /* ================================================================== المصروفات / الإيرادات */
  function itemsDoc(kind, id) {
    if (id) { const ex = Object.values(A.DOCS).find(d => d.kind === kind && d.id === id); if (ex) { tabOpen(ex.key, ex.title, ex.view); return ex; } }
    const exp = kind === "exp", view = "ac" + kind, key = view + ":" + A.nextSeq(), title = A.TITLE[kind];
    const page = A.docPage(view, title, key);
    const D = A.DOCS[key] = { key, kind, view, page, title, id: 0, fx: [], lg: [], dirtyF: false };
    const tb = exp ? A.toolbar([["prev", "", I.prev], ["next", "", I.next], ["save", "حفظ", I.save, 0, "", 1], ["print", "طباعة", I.print, 0, "", 1], ["mail", "Email", I.mail], ["reload", "تحديث البيانات", I.spin], ["copy", "نسخ التعامل", I.dup], ["xls", "تصدير إلى Xls", I.xls, 0, "", 1], ["del", "حذف", I.del, 1], ["close", "إغلاق", I.close], ["att", "المرفقات", I.clip, 1]], [["cols", "إختيار الحقول", I.cols]])
      : A.toolbar([["save", "حفظ", I.save], ["savePrint", "حفظ و طباعة", I.print]], [["cols", "اختيار الحقول", I.cols]]);
    page.innerHTML = (exp ? '<div class="ac-tabs"><button type="button" class="on">عام</button><button type="button" data-a="fmt">تنسيق الإدخال</button></div>' : "") + tb + A.header() + `<div class="ac-body ac-items">
      <div class="ac-ir1">${exp ? `<div class="ac-fr v"><span class="lb">نوع المصروف</span><span class="ac-ap"><button type="button" class="ac-ty" data-a="etype">${I.eitm}<i>⌄</i></button><span class="ac-etxt" data-k="etxt">مصروف عام</span></span></div>` : ""}
        <div class="ac-banner ${exp ? "red" : "green"}">${esc(title)}</div><div class="ac-fr v vm"><span class="lb">طريقة العرض</span><span class="ac-cb"><input value="" readonly><i class="ok">✓</i><button type="button" class="dd" tabindex="-1">⌄</button></span></div></div>
      <div class="ac-ir2"><div class="ac-fr v w"><span class="lb">البيان</span><input data-k="stmt" autocomplete="off"><i class="req">${exp ? "" : "*"}</i></div>
        <div class="ac-fr v"><span class="lb">الضريبة</span>${A.selH("tax", TAXES.map(t => [t[0], t[1]]), "")}</div><div class="ac-fr v"><span class="lb">مركز التكلفة</span>${A.selH("cc", CC, "")}</div>
        ${exp ? `<div class="ac-fr v"><span class="lb">الاعتماد</span>${A.selH("credit", ["", "اعتماد مستندى"], "")}</div>` : ""}<div class="ac-fr v"><span class="lb">رقم المرجع #</span><input data-k="ref" autocomplete="off"></div></div>
      <div class="ac-grid" data-g="1"></div>
      <div class="ac-ifoot"><div class="ac-it"><div class="ac-tl"><span>الاجمالى قبل الضريبة:</span><b data-k="tb">0</b></div><div class="ac-tl"><span>الضرائب :</span><b data-k="tt">0</b></div><div class="ac-bigt" data-k="tot">0</div></div>
        <div class="ac-ipm"><div class="ac-fr"><span class="lb">طريقة الدفع</span><span class="ac-mt"><small>النوع</small><small>اسم الحساب</small><span data-ap="1"></span></span></div>
          <div class="ac-fr"><span class="lb">العمله</span><span class="ac-cur">${A.selH("cur", ["DZD"], "DZD")}<span class="spin"><input data-k="rate" value="1"><i>⌃</i><i>⌄</i></span></span><i class="req">*</i></div>
          <div class="ac-fr"><span class="lb">الملاحظات</span><textarea data-k="notes" rows="2"></textarea></div></div></div>
      <div class="ac-btns"><button type="button" class="ac-btn blue" data-a="save2">حفظ</button><button type="button" class="ac-btn blue" data-a="sp2">حفظ و طباعة</button><button type="button" class="ac-btn blue" data-a="close2">اغلاق</button></div></div>`;
    const Q = s => page.querySelector(s), K = k => page.querySelector(`[data-k="${k}"]`);
    const HD = A.wireHeader(page, kind, D);
    const AP = A.accPicker(Q("[data-ap]"), { type: "tr" });
    let ITEMS = [], etype = "gen";
    const lid = "acitm_" + kind;
    A.accounts(kind).then(l => { ITEMS = l; dl(lid, l.map(x => x.name)); if (!l.length) say("لا توجد بنود " + (exp ? "مصروفات" : "إيرادات") + " — أضفها من «الفهرس ← بنود " + (exp ? "المصروفات" : "الإيرادات") + "»", "i"); });
    const G = LGrid(Q("[data-g]"), { tpl: "40px 180px minmax(220px,1.6fr) 1fr minmax(220px,1.8fr) 34px", min: 10, blank: () => ({ no: "", name: "", amt: 0, note: "" }),
      cols: [{ k: "no", t: "الرقم" }, { k: "name", t: exp ? "نوع المصروف" : "نوع الايراد", list: lid }, { k: "amt", t: "المبلغ", n: 1, sum: 1 }, { k: "note", t: "الشرح" }],
      onChange: (r, k) => { D.dirtyF = true; if (k === "name") { const it = ITEMS.find(x => x.name === r.name); r.iid = it ? it.id : 0; if (it) r.no = it.no; } else if (k === "no") { const it = ITEMS.find(x => String(x.no) === String(r.no)); if (it) { r.name = it.name; r.iid = it.id; } } },
      onRender: tot, onDel: () => { D.dirtyF = true; } });
    function tot() { const b = r2(G.rows.reduce((s, r) => s + (+r.amt || 0), 0)), t = r2(b * taxRate(K("tax").value) / 100); K("tb").textContent = fmt(b); K("tt").textContent = fmt(t); K("tot").textContent = fmt(b + t); return { b, t, tot: r2(b + t) }; }
    K("tax").addEventListener("change", tot);
    if (exp) Q('[data-a="etype"]').addEventListener("click", e => H.ctxMenu(EXPT.map(x => [x[1], "", I[x[2]], () => { etype = x[0]; K("etxt").textContent = x[1]; Q('[data-a="etype"]').innerHTML = I[x[2]] + "<i>⌄</i>"; }]), e.currentTarget.getBoundingClientRect()));
    function reset() { D.id = 0; D.fx = []; D.lg = []; D.dirtyF = false; D.title = title; HD.set("", today()); A.nextNo(kind).then(n => { if (!D.id) K("no").value = n; }); ["stmt", "ref", "notes"].forEach(k => K(k).value = ""); K("tax").value = ""; K("cc").value = ""; G.set([]); const del = Q('[data-a="del"]'); if (del) del.disabled = true; }
    function fill(d) { const x = d.data; D.id = d.id; D.fx = x.fx || []; D.lg = x.lg || []; D.dirtyF = false; HD.set(d.no, x.date, x.br); K("stmt").value = x.stmt || ""; K("ref").value = x.ref || ""; K("notes").value = x.notes || ""; K("tax").value = x.tax || ""; K("cc").value = x.cc || "";
      if (exp && x.etype) { const t = EXPT.find(z => z[0] === x.etype) || EXPT[0]; etype = t[0]; K("etxt").textContent = t[1]; }
      G.set((x.rows || []).map(r => Object.assign({}, r))); AP.set((x.acc || {}).type || "tr", (x.acc || {}).id); const del = Q('[data-a="del"]'); if (del) del.disabled = false; D.title = title + " - " + d.no; tabOpen(D.key, D.title, view); }
    D.open = id => A.docs(kind, true).then(l => { const d = l.find(z => z.id === id); if (d) fill(d); });
    D.dirty = () => D.dirtyF && G.rows.length > 0;
    D.reload = () => { if (D.id) D.open(D.id); else { delete A.AC[kind]; A.accounts(kind, true).then(l => { ITEMS = l; dl(lid, l.map(x => x.name)); }); AP.refresh(); } };
    D.save = after => {
      const h = HD.get(), t = tot(), rows = G.rows.filter(r => r.name || r.amt);
      if (!exp && !K("stmt").value.trim()) { say("البيان حقل إجباري", "w"); K("stmt").focus(); return; }
      if (!rows.length || !(t.b > 0)) { say("أدخل " + (exp ? "المصروفات" : "الإيرادات") + " في الجدول", "w"); return; }
      const bad = rows.findIndex(r => !r.iid || !(r.amt > 0)); if (bad >= 0) { say("السطر " + (bad + 1) + ": اختر " + (exp ? "نوع المصروف" : "نوع الإيراد") + " من البنود وأدخل المبلغ", "w"); return; }
      if (!AP.acc) { say("اختر طريقة الدفع (اسم الحساب)", "w"); return; }
      const sign = exp ? -1 : 1;
      const go = no => { const notes = title + " رقم " + no + (K("stmt").value ? " - " + K("stmt").value : "");
        const af = A.accFx(AP.acc, sign * t.tot, { party: K("stmt").value, notes, what: title });
        const lg = af.lg.concat(rows.map(r => ({ t: kind, id: r.iid, d: r2(r.amt), name: r.name, what: title })));
        const data = { date: h.date, time: A.nowT(), br: h.br, etype, stmt: K("stmt").value.trim(), ref: K("ref").value.trim(), tax: K("tax").value, cc: K("cc").value, rows, before: t.b, taxv: t.t, total: t.tot, acc: AP.acc, notes: K("notes").value.trim(), fx: af.fx, lg, user: (window.__USER_NAME || "ANOUER") };
        return A.post(af.fx, D.fx, { date: h.date, no: String(no), notes }).then(() => A.saveDoc(kind, { id: D.id, no, data }))
          .then(r => { A.invalidate(); A.snd("save"); say("تم حفظ " + title + " رقم " + (r.no || no), "s"); delete A.AC.tr; if (after === "print") printIt(r.no || no, data); const was = D.id; D.id = r.id; D.fx = af.fx; D.dirtyF = false; if (!was) reset(); else D.open(r.id); if (window.__AC_REFRESH) __AC_REFRESH(kind); }); };
      (h.no ? Promise.resolve(h.no) : A.nextNo(kind)).then(go).catch(e => { A.snd("err"); say("لم يتم الحفظ: " + (e.message || e), "e"); });
    };
    D.remove = () => { if (!D.id) return; A.ask("هل تريد حذف " + title + " رقم " + K("no").value + " ؟", () => A.post([], D.fx, { date: HD.get().date, no: K("no").value, notes: "حذف " + title }).then(() => A.delDoc(kind, D.id)).then(() => { A.invalidate(); A.snd("del"); say("تم الحذف", "s"); reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); }).catch(e => say(e.message, "e"))); };
    function printIt(no, x) { x = x || { stmt: K("stmt").value, rows: G.rows, before: tot().b, taxv: tot().t, total: tot().tot };
      /* «تصميم التقارير»: مصروفات / ايرادات بالتصميم الافتراضي */
      if (window.ANOUER_RD && !window.__rdOff) {
        const tx = exp ? "مصروفات" : "ايرادات", h = HD.get(), amt = +x.total || 0;
        const hd = { Number: no || K("no").value, Transaction: tx, Date: h.date, Time: "", "Party Name": "", Amount: amt, "Amount In Words": ANOUER_RD.tafqit(amt, ANOUER_RD.currencyName()), Statement: x.stmt || "", Account: (AP.acc || {}).name || "", "Payment Method": (AP.acc || {}).name || "", WrittenBy: ANOUER_RD.userName(), Branch: h.br || "", Notes: "", "Previous Balance": 0, "Current Balance": 0 };
        const items = (x.rows || []).map((r, i) => ({ Index: i + 1, Account: r.name, Amount: +r.amt || 0, Notes: r.note || "" }));
        ANOUER_RD.printTx({ tx, data: { header: hd, items }, mode: "preview", title: tx + " " + hd.Number }).catch(e => say("تعذّرت الطباعة: " + ((e && e.message) || e), "e"));
        return;
      }
      A.printDoc(title, A.kvHtml([["الرقم", no || K("no").value], ["التاريخ", HD.get().date], ["البيان", x.stmt], ["طريقة الدفع", (AP.acc || {}).name || ""]]), `<table><tr><th>${exp ? "نوع المصروف" : "نوع الايراد"}</th><th>المبلغ</th><th>الشرح</th></tr>${(x.rows || []).map(r => `<tr><td>${esc(r.name)}</td><td>${fmt(r.amt)}</td><td>${esc(r.note || "")}</td></tr>`).join("")}<tr><th>الاجمالى قبل الضريبة</th><th>${fmt(x.before)}</th><th></th></tr><tr><th>الضرائب</th><th>${fmt(x.taxv)}</th><th></th></tr><tr><th>الإجمالى</th><th>${fmt(x.total)}</th><th></th></tr></table>`); }
    function step(dir) { A.docs(kind, true).then(l => { if (!l.length) return say("لا توجد مستندات محفوظة", "i"); l.sort((a, b) => (+a.no || 0) - (+b.no || 0)); const c = l.findIndex(x => x.id === D.id), n = c < 0 ? (dir < 0 ? l.length - 1 : 0) : c + dir; if (n < 0 || n >= l.length) return say(dir < 0 ? "هذا أول مستند" : "هذا آخر مستند", "i"); fill(l[n]); }); }
    page.addEventListener("click", e => { const b = e.target.closest("button[data-a]"); if (!b || b.disabled) return; const a = b.dataset.a;
      if (a === "file") A.fileMenu(b, D, [["طباعة", "Ctrl+P", I.print, () => printIt()]]);
      else if (a === "save" || a === "save2") D.save(); else if (a === "savePrint" || a === "sp2") D.save("print"); else if (a === "print") printIt();
      else if (a === "close" || a === "close2") A.closeDoc(D); else if (a === "del") D.remove(); else if (a === "reload") D.reload();
      else if (a === "prev") step(-1); else if (a === "next") step(1);
      else if (a === "copy") { D.id = 0; D.fx = []; A.nextNo(kind).then(n => { K("no").value = n; }); D.title = title; tabOpen(D.key, title, view); say("تم نسخ التعامل — عدّل ثم احفظ كمستند جديد", "i"); const del = Q('[data-a="del"]'); if (del) del.disabled = true; }
      else if (a === "xls") { const csv = "﻿" + [["الرقم", "النوع", "المبلغ", "الشرح"]].concat(G.rows.map(r => [r.no, r.name, r.amt, r.note || ""])).map(r => r.join(",")).join("\r\n"); const x = document.createElement("a"); x.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" })); x.download = title + ".csv"; x.click(); }
      else if (a === "mail" && window.ANOUER_MAIL) ANOUER_MAIL.viaPrint(() => printIt());
      else if (a === "mail") { const t = tot(); location.href = "mailto:?subject=" + encodeURIComponent(title + " رقم " + K("no").value) + "&body=" + encodeURIComponent(G.rows.map(r => r.name + ": " + fmt(r.amt)).join("\n") + "\nالإجمالى: " + fmt(t.tot)); }
      else if (a === "fmt") say("تنسيق الإدخال: Enter ينتقل للحقل التالي، والسطر الجديد يُضاف تلقائياً", "i");
      else if (a === "cols") A.fieldChooser(page, kind, b); });
    page.addEventListener("input", e => { if (e.target.dataset && e.target.dataset.k) D.dirtyF = true; });
    reset(); tabOpen(key, title, view); if (id) D.open(id);
    return D;
  }

  /* ================================================================== قيود المحاسبة */
  const JET = [["gl", "حساب استاذ", "gl"], ["cu", "العملاء", "cu"], ["su", "الموردين", "su"], ["tr", "الخزينة", "tr"], ["bk", "البنوك", "bk"], ["pos", "فيزا", "pos"], ["emp", "عهد الموظفين", "cust"], ["oth", "جهات أخرى", "oth"], ["zm", "الزمم", "zm"], ["taxa", "الضرائب", "pct"], ["wtax", "ضرائب الخصم", "dtax"], ["exp", "المصروفات", "eitm"], ["rev", "الإيرادات", "ritm"]];
  function jeList(t) { if (t === "cu" || t === "su") return A.parties(t); if (["tr", "bk", "pos", "gl", "emp", "exp", "rev"].includes(t)) return A.accounts(t); if (t === "taxa") return Promise.resolve([{ id: 2132, no: "2132", name: "ضريبة القيمة المضافة" }, { id: 2133, no: "2133", name: "مصلحة الضرائب العامة" }].concat(TAXES.filter(x => x[0]).map((x, i) => ({ id: i + 1, no: x[0], name: x[1] })))); if (t === "wtax") return Promise.resolve([{ id: 1, no: "wt1", name: "ضرائب الخصم والإضافة" }]); return Promise.resolve(H.lsGet("ac.jeo." + t, [])); }
  function jeDoc(id) {
    if (id) { const ex = Object.values(A.DOCS).find(d => d.kind === "je" && d.id === id); if (ex) { tabOpen(ex.key, ex.title, ex.view); return ex; } }
    const kind = "je", view = "acje", key = view + ":" + A.nextSeq(), title = A.TITLE.je;
    const page = A.docPage(view, title, key);
    const D = A.DOCS[key] = { key, kind, view, page, title, id: 0, fx: [], dirtyF: false };
    page.innerHTML = A.toolbar([["save", "حفظ", I.save], ["savePrint", "حفظ و طباعة", ""]], [["cols", "اختيار الحقول", I.cols]]) + A.header() + `<div class="ac-body ac-je">
      <div class="ac-side3"><div class="t or">بيانات اساسية</div><div class="t bl grow">القيود</div><div class="t bl">الملاحظا ت</div></div>
      <div class="ac-jm"><div class="ac-jr1"><div class="ac-fr"><span class="lb">بيان القيد</span><input data-k="stmt" class="wide" autocomplete="off"><i class="req">*</i></div><div class="ac-fr v"><span class="lb">مركز التكلفة</span>${A.selH("cc", CC, "")}</div></div>
        <div class="ac-jr2"><div class="ac-fr"><span class="lb">العملة</span><span class="ac-cur">${A.selH("cur", ["DZD"], "DZD")}<span class="spin"><input data-k="rate" value="1"><i>⌃</i><i>⌄</i></span></span><i class="req">*</i></div><button type="button" class="ac-rev" data-a="flip">عكس القيد</button></div>
        <div class="ac-grid" data-g="1"></div>
        <div class="ac-jf"><textarea data-k="notes" rows="2" placeholder=""></textarea><div class="ac-jt"><div><span>مدين</span><b data-k="dr">0</b></div><div><span>دائن</span><b data-k="cr">0</b></div></div></div>
        <div class="ac-btns"><button type="button" class="ac-btn green" data-a="save2">حفظ</button><button type="button" class="ac-btn blue" data-a="sp2">حفظ و طباعة</button><button type="button" class="ac-btn blue" data-a="close2">إغلاق</button></div></div></div>`;
    const Q = s => page.querySelector(s), K = k => page.querySelector(`[data-k="${k}"]`);
    const HD = A.wireHeader(page, kind, D);
    const LISTS = {};
    function ensure(t) { if (LISTS[t]) return Promise.resolve(LISTS[t]); return jeList(t).then(l => { LISTS[t] = l || []; dl("acje_" + t, LISTS[t].map(x => x.name)); return LISTS[t]; }); }
    ensure("gl");
    const G = LGrid(Q("[data-g]"), { tpl: "40px 150px 140px minmax(220px,1.6fr) 1fr 1fr minmax(200px,1.5fr) 34px", min: 12, blank: () => ({ t: "gl", no: "", name: "", dr: 0, cr: 0, note: "" }),
      cols: [{ k: "t", t: "النوع", sel: JET.map(x => [x[0], x[1]]) }, { k: "no", t: "الرقم" }, { k: "name", t: "الاسم" }, { k: "dr", t: "مدين", n: 1, sum: 1 }, { k: "cr", t: "دائن", n: 1, sum: 1 }, { k: "note", t: "الشرح" }],
      onRender: () => { Q("[data-g]").querySelectorAll('.r[data-i] input[data-c="name"]').forEach(inp => { const i = +inp.closest(".r").dataset.i, r = G.rows[i] || { t: "gl" }; inp.setAttribute("list", "acje_" + r.t); }); tot(); },
      onChange: (r, k) => { D.dirtyF = true; if (k === "t") { r.no = ""; r.name = ""; r.aid = 0; return ensure(r.t); }
        return ensure(r.t || "gl").then(l => { if (k === "name") { const a = l.find(x => x.name === r.name); r.aid = a ? a.id : 0; if (a) r.no = a.no || a.id; } else if (k === "no") { const a = l.find(x => String(x.no) === String(r.no)); if (a) { r.name = a.name; r.aid = a.id; } }
          else if (k === "dr" && r.dr) r.cr = 0; else if (k === "cr" && r.cr) r.dr = 0; }); },
      onDel: () => { D.dirtyF = true; tot(); } });
    function tot() { const dr = r2(G.rows.reduce((s, r) => s + (+r.dr || 0), 0)), cr = r2(G.rows.reduce((s, r) => s + (+r.cr || 0), 0)); K("dr").textContent = fmt(dr); K("cr").textContent = fmt(cr); K("dr").parentNode.classList.toggle("bad", dr !== cr); K("cr").parentNode.classList.toggle("bad", dr !== cr); return { dr, cr }; }
    Q('[data-a="flip"]').addEventListener("click", () => { G.rows.forEach(r => { const d = r.dr; r.dr = r.cr; r.cr = d; }); G.render(); D.dirtyF = true; });
    function reset() { D.id = 0; D.fx = []; D.dirtyF = false; D.title = title; HD.set("", today()); A.nextNo(kind).then(n => { if (!D.id) K("no").value = n; }); K("stmt").value = ""; K("notes").value = ""; K("cc").value = ""; G.set([]); }
    function fill(d) { const x = d.data; D.id = d.id; D.fx = x.fx || []; D.dirtyF = false; HD.set(d.no, x.date, x.br); K("stmt").value = x.stmt || ""; K("notes").value = x.notes || ""; K("cc").value = x.cc || ""; Promise.all((x.rows || []).map(r => ensure(r.t))).then(() => G.set((x.rows || []).map(r => Object.assign({}, r)))); D.title = title + " - " + d.no; tabOpen(D.key, D.title, view); }
    D.open = id => A.docs(kind, true).then(l => { const d = l.find(z => z.id === id); if (d) fill(d); });
    D.dirty = () => D.dirtyF && G.rows.length > 0;
    D.save = after => {
      const h = HD.get(), t = tot(), rows = G.rows.filter(r => r.name || r.dr || r.cr);
      if (!K("stmt").value.trim()) { say("بيان القيد حقل إجباري", "w"); K("stmt").focus(); return; }
      if (rows.length < 2) { say("القيد يحتاج سطرين على الأقل (مدين ودائن)", "w"); return; }
      const bad = rows.findIndex(r => !r.aid || !((+r.dr || 0) > 0 || (+r.cr || 0) > 0)); if (bad >= 0) { say("السطر " + (bad + 1) + ": اختر الحساب من القائمة وأدخل مدين أو دائن", "w"); return; }
      if (t.dr !== t.cr) { say("القيد غير متوازن: مدين " + fmt(t.dr) + " ≠ دائن " + fmt(t.cr), "w"); return; }
      const go = no => { const notes = "قيد رقم " + no + " - " + K("stmt").value.trim(); const fx = [], lg = [];
        rows.forEach(r => { const dr = +r.dr || 0, cr = +r.cr || 0;
          if (r.t === "tr") fx.push({ t: "tr", id: r.aid, d: r2(dr - cr), party: r.name, notes });
          else if (r.t === "cu") fx.push({ t: "cu", id: r.aid, d: r2(cr - dr) });
          else if (r.t === "su") fx.push({ t: "su", id: r.aid, d: r2(cr - dr) });
          else lg.push({ t: r.t, id: r.aid, d: r2(dr - cr), name: r.name, what: "قيد" }); });
        const data = { date: h.date, time: A.nowT(), br: h.br, stmt: K("stmt").value.trim(), cc: K("cc").value, notes: K("notes").value.trim(), rows, dr: t.dr, cr: t.cr, total: t.dr, fx, lg, user: (window.__USER_NAME || "ANOUER") };
        return A.post(fx, D.fx, { date: h.date, no: String(no), notes }).then(() => A.saveDoc(kind, { id: D.id, no, data }))
          .then(r => { A.invalidate(); A.snd("save"); say("تم حفظ القيد رقم " + (r.no || no), "s"); delete A.PC.cu; delete A.PC.su; delete A.AC.tr; if (after === "print") A.printDoc("قيد محاسبى", A.kvHtml([["الرقم", r.no || no], ["التاريخ", h.date], ["البيان", data.stmt], ["", ""]]), `<table><tr><th>النوع</th><th>الحساب</th><th>مدين</th><th>دائن</th><th>الشرح</th></tr>${rows.map(x => `<tr><td>${esc((JET.find(j => j[0] === x.t) || [])[1] || "")}</td><td>${esc(x.name)}</td><td>${fmt(x.dr)}</td><td>${fmt(x.cr)}</td><td>${esc(x.note || "")}</td></tr>`).join("")}<tr><th></th><th>الإجمالى</th><th>${fmt(t.dr)}</th><th>${fmt(t.cr)}</th><th></th></tr></table>`);
            const was = D.id; D.id = r.id; D.fx = fx; D.dirtyF = false; if (!was) reset(); else D.open(r.id); if (window.__AC_REFRESH) __AC_REFRESH(kind); }); };
      (h.no ? Promise.resolve(h.no) : A.nextNo(kind)).then(go).catch(e => { A.snd("err"); say("لم يتم الحفظ: " + (e.message || e), "e"); });
    };
    D.remove = () => { if (!D.id) return; A.ask("هل تريد حذف القيد رقم " + K("no").value + " ؟", () => A.post([], D.fx, { date: HD.get().date, no: K("no").value, notes: "حذف قيد" }).then(() => A.delDoc(kind, D.id)).then(() => { A.invalidate(); say("تم الحذف", "s"); reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); }).catch(e => say(e.message, "e"))); };
    page.addEventListener("click", e => { const b = e.target.closest("button[data-a]"); if (!b) return; const a = b.dataset.a;
      if (a === "file") A.fileMenu(b, D); else if (a === "save" || a === "save2") D.save(); else if (a === "savePrint" || a === "sp2") D.save("print"); else if (a === "close2") A.closeDoc(D); else if (a === "cols") A.fieldChooser(page, kind, b); });
    page.addEventListener("input", e => { if (e.target.dataset && e.target.dataset.k) D.dirtyF = true; });
    reset(); tabOpen(key, title, view); if (id) D.open(id);
    return D;
  }

  /* ================================================================== تحويل النقدية */
  function xferDoc(id) {
    if (id) { const ex = Object.values(A.DOCS).find(d => d.kind === "xfer" && d.id === id); if (ex) { tabOpen(ex.key, ex.title, ex.view); return ex; } }
    const kind = "xfer", view = "acxfer", key = view + ":" + A.nextSeq(), title = A.TITLE.xfer;
    const page = A.docPage(view, title, key);
    const D = A.DOCS[key] = { key, kind, view, page, title, id: 0, fx: [], dirtyF: false };
    page.innerHTML = A.toolbar([["spin", "", I.spin], ["save", "حفظ", I.save], ["savePrint", "حفظ و طباعة", I.print]], []) + A.header() + `<div class="ac-body ac-xf">
      <div class="ac-xrow"><div class="ac-xs or">بيانات<br>أساسية</div><div class="ac-xc"><div class="ac-fr v w"><span class="lb">البيان</span><span class="in"><input data-k="stmt" autocomplete="off"><i class="req">*</i></span></div>
        <div class="ac-fr v"><span class="lb">التحويل إلى</span>${A.selH("tobr", BR(), BR()[0])}</div></div><div class="ac-xic">${I.money}</div></div>
      <div class="ac-xrow"><div class="ac-xs bl tall">بيانات<br>التحويل</div><div class="ac-xc two">
        <div class="ac-xh"><div class="ac-fr v"><span class="lb">من حساب</span><span data-ap="from"></span></div><div class="ac-fr v"><span class="lb">المبلغ المدفوع</span><span class="ac-amt"><input data-k="paid" class="n" value="0.000"><span>DZD</span></span><i class="req">*</i></div></div>
        <div class="ac-xarr">${I.arrowL}</div>
        <div class="ac-xh"><div class="ac-fr v"><span class="lb">إلى حساب</span><span data-ap="to"></span></div><div class="ac-xr2"><div class="ac-fr v"><span class="lb">المبلغ المستلم</span><span class="ac-amt"><input data-k="recv" class="n" value="0.000"><span>DZD</span></span><i class="req">*</i></div><div class="ac-fr v"><span class="lb">المعامل</span><input data-k="rate" class="n sm" value="1"></div></div></div></div></div>
      <div class="ac-xrow"><div class="ac-xs bl">العمولة</div><div class="ac-xc two"><div class="ac-xh row"><div class="ac-fr v"><span class="lb">عمولة التحويل</span><input data-k="comm" class="n" value="0"></div><div class="ac-fr v"><span class="lb">الضريبة على العمولة</span><input data-k="ctax" class="n" value="0"></div></div><div></div>
        <label class="ac-chk"><input type="checkbox" data-k="fromTo"> خصم العمولة من المحول إليه</label></div></div>
      <div class="ac-xrow"><div class="ac-xs bl">أخرى</div><div class="ac-xc"><div class="ac-fr v"><span class="lb">رقم المرجع #</span><input data-k="ref" autocomplete="off"></div><div class="ac-fr v w"><span class="lb">الملاحظات</span><textarea data-k="notes" rows="2"></textarea></div></div></div>
      <div class="ac-btns c"><button type="button" class="ac-btn green" data-a="save2">حفظ</button><button type="button" class="ac-btn blue" data-a="sp2">حفظ و طباعة</button><button type="button" class="ac-btn blue" data-a="cancel">الغاء</button></div>
      <div class="ac-xfoot"><div class="ac-fr v"><span class="lb">حساب التحويل <i class="req">*</i></span>${A.selH("xacc", ["تحويلات النقدية بين الفروع", "تحويلات نقدية داخلية"], "تحويلات النقدية بين الفروع")}</div><div class="ac-fr v"><span class="lb">حساب عمولة التحويل <i class="req">*</i></span>${A.selH("cacc", ["مصروفات بنكية وعمولات"], "مصروفات بنكية وعمولات")}</div><div class="ac-fr v"><span class="lb">الضريبة <i class="req">*</i></span>${A.selH("taxk", TAXES.map(t => [t[0], t[1]]), "")}</div></div></div>`;
    const Q = s => page.querySelector(s), K = k => page.querySelector(`[data-k="${k}"]`);
    const HD = A.wireHeader(page, kind, D);
    const FA = A.accPicker(Q('[data-ap="from"]'), { type: "tr" }), TA = A.accPicker(Q('[data-ap="to"]'), { type: "tr" });
    const fmt3 = v => (+v || 0).toFixed(3);
    K("paid").addEventListener("change", () => { K("paid").value = fmt3(num(K("paid").value)); K("recv").value = fmt3(num(K("paid").value) * (num(K("rate").value) || 1)); D.dirtyF = true; });
    K("rate").addEventListener("change", () => { K("recv").value = fmt3(num(K("paid").value) * (num(K("rate").value) || 1)); });
    K("recv").addEventListener("change", () => { K("recv").value = fmt3(num(K("recv").value)); });
    function reset() { D.id = 0; D.fx = []; D.dirtyF = false; D.title = title; HD.set("", today()); A.nextNo(kind).then(n => { if (!D.id) K("no").value = n; }); ["stmt", "ref", "notes"].forEach(k => K(k).value = ""); K("paid").value = K("recv").value = "0.000"; K("comm").value = K("ctax").value = "0"; K("rate").value = "1"; K("fromTo").checked = false; setTimeout(() => K("stmt").focus(), 50); }
    function fill(d) { const x = d.data; D.id = d.id; D.fx = x.fx || []; D.dirtyF = false; HD.set(d.no, x.date, x.br); K("stmt").value = x.stmt || ""; K("ref").value = x.ref || ""; K("notes").value = x.notes || ""; K("paid").value = fmt3(x.paid); K("recv").value = fmt3(x.recv); K("comm").value = x.comm || 0; K("ctax").value = x.ctax || 0; K("fromTo").checked = !!x.fromTo; if (x.tobr) K("tobr").value = x.tobr;
      FA.set((x.from || {}).type, (x.from || {}).id); TA.set((x.to || {}).type, (x.to || {}).id); D.title = title + " - " + d.no; tabOpen(D.key, D.title, view); }
    D.open = id => A.docs(kind, true).then(l => { const d = l.find(z => z.id === id); if (d) fill(d); });
    D.dirty = () => D.dirtyF && num(K("paid").value) > 0;
    D.save = after => {
      const h = HD.get(), paid = r2(num(K("paid").value)), rec = r2(num(K("recv").value)), comm = r2(num(K("comm").value)), ctax = r2(num(K("ctax").value)), fromTo = K("fromTo").checked;
      if (!K("stmt").value.trim()) { say("البيان حقل إجباري", "w"); K("stmt").focus(); return; }
      if (!FA.acc || !TA.acc) { say("اختر حساب التحويل منه وإليه", "w"); return; }
      if (FA.acc.type === TA.acc.type && String(FA.acc.id) === String(TA.acc.id)) { say("لا يمكن التحويل إلى نفس الحساب", "w"); return; }
      if (!(paid > 0) || !(rec > 0)) { say("أدخل المبلغ المدفوع والمستلم", "w"); return; }
      const go = no => { const notes = "تحويل نقدية رقم " + no + " - " + K("stmt").value.trim(), cm = r2(comm + ctax);
        const f = A.accFx(FA.acc, -(paid + (fromTo ? 0 : cm)), { party: TA.acc.name, notes, what: title }), t = A.accFx(TA.acc, rec - (fromTo ? cm : 0), { party: FA.acc.name, notes, what: title });
        const fx = f.fx.concat(t.fx), lg = f.lg.concat(t.lg);
        const data = { date: h.date, time: A.nowT(), br: h.br, tobr: K("tobr").value, stmt: K("stmt").value.trim(), from: FA.acc, to: TA.acc, paid, recv: rec, rate: num(K("rate").value) || 1, comm, ctax, fromTo, ref: K("ref").value.trim(), notes: K("notes").value.trim(), xacc: K("xacc").value, cacc: K("cacc").value, total: paid, fx, lg, user: (window.__USER_NAME || "ANOUER") };
        return A.post(fx, D.fx, { date: h.date, no: String(no), notes }).then(() => A.saveDoc(kind, { id: D.id, no, data }))
          .then(r => { A.invalidate(); A.snd("save"); say("تم حفظ تحويل النقدية رقم " + (r.no || no), "s"); delete A.AC.tr; if (after === "print") A.printDoc(title, A.kvHtml([["الرقم", r.no || no], ["التاريخ", h.date], ["البيان", data.stmt], ["التحويل إلى", data.tobr], ["من حساب", FA.acc.name], ["المبلغ المدفوع", fmt(paid)], ["إلى حساب", TA.acc.name], ["المبلغ المستلم", fmt(rec)], ["عمولة التحويل", fmt(comm)], ["الضريبة على العمولة", fmt(ctax)]]));
            const was = D.id; D.id = r.id; D.fx = fx; D.dirtyF = false; FA.refresh(); TA.refresh(); if (!was) reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); }); };
      (h.no ? Promise.resolve(h.no) : A.nextNo(kind)).then(go).catch(e => { A.snd("err"); say("لم يتم الحفظ: " + (e.message || e), "e"); });
    };
    D.remove = () => { if (!D.id) return; A.ask("هل تريد حذف التحويل رقم " + K("no").value + " ؟", () => A.post([], D.fx, { date: HD.get().date, no: K("no").value }).then(() => A.delDoc(kind, D.id)).then(() => { A.invalidate(); say("تم الحذف", "s"); reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); })); };
    page.addEventListener("click", e => { const b = e.target.closest("button[data-a]"); if (!b) return; const a = b.dataset.a;
      if (a === "file") A.fileMenu(b, D); else if (a === "save" || a === "save2") D.save(); else if (a === "savePrint" || a === "sp2") D.save("print"); else if (a === "cancel") A.closeDoc(D); else if (a === "spin") { FA.refresh(); TA.refresh(); } });
    page.addEventListener("input", e => { if (e.target.dataset && e.target.dataset.k) D.dirtyF = true; });
    reset(); tabOpen(key, title, view); if (id) D.open(id);
    return D;
  }
  function BR() { return H.BR || ["الفرع الرئيسي"]; }

  /* ================================================================== سداد الضرائب / تسويات الضرائب (DEXEF ONE + لمسة 2026)
     • اسم الحساب: شجرة الحسابات الحيّة (الخصوم: 2132 ضريبة القيمة المضافة ، 2133 مصلحة الضرائب العامة ، … ، 214 حسابات دائنة أخرى ، 22 …)
     • المبلغ: حاسبة ▾ مثل DEXEF ، الفترة: اختصارات سريعة ، التسويات: مدين / دائن (اختيار إلزامي مثل DEXEF)
     • «ملخص الفترة الضريبية»: ضريبة المبيعات − ضريبة المشتريات − المسدد ± التسويات = المستحق ، وزر «استخدام المبلغ» */
  const VAT_NO = "2132", VAT_NAME = "ضريبة القيمة المضافة";
  const TX_OLD = { vat19: [VAT_NO, VAT_NAME], vat9: [VAT_NO, VAT_NAME], stamp: ["2133", "مصلحة الضرائب العامة"] };
  const ymdL = d => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  function txPeriod(k) {
    const d = new Date(), y = d.getFullYear(), m = d.getMonth(), q = Math.floor(m / 3);
    if (k === "cm") return [ymdL(new Date(y, m, 1)), ymdL(new Date(y, m + 1, 0))];
    if (k === "pm") return [ymdL(new Date(y, m - 1, 1)), ymdL(new Date(y, m, 0))];
    if (k === "pq") return [ymdL(new Date(y, (q - 1) * 3, 1)), ymdL(new Date(y, q * 3, 0))];
    if (k === "cy") return [y + "-01-01", y + "-12-31"];
    return null;
  }
  /* ملخص ضريبة الفترة (يُستعمل أيضاً في تقرير ضريبة القيمة المضافة) */
  function taxSummary(f1, f2, accNo, exceptId, kindNow) {
    const R = window.ANOUER_REPORTS, isVat = !accNo || accNo === VAT_NO;
    const inv = isVat && R && R.data ? R.data(f1, f2).then(D => D.inv).catch(() => []) : Promise.resolve([]);
    const ov = d => d.data && !(d.data.f2 < f1 || d.data.f1 > f2) && String(d.data.taccNo || (TX_OLD[d.data.tacc] || [])[0] || VAT_NO) === String(accNo || VAT_NO);
    return Promise.all([inv, A.docs("taxp").catch(() => []), A.docs("taxs").catch(() => [])]).then(([L, P, S]) => {
      const sum = (t, f) => r2(L.filter(x => x.t === t).reduce((a, x) => a + f(x), 0));
      const sTax = r2(sum("Sale", x => +x.tax || 0) - sum("SaleReturn", x => +x.tax || 0));
      const pTax = r2(sum("Purchase", x => +x.tax || 0) - sum("PurchaseReturn", x => +x.tax || 0));
      const notMe = (d, k) => !(k === kindNow && d.id === exceptId);
      const paid = r2(P.filter(d => ov(d) && notMe(d, "taxp")).reduce((a, d) => a + (+d.data.amt || 0), 0));
      const adjDr = r2(S.filter(d => ov(d) && notMe(d, "taxs") && d.data.dc !== "cr").reduce((a, d) => a + (+d.data.amt || 0), 0));
      const adjCr = r2(S.filter(d => ov(d) && notMe(d, "taxs") && d.data.dc === "cr").reduce((a, d) => a + (+d.data.amt || 0), 0));
      return { isVat, sTax, pTax, gross: r2(sTax - pTax), paid, adjDr, adjCr, due: r2(sTax - pTax - paid - adjDr + adjCr), nS: L.filter(x => x.t === "Sale" || x.t === "SaleReturn").length, nP: L.filter(x => x.t === "Purchase" || x.t === "PurchaseReturn").length };
    });
  }
  const TXI = {
    sum: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2z"/><path d="M9 8h6M9 12h6M9 16h3"/></svg>',
    use: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12H5M11 6l-6 6 6 6"/></svg>',
    rpt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>'
  };
  function taxDoc(kind, id) {
    if (id) { const ex = Object.values(A.DOCS).find(d => d.kind === kind && d.id === id); if (ex) { tabOpen(ex.key, ex.title, ex.view); return ex; } }
    const adj = kind === "taxs", view = "ac" + kind, key = view + ":" + A.nextSeq(), title = A.TITLE[kind];
    const page = A.docPage(view, title, key);
    const D = A.DOCS[key] = { key, kind, view, page, title, id: 0, fx: [], dirtyF: false };
    page.innerHTML = A.toolbar([["save", "حفظ", I.save], ["savePrint", "حفظ و طباعة", I.print]], [["cols", "اختيار الحقول", I.cols]]) + A.header() + `<div class="ac-body ac-tx tx26">
      <div class="ac-xrow"><div class="ac-xs or">بيانات<br>أساسية</div><div class="ac-tc">
        <div class="ac-fr"><span class="lb">اسم الحساب</span><span class="tx-acc" data-tp="1"></span><b class="tx-ok" data-okacc title="حساب صحيح">✓</b><i class="req">*</i></div>
        <div class="ac-fr"><span class="lb">المبلغ</span><span class="ac-cb n tx-amt"><input data-k="amt" inputmode="decimal" autocomplete="off"><button type="button" class="dd" data-a="calc" tabindex="-1" title="الحاسبة (Alt+↓)">⌄</button></span><i class="req">*</i>${adj ? '<span class="tx-dc"><label class="ac-rd"><input type="radio" name="dc' + key + '" value="dr"> مدين</label><label class="ac-rd"><input type="radio" name="dc' + key + '" value="cr"> دائن</label></span>' : ""}</div>
        <div class="ac-fr"><span class="lb">عن الفترة بين</span><input type="date" data-k="f1"><input type="date" data-k="f2"><i class="req">*</i></div>
        <div class="tx-pq">${[["cm", "هذا الشهر"], ["pm", "الشهر الماضي"], ["pq", "الربع الماضي"], ["cy", "هذه السنة"]].map(x => `<button type="button" data-per="${x[0]}">${x[1]}</button>`).join("")}</div></div>
        <div class="ac-tref"><div class="ac-fr v"><span class="lb">رقم المرجع #</span><input data-k="ref" class="box"></div>
          <div class="tx-card" data-sum><div class="tx-ch">${TXI.sum}<b>ملخص الفترة الضريبية</b><span data-per-l></span></div><div class="tx-cb" data-sb><div class="tx-ld"><i></i>جارٍ الحساب …</div></div></div></div></div>
      <div class="ac-xrow"><div class="ac-xs bl tall">التفاصيل</div><div class="ac-tc">
        <div class="ac-fr"><span class="lb">الدفع من</span><span data-ap="1"></span></div>
        <div class="ac-fr"><span class="lb">العمله</span><span class="ac-cur">${A.selH("cur", ["DZD"], "DZD")}<span class="spin"><input data-k="rate" value="1"><i>⌃</i><i>⌄</i></span></span><i class="req">*</i></div>
        <div class="ac-fr"><span class="lb">الملاحظات</span><textarea data-k="notes" rows="3"></textarea></div></div></div>
      <div class="ac-btns t"><button type="button" class="ac-btn green" data-a="save2">حفظ</button><button type="button" class="ac-btn blue" data-a="sp2">حفظ و طباعة</button><button type="button" class="ac-btn blue" data-a="close2">اغلاق</button></div></div>`;
    const Q = s => page.querySelector(s), K = k => page.querySelector(`[data-k="${k}"]`);
    const HD = A.wireHeader(page, kind, D);
    const AP = A.accPicker(Q("[data-ap]"), { type: "tr" });
    const TP = A.treePicker(Q("[data-tp]"), { key: "tacc", root: "2", hide: ["21", "213"], value: VAT_NAME, ph: "اختر حساب الضريبة", onChange: () => { D.dirtyF = true; okAcc(); sumSoon(); } });
    const accNo = () => (TP.node && TP.node.no) || (TP.get() === VAT_NAME ? VAT_NO : "");
    const okAcc = () => { const o = Q("[data-okacc]"); if (o) o.style.visibility = TP.get() ? "" : "hidden"; };
    const dc = () => { const r = page.querySelector('input[type=radio]:checked'); return r ? r.value : ""; };
    /* ---------- الملخص الذكي */
    let sumT = 0, sumSeq = 0;
    const sumSoon = () => { clearTimeout(sumT); sumT = setTimeout(drawSum, 250); };
    function drawSum() {
      const box = Q("[data-sb]"), f1 = K("f1").value, f2 = K("f2").value, no = accNo(), seq = ++sumSeq;
      const pl = Q("[data-per-l]"); if (pl) pl.textContent = f1 && f2 ? f1 + " ← " + f2 : "";
      if (!f1 || !f2 || f1 > f2) { box.innerHTML = '<div class="tx-em">حدّد الفترة لعرض الملخص</div>'; return; }
      box.innerHTML = '<div class="tx-ld"><i></i>جارٍ الحساب …</div>';
      taxSummary(f1, f2, no, D.id, kind).then(S => {
        if (seq !== sumSeq) return;
        const row = (t, v, cls, hint) => `<div class="tx-r ${cls || ""}"${hint ? ` title="${esc(hint)}"` : ""}><span>${t}</span><b>${fmt(v)}</b></div>`;
        const due = S.due, st = due > 0.009 ? "due" : due < -0.009 ? "cred" : "zero";
        box.innerHTML = (S.isVat ? row("ضريبة المبيعات (المحصّلة)", S.sTax, "", S.nS + " فاتورة مبيعات / مرتجع") + row("− ضريبة المشتريات (القابلة للخصم)", -S.pTax, "", S.nP + " فاتورة مشتريات / مرتجع") + row("الضريبة عن الفترة", S.gross, "sub") : `<div class="tx-em sm">حساب «${esc(TP.get())}»: الملخص من المستندات المسجلة فقط</div>`)
          + row("− المسدد عن نفس الفترة", -S.paid) + (S.adjDr || S.adjCr ? row("± التسويات (مدين / دائن)", r2(S.adjCr - S.adjDr)) : "")
          + `<div class="tx-due ${st}"><span>${st === "cred" ? "رصيد دائن (مسترد)" : st === "zero" ? "لا يوجد مستحق ✓" : "المستحق للسداد"}</span><b>${fmt(Math.abs(due))} <small>DZD</small></b></div>
          <div class="tx-act">${st === "due" && !adj ? `<button type="button" class="tx-use" data-a="use">${TXI.use}استخدام المبلغ</button>` : ""}${S.isVat ? `<button type="button" class="tx-rp" data-a="vat">${TXI.rpt}تقرير ضريبة القيمة المضافة</button>` : ""}</div>`;
        D.sugg = st === "due" ? due : 0;
      }).catch(() => { if (seq === sumSeq) box.innerHTML = '<div class="tx-em">تعذّر حساب الملخص</div>'; });
    }
    function reset() { D.id = 0; D.fx = []; D.dirtyF = false; D.title = title; HD.set("", today()); A.nextNo(kind).then(n => { if (!D.id) K("no").value = n; }); ["amt", "ref", "notes"].forEach(k => K(k).value = ""); const p = txPeriod("pm"); K("f1").value = p[0]; K("f2").value = p[1]; TP.set(VAT_NAME); okAcc(); page.querySelectorAll("input[type=radio]").forEach(r => r.checked = false); sumSoon(); }
    function fill(d) { const x = d.data; D.id = d.id; D.fx = x.fx || []; D.dirtyF = false; HD.set(d.no, x.date, x.br); TP.set(x.taccName || (TX_OLD[x.tacc] || [])[1] || VAT_NAME); okAcc(); K("amt").value = x.amt || ""; K("ref").value = x.ref || ""; K("notes").value = x.notes || ""; K("f1").value = x.f1 || ""; K("f2").value = x.f2 || "";
      if (adj) { const r = page.querySelector(`input[type=radio][value="${x.dc || "dr"}"]`); if (r) r.checked = true; } AP.set((x.acc || {}).type, (x.acc || {}).id); D.title = title + " - " + d.no; tabOpen(D.key, D.title, view); sumSoon(); }
    D.open = id => A.docs(kind, true).then(l => { const d = l.find(z => z.id === id); if (d) fill(d); });
    D.dirty = () => D.dirtyF && num(K("amt").value) > 0;
    D.save = after => {
      const h = HD.get(), amt = r2(num(K("amt").value)), tname = TP.get().trim();
      if (!tname) { say("اختر اسم الحساب", "w"); TP.input.focus(); return; }
      if (!(amt > 0)) { say("أدخل المبلغ", "w"); K("amt").focus(); return; }
      if (adj && !dc()) { say("اختر مدين أو دائن", "w"); return; }
      if (!K("f1").value || !K("f2").value) { say("أدخل الفترة", "w"); return; }
      if (K("f1").value > K("f2").value) { say("بداية الفترة بعد نهايتها", "w"); return; }
      if (!AP.acc) { say("اختر حساب الدفع", "w"); return; }
      const sign = adj && dc() === "cr" ? 1 : -1, tno = accNo();
      const go = no => { const notes = title + " رقم " + no + " (" + K("f1").value + " - " + K("f2").value + ")";
        const af = A.accFx(AP.acc, sign * amt, { party: tname, notes, what: title });
        const lg = af.lg.concat([{ t: "taxa", id: +tno || 1, d: r2(-sign * amt), name: tname, what: title }]);
        const data = { date: h.date, time: A.nowT(), br: h.br, tacc: tno || "vat19", taccNo: tno, taccName: tname, amt, dc: adj ? dc() : "dr", f1: K("f1").value, f2: K("f2").value, acc: AP.acc, ref: K("ref").value.trim(), notes: K("notes").value.trim(), total: amt, cur: "DZD", rate: num(K("rate").value) || 1, fx: af.fx, lg, user: (window.__USER_NAME || "ANOUER"), mod: A.nowT ? h.date + " " + A.nowT() : "" };
        if (D.id) data.modBy = window.__USER_NAME || "ANOUER";
        return A.post(af.fx, D.fx, { date: h.date, no: String(no), notes }).then(() => A.saveDoc(kind, { id: D.id, no, data }))
          .then(r => { A.invalidate(); A.snd("save"); say("تم حفظ " + title + " رقم " + (r.no || no), "s"); delete A.AC.tr; if (after === "print") printTax(kind, { no: r.no || no, data });
            const was = D.id; D.id = r.id; D.fx = af.fx; D.dirtyF = false; AP.refresh(); if (!was) reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); }); };
      (h.no ? Promise.resolve(h.no) : A.nextNo(kind)).then(go).catch(e => { A.snd("err"); say("لم يتم الحفظ: " + (e.message || e), "e"); });
    };
    D.remove = () => { if (!D.id) return; A.ask("هل تريد حذف المستند رقم " + K("no").value + " ؟", () => A.post([], D.fx, { date: HD.get().date, no: K("no").value }).then(() => A.delDoc(kind, D.id)).then(() => { A.invalidate(); say("تم الحذف", "s"); reset(); if (window.__AC_REFRESH) __AC_REFRESH(kind); })); };
    const calc = () => { const b = Q('[data-a="calc"]'); if (window.ANOUER_CALC) ANOUER_CALC.open(b.parentElement, num(K("amt").value) || 0, v => { K("amt").value = r2(v) || ""; D.dirtyF = true; K("amt").focus(); }, { title: "المبلغ" }); };
    page.addEventListener("click", e => { const b = e.target.closest("button[data-a],button[data-per]"); if (!b) return;
      if (b.dataset.per) { const p = txPeriod(b.dataset.per); K("f1").value = p[0]; K("f2").value = p[1]; D.dirtyF = true; page.querySelectorAll(".tx-pq button").forEach(x => x.classList.toggle("on", x === b)); sumSoon(); return; }
      const a = b.dataset.a;
      if (a === "file") A.fileMenu(b, D); else if (a === "save" || a === "save2") D.save(); else if (a === "savePrint" || a === "sp2") D.save("print"); else if (a === "close2") A.closeDoc(D); else if (a === "cols") A.fieldChooser(page, kind, b);
      else if (a === "calc") calc();
      else if (a === "use") { if (D.sugg > 0) { K("amt").value = r2(D.sugg); D.dirtyF = true; K("amt").classList.add("tx-flash"); setTimeout(() => K("amt").classList.remove("tx-flash"), 900); A.snd && A.snd("click"); } }
      else if (a === "vat") openVat(K("f1").value, K("f2").value); });
    page.addEventListener("keydown", e => { if (e.target === K("amt") && e.altKey && e.key === "ArrowDown") { e.preventDefault(); calc(); } });
    page.addEventListener("input", e => { if (e.target.dataset && e.target.dataset.k) D.dirtyF = true; });
    page.addEventListener("change", e => { const k = e.target.dataset && e.target.dataset.k; if (k === "f1" || k === "f2") { page.querySelectorAll(".tx-pq button").forEach(x => x.classList.remove("on")); sumSoon(); } if (e.target.type === "radio") D.dirtyF = true; });
    reset(); tabOpen(key, title, view); if (id) D.open(id);
    return D;
  }
  /* طباعة إيصال سداد / تسوية ضريبية (من الشاشة أو من المراجعة) */
  function printTax(kind, d) {
    const x = d.data || {}, adj = kind === "taxs";
    A.printDoc(A.TITLE[kind] + " رقم " + d.no, A.kvHtml([["الرقم", d.no], ["التاريخ", x.date], ["اسم الحساب", (x.taccNo ? x.taccNo + " - " : "") + (x.taccName || "")], ["المبلغ", fmt(+x.amt || 0) + " DZD" + (adj ? (x.dc === "cr" ? " (دائن)" : " (مدين)") : "")], ["عن الفترة", (x.f1 || "") + " ← " + (x.f2 || "")], [adj ? "الحساب المقابل" : "الدفع من", (x.acc || {}).name || ""], ["رقم المرجع", x.ref || ""], ["الملاحظات", x.notes || ""], ["بواسطة", x.user || ""]]));
  }
  /* طباعة قيد التعامل */
  function printTaxJe(kind, d) {
    const x = d.data || {}, amt = r2(+x.amt || 0), acc = (x.acc || {}).name || "الخزينة", tn = (x.taccNo ? x.taccNo + " - " : "") + (x.taccName || "");
    const crSide = kind === "taxs" && x.dc === "cr";
    const L = crSide ? [[acc, amt, 0], [tn, 0, amt]] : [[tn, amt, 0], [acc, 0, amt]];
    A.printDoc("قيد " + A.TITLE[kind] + " رقم " + d.no, A.kvHtml([["رقم القيد", d.no], ["التاريخ", x.date], ["البيان", A.TITLE[kind] + " رقم " + d.no + " (" + (x.f1 || "") + " - " + (x.f2 || "") + ")"], ["بواسطة", x.user || ""]]),
      `<table><tr><th>الحساب</th><th>مدين</th><th>دائن</th></tr>${L.map(z => `<tr><td>${esc(z[0])}</td><td>${z[1] ? fmt(z[1]) : ""}</td><td>${z[2] ? fmt(z[2]) : ""}</td></tr>`).join("")}<tr><th>الاجمالي</th><th>${fmt(amt)}</th><th>${fmt(amt)}</th></tr></table>`);
  }
  function openVat(f1, f2) { const R = window.ANOUER_REPORTS; if (R && R.vat) R.vat(f1, f2); else if (R && R.run) R.run(482); }

  window.ANOUER_ACDOCS = { exp: id => itemsDoc("exp", id), rev: id => itemsDoc("rev", id), je: id => jeDoc(id), xfer: id => xferDoc(id), taxp: id => taxDoc("taxp", id), taxs: id => taxDoc("taxs", id), LGrid, TAXES, JET, printTax, printTaxJe, taxSummary, txPeriod };
})();
