/* ANOUER — تعريفات شاشات «الخصائص» (مطابقة DEXEF ONE) — الجزء 1: إعدادات النظام + الفواتير */
(function () {
  "use strict";
  const P = window.__PP; if (!P) return;
  const { TILES, IC, esc, T, clone, today, get, put, tg, sel, num, txt, optHTML, rowHTML, fHTML, collect, wire, dlg, ask, gridHTML, wireFilter, listTab, formTab } = P;
  const YN = ["نعم", "لا"];

  // ==================================================================== 1) إعدادات النظام
  const PERIODS = ["الكل", "العام السابق", "العام السابق الى الان", "السنة الحالية", "ربع السنة الأول", "ربع السنة الثاني", "ربع السنة الثالث", "ربع السنة الأخير", "الثلاث شهور السابقة", "الشهرين السابقين", "الشهر السابق", "الشهر الحالى", "الاسبوع الحالي", "اليوم"];
  const CUR_NAMES = [["DZD", "دينار جزائرى"], ["EUR", "يورو"], ["USD", "دولار أمريكى"], ["GBP", "جنيه إسترلينى"], ["SAR", "ريال سعودى"], ["AED", "درهم إماراتى"], ["MAD", "درهم مغربى"], ["TND", "دينار تونسى"], ["EGP", "جنيه مصرى"], ["LYD", "دينار ليبى"], ["QAR", "ريال قطرى"], ["KWD", "دينار كويتى"], ["TRY", "ليرة تركية"], ["CNY", "يوان صينى"], ["CHF", "فرنك سويسرى"], ["CAD", "دولار كندى"], ["JPY", "ين يابانى"]];
  const addDays = (d, n) => { const x = new Date(d + "T00:00:00"); if (isNaN(x)) return ""; x.setDate(x.getDate() + n); return x.getFullYear() + "-" + String(x.getMonth() + 1).padStart(2, "0") + "-" + String(x.getDate()).padStart(2, "0"); };

  /* ثوابت الحسابات: [المجموعة, [[البند, الحساب الافتراضي]]] */
  const ACC_GROUPS = [
    ["بيانات اساسية", [["رأس المال", "رأس المال"], ["الأرصدة الافتتاحية", "الأرصدة الافتتاحية"], ["تحويل النقدية بين الفروع", "تحويلات النقدية بين الفروع"]]],
    ["حسابات النقدية و البنوك", [["الخزينة", "الخزينة"], ["البنوك", "البنوك"], ["عهد الموظفين النقدية", "عهد الموظفين"], ["أوراق القبض", "أوراق القبض"], ["أوراق الدفع", "أوراق الدفع"], ["شيكات تحت التحصيل", "أوراق تحت التحصيل"], ["الاشعارات البنكية", "مصروفات بنكية"], ["الاعتمادات المستندية", "اعتمادات مستنديه لشراء أصول ثابتة"], ["الفيزا", "بطاقات إئتمان"], ["عمولات الفيزا", "مصروفات بنكية وعمولات"], ["حافظة الشيكات المرتجعة", ""], ["إيرادات مستحقة التحصيل", ""], ["كوبونات الخصم", ""]]],
    ["العملاء و الموردين", [["العملاء", "العملاء"], ["الموردين", "موردون"], ["الزمم", "الموزعون"], ["جهات أخرى", "الوكلاء"], ["الاشعارات", ""], ["التسويات المالية", "فروق تسويات مالية"], ["ديون معدومة", ""], ["نسبة مبيعات بضاعة الأمانة", "مبيعات بضاعة بغرض الأمانة"], ["حساب أرباح غير محققة", ""], ["حساب أرباح محققة", ""], ["تأمينات من الغير", ""]]],
    ["الاصناف", [["مخزون البضاعة", "مخزون البضاعة"], ["المبيعات", "مبيعات بضائع مشتراة"], ["مردودات المبيعات", "مرتجعات مبيعات (مدين)"], ["مسموحات المبيعات", "مسموحات المبيعات (مدين)"], ["تبرعات و إعانات", ""], ["هدايا وعينات تسويقية", ""], ["هالك المخزون", "تألف إنتاج تالف / بضائع مشتراة (فى مرحلة البيع)"], ["التسويات الجردية", "فروق تسويات جردية"], ["مخزون بضاعة المنتج التام", "مخزون إنتاج تام"], ["تكلفة البضاعة المباعة", "تكلفة البضاعة المباعة"], ["تحويلات المخازن", ""]]],
    ["شئون العاملين", [["المرتبات", "أجور نقدية"], ["المرتبات المستحقة", "مرتبات مستحقة السداد"], ["السلف", "سلف الموظفين"], ["الحوافز", ""], ["المصروفات المستحقة على الموظف من الخدمات", "مستحقات سداد الخدمات الالكترونية"], ["المصروفات المدفوعة من الشركة للخدمات", "خدمات الجهات الحكومية والمؤسسات"], ["نسبة توزيع المناديب", "اجور نسب المناديب"], ["حساب وسيط نسبة المناديب", "مرتبات مستحقة السداد"], ["ايرادات التوصيل", ""]]],
    ["الضرائب و التأمينات", [["الضرائب", "ضريبة القيمة المضافة"], ["الضريبة الاضافية", ""], ["ضريبة كسب العمل", "مصلحة الضرائب العامة"], ["التأمينات الاجتماعية", "جارى مصلحة التأمينات الاجتماعية"], ["ضريبة الخصم و الاضافة", "ضريبة الخصم و الاضافة"]]],
    ["الخصومات", [["خصم مكتسب", "خصم مكتسب"], ["خصم مسموح به", "خصم مسموح به (مدين)"], ["خصم كمية مكتسب", "خصم كميه مكتسب"], ["خصم كمية مسموح به", "خصم كمية مسموح به (مدين)"]]],
    ["الاصول الثابتة", [["حساب الاصل", ""], ["مخصص الاهلاك", "إهلاك الأصول الثابتة"], ["مصروفات الصيانة", "مصروفات صيانة واصلاح"], ["مجمع الاهلاك", ""], ["ارباح رأسمالية", "أرباح رأسمالية"], ["خسائر رأسمالية", "خسائر رأسمالية"], ["مصروفات الاهلاك", ""], ["أصول مستبعدة", ""], ["فائض إعادة التقييم", ""]]],
    ["فروق العملات", [["أرباح فروق عملة", "أرباح فروق العملة"], ["خسائر فروق عملة", "خسائر فروق العملة"], ["فروق تقريب الكسور العشرية", "فروق تقريب الكسور العشرية"]]],
    ["إغلاق اليومية", [["العجز في إغلاق اليومية", "عجز فى إغلاق اليومية"], ["إيرادات الفائض في إغلاقات اليومية", "فائض إغلاق اليومية"]]]
  ];
  const ITEM_ACC_GROUPS = [
    ["مخزون", [["مخزون البضاعة", "مخزون البضاعة"], ["المبيعات", "مبيعات بضائع مشتراة"], ["مرتجع المبيعات", "مرتجعات مبيعات (مدين)"], ["تكلفة البضاعة المباعة", "تكلفة البضاعة المباعة"]]],
    ["منتج تام", [["مخزون البضاعة", "مخزون البضاعة"], ["المبيعات", "مبيعات بضائع مشتراة"], ["مرتجع المبيعات", "مرتجعات مبيعات (مدين)"], ["تكلفة البضاعة المباعة", "تكلفة البضاعة المباعة"], ["مخزون تحت التشغيل", "مخزون إنتاج غير تام"]]],
    ["خدمة", [["المشتريات", "خدمات مشتراة"], ["المبيعات", "خدمات مباعة"], ["مرتجع المبيعات", "خدمات مباعة"]]],
    ["بضاعة أمانة", [["مخزون البضاعة", "إيرادات محصلة مقدما"], ["المبيعات", "مبيعات بضاعة بغرض الأمانة"], ["مرتجع المبيعات", "مرتجعات مبيعات بغرض الأمانة (مدين)"], ["تكلفة البضاعة المباعة", "تكلفة البضاعة المباعة"]]]
  ];
  /* شاشة ثوابت: مجموعات قابلة للطي، البند يميناً والحساب يساراً (يتحول لحقل بحث عند الضغط) */
  function accTab(id, t, groups, intro) {
    return {
      id, t, render(host, ctx) {
        const k = ctx.tile + "." + id, v = get(k, {});
        const sc = window.__PP && __PP.accScope ? __PP.accScope() : null;
        const chip = sc && ctx.tile === "sys" ? `<div class="pp-accsc" style="display:inline-flex;align-items:center;gap:6px;margin:0 0 10px;padding:4px 12px;border-radius:999px;background:#eef4ff;color:#1d4ed8;font-size:11.5px;font-weight:600">${sc.by === "الجهاز" ? "💻 هذه الثوابت خاصة بهذا الجهاز" : "👤 هذه الثوابت خاصة بالمستخدم الحالي"} <span style="color:#64748b;font-weight:400">— «خصائص عامة ← طريقة قراءة الحسابات الافتراضية»</span></div>` : "";
        host.innerHTML = `${chip}${intro ? `<div class="pp-acc-in">${esc(intro)}</div>` : ""}<div class="pp-acc">${groups.map((g, gi) => `<div class="pp-ag" data-g="${gi}"><div class="pp-agh"><span>${esc(g[0])}</span><i>⌃</i></div><div class="pp-agb">${g[1].map((r, ri) => {
          const kk = gi + "." + ri, val = v[kk] !== undefined ? v[kk] : r[1];
          return `<div class="pp-ar"><span class="l">${esc(r[0])}</span><span class="v" data-k="${kk}" tabindex="0">${esc(val)}</span></div>`;
        }).join("")}</div></div>`).join("")}</div>`;
        host.addEventListener("click", e => {
          const h = e.target.closest(".pp-agh"); if (h) { h.parentNode.classList.toggle("col"); return; }
          const s = e.target.closest(".pp-ar .v"); if (!s || s.querySelector("input")) return;
          const old = s.textContent; s.innerHTML = txt(old, null, 0, { list: P.accList() }); const i = s.firstChild; i.style.width = "100%"; i.focus(); i.select();
          const done = () => { s.textContent = i.value.trim(); };
          i.addEventListener("blur", done, { once: true });
          i.addEventListener("keydown", ev => { if (ev.key === "Enter") { ev.preventDefault(); i.blur(); } else if (ev.key === "Escape") { ev.stopPropagation(); i.value = old; i.blur(); } });
        });
        host.addEventListener("keydown", e => { const s = e.target.closest && e.target.closest(".pp-ar .v"); if (s && e.key === "Enter" && !s.querySelector("input")) { e.preventDefault(); s.click(); } });
        return () => { const o = {}; host.querySelectorAll(".pp-ar .v").forEach(s => { const i = s.querySelector("input"); o[s.dataset.k] = (i ? i.value : s.textContent).trim(); }); return put(k, o); };
      }
    };
  }

  const COUNTRIES = [["الجزائر", "دينار جزائرى", "سنتيم", "DZD"], ["أفغانستان", "أفغانى", "", "AFN"], ["أنغولا", "كوانزا أنغولي", "العملات المعدنية المركزية", "AOA"], ["الأرجنتين", "بيزو أرجنتيني", "العملات المعدنية المركزية", "ARS"], ["أرمينيا", "درام أرميني", "لمى", "AMD"], ["أستراليا", "دولار أسترالي", "سنت", "AUD"], ["أذربيجان", "مانات", "Qapik", "AZN"], ["البحرين", "دينار بحريني", "فلس", "BHD"], ["بنغلاديش", "تاكا بنغلاديشي", "بيزة", "BDT"], ["بلجيكا", "يورو", "سنت", "EUR"], ["البرازيل", "ريال برازيلي", "سنتافو", "BRL"], ["كندا", "دولار كندي", "سنت", "CAD"], ["الصين", "يوان صيني", "فين", "CNY"], ["مصر", "جنيه مصرى", "قرش", "EGP"], ["فرنسا", "يورو", "سنت", "EUR"], ["ألمانيا", "يورو", "سنت", "EUR"], ["الهند", "روبية هندية", "بيزة", "INR"], ["إيطاليا", "يورو", "سنت", "EUR"], ["اليابان", "ين يابانى", "سين", "JPY"], ["الأردن", "دينار أردنى", "فلس", "JOD"], ["الكويت", "دينار كويتى", "فلس", "KWD"], ["لبنان", "ليرة لبنانية", "قرش", "LBP"], ["ليبيا", "دينار ليبى", "درهم", "LYD"], ["موريتانيا", "أوقية موريتانية", "خمس", "MRU"], ["المغرب", "درهم مغربى", "سنتيم", "MAD"], ["عمان", "ريال عمانى", "بيسة", "OMR"], ["فلسطين", "شيكل", "أغورة", "ILS"], ["قطر", "ريال قطرى", "درهم", "QAR"], ["المملكة العربية السعودية", "ريال سعودى", "هللة", "SAR"], ["السودان", "جنيه سودانى", "قرش", "SDG"], ["إسبانيا", "يورو", "سنت", "EUR"], ["سويسرا", "فرنك سويسرى", "سنتيم", "CHF"], ["سوريا", "ليرة سورية", "قرش", "SYP"], ["تونس", "دينار تونسى", "مليم", "TND"], ["تركيا", "ليرة تركية", "قرش", "TRY"], ["الإمارات العربية المتحدة", "درهم إماراتى", "فلس", "AED"], ["المملكة المتحدة", "جنيه إسترلينى", "بنس", "GBP"], ["الولايات المتحدة", "دولار أمريكى", "سنت", "USD"], ["اليمن", "ريال يمنى", "فلس", "YER"], ["العراق", "دينار عراقى", "فلس", "IQD"], ["مالي", "فرنك غرب أفريقي", "سنتيم", "XOF"], ["النيجر", "فرنك غرب أفريقي", "سنتيم", "XOF"]]
    .map(r => ({ name: r[0], cur: r[1], sub: r[2], code: r[3], active: true }));
  const ACTS = [["0111", "زراعة الحبوب والمحاصيل ( فيما عدا الارز ) والبقوليات والحبوب الزيتية"], ["0112", "زراعة الارز"], ["0113", "زراعة الخضر والبطيخ والجذور والدرنات"], ["0114", "زراعة قصب السكر"], ["0115", "زراعة التبغ"], ["0116", "زراعة المحاصيل ذات الالياف"], ["0119", "زراعة المحاصيل غير المعمرة الاخرى"], ["0121", "زراعة الكروم"], ["0122", "زراعة الفواكه الاستوائية وشبه الاستوائية"], ["0123", "زراعة الموالح"], ["0124", "زراعة الفواكه ذات النواة والناتجة عن انواع النخيل"], ["0125", "زراعة اشجار وشجيرات الفواكه والمكسرات الاخرى"], ["0126", "زراعة الفواكه الزيتية"], ["0127", "زراعة المحاصيل التي تستخرج منها المشروبات"], ["0128", "زراعة محاصيل التوابل والعطريات والادوية والعقاقير الصيدلانية"], ["0129", "زراعة المحاصيل المعمرة الاخرى"], ["0130", "اكثار المحاصيل"], ["0141", "تربية الماشية والجاموس"], ["0145", "تربية الخنازير"], ["0146", "تربية الدواجن"], ["0311", "صيد الاسماك البحرية"], ["1010", "تجهيز وحفظ اللحوم"], ["1050", "صناعة منتجات الالبان"], ["1071", "صناعة منتجات المخابز"], ["1104", "صناعة المشروبات غير الكحولية والمياه المعدنية"], ["1410", "صناعة الملابس عدا الملابس المصنوعة من الفراء"], ["1520", "صناعة الاحذية"], ["2100", "صناعة المستحضرات الصيدلانية"], ["4100", "تشييد المباني"], ["4520", "صيانة واصلاح المركبات ذات المحركات"], ["4610", "البيع بالجملة على اساس رسم او عقد"], ["4630", "البيع بالجملة للاغذية والمشروبات والتبغ"], ["4649", "البيع بالجملة للسلع المنزلية الاخرى"], ["4711", "البيع بالتجزئة في المتاجر غير المتخصصة التي يغلب على مبيعاتها الاغذية"], ["4721", "البيع بالتجزئة للاغذية في المتاجر المتخصصة"], ["4741", "البيع بالتجزئة للحواسيب والاجهزة الطرفية والبرمجيات"], ["4771", "البيع بالتجزئة للملابس والاحذية والسلع الجلدية"], ["4772", "البيع بالتجزئة للسلع الصيدلانية والطبية ومستحضرات التجميل"], ["5610", "انشطة المطاعم وخدمات الاطعام المتنقلة"], ["6201", "انشطة برمجة الحواسيب"], ["8510", "التعليم قبل الابتدائى والابتدائى"], ["8620", "انشطة الممارسة الطبية وطب الاسنان"]]
    .map(r => ({ code: r[0], name: r[1], active: true }));

  function exampleRound(n) { n = +n || 0; const v = 14.529483726; return (Math.round(v * Math.pow(10, n)) / Math.pow(10, n)).toFixed(n); }
  /* العملات: مفتاح التعدد + العملة المحلية + جدول العملات + خصائص */
  function currencyTab() {
    return {
      id: "cur", t: "العملات", render(host, ctx) {
        const fk = "sys.curf", v = get(fk, { multi: true, lockPrice: false, unified: false });
        host.innerHTML = `<div class="pp-form">${rowHTML(["tg", "multi", "هل تتعامل بأكثر من عملة فى البرنامج ؟", true], v)}
          <div class="pp-row" data-show="multi"><label>العملة المحلية</label><span class="pp-line"></span><div class="pp-ctl"><b class="pp-red">دينار جزائرى</b></div></div></div>
          <div class="pp-curl" data-show="multi"></div>
          <div class="pp-fxh" data-show="multi"></div>
          <div class="pp-form" data-show="multi">${rowHTML(["tg", "lockPrice", "عدم السماح بتعديل سعر الصنف إذا كانت عملته لا تساوى عملة الفاتورة", false], v)}${rowHTML(["tg", "unified", "التعامل فى البرنامج بنظام العملة الموحدة", false], v)}
          <div class="pp-note">التعامل بنظام العملة الموحدة : يتم تحويل جميع التعاملات الى العملة المحلية للبرنامج طبقاً لسعر الصرف وقت التعامل , وتظهر جميع التقارير بالعملة المحلية .</div></div>`;
        const lh = host.querySelector(".pp-curl");
        const mkList = () => listTab({
          id: "currencies", t: "العملات", activeFilter: false, noDel: false,
          seed: [{ code: "DZD", name: "دينار جزائرى", rate: 1, lt1: false, active: true }, { code: "EUR", name: "يورو", rate: 4, lt1: true, active: true }, { code: "USD", name: "دولار أمريكى", rate: 3, lt1: true, active: true }],
          cols: [["code", "الكود", 90], ["name", "الاسم"], ["rate", "القيمة", 110, "eq"], ["lt1", "أقل من الواحد", 110, "chk"], ["active", "نشط", 80, "chk"]],
          dTitle: "العملات", dW: 520, okCls: "green",
          dHead: `<div class="pp-dhead"><span class="ic">${IC.coins}</span><div><b>يمكنك إضافة جميع العملات التى تتعامل بها فى المؤسسه</b><div>عملة البلد : <b class="pp-red">دينار جزائرى</b></div></div></div>`,
          blank: { code: "", name: "", rate: 1, lt1: false, active: true },
          form: [["txt", "code", "الرمز", "", { req: 1, w: 120, ltr: 1 }], ["sel", "name", "الاسم", "", { req: 1, w: 220, opts: () => [["", ""]].concat(CUR_NAMES.map(c => [c[1], c[1]])) }],
            ["chk", "active", "الحاله", true, { cap: "نشط" }], ["num", "rate", "سعر الصرف", 1, { req: 1, step: "any", w: 120 }], ["chk", "lt1", "", false, { bare: 1, cap: "سعر صرف العملة أقل من الواحد الصحيح" }],
            ["html", '<div class="pp-note">سعر الصرف : هو قيمة العملة بالنسبة للعملة المحلية , فإذا كانت العملة أقل من الواحد الصحيح يتم إدخال عدد الوحدات من العملة التى تساوى واحد من العملة المحلية .</div>']],
          onDialog(d) { const n = d.$('[data-pk="name"]'), c = d.$('[data-pk="code"]'); n.addEventListener("change", () => { const f = CUR_NAMES.find(x => x[1] === n.value); if (f && !c.value) c.value = f[0]; }); },
          validate(nv, rows, i) { nv.code = String(nv.code).toUpperCase(); if (rows.some((r, j) => j !== i && r.code === nv.code)) return "رمز العملة مستخدم من قبل"; }
        }, lh, ctx);
        mkList();
        /* أسعار الصرف اليومية: البنك + السكوار (fx-rates.js) */
        if (window.ANOUER_FX) ANOUER_FX.panel(host.querySelector(".pp-fxh"), { reload: mkList });
        const upd = wire(host);
        return () => put(fk, Object.assign(v, collect(host.querySelectorAll(".pp-form")[0]), collect(host.querySelectorAll(".pp-form")[1])));
      }
    };
  }

  TILES.sys = {
    id: "sys", title: "إعدادات النظام",
    tabs: [
      { id: "gen", t: "خصائص عامة", type: "form", rows: [
        ["sel", "round", "تقريب الكسور العشرية الى اقرب", 2, { opts: [0, 1, 2, 3, 4, 5, 6].map(n => [n, n === 0 ? "رقم صحيح" : n + " رقم عشرى"]), w: 200 }],
        ["note", 'مثال القيمة بـ 14.529483726 فيكون التقريب <b class="pp-ex">14.53</b>', "pp-mut"],
        ["gap", 6],
        ["sel", "overPay", "فى حالة ان الرصيد الحالى أقل من القيمة المراد دفعها", "عدم الاهتمام", { opts: ["عدم الاهتمام", "ظهور تنبيه قبل الحفظ", "عدم حفظ العملية"], w: 200 }],
        ["sel", "period", "فترة البحث بالتاريخ الافتراضية للبرنامج", "الثلاث شهور السابقة", { opts: PERIODS, w: 200 }],
        ["sel", "coName", "طريقة قراءة اسم الشركة يكون من", "بيانات الشركة", { opts: ["بيانات الفرع", "بيانات الشركة"], w: 200 }],
        ["sel", "accFrom", "طريقة قراءة الحسابات الافتراضية يكون من", "المستخدم", { opts: ["المستخدم", "الجهاز"], w: 200 }],
        ["sel", "link", "طريقة ربط الفروع عن طريق الإنترنت", "أونلاين", { opts: ["أونلاين", "مزامنة البيانات"], w: 200 }],
        ["note", "<b>أونلاين :</b> تعمل جميع الفروع على قاعدة بيانات واحدة عبر الإنترنت ويظهر أى تعامل فى جميع الفروع لحظياً .<br><b>مزامنة البيانات :</b> يعمل كل فرع على قاعدة بياناته المحلية ويتم مزامنة البيانات مع باقى الفروع عند الاتصال بالإنترنت .", "pp-green"]
      ], onRender(host) { const s = host.querySelector('[data-pk="round"]'), ex = host.querySelector(".pp-ex"); const u = () => { ex.textContent = exampleRound(s.value); }; s.addEventListener("change", u); u(); } },
      /* ✦ (2026-11-22) حسابات التواصل — شريط «تابعونا» (فيسبوك · يوتيوب · تيك توك) في آخر كل الإيصالات والفواتير */
      { id: "social", t: "حسابات التواصل", type: "form", rows: [
        ["h", "حسابات التواصل في الإيصالات"],
        ["txt", "fb", "فيسبوك", "", { w: 280, ltr: 1, ph: "anouerpos" }],
        ["txt", "yt", "يوتيوب", "", { w: 280, ltr: 1, ph: "@anouerapp" }],
        ["txt", "tt", "تيك توك", "", { w: 280, ltr: 1, ph: "@anouersaed" }],
        ["sel", "on", "شريط «تابعونا» في الإيصالات", "إظهار", { opts: ["إظهار", "إخفاء"], w: 200 }],
        ["note", "اكتب اسم الحساب فقط (مثل <b dir=\"ltr\">@anouerapp</b>) أو الرابط كاملاً — يظهر في آخر كل إيصال وفاتورة. الخانة الفارغة لا تظهر في الإيصال.", "pp-mut"],
        ["html", '<div class="pp-socpv" style="width:300px;margin-top:10px;padding:8px;background:#fff;border:1px solid #e2e8f0;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.06)"></div>']
      ], onRender(host) {
        const RD = window.ANOUER_RD, q = k => host.querySelector('[data-pk="' + k + '"]'), pv = host.querySelector(".pp-socpv");
        /* أول فتح: نعرض الحسابات المستعملة حالياً في الإيصالات */
        try { const sv = get("sys.social", null); if ((!sv || !("fb" in sv || "yt" in sv || "tt" in sv)) && RD && RD.company) RD.company().then(co => { [["fb", "Social Facebook"], ["yt", "Social YouTube"], ["tt", "Social TikTok"]].forEach(([k, c]) => { const e = q(k); if (e && !e.value && co[c]) e.value = co[c]; }); draw(); }).catch(() => { }); } catch (e) { }
        const draw = () => { if (!pv || !RD || !RD.socialHTML) return; const on = (q("on") || {}).value !== "إخفاء";
          const r = on ? RD.socialHTML({ "Social Facebook": RD.socHandle(q("fb").value), "Social YouTube": RD.socHandle(q("yt").value), "Social TikTok": RD.socHandle(q("tt").value) }) : null;
          pv.innerHTML = r ? '<div style="font:700 11px Tahoma;color:#64748b;margin-bottom:6px">معاينة (إيصال 80 مم)</div><div style="width:74mm;margin:auto">' + r.html + "</div>" : '<div style="font:12px Tahoma;color:#94a3b8;text-align:center;padding:10px">' + (on ? "اكتب حساباتك لتظهر المعاينة" : "الشريط مخفي من الإيصالات") + "</div>"; };
        host.addEventListener("input", draw); host.addEventListener("change", draw); draw();
      } },
      { id: "close", t: "فترات الإغلاق", type: "list", title: "إغلاق التعاملات", desc: "وهى الفترات التى يتم فيها إغلاق جميع التعاملات من التعديل و الحذف", activeFilter: false,
        cols: [["name", "الاسم"], ["from", "من تاريخ", 160], ["to", "الى تاريخ", 160]],
        dTitle: "فترات الإغلاق", dW: 560, okLbl: "موافق", okCls: "blue2",
        blank: () => ({ name: "", from: today(), days: 30, count: 12, open: false, auto: true, archive: 0, salePol: false, saleDays: 1, purDays: 1, editAfter: false, editDays: 1 }),
        form: [["txt", "name", "الاسم", "", { req: 1, w: 280 }], ["date", "from", "تاريخ البدأ", "", { req: 1 }], ["num", "days", "مدة الفترة", 30, { req: 1, unit: "يوم", min: 1 }], ["num", "count", "عدد الفترات", 12, { req: 1, min: 1 }], ["ro", "to", "تاريخ النهاية", ""],
          ["h", "الخصائص"], ["tg", "open", "حالة الفترات", true, { lb: ["مفتوحة", "مغلقة"] }], ["tg", "auto", "إغلاق الفترات تلقائياً", true], ["num", "archive", "أرشفة التعاملات بعد إغلاقها بمدة ؟", 0, { unit: "يوم", min: 0 }],
          ["tg", "salePol", "هل يوجد للمبيعات سياسة خاصة؟", false], ["num", "saleDays", "تعتبر فواتير المبيعات مغلقة إذا مر على إضافتها", 1, { unit: "يوم", show: "salePol", req: 1 }], ["num", "purDays", "تعتبر فواتير المشتريات مغلقة إذا مر على إضافتها", 1, { unit: "يوم", show: "salePol", req: 1 }],
          ["tg", "editAfter", "التعديل على التعاملات بعد إغلاقها ؟", false], ["num", "editDays", "إتاحة التعديل بعد الإغلاق لمدة", 1, { unit: "يوم", show: "editAfter", req: 1, min: 0 }], ["txt", "pw", "وذلك لمن يحمل الرقم السرى", "", { show: "editAfter", req: 0, w: 160, pw: 1, ltr: 1, ph: "••••" }], ["txt", "pw2", "تأكيد الرقم السرى", "", { show: "editAfter", w: 160, pw: 1, ltr: 1, ph: "••••" }],
          ["html", '<div class="cpt-prev"></div>']],
        onDialog(d, v) { const C = window.ANOUER_CLOSE; d.body.querySelectorAll('[data-pk="pw"],[data-pk="pw2"]').forEach(x => { if (v && v.pwh) x.placeholder = "اتركه فارغاً للإبقاء"; });
          const f = () => { const x = collect(d.body); d.$('[data-ro="to"]').textContent = addDays(x.from, (+x.days || 0) * (+x.count || 0) - 1); if (C) C.preview(d.$(".cpt-prev"), Object.assign({}, v, x)); }; d.body.addEventListener("input", f); d.body.addEventListener("change", f); d.body.addEventListener("click", () => setTimeout(f, 0)); f(); },
        validate(nv) { nv.to = addDays(nv.from, (+nv.days || 0) * (+nv.count || 0) - 1); if (!nv.to) return "تاريخ البدأ غير صحيح";
          if ((+nv.count || 0) > 500) return "عدد الفترات كبير جداً (500 كحد أقصى)";
          const pw = String(nv.pw || ""), pw2 = String(nv.pw2 || ""); delete nv.pw; delete nv.pw2;
          if (nv.editAfter) { if (pw || pw2) { if (pw.length < 4) return "الرقم السرى 4 خانات على الأقل"; if (pw !== pw2) return "تأكيد الرقم السرى غير مطابق"; nv.pwh = window.ANOUER_CLOSE ? ANOUER_CLOSE.hash(pw) : pw; } else if (!nv.pwh) return "أدخل الرقم السرى للتعديل بعد الإغلاق"; }
          if (!nv.at) nv.at = today(); },
        onRender(host, rows) { if (window.ANOUER_CLOSE) ANOUER_CLOSE.render(host, rows); } },
      currencyTab(),
      accTab("accs", "ثوابت الحسابات", ACC_GROUPS, "من هنا يمكنك إضافة الحسابات الرئيسيه التى يتعامل معها البرنامج باستمرار والغرض منها تقديم راحه اليكم اثناء التعاملات"),
      accTab("itemAccs", "ثوابت حسابات الأصناف", ITEM_ACC_GROUPS, ""),
      { id: "countries", t: "البلدان", type: "list", newLbl: "إضافة دولة", activeFilter: false, seed: COUNTRIES,
        cols: [["name", "الدولة"], ["cur", "العملة", 200], ["sub", "العملة الفرعية", 200], ["code", "كود العملة", 120]],
        dTitle: "البلدان", form: [["txt", "name", "الدولة", "", { req: 1, w: 240 }], ["txt", "cur", "العملة", "", { req: 1, w: 200 }], ["txt", "sub", "العملة الفرعية", "", { w: 200 }], ["txt", "code", "كود العملة", "", { w: 100, ltr: 1 }]] },
      { id: "acts", t: "النشاطات", type: "list", newLbl: "إضافة نشاط", activeFilter: false, seed: ACTS,
        cols: [["name", "الاسم"], ["code", "الكود", 180]],
        dTitle: "النشاطات", form: [["txt", "name", "الاسم", "", { req: 1, w: 320 }], ["txt", "code", "الكود", "", { req: 1, w: 120, ltr: 1 }]],
        validate(nv, rows, i) { if (rows.some((r, j) => j !== i && r.code === nv.code)) return "كود النشاط مستخدم من قبل"; } }
    ]
  };

  // ==================================================================== 2) الفواتير
  const SALE_TYPES = ["مبيعات", "مرتجع مبيعات", "عرض السلعة", "فاتورة أولية", "أمر توريد"];
  const PUR_TYPES = ["مشتريات", "مرتجع مشتريات", "طلبية شراء", "أمر توريد شراء", "إذن استلام"];
  const ACC_TYPES = ["دفع نقدية", "استلام نقدية", "مصروفات", "ايرادات", "تحويلات الأرصدة", "قيد محاسبى"];
  const WH_TYPES = ["إذن إضافة", "إذن صرف", "تحويل مخزنى", "تسوية جردية", "حجز بضاعة", "إلغاء الحجز", "هالك"];
  const infoRows = (who) => [["h", "ما الذى تريده فى شاشة معلومات عن الصنف ؟"], ["tg", "iStock", "ظهور رصيد الصنف ؟", true], ["tg", "iPrices", "ظهور أسعار الصنف ؟", true], ["tg", "iAlt", "ظهور الأصناف البديلة لهذا الصنف؟", true], ["tg", "iAllWh", "ظهور رصيد الصنف فى جميع المخازن ؟", true],
    ["h", "ما الذى تريده فى شاشة معلومات عن " + who + " ؟"], ["tg", "cBal", "ظهور الرصيد الحالى له ؟", true], ["tg", "cLimit", "ظهور حد الإئتمان ؟", true], ["tg", "cLast", "ظهور اخر تعاملات تمت معه ؟", true], ["tg", "cPers", "ظهور البيانات الشخصيه له ؟", true]];
  const STATE_TYPES = [["Draft", "Draft"], ["Open", "Open"], ["InProgress", "InProgress"], ["Locked", "Locked"], ["Completed", "Completed"]];
  const STATE_IC = { Draft: "✎", Open: "✔", InProgress: "⟳", Locked: "🔒", Completed: "☑" };

  /* سياسة الترقيم: معالج من خطوتين */
  function numberingEditor(row, done) {
    const v = row || { name: "", active: true, by: ["branch"], grid: null };
    const G = [["فواتير المبيعات", SALE_TYPES], ["فواتير المشتريات", PUR_TYPES], ["الحسابات", ACC_TYPES], ["فواتير المخازن", WH_TYPES]];
    const g = v.grid || {}; G.forEach(x => x[1].forEach(n => { if (!g[n]) g[n] = { auto: true, pre: "", start: 1, daily: false, dev: false }; }));
    const BY = [["branch", "الفرع", '<svg viewBox="0 0 24 24" fill="#fff"><rect x="4" y="3" width="10" height="18" rx="1" opacity=".9"/><rect x="14" y="8" width="7" height="13" rx="1" opacity=".75"/><g fill="#0b4e93"><rect x="6" y="5" width="2" height="2"/><rect x="10" y="5" width="2" height="2"/><rect x="6" y="9" width="2" height="2"/><rect x="10" y="9" width="2" height="2"/><rect x="6" y="13" width="2" height="2"/><rect x="10" y="13" width="2" height="2"/><rect x="16" y="11" width="2" height="2"/><rect x="16" y="15" width="2" height="2"/></g></svg>'],
      ["party", "العميل أو المورد", '<svg viewBox="0 0 24 24" fill="#fff"><circle cx="12" cy="8" r="4.2"/><path d="M4 21c0-5 3.6-7.5 8-7.5s8 2.5 8 7.5z"/></svg>'],
      ["form", "نموزج الفاتورة", '<svg viewBox="0 0 24 24" fill="#fff"><rect x="4" y="3" width="16" height="18" rx="2" opacity=".95"/><g fill="#3a87e8"><rect x="6.5" y="6" width="11" height="2.5"/><rect x="6.5" y="10.5" width="5" height="8"/><rect x="13" y="10.5" width="4.5" height="8"/></g></svg>']];
    let step = 1;
    const d = dlg({ title: "سياسة الترقيم", w: 900, cls: "pp-wiz", icon: '<svg viewBox="0 0 16 16"><rect x="2" y="2" width="12" height="12" rx="1" fill="#555"/><path d="M4 5h8M4 8h8M4 11h8" stroke="#fff"/></svg>', body: "", buttons: [] });
    const paint = () => {
      d.foot.innerHTML = ""; d.foot.style.display = "";
      const B = (t, cls, fn) => { const b = document.createElement("button"); b.type = "button"; b.className = "pp-btn " + cls; b.textContent = t; b.onclick = fn; d.foot.appendChild(b); };
      if (step === 1) {
        d.body.innerHTML = `<div class="pp-wz1"><div class="pp-wzf">${fHTML(["txt", "name", "الاسم", v.name, { req: 1, w: 280 }], {})}<label class="pp-chk"><input type="checkbox" data-pk="active" data-t="chk"${v.active !== false ? " checked" : ""}> نشط</label>
          <div class="pp-wzl">الترقيم عن طريق</div><div class="pp-wzt">${BY.map(b => `<button type="button" class="pp-wtile${v.by.indexOf(b[0]) >= 0 ? " on" : ""}" data-b="${b[0]}">${b[2]}<span>${esc(b[1])}</span></button>`).join("")}</div></div>
          <div class="pp-wzimg">${IC.note.replace('viewBox="0 0 48 48"', 'viewBox="0 0 48 48" width="150" height="150"')}</div></div>`;
        d.body.querySelectorAll(".pp-wtile").forEach(b => b.onclick = () => { b.classList.toggle("on"); });
        B("التالى", "blue2", () => {
          const nm = d.$('[data-pk="name"]'); if (!nm.value.trim()) { nm.classList.add("err"); nm.focus(); T("أدخل الاسم", "w"); return; }
          v.name = nm.value.trim(); v.active = d.$('[data-pk="active"]').checked; v.by = Array.from(d.body.querySelectorAll(".pp-wtile.on")).map(b => b.dataset.b);
          step = 2; paint();
        });
        setTimeout(() => d.$('[data-pk="name"]').focus(), 20);
      } else {
        d.body.innerHTML = `<table class="pp-grid pp-tree"><colgroup><col><col style="width:110px"><col style="width:110px"><col style="width:110px"><col style="width:110px"><col style="width:110px"></colgroup>
          <thead><tr><th>الاسم</th><th>الترقيم تلقائياً</th><th>البادئة</th><th>بدأ الترقيم من</th><th>الترقيم يومياً</th><th>الترقيم بالجهاز</th></tr></thead><tbody>${G.map((x, gi) => `<tr class="pp-trg" data-g="${gi}"><td><i class="pp-car">›</i> ${esc(x[0])}</td><td></td><td></td><td></td><td></td><td></td></tr>` +
          x[1].map(n => { const r = g[n]; return `<tr class="pp-trc" data-g="${gi}" data-n="${esc(n)}" style="display:none"><td class="ind">${esc(n)}</td><td class="c">${tg(r.auto)}</td><td><input class="pp-txt" data-f="pre" value="${esc(r.pre)}" style="width:96%"></td><td><input class="pp-num" type="number" data-f="start" value="${r.start}" style="width:90%"></td><td class="c">${tg(r.daily)}</td><td class="c">${tg(r.dev)}</td></tr>`; }).join("")).join("")}</tbody></table>`;
        wire(d.body);
        d.body.querySelectorAll(".pp-trg").forEach(tr => tr.onclick = () => { const open = !tr.classList.contains("op"); tr.classList.toggle("op", open); d.body.querySelectorAll(`.pp-trc[data-g="${tr.dataset.g}"]`).forEach(c => c.style.display = open ? "" : "none"); });
        d.body.querySelector('.pp-trg[data-g="2"]').click();
        B("السابق", "blue2", () => { read(); step = 1; paint(); });
        B("حفظ", "green", () => { read(); v.grid = g; d.close(); done(v); T("تم الحفظ", "s"); });
      }
    };
    const read = () => { d.body.querySelectorAll(".pp-trc").forEach(tr => { const r = g[tr.dataset.n], t = tr.querySelectorAll(".pp-tg"); r.auto = t[0].classList.contains("on"); r.daily = t[1].classList.contains("on"); r.dev = t[2].classList.contains("on"); r.pre = tr.querySelector('[data-f="pre"]').value; r.start = +tr.querySelector('[data-f="start"]').value || 1; }); };
    paint();
  }

  TILES.inv = {
    id: "inv", title: "الفواتير",
    tabs: [
      { id: "gen", t: "خصائص عامة", type: "form", rows: [
        ["tg", "allowNeg", "السماح بصرف البضاعة على المكشوف ( عندما لا يوجد رصيد للصنف بالمخزن )", true],
        ["tg", "payScreen", "ظهور شاشة ادخال النقدية المدفوعة قبل حفظ كل فاتورة ؟", false],
        ["tg", "multiWh", "السماح بإجراء تعاملات فى أكثر من مخزن فى نفس الفاتورة ؟", true],
        ["tg", "qty1", "ملأ خانة الكمية فى الفاتورة بالرقم = 1 .. دائما ؟", true],
        ["tg", "editTotal", "إمكانية التعديل على خانة الإجمالى بالفاتورة", false],
        ["sel", "editTotalBy", "عند تعديل الاجمالى ما الذى تريد تعديله", "السعر", { opts: ["السعر", "الكمية", "الخصم"], show: "editTotal" }],
        ["tg", "retInside", "السماح بعمل مرتجعات من داخل الفواتير", true],
        ["sel", "overPay", "فى حالة سداد الفاتورة بمبالغ مالية أكبر من قيمتها . ما الذى تود فعلة ؟", "دعنى أتخذ القرار", { opts: ["دعنى أتخذ القرار", "إضافة المبلغ الى رصيد العميل أو المورد", "رد المبلغ الى العميل أو المورد"], w: 210 }],
        ["sel", "donate", "ظهور شاشة التبرعات وتحويل النقاط عند الدفع نقدا فى حالة", "عدم الظهور", { opts: ["وجود كسور عشرية فى الفاتورة", "ظهور دائماً", "عدم الظهور"], w: 210 }],
        ["sel", "onClose", "فى حالة وجود أصناف بداخل الفاتورة . عند إغلاقها . ما الذى تود فعله ؟", "ظهور رسالة تنبيه", { opts: ["ظهور رسالة تنبيه", "عدم ظهور رسالة تنبيه", "منع إغلاق الفاتورة"], w: 210 }],
        ["tg", "editName", "التعديل على إسم الصنف داخل الفاتورة ؟", true],
        ["tg", "newPriceWarn", "ظهور تنبيه إذا كان سعر الصنف لم يسبق التعامل به مع إمكانية تثبيت هذا السعر", true],
        ["tg", "tierWarn", "ظهور تنبيه فى حالة التنقل بين مستوى الاسعار", true],
        ["sel", "roundTotal", "كيفية تقريب الاجمالى فى الفاتورة ؟", "تقريب الأرقام العشرية فقط", { opts: ["بدون تقريب", "تقريب الأرقام العشرية فقط", "تقريب الاجمالى ككل"], w: 210 }],
        ["num", "roundTo", "التقريب إلى أقرب", 25, { min: 0, unit: "دج" }],
        ["tg", "touch", "استخدام شاشات اللمس فى شاشة الكاشير ؟", true]
      ] },
      { id: "pur", t: "فواتير المشتريات", type: "form", rows: [
        ["tg", "cash", "هل تستخدم دائماً التعاملات الكاش فى المشتريات ؟", true],
        ["tg", "dup", "هل أسمح بتكرار نفس الصنف فى الفاتورة أكثر من مرة ؟", true],
        ["tg", "dupQty", "فى حالة تكرار نفس الصنف فى الفاتورة . هل أقوم بزيادة الكمية وعدم تكرار الصنف؟", true],
        ["tg", "editSale", "هل تريد التعديل على سعر البيع أثناء عمل فاتورة المشتريات ؟", true],
        ["tg", "linkUnits", "ربط الأسعار بين وحدات الصنف (الشراء والبيع) .. سعر القطعة × عدد القطع = سعر الكرتونة ، مع إمكانية تعديل الكرتونة يدوياً ؟", true],
        ["tg", "prefSup", "ظهور الأصناف التى يتعامل بها المورد المفضل فقط .. فى فواتير الشراء ؟", false]
      ].concat(infoRows("المورد")) },
      { id: "sale", t: "فواتير المبيعات", type: "form", rows: [
        ["sel", "loss", "السماح للأصناف التى قد تسبب خسائر اثناء المبيعات", "دعنى أتخذ القرار", { opts: ["دعنى أتخذ القرار", "السماح دائماً", "عدم السماح"], w: 210 }],
        ["tg", "cash", "هل تستخدم دائماً التعاملات الكاش فى المبيعات ؟", true],
        ["tg", "dup", "هل أسمح بتكرار نفس الصنف فى الفاتورة أكثر من مرة ؟", true],
        ["tg", "dupQty", "فى حالة تكرار نفس الصنف فى الفاتورة . هل أقوم بزيادة الكمية وعدم تكرار الصنف؟", true],
        ["tg", "noDupSame", "عدم السماح بتكرار الصنف فى حالة وجود نفس الكمية و الوحدة ؟", true, { cls: "dis" }],
        ["tg", "order", "إذا كان الصنف المباع رصيده لا يكفى .هل أقوم بعمل طلبية منه ؟", true],
        ["tg", "qtyAsk", "ظهور نافذة العدد عند إضافة صنف ( بالباركود أو من قائمة الأصناف ) ؟", true],
        ["sel", "qtyAskDup", "عند إضافة صنف موجود بالفاتورة . نافذة العدد تفتح على", "زيادة العدد الحالى", { opts: ["زيادة العدد الحالى", "كتابة عدد جديد", "لا تظهر ( زيادة 1 فقط )"], show: "qtyAsk", w: 210 }],
        ["tg", "qtyAskScan", "مسح صنف آخر والنافذة مفتوحة .. يؤكد العدد ويضيف الصنف الجديد ؟", true, { show: "qtyAsk" }],
        ["tg", "qtyAskStock", "تنبيه داخل نافذة العدد إذا كان العدد أكبر من رصيد الصنف ؟", true, { show: "qtyAsk" }],
        ["num", "maxItems", "لا يزيد عدد الأصناف بداخل أى فاتورة عن", 900, { unit: "صنف", min: 1 }],
        ["num", "offerDays", "فترة سريان عرض السعر من تاريخ الإصدار", 10, { unit: "يوم", min: 0 }]
      ].concat(infoRows("العميل")), onRender(host) { const t = host.querySelector('[data-pk="noDupSame"]'); if (t) t.classList.add("dis"); } },
      { id: "ret", t: "المرتجعات والتحويلات", type: "form", rows: [
        ["h", "المرتجعات"],
        ["tg", "retNoOrig", "لا يتم قبول مرتجع المبيعات بدون أصل الفاتورة ؟", false],
        ["num", "retDays", "لا يتم ارتجاع الفواتير التى مر عليها", 14, { unit: "يوم من تاريخ بيعها", min: 0 }],
        ["tg", "purOrig", "يجب إدخال أصل فاتورة المشتريات قبل إجراء أى مرتجعات ؟", false],
        ["tg", "expired", "هل يتم قبول الصنف المنتهى صلاحيته؟", false],
        ["h", "أخرى"],
        ["sel", "trPrice", "تحويل الاصناف بين المخازن بسعر", "سعر التكلفة", { opts: ["سعر التكلفة", "سعر الشراء", "سعر البيع"] }],
        ["num", "minOrder", "أقل مبلغ يتم قبول عليه عمل طلبية مبيعات", 0, { unit: "DZD", min: 0, w: 90 }]
      ] },
      { id: "types", t: "أنواع الفواتير", render(host, ctx) {
        let v = get("inv.types", { sel: "Professional" });
        const L = ["Clean", "Simple", "Professional", "Advanced"];
        const draw = () => {
          host.innerHTML = `<div class="pp-list"><div class="pp-lt dark">طريقة العرض</div><div class="pp-ld">يمكنك من هنا أختيار الخصائص المراد عرضها في الفاتورة</div>
            <table class="pp-grid"><thead><tr><th>الاسم</th></tr><tr class="pp-flt"><td><span class="fi">${IC.abc}</span><input data-fc="0"></td></tr></thead><tbody>${L.map((n, i) => `<tr data-r="${i}" tabindex="-1" class="${v.sel === n ? "sel cur" : ""}"><td class="c">${n}${v.sel === n ? ' <b class="pp-ok">✔</b>' : ""}</td></tr>`).join("")}</tbody></table></div>`;
          const tbl = host.querySelector(".pp-grid"); wireFilter(tbl);
          tbl.addEventListener("click", e => { const tr = e.target.closest("tr[data-r]"); if (!tr) return; tbl.querySelectorAll("tr.sel").forEach(x => x.classList.remove("sel")); tr.classList.add("sel"); });
          tbl.addEventListener("dblclick", e => { const tr = e.target.closest("tr[data-r]"); if (!tr) return; v.sel = L[+tr.dataset.r]; put("inv.types", v).then(() => { T("طريقة العرض: " + v.sel, "s"); draw(); }); });
        };
        draw(); return null;
      } },
      { id: "numbering", t: "سياسة ترقيم الفواتير", type: "list", title: "سياسة ترقيم التعاملات", tcls: "dark",
        cols: [["name", "الاسم"], ["byTxt", "الترقيم عن طريق", 260]], editor: (row, done) => numberingEditor(row, r => { r.byTxt = (r.by || []).map(b => ({ branch: "الفرع", party: "العميل أو المورد", form: "نموزج الفاتورة" })[b]).join(" - "); done(r); }) },
      { id: "states", t: "حالات الفواتير", render(host, ctx) {
        const OPT = [["المبيعات", SALE_TYPES], ["المشتريات", PUR_TYPES], ["المخازن", WH_TYPES]];
        let deal = "مبيعات";
        const draw = () => {
          const all = get("inv.states", {}); const rows = all[deal] || [{ name: "Draft", type: "Draft", active: true, def: true }];
          host.innerHTML = `<div class="pp-list"><div class="pp-tb top"><button type="button" class="pp-btn blue pp-new">جديد</button><div class="pp-fl"><label>التعامل</label><select class="pp-sel pp-deal" style="width:200px">${OPT.map(g => `<optgroup label="${g[0]}">${optHTML(g[1], deal)}</optgroup>`).join("")}</select></div></div>
            <table class="pp-grid"><colgroup><col style="width:34px"><col><col style="width:45%"></colgroup><thead><tr><th></th><th>الاسم</th><th>النوع</th></tr><tr class="pp-flt"><td class="c">⊤</td><td><span class="fi">${IC.abc}</span><input data-fc="1"></td><td><span class="fi">${IC.abc}</span><input data-fc="2"></td></tr></thead>
            <tbody>${rows.map((r, i) => `<tr data-r="${i}" tabindex="-1"><td class="c pp-arw">${r.def ? "←" : ""}</td><td>${esc(r.name)}</td><td><span class="pp-st">${STATE_IC[r.type] || ""}</span> ${esc(r.type)}</td></tr>`).join("")}</tbody></table></div>`;
          wireFilter(host.querySelector(".pp-grid"));
          host.querySelector(".pp-deal").onchange = e => { deal = e.target.value; draw(); };
          const ed = i => {
            const v = i < 0 ? { name: "", type: "Open", active: true, def: false } : clone(rows[i]);
            dlg({ title: "حالة الفواتير", w: 380, body: `<div class="pp-form2">${fHTML(["txt", "name", "الاسم", v.name, { req: 1, w: 220 }], {})}<div class="pp-fr col"><label>النوع</label><div class="pp-fc">${sel(STATE_TYPES, v.type, "type", 100)}<label class="pp-chk"><input type="checkbox" data-pk="active" data-t="chk"${v.active !== false ? " checked" : ""}> نشط</label></div></div>
              <label class="pp-chk blk"><input type="checkbox" data-pk="def" data-t="chk"${v.def ? " checked" : ""}> جعل هذه الحالة هى الإفتراضى للإدخال</label></div>`,
              buttons: [{ t: "حفظ", cls: "green", fn: d => { const nv = collect(d.body); if (!nv.name.trim()) { T("أدخل الاسم", "w"); return; } if (nv.def) rows.forEach(r => r.def = false); if (i < 0) rows.push(nv); else rows[i] = nv; all[deal] = rows; put("inv.states", all).then(() => { d.close(); draw(); T("تم الحفظ", "s"); }); } },
                { t: "الغاء", cls: "blue", fn: d => d.close() }] });
          };
          host.querySelector(".pp-new").onclick = () => ed(-1);
          host.querySelector(".pp-grid").addEventListener("dblclick", e => { const tr = e.target.closest("tr[data-r]"); if (tr) ed(+tr.dataset.r); });
          host.querySelector(".pp-grid").addEventListener("click", e => { const tr = e.target.closest("tr[data-r]"); if (!tr) return; host.querySelectorAll("tr.sel").forEach(x => x.classList.remove("sel")); tr.classList.add("sel"); });
        };
        draw(); return null;
      } },
      { id: "design", t: "تصميم الفاتورة", type: "form", cls: "wide", rows: [
        ["tg", "fastPrint", "إستخدام الطريقة المثلى لطباعة الفاتورة بشكل أسرع ؟", false],
        ["tg", "qtyTrack", "إستخدام تتبع الكميات؟", false],
        ["tg", "grpNoComp", "ظهور صنف المجموعه بدون مكونات ؟", true],
        ["tg", "tafqit", "ظهور تفقيط الفاتورة", true],
        ["tg", "payWay", "ظهور طريقة دفع الفاتورة", true],
        ["tg", "serials", "ظهور أرقام السيريال للأصناف", true],
        ["tg", "qr", "ظهور ال QR Code", true],
        ["tg", "thanks", "ظهور رسالة الشكر", true],
        ["tg", "donMsg", "ظهور رسالة التبرعات ؟", true],
        ["tg", "policy", "ظهور سياسة التعامل", true],
        ["gap", 6],
        ["tg", "coAddr", "العنوان", true, { cls: "co" }],
        ["tg", "coPhone", "التليفون", true],
        ["tg", "coTax", "الرقم الضريبى", true]
      ], onRender(host, v) {
        // حقول «الرسالة/السياسة» بجانب المفاتيح + عنوان «ظهور بيانات الشركة»
        [["thanks", "thanksTxt", "الرسالة", "شكراً لزيارتكم"], ["donMsg", "donTxt", "الرسالة", ""], ["policy", "polTxt", "السياسة", "البضاعة المباعة لا ترد ولا تستبدل"]].forEach(x => {
          const r = host.querySelector(`[data-pk="${x[0]}"]`).closest(".pp-row"); r.querySelector(".pp-msg") && r.querySelector(".pp-msg").remove();
          const s = document.createElement("span"); s.className = "pp-msg"; s.innerHTML = `<b>${x[2]}</b>${txt(v[x[1]] !== undefined ? v[x[1]] : x[3], x[1], 150)}`; r.appendChild(s);
        });
        const r = host.querySelector('[data-pk="coAddr"]').closest(".pp-row"); const h = document.createElement("span"); h.className = "pp-coh"; h.textContent = "ظهور بيانات الشركة"; r.insertBefore(h, r.firstChild);
      } }
    ]
  };

  window.__PPD = { SALE_TYPES, PUR_TYPES, ACC_TYPES, WH_TYPES, CUR_NAMES, addDays };
})();
