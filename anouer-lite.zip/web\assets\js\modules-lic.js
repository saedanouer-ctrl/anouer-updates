/* ANOUER — ترخيص الموديولات (مثل DEXEF ONE: «يجب عليك شراء هذا الموديول»)
   كل موديول مقفول حتى يُدخل العميل «كود التفعيل» الذي يصدره صاحب البرنامج فقط (برنامج ANOUER-Keygen).
   - الرقم السري: بصمة الجهاز (اسم الجهاز + معرّف التثبيت المحفوظ في القاعدة) + رمز الموديول.
   - كود التفعيل: توقيع ECDSA P-256 من المفتاح الخاص (عند صاحب البرنامج فقط) — البرنامج يحمل المفتاح العام للتحقق.
     الصيغة: <P | yyyymmdd>.<توقيع base64url>  (P = دائم، أو تاريخ انتهاء الترخيص).
   - تجربة لمدة شهر (مرة واحدة لكل موديول) — عند انقضائها يُقفل الموديول. حماية من إرجاع تاريخ الجهاز.
   الاستعمال: ANOUER_LIC.gate("quota", () => فتح الموديول) — ANOUER_LIC.ok("quota") للتحقق المتزامن. */
(function () {
  "use strict";
  const PUB = { kty: "EC", crv: "P-256", x: "dDMKTXOn7OnGjv-KYIrsvaD_Fcfbpm0NvfWrCj2FmnY", y: "JSIKJbg5KD_8vImN70lspLExAoPtydn3UvDBjysMnzY" };
  const DAY = 864e5, ED = window.ANOUER_EDITION || {}, DIST = !!ED.dist;
  const MODS = {
    quota: { t: "كوتة الأصناف", tag: "QUOTA", c: "#0a78d4", days: 30, desc: "نظام تطبقه بعض الشركات على أصناف ذات طبيعة خاصة مثل الألبان والأدوية وبعض الأصناف المستوردة، حيث يُحدَّد لكل عميل حد أقصى من الكمية خلال فترة معينة (يومياً، أسبوعياً، شهرياً …) ويمنع البرنامج أو ينبّه عند تجاوزه." }
  };
  /* «نسخة العملاء»: البرنامج كامل (تجربة 15 يوم تبدأ وحدها) + كل الإضافات تحتاج تفعيل
     ✦ (2026-11-22) إضافات الخصومات تعمل بكود التفعيل فقط — بدون فترة تجربة */
  const PAID_ONLY = ["idisc", "qdisc", "bonus", "extra", "invdisc", "slices", "coupon"];
  if (DIST) {
    MODS.app = { t: "ANOUER", tag: "APP", c: "#2e8b57", days: +ED.trialDays || 15, app: 1,
      desc: "نظام مبيعات ونقاط بيع ومحاسبة متكامل: الفواتير، المشتريات، المخازن، العملاء والموردين، الحسابات، التقارير والطباعة — سريع، سهل وبتصميم حديث." };
    [["idisc", "خصومات الأصناف", "IDISC", "خصم تلقائي على أصناف أو مجموعات محددة بنسبة أو بمبلغ، لفترة محددة أو دائماً."],
      ["qdisc", "خصم الكمية", "QDISC", "خصم يُحسب حسب الكمية المباعة من الصنف (مثلاً: 5 قطع وما فوق بسعر خاص)."],
      ["bonus", "البونص", "BONUS", "كمية مجانية تُضاف تلقائياً عند شراء كمية معينة من الصنف (اشترِ 10 وخذ 1)."],
      ["extra", "تكاليف الأصناف الإضافية", "EXTRA", "إضافة تكاليف على أصناف معينة (نقل، تغليف …) تُحتسب في الفاتورة تلقائياً."],
      ["invdisc", "خصومات الفواتير", "INVDISC", "خصم على إجمالي الفاتورة حسب قيمتها أو حسب العميل."],
      ["slices", "شرائح الخصم", "SLICES", "شرائح خصم متدرجة حسب قيمة المشتريات لتشجيع البيع بكميات أكبر."],
      ["coupon", "كوبونات الخصم", "COUPON", "كوبونات بأرقام خاصة يستعملها العميل للحصول على خصم."],
      ["loyal", "نقاط الولاء", "LOYAL", "يكسب العميل نقاطاً مع كل شراء ويستبدلها بخصومات أو هدايا."],
      ["donate", "التبرعات", "DONATE", "جمع التبرعات في الفاتورة (تقريب المبلغ أو مبلغ اختياري)."],
      ["inst", "الأقساط", "INST", "بيع الشيء بثمن مؤجل يُدفع على أقساط معلومة في أوقات محددة: عقد تقسيط، جدول أقساط تلقائي، تحصيل بإيصال استلام، ومتابعة المتأخرين."]]
      .forEach(a => { MODS[a[0]] = { t: a[1], tag: a[2], c: "#0a78d4", days: 30, desc: a[3], noTrial: PAID_ONLY.includes(a[0]) ? 1 : 0 }; });
  }
  const TD = mod => (MODS[mod] && MODS[mod].days) || 30;
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const say = (m, k) => { try { toast(m, k || "i"); } catch (e) { console.log(m); } };
  const snd = k => { try { if (window.ANOUER_SOUND) ANOUER_SOUND(k); } catch (e) { } };
  const LSK = "anouer.lic";
  const lsGet = () => { try { return JSON.parse(localStorage.getItem(LSK) || "{}") || {}; } catch (e) { return {}; } };
  const lsSet = v => { try { localStorage.setItem(LSK, JSON.stringify(v)); } catch (e) { } };
  const P = () => window.ANOUER_PROPS;
  const p2 = n => String(n).padStart(2, "0");
  const dstr = t => { const d = new Date(t); return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()); };

  /* ---------------- base32 / base64url ---------------- */
  const B32 = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const b32 = u8 => { let bits = 0, v = 0, o = ""; for (const b of u8) { v = (v << 8) | b; bits += 8; while (bits >= 5) { o += B32[(v >>> (bits - 5)) & 31]; bits -= 5; } } if (bits) o += B32[(v << (5 - bits)) & 31]; return o; };
  const ub64 = s => { s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "="; const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
  const enc = s => new TextEncoder().encode(s);
  const sha = s => crypto.subtle.digest("SHA-256", enc(s)).then(b => new Uint8Array(b));

  /* ---------------- الحالة ---------------- */
  const D = { iid: "", iids: [], machine: "", cores: [], core: "", lic: {}, trial: {}, seen: 0 };
  const VER = {};   /* mod → {exp} بعد التحقق من التوقيع */
  let READY = null, KEY = null;
  function merge(a, b) {
    const o = { iid: a.iid || b.iid || "", mods: Object.assign({}, b.mods || {}, a.mods || {}), trial: {}, seen: Math.max(+a.seen || 0, +b.seen || 0),
      iids: [...new Set([a.iid, b.iid].concat(a.iids || [], b.iids || []).filter(Boolean))].slice(0, 8), m: a.m || b.m || "" };
    new Set(Object.keys(a.trial || {}).concat(Object.keys(b.trial || {}))).forEach(k => {
      const x = (a.trial || {})[k] || {}, y = (b.trial || {})[k] || {}, s = [x.s, y.s].filter(Boolean);
      o.trial[k] = { s: s.length ? Math.min(...s) : 0, c: !!(x.c || y.c) };
    });
    return o;
  }
  /* iids: كل معرّفات التثبيت التي عرفها هذا الجهاز ، m: اسم الجهاز — حتى لا يتغيّر «الرقم السري» ويضيع الترخيص
     (مسح ذاكرة المتصفح / قاعدة جديدة / تعذّر قراءة اسم الجهاز عند الإقلاع) */
  function blob() { return { iid: D.iid, iids: D.iids, m: D.machine === "ANOUER-WEB" ? "" : D.machine, mods: D.lic, trial: D.trial, seen: D.seen }; }
  function save() {
    const b = blob(); lsSet(b);
    const pr = P(); if (pr && pr.put) return Promise.resolve(pr.put("Lic", b)).catch(() => { });
    return Promise.resolve();
  }
  function init() {
    if (READY) return READY;
    const pr = P();
    READY = Promise.all([
      pr && pr.load ? Promise.resolve(pr.load()).catch(() => { }) : null,
      HOST() ? Anouer.call("fm.app.info", {}).catch(() => ({})) : Promise.resolve({}),
      crypto.subtle.importKey("jwk", PUB, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]).catch(() => null)
    ]).then(([, info, k]) => {
      KEY = k;
      const fromDb = (pr && pr.get ? pr.get("Lic", null) : null) || {}, loc = lsGet();
      const m = merge(fromDb, loc);
      D.iid = fromDb.iid || loc.iid || "";
      if (!D.iid) { const r = new Uint8Array(10); crypto.getRandomValues(r); D.iid = b32(r); }
      const mc = String(m.m || "").toUpperCase();
      D.machine = String((info && info.machine) || mc || "ANOUER-WEB").toUpperCase();   /* اسم الجهاز المحفوظ بدل «ANOUER-WEB» إن تعذّرت قراءته */
      D.lic = m.mods || {}; D.trial = m.trial || {}; D.seen = m.seen || 0;
      D.iids = [...new Set([D.iid].concat(m.iids || []).filter(Boolean))].slice(0, 8);
      const ms = [...new Set([D.machine, mc].filter(Boolean))], pairs = [];
      D.iids.forEach(i => ms.forEach(mm => pairs.push([i, mm])));   /* الأول دائماً: المعرّف الحالي + اسم الجهاز الحالي = «الرقم السري» المعروض */
      return Promise.all(pairs.map(([i, mm]) => sha("ANOUER-HW|" + i + "|" + mm))).then(hs => {
        D.cores = [...new Set(hs.map(h => b32(h).slice(0, 20).match(/.{4}/g).join("-")))]; D.core = D.cores[0];
        touch(true); save();
        return Promise.all(Object.keys(D.lic).map(mod => verify(mod, (D.lic[mod] || {}).code).then(v => { if (v) VER[mod] = v; else delete VER[mod]; })));
      });
    }).then(() => { paintMenus(); return D; }).catch(e => { console.warn("lic", e); return D; });
    return READY;
  }
  /* حماية من إرجاع التاريخ: نحتفظ بأكبر وقت شوهد */
  let lastTouch = 0;
  function touch(force) { const n = Date.now(); if (n > D.seen) D.seen = n; if (force || n - lastTouch > 36e5) { lastTouch = n; if (!force) save(); } }
  const clockBad = () => D.seen && Date.now() < D.seen - 2 * DAY;

  function parse(code) {
    code = String(code || "").replace(/\s+/g, "").trim();
    const m = /^(P|\d{8})\.([A-Za-z0-9_-]{80,90})$/.exec(code);
    return m ? { exp: m[1], sig: m[2], code } : null;
  }
  function verify(mod, code) {
    const c = parse(code); if (!c || !KEY || !MODS[mod]) return Promise.resolve(null);
    let sig; try { sig = ub64(c.sig); } catch (e) { return Promise.resolve(null); }
    if (sig.length !== 64) return Promise.resolve(null);
    const tag = MODS[mod].tag;
    return Promise.all(D.cores.map(core => crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, KEY, sig, enc("ANOUER|LIC1|" + tag + "|" + core + "|" + c.exp)).catch(() => false)))
      .then(r => r.some(Boolean) ? { exp: c.exp === "P" ? null : c.exp.slice(0, 4) + "-" + c.exp.slice(4, 6) + "-" + c.exp.slice(6, 8) } : null);
  }
  function status(mod) {
    if (!MODS[mod]) return { state: "lic" };
    if (clockBad()) return { state: "clock" };
    const v = VER[mod], now = Date.now();
    if (v) { if (!v.exp || dstr(now) <= v.exp) return { state: "lic", exp: v.exp }; }
    const t = MODS[mod].noTrial ? null : D.trial[mod];
    if (t && t.s) {
      const TRIAL_DAYS = TD(mod), end = t.s + TRIAL_DAYS * DAY, left = Math.ceil((end - now) / DAY);
      if (t.c) return { state: "ended", why: "cancel", start: t.s, end, licExp: v && v.exp };
      if (now >= end) return { state: "ended", why: "time", start: t.s, end, licExp: v && v.exp };
      return { state: "trial", start: t.s, end, left: Math.max(1, left), used: TRIAL_DAYS - Math.max(1, left), licExp: v && v.exp };
    }
    return { state: "none", licExp: v && v.exp };
  }
  const isOk = s => s.state === "lic" || s.state === "trial";
  function ok(mod) { if (!MODS[mod]) return true; if (!READY) init(); touch(); return isOk(status(mod)); }
  function serial(mod) { return D.core + "#" + (MODS[mod] ? MODS[mod].tag : String(mod).toUpperCase()) + "#ANOUER"; }

  /* ---------------- البوابة ---------------- */
  function gate(mod, run) {
    return init().then(() => {
      touch();
      const s = status(mod);
      if (s.state === "lic") { run && run(); return true; }
      if (s.state === "trial" && s.left > 5) { run && run(); trialPill(mod, s); return true; }
      dialog(mod, run);
      return false;
    });
  }
  function trialPill(mod, s) {
    document.querySelectorAll(".lic-pill").forEach(x => x.remove());
    const el = document.createElement("div"); el.className = "lic-pill";
    el.innerHTML = `<span class="rg" style="--p:${Math.round(s.left / TD(mod) * 100)}"><b>${s.left}</b></span><div><b>${esc(MODS[mod].t)} — نسخة تجريبية</b><small>متبقي ${s.left} يوم · تنتهي ${dstr(s.end)}</small></div><button type="button">تفعيل</button>`;
    document.body.appendChild(el);
    el.querySelector("button").onclick = () => { el.remove(); dialog(mod, null); };
    setTimeout(() => { el.classList.add("out"); setTimeout(() => el.remove(), 400); }, 5200);
  }

  /* ---------------- النافذة (مثل DEXEF + 2026) ---------------- */
  const IC = {
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><rect x="8" y="3" width="12" height="15" rx="1.5"/><path d="M5 7v13.5A.5.5 0 0 0 5.5 21H16"/></svg>',
    paste: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"><rect x="5" y="5" width="14" height="16" rx="1.5"/><path d="M9 5V3.5h6V5M8.5 11h7M8.5 14.5h7M8.5 18h4"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/><circle cx="12" cy="15.5" r="1.4" fill="currentColor"/></svg>',
    ok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    app: '<svg viewBox="0 0 16 16"><rect x="1" y="1" width="14" height="14" rx="3" fill="#f39c12"/><path d="M4.5 5h7M4.5 8h7M4.5 11h4.5" stroke="#fff" stroke-width="1.4" stroke-linecap="round"/></svg>'
  };
  function dialog(mod, run) {
    document.querySelectorAll(".lic-ov").forEach(x => x.remove());
    const M = MODS[mod], ov = document.createElement("div"); ov.className = "lic-ov" + (M.app ? " app" : "");
    const hard = () => !!M.app && !isOk(status(mod));   /* البرنامج مقفول: لا إغلاق */
    ov.innerHTML = `<div class="lic-w" role="dialog" aria-modal="true" aria-label="${esc(M.t)}" style="--mc:${M.c}">
      <div class="lic-tb"><span class="ap">${IC.app}</span><span class="sp"></span>${M.app ? "" : '<button type="button" class="mn" title="تصغير">—</button>'}<button type="button" class="x" title="إغلاق">✕</button></div>
      <div class="lic-bd">
        <div class="lic-hd"><span class="nm">${esc(M.t)}</span><span class="lk">${IC.lock}</span></div>
        <p class="lic-ds">${esc(M.desc)}</p>
        <div class="lic-st"></div>
        <label class="lic-lb">الرقم السري</label>
        <div class="lic-f ser"><button type="button" class="ib" data-a="copy" title="نسخ الرقم السري">${IC.copy}</button><input readonly spellcheck="false" dir="ltr" value="${esc(serial(mod))}"></div>
        <label class="lic-lb">كود التفعيل</label>
        <div class="lic-f code"><button type="button" class="ib" data-a="paste" title="لصق كود التفعيل">${IC.paste}</button><input spellcheck="false" dir="ltr" placeholder="Please Purchase the plugin" autocomplete="off"><i class="vk"></i></div>
        <div class="lic-msg" aria-live="polite"></div>
      </div>
      <div class="lic-ft"><button type="button" class="act" data-a="act"><span>تفعيل</span></button>
        <div class="lnk">${M.app || M.noTrial ? "" : '<button type="button" class="tr" data-a="trial">تجربة لمدة شهر</button><button type="button" class="cn" data-a="cancel">إلغاء التجربة</button>'}</div></div>
      <div class="lic-done" hidden><div class="ck">${IC.ok}</div><b>تم تفعيل «${esc(M.t)}»</b><small></small></div></div>`;
    document.body.appendChild(ov);
    const W = ov.querySelector(".lic-w"), Q = s => ov.querySelector(s), inp = Q(".code input"), msg = Q(".lic-msg");
    const close = () => { if (hard()) { shake(); snd("error"); return; } ov.classList.add("out"); setTimeout(() => ov.remove(), 180); document.removeEventListener("keydown", kd, true); };
    const kd = e => { if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); close(); } else if (e.key === "Enter" && document.activeElement === inp) { e.preventDefault(); activate(); } };
    document.addEventListener("keydown", kd, true);
    const shake = () => { W.classList.remove("shk"); void W.offsetWidth; W.classList.add("shk"); };
    ov.addEventListener("mousedown", e => { if (e.target === ov) shake(); });
    function paint() {
      const s = status(mod), st = Q(".lic-st"), tr = Q('[data-a="trial"]'), cn = Q('[data-a="cancel"]');
      W.dataset.st = s.state; const X = Q(".lic-tb .x"); if (X) X.hidden = hard();
      const what = M.app ? "البرنامج" : "الموديول";
      if (s.state === "trial") {
        const pc = Math.round(s.left / TD(mod) * 100);
        st.innerHTML = `<div class="tri"><span class="rg" style="--p:${pc}"><b>${s.left}</b><small>يوم</small></span><div><b>${M.app ? "نسخة تجريبية — " + TD(mod) + " يوم" : "أنت في فترة التجربة"}</b><small>بدأت ${dstr(s.start)} — تنتهي ${dstr(s.end)}</small><i class="bar"><u style="width:${100 - pc}%"></u></i></div>
          <button type="button" class="go" data-a="go">متابعة التجربة ←</button></div>`;
      } else if (s.state === "ended") {
        st.innerHTML = `<b class="red">${s.why === "cancel" ? "تم إلغاء فترة التجربة" : "انتهت فترة التجربة (" + TD(mod) + " يوم)"} — ${what} مقفول .</b><span class="sub">لمواصلة العمل يجب شراء ${what} وإدخال كود التفعيل.${M.app ? " بياناتك محفوظة ولن تضيع." : ""}</span>`;
      } else if (s.state === "clock") {
        st.innerHTML = `<b class="red">تاريخ الجهاز غير صحيح .</b><span class="sub">تم إرجاع تاريخ/وقت الجهاز إلى الوراء — صحّح التاريخ ثم أعد فتح البرنامج.</span>`;
      } else if (D.lic[mod] && D.lic[mod].code && D.lic[mod].core && !VER[mod]) {
        st.innerHTML = `<b class="red">تغيّر «الرقم السري» لهذا الجهاز — كود التفعيل القديم لا يصلح .</b><span class="sub">كان ${what} مفعّلاً على الرقم السري <b dir="ltr">${esc(D.lic[mod].core)}</b> (يحدث بعد تغيير الجهاز أو قاعدة البيانات أو إعادة التثبيت). انسخ «الرقم السري» الجديد أدناه وأنشئ له كود تفعيل جديد.</span>`;
      } else {
        st.innerHTML = `<b class="red">${s.licExp ? "انتهت صلاحية ترخيص هذا الموديول (" + esc(s.licExp) + ") ." : "يجب عليك شراء هذا " + (M.app ? "البرنامج" : "الموديول") + " ."}</b><span class="sub">في حالة رغبتك بشراء هذا ${M.app ? "البرنامج" : "الموديول"}، يرجى التواصل مع مهندس الدعم المسئول عن حسابك وإرسال <b>الرقم السري</b> له ليعطيك <b>كود التفعيل</b>.</span>`;
      }
      const t = D.trial[mod], used = !!(t && t.s);
      if (!tr) return;
      tr.disabled = used || s.state === "clock"; tr.title = used ? (s.state === "trial" ? "التجربة جارية" : "تم استعمال فترة التجربة") : "جرّب الموديول مجاناً لمدة " + TD(mod) + " يوم (مرة واحدة)";
      tr.textContent = s.state === "trial" ? "التجربة جارية · " + s.left + " يوم" : "تجربة لمدة شهر";
      cn.hidden = s.state !== "trial";
    }
    const setMsg = (t, k) => { msg.className = "lic-msg" + (k ? " " + k : ""); msg.textContent = t || ""; };
    inp.addEventListener("input", () => { const c = parse(inp.value); Q(".code").classList.toggle("fmt", !!c); Q(".code").classList.remove("bad", "good"); setMsg(inp.value.trim() && !c ? "صيغة الكود غير صحيحة" : ""); });
    function activate() {
      const v = inp.value.trim();
      if (!v) { setMsg("أدخل كود التفعيل", "e"); shake(); inp.focus(); snd("error"); return; }
      const b = Q('[data-a="act"]'); b.classList.add("busy"); b.disabled = true;
      verify(mod, v).then(r => {
        b.classList.remove("busy"); b.disabled = false;
        if (!r) { Q(".code").classList.add("bad"); setMsg("كود التفعيل غير صحيح لهذا الجهاز / الموديول", "e"); shake(); snd("error"); return; }
        if (r.exp && dstr(Date.now()) > r.exp) { Q(".code").classList.add("bad"); setMsg("كود التفعيل منتهي الصلاحية (" + r.exp + ")", "e"); shake(); snd("error"); return; }
        VER[mod] = r; D.lic[mod] = { code: parse(v).code, core: D.core, at: Date.now() }; save(); paintMenus();
        Q(".code").classList.add("good"); snd("ok");
        const dn = Q(".lic-done"); dn.querySelector("small").textContent = r.exp ? "الترخيص صالح حتى " + r.exp : "ترخيص دائم لهذا الجهاز"; dn.hidden = false; W.classList.add("won");
        setTimeout(() => { close(); run && run(); paintChip(); }, 1500);
      });
    }
    ov.addEventListener("click", e => {
      const b = e.target.closest("[data-a]"); if (e.target.closest(".x")) return close(); if (e.target.closest(".mn")) { W.classList.toggle("min"); return; }
      if (!b || b.disabled) return; const a = b.dataset.a;
      if (a === "copy") { const s = Q(".ser input"); s.select(); const t = s.value; (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).catch(() => { try { document.execCommand("copy"); } catch (x) { } }).then(() => { b.classList.add("flash"); setTimeout(() => b.classList.remove("flash"), 700); say("تم نسخ الرقم السري — أرسله لمهندس الدعم", "s"); }); }
      else if (a === "paste") { (navigator.clipboard && navigator.clipboard.readText ? navigator.clipboard.readText() : Promise.reject()).then(t => { inp.value = String(t || "").trim(); inp.dispatchEvent(new Event("input")); inp.focus(); }).catch(() => { inp.focus(); say("الصق الكود بـ Ctrl+V", "i"); }); }
      else if (a === "act") activate();
      else if (a === "trial") {
        if (D.trial[mod] && D.trial[mod].s) return;
        D.trial[mod] = { s: Date.now(), c: false }; touch(true); save(); paintMenus(); snd("ok"); paint();
        say("بدأت فترة تجربة «" + MODS[mod].t + "» لمدة " + TD(mod) + " يوم", "s");
        setTimeout(() => { close(); run && run(); }, 700);
      }
      else if (a === "go") { close(); run && run(); }
      else if (a === "cancel") {
        const yes = () => { D.trial[mod] = Object.assign({}, D.trial[mod], { c: true }); save(); paintMenus(); paint(); say("تم إلغاء التجربة — الموديول مقفول", "w"); };
        try { askConfirm("هل تريد إلغاء فترة التجربة ؟ سيتم قفل «" + MODS[mod].t + "» ولا يمكن إعادة التجربة.", yes); } catch (x) { if (confirm("إلغاء التجربة؟")) yes(); }
      }
    });
    { const t = Q(".lic-tb"); t.addEventListener("pointerdown", e => { if (e.target.closest("button")) return; const r = W.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top; t.setPointerCapture(e.pointerId);
      const mv = ev => { W.style.position = "fixed"; W.style.margin = "0"; W.style.left = Math.max(0, Math.min(innerWidth - 120, ev.clientX - dx)) + "px"; W.style.top = Math.max(0, Math.min(innerHeight - 40, ev.clientY - dy)) + "px"; };
      const up = () => { t.removeEventListener("pointermove", mv); t.removeEventListener("pointerup", up); }; t.addEventListener("pointermove", mv); t.addEventListener("pointerup", up); }); }
    if (M.app) Q(".lic-hd .nm").innerHTML = 'ANOUER <small>POS</small>';
    paint(); snd(status(mod).state === "trial" ? "info" : "warn");
    setTimeout(() => { const s = Q(".ser input"); s.focus(); s.select(); }, 60);
  }

  /* شارة على عنصر القائمة (قفل / تجربة) */
  function paintMenus() {
    try { syncAdds(); } catch (e) { }
    try {
      const M = window.__MENUS; if (!M) return;
      Object.keys(MODS).forEach(mod => { const s = status(mod); Object.values(M).forEach(list => (list || []).forEach(i => { if (i && i.t === MODS[mod].t) i.badge = s.state === "lic" ? "" : s.state === "trial" ? "تجربة · " + s.left + " يوم" : "مقفول"; i.bc = s.state === "trial" ? "tr" : "lk"; })); });
    } catch (e) { }
  }

  /* ---------------- «نسخة العملاء»: قفل البرنامج كامل ---------------- */
  function appStart() {
    if (!DIST) return;
    init().then(() => {
      if (!D.trial.app || !D.trial.app.s) { if (!VER.app) { D.trial.app = { s: Date.now(), c: false }; touch(true); save(); } }
      const s = status("app");
      if (s.state === "lic") return paintChip();
      if (isOk(s)) { paintChip(); setTimeout(() => { if (s.left <= 3) dialog("app", null); else trialPill("app", s); }, 1800); }
      else dialog("app", null);
    });
    setInterval(() => { if (READY && !ok("app") && !document.querySelector(".lic-ov.app")) dialog("app", null); paintChip(); }, 60000);
  }
  /* شارة «نسخة تجريبية» في أسفل الشاشة — تضغط عليها لتفعيل البرنامج */
  function paintChip() {
    if (!DIST) return;
    let el = document.querySelector(".lic-chip"); const s = status("app");
    if (s.state === "lic") { if (el) el.remove(); return; }
    if (!el) { el = document.createElement("button"); el.type = "button"; el.className = "lic-chip"; el.onclick = () => dialog("app", null); document.body.appendChild(el); }
    el.classList.toggle("warn", !isOk(s) || (s.left || 0) <= 3);
    el.innerHTML = `<i></i>${isOk(s) ? "نسخة تجريبية · متبقي " + s.left + " يوم" : "البرنامج مقفول"}<b>تفعيل</b>`;
  }
  /* الإضافات: كل عنصر في قائمة «الإضافات» له موديول ← يمر عبر البوابة */
  function wrapMenus(n) {
    if (!DIST) return;
    const M = window.__MENUS, A = M && M["الإضافات"];
    if (!A) { if ((n || 0) < 20) setTimeout(() => wrapMenus((n || 0) + 1), 500); return; }
    const byT = {}; Object.keys(MODS).forEach(k => { if (!MODS[k].app) byT[MODS[k].t] = k; });
    A.forEach(i => { const k = i && byT[i.t]; if (!k || k === "quota" || i.__lic || typeof i.run !== "function") return; const f = i.run; i.run = function () { const a = arguments, me = this; return gate(k, () => f.apply(me, a)); }; i.__lic = 1; });
    if ((n || 0) < 6) setTimeout(() => wrapMenus((n || 0) + 1), 1500);   /* عناصر تُضاف لاحقاً (مثل كوتة الأصناف) */
    paintMenus();
  }
  /* ================= ✦ (2026-11-22) «الإضافات» في نسخة العملاء =================
     ▸ القائمة العلوية «الإضافات» تُظهر فقط الإضافات المفعّلة (كود أو تجربة جارية) + «الخصائص» (والعناصر المجانية).
     ▸ الإضافة المقفولة تُفتح من بطاقتها فقط في «الخصائص ← الإضافات» ← نافذة التفعيل ← بعدها تظهر في القائمة.
     ▸ شارة حالة على كل بطاقة: مفعّلة · تجربة N يوم · مقفلة. */
  const CARD = { disc: "idisc", qdisc: "qdisc", bonus: "bonus", extra: "extra", invdisc: "invdisc", slices: "slices", coupon: "coupon", loyal: "loyal", don: "donate", quota: "quota", inst: "inst" };
  const MASTER = [];
  const modOfItem = i => { if (!i || !i.t) return ""; const k = Object.keys(MODS).find(m => !MODS[m].app && MODS[m].t === i.t); return k || ""; };
  const liteLock = () => !!(window.ANOUER_LITE && ANOUER_LITE.on && ANOUER_LITE.pro && !ANOUER_LITE.pro());
  function syncAdds() {
    if (!DIST || !READY) return;
    const A = window.__MENUS && __MENUS["الإضافات"]; if (!A) return;
    A.forEach((i, ix) => { if (MASTER.indexOf(i) < 0 && !MASTER.some(x => x.t === i.t)) { const prev = ix > 0 ? MASTER.indexOf(A[ix - 1]) : -1; MASTER.splice(prev + 1, 0, i); } });
    const want = MASTER.filter(i => { const m = modOfItem(i); return !m || (!liteLock() && isOk(status(m))); });
    const pi = want.findIndex(i => i.t === "الخصائص"); if (pi >= 0 && pi !== want.length - 1) want.push(want.splice(pi, 1)[0]);
    if (want.length === A.length && want.every((x, k) => x === A[k])) return;
    A.splice(0, A.length, ...want);
  }
  function openMod(mod) {
    syncAdds();
    const it = MASTER.find(i => modOfItem(i) === mod);
    if (it && typeof it.run === "function") { try { it.run(); } catch (e) { } }
  }
  function cardBadges(root) {
    if (!DIST || !READY) return;
    (root || document).querySelectorAll(".pp-card[data-a]").forEach(c => {
      const mod = CARD[c.dataset.a]; if (!mod || !MODS[mod]) return;
      const s = liteLock() ? { state: "pro" } : status(mod);
      const st = s.state === "lic" ? "on" : s.state === "trial" ? "tr" : "off";
      const txt = s.state === "pro" ? "يحتاج PRO" : st === "on" ? "مفعّلة" : st === "tr" ? "تجربة · " + s.left + " يوم" : MODS[mod].noTrial ? "مقفلة · كود تفعيل" : "مقفلة · جرّبها شهر";
      let b = c.querySelector(".lic-cb"); if (!b) { b = document.createElement("span"); b.className = "lic-cb"; c.appendChild(b); }
      if (b.dataset.k !== st + txt) { b.dataset.k = st + txt; b.className = "lic-cb " + st; b.innerHTML = `<i>${st === "on" ? "✓" : st === "tr" ? "⏳" : "🔒"}</i>${esc(txt)}`; }
      c.classList.toggle("lic-locked", st === "off"); c.classList.add("lic-card");
      c.querySelectorAll(".ok,.pa,.loy-badge").forEach(x => { x.style.display = "none"; });
    });
    const h = document.querySelector(".pp-addw .pp-adh");
    if (h && !h.querySelector(".lic-adtip")) h.insertAdjacentHTML("afterbegin", '<div class="lic-adtip"><b>✦ الإضافات</b><span>اضغط على بطاقة الإضافة المقفلة لتفعيلها بكودها — بعد التفعيل تظهر وحدها في قائمة «الإضافات»</span></div>');
  }
  if (DIST) {
    /* البطاقة: قبل أي معالج آخر (حتى بطاقات الولاء والتبرعات) */
    window.addEventListener("click", e => {
      const c = e.target && e.target.closest && e.target.closest(".pp-card[data-a]"); if (!c) return;
      const mod = CARD[c.dataset.a]; if (!mod || !MODS[mod]) return;
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      const go = () => { syncAdds(); paintMenus(); cardBadges(); openMod(mod); };
      if (liteLock()) { if (window.ANOUER_LITE && ANOUER_LITE.gate) ANOUER_LITE.gate(MODS[mod].t, go); return; }
      init().then(() => { if (isOk(status(mod))) go(); else dialog(mod, go); });
    }, true);
    new MutationObserver(() => { if (document.querySelector(".pp-card[data-a]:not(.lic-card)")) cardBadges(); }).observe(document.documentElement, { childList: true, subtree: true });
    setInterval(() => { syncAdds(); if (document.querySelector(".pp-addw")) cardBadges(); }, 2500);
  }
  window.ANOUER_LIC = { gate, ok, status: mod => (init(), status(mod)), dialog: (mod, run) => init().then(() => dialog(mod, run)), serial: mod => init().then(() => serial(mod)), init, mods: MODS, register: (k, o) => { MODS[k] = o;
    /* تسجيل متأخر (ملف يُحمَّل قبل/بعد init): نعيد التحقق من كود هذا الموديول المحفوظ */
    if (READY) READY = READY.then(d => (D.lic[k] && D.lic[k].code ? verify(k, D.lic[k].code).then(v => { if (v) VER[k] = v; }) : null)).then(() => { paintMenus(); return D; }, () => D); } };
  setTimeout(init, 300);
  if (DIST) { if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => { appStart(); wrapMenus(); }); else { appStart(); wrapMenus(); } }
})();
