/* ANOUER — «تصميم التقارير»: مدير التصاميم (مطابق Dexef Report Designer) + نافذة المعاينة (Print Preview)
   الجذر: التعاملات ، الباركود ، التقارير المضافة ، التقارير المعدلة ، الأقسام — الفرع أعلى اليسار و«جديد» أعلى اليمين.
   التعاملات ← النماذج (Default Template …) ← بطاقات التصاميم بصورة مصغّرة حية ✔ = التصميم الافتراضي للتعامل.
   قائمة البطاقة: معاينة ، تعديل التصميم ، دمج (استيراد ملف تصميم) ، حفظ التصميم (تصدير) ، حذف ، الخصائص. */
(function () {
  "use strict";
  if (window.ANOUER_RDM) return;
  const RD = window.ANOUER_RD; if (!RD) return;
  const esc = RD.esc, clone = RD.clone;
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const T = (m, k) => { try { toast(m, k || "i"); } catch (e) { console.log(m); } };
  const today = () => { const d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };
  const BR = () => (window.__FH && window.__FH.BR && window.__FH.BR.length ? window.__FH.BR : ["الفرع الرئيسى"]);
  let ME = null;
  const me = () => ME ? Promise.resolve(ME) : (HOST() ? Anouer.call("auth.me").then(m => (ME = m || {})).catch(() => (ME = {})) : Promise.resolve(ME = { Username: "ANOUER", Permissions: ["users.manage"] }));
  const isAdmin = () => !ME || !HOST() || (ME.Permissions || []).indexOf("users.manage") >= 0 || /admin/i.test(ME.RoleCode || "");
  const myName = () => (ME && (ME.Username || ME.FullName)) || "";

  /* ------------------------------------------------------------------ أيقونات */
  const IC = {
    fold: '<svg viewBox="0 0 64 52"><path d="M3 8a5 5 0 0 1 5-5h16l7 7h25a5 5 0 0 1 5 5v4H3z" fill="#f6a04d"/><path d="M8 19h53l-6 27a4 4 0 0 1-4 3H5a3 3 0 0 1-3-3.6z" fill="#f47c20"/></svg>',
    up: '<svg viewBox="0 0 20 20"><path d="M10 17V4M4 9.5L10 3.5l6 6" fill="none" stroke="#3b9b3b" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    logo: '<svg viewBox="0 0 16 16"><path d="M2 13.5L11.5 4l2 2L4 15.5H2z" fill="#3f51b5"/><path d="M3 3l10 10" stroke="#9fa8da" stroke-width="2.4" stroke-linecap="round"/></svg>',
    view: '<svg viewBox="0 0 16 16"><path d="M1.5 4.5h5l1.5 1.5h6.5v7.5h-13z" fill="#f6a04d"/></svg>',
    edit: '<svg viewBox="0 0 16 16"><rect x="2" y="9" width="2.6" height="5" fill="#e53935"/><rect x="6" y="5" width="2.6" height="9" fill="#43a047"/><rect x="10" y="2" width="2.6" height="12" fill="#1e88e5"/></svg>',
    merge: '<svg viewBox="0 0 16 16"><rect x="2" y="2" width="12" height="12" fill="#43a047"/><path d="M4 5h8M4 8h8M4 11h8" stroke="#fff" stroke-width="1.2"/></svg>',
    save: '<svg viewBox="0 0 16 16"><path d="M2 2h10l2 2v10H2z" fill="none" stroke="#333" stroke-width="1.4"/><rect x="5" y="2.7" width="5" height="3.3" fill="#333"/><rect x="4.5" y="9" width="7" height="4" fill="#333"/></svg>',
    del: '<svg viewBox="0 0 16 16"><path d="M3 3l10 10M13 3L3 13" stroke="#e53935" stroke-width="2" stroke-linecap="round"/></svg>',
    prop: '<svg viewBox="0 0 16 16"><path d="M8 1.5l1.2 1.8 2.1-.5.4 2.1 2 .9-.9 2 .9 2-2 .9-.4 2.1-2.1-.5L8 14.5l-1.2-1.8-2.1.5-.4-2.1-2-.9.9-2-.9-2 2-.9.4-2.1 2.1.5z" fill="#1e6fd0"/><circle cx="8" cy="8" r="2.3" fill="#fff"/></svg>',
    tx: '<svg viewBox="0 0 48 48"><rect x="4" y="6" width="40" height="36" rx="2" fill="#1f73d1"/><rect x="8" y="12" width="12" height="24" fill="#fff" opacity=".9"/><g fill="#fff"><rect x="23" y="12" width="17" height="3"/><rect x="23" y="18" width="17" height="3"/><rect x="23" y="24" width="17" height="3"/><rect x="23" y="30" width="17" height="3"/></g></svg>',
    bc: '<svg viewBox="0 0 48 48"><g fill="#2d3e57"><rect x="4" y="9" width="12" height="9"/><rect x="18" y="9" width="12" height="9"/><rect x="32" y="9" width="12" height="9"/><rect x="4" y="20" width="12" height="9"/><rect x="18" y="20" width="12" height="9"/><rect x="32" y="20" width="12" height="9"/><rect x="4" y="31" width="12" height="9"/><rect x="18" y="31" width="12" height="9"/><rect x="32" y="31" width="12" height="9"/></g></svg>',
    rep: '<svg viewBox="0 0 48 48"><ellipse cx="24" cy="11" rx="14" ry="5" fill="#2d3e57"/><path d="M10 11v9c0 2.8 6.3 5 14 5s14-2.2 14-5v-9c0 2.8-6.3 5-14 5s-14-2.2-14-5z" fill="#2d3e57"/><path d="M10 23v9c0 2.8 6.3 5 14 5s14-2.2 14-5v-9c0 2.8-6.3 5-14 5s-14-2.2-14-5z" fill="#2d3e57"/></svg>',
    tpl: '<svg viewBox="0 0 48 48"><g fill="#2d3e57"><rect x="6" y="6" width="8" height="8" rx="1.5"/><rect x="18" y="6" width="8" height="8" rx="1.5"/><rect x="30" y="6" width="8" height="8" rx="1.5"/><rect x="6" y="18" width="8" height="8" rx="1.5"/><rect x="18" y="18" width="8" height="8" rx="1.5"/><rect x="30" y="18" width="8" height="8" rx="1.5"/><rect x="6" y="30" width="8" height="8" rx="1.5"/><rect x="18" y="30" width="8" height="8" rx="1.5"/></g><path d="M36 26l-6 10h5l-3 9 8-12h-5l3-7z" fill="#2d3e57"/></svg>',
    sec: '<svg viewBox="0 0 48 48"><rect x="11" y="6" width="26" height="36" rx="3" fill="#7a5a3a"/><rect x="15" y="10" width="18" height="28" fill="#fff"/><rect x="18" y="3" width="12" height="7" rx="2" fill="#5c4128"/><path d="M18 24l4.5 4.5L31 19" fill="none" stroke="#7a5a3a" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    warn: '<svg viewBox="0 0 40 40"><rect x="4" y="5" width="32" height="24" rx="3" fill="#cfe2f8"/><rect x="18" y="9" width="4" height="12" rx="1.5" fill="#1e6fd0"/><circle cx="20" cy="25" r="2.2" fill="#1e6fd0"/><rect x="11" y="31" width="18" height="4" rx="2" fill="#1e6fd0"/></svg>',
    pic1: '<svg viewBox="0 0 130 110"><rect x="10" y="10" width="92" height="64" rx="4" fill="#e8eefb"/><rect x="18" y="20" width="36" height="5" rx="2" fill="#b8c6ef"/><rect x="18" y="30" width="56" height="4" rx="2" fill="#d2dbf5"/><rect x="18" y="38" width="48" height="4" rx="2" fill="#d2dbf5"/><path d="M62 70V48h8v22zM76 70V40h8v30zM90 70V52h8v18z" fill="#8fa5e8"/><circle cx="104" cy="44" r="7" fill="#f0b8a0"/><path d="M96 98l4-34h10l4 34z" fill="#3a4a7a"/><path d="M98 62q6-8 14 0v12H98z" fill="#5b7be0"/><rect x="14" y="80" width="50" height="22" rx="3" fill="#fff" stroke="#c8d3f0"/><path d="M22 98c4-10 8-14 12-6s7-4 10-2" fill="none" stroke="#5b7be0" stroke-width="2"/></svg>'
  };

  /* ------------------------------------------------------------------ حوارات (شكل DEXEF) */
  let DLG = 0;
  function dlg(o) {
    const ov = document.createElement("div"); ov.className = "rdm-dov"; ov.style.zIndex = 10200 + (++DLG);
    ov.innerHTML = `<div class="rdm-dlg${o.cls ? " " + o.cls : ""}" style="width:${o.w || 440}px" role="dialog" aria-modal="true"><button type="button" class="rdm-dx" title="إغلاق">✕</button>${o.title ? `<div class="rdm-dt">${esc(o.title)}</div>` : ""}<div class="rdm-db"></div>${o.buttons ? '<div class="rdm-df"></div>' : ""}</div>`;
    document.body.appendChild(ov);
    const box = ov.firstChild, body = box.querySelector(".rdm-db");
    if (typeof o.body === "string") body.innerHTML = o.body; else if (o.body) body.appendChild(o.body);
    const close = () => { ov.remove(); DLG--; window.removeEventListener("keydown", key, true); if (o.onClose) o.onClose(); };
    const key = e => { if (ov !== document.querySelector(".rdm-dov:last-of-type")) return; if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); close(); } else if (e.key === "Enter" && o.enter && !/TEXTAREA|BUTTON/.test(e.target.tagName)) { e.preventDefault(); e.stopImmediatePropagation(); o.enter(api); } };
    window.addEventListener("keydown", key, true);
    box.querySelector(".rdm-dx").onclick = close;
    ov.addEventListener("keydown", e => e.stopPropagation());
    const api = { ov, box, body, close, $: s => box.querySelector(s), $$: s => Array.from(box.querySelectorAll(s)) };
    if (o.buttons) {
      const f = box.querySelector(".rdm-df");
      o.buttons.forEach(b => { const e = document.createElement("button"); e.type = "button"; e.className = "rdm-btn " + (b.cls || "blue"); e.textContent = b.t; e.onclick = () => b.fn(api); f.appendChild(e); });
    }
    setTimeout(() => { const f = box.querySelector("input:not([disabled]),select:not([disabled]),.rdm-btn"); if (f && o.focus !== false) try { f.focus(); } catch (e) { } }, 30);
    return api;
  }
  /* رسالة بأيقونة «!» — أزرار: [{t,cls,fn}] */
  function msg(text, btns) {
    btns = btns || [{ t: "موافق", cls: "green" }];
    return dlg({ w: 420, cls: "rdm-msg", body: `<div class="rdm-mb"><span class="rdm-mi">${IC.warn}</span><p>${esc(text)}</p></div>`, buttons: btns.map(b => ({ t: b.t, cls: b.cls, fn: d => { d.close(); if (b.fn) b.fn(); } })), enter: d => { d.close(); if (btns[0].fn) btns[0].fn(); } });
  }
  const ask = (text, yes, no) => msg(text, [{ t: "لا", cls: "blue", fn: no }, { t: "نعم", cls: "green", fn: yes }]);
  RD.ui = { dlg, msg, ask, IC };

  /* ================================================================== نافذة «اختيار التصميم» عند الطباعة (مثل DEXEF)
     تظهر عند الحفظ/الطباعة إذا كان للتعامل أكثر من تصميم ولا يوجد تصميم افتراضى ✔
     • نقرة مزدوجة / Enter / موافق: طباعة بالتصميم المحدد — إغلاق / Esc: بدون طباعة
     • ↑ ↓ للتنقل ، 1..9 اختيار مباشر ، Ctrl+↑ / Ctrl+↓ أو السحب بالفأرة: تغيير الترتيب (يُحفظ)
     • 👁 معاينة بالفاتورة الحالية ، «اجعله الافتراضى» حتى لا تظهر النافذة مرة أخرى */
  const LASTK = "anouer.rd.last";
  const lastGet = tx => { try { return (JSON.parse(localStorage.getItem(LASTK) || "{}") || {})[tx || "_"] || ""; } catch (e) { return ""; } };
  const lastPut = (tx, id) => { try { const o = JSON.parse(localStorage.getItem(LASTK) || "{}") || {}; o[tx || "_"] = id; localStorage.setItem(LASTK, JSON.stringify(o)); } catch (e) { } };
  RD.chooseDesign = function (list, o) {
    o = o || {};
    return new Promise(res => {
      /* ✦ وضع «اختيار الوصل» (F4 / موافق بعد دفع العميل): ★ حتى تصميمين مفضّلين يظهران وحدهما ، ⚡ تصميم F6 */
      const all = list.slice(), PR = o.choose && RD.rcptPref ? RD.rcptPref : null;
      let pref = PR ? PR.get(o.tx) : { fav: [], f6: "" }, showAll = false;
      const favIds = () => pref.fav.filter(id => all.some(i => i.id === id));
      const f6Id = () => (RD.f6Item && PR ? (RD.f6Item(all, o.tx) || {}).id : "") || "";
      const view = () => (PR && !showAll && favIds().length) ? favIds().map(id => all.find(i => i.id === id)) : all.slice();
      let items = view(), sel = Math.max(0, items.findIndex(i => i.id === lastGet(o.tx))), done = false, dragAt = 0;
      if (o.choose && sel === 0 && !lastGet(o.tx)) sel = Math.max(0, items.findIndex(i => i.def || i.use));
      const ov = document.createElement("div"); ov.className = "rdc-ov";
      /* ✦ «اختيار الوصل» بعد دفع العميل: ملخص الدفع (كاش / أجل) فوق القائمة + «بدون طباعة» */
      const S = o.summary, F = v => (Math.round((+v || 0) * 100) / 100).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      const sumHtml = S ? `<div class="rdc-sum" data-st="${esc(S.st || "")}"><div class="rdc-sh"><span class="rdc-sd">${S.st === "cash" ? "كاش" : "أجل"}</span><b>${esc(S.cust || "")}</b>${S.no ? `<em>رقم ${esc(S.no)}</em>` : ""}</div>
          <div class="rdc-sg"><span><i>الإجمالي</i><b>${F(S.total)}</b></span><span><i>المدفوع</i><b class="p">${F(S.paid)}</b></span><span><i>${S.rest > 0 ? "على الحساب" : "الباقي"}</i><b class="r">${F(S.rest)}</b></span></div></div>` : "";
      ov.innerHTML = `<div class="rdc-box${S ? " rcpt" : ""}${PR ? " rcx" : ""}" role="dialog" aria-modal="true" dir="rtl">
        <div class="rdc-tb"><span class="rdc-tt">${esc(o.review === "print" ? "طباعة التعامل" : o.review ? "عرض للطباعة" : o.choose ? "اختيار الوصل" : o.tx ? "طباعة " + o.tx : "اختيار التصميم")}</span><button type="button" class="rdc-x" title="إغلاق (Esc)">✕</button></div>
        <div class="rdc-body">${sumHtml}<div class="rdc-list" tabindex="0"><div class="rdc-hd"><span>الاسم</span>${PR ? '<em class="rdc-hint">نقرة = طباعة مباشرة · F4 (حتى 2) · F6 حفظ سريع</em>' : ""}<i title="اسحب الصف لأعلى أو لأسفل لتغيير الترتيب — أو Ctrl+↑ / Ctrl+↓">⇅</i></div><div class="rdc-rows"></div></div>
          ${o.choose ? "" : '<label class="rdc-def"><input type="checkbox"><span>اجعله التصميم الافتراضى (عدم ظهور هذه النافذة)</span></label>'}</div>
        ${o.choose ? '<button type="button" class="rdc-dlg" title="يطبع التصميم المحدد بعد اختيار الطابعة وعدد النسخ والوجهين (Ctrl+P)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9V3h12v6"/><rect x="2.5" y="9" width="19" height="8.5" rx="2"/><path d="M6 14h12v7H6z"/></svg>اختيار الطابعة… <kbd>Ctrl+P</kbd></button>' : ""}<div class="rdc-ft"><button type="button" class="rdc-ok">${o.review === "preview" ? "عرض" : o.choose ? "طباعة" : "موافق"}</button><button type="button" class="rdc-cl">${o.review ? "إغلاق" : o.choose ? "بدون طباعة" : "إغلاق"}</button></div></div>`;
      document.body.appendChild(ov);
      const box = ov.firstChild, rowsEl = box.querySelector(".rdc-rows"), listEl = box.querySelector(".rdc-list");
      /* حماية من الطباعة بالغلط: النافذة تنفتح تحت الفأرة مباشرة بعد «موافق» — نقرة ثانية أو Enter مكرر
         (أو ضغطة بدأت قبل ظهورها) ما تطبعش. بعد 0.6 ثانية تخدم عادي */
      const openAt = performance.now(), ARMMS = 600, early = () => performance.now() - openAt < ARMMS;
      let downOk = false;
      box.classList.add("rdc-arm"); box.style.setProperty("--rdc-arm", ARMMS + "ms"); setTimeout(() => box.classList.remove("rdc-arm"), ARMMS);
      ov.addEventListener("pointerdown", e => { downOk = !early(); if (!downOk && e.target !== ov) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
      ["click", "dblclick"].forEach(ev => ov.addEventListener(ev, e => { if (!downOk || early()) { e.preventDefault(); e.stopImmediatePropagation(); } }, true));
      const draw = () => {
        const fv = favIds(), f6 = f6Id(), filt = items.length < all.length; box.classList.toggle("flt", filt);
        rowsEl.innerHTML = items.map((it, i) => `<div class="rdc-r${i === sel ? " on" : ""}${fv.indexOf(it.id) >= 0 ? " fav" : ""}" data-i="${i}" title="${esc([it.paper, it.printer ? "الطابعة : " + it.printer : "الطابعة الافتراضية", (it.copies || 1) > 1 ? it.copies + " نسخ" : ""].filter(Boolean).join(" — "))}"><b class="rdc-n">${i < 9 ? i + 1 : ""}</b><span class="rdc-t">${esc(it.name)}</span>${PR ? `<button type="button" class="rdc-st${fv.indexOf(it.id) >= 0 ? " on" : ""}" title="${fv.indexOf(it.id) >= 0 ? "إزالة من «حفظ وطباعة F4»" : "أضفه لـ «حفظ وطباعة F4» — يظهر وحده عند F4 (حتى تصميمين)"}">F4</button><button type="button" class="rdc-f6${it.id === f6 ? " on" : ""}" title="${it.id === f6 ? "هذا تصميم «حفظ سريع F6»" : "اجعله تصميم «حفظ سريع F6»"}">⚡F6</button>` : ""}<button type="button" class="rdc-pv" title="معاينة (F4)"><svg viewBox="0 0 24 24"><path d="M12 5C6.5 5 2.3 9.1 1 12c1.3 2.9 5.5 7 11 7s9.7-4.1 11-7c-1.3-2.9-5.5-7-11-7zm0 11.5A4.5 4.5 0 1 1 12 7.5a4.5 4.5 0 0 1 0 9zm0-7a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z"/></svg></button></div>`).join("");
        if (PR && (filt || (showAll && fv.length))) rowsEl.insertAdjacentHTML("beforeend", `<div class="rdc-more" data-more="1">${filt ? "عرض كل التصاميم (" + all.length + ")" : "عرض تصاميم F4 فقط"}</div>`);
        const on = rowsEl.querySelector(".rdc-r.on"); if (on) on.scrollIntoView({ block: "nearest" });
      };
      const reView = keepId => { items = view(); const k = items.findIndex(i => i.id === keepId); sel = k >= 0 ? k : 0; draw(); };
      draw();
      setTimeout(() => { try { listEl.focus(); } catch (e) { } }, 20);
      const finish = r => {
        if (done) return; done = true;
        window.removeEventListener("keydown", key, true); ov.remove();
        if (r && r.item) {
          lastPut(o.tx, r.item.id);
          if ((box.querySelector(".rdc-def input") || {}).checked && typeof o.onDefault === "function" && o.onDefault(r.item) === true) {
            /* تصميم استوديو: يُفعَّل عليه «استعمل هذا التصميم في طباعة الفواتير» */
            T("«" + r.item.name + "» هو التصميم الإفتراضى لـ" + (o.tx || "الطباعة") + " — لإظهار نافذة الاختيار مرة أخرى: ألغِ «استعمل هذا التصميم في طباعة الفواتير» في الاستوديو", "s");
          } else if ((box.querySelector(".rdc-def input") || {}).checked) {
            const idx = RD.idx(); idx.items.forEach(x => { if (x !== r.item && (x.kind || "tx") === (r.item.kind || "tx") && x.tx === r.item.tx && x.tpl === r.item.tpl && (x.branch || "") === (r.item.branch || "")) x.def = false; });
            r.item.def = true; RD.saveIdx().then(() => T("«" + r.item.name + "» هو التصميم الإفتراضى لـ" + (r.item.tx || "الباركود"), "s"));
          }
        }
        res(r || { cancel: true });
      };
      const ok = () => items[sel] && finish({ item: items[sel] });
      const move = (i, to) => {
        if (to < 0 || to >= items.length || i === to || items.length < all.length) return;   /* الترتيب من القائمة الكاملة فقط */
        const [it] = items.splice(i, 1); items.splice(to, 0, it); sel = to; draw();
        RD.reorder(items.map(x => x.id)).catch(() => { });
      };
      const key = e => {
        if (!ov.isConnected) return;
        if ((e.repeat || early()) && (e.key === "Enter" || e.key === " " || e.key === "F4" || /^[1-9]$/.test(e.key))) { e.preventDefault(); e.stopImmediatePropagation(); return; }
        if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); finish(null); }
        else if (e.key === "Enter") { e.preventDefault(); e.stopImmediatePropagation(); ok(); }
        else if (e.key === "ArrowDown" || e.key === "ArrowUp") {
          e.preventDefault(); e.stopImmediatePropagation(); const d = e.key === "ArrowDown" ? 1 : -1;
          if (e.ctrlKey || e.altKey) move(sel, sel + d); else { sel = Math.min(items.length - 1, Math.max(0, sel + d)); draw(); }
        }
        else if (e.key === "Home" || e.key === "End") { e.preventDefault(); e.stopImmediatePropagation(); const to = e.key === "Home" ? 0 : items.length - 1; if (e.ctrlKey) move(sel, to); else { sel = to; draw(); } }
        else if (/^[1-9]$/.test(e.key) && !e.ctrlKey && !e.altKey) { const i = +e.key - 1; if (items[i]) { e.preventDefault(); e.stopImmediatePropagation(); sel = i; draw(); ok(); } }
        else if (o.choose && e.ctrlKey && !e.altKey && (e.code === "KeyP" || e.key === "p")) { e.preventDefault(); e.stopImmediatePropagation(); if (items[sel]) finish({ item: items[sel], mode: "dialog" }); }
        else if (e.key === "F4" || (e.key === " " && e.target === listEl)) { e.preventDefault(); e.stopImmediatePropagation(); if (items[sel]) finish({ item: items[sel], mode: "preview" }); }
        else e.stopPropagation();
      };
      window.addEventListener("keydown", key, true);
      box.querySelector(".rdc-x").onclick = () => finish(null);
      box.querySelector(".rdc-cl").onclick = () => finish(null);
      box.querySelector(".rdc-ok").onclick = ok;
      const dlg = () => items[sel] && finish({ item: items[sel], mode: "dialog" });
      if (box.querySelector(".rdc-dlg")) box.querySelector(".rdc-dlg").onclick = dlg;
      ov.addEventListener("mousedown", e => { if (e.target === ov) { box.classList.remove("shake"); void box.offsetWidth; box.classList.add("shake"); } });
      rowsEl.addEventListener("dblclick", e => { const r = e.target.closest(".rdc-r"); if (r && !e.target.closest(".rdc-pv,.rdc-st,.rdc-f6")) { sel = +r.dataset.i; ok(); } });
      rowsEl.addEventListener("click", e => {
        if (PR) {
          if (e.target.closest("[data-more]")) { showAll = !showAll; reView(items[sel] && items[sel].id); return; }
          const r0 = e.target.closest(".rdc-r"), it = r0 && items[+r0.dataset.i];
          if (it && e.target.closest(".rdc-st")) {
            let f = favIds(); const k = f.indexOf(it.id);
            if (k >= 0) f.splice(k, 1); else { f.push(it.id); if (f.length > 2) { const out = all.find(x => x.id === f.shift()); T("F4 تصميمان فقط — أُزيل «" + (out ? out.name : "") + "»", "i"); } }
            pref = PR.set(o.tx, { fav: f }); if (!f.length) showAll = false; else showAll = true;
            if (f.indexOf(it.id) >= 0) T("F4 «حفظ وطباعة» يعرض: " + f.map(id => (all.find(x => x.id === id) || {}).name).filter(Boolean).join(" + "), "s");
            reView(it.id); return;
          }
          if (it && e.target.closest(".rdc-f6")) { pref = PR.set(o.tx, { f6: it.id }); T("⚡ حفظ سريع F6 يطبع دائماً بـ «" + it.name + "»", "s"); draw(); return; }
        }
        const pv = e.target.closest(".rdc-pv"); const r = e.target.closest(".rdc-r"); if (!r) return; sel = +r.dataset.i; if (pv) { finish({ item: items[sel], mode: "preview" }); return; }
        /* ✦ F4 «حفظ وطباعة»: نقرة واحدة على التصميم (مثل «كاشير 2») = طباعة مباشرة */
        if (PR && !o.review && Date.now() - dragAt > 350) { finish({ item: items[sel] }); return; }
        rowsEl.querySelectorAll(".rdc-r").forEach(x => x.classList.toggle("on", +x.dataset.i === sel)); });
      /* السحب لأعلى/لأسفل لتغيير الترتيب */
      rowsEl.addEventListener("pointerdown", e => {
        const r = e.target.closest(".rdc-r"); if (!r || e.button !== 0 || e.target.closest(".rdc-pv,.rdc-st,.rdc-f6")) return;
        const from = +r.dataset.i, y0 = e.clientY, rows = Array.from(rowsEl.children), H = r.offsetHeight;
        let dragging = false, to = from, ghost = null;
        const mv = ev => {
          const dy = ev.clientY - y0;
          if (!dragging && Math.abs(dy) < 5) return;
          if (!dragging) { dragging = true; r.classList.add("drag"); ghost = r.cloneNode(true); ghost.className = "rdc-r rdc-ghost"; ghost.style.width = r.offsetWidth + "px"; document.body.appendChild(ghost); rowsEl.classList.add("dragging"); try { r.setPointerCapture(e.pointerId); } catch (x) { } }
          const rb = rowsEl.getBoundingClientRect();
          ghost.style.left = rb.left + "px"; ghost.style.top = (ev.clientY - H / 2) + "px";
          to = Math.max(0, Math.min(rows.length - 1, Math.floor((ev.clientY - rb.top + rowsEl.scrollTop) / H)));
          rows.forEach((x, i) => { x.style.transform = ""; if (i === from) return; if (from < to && i > from && i <= to) x.style.transform = `translateY(-${H}px)`; if (from > to && i < from && i >= to) x.style.transform = `translateY(${H}px)`; });
          if (ev.clientY < rb.top + 8) rowsEl.scrollTop -= 6; else if (ev.clientY > rb.bottom - 8) rowsEl.scrollTop += 6;
        };
        const up = () => {
          window.removeEventListener("pointermove", mv, true); window.removeEventListener("pointerup", up, true);
          if (!dragging) return;
          dragAt = Date.now(); if (ghost) ghost.remove(); rowsEl.classList.remove("dragging"); rows.forEach(x => { x.style.transform = ""; });
          if (to !== from) move(from, to); else draw();
        };
        window.addEventListener("pointermove", mv, true); window.addEventListener("pointerup", up, true);
      });
    });
  };
  function ctx(x, y, items) {
    document.querySelectorAll(".rdm-ctx").forEach(e => e.remove());
    const m = document.createElement("div"); m.className = "rdm-ctx";
    m.innerHTML = items.map((it, i) => it === "-" ? '<div class="sep"></div>' : `<button type="button" data-i="${i}"${it.dis ? " disabled" : ""}><span>${esc(it.t)}</span><i>${it.ic || ""}</i></button>`).join("");
    document.body.appendChild(m);
    const r = m.getBoundingClientRect();
    m.style.left = Math.max(4, Math.min(x - r.width, innerWidth - r.width - 4)) + "px";
    m.style.top = Math.max(4, Math.min(y, innerHeight - r.height - 4)) + "px";
    const close = () => { m.remove(); document.removeEventListener("mousedown", out, true); window.removeEventListener("keydown", k, true); };
    const out = e => { if (!m.contains(e.target)) close(); };
    const k = e => { if (e.key === "Escape") { e.stopImmediatePropagation(); close(); } };
    setTimeout(() => { document.addEventListener("mousedown", out, true); window.addEventListener("keydown", k, true); }, 0);
    m.addEventListener("click", e => { const b = e.target.closest("button[data-i]"); if (!b) return; close(); const it = items[+b.dataset.i]; if (it && it.fn) it.fn(); });
    return m;
  }
  RD.ui.ctx = ctx;

  /* ------------------------------------------------------------------ عناصر النماذج */
  const opt = (list, v) => list.map(o => { const a = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(a[0])}"${String(a[0]) === String(v) ? " selected" : ""}>${esc(a[1])}</option>`; }).join("");
  const fld = (lbl, inner, req, cls) => `<div class="rdm-f${cls ? " " + cls : ""}"><label>${esc(lbl)}</label><div class="rdm-fi">${req ? '<i class="rq">*</i>' : '<i></i>'}${inner}</div></div>`;
  const spin = (k, v, o) => `<span class="rdm-spin"><input data-k="${k}" type="number" value="${esc(v)}"${o && o.min != null ? ` min="${o.min}"` : ""}${o && o.step ? ` step="${o.step}"` : ""}${o && o.dis ? " disabled" : ""}></span>`;
  function printerSel(k, v) {
    return `<select data-k="${k}" class="rdm-prn"><option value="">(الطابعة الافتراضية)</option>${v ? `<option value="${esc(v)}" selected>${esc(v)}</option>` : ""}</select>`;
  }
  function fillPrinters(root, v) {
    RD.printers().then(p => {
      root.querySelectorAll(".rdm-prn").forEach(s => {
        const cur = s.value || v || "";
        const list = (p.printers || []).slice(); if (cur && list.indexOf(cur) < 0) list.unshift(cur);
        s.innerHTML = `<option value="">(الطابعة الافتراضية${p.def ? " : " + esc(p.def) : ""})</option>` + list.map(n => `<option value="${esc(n)}"${n === cur ? " selected" : ""}>${esc(n)}</option>`).join("");
      });
    });
  }
  const vals = root => { const o = {}; root.querySelectorAll("[data-k]").forEach(e => { o[e.dataset.k] = e.type === "checkbox" ? e.checked : e.type === "number" ? +e.value : e.value; }); return o; };
  const visibleTpls = () => (RD.idx().tpls || []).filter(t => t.perm !== "me" || !t.owner || t.owner === myName());

  /* ------------------------------------------------------------------ الصور المصغّرة */
  const THUMB = {};
  function thumbHTML(it, d) {
    try {
      const data = Object.assign({ company: null }, RD.sampleData(d));
      return RD.company().then(co => {
        data.company = co;
        const res = RD.render(d, data);
        const p = res.pages[0]; if (!p) return "";
        const Wpx = p.w * RD.PX, Hpx = p.h * RD.PX, box = [150, 128], s = Math.min(box[0] / Wpx, box[1] / Hpx);
        return `<div class="rdm-th" style="width:${Wpx * s}px;height:${Math.min(Hpx * s, box[1])}px"><div style="transform:scale(${s});transform-origin:0 0;width:${Wpx}px">${p.html}</div></div>`;
      });
    } catch (e) { return Promise.resolve(""); }
  }
  function loadThumb(it, el) {
    const k = it.id + ":" + (it.updated || it.created || "");
    if (THUMB[k] != null) { el.innerHTML = THUMB[k] || IC.pic1; return; }
    RD.getDesign(it).then(d => d ? thumbHTML(it, d) : "").then(h => { THUMB[k] = h; if (el.isConnected) el.innerHTML = h || IC.pic1; }).catch(() => { if (el.isConnected) el.innerHTML = IC.pic1; });
  }
  RD.dropThumb = id => Object.keys(THUMB).forEach(k => { if (k.indexOf(id + ":") === 0) delete THUMB[k]; });

  /* ================================================================== المدير */
  const ROOT = [["tx", "التعاملات"], ["bc", "الباركود"], ["added", "التقارير المضافة"], ["edited", "التقارير المعدلة"], ["secs", "الأقسام"]];
  let W = null;
  function open() {
    if (W) { W.ov.classList.add("show"); return; }
    Promise.all([RD.load(), me(), RD.company()]).then(() => build());
  }
  function build() {
    const ov = document.createElement("div"); ov.className = "rdm-ov show";
    ov.innerHTML = `<div class="rdm-win" role="dialog" aria-label="Report Designer"><div class="rdm-tb"><span class="rdm-tt">${IC.logo}<b>ANOUER Report Designer</b></span><span class="sp"></span><button type="button" data-w="min" title="تصغير">—</button><button type="button" data-w="max" title="تكبير">☐</button><button type="button" data-w="x" title="إغلاق">✕</button></div>
      <div class="rdm-hd"><button type="button" class="rdm-new">جديد</button><span class="sp"></span><select class="rdm-br" title="الفرع">${opt(BR(), BR()[0])}</select></div>
      <div class="rdm-path"></div><div class="rdm-grid" tabindex="0"></div></div>`;
    document.body.appendChild(ov);
    const st = { path: [], sel: null, branch: BR()[0] };
    W = { ov, st, draw: () => draw() };
    ov.addEventListener("keydown", e => e.stopPropagation());
    const win = ov.querySelector(".rdm-win"), grid = ov.querySelector(".rdm-grid"), path = ov.querySelector(".rdm-path");
    ov.querySelector(".rdm-tb").addEventListener("click", e => {
      const b = e.target.closest("[data-w]"); if (!b) return;
      if (b.dataset.w === "max") win.classList.toggle("max"); else if (b.dataset.w === "min") ov.classList.remove("show"); else close();
    });
    ov.querySelector(".rdm-br").onchange = e => { st.branch = e.target.value; draw(); };
    ov.querySelector(".rdm-new").onclick = () => wizard();
    const key = e => {
      if (!ov.classList.contains("show") || document.querySelector(".rdm-dov,.rdx-ov.show,.rdp-ov.show,.rdm-ctx")) return;
      if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); if (st.path.length) { st.path.pop(); st.sel = null; draw(); } else close(); }
      else if (e.key === "Backspace" && st.path.length && !/INPUT|SELECT/.test(e.target.tagName)) { e.preventDefault(); st.path.pop(); st.sel = null; draw(); }
      else if (e.key === "Enter" && !/INPUT|SELECT|BUTTON/.test(e.target.tagName)) { const c = grid.querySelector(".rdm-c.on"); if (c) { e.preventDefault(); activate(c); } }
      else if (e.key === "Delete" && !/INPUT|SELECT/.test(e.target.tagName)) { const c = grid.querySelector(".rdm-c.on"); if (c && c.dataset.kind === "d") { e.preventDefault(); delItem(itemOf(c)); } }
      else if (/^Arrow/.test(e.key) && !e.ctrlKey && !/INPUT|SELECT/.test(e.target.tagName)) {
        const cs = Array.from(grid.querySelectorAll(".rdm-c")); if (!cs.length) return; e.preventDefault();
        let i = cs.findIndex(c => c.classList.contains("on")); if (i < 0) i = 0;
        else if (e.key === "ArrowLeft") i = Math.min(cs.length - 1, i + 1); else if (e.key === "ArrowRight") i = Math.max(0, i - 1);
        else { const r0 = cs[i].getBoundingClientRect(); const dir = e.key === "ArrowDown" ? 1 : -1; let best = -1, bd = 1e9; cs.forEach((c, j) => { const r = c.getBoundingClientRect(); if ((r.top - r0.top) * dir > 10) { const dd = Math.abs(r.left - r0.left) + Math.abs(r.top - r0.top); if (dd < bd) { bd = dd; best = j; } } }); if (best >= 0) i = best; }
        selCard(cs[i]);
      }
    };
    window.addEventListener("keydown", key, true);
    W.close = () => { window.removeEventListener("keydown", key, true); ov.remove(); W = null; };
    function close() { W.close(); }
    const itemOf = c => RD.idx().items.find(i => i.id === c.dataset.id);
    function selCard(c) { grid.querySelectorAll(".rdm-c.on").forEach(x => x.classList.remove("on")); if (c) { c.classList.add("on"); st.sel = c.dataset.id; c.scrollIntoView({ block: "nearest" }); } }
    function activate(c) {
      if (c.dataset.kind === "f") { st.path.push(c.dataset.id); st.sel = null; draw(); }
      else if (c.dataset.kind === "d") editItem(itemOf(c));
      else if (c.dataset.kind === "s") secProps(RD.idx().secs[+c.dataset.id]);
    }
    grid.addEventListener("click", e => {
      const ck = e.target.closest(".rdm-ck");
      const c = e.target.closest(".rdm-c");
      if (!c) { selCard(null); return; }
      selCard(c);
      if (ck) { e.stopPropagation(); if (c.dataset.kind === "d") setDefault(itemOf(c)); else if (c.dataset.kind === "f" && c.dataset.tpl) setTemplate(c.dataset.tpl); }
    });
    grid.addEventListener("dblclick", e => { const c = e.target.closest(".rdm-c"); if (c && !e.target.closest(".rdm-ck")) activate(c); });
    /* تغيير ترتيب البطاقات بالسحب (يُحفظ ويُطبّق على نافذة اختيار التصميم) */
    const saveOrder = () => { const ids = Array.from(grid.querySelectorAll('.rdm-card[data-kind="d"]')).map(c => c.dataset.id); return RD.reorder(ids).then(() => T("تم حفظ الترتيب", "s")).catch(e => T("لم يُحفظ الترتيب: " + e.message, "e")); };
    grid.addEventListener("pointerdown", e => {
      const c = e.target.closest('.rdm-card[data-kind="d"]'); if (!c || e.button !== 0 || e.target.closest(".rdm-ck")) return;
      const x0 = e.clientX, y0 = e.clientY; let drag = false, ghost = null, mark = null, target = null, after = false;
      const mv = ev => {
        if (!drag && Math.hypot(ev.clientX - x0, ev.clientY - y0) < 8) return;
        if (!drag) {
          drag = true; c.classList.add("rdm-drag"); grid.classList.add("rdm-dragging");
          const r = c.getBoundingClientRect(); ghost = c.cloneNode(true); ghost.classList.add("rdm-ghost"); ghost.style.width = r.width + "px"; ghost.style.height = r.height + "px"; document.body.appendChild(ghost);
          mark = document.createElement("div"); mark.className = "rdm-dropmark"; document.body.appendChild(mark);
        }
        ghost.style.left = (ev.clientX - ghost.offsetWidth / 2) + "px"; ghost.style.top = (ev.clientY - 20) + "px";
        ghost.style.display = "none"; const el = document.elementFromPoint(ev.clientX, ev.clientY); ghost.style.display = "";
        const t = el && el.closest('.rdm-card[data-kind="d"]');
        if (t && t !== c && grid.contains(t)) {
          const r = t.getBoundingClientRect(), rtl = getComputedStyle(grid).direction === "rtl";
          after = rtl ? ev.clientX < r.left + r.width / 2 : ev.clientX > r.left + r.width / 2; target = t;
          mark.style.display = "block"; mark.style.height = r.height + "px"; mark.style.top = r.top + "px";
          mark.style.left = ((rtl ? !after : after) ? r.right + 3 : r.left - 7) + "px";
        } else if (!t) { target = null; mark.style.display = "none"; }
        const gr = grid.getBoundingClientRect(); if (ev.clientY < gr.top + 30) grid.scrollTop -= 12; else if (ev.clientY > gr.bottom - 30) grid.scrollTop += 12;
      };
      const up = () => {
        window.removeEventListener("pointermove", mv, true); window.removeEventListener("pointerup", up, true);
        if (!drag) return;
        ghost.remove(); mark.remove(); c.classList.remove("rdm-drag"); grid.classList.remove("rdm-dragging");
        const swallow = ev => { ev.stopPropagation(); ev.preventDefault(); }; window.addEventListener("click", swallow, { capture: true, once: true }); setTimeout(() => window.removeEventListener("click", swallow, true), 50);
        if (!target) return;
        if (!isAdmin()) { msg("تعديل التصاميم متاح لمدير النظام فقط"); return; }
        target.parentNode.insertBefore(c, after ? target.nextSibling : target);
        selCard(c); saveOrder();
      };
      window.addEventListener("pointermove", mv, true); window.addEventListener("pointerup", up, true);
    });
    // Ctrl + الأسهم: تحريك البطاقة المحددة
    const moveKey = e => {
      if (!W || !ov.isConnected || !e.ctrlKey || !/^Arrow(Left|Right|Up|Down)$/.test(e.key) || /INPUT|SELECT|TEXTAREA/.test(e.target.tagName) || document.querySelector(".rdm-dov,.rdp-ov.show,.rdx-ov,.rdc-ov")) return;
      const c = grid.querySelector('.rdm-card[data-kind="d"].on'); if (!c) return;
      e.preventDefault(); e.stopImmediatePropagation();
      if (!isAdmin()) { msg("تعديل التصاميم متاح لمدير النظام فقط"); return; }
      const cs = Array.from(grid.querySelectorAll('.rdm-card[data-kind="d"]')), i = cs.indexOf(c);
      const per = Math.max(1, cs.filter(x => Math.abs(x.offsetTop - cs[0].offsetTop) < 4).length);
      const d = e.key === "ArrowLeft" ? 1 : e.key === "ArrowRight" ? -1 : e.key === "ArrowDown" ? per : -per;
      const j = Math.max(0, Math.min(cs.length - 1, i + d)); if (j === i) return;
      if (j > i) cs[j].after(c); else cs[j].before(c);
      c.scrollIntoView({ block: "nearest" }); saveOrder();
    };
    window.addEventListener("keydown", moveKey, true);
    { const cl0 = W.close; W.close = () => { window.removeEventListener("keydown", moveKey, true); cl0(); }; }
    grid.addEventListener("contextmenu", e => {
      const c = e.target.closest(".rdm-c"); e.preventDefault();
      if (!c) return;
      selCard(c);
      if (c.dataset.kind === "d") { const it = itemOf(c); ctx(e.clientX, e.clientY, cardMenu(it)); }
      else if (c.dataset.kind === "f" && c.dataset.tpl) { const t = c.dataset.tpl; ctx(e.clientX, e.clientY, [{ t: "فتح", ic: IC.view, fn: () => activate(c) }, { t: "تعيين كنموذج نشط", ic: IC.edit, fn: () => setTemplate(t) }, { t: "الخصائص", ic: IC.prop, fn: () => tplProps(t) }, { t: "حذف", ic: IC.del, dis: t === "Default Template", fn: () => delTpl(t) }]); }
      else if (c.dataset.kind === "f") ctx(e.clientX, e.clientY, [{ t: "فتح", ic: IC.view, fn: () => activate(c) }]);
      else if (c.dataset.kind === "s") { const i = +c.dataset.id; ctx(e.clientX, e.clientY, [{ t: "الخصائص", ic: IC.prop, fn: () => secProps(RD.idx().secs[i]) }, { t: "حذف", ic: IC.del, fn: () => ask("هل تريد حذف القسم «" + RD.idx().secs[i].name + "» ؟", () => { RD.idx().secs.splice(i, 1); RD.saveIdx().then(draw); }) }]); }
    });
    path.addEventListener("click", e => { if (e.target.closest(".rdm-up")) { st.path.pop(); st.sel = null; draw(); } });
    draw();

    function cardsOf() {
      const idx = RD.idx(), p = st.path, br = st.branch;
      const inBr = i => !i.branch || i.branch === br || br === BR()[0] && !i.branch;
      if (!p.length) return ROOT.map(r => ({ kind: "f", id: r[0], t: r[1], big: 1 }));
      if (p[0] === "tx") {
        if (p.length === 1) return visibleTpls().map(t => ({ kind: "f", id: "tpl:" + t.name, t: t.name, tpl: t.name, on: idx.tpl === t.name }));
        const tpl = p[1].slice(4);
        return idx.items.filter(i => (i.kind || "tx") === "tx" && i.tpl === tpl && inBr(i)).map(i => ({ kind: "d", it: i }));
      }
      if (p[0] === "bc") return idx.items.filter(i => i.kind === "bc" && inBr(i)).map(i => ({ kind: "d", it: i }));
      if (p[0] === "added") return idx.items.filter(i => i.kind === "rep" && inBr(i)).map(i => ({ kind: "d", it: i }));
      if (p[0] === "edited") return idx.items.filter(i => i.edited && inBr(i)).map(i => ({ kind: "d", it: i }));
      if (p[0] === "secs") return idx.secs.map((s, i) => ({ kind: "s", id: String(i), s })).filter(x => !x.s.branch || x.s.branch === br);
      return [];
    }
    function draw() {
      const p = st.path, idx = RD.idx();
      ov.querySelector(".rdm-new").classList.toggle("in", p.length > 0);
      const nm = !p.length ? "" : p.length === 1 ? (ROOT.find(r => r[0] === p[0]) || [0, ""])[1] : p[p.length - 1].replace(/^tpl:/, "");
      path.innerHTML = p.length ? `<button type="button" class="rdm-up" title="رجوع (Backspace)">${IC.up}</button><b>${esc(nm)}</b>` : "";
      const cards = cardsOf();
      grid.className = "rdm-grid" + (!p.length ? " root" : "");
      if (!cards.length) { grid.innerHTML = `<div class="rdm-empty">${p[0] === "secs" ? "لا توجد أقسام — أضف قسماً من «جديد»" : p[0] === "added" ? "لا توجد تقارير مضافة — أضف تقريراً من «جديد» ← إضافة تقرير" : p[0] === "edited" ? "لا توجد تقارير معدلة بعد — أي تصميم تعدّله وتحفظه يظهر هنا" : "لا توجد تصاميم — أضف تصميماً من «جديد»"}</div>`; return; }
      grid.innerHTML = cards.map(c => {
        if (c.kind === "f" && c.big) return `<div class="rdm-c rdm-fold" data-kind="f" data-id="${esc(c.id)}" tabindex="-1">${IC.fold}<span>${esc(c.t)}</span></div>`;
        if (c.kind === "f") return `<div class="rdm-c rdm-card rdm-tplc${c.on ? " def" : ""}" data-kind="f" data-id="${esc(c.id)}" data-tpl="${esc(c.tpl)}" tabindex="-1"><i class="rdm-ck" title="${c.on ? "النموذج النشط" : "تعيين كنموذج نشط"}">${c.on ? "✔" : ""}</i><div class="rdm-pic">${IC.fold}</div><div class="rdm-nm">${esc(c.t)}</div><div class="rdm-sub"></div></div>`;
        if (c.kind === "s") return `<div class="rdm-c rdm-card" data-kind="s" data-id="${c.id}" tabindex="-1"><div class="rdm-pic">${IC.sec}</div><div class="rdm-nm">${esc(c.s.name)}</div><div class="rdm-sub">${esc(c.s.printer || "الطابعة الافتراضية")}</div></div>`;
        const i = c.it;
        return `<div class="rdm-c rdm-card${i.def ? " def" : ""}${st.sel === i.id ? " on" : ""}" data-kind="d" data-id="${esc(i.id)}" tabindex="-1" title="${esc(i.name + (i.paper ? " — " + i.paper : ""))}"><i class="rdm-ck" title="${i.def ? "التصميم الافتراضى" : "جعله التصميم الإفتراضى"}">${i.def ? "✔" : ""}</i><div class="rdm-pic" data-th="${esc(i.id)}"><div class="rdm-ld"></div></div><div class="rdm-nm">${esc(i.name)}</div><div class="rdm-sub">${esc(i.kind === "bc" ? (i.paper === "A4" ? "A4 — ملصقات" : "ملصق") : i.kind === "rep" ? ((RD.DATASETS[i.dataset] || {}).t || "تقرير") : i.tx)}</div></div>`;
      }).join("");
      // الصور المصغّرة تباعاً حتى لا تتجمد الواجهة
      const pics = Array.from(grid.querySelectorAll("[data-th]"));
      let k = 0; const step = () => { if (k >= pics.length || !grid.isConnected) return; const el = pics[k++]; const it = idx.items.find(x => x.id === el.dataset.th); if (it) loadThumb(it, el); setTimeout(step, 15); };
      step();
      const on = grid.querySelector(".rdm-c.on"); if (on) on.scrollIntoView({ block: "nearest" });
      try { grid.focus({ preventScroll: true }); } catch (e) { }
    }
  }
  function cardMenu(it) {
    return [
      { t: "معاينة", ic: IC.view, fn: () => previewItem(it) },
      { t: "تعديل التصميم", ic: IC.edit, fn: () => editItem(it) },
      { t: "دمج", ic: IC.merge, fn: () => importInto(it) },
      { t: "حفظ التصميم", ic: IC.save, fn: () => exportItem(it) },
      { t: "حذف", ic: IC.del, fn: () => delItem(it) },
      { t: "الخصائص", ic: IC.prop, fn: () => itemProps(it) }
    ];
  }
  const redraw = () => { if (W) W.draw(); };
  const needAdmin = () => { if (isAdmin()) return true; msg("تعديل التصاميم متاح لمدير النظام فقط"); return false; };

  /* ------------------------------------------------------------------ عمليات البطاقة */
  function sampleOrReal(d) {
    // المعاينة: آخر فاتورة محفوظة إن وُجدت (بيانات حقيقية) وإلا بيانات تجريبية
    const sc = RD.schemaOf(d.kind, d.tx);
    if (sc === "inv" && /مبيعات/.test(d.tx || "") && (window.SALES_DATA || []).length) {
      const r = window.SALES_DATA[0];
      return RD.dataFromSaved(r, d.tx).then(x => x.items.length ? x : RD.sampleData(d)).catch(() => RD.sampleData(d));
    }
    if (sc === "rep") return Promise.resolve(RD.dataset(d.dataset || "items"));
    return Promise.resolve(RD.sampleData(d));
  }
  RD.previewData = sampleOrReal;
  function previewItem(it) {
    Promise.all([RD.getDesign(it), RD.company()]).then(([d, co]) => {
      if (!d) { msg("تعذّر تحميل التصميم"); return; }
      sampleOrReal(d).then(data => { data.company = co; window.ANOUER_RDP.open(d, data, { item: it, title: it.name }); });
    });
  }
  function editItem(it) {
    if (!it || !needAdmin()) return;
    if (!window.ANOUER_RDX) { msg("المصمم غير محمّل"); return; }
    RD.getDesign(it).then(d => { if (!d) { msg("تعذّر تحميل التصميم"); return; } window.ANOUER_RDX.open(it, d, { onSaved: () => { RD.dropThumb(it.id); redraw(); } }); });
  }
  function importInto(it) {
    if (!needAdmin()) return;
    const inp = document.createElement("input"); inp.type = "file"; inp.accept = ".anrd,.json,application/json";
    inp.onchange = () => {
      const f = inp.files && inp.files[0]; if (!f) return;
      const rd = new FileReader();
      rd.onload = () => {
        let d; try { d = JSON.parse(rd.result); if (d && d.design) d = d.design; if (!d || !Array.isArray(d.bands)) throw 0; } catch (e) { msg("الملف ليس تصميماً صالحاً"); return; }
        ask("سيتم استبدال تصميم «" + it.name + "» بالتصميم الموجود في الملف «" + f.name + "» .. هل تريد المتابعة ؟", () => {
          d.name = it.name; if (it.kind !== "bc" && it.kind !== "rep") d.tx = it.tx; d.kind = it.kind || "tx";
          RD.putDesign(it, d).then(() => { it.edited = true; it.updated = new Date().toISOString(); it.paper = d.paper || it.paper; return RD.saveIdx(); }).then(() => { RD.dropThumb(it.id); redraw(); T("تم دمج التصميم «" + f.name + "»", "s"); }).catch(e => T("لم يتم الحفظ: " + e.message, "e"));
        });
      };
      rd.readAsText(f, "utf-8");
    };
    inp.click();
  }
  function exportItem(it) {
    RD.getDesign(it).then(d => {
      if (!d) return;
      const blob = new Blob([JSON.stringify({ app: "ANOUER", type: "report-design", v: 1, design: d }, null, 1)], { type: "application/json" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = (it.name || "design").replace(/[\\/:*?"<>|]/g, "_") + ".anrd";
      document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800);
      T("تم حفظ التصميم في ملف «" + a.download + "»", "s");
    });
  }
  function delItem(it) {
    if (!it || !needAdmin()) return;
    ask("هل تريد حذف التصميم «" + it.name + "» ؟", () => {
      const idx = RD.idx(), i = idx.items.indexOf(it); if (i < 0) return;
      idx.items.splice(i, 1);
      if (it.builtin) (idx.removed = idx.removed || []).push(it.builtin);
      if (it.src === "dexef") (idx.dexDel = idx.dexDel || []).push(it.id);
      if (it.def) { const nx = idx.items.find(x => (x.kind || "tx") === (it.kind || "tx") && x.tx === it.tx && x.tpl === it.tpl); if (nx) nx.def = true; }
      RD.dropDesign(it).catch(() => { }).then(() => RD.saveIdx()).then(() => { redraw(); T("تم حذف التصميم", "s"); });
    });
  }
  function setDefault(it) {
    if (!it || it.def) return;
    if (!needAdmin()) return;
    RD.idx().items.forEach(x => { if (x !== it && (x.kind || "tx") === (it.kind || "tx") && (it.kind === "bc" || x.tx === it.tx) && x.tpl === it.tpl && (x.branch || "") === (it.branch || "")) x.def = false; });
    it.def = true;
    RD.saveIdx().then(() => { redraw(); T("«" + it.name + "» هو التصميم الإفتراضى" + (it.kind === "bc" ? " للباركود" : " لـ" + it.tx), "s"); });
  }
  function setTemplate(t) {
    if (!needAdmin()) return;
    RD.idx().tpl = t; RD.saveIdx().then(() => { redraw(); T("النموذج النشط : " + t, "s"); });
  }
  /* الخصائص */
  function itemProps(it) {
    if (!it || !needAdmin()) return;
    const bc = it.kind === "bc";
    RD.getDesign(it).then(d => {
      const lb = (d && d.label) || { w: 38, h: 25 };
      const papers = bc ? ["Label", "A4"] : it.kind === "rep" ? ["A4", "A4 Landscape", "A5"] : ["A4 Invoice", "Cashier Receipt", "A5"];
      if (it.paper && papers.indexOf(it.paper) < 0) papers.unshift(it.paper);   // أنواع ورق DEXEF (Cashier ، A4 …)
      const body = `<div class="rdm-form">
        ${fld("اسم التصميم", `<input data-k="name" value="${esc(it.name)}">`, 1)}
        ${bc || it.kind === "rep" ? "" : fld("التعامل", `<select data-k="tx" disabled>${opt(RD.TXS, it.tx)}</select>`, 1)}
        ${it.kind === "rep" ? "" : fld("نموذج التصميم", `<select data-k="tpl"${bc ? " disabled" : ""}>${opt(visibleTpls().map(t => t.name), it.tpl)}</select>`, 1)}
        ${fld("نوع الورقة", `<select data-k="paper">${opt(papers, it.paper || papers[0])}</select>`)}
        ${bc ? `<div class="rdm-two">${fld("ارتفاع اللاصقة (سم)", spin("lh", (lb.h / 10).toFixed(2), { step: 0.1, min: 0.5 }))}${fld("عرض اللاصقة (سم)", spin("lw", (lb.w / 10).toFixed(2), { step: 0.1, min: 0.5 }))}</div>` : ""}
        ${fld("عدد النسخ", spin("copies", it.copies || 1, { min: 1 }))}
        ${fld("الطابعة", printerSel("printer", it.printer))}
        ${fld("الفرع", `<select data-k="branch"><option value="">كل الفروع</option>${opt(BR(), it.branch)}</select>`)}
        <label class="rdm-chk"><input type="checkbox" data-k="def"${it.def ? " checked" : ""}><span>جعل هذا التصميم هو التصميم الإفتراضى ؟</span></label></div>`;
      const D = dlg({ w: 420, body, buttons: [{ t: "الغاء", cls: "blue", fn: x => x.close() }, { t: "موافق", cls: "green", fn: x => ok(x) }], enter: x => ok(x) });
      fillPrinters(D.box, it.printer);
      function ok(x) {
        const v = vals(D.box);
        if (!String(v.name || "").trim()) { msg("يجب ادخال جميع الحقول التى بجوارها نجمة حمراء"); return; }
        const changedPaper = v.paper !== it.paper;
        it.name = v.name.trim(); if (v.tpl) it.tpl = v.tpl; it.copies = Math.max(1, v.copies || 1); it.printer = v.printer; it.branch = v.branch;
        it.paper = v.paper; it.updated = new Date().toISOString();
        if (v.def) { it.def = false; x.close(); applyDesignChanges(); setDefaultForce(it); return; }
        else it.def = false;
        x.close(); applyDesignChanges();
        function applyDesignChanges() {
          if (!d) { RD.saveIdx().then(redraw); return; }
          let touch = d.name !== it.name; d.name = it.name;
          const nl = bc ? { w: Math.max(5, v.lw * 10), h: Math.max(5, v.lh * 10) } : null;
          const sizeCh = bc && (Math.abs(nl.w - lb.w) > 0.05 || Math.abs(nl.h - lb.h) > 0.05);
          if (changedPaper || sizeCh) { RD.applyPaper(d, it.paper, nl); touch = true; }
          (touch ? RD.putDesign(it, d) : Promise.resolve()).then(() => RD.saveIdx()).then(() => { RD.dropThumb(it.id); redraw(); T("تم حفظ الخصائص", "s"); }).catch(e => T("لم يتم الحفظ: " + e.message, "e"));
        }
      }
    });
  }
  function setDefaultForce(it) { it.def = false; setDefault(it); }
  /* تطبيق نوع الورقة على التصميم (المقاس والهوامش) */
  RD.applyPaper = function (d, paper, lab) {
    d.paper = paper;
    if (paper === "A4 Landscape") { d.paper = "A4"; d.page.w = 210; d.page.h = 297; d.page.land = true; }
    else if (paper === "Label" && d.label && d.label.single) { const l = lab || d.label, m = d.page.m; d.page.w = l.w; d.page.h = l.h; d.label = Object.assign({}, d.label, { w: l.w, h: l.h, bw: Math.max(5, l.w - m[1] - m[3]) }); d.roll = 0; return; }
    else if (paper === "Label") { const l = lab || d.label || { w: 38, h: 25 }; d.label = Object.assign({}, d.label || {}, { w: l.w, h: l.h, cols: 1, rows: 1 }); d.page.w = l.w; d.page.h = l.h; d.page.m = [0, 0, 0, 0]; d.roll = 0; }
    else if (paper === "A4" && d.kind === "bc") { const l = lab || d.label || { w: 38, h: 25 }; d.page.w = 210; d.page.h = 297; d.page.m = [5, 5, 5, 5]; d.label = Object.assign({}, d.label || {}, { w: l.w, h: l.h, cols: Math.max(1, Math.floor(200 / l.w)), rows: Math.max(1, Math.floor(287 / l.h)) }); d.roll = 0; }
    else { const p = RD.PAPERS[paper] || RD.PAPERS["A4 Invoice"]; d.page.w = p.w; d.page.h = p.h; d.page.m = p.m.slice(); d.page.land = false; d.roll = p.roll ? 1 : 0; }
    const tm = RD.band(d, "TopMargin"), bm = RD.band(d, "BottomMargin"); if (tm) tm.h = d.page.m[0]; if (bm) bm.h = d.page.m[2];
    if (d.kind === "bc") { const det = RD.band(d, "Detail"); if (det && d.label) det.h = d.label.h; }
    // العناصر التي تتجاوز العرض الجديد تُقصّ إلى حدوده
    const cw = RD.contentW(d) || (d.label && d.label.w) || 50;
    d.bands.forEach(b => (b.ctrls || []).forEach(c => { if (c.x + c.w > cw) { c.x = Math.max(0, Math.min(c.x, cw - 2)); c.w = Math.max(2, Math.min(c.w, cw - c.x)); } }));
  };
  function tplProps(name) {
    if (!needAdmin()) return;
    const t = RD.idx().tpls.find(x => x.name === name); if (!t) return;
    const D = dlg({ w: 420, title: "بيانات النموذج", body: `<div class="rdm-form">${fld("اسم النموذج", `<input data-k="name" value="${esc(t.name)}"${name === "Default Template" ? " disabled" : ""}>`, 1)}${fld("الصلاحية", `<select data-k="perm">${opt([["all", "متاح لجميع المستخدمين"], ["me", "متاح لى فقط"]], t.perm || "all")}</select>`, 1)}</div>`,
      buttons: [{ t: "الغاء", cls: "blue", fn: x => x.close() }, { t: "حفظ", cls: "green", fn: x => ok(x) }], enter: x => ok(x) });
    function ok(x) {
      const v = vals(D.box), nn = String(v.name || t.name).trim();
      if (!nn) { msg("يجب ادخال جميع الحقول التى بجوارها نجمة حمراء"); return; }
      if (nn !== t.name && RD.idx().tpls.some(z => z.name === nn)) { msg("يوجد نموذج بنفس الاسم"); return; }
      RD.idx().items.forEach(i => { if (i.tpl === t.name) i.tpl = nn; }); if (RD.idx().tpl === t.name) RD.idx().tpl = nn;
      t.name = nn; t.perm = v.perm; t.owner = v.perm === "me" ? myName() : "";
      x.close(); RD.saveIdx().then(() => { if (W) { W.st.path = W.st.path.map(p => p === "tpl:" + name ? "tpl:" + nn : p); } redraw(); });
    }
  }
  function delTpl(name) {
    if (!needAdmin() || name === "Default Template") return;
    const n = RD.idx().items.filter(i => i.tpl === name).length;
    ask("هل تريد حذف النموذج «" + name + "»" + (n ? " وتصاميمه (" + n + ")" : "") + " ؟", () => {
      const idx = RD.idx(); const gone = idx.items.filter(i => i.tpl === name);
      idx.items = idx.items.filter(i => i.tpl !== name); idx.tpls = idx.tpls.filter(t => t.name !== name); if (idx.tpl === name) idx.tpl = "Default Template";
      Promise.all(gone.map(i => RD.dropDesign(i).catch(() => { }))).then(() => RD.saveIdx()).then(redraw);
    });
  }
  function secProps(s, isNew) {
    if (!needAdmin()) return;
    s = s || { name: "", branch: BR()[0], printer: "", design: "" };
    const ds = RD.idx().items.filter(i => (i.kind || "tx") === "tx");
    let cats = []; try { cats = Array.from(new Set((window.products || (typeof products !== "undefined" ? products : [])).map(p => p.cat || p.group || "").filter(Boolean))).sort(); } catch (e) { }
    const gs = s.groups || [];
    const D = dlg({ w: 680, cls: "rdm-wz", title: "بيانات القسم", body: `<div class="rdm-wzb"><div class="rdm-form">${fld("اسم القسم", `<input data-k="name" value="${esc(s.name)}">`, 1)}${fld("اسم الفرع", `<select data-k="branch">${opt(BR(), s.branch)}</select>`, 1)}${fld("الطابعة الإفتراضية", printerSel("printer", s.printer), 1)}${fld("التصميم الإفتراضى", `<select data-k="design"><option value=""></option>${opt(ds.map(i => [i.id, i.name + " — " + i.tx]), s.design)}</select>`, 1)}
        <div class="rdm-f"><label>مجموعات الأصناف التي تُطبع في هذا القسم</label><div class="rdm-cats">${cats.length ? cats.map(c => `<label class="rdm-chk"><input type="checkbox" data-g="${esc(c)}"${gs.indexOf(c) >= 0 ? " checked" : ""}><span>${esc(c)}</span></label>`).join("") : '<span class="rdm-note">لا توجد مجموعات أصناف — سيطبع القسم كل أصناف الفاتورة</span>'}</div></div>
        <label class="rdm-chk"><input type="checkbox" data-k="auto"${s.auto !== false ? " checked" : ""}><span>طباعة القسم تلقائياً عند «حفظ و طباعة» في المبيعات</span></label></div><div class="rdm-art">${IC.pic1}</div></div>`,
      buttons: [{ t: "الغاء", cls: "blue", fn: x => x.close() }, { t: "حفظ", cls: "navy", fn: x => ok(x) }], enter: x => ok(x) });
    fillPrinters(D.box, s.printer);
    function ok(x) {
      const v = vals(D.box);
      if (!v.name.trim() || !v.design) { msg("يجب ادخال جميع الحقول التى بجوارها نجمة حمراء"); return; }
      Object.assign(s, { name: v.name.trim(), branch: v.branch, printer: v.printer, design: v.design, auto: !!v.auto, groups: D.$$("[data-g]").filter(i => i.checked).map(i => i.dataset.g) });
      if (isNew) RD.idx().secs.push(s);
      x.close(); RD.saveIdx().then(() => { if (W && isNew) { W.st.path = ["secs"]; } redraw(); T("تم حفظ القسم", "s"); });
    }
  }

  /* ------------------------------------------------------------------ «جديد»: نوع التصميم المراد إضافته */
  function wizard() {
    if (!needAdmin()) return;
    const types = [["tx", "تعامل", IC.tx], ["bc", "باركود", IC.bc], ["rep", "إضافة تقرير", IC.rep], ["tpl", "نموذج تصميم", IC.tpl], ["sec", "قسم", IC.sec]];
    const cur = W && W.st.path[0] === "bc" ? "bc" : W && W.st.path[0] === "added" ? "rep" : W && W.st.path[0] === "secs" ? "sec" : "tx";
    const D = dlg({ w: 720, cls: "rdm-wz", title: "نوع التصميم المراد إضافته", body: `<div class="rdm-types">${types.map(t => `<button type="button" class="rdm-ty${t[0] === cur ? " on" : ""}" data-t="${t[0]}">${t[2]}<span>${t[1]}</span></button>`).join("")}</div>`,
      buttons: [{ t: "التالى", cls: "green", fn: x => next(x) }], enter: x => next(x) });
    D.$$(".rdm-ty").forEach(b => { b.onclick = () => { D.$$(".rdm-ty").forEach(z => z.classList.remove("on")); b.classList.add("on"); }; b.ondblclick = () => next(D); });
    function next(x) {
      const t = (x.$(".rdm-ty.on") || {}).dataset; if (!t) return;
      x.close();
      if (t.t === "tx") txStep({});
      else if (t.t === "bc") bcStep({});
      else if (t.t === "rep") repStep({});
      else if (t.t === "tpl") tplStep();
      else secProps(null, true);
    }
  }
  const back = () => setTimeout(wizard, 0);
  function txStep(pre) {
    const tpls = visibleTpls().map(t => t.name), defTpl = W && W.st.path[0] === "tx" && W.st.path[1] ? W.st.path[1].slice(4) : RD.idx().tpl;
    const D = dlg({ w: 720, cls: "rdm-wz", title: "بيانات التصميم", body: `<div class="rdm-wzb"><div class="rdm-form">
        ${fld("اسم التصميم", `<input data-k="name" value="${esc(pre.name || "")}">`, 1)}
        <div class="rdm-grpf">${fld("التعامل", `<select data-k="tx"><option value=""></option>${opt(RD.TXS, pre.tx || "")}</select>`, 1)}${fld("نموذج التصميم", `<select data-k="tpl">${opt(tpls, pre.tpl || defTpl)}</select>`, 1)}</div>
        <div class="rdm-grpf b">${fld("نوع الورقة", `<select data-k="paper">${opt(["A4 Invoice", "Cashier Receipt", "A5"], pre.paper || "A4 Invoice")}</select>`)}${fld("عدد النسخ", spin("copies", pre.copies || 1, { min: 1 }))}${fld("الطابعة", printerSel("printer", pre.printer))}</div>
        <label class="rdm-chk"><input type="checkbox" data-k="def"${pre.def ? " checked" : ""}><span>جعل هذا التصميم هو التصميم الإفتراضى ؟</span></label></div><div class="rdm-art">${IC.pic1}</div></div>`,
      buttons: [{ t: "السابق", cls: "blue", fn: x => { x.close(); back(); } }, { t: "التالى", cls: "green", fn: x => next(x) }], enter: x => next(x) });
    fillPrinters(D.box, pre.printer);
    function next(x) {
      const v = vals(D.box);
      if (!v.name.trim() || !v.tx || !v.tpl) { msg("يجب ادخال جميع الحقول التى بجوارها نجمة حمراء"); return; }
      x.close(); startStep(Object.assign(v, { kind: "tx", name: v.name.trim() }), () => txStep(v));
    }
  }
  function bcStep(pre) {
    const D = dlg({ w: 760, cls: "rdm-wz", title: "بيانات التصميم", body: `<div class="rdm-wzb bc"><div class="rdm-form">
        ${fld("اسم التصميم", `<input data-k="name" value="${esc(pre.name || "")}">`, 1)}
        <div class="rdm-grpf">${fld("نموذج التصميم", `<select data-k="tpl">${opt(visibleTpls().map(t => t.name), pre.tpl || "Default Template")}</select>`, 1)}${fld("نوع الورقة", `<select data-k="paper">${opt(["Label", "A4"], pre.paper || "Label")}</select>`, 1)}</div>
        <div class="rdm-grpf b">${fld("عدد النسخ", spin("copies", pre.copies || 1, { min: 1 }))}${fld("الطابعة", printerSel("printer", pre.printer))}</div>
        <table class="rdm-dims"><tr><th></th><th>الإرتفاع</th><th>العرض</th><th class="a4o" colspan="2">تقسيم الصفحة</th></tr>
          <tr><td>حجم اللاصقة</td><td>${spin("lh", pre.lh || 2.5, { step: 0.1, min: 0.5 })}<em>سم</em></td><td>${spin("lw", pre.lw || 3.8, { step: 0.1, min: 0.5 })}<em>سم</em></td><td class="a4o">عدد الأعمدة</td><td class="a4o">${spin("cols", pre.cols || 5, { min: 1 })}</td></tr>
          <tr><td>حجم الصفحة</td><td>${spin("ph", pre.ph || 2.7, { step: 0.1, min: 0.5 })}<em>سم</em></td><td>${spin("pw", pre.pw || 4, { step: 0.1, min: 0.5 })}<em>سم</em></td><td class="a4o">عدد الأسطر</td><td class="a4o">${spin("rows", pre.rows || 11, { min: 1 })}</td></tr></table>
        <label class="rdm-chk"><input type="checkbox" data-k="def"${pre.def ? " checked" : ""}><span>جعل هذا التصميم هو التصميم الإفتراضى ؟</span></label></div><div class="rdm-bcpv"></div></div>`,
      buttons: [{ t: "السابق", cls: "blue", fn: x => { x.close(); back(); } }, { t: "التالى", cls: "green", fn: x => next(x) }], enter: x => next(x) });
    fillPrinters(D.box, pre.printer);
    const K = k => D.box.querySelector(`[data-k="${k}"]`);
    let lastPaper = K("paper").value;
    const pv = () => {
      const a4 = K("paper").value === "A4";
      D.box.querySelector(".rdm-dims").classList.toggle("a4", a4);
      if (a4 && lastPaper !== "A4") { K("pw").value = 21; K("ph").value = 29.7; }
      if (!a4 && lastPaper === "A4") { K("pw").value = (+K("lw").value + 0.2).toFixed(1); K("ph").value = (+K("lh").value + 0.2).toFixed(1); }
      lastPaper = K("paper").value;
      const lw = +K("lw").value || 1, lh = +K("lh").value || 1, pw = +K("pw").value || 1, ph = +K("ph").value || 1;
      if (a4) { const cmx = Math.max(1, Math.floor((pw - 1) / lw)), cmy = Math.max(1, Math.floor((ph - 1) / lh)); if (+K("cols").value > cmx || this === "auto") K("cols").value = cmx; if (+K("rows").value > cmy) K("rows").value = cmy; }
      const cols = a4 ? +K("cols").value : 1, rows = a4 ? +K("rows").value : 1;
      const s = Math.min(150 / pw, 190 / ph);
      let cells = ""; for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) { const x = pw * s - (a4 ? 0.5 * s : (pw - lw) / 2 * s) - (c + 1) * lw * s, y = (a4 ? 0.5 * s : (ph - lh) / 2 * s) + r * lh * s; cells += `<div class="blb" style="left:${x}px;top:${y}px;width:${lw * s - 2}px;height:${lh * s - 2}px">${r + c === 0 ? '<i class="bars"></i><em>' + (+lw).toFixed(1) + "</em>" : ""}</div>`; }
      D.box.querySelector(".rdm-bcpv").innerHTML = `<div class="bpg" style="width:${pw * s}px;height:${ph * s}px">${cells}</div><span class="dw">${pw}</span><span class="dh">${ph}</span>`;
    };
    D.box.addEventListener("input", pv); D.box.addEventListener("change", pv); pv();
    function next(x) {
      const v = vals(D.box);
      if (!v.name.trim()) { msg("يجب ادخال جميع الحقول التى بجوارها نجمة حمراء"); return; }
      if (v.paper === "A4" && (v.lw * v.cols > v.pw + 0.01 || v.lh * v.rows > v.ph + 0.01)) { msg("عدد الأعمدة أو الأسطر لا يتسع في الصفحة — قلّل العدد أو حجم اللاصقة"); return; }
      x.close(); startStep(Object.assign(v, { kind: "bc", name: v.name.trim() }), () => bcStep(v));
    }
  }
  function repStep(pre) {
    const D = dlg({ w: 720, cls: "rdm-wz", title: "إضافة تقرير", body: `<div class="rdm-wzb"><div class="rdm-form">
        ${fld("اسم التقرير", `<input data-k="name" value="${esc(pre.name || "")}">`, 1)}
        ${fld("البيانات", `<select data-k="dataset">${opt(Object.keys(RD.DATASETS).map(k => [k, RD.DATASETS[k].t]), pre.dataset || "items")}</select>`, 1)}
        ${fld("نوع الورقة", `<select data-k="paper">${opt(["A4", "A4 Landscape", "A5"], pre.paper || "A4")}</select>`)}
        ${fld("عدد النسخ", spin("copies", pre.copies || 1, { min: 1 }))}${fld("الطابعة", printerSel("printer", pre.printer))}
        <p class="rdm-note">يُنشأ التقرير بجدول يحتوي كل حقول البيانات المختارة مع العنوان والإجماليات ورقم الصفحة، ثم يفتح في المصمم لتعديله.</p></div><div class="rdm-art">${IC.rep}</div></div>`,
      buttons: [{ t: "السابق", cls: "blue", fn: x => { x.close(); back(); } }, { t: "حفظ", cls: "green", fn: x => ok(x) }], enter: x => ok(x) });
    fillPrinters(D.box, pre.printer);
    function ok(x) {
      const v = vals(D.box);
      if (!v.name.trim()) { msg("يجب ادخال جميع الحقول التى بجوارها نجمة حمراء"); return; }
      x.close();
      const d = repDesign(v.name.trim(), v.dataset, v.paper);
      create({ kind: "rep", name: v.name.trim(), tx: "", tpl: "", paper: v.paper, copies: v.copies, printer: v.printer, dataset: v.dataset }, d, "added");
    }
  }
  function repDesign(name, ds, paper) {
    const D = RD.DATASETS[ds] || RD.DATASETS.items, mk = RD.mk;
    const d = RD.newDesign({ name, kind: "rep", paper: "A4", dataset: ds });
    RD.applyPaper(d, paper === "A4 Landscape" ? "A4 Landscape" : paper === "A5" ? "A5" : "A4 Invoice");
    d.kind = "rep"; d.dataset = ds; d.paper = paper;
    const cw = d.page.land ? 297 - 20 : RD.contentW(d), n = D.f.length;
    const ws = D.f.map(f => f.n === "Index" ? 10 : f.t === "n" ? 24 : f.t === "d" ? 24 : 0), fixed = ws.reduce((s, w) => s + w, 0), flex = ws.filter(w => !w).length;
    const fw = ws.map(w => w || Math.max(18, (cw - fixed) / Math.max(1, flex)));
    const k = cw / fw.reduce((s, w) => s + w, 0), cols = fw.map(w => Math.round(w * k * 10) / 10).reverse();
    const f = D.f.slice().reverse();
    d.bands = d.bands.filter(b => b.type === "TopMargin" || b.type === "BottomMargin");
    d.bands.push({ type: "ReportHeader", h: 22, ctrls: [mk.E(0, 0, cw, 9, "[Company Name]", "", { fs: 13, b: 1, al: "r", color: "#12508f" }), mk.E(0, 9, cw, 8, "[Report Title]", "", { fs: 14, b: 1, al: "c" }), mk.E(0, 17, cw, 5, "'تاريخ الطباعة : ' + FormatString('{0:dd/MM/yyyy}', [Print Date])", "", { fs: 8, al: "l" })] });
    d.bands.push({ type: "PageHeader", h: 7, ctrls: [mk.TB(0, 0, cols, { h: 7, texts: f.map(x => x.a), s: { b: 1, bg: "#dfeafa", color: "#12508f", fs: 8.5 } })] });
    d.bands.push({ type: "Detail", h: 6, ctrls: [mk.TB(0, 0, cols, { h: 6, exprs: f.map(x => "[" + x.n + "]"), fmts: f.map(x => x.t === "n" && x.n !== "Index" ? "n2" : x.t === "d" ? "dd/MM/yyyy" : ""), s: { fs: 8.5 } })] });
    const sumF = D.f.filter(x => x.t === "n" && x.n !== "Index");
    d.bands.push({ type: "ReportFooter", h: 8, ctrls: [mk.L(cw - 40, 1, 40, 6, "عدد السجلات :", { b: 1 }), mk.E(cw - 70, 1, 30, 6, "[Row Count]", "", { b: 1 })].concat(sumF.length ? [mk.E(0, 1, cw - 75, 6, "Concat(" + sumF.map(x => "'" + x.a + " : ' + FormatString('{0:n2}', Sum([" + x.n + "]))").join(", '   ', ") + ")", "", { b: 1, al: "l" })] : []) });
    d.bands.push({ type: "PageFooter", h: 6, ctrls: [{ id: RD.uid(), t: "pageinfo", info: "pn", x: 0, y: 0, w: 40, h: 5, fmt: "صفحة {0} من {1}", s: RD.mk.st({ fs: 7.5, al: "l" }) }] });
    RD.sortBands(d);
    return d;
  }
  RD.repDesign = repDesign;
  function tplStep() {
    const D = dlg({ w: 720, cls: "rdm-wz", title: "بيانات النموذج", body: `<div class="rdm-wzb"><div class="rdm-form">${fld("اسم النموذج", '<input data-k="name">', 1)}${fld("الصلاحية", `<select data-k="perm">${opt([["all", "متاح لجميع المستخدمين"], ["me", "متاح لى فقط"]], "all")}</select>`, 1)}<label class="rdm-chk"><input type="checkbox" data-k="copy" checked><span>نسخ تصاميم «Default Template» إلى النموذج الجديد</span></label></div><div class="rdm-art">${IC.pic1}</div></div>`,
      buttons: [{ t: "السابق", cls: "blue", fn: x => { x.close(); back(); } }, { t: "حفظ", cls: "navy", fn: x => ok(x) }], enter: x => ok(x) });
    function ok(x) {
      const v = vals(D.box), nm = v.name.trim();
      if (!nm) { msg("يجب ادخال جميع الحقول التى بجوارها نجمة حمراء"); return; }
      const idx = RD.idx();
      if (idx.tpls.some(t => t.name === nm)) { msg("يوجد نموذج بنفس الاسم"); return; }
      idx.tpls.push({ name: nm, perm: v.perm, owner: v.perm === "me" ? myName() : "" });
      x.close();
      const src = v.copy ? idx.items.filter(i => (i.kind || "tx") === "tx" && i.tpl === "Default Template") : [];
      Promise.all(src.map(i => RD.getDesign(i).then(d => {
        const ni = Object.assign({}, i, { id: "u_" + RD.uid(), tpl: nm, builtin: null, edited: false, created: today(), updated: "" });
        idx.items.push(ni); return d ? RD.putDesign(ni, d) : null;
      }))).then(() => RD.saveIdx()).then(() => { if (W) { W.st.path = ["tx"]; } redraw(); T("تم إضافة النموذج «" + nm + "»", "s"); }).catch(e => T("لم يتم الحفظ: " + e.message, "e"));
    }
  }
  /* بداية التصميم: جاهز / نسخ من تصميم موجود / فارغ */
  function startStep(v, prev) {
    const same = RD.idx().items.filter(i => (i.kind || "tx") === v.kind);
    const D = dlg({ w: 720, cls: "rdm-wz", title: "بداية التصميم", body: `<div class="rdm-start">
        <label class="rdm-opt"><input type="radio" name="st" value="ready" checked><b>تصميم جاهز</b><span>${v.kind === "bc" ? "ملصق: اسم الصنف + الباركود + السعر بمقاس اللاصقة" : "تصميم ANOUER الجاهز لـ«" + esc(v.tx) + "» بمقاس " + esc(v.paper)}</span></label>
        <label class="rdm-opt"><input type="radio" name="st" value="copy"${same.length ? "" : " disabled"}><b>نسخ من تصميم موجود</b><select data-k="src">${opt(same.map(i => [i.id, i.name + (i.tx ? " — " + i.tx : "")]), same[0] && same[0].id)}</select></label>
        <label class="rdm-opt"><input type="radio" name="st" value="blank"><b>تصميم فارغ</b><span>بنود فارغة (رأس التقرير ، رأس الصفحة ، التفاصيل ، تذييل التقرير)</span></label></div>`,
      buttons: [{ t: "السابق", cls: "blue", fn: x => { x.close(); prev(); } }, { t: "حفظ", cls: "green", fn: x => ok(x) }], enter: x => ok(x) });
    function ok(x) {
      const mode = (x.$('input[name="st"]:checked') || {}).value || "ready", src = x.$('[data-k="src"]').value;
      x.close();
      let p;
      if (mode === "copy") p = RD.getDesign(same.find(i => i.id === src)).then(d => d || readyOf(v));
      else if (mode === "blank") p = Promise.resolve(blankOf(v));
      else p = Promise.resolve(readyOf(v));
      p.then(d => {
        d = clone(d); d.name = v.name; d.kind = v.kind; if (v.kind === "tx") d.tx = v.tx;
        if (v.kind === "bc") {
          const lab = { w: v.lw * 10, h: v.lh * 10 };
          RD.applyPaper(d, v.paper, lab);
          if (v.paper === "A4") { d.label.cols = v.cols; d.label.rows = v.rows; d.page.w = v.pw * 10; d.page.h = v.ph * 10; }
          else { d.page.w = v.pw * 10; d.page.h = v.ph * 10; d.label.w = lab.w; d.label.h = lab.h; }
          if (mode === "ready") fitLabel(d, lab);
        } else if (mode !== "copy" || d.paper !== v.paper) RD.applyPaper(d, v.paper);
        create({ kind: v.kind, name: v.name, tx: v.kind === "tx" ? v.tx : "", tpl: v.tpl || "Default Template", paper: v.paper, copies: v.copies, printer: v.printer, def: v.def }, d, v.kind === "bc" ? "bc" : "tx:" + (v.tpl || "Default Template"));
      });
    }
  }
  function readyOf(v) {
    if (v.kind === "bc") return RD.builtin("bc.38");
    const b = RD.BUILTIN.find(x => x.tx === v.tx && x.paper === v.paper) || RD.BUILTIN.find(x => x.tx === v.tx) || null;
    if (b) return b.mk();
    const kind = RD.schemaOf("tx", v.tx);
    const base = RD.BUILTIN.find(x => kind === "vch" ? x.key === "rcv.a5" : v.paper === "Cashier Receipt" ? x.key === "sale.cash" : x.key === "sale.a4").mk();
    // عنوان التصميم = اسم التعامل
    base.bands.forEach(bd => (bd.ctrls || []).forEach(c => { if (c.t === "label" && /^(فاتورة مبيعات|إيصال استلام نقدية)$/.test(c.text)) c.text = v.tx; }));
    return base;
  }
  function blankOf(v) {
    if (v.kind === "bc") { const d = RD.builtin("bc.38"); RD.band(d, "Detail").ctrls = []; return d; }
    return RD.newDesign({ name: v.name, tx: v.tx, paper: v.paper === "Cashier Receipt" ? "Cashier Receipt" : v.paper === "A5" ? "A5" : "A4 Invoice", bands: [{ type: "ReportHeader", h: 30 }, { type: "PageHeader", h: 8 }, { type: "Detail", h: 7 }, { type: "ReportFooter", h: 25 }] });
  }
  function fitLabel(d, lab) {
    const det = RD.band(d, "Detail"); if (!det) return; det.h = lab.h;
    const src = RD.builtin("bc.38"), s = RD.band(src, "Detail"), kx = lab.w / 38, ky = lab.h / 25;
    det.ctrls = s.ctrls.map(c => Object.assign(clone(c), { id: RD.uid(), x: c.x * kx, y: c.y * ky, w: c.w * kx, h: c.h * ky }));
  }
  function create(meta, d, goPath) {
    const idx = RD.idx();
    const it = Object.assign({ id: "u_" + RD.uid(), builtin: null, edited: false, perm: "all", branch: "", created: today(), updated: "" }, meta);
    it.copies = Math.max(1, +it.copies || 1);
    if (it.dataset) d.dataset = it.dataset;
    const wantDef = !!it.def || !idx.items.some(x => (x.kind || "tx") === it.kind && x.tpl === it.tpl && (it.kind === "bc" || x.tx === it.tx));
    it.def = false;
    idx.items.push(it);
    RD.putDesign(it, d).then(() => {
      if (wantDef && it.kind !== "rep") { idx.items.forEach(x => { if (x !== it && (x.kind || "tx") === it.kind && x.tpl === it.tpl && (it.kind === "bc" || x.tx === it.tx)) x.def = false; }); it.def = true; }
      return RD.saveIdx();
    }).then(() => {
      if (W) { W.st.path = goPath === "added" ? ["added"] : goPath === "bc" ? ["bc"] : ["tx", "tpl:" + it.tpl]; W.st.sel = it.id; }
      redraw();
      T("تم إضافة التصميم «" + it.name + "»", "s");
      if (window.ANOUER_RDX) setTimeout(() => editItem(it), 60);
    }).catch(e => T("لم يتم الحفظ: " + e.message, "e"));
  }

  window.ANOUER_RDM = { open, preview: previewItem, edit: editItem, props: itemProps };

  /* ================================================================== نافذة المعاينة (Print Preview) */
  const PI = {
    open: '<svg viewBox="0 0 32 32"><path d="M3 8h9l2 3h15v16H3z" fill="#f6a04d"/><path d="M3 13h26l-3 14H3z" fill="#f47c20"/></svg>',
    save: '<svg viewBox="0 0 32 32"><path d="M4 4h20l4 4v20H4z" fill="#555"/><rect x="9" y="5" width="12" height="7" fill="#fff"/><rect x="8" y="17" width="16" height="10" fill="#fff"/></svg>',
    print: '<svg viewBox="0 0 32 32"><rect x="8" y="3" width="16" height="8" fill="#fff" stroke="#555" stroke-width="2"/><rect x="3" y="11" width="26" height="12" rx="2" fill="#555"/><rect x="8" y="19" width="16" height="10" fill="#fff" stroke="#555" stroke-width="2"/></svg>',
    qprint: '<svg viewBox="0 0 32 32"><rect x="6" y="3" width="14" height="8" fill="#fff" stroke="#555" stroke-width="2"/><rect x="2" y="11" width="22" height="12" rx="2" fill="#555"/><rect x="6" y="19" width="14" height="10" fill="#fff" stroke="#555" stroke-width="2"/><path d="M27 12l-4 8h4l-3 8 7-10h-4l3-6z" fill="#f4a020"/></svg>',
    params: '<svg viewBox="0 0 32 32"><rect x="7" y="4" width="18" height="24" rx="2" fill="none" stroke="#999" stroke-width="2"/><rect x="11" y="2" width="10" height="5" rx="1" fill="#999"/><text x="16" y="23" text-anchor="middle" font-size="12" fill="#999" font-family="Arial">?</text></svg>',
    scale: '<svg viewBox="0 0 32 32"><rect x="3" y="3" width="26" height="26" fill="none" stroke="#1e6fd0" stroke-width="2"/><path d="M8 24L24 8M24 8h-7M24 8v7M8 24h7M8 24v-7" stroke="#1e6fd0" stroke-width="2" fill="none"/></svg>',
    margins: '<svg viewBox="0 0 32 32"><rect x="4" y="3" width="24" height="26" fill="none" stroke="#1e6fd0" stroke-width="2"/><path d="M10 3v26M22 3v26M4 9h24M4 23h24" stroke="#1e6fd0" stroke-width="1.5"/></svg>',
    orient: '<svg viewBox="0 0 32 32"><rect x="4" y="4" width="15" height="20" fill="#fff" stroke="#555" stroke-width="2"/><rect x="11" y="12" width="17" height="14" fill="#fff" stroke="#555" stroke-width="2"/></svg>',
    size: '<svg viewBox="0 0 32 32"><rect x="9" y="7" width="16" height="22" fill="#fff" stroke="#555" stroke-width="2"/><path d="M6 3v26M3 3h6M3 29h6M9 4h16" stroke="#1e6fd0" stroke-width="2"/></svg>',
    find: '<svg viewBox="0 0 32 32"><circle cx="9" cy="19" r="6" fill="#333"/><circle cx="23" cy="19" r="6" fill="#333"/><rect x="12" y="10" width="8" height="6" fill="#333"/><circle cx="9" cy="19" r="3" fill="#888"/><circle cx="23" cy="19" r="3" fill="#888"/></svg>',
    thumbs: '<svg viewBox="0 0 32 32"><rect x="4" y="4" width="10" height="24" fill="none" stroke="#333" stroke-width="2"/><rect x="18" y="4" width="10" height="11" fill="none" stroke="#333" stroke-width="2"/><rect x="18" y="17" width="10" height="11" fill="none" stroke="#333" stroke-width="2"/></svg>',
    first: '<svg viewBox="0 0 32 32"><path d="M23 6v20L10 16z" fill="#999"/><rect x="6" y="6" width="3" height="20" fill="#999"/></svg>',
    prev: '<svg viewBox="0 0 32 32"><path d="M22 6v20L9 16z" fill="#999"/></svg>',
    next: '<svg viewBox="0 0 32 32"><path d="M10 6v20l13-10z" fill="#999"/></svg>',
    last: '<svg viewBox="0 0 32 32"><path d="M9 6v20l13-10z" fill="#999"/><rect x="23" y="6" width="3" height="20" fill="#999"/></svg>',
    zout: '<svg viewBox="0 0 32 32"><circle cx="13" cy="13" r="9" fill="none" stroke="#444" stroke-width="2.4"/><path d="M20 20l8 8M9 13h8" stroke="#444" stroke-width="2.6"/></svg>',
    zoom: '<svg viewBox="0 0 32 32"><circle cx="13" cy="13" r="9" fill="none" stroke="#444" stroke-width="2.4"/><path d="M20 20l8 8" stroke="#444" stroke-width="2.6"/></svg>',
    zin: '<svg viewBox="0 0 32 32"><circle cx="13" cy="13" r="9" fill="none" stroke="#444" stroke-width="2.4"/><path d="M20 20l8 8M9 13h8M13 9v8" stroke="#444" stroke-width="2.6"/></svg>',
    many: '<svg viewBox="0 0 32 32"><rect x="4" y="4" width="10" height="11" fill="none" stroke="#999" stroke-width="2"/><rect x="18" y="4" width="10" height="11" fill="none" stroke="#999" stroke-width="2"/><rect x="4" y="18" width="10" height="11" fill="none" stroke="#999" stroke-width="2"/><rect x="18" y="18" width="10" height="11" fill="none" stroke="#999" stroke-width="2"/></svg>',
    pcolor: '<svg viewBox="0 0 32 32"><path d="M6 14l10-10 10 10-10 10z" fill="#555"/><path d="M8 26h16" stroke="#1e6fd0" stroke-width="4"/><path d="M24 18c2 3 3 4 3 6a3 3 0 0 1-6 0c0-2 1-3 3-6z" fill="#1e6fd0"/></svg>',
    wmark: '<svg viewBox="0 0 32 32"><rect x="6" y="3" width="20" height="26" fill="#fff" stroke="#555" stroke-width="2"/><path d="M9 25L23 7M9 19l9-11M14 25l9-11" stroke="#1e6fd0" stroke-width="1.6"/></svg>',
    pdf: '<svg viewBox="0 0 32 32"><path d="M6 2h14l6 6v22H6z" fill="#fff" stroke="#d32f2f" stroke-width="2"/><rect x="2" y="12" width="22" height="10" fill="#d32f2f"/><text x="13" y="20" text-anchor="middle" font-size="7.5" fill="#fff" font-family="Arial" font-weight="700">PDF</text></svg>',
    mail: '<svg viewBox="0 0 32 32"><path d="M6 2h14l6 6v22H6z" fill="#fff" stroke="#d32f2f" stroke-width="2"/><rect x="2" y="12" width="20" height="9" fill="#d32f2f"/><text x="12" y="19.5" text-anchor="middle" font-size="7" fill="#fff" font-family="Arial" font-weight="700">PDF</text><rect x="18" y="20" width="12" height="9" fill="#fff" stroke="#555" stroke-width="1.5"/><path d="M18 20l6 5 6-5" fill="none" stroke="#555" stroke-width="1.5"/></svg>',
    close: '<svg viewBox="0 0 32 32"><circle cx="16" cy="16" r="13" fill="#e53935"/><path d="M11 11l10 10M21 11L11 21" stroke="#fff" stroke-width="3" stroke-linecap="round"/></svg>',
    ptr: '<svg viewBox="0 0 16 16"><path d="M4 2v11l3-3 2 4 2-1-2-4h4z" fill="#333"/></svg>',
    hand: '<svg viewBox="0 0 16 16"><path d="M5 8V3.5a1 1 0 0 1 2 0V7V2.5a1 1 0 0 1 2 0V7V3.5a1 1 0 0 1 2 0V8V5.5a1 1 0 0 1 2 0V10c0 3-2 5-5 5S4 13 3 11L1.5 8a1 1 0 0 1 1.7-1z" fill="#333"/></svg>',
    mag: '<svg viewBox="0 0 16 16"><circle cx="6.5" cy="6.5" r="4.5" fill="none" stroke="#1e6fd0" stroke-width="1.8"/><path d="M10 10l4 4" stroke="#1e6fd0" stroke-width="2"/></svg>'
  };
  const P = {};
  function pvOpen(design, data, o) {
    o = o || {};
    const ov = document.createElement("div"); ov.className = "rdp-ov show";
    if (o.embed) { ov.classList.add("emb"); o.embed.appendChild(ov); } else document.body.appendChild(ov);
    const S = { design: RD.clone(design), data, o, zoom: o.zoom || 1, page: 0, res: null, many: 1, tool: "ptr", find: "", thumbs: false, scale: 100, over: {} };
    const big = (k, ic, t, tip, dd, dis) => `<button type="button" class="rdr-b big${dis ? " dis" : ""}" data-a="${k}" title="${esc(tip || t)}"${dis ? " disabled" : ""}><i>${ic}</i><span>${t}${dd ? '<em class="dd"></em>' : ""}</span></button>`;
    const grp = (t, inner) => `<div class="rdr-g"><div class="rdr-gi">${inner}</div><div class="rdr-gt">${t}</div></div>`;
    ov.innerHTML = `${o.embed ? "" : `<div class="rdp-tb"><span class="sp"></span><b>Preview</b><span class="sp"></span><button type="button" data-a="maxw" title="تكبير">☐</button><button type="button" data-a="close" title="إغلاق">✕</button></div>`}
      <div class="rdr rdp-rb">${grp("Document", big("open", PI.open, "Open", "فتح مستند محفوظ (HTML)") + big("save", PI.save, "Save", "حفظ المستند كملف HTML"))}
        ${grp("Print", big("print", PI.print, "Print", "طباعة… (اختيار الطابعة)") + big("qprint", PI.qprint, "Quick<br>Print", "طباعة سريعة على طابعة التصميم") + big("params", PI.params, "Parameters", "المعاملات", 0, !(design.params || []).length))}
        ${grp("Page Setup", big("scale", PI.scale, "Scale", "التحجيم", 1) + big("margins", PI.margins, "Margins", "الهوامش", 1) + big("orient", PI.orient, "Orientation", "الاتجاه", 1) + big("size", PI.size, "Size", "مقاس الورق", 1))}
        ${grp("Navigation", big("find", PI.find, "Find", "بحث (Ctrl+F)") + big("thumbs", PI.thumbs, "Thumbnails", "الصفحات المصغّرة") + big("first", PI.first, "First<br>Page", "الصفحة الأولى") + big("prev", PI.prev, "Previous<br>Page", "السابقة") + big("next", PI.next, "Next<br>Page", "التالية") + big("last", PI.last, "Last<br>Page", "الأخيرة"))}
        ${grp("Zoom", `<div class="rdr-tools"><button type="button" class="rdr-s on" data-a="tptr" title="مؤشر">${PI.ptr}</button><button type="button" class="rdr-s" data-a="thand" title="يد (سحب)">${PI.hand}</button><button type="button" class="rdr-s" data-a="tmag" title="عدسة التكبير">${PI.mag}</button></div>` + big("many", PI.many, "Many Pages", "عدة صفحات", 1) + big("zout", PI.zout, "Zoom Out", "تصغير") + big("zoom", PI.zoom, "Zoom", "التكبير", 1) + big("zin", PI.zin, "Zoom In", "تكبير"))}
        ${grp("Page Background", big("pcolor", PI.pcolor, "Page Color", "لون الصفحة", 1) + big("wmark", PI.wmark, "Watermark", "العلامة المائية"))}
        ${grp("Export", big("export", PI.pdf, "Export<br>To", "تصدير", 1) + big("mail", PI.mail, "E-Mail<br>As", "إرسال بالبريد", 1))}
        ${o.embed ? "" : grp("Close", big("close", PI.close, "Close", "إغلاق (Esc)"))}</div>
      <div class="rdp-find"><input placeholder="بحث في المستند…"><button type="button" data-a="fprev">▲</button><button type="button" data-a="fnext">▼</button><span class="fcnt"></span><button type="button" data-a="fclose">✕</button></div>
      <div class="rdp-main"><div class="rdp-thumbs"></div><div class="rdp-view"><div class="rdp-pages"></div></div></div>
      <div class="rdp-st"><span class="pg">Page 1 of 1</span><span class="sp"></span><span class="zl">100%</span><button type="button" data-a="zout" class="z">−</button><input type="range" min="10" max="500" value="100" class="zr"><button type="button" data-a="zin" class="z">+</button></div>`;
    const $ = s => ov.querySelector(s);
    const view = $(".rdp-view"), pagesEl = $(".rdp-pages");
    ov.tabIndex = -1; ov.addEventListener("keydown", e => e.stopPropagation()); if (!o.embed) setTimeout(() => { try { ov.focus({ preventScroll: true }); } catch (e) { } }, 0);
    function render() {
      try { S.res = RD.render(S.design, S.data, { page: S.over.page, margins: S.over.margins, params: S.params }); } catch (e) { console.error(e); S.res = { pages: [], w: 210, h: 297 }; T("خطأ في التصميم: " + e.message, "e"); }
      draw();
    }
    function draw() {
      const z = S.zoom * S.scale / 100;
      if (!S.res.pages.length) { pagesEl.innerHTML = '<div class="rdp-none">The document does not contain any pages.</div>'; status(); return; }
      pagesEl.className = "rdp-pages m" + S.many;
      pagesEl.innerHTML = S.res.pages.map((p, i) => `<div class="rdp-pw${i === S.page ? " cur" : ""}" data-p="${i}" style="width:${p.w * RD.PX * z}px;height:${p.h * RD.PX * z}px"><div class="rdp-pz" style="transform:scale(${z})">${p.html}</div></div>`).join("");
      if (S.find) highlight();
      if (S.thumbs) drawThumbs();
      status();
    }
    function status() {
      const n = S.res.pages.length;
      $(".rdp-st .pg").textContent = "Page " + (n ? S.page + 1 : 0) + " of " + n;
      const zp = Math.round(S.zoom * 100); $(".rdp-st .zl").textContent = zp + "%"; $(".rdp-st .zr").value = zp;
      ov.querySelectorAll('[data-a="first"],[data-a="prev"]').forEach(b => b.classList.toggle("dis", S.page <= 0));
      ov.querySelectorAll('[data-a="next"],[data-a="last"]').forEach(b => b.classList.toggle("dis", S.page >= n - 1));
    }
    function go(i) { const n = S.res.pages.length; S.page = Math.max(0, Math.min(n - 1, i)); pagesEl.querySelectorAll(".rdp-pw").forEach((p, k) => p.classList.toggle("cur", k === S.page)); const el = pagesEl.children[S.page]; if (el) el.scrollIntoView({ block: "start", inline: "center" }); status(); if (S.thumbs) $(".rdp-thumbs").querySelectorAll(".t").forEach((t, k) => t.classList.toggle("on", k === S.page)); }
    function setZoom(z) { S.zoom = Math.max(0.1, Math.min(5, z)); draw(); go(S.page); }
    function fitW() { const p = S.res.pages[0]; if (!p) return; setZoom((view.clientWidth - 40) / (p.w * RD.PX) / (S.scale / 100) / (S.many > 1 ? Math.min(S.many, 2) : 1)); }
    function fitP() { const p = S.res.pages[0]; if (!p) return; setZoom(Math.min((view.clientWidth - 40) / (p.w * RD.PX), (view.clientHeight - 30) / (p.h * RD.PX)) / (S.scale / 100)); }
    function drawThumbs() {
      const th = $(".rdp-thumbs");
      th.innerHTML = S.res.pages.map((p, i) => { const s = 120 / (p.w * RD.PX); return `<div class="t${i === S.page ? " on" : ""}" data-p="${i}"><div class="b" style="width:120px;height:${p.h * RD.PX * s}px"><div style="transform:scale(${s});transform-origin:0 0">${p.html}</div></div><span>${i + 1}</span></div>`; }).join("");
    }
    let hits = [], hi = -1;
    function highlight() {
      hits = [];
      const q = S.find.trim(); if (!q) { $(".rdp-find .fcnt").textContent = ""; return; }
      pagesEl.querySelectorAll(".rdt span, td").forEach(el => { if (el.textContent.indexOf(q) >= 0) { el.classList.add("rdp-hit"); hits.push(el); } });
      $(".rdp-find .fcnt").textContent = hits.length ? hits.length + " نتيجة" : "لا نتائج";
    }
    function findStep(d) { if (!hits.length) return; hits.forEach(h => h.classList.remove("cur")); hi = (hi + d + hits.length) % hits.length; hits[hi].classList.add("cur"); hits[hi].scrollIntoView({ block: "center" }); const pw = hits[hi].closest(".rdp-pw"); if (pw) { S.page = +pw.dataset.p; status(); } }
    const fname = () => (o.title || S.design.name || "ANOUER").replace(/[\\/:*?"<>|]/g, "_");
    function menu(btn, items) { const r = btn.getBoundingClientRect(); const m = ctx(r.right, r.bottom + 2, items); m.classList.add("ltr"); m.style.left = Math.max(4, Math.min(r.left, innerWidth - m.offsetWidth - 4)) + "px"; }
    function act(a, btn) {
      const pg = Object.assign({}, S.design.page, S.over.page || {});
      switch (a) {
        case "close": close(); break;
        case "maxw": ov.classList.toggle("max"); break;
        case "print": RD.printResult(S.res, { dialog: true, current: S.page || 0, printer: o.item && o.item.printer, copies: (o.item && o.item.copies) || 1, title: fname() }).catch(() => { }); break;
        case "qprint": RD.printResult(S.res, { printer: o.item && o.item.printer, copies: (o.item && o.item.copies) || 1, title: fname() }).catch(() => { }); break;
        case "params": paramsDlg(); break;
        case "save": { const blob = new Blob([RD.docHTML(S.res, fname())], { type: "text/html" }); const l = document.createElement("a"); l.href = URL.createObjectURL(blob); l.download = fname() + ".html"; document.body.appendChild(l); l.click(); setTimeout(() => { URL.revokeObjectURL(l.href); l.remove(); }, 800); T("تم حفظ المستند «" + l.download + "»", "s"); break; }
        case "open": { const inp = document.createElement("input"); inp.type = "file"; inp.accept = ".html,.htm"; inp.onchange = () => { const f = inp.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => { const doc = new DOMParser().parseFromString(r.result, "text/html"); const ps = Array.from(doc.querySelectorAll(".rdp")); if (!ps.length) { msg("الملف ليس مستند ANOUER محفوظاً"); return; } S.res = { pages: ps.map(p => ({ w: parseFloat(p.style.width), h: parseFloat(p.style.height), html: p.outerHTML })), w: parseFloat(ps[0].style.width), h: parseFloat(ps[0].style.height) }; S.page = 0; draw(); }; r.readAsText(f); }; inp.click(); break; }
        case "scale": menu(btn, [50, 75, 90, 100, 110, 125, 150].map(v => ({ t: v + " %" + (S.scale === v ? "  ✔" : ""), fn: () => { S.scale = v; draw(); } }))); break;
        case "margins": menu(btn, [["Normal", [10, 10, 10, 10]], ["Narrow", [5, 5, 5, 5]], ["Moderate", [12, 8, 12, 8]], ["Wide", [20, 20, 20, 20]], ["None", [0, 0, 0, 0]], ["Design", null]].map(m => ({ t: m[0] + (m[1] ? "  (" + m[1][0] + " mm)" : ""), fn: () => { S.over.margins = m[1]; render(); } }))); break;
        case "orient": menu(btn, [["Portrait", false], ["Landscape", true]].map(x => ({ t: x[0] + (!!pg.land === x[1] ? "  ✔" : ""), fn: () => { S.over.page = Object.assign({}, S.over.page || {}, { land: x[1] }); render(); } }))); break;
        case "size": menu(btn, RD.SIZES.map(s => ({ t: s[0] + "  " + s[1] + (s[2] ? " × " + s[2] : "") + " mm", fn: () => { S.over.page = Object.assign({}, S.over.page || {}, { w: s[1], h: s[2] }); render(); } }))); break;
        case "find": ov.classList.toggle("finding"); if (ov.classList.contains("finding")) setTimeout(() => $(".rdp-find input").focus(), 0); break;
        case "fnext": findStep(1); break; case "fprev": findStep(-1); break;
        case "fclose": ov.classList.remove("finding"); S.find = ""; draw(); break;
        case "thumbs": S.thumbs = !S.thumbs; ov.classList.toggle("thumbs", S.thumbs); if (S.thumbs) drawThumbs(); break;
        case "first": go(0); break; case "prev": go(S.page - 1); break; case "next": go(S.page + 1); break; case "last": go(S.res.pages.length - 1); break;
        case "tptr": case "thand": case "tmag": S.tool = a.slice(1); ov.querySelectorAll(".rdr-tools .rdr-s").forEach(b => b.classList.toggle("on", b.dataset.a === a)); view.classList.toggle("hand", S.tool === "hand"); view.classList.toggle("mag", S.tool === "mag"); break;
        case "many": menu(btn, [[1, "1 Page"], [2, "2 Pages"], [3, "3 Pages"], [4, "4 Pages"]].map(x => ({ t: x[1] + (S.many === x[0] ? "  ✔" : ""), fn: () => { S.many = x[0]; draw(); } }))); break;
        case "zout": setZoom(S.zoom > 1 ? S.zoom - 0.25 : S.zoom - 0.1); break;
        case "zin": setZoom(S.zoom >= 1 ? S.zoom + 0.25 : S.zoom + 0.1); break;
        case "zoom": menu(btn, [["Page Width", fitW], ["Whole Page", fitP]].map(x => ({ t: x[0], fn: x[1] })).concat([10, 25, 50, 75, 100, 150, 200, 300, 500].map(v => ({ t: v + "%", fn: () => setZoom(v / 100) })))); break;
        case "pcolor": { const c = document.createElement("input"); c.type = "color"; c.value = pg.color || "#ffffff"; c.oninput = () => { S.over.page = Object.assign({}, S.over.page || {}, { color: c.value }); render(); }; c.click(); break; }
        case "wmark": RD.wmDialog(Object.assign({}, pg.wm || {}), wm => { S.over.page = Object.assign({}, S.over.page || {}, { wm }); render(); }); break;
        case "export": menu(btn, [["PDF File", () => RD.exportPdf(S.res, fname())], ["HTML File", () => act("save")], ["XLSX File", () => expXlsx()], ["CSV File", () => expCsv()]].map(x => ({ t: x[0], fn: x[1] }))); break;
        case "mail": if (window.ANOUER_MAIL) { ANOUER_MAIL.report(S.res, fname()); break; }
        case "mail": menu(btn, [["PDF File", () => RD.exportPdf(S.res, fname()).then(r => { if (r && r.path) { location.href = "mailto:?subject=" + encodeURIComponent(fname()) + "&body=" + encodeURIComponent("المرفق: " + r.path); T("أرفق الملف من: " + r.path, "i"); } })]].map(x => ({ t: x[0], fn: x[1] }))); break;
      }
    }
    function rowsOf() {
      const f = RD.fieldsOf(S.design).Items.map(x => x.n), it = (S.data.items || []);
      return [f].concat(it.map(r => f.map(k => r[k] == null ? "" : r[k])));
    }
    function expCsv() {
      const q = v => { v = String(v); return /[",\n;]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
      const txt = "﻿" + rowsOf().map(r => r.map(q).join(",")).join("\r\n");
      const l = document.createElement("a"); l.href = URL.createObjectURL(new Blob([txt], { type: "text/csv;charset=utf-8" })); l.download = fname() + ".csv"; document.body.appendChild(l); l.click(); setTimeout(() => { URL.revokeObjectURL(l.href); l.remove(); }, 800);
    }
    function expXlsx() {
      if (!window.XLSX) { expCsv(); return; }
      const h = S.data.header || {}, wb = XLSX.utils.book_new();
      const head = Object.keys(h).map(k => [k, h[k]]);
      const ws = XLSX.utils.aoa_to_sheet(head.concat([[]]).concat(rowsOf()));
      ws["!views"] = [{ RTL: true }];
      XLSX.utils.book_append_sheet(wb, ws, "Report");
      XLSX.writeFile(wb, fname() + ".xlsx");
    }
    function paramsDlg() {
      const ps = S.design.params || []; if (!ps.length) return;
      const D = dlg({ w: 420, title: "Parameters", body: `<div class="rdm-form">${ps.map(p => fld(p.desc || p.name, `<input data-k="${esc(p.name)}" value="${esc(S.params && p.name in S.params ? S.params[p.name] : p.value == null ? "" : p.value)}"${p.type === "n" ? ' type="number"' : p.type === "d" ? ' type="date"' : ""}>`)).join("")}</div>`,
        buttons: [{ t: "Reset", cls: "blue", fn: x => { S.params = null; x.close(); render(); } }, { t: "Submit", cls: "green", fn: x => { S.params = {}; ps.forEach(p => { const v = x.$(`[data-k="${p.name}"]`).value; S.params[p.name] = p.type === "n" ? +v : v; }); x.close(); render(); } }] });
    }
    ov.addEventListener("click", e => { const b = e.target.closest("[data-a]"); if (!b || b.disabled || b.classList.contains("dis") && /first|prev|next|last/.test(b.dataset.a)) return; act(b.dataset.a, b); });
    $(".rdp-st .zr").addEventListener("input", e => setZoom(+e.target.value / 100));
    $(".rdp-find input").addEventListener("input", e => { S.find = e.target.value; pagesEl.querySelectorAll(".rdp-hit").forEach(x => x.classList.remove("rdp-hit", "cur")); hi = -1; highlight(); if (hits.length) findStep(1); });
    $(".rdp-find input").addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); findStep(e.shiftKey ? -1 : 1); } });
    $(".rdp-thumbs").addEventListener("click", e => { const t = e.target.closest(".t"); if (t) go(+t.dataset.p); });
    pagesEl.addEventListener("click", e => { const p = e.target.closest(".rdp-pw"); if (p && S.tool !== "hand") { S.page = +p.dataset.p; pagesEl.querySelectorAll(".rdp-pw").forEach((x, k) => x.classList.toggle("cur", k === S.page)); status(); } if (S.tool === "mag") setZoom(e.shiftKey || e.altKey ? S.zoom / 1.5 : S.zoom * 1.5); });
    let drag = null;
    view.addEventListener("mousedown", e => { if (S.tool !== "hand") return; drag = { x: e.clientX, y: e.clientY, sl: view.scrollLeft, st: view.scrollTop }; e.preventDefault(); });
    window.addEventListener("mousemove", e => { if (!drag) return; view.scrollLeft = drag.sl - (e.clientX - drag.x); view.scrollTop = drag.st - (e.clientY - drag.y); });
    window.addEventListener("mouseup", () => { drag = null; });
    view.addEventListener("wheel", e => { if (e.ctrlKey) { e.preventDefault(); setZoom(S.zoom * (e.deltaY < 0 ? 1.1 : 1 / 1.1)); } }, { passive: false });
    view.addEventListener("scroll", () => { const ps = pagesEl.children; const vr = view.getBoundingClientRect(); for (let i = 0; i < ps.length; i++) { const r = ps[i].getBoundingClientRect(); if (r.bottom > vr.top + 40) { if (S.page !== i) { S.page = i; status(); pagesEl.querySelectorAll(".rdp-pw").forEach((x, k) => x.classList.toggle("cur", k === i)); } break; } } });
    const key = e => {
      if (!ov.isConnected || document.querySelector(".rdm-dov")) return;
      if (o.embed && !ov.offsetParent) return;
      if (e.key === "Escape" && !o.embed) { e.preventDefault(); e.stopImmediatePropagation(); if (ov.classList.contains("finding")) act("fclose"); else close(); }
      else if (e.ctrlKey && (e.key === "p" || e.key === "P")) { e.preventDefault(); e.stopImmediatePropagation(); act("print"); }
      else if (e.ctrlKey && (e.key === "f" || e.key === "F")) { e.preventDefault(); e.stopImmediatePropagation(); act("find"); }
      else if (e.key === "PageDown") { e.preventDefault(); go(S.page + 1); } else if (e.key === "PageUp") { e.preventDefault(); go(S.page - 1); }
      else if (e.ctrlKey && e.key === "Home") { e.preventDefault(); go(0); } else if (e.ctrlKey && e.key === "End") { e.preventDefault(); go(S.res.pages.length - 1); }
      else if (e.ctrlKey && (e.key === "+" || e.key === "=")) { e.preventDefault(); act("zin"); } else if (e.ctrlKey && e.key === "-") { e.preventDefault(); act("zout"); }
    };
    window.addEventListener("keydown", key, true);
    function close() { window.removeEventListener("keydown", key, true); ov.remove(); if (o.onClose) o.onClose(); }
    render();
    // التكبير المبدئي: الصفحة كاملة للإيصالات، و«عرض الصفحة» لما يتسع
    setTimeout(() => { if (!S.res.pages.length) return; if (!o.zoom) { const p = S.res.pages[0], fit = Math.min((view.clientWidth - 40) / (p.w * RD.PX), 1.5); if (fit < 1) setZoom(fit); } }, 0);
    return { ov, close, rerender: (d, data) => { if (d) S.design = RD.clone(d); if (data) S.data = data; render(); }, state: S };
  }
  window.ANOUER_RDP = { open: pvOpen };

  /* العلامة المائية (مشتركة مع المصمم) */
  RD.wmDialog = function (wm, done) {
    wm = wm || {};
    const D = dlg({ w: 520, title: "Watermark", body: `<div class="rdm-form ltr">
      <div class="rdm-tabs"><button type="button" class="on" data-t="txt">Text Watermark</button><button type="button" data-t="img">Picture Watermark</button></div>
      <div class="pane" data-p="txt">${fld("Text", `<input data-k="text" value="${esc(wm.text || "")}" placeholder="نسخة / مدفوع / CONFIDENTIAL" list="rdWmList"><datalist id="rdWmList"><option value="نسخة"><option value="مدفوع"><option value="غير مدفوع"><option value="ملغاة"><option value="ASAP"><option value="CONFIDENTIAL"><option value="DRAFT"></datalist>`)}
        <div class="rdm-two">${fld("Direction", `<select data-k="dir">${opt([["fd", "Forward Diagonal"], ["bd", "Backward Diagonal"], ["h", "Horizontal"]], wm.dir || "fd")}</select>`)}${fld("Color", `<input type="color" data-k="color" value="${esc(wm.color || "#808080")}">`)}</div>
        <div class="rdm-two">${fld("Font", `<select data-k="font">${opt(["Arial", "Tahoma", "Segoe UI", "Times New Roman", "Verdana"], wm.font || "Arial")}</select>`)}${fld("Size", `<input type="number" data-k="size" value="${wm.size || 54}" min="8" max="200">`)}</div>
        <div class="rdm-two">${fld("Transparency %", `<input type="range" data-k="op" min="0" max="100" value="${wm.op == null ? 15 : wm.op}">`)}<label class="rdm-chk"><input type="checkbox" data-k="b"${wm.b ? " checked" : ""}><span>Bold</span></label></div></div>
      <div class="pane" data-p="img" hidden>${fld("Image", `<button type="button" class="rdm-btn blue sm" data-a="load">Load…</button> <button type="button" class="rdm-btn red sm" data-a="clr">Clear</button><span class="im">${wm.img ? "✔ صورة محمّلة" : ""}</span>`)}
        ${fld("Size Mode", `<select data-k="imgMode">${opt([["zoom", "Zoom"], ["stretch", "Stretch"], ["clip", "Clip"]], wm.imgMode || "zoom")}</select>`)}${fld("Transparency %", `<input type="range" data-k="imgOp" min="0" max="100" value="${wm.imgOp == null ? 30 : wm.imgOp}">`)}</div>
      <label class="rdm-chk"><input type="checkbox" data-k="front"${wm.front ? " checked" : ""}><span>In front</span></label></div>`,
      buttons: [{ t: "Clear All", cls: "red", fn: x => { x.close(); done(null); } }, { t: "Cancel", cls: "blue", fn: x => x.close() }, { t: "OK", cls: "green", fn: x => { const v = vals(x.box); x.close(); done(Object.assign(wm, { text: v.text, dir: v.dir, color: v.color, font: v.font, size: +v.size || 54, op: +v.op, b: v.b, imgMode: v.imgMode, imgOp: +v.imgOp, front: v.front })); } }] });
    D.$$(".rdm-tabs button").forEach(b => b.onclick = () => { D.$$(".rdm-tabs button").forEach(z => z.classList.toggle("on", z === b)); D.$$(".pane").forEach(p => p.hidden = p.dataset.p !== b.dataset.t); });
    D.$('[data-a="load"]').onclick = () => RD.pickImage(src => { wm.img = src; D.$(".im").textContent = "✔ صورة محمّلة"; });
    D.$('[data-a="clr"]').onclick = () => { wm.img = ""; D.$(".im").textContent = ""; };
  };
  RD.pickImage = function (cb, maxPx) {
    const inp = document.createElement("input"); inp.type = "file"; inp.accept = "image/*";
    inp.onchange = () => {
      const f = inp.files && inp.files[0]; if (!f) return;
      const r = new FileReader();
      r.onload = () => {
        const img = new Image();
        img.onload = () => {
          const mx = maxPx || 900, k = Math.min(1, mx / Math.max(img.width, img.height));
          if (k >= 1 && f.size < 300000) { cb(r.result); return; }
          const c = document.createElement("canvas"); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
          c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
          cb(c.toDataURL(/png|gif|svg/.test(f.type) ? "image/png" : "image/jpeg", 0.88));
        };
        img.onerror = () => msg("تعذّر قراءة الصورة");
        img.src = r.result;
      };
      r.readAsDataURL(f);
    };
    inp.click();
  };
})();
