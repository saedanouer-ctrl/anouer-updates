/* ANOUER — «تصميم التقارير» (مطابق Dexef Report Designer): المحرّك المشترك
   • نموذج التصميم (بنود Bands + عناصر Controls بالمليمتر) والتصاميم الجاهزة لكل تعامل
   • لغة التعبيرات (مثل DevExpress): [Field] ، Iif() ، FormatString() ، Sum() … بلا eval
   • التنسيق ({0:n2} ، dd/MM/yyyy …) والتفقيط بالعربية
   • الإخراج: تصميم + بيانات → صفحات HTML مقسّمة (A4 / ورق كاشير متصل / ملصقات باركود)
   • الطباعة: مباشرة على طابعة التصميم (المضيف print.html) أو نافذة الطباعة أو PDF */
(function () {
  "use strict";
  if (window.ANOUER_RD) return;
  const RD = window.ANOUER_RD = {};
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const call = (a, p) => Anouer.call(a, p || {});
  const T = (m, k) => { try { toast(m, k || "i"); } catch (e) { console.log(m); } };
  const clone = o => o == null ? o : JSON.parse(JSON.stringify(o));
  const PX = 96 / 25.4;   // بكسل لكل مم
  const uid = () => "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  RD.esc = esc; RD.clone = clone; RD.PX = PX; RD.uid = uid;

  /* ================================================================== التعاملات (قائمة DEXEF) */
  RD.TXS = ["ايرادات", "إيصال دفع نقدية", "إيصال استلام نقدية", "مصروفات", "ورقة مالية", "المطالبة", "مبيعات الصالة", "طلبات التوصيل", "مشتريات", "إذن استلام معتمد", "أمر شراء", "طلبية مشتريات", "استلام عروض اسعار", "إستلام بضاعة أمانة", "مرتجع مشتريات", "مرتجع مبيعات", "مرتجع بضاعة أمانة", "مبيعات", "إذن صرف معتمد", "فاتورة أولية", "أمر توريد", "عرض السلعة", "تحويلات الأرصدة", "تجميع صنف", "صدقات من المخزون", "تحويلات المخازن", "تفكيك الصنف", "هالك المخزون", "إذن استلام", "إذن استلام تحويل", "صرف بضاعة", "مخزون أول المدة", "إذن صرف", "إذن صرف تحويل", "حجز بضاعة", "إلغاء حجز بضاعة", "طلب حجز بضاعة", "استلام بضاعة", "طلب صرف بضاعة", "طلب تحويل بضاعة"];
  const VCH = ["ايرادات", "إيصال دفع نقدية", "إيصال استلام نقدية", "مصروفات", "ورقة مالية", "المطالبة", "تحويلات الأرصدة"];
  RD.schemaOf = (kind, tx) => kind === "bc" ? "lbl" : kind === "rep" ? "rep" : VCH.indexOf(tx) >= 0 ? "vch" : "inv";

  /* ================================================================== الحقول (قائمة الحقول) */
  const F = (n, a, t) => ({ n, a, t: t || "s" });   // t: s نص ، n رقم ، d تاريخ ، b منطقي ، i صورة
  const COMPANY = [F("Company Name", "اسم الشركة"), F("Company Name Fr", "الاسم باللاتينية"), F("Activity", "النشاط"), F("Company Address", "العنوان"), F("Company Phone", "الهاتف"), F("Company Mobile", "الموبايل"), F("Company Email", "البريد الإلكتروني"), F("NIF", "الرقم الجبائي"), F("NIS", "رقم التعريف الإحصائي"), F("RC", "السجل التجاري"), F("AI", "رقم المادة"), F("Currency", "العملة"), F("Invoice Footer", "تذييل الفاتورة"), F("Social Facebook", "حساب فيسبوك"), F("Social YouTube", "حساب يوتيوب"), F("Social TikTok", "حساب تيك توك")];
  RD.SCHEMA = {
    inv: {
      Header: [F("Number", "رقم الفاتورة"), F("Transaction", "نوع التعامل"), F("Date", "التاريخ", "d"), F("Time", "الوقت"), F("Customer Name", "اسم العميل"), F("Customer Code", "كود العميل"), F("Customer Phone", "هاتف العميل"), F("Customer Address", "عنوان العميل"), F("WrittenBy", "المستخدم"), F("Branch", "الفرع"), F("Store", "المخزن"), F("Payment Method", "طريقة الدفع"), F("Reference", "المرجع"), F("Notes", "الملاحظات"),
        F("Item Count", "عدد الأصناف", "n"), F("Qty Total", "إجمالي الكميات", "n"), F("Before Discount", "الإجمالي قبل الخصم", "n"), F("Discount", "الخصم", "n"), F("Extra", "الإضافى", "n"), F("Taxes", "الضرائب", "n"), F("Net Amount", "الإجمالي", "n"), F("Paid", "المدفوع", "n"), F("Remain", "الباقى", "n"), F("Previous Balance", "الرصيد السابق", "n"), F("Current Balance", "الرصيد الحالى", "n"), F("Amount In Words", "المبلغ بالحروف"), F("Amount Short", "المبلغ مختصراً"), F("Amount Words", "المبلغ بالحروف (بدون فقط)"), F("Currency Code", "رمز العملة"), F("Payment Type", "نقدي / آجل"), F("Treasury", "الخزينة"), F("Payment Policy", "سياسة التعامل"), F("Payment Policy Line", "سطر سياسة التعامل")],
      Items: [F("Index", "م", "n"), F("Item Code", "كود الصنف"), F("Barcode", "الباركود"), F("Item Name", "اسم الصنف"), F("Unite", "الوحدة"), F("Qty", "الكمية", "n"), F("Price", "السعر", "n"), F("Item Discount", "خصم الصنف", "n"), F("Net Price", "صافى السعر", "n"), F("Total", "الإجمالي", "n"), F("Group", "المجموعة"), F("Description", "الوصف")],
      Company: COMPANY
    },
    vch: {
      Header: [F("Number", "الرقم"), F("Transaction", "نوع التعامل"), F("Date", "التاريخ", "d"), F("Time", "الوقت"), F("Party Name", "الاسم"), F("Amount", "المبلغ", "n"), F("Amount In Words", "المبلغ بالحروف"), F("Statement", "البيان"), F("Account", "الحساب / الخزينة"), F("Payment Method", "طريقة الدفع"), F("WrittenBy", "المستخدم"), F("Branch", "الفرع"), F("Notes", "الملاحظات"), F("Previous Balance", "الرصيد السابق", "n"), F("Current Balance", "الرصيد الحالى", "n")],
      Items: [F("Index", "م", "n"), F("Account", "الحساب"), F("Amount", "المبلغ", "n"), F("Notes", "البيان")],
      Company: COMPANY
    },
    lbl: {
      Header: [F("Print Date", "تاريخ الطباعة", "d")],
      Items: [F("Item Name", "اسم الصنف"), F("Item Code", "كود الصنف"), F("Barcode", "الباركود"), F("Price", "سعر البيع", "n"), F("Old Price", "السعر القديم", "n"), F("Unite", "الوحدة"), F("Group", "المجموعة"), F("Index", "م", "n")],
      Company: COMPANY
    },
    rep: {
      Header: [F("Report Title", "عنوان التقرير"), F("Print Date", "تاريخ الطباعة", "d"), F("WrittenBy", "المستخدم"), F("Row Count", "عدد السجلات", "n")],
      Items: [],
      Company: COMPANY
    }
  };
  /* بيانات «إضافة تقرير» (التقارير المضافة) */
  RD.DATASETS = {
    items: { t: "قائمة الأصناف", f: [F("Index", "م", "n"), F("Code", "الكود"), F("Name", "اسم الصنف"), F("Unite", "الوحدة"), F("Price", "سعر البيع", "n"), F("Stock", "الرصيد", "n"), F("Group", "المجموعة")] },
    customers: { t: "قائمة العملاء", f: [F("Index", "م", "n"), F("Code", "الكود"), F("Name", "الاسم"), F("Phone", "الهاتف"), F("Address", "العنوان"), F("Balance", "الرصيد", "n")] },
    sales: { t: "فواتير المبيعات", f: [F("Index", "م", "n"), F("Number", "رقم الفاتورة"), F("Date", "التاريخ", "d"), F("Customer", "العميل"), F("Count", "عدد الأصناف", "n"), F("Total", "الإجمالي", "n"), F("Paid", "المدفوع", "n"), F("Remain", "الباقى", "n")] }
  };
  /* حقول DEXEF الأصلية (للتصاميم المنقولة من DEXEF) */
  const DXC = [F("Company Name", "اسم الشركة"), F("Field", "النشاط"), F("Phone No.1", "الهاتف 1"), F("Phone No.2", "الهاتف 2"), F("currency", "العملة"), F("Email", "البريد"), F("Tax ID", "الرقم الضريبي"), F("Company Logo", "الشعار", "i")];
  const DXS = {
    inv: { Header: [F("Number", "رقم الفاتورة"), F("Date", "التاريخ", "d"), F("Transaction Title", "عنوان التعامل"), F("TransactionName", "التعامل"), F("Customer Name", "اسم العميل"), F("Customer Phone1", "الهاتف 1"), F("Customer Phone2", "الهاتف 2"), F("Customer Adress", "العنوان"), F("Customer VAT Number", "الرقم الضريبي للعميل"), F("Customer Balance", "رصيد العميل", "n"), F("Footer_Amount", "الإجمالي", "n"), F("Footer_Discount", "الخصم", "n"), F("Footer_Extra", "الإضافى", "n"), F("Taxes", "الضرائب", "n"), F("Footer_Net_Amount", "الصافى", "n"), F("Footer_Payment", "المدفوع", "n"), F("Footer_Remain", "الباقى", "n"), F("Amount In Words", "المبلغ بالحروف"), F("Amount Short", "المبلغ مختصراً"), F("Amount Words", "المبلغ بالحروف (بدون فقط)"), F("Currency Code", "رمز العملة"), F("Payment Type", "نقدي / آجل"), F("Treasury", "الخزينة"), F("Payment Policy", "سياسة التعامل"), F("Payment Policy Line", "سطر سياسة التعامل"), F("Payment Method", "طريقة الدفع"), F("WrittenBy", "المستخدم"), F("Branchname", "الفرع"), F("Note", "الملاحظات"), F("PaymentTerms_DueDate", "الاستحقاق", "d"), F("Currency", "العملة"), F("QR Text", "نص QR")],
      Items: [F("RowNumber", "م", "n"), F("Item Code", "كود الصنف"), F("Item Barcode", "الباركود"), F("Item Name", "اسم الصنف"), F("Unite", "الوحدة"), F("Qty", "الكمية", "n"), F("Price", "السعر", "n"), F("NetPrice", "صافى السعر", "n"), F("TotalDiscount", "الخصم", "n"), F("Total", "الإجمالي", "n"), F("Item Description", "الوصف"), F("ItemTxt1", "نص 1")] },
    vch: { Header: [F("BillNum", "الرقم"), F("Dt", "التاريخ", "d"), F("AccountName", "الاسم"), F("Value", "المبلغ", "n"), F("AccountBalance", "الرصيد", "n"), F("Note", "الملاحظات"), F("PaymentIndex", "طريقة الدفع"), F("WrittenBy", "المستخدم"), F("Currency", "العملة")], Items: [] },
    lbl: { Header: [F("Print Date", "تاريخ الطباعة", "d")],
      Items: [F("Item Name", "اسم الصنف"), F("Item Barcode", "الباركود"), F("Item Code", "كود الصنف"), F("Price", "السعر", "n"), F("price1", "سعر 1 (التجزئة)", "n"), F("price2", "سعر 2 (عابر سبيل)", "n"), F("price3", "سعر 3 (استطلاع)", "n"), F("price4", "سعر 4 (الجملة)", "n"), F("price5", "سعر 5 (5 ومافوق)", "n"), F("price6", "سعر 6", "n"), F("price7", "سعر 7", "n"), F("price8", "سعر 8", "n"), F("Location1", "مكان التخزين 1"), F("Location 2", "مكان التخزين 2"), F("Location 3", "مكان التخزين 3"), F("Item Description", "الوصف"), F("Unite", "الوحدة"), F("txt1", "نص 1"), F("txt2", "نص 2"), F("txt3", "نص 3"), F("txt4", "نص 4")] }
  };
  RD.fieldsOf = function (d) {
    if (d.src === "dexef") { const k = RD.schemaOf(d.kind, d.tx), x = DXS[k] || DXS.inv; return { Header: x.Header, Items: x.Items, Company: DXC }; }
    const sc = RD.SCHEMA[RD.schemaOf(d.kind, d.tx)] || RD.SCHEMA.inv;
    const items = d.kind === "rep" ? ((RD.DATASETS[d.dataset] || RD.DATASETS.items).f) : sc.Items;
    return { Header: sc.Header, Items: items, Company: sc.Company };
  };

  /* ================================================================== التفقيط (المبلغ بالحروف) */
  const ONES = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
  const TENS = ["", "", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
  const HUND = ["", "مائة", "مائتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة"];
  function w999(n) {
    const h = Math.floor(n / 100), r = n % 100, out = [];
    if (h) out.push(HUND[h]);
    if (r) { if (r < 20) out.push(ONES[r]); else { const o = r % 10, t = Math.floor(r / 10); out.push(o ? ONES[o] + " و" + TENS[t] : TENS[t]); } }
    return out.join(" و");
  }
  const SCALES = [["", "", "", ""], ["ألف", "ألفان", "آلاف", "ألف"], ["مليون", "مليونان", "ملايين", "مليون"], ["مليار", "ملياران", "مليارات", "مليار"]];
  function intWords(n) {
    n = Math.floor(Math.abs(n));
    if (!n) return "صفر";
    const parts = []; let i = 0;
    while (n > 0 && i < SCALES.length) {
      const g = n % 1000; n = Math.floor(n / 1000);
      if (g) {
        const s = SCALES[i]; let w;
        if (!i) w = w999(g);
        else if (g === 1) w = s[0];
        else if (g === 2) w = s[1];
        else if (g <= 10) w = w999(g) + " " + s[2];
        else w = w999(g) + " " + s[3];
        parts.unshift(w);
      }
      i++;
    }
    return parts.join(" و");
  }
  RD.tafqit = function (v, cur, sub) {
    v = Math.round((+v || 0) * 100) / 100;
    const neg = v < 0; v = Math.abs(v);
    const i = Math.floor(v), f = Math.round((v - i) * 100);
    cur = cur || "دينار جزائري"; sub = sub || "سنتيم";
    let s = "فقط " + intWords(i) + " " + cur;
    if (f) s += " و" + intWords(f) + " " + sub;
    return (neg ? "سالب " : "") + s + " لا غير";
  };

  /* ================================================================== التنسيق */
  function pad(n, l) { n = String(n); while (n.length < l) n = "0" + n; return n; }
  function toDate(v) {
    if (v instanceof Date) return v;
    if (v == null || v === "") return null;
    const s = String(v);
    let m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/.exec(s);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
    m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(s);
    if (m) return new Date(+m[3], +m[2] - 1, +m[1]);
    const d = new Date(s); return isNaN(d) ? null : d;
  }
  function fmtDate(d, f) {
    if (!d) return "";
    return f.replace(/yyyy|yy|MMMM|MM|M|dddd|dd|d|HH|H|hh|h|mm|m|ss|s|tt/g, k => {
      switch (k) {
        case "yyyy": return d.getFullYear(); case "yy": return pad(d.getFullYear() % 100, 2);
        case "MMMM": return ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"][d.getMonth()];
        case "MM": return pad(d.getMonth() + 1, 2); case "M": return d.getMonth() + 1;
        case "dddd": return ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"][d.getDay()];
        case "dd": return pad(d.getDate(), 2); case "d": return d.getDate();
        case "HH": return pad(d.getHours(), 2); case "H": return d.getHours();
        case "hh": return pad(d.getHours() % 12 || 12, 2); case "h": return d.getHours() % 12 || 12;
        case "mm": return pad(d.getMinutes(), 2); case "m": return d.getMinutes();
        case "ss": return pad(d.getSeconds(), 2); case "s": return d.getSeconds();
        case "tt": return d.getHours() < 12 ? "ص" : "م";
      }
      return k;
    });
  }
  function grp(intStr, sep) { return intStr.replace(/\B(?=(\d{3})+(?!\d))/g, sep); }
  function fmtNum(n, f) {
    if (typeof n !== "number") { const x = parseFloat(n); if (isNaN(x)) return String(n == null ? "" : n); n = x; }
    const m = /^([NnFfCcPpDd])(\d*)$/.exec(f);
    if (m) {
      const k = m[1].toUpperCase(), dg = m[2] === "" ? (k === "D" ? 0 : 2) : +m[2];
      if (k === "D") { const s = pad(Math.abs(Math.round(n)), dg); return (n < 0 ? "-" : "") + s; }
      if (k === "P") n *= 100;
      const neg = n < 0, s = Math.abs(n).toFixed(dg), [a, b] = s.split(".");
      const body = (k === "F" ? a : grp(a, ",")) + (b ? "." + b : "");
      return (neg ? "-" : "") + body + (k === "P" ? " %" : k === "C" ? " " + (RD.currency || "DZD") : "");
    }
    // نمط مخصص: #,##0.00 ، 0.000 ، 0%
    if (/[#0]/.test(f)) {
      const pct = /%/.test(f); if (pct) n *= 100;
      const sec = f.split(";"), use = n < 0 && sec[1] ? sec[1] : sec[0], neg = n < 0 && !sec[1];
      const mm = /([#0,]*)(?:\.([#0]+))?/.exec(use.replace(/[^#0,.]/g, "")) || [];
      const dec = mm[2] || "", minD = (dec.match(/0/g) || []).length, maxD = dec.length;
      let s = Math.abs(n).toFixed(maxD);
      if (maxD > minD) s = s.replace(new RegExp("0{1," + (maxD - minD) + "}$"), "").replace(/\.$/, "");
      let [a, b] = s.split(".");
      const minI = ((mm[1] || "").match(/0/g) || []).length; a = pad(a, minI);
      if (/,/.test(mm[1] || "")) a = grp(a, ",");
      const body = a + (b ? "." + b : "");
      const pre = use.slice(0, use.search(/[#0,.]/)), post = use.slice(use.search(/[#0.][^#0,.]*$/) + 1).replace(/^[#0,.]+/, "");
      return (neg ? "-" : "") + pre + body + post.replace(/%/, pct ? " %" : "");
    }
    return String(n);
  }
  function fmtOne(v, f) {
    if (!f) return v == null ? "" : (typeof v === "number" ? (Number.isInteger(v) ? String(v) : String(Math.round(v * 10000) / 10000)) : (v instanceof Date ? fmtDate(v, "dd/MM/yyyy") : String(v)));
    if (/^[NnFfCcPpDd]\d*$/.test(f) || /^[#0,.%;\s\-+()DZA]+$/.test(f) && /[#0]/.test(f)) return fmtNum(v, f);
    const d = v instanceof Date ? v : toDate(v);
    if (d && /[dMyHhms]/.test(f)) return fmtDate(d, f);
    if (/^[NnFfCcPpDd]\d*$/.test(f)) return fmtNum(v, f);
    return v == null ? "" : String(v);
  }
  /* FormatString: "{0:n2} DZD" ، "{0}" ، أو نمط مجرّد "n2" */
  RD.format = function (f, args) {
    if (!Array.isArray(args)) args = [args];
    if (f == null || f === "") return fmtOne(args[0], "");
    if (/\{\d+(:[^}]*)?\}/.test(f)) return f.replace(/\{(\d+)(?::([^}]*))?\}/g, (m, i, ff) => fmtOne(args[+i], ff || ""));
    return fmtOne(args[0], f);
  };
  RD.fmtNum = fmtNum; RD.fmtDate = fmtDate; RD.toDate = toDate;

  /* ================================================================== لغة التعبيرات */
  function lex(src) {
    const out = []; let i = 0;
    while (i < src.length) {
      const c = src[i];
      if (/\s/.test(c)) { i++; continue; }
      if (c === "[") { const j = src.indexOf("]", i); if (j < 0) throw new Error("قوس [ غير مغلق"); out.push({ t: "f", v: src.slice(i + 1, j).trim() }); i = j + 1; continue; }
      if (c === "'" || c === '"') {
        let j = i + 1, s = "";
        while (j < src.length) { if (src[j] === c) { if (src[j + 1] === c) { s += c; j += 2; continue; } break; } s += src[j++]; }
        if (j >= src.length) throw new Error("نص غير مغلق");
        out.push({ t: "s", v: s }); i = j + 1; continue;
      }
      if (c === "#") { const j = src.indexOf("#", i + 1); if (j < 0) throw new Error("تاريخ غير مغلق"); out.push({ t: "s", v: toDate(src.slice(i + 1, j)) }); i = j + 1; continue; }
      if (/\d/.test(c) || (c === "." && /\d/.test(src[i + 1] || ""))) { const m = /^\d*\.?\d+(?:[eE][+-]?\d+)?[mMfFdD]?/.exec(src.slice(i)); out.push({ t: "n", v: parseFloat(m[0]) }); i += m[0].length; continue; }
      if (/[A-Za-z_؀-ۿ?]/.test(c)) { const m = /^[?A-Za-z_؀-ۿ][A-Za-z0-9_.؀-ۿ]*/.exec(src.slice(i)); out.push({ t: "id", v: m[0] }); i += m[0].length; continue; }
      const two = src.substr(i, 2);
      if (["<>", "!=", "==", "<=", ">=", "&&", "||"].indexOf(two) >= 0) { out.push({ t: "op", v: two }); i += 2; continue; }
      if ("+-*/%=<>(),!".indexOf(c) >= 0) { out.push({ t: "op", v: c }); i++; continue; }
      throw new Error("رمز غير معروف: " + c);
    }
    return out;
  }
  const PREC = { "or": 1, "||": 1, "and": 2, "&&": 2, "=": 3, "==": 3, "<>": 3, "!=": 3, "<": 3, ">": 3, "<=": 3, ">=": 3, "+": 4, "-": 4, "*": 5, "/": 5, "%": 5 };
  function parse(src) {
    const tk = lex(String(src)); let p = 0;
    const peek = () => tk[p], next = () => tk[p++];
    const opOf = t => t && (t.t === "op" ? t.v : t.t === "id" && /^(and|or)$/i.test(t.v) ? t.v.toLowerCase() : null);
    function primary() {
      const t = next();
      if (!t) throw new Error("تعبير ناقص");
      if (t.t === "n" || t.t === "s") return { k: "lit", v: t.v };
      if (t.t === "f") return { k: "fld", v: t.v };
      if (t.t === "op" && t.v === "(") { const e = expr(0); const c = next(); if (!c || c.v !== ")") throw new Error("قوس ) ناقص"); return e; }
      if (t.t === "op" && (t.v === "-" || t.v === "+")) return { k: "un", op: t.v, a: primary() };
      if (t.t === "op" && t.v === "!") return { k: "un", op: "not", a: primary() };
      if (t.t === "id") {
        const lw = t.v.toLowerCase();
        if (lw === "true") return { k: "lit", v: true }; if (lw === "false") return { k: "lit", v: false }; if (lw === "null") return { k: "lit", v: null };
        if (lw === "not") return { k: "un", op: "not", a: expr(3) };
        if (peek() && peek().v === "(") {
          next(); const args = [];
          if (peek() && peek().v !== ")") { do { args.push(expr(0)); } while (peek() && peek().v === "," && next()); }
          const c = next(); if (!c || c.v !== ")") throw new Error("قوس ) ناقص بعد " + t.v);
          if (!FN[lw] && !AGG[lw]) throw new Error("دالة غير معروفة: " + t.v);
          return { k: "fn", n: lw, a: args };
        }
        if (t.v.charAt(0) === "?") return { k: "par", v: t.v.slice(1) };
        return { k: "fld", v: t.v };
      }
      throw new Error("رمز غير متوقع: " + t.v);
    }
    function expr(min) {
      let l = primary();
      for (; ;) {
        const op = opOf(peek()); if (!op || PREC[op] === undefined || PREC[op] <= min) break;
        next(); const r = expr(PREC[op]); l = { k: "bin", op, l, r };
      }
      return l;
    }
    const e = expr(0);
    if (p < tk.length) throw new Error("رمز زائد: " + tk[p].v);
    return e;
  }
  const num = v => typeof v === "number" ? v : v == null || v === "" ? 0 : typeof v === "boolean" ? (v ? 1 : 0) : (isNaN(parseFloat(v)) ? 0 : parseFloat(v));
  const str = v => v == null ? "" : v instanceof Date ? fmtDate(v, "dd/MM/yyyy") : String(v);
  const truthy = v => v === true || (typeof v === "number" && v !== 0) || (typeof v === "string" && v !== "" && v.toLowerCase() !== "false");
  const FN = {
    iif: (a) => { for (let i = 0; i + 1 < a.length; i += 2) if (truthy(a[i]())) return a[i + 1](); return a.length % 2 ? a[a.length - 1]() : null; },
    isnull: a => { const v = a[0](); return a.length > 1 ? (v == null || v === "" ? a[1]() : v) : v == null; },
    isnullorempty: a => { const v = a[0](); return v == null || v === ""; },
    len: a => str(a[0]()).length, upper: a => str(a[0]()).toUpperCase(), lower: a => str(a[0]()).toLowerCase(), trim: a => str(a[0]()).trim(),
    substring: a => { const s = str(a[0]()), st = num(a[1]()); return a.length > 2 ? s.substr(st, num(a[2]())) : s.substr(st); },
    concat: a => a.map(f => str(f())).join(""), contains: a => str(a[0]()).indexOf(str(a[1]())) >= 0, startswith: a => str(a[0]()).indexOf(str(a[1]())) === 0,
    endswith: a => { const s = str(a[0]()), e = str(a[1]()); return s.slice(-e.length) === e; }, replace: a => str(a[0]()).split(str(a[1]())).join(str(a[2]())),
    padleft: a => { let s = str(a[0]()); const n = num(a[1]()), c = a.length > 2 ? str(a[2]()) || " " : " "; while (s.length < n) s = c + s; return s; },
    padright: a => { let s = str(a[0]()); const n = num(a[1]()), c = a.length > 2 ? str(a[2]()) || " " : " "; while (s.length < n) s += c; return s; },
    round: a => { const n = num(a[0]()), d = a.length > 1 ? num(a[1]()) : 0, m = Math.pow(10, d); return Math.round(n * m) / m; },
    floor: a => Math.floor(num(a[0]())), ceiling: a => Math.ceil(num(a[0]())), abs: a => Math.abs(num(a[0]())),
    max: a => Math.max.apply(null, a.map(f => num(f()))), min: a => Math.min.apply(null, a.map(f => num(f()))),
    tostr: a => str(a[0]()), toint: a => Math.trunc(num(a[0]())), todecimal: a => num(a[0]()), todouble: a => num(a[0]()),
    formatstring: a => RD.format(str(a[0]()), a.slice(1).map(f => f())),
    now: () => new Date(), today: () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; },
    getyear: a => (toDate(a[0]()) || new Date()).getFullYear(), getmonth: a => (toDate(a[0]()) || new Date()).getMonth() + 1, getday: a => (toDate(a[0]()) || new Date()).getDate(),
    adddays: a => { const d = new Date(toDate(a[0]()) || new Date()); d.setDate(d.getDate() + num(a[1]())); return d; },
    numtowords: a => RD.tafqit(num(a[0]()), a.length > 1 ? str(a[1]()) : "", a.length > 2 ? str(a[2]()) : ""), tafqit: a => RD.tafqit(num(a[0]()), a.length > 1 ? str(a[1]()) : "", a.length > 2 ? str(a[2]()) : ""),
    /* دوال DEXEF */
    horof: a => RD.tafqit(num(a[0]()), a.length > 1 ? RD.currencyName(str(a[1]())) : "", "سنتيم"),
    tofloat: a => num(a[0]()), tostring: a => str(a[0]()), tolong: a => Math.trunc(num(a[0]())), charindex: a => str(a[1]()).indexOf(str(a[0]())),
    insert: a => { const s = str(a[0]()), p = num(a[1]()); return s.slice(0, p) + str(a[2]()) + s.slice(p); }, remove: a => { const s = str(a[0]()), p = num(a[1]()); return a.length > 2 ? s.slice(0, p) + s.slice(p + num(a[2]())) : s.slice(0, p); },
    localdatetimetoday: () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; }, localdatetimenow: () => new Date()
  };
  const AGG = { sum: 1, count: 1, avg: 1, min: 1, max: 1, sumsum: 1, sumcount: 1, sumavg: 1, summin: 1, summax: 1, first: 1, last: 1 };
  RD.FUNCTIONS = ["Iif(condition, a, b)", "IsNull(x, default)", "IsNullOrEmpty(x)", "Len(s)", "Upper(s)", "Lower(s)", "Trim(s)", "Substring(s, start, len)", "Concat(a, b, ...)", "Contains(s, x)", "StartsWith(s, x)", "Replace(s, a, b)", "PadLeft(s, n, c)", "Round(x, digits)", "Floor(x)", "Ceiling(x)", "Abs(x)", "Max(a, b)", "Min(a, b)", "ToStr(x)", "ToInt(x)", "ToDecimal(x)", "FormatString('{0:n2}', x)", "Now()", "Today()", "GetYear(d)", "GetMonth(d)", "GetDay(d)", "AddDays(d, n)", "NumToWords(x)", "Sum([Field])", "Count()", "Avg([Field])", "Min([Field])", "Max([Field])"];
  RD.OPERATORS = ["+", "-", "*", "/", "%", "=", "<>", "<", ">", "<=", ">=", "And", "Or", "Not", "( )"];

  const CACHE = {};
  RD.compile = function (src) {
    src = String(src == null ? "" : src);
    if (CACHE[src]) return CACHE[src];
    const ast = parse(src);
    return (CACHE[src] = ast);
  };
  RD.check = function (src) { try { if (String(src || "").trim()) RD.compile(src); return null; } catch (e) { return e.message; } };
  function ev(n, cx) {
    switch (n.k) {
      case "lit": return n.v;
      case "fld": return cx.get(n.v);
      case "par": return cx.param(n.v);
      case "un": { const v = ev(n.a, cx); return n.op === "-" ? -num(v) : n.op === "not" ? !truthy(v) : num(v); }
      case "bin": {
        const op = n.op;
        if (op === "and" || op === "&&") return truthy(ev(n.l, cx)) && truthy(ev(n.r, cx));
        if (op === "or" || op === "||") return truthy(ev(n.l, cx)) || truthy(ev(n.r, cx));
        const a = ev(n.l, cx), b = ev(n.r, cx);
        switch (op) {
          case "+": return (typeof a === "string" || typeof b === "string") && !(isNum(a) && isNum(b)) ? str(a) + str(b) : num(a) + num(b);
          case "-": return num(a) - num(b); case "*": return num(a) * num(b);
          case "/": return num(b) === 0 ? 0 : num(a) / num(b); case "%": return num(b) === 0 ? 0 : num(a) % num(b);
          case "=": case "==": return cmp(a, b) === 0; case "<>": case "!=": return cmp(a, b) !== 0;
          case "<": return cmp(a, b) < 0; case ">": return cmp(a, b) > 0; case "<=": return cmp(a, b) <= 0; case ">=": return cmp(a, b) >= 0;
        }
        return null;
      }
      case "fn": {
        if (AGG[n.n]) return agg(n, cx);
        return FN[n.n](n.a.map(x => () => ev(x, cx)));
      }
    }
    return null;
  }
  const isNum = v => typeof v === "number" || (typeof v === "string" && v.trim() !== "" && !isNaN(+v));
  function cmp(a, b) {
    if (a instanceof Date || b instanceof Date) { const x = toDate(a), y = toDate(b); return (x ? +x : 0) - (y ? +y : 0); }
    if (isNum(a) && isNum(b)) return num(a) - num(b);
    a = str(a); b = str(b); return a < b ? -1 : a > b ? 1 : 0;
  }
  function agg(n, cx) {
    const rows = cx.scope || cx.rows || [], fn = n.n.replace(/^sum(?=sum|count|avg|min|max)/, "");
    if (fn === "count") return n.a.length ? rows.filter(r => truthy(ev(n.a[0], cx.withRow(r)))).length : rows.length;
    const vals = rows.map(r => ev(n.a[0] || { k: "lit", v: 0 }, cx.withRow(r)));
    if (fn === "first") return vals[0]; if (fn === "last") return vals[vals.length - 1];
    const ns = vals.map(num);
    if (fn === "sum") return ns.reduce((s, x) => s + x, 0);
    if (fn === "avg") return ns.length ? ns.reduce((s, x) => s + x, 0) / ns.length : 0;
    if (fn === "min") return ns.length ? Math.min.apply(null, ns) : 0;
    if (fn === "max") return ns.length ? Math.max.apply(null, ns) : 0;
    return null;
  }
  /* سياق التقييم: صف الأصناف الحالي ← بيانات الرأس ← الشركة ← الحقول المحسوبة ← المعاملات */
  function Ctx(o) { Object.assign(this, o); }
  Ctx.prototype.withRow = function (r) { const c = new Ctx(this); c.row = r; return c; };
  Ctx.prototype.param = function (n) { const p = (this.design.params || []).find(x => x.name === n); return p ? (this.paramValues && n in this.paramValues ? this.paramValues[n] : p.value) : null; };
  Ctx.prototype.has = function (n) {
    if (this.row && n in this.row) return true;
    if ((this.design.calc || []).some(x => x.name === n)) return true;
    return !!((this.data && n in this.data) || (this.company && n in this.company));
  };
  Ctx.prototype.get = function (name) {
    let n = name;
    const dot = n.indexOf(".");
    if (dot > 0) { const ds = n.slice(0, dot); if (/^(Header|Invoice|Items|Company|Parameters|Detail)$/i.test(ds)) n = n.slice(dot + 1); }
    // [مصدر البيانات.الحقل] بأسلوب DEXEF: «Item Data.price3» ، «Company Information.Phone No.1»
    if (n.indexOf(".") > 0 && !this.has(n)) { let i = n.indexOf("."); while (i > 0) { const sfx = n.slice(i + 1); if (sfx && this.has(sfx)) { n = sfx; break; } i = n.indexOf(".", i + 1); } }
    if (/^DataSource\.CurrentRowIndex$/i.test(name)) return this.row ? (this.rows.indexOf(this.row)) : 0;
    if (/^Parameters\./i.test(name)) return this.param(name.slice(11));
    if (this.row && n in this.row) return this.row[n];
    const cf = (this.design.calc || []).find(x => x.name === n);
    if (cf) {
      this._depth = (this._depth || 0) + 1;
      if (this._depth > 20) { this._depth--; return null; }
      try { return RD.evalExpr(cf.expr, this); } finally { this._depth--; }
    }
    if (this.data && n in this.data) return this.data[n];
    if (this.company && n in this.company) return this.company[n];
    const p = (this.design.params || []).find(x => x.name === n); if (p) return this.param(n);
    return null;
  };
  RD.evalExpr = function (src, cx) {
    if (src == null || String(src).trim() === "") return null;
    try { return ev(RD.compile(src), cx); } catch (e) { return "#خطأ: " + e.message; }
  };
  RD.truthy = truthy;

  /* ================================================================== الباركود */
  function code128Bars(txt) {
    const PT = "212222,222122,222221,121223,121322,131222,122213,122312,132212,221213,221312,231212,112232,122132,122231,113222,123122,123221,223211,221132,221231,213212,223112,312131,311222,321122,321221,312212,322112,322211,212123,212321,232121,111323,131123,131321,112313,132113,132311,211313,231113,231311,112133,112331,132131,113123,113321,133121,313121,211331,231131,213113,213311,213131,311123,311321,331121,312113,312311,332111,314111,221411,431111,111224,111422,121124,121421,141122,141221,112214,112412,122114,122411,142112,142211,241211,221114,413111,241112,134111,111242,121142,121241,114212,124112,124211,411212,421112,421211,212141,214121,412121,111143,111341,131141,114113,114311,411113,411311,113141,114131,311141,411131,211412,211214,211232,2331112".split(",");
    txt = String(txt == null ? "" : txt).replace(/[^\x20-\x7e]/g, "");
    if (!txt) return null;
    let codes;
    if (/^\d{4,}$/.test(txt) && txt.length % 2 === 0) { codes = [105]; for (let i = 0; i < txt.length; i += 2) codes.push(+txt.substr(i, 2)); }
    else { codes = [104]; for (const ch of txt) codes.push(ch.charCodeAt(0) - 32); }
    let sum = codes[0]; for (let i = 1; i < codes.length; i++) sum += codes[i] * i;
    codes.push(sum % 103); codes.push(106);
    const w = []; codes.forEach(c => { for (const d of PT[c]) w.push(+d); });
    return w;
  }
  const EANL = ["0001101", "0011001", "0010011", "0111101", "0100011", "0110001", "0101111", "0111011", "0110111", "0001011"];
  const EANP = ["LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG", "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL"];
  function ean13Bits(t) {
    t = String(t || "").replace(/\D/g, "");
    if (t.length === 12) { let s = 0; for (let i = 0; i < 12; i++) s += (+t[i]) * (i % 2 ? 3 : 1); t += (10 - s % 10) % 10; }
    if (t.length !== 13) return null;
    const L = d => EANL[d], R = d => EANL[d].replace(/./g, c => c === "0" ? "1" : "0"), G = d => R(d).split("").reverse().join("");
    let b = "101"; const par = EANP[+t[0]];
    for (let i = 1; i <= 6; i++) b += par[i - 1] === "L" ? L(+t[i]) : G(+t[i]);
    b += "01010"; for (let i = 7; i <= 12; i++) b += R(+t[i]); b += "101";
    return { bits: b, text: t };
  }
  RD.barcodeSVG = function (value, o) {
    o = o || {}; const sym = o.sym || "code128", txt = String(value == null ? "" : value);
    if (sym === "qr") {
      let q = "";
      try { q = window.ANOUER_STORES && ANOUER_STORES.QR ? ANOUER_STORES.QR(txt || " ") : ""; } catch (e) { q = ""; }
      return q ? q.replace("<svg ", '<svg preserveAspectRatio="xMidYMid meet" style="width:100%;height:100%;display:block" ') : '<div style="font-size:7pt;color:#c00">QR</div>';
    }
    let path = "", W = 0;
    if (sym === "ean13") {
      const e = ean13Bits(txt); if (!e) return '<div style="font-size:7pt;color:#c00">EAN-13 ✗</div>';
      W = e.bits.length + 18; for (let i = 0; i < e.bits.length; i++) if (e.bits[i] === "1") path += `M${i + 9} 0h1v1h-1z`;
    } else {
      const w = code128Bars(txt); if (!w) return "";
      let x = 10; w.forEach((n, i) => { if (i % 2 === 0) path += `M${x} 0h${n}v1h-${n}z`; x += n; }); W = x + 10;
    }
    const show = o.showText !== false;
    return `<div style="display:flex;flex-direction:column;width:100%;height:100%"><svg viewBox="0 0 ${W} 1" preserveAspectRatio="none" style="flex:1;width:100%;min-height:0;display:block" shape-rendering="crispEdges"><path d="${path}" fill="${o.color || "#000"}"/></svg>${show ? `<div style="text-align:center;font:${o.fs || 7}pt Arial;line-height:1.1;letter-spacing:.5px;direction:ltr">${esc(txt)}</div>` : ""}</div>`;
  };

  /* ================================================================== الورق والبنود */
  RD.PAPERS = {
    "A4 Invoice": { w: 210, h: 297, m: [10, 10, 10, 10] }, "Cashier Receipt": { w: 80, h: 0, m: [3, 3, 3, 3], roll: 1 },
    "A5": { w: 148, h: 210, m: [8, 8, 8, 8] }, "Label": { w: 38, h: 25, m: [0, 0, 0, 0] }, "A4": { w: 210, h: 297, m: [5, 5, 5, 5] }
  };
  RD.SIZES = [["A4", 210, 297], ["A5", 148, 210], ["A3", 297, 420], ["Letter", 215.9, 279.4], ["Legal", 215.9, 355.6], ["Roll 80mm", 80, 0], ["Roll 58mm", 58, 0]];
  RD.BAND_ORDER = ["TopMargin", "ReportHeader", "PageHeader", "GroupHeader", "Detail", "GroupFooter", "ReportFooter", "PageFooter", "BottomMargin"];
  RD.BAND_INFO = { TopMargin: "", ReportHeader: "[one band per report]", PageHeader: "[one band per page]", GroupHeader: "", Detail: "", GroupFooter: "", ReportFooter: "[one band per report]", PageFooter: "[one band per page]", BottomMargin: "" };
  RD.sortBands = function (d) {
    const ix = b => RD.BAND_ORDER.indexOf(b.type) * 100 + (b.type === "GroupHeader" ? -(b.level || 0) : b.type === "GroupFooter" ? (b.level || 0) : 0);
    d.bands.sort((a, b) => ix(a) - ix(b));
  };
  RD.band = (d, t) => d.bands.find(b => b.type === t);
  RD.contentW = d => Math.max(10, d.page.w - d.page.m[1] - d.page.m[3]);

  /* ================================================================== بناء عناصر (للتصاميم الجاهزة) */
  const st = (o) => Object.assign({ fs: 9, b: 0, al: "r", va: "m", color: "#000", bg: "", bd: "", bw: 1, bc: "#000", bs: "solid", pad: [1, 2, 1, 2] }, o || {});
  const L = (x, y, w, h, text, s, extra) => Object.assign({ id: uid(), t: "label", x, y, w, h, text: text || "", expr: "", fmt: "", grow: 1, wrap: 1, s: st(s) }, extra || {});
  const E = (x, y, w, h, expr, fmt, s, extra) => L(x, y, w, h, "", s, Object.assign({ expr, fmt: fmt || "" }, extra || {}));
  const LN = (x, y, w, h, o) => Object.assign({ id: uid(), t: "line", x, y, w, h, dir: "h", lw: 1, ls: "solid", color: "#000" }, o || {});
  const BC = (x, y, w, h, expr, sym, o) => Object.assign({ id: uid(), t: "barcode", x, y, w, h, expr, text: "", sym: sym || "code128", showText: 1, s: st({ al: "c" }) }, o || {});
  const TB = (x, y, cols, o) => {
    o = o || {};
    const mk = (texts, exprs, s) => ({ h: o.h || 6, cells: cols.map((w, i) => ({ id: uid(), w, text: texts ? texts[i] || "" : "", expr: exprs ? exprs[i] || "" : "", fmt: o.fmts ? o.fmts[i] || "" : "", s: st(Object.assign({ al: "c", bd: "lrtb" }, s || {}, o.cellS && o.cellS[i] || {})) })) });
    return { id: uid(), t: "table", x, y, w: cols.reduce((s, w) => s + w, 0), h: o.h || 6, rows: [mk(o.texts, o.exprs, o.s)], s: st() };
  };
  /* ✦ مربع QR المتجر الإلكتروني (يختفي إذا أُطفئ من الإعدادات): الرمز + «امسح وتسوّق أونلاين» + اسم الموقع */
  const storeQR = (x, y, sz) => {
    const cw = sz + 20, cx = Math.max(0, x + sz / 2 - cw / 2), V = { visExpr: "[Store Url]" };
    return [
      Object.assign(BC(x, y, sz, sz, "[Store Url]", "qr", { showText: 0 }), V),
      Object.assign(L(cx, y + sz + 0.5, cw, 4, "امسح وتسوّق أونلاين", { fs: 7, b: 1, al: "c" }), V),
      Object.assign(E(cx, y + sz + 4.2, cw, 3.6, "[Store Host]", "", { fs: 6, al: "c", color: "#444" }), V)
    ];
  };
  RD.mk = { L, E, LN, BC, TB, st, storeQR };
  function design(o) {
    const p = RD.PAPERS[o.paper] || RD.PAPERS["A4 Invoice"];
    const d = { v: 1, name: o.name, kind: o.kind || "tx", tx: o.tx || "", paper: o.paper || "A4 Invoice", rtl: true, font: "Tahoma",
      page: { w: o.pw || p.w, h: o.ph != null ? o.ph : p.h, m: (o.m || p.m).slice(), land: false, color: "", wm: null }, roll: o.paper === "Cashier Receipt" ? 1 : 0,
      label: o.label || null, dataset: o.dataset || "", calc: [], params: [], styles: [], sort: [], bands: [] };
    d.bands.push({ type: "TopMargin", h: d.page.m[0], ctrls: [] });
    (o.bands || []).forEach(b => d.bands.push(Object.assign({ ctrls: [] }, b)));
    if (!RD.band(d, "Detail")) d.bands.push({ type: "Detail", h: 0, ctrls: [] });
    d.bands.push({ type: "BottomMargin", h: d.page.m[2], ctrls: [] });
    RD.sortBands(d);
    return d;
  }
  RD.newDesign = design;

  /* ---------- فاتورة A4 */
  function a4Invoice(title, tx, party) {
    const W = 190, partyL = party || "العميل";
    const head = [
      E(95, 2, 95, 9, "[Company Name]", "", { fs: 15, b: 1, al: "r", color: "#12508f" }),
      E(95, 11, 95, 5, "[Activity]", "", { fs: 9, al: "r", color: "#444" }, { shrink: 1 }),
      E(95, 16, 95, 5, "Iif(IsNullOrEmpty([Company Address]), '', 'العنوان : ' + [Company Address])", "", { fs: 8, al: "r" }),
      E(95, 21, 95, 5, "Concat(Iif(IsNullOrEmpty([Company Phone]), '', 'الهاتف : ' + [Company Phone]), Iif(IsNullOrEmpty([Company Mobile]), '', '   الموبايل : ' + [Company Mobile]))", "", { fs: 8, al: "r" }),
      E(0, 2, 70, 5, "Iif(IsNullOrEmpty([NIF]), '', 'NIF : ' + [NIF])", "", { fs: 7.5, al: "l" }),
      E(0, 7, 70, 5, "Iif(IsNullOrEmpty([RC]), '', 'RC : ' + [RC])", "", { fs: 7.5, al: "l" }),
      E(0, 12, 70, 5, "Iif(IsNullOrEmpty([AI]), '', 'AI : ' + [AI])", "", { fs: 7.5, al: "l" }),
      BC(0, 17, 45, 10, "[Number]", "code128", { showText: 0 }),
      LN(0, 29, W, 2, { lw: 2, color: "#12508f" }),
      L(65, 32, 60, 10, title, { fs: 16, b: 1, al: "c", bg: "#12508f", color: "#fff" }),
      L(165, 45, 25, 6, "رقم الفاتورة :", { b: 1 }), E(130, 45, 35, 6, "[Number]", "", { al: "r" }),
      L(165, 51, 25, 6, "التاريخ :", { b: 1 }), E(130, 51, 35, 6, "[Date]", "dd/MM/yyyy", { al: "r" }),
      L(165, 57, 25, 6, "الوقت :", { b: 1 }), E(130, 57, 35, 6, "[Time]", "", { al: "r" }),
      L(70, 45, 25, 6, partyL + " :", { b: 1 }), E(0, 45, 70, 6, "[Customer Name]", "", { al: "r" }),
      L(70, 51, 25, 6, "الهاتف :", { b: 1 }), E(0, 51, 70, 6, "[Customer Phone]", "", { al: "r" }),
      L(70, 57, 25, 6, "العنوان :", { b: 1 }), E(0, 57, 70, 6, "[Customer Address]", "", { al: "r" })
    ];
    const cols = [12, 25, 63, 20, 18, 18, 14, 20], hdr = ["م", "الكود", "اسم الصنف", "الوحدة", "الكمية", "السعر", "الخصم", "الإجمالي"].reverse();
    const fields = ["[Index]", "[Item Code]", "[Item Name]", "[Unite]", "[Qty]", "[Price]", "[Item Discount]", "[Total]"].reverse();
    const fm = ["", "", "", "", "", "n2", "n2", "n2"].reverse();
    const c = cols.slice().reverse();
    const pageHead = [TB(0, 0, c, { h: 7, texts: hdr, s: { b: 1, bg: "#dfeafa", color: "#12508f" } })];
    const detail = [TB(0, 0, c, { h: 6, exprs: fields, fmts: fm, cellS: { 5: { al: "r" } } })];
    const foot = [
      L(160, 3, 30, 6, "الإجمالي قبل الخصم", { b: 1, bd: "lrtb", bg: "#f3f6fa" }), E(125, 3, 35, 6, "[Before Discount]", "n2", { bd: "lrtb", al: "c" }),
      L(160, 9, 30, 6, "الخصم", { b: 1, bd: "lrtb", bg: "#f3f6fa" }), E(125, 9, 35, 6, "[Discount]", "n2", { bd: "lrtb", al: "c" }),
      L(160, 15, 30, 6, "الضرائب", { b: 1, bd: "lrtb", bg: "#f3f6fa" }), E(125, 15, 35, 6, "[Taxes]", "n2", { bd: "lrtb", al: "c" }),
      L(160, 21, 30, 7, "الإجمالي", { b: 1, bd: "lrtb", bg: "#12508f", color: "#fff", fs: 10 }), E(125, 21, 35, 7, "[Net Amount]", "n2", { bd: "lrtb", al: "c", b: 1, fs: 10 }),
      L(160, 28, 30, 6, "المدفوع", { b: 1, bd: "lrtb", bg: "#f3f6fa" }), E(125, 28, 35, 6, "[Paid]", "n2", { bd: "lrtb", al: "c" }),
      L(160, 34, 30, 6, "الباقى", { b: 1, bd: "lrtb", bg: "#f3f6fa" }), E(125, 34, 35, 6, "[Remain]", "n2", { bd: "lrtb", al: "c" }),
      L(85, 3, 35, 6, "الرصيد السابق :", { b: 1 }), E(45, 3, 40, 6, "[Previous Balance]", "n2", { al: "r" }),
      L(85, 9, 35, 6, "الرصيد الحالى :", { b: 1 }), E(45, 9, 40, 6, "[Current Balance]", "n2", { al: "r" }),
      E(0, 42, W, 6, "[Amount In Words]", "", { b: 1, al: "r", color: "#12508f" }),
      E(0, 48, W, 6, "Iif(IsNullOrEmpty([Notes]), '', 'ملاحظات : ' + [Notes])", "", { al: "r", fs: 8.5 }),
      L(140, 60, 50, 6, "توقيع المستلم", { al: "c", b: 1 }), LN(140, 72, 50, 1, { ls: "dotted" }),
      L(0, 60, 50, 6, "الختم و التوقيع", { al: "c", b: 1 }), LN(0, 72, 50, 1, { ls: "dotted" })
    ].concat(party ? [] : storeQR(10, 13, 20));   /* ✦ QR المتجر الإلكتروني (فواتير الزبائن) */
    const pf = [LN(0, 0, W, 1, { color: "#999" }), { id: uid(), t: "pageinfo", info: "pn", x: 0, y: 1, w: 50, h: 5, fmt: "صفحة {0} من {1}", s: st({ fs: 7.5, al: "l" }) },
      E(60, 1, 70, 5, "[Invoice Footer]", "", { fs: 7.5, al: "c", color: "#555" }), { id: uid(), t: "pageinfo", info: "dt", x: 140, y: 1, w: 50, h: 5, fmt: "dd/MM/yyyy HH:mm", s: st({ fs: 7.5, al: "r" }) }];
    return design({ name: title + " A4", tx, paper: "A4 Invoice", bands: [{ type: "ReportHeader", h: 66, ctrls: head }, { type: "PageHeader", h: 7, ctrls: pageHead }, { type: "Detail", h: 6, ctrls: detail }, { type: "ReportFooter", h: 76, ctrls: foot }, { type: "PageFooter", h: 7, ctrls: pf }] });
  }
  /* ---------- إيصال كاشير 80mm */
  function cashier(title, tx) {
    const W = 74;
    const head = [
      E(0, 0, W, 8, "[Company Name]", "", { fs: 14, b: 1, al: "c" }),
      E(0, 8, W, 4.5, "[Activity]", "", { fs: 8, al: "c" }, { shrink: 1 }),
      E(0, 12.5, W, 4.5, "[Company Address]", "", { fs: 7.5, al: "c" }, { shrink: 1 }),
      E(0, 17, W, 4.5, "Concat([Company Phone], Iif(IsNullOrEmpty([Company Mobile]), '', ' / ' + [Company Mobile]))", "", { fs: 7.5, al: "c" }, { shrink: 1 }),
      L(0, 22, W, 6, title, { fs: 11, b: 1, al: "c", bg: "#000", color: "#fff" }),
      L(56, 29, 18, 4.5, "رقم الفاتورة :", { fs: 7.5 }), E(38, 29, 18, 4.5, "[Number]", "", { fs: 8, b: 1 }),
      L(56, 33.5, 18, 4.5, "التاريخ :", { fs: 7.5 }), E(38, 33.5, 18, 4.5, "[Date]", "dd/MM/yyyy", { fs: 8 }),
      L(56, 38, 18, 4.5, "الوقت :", { fs: 7.5 }), E(38, 38, 18, 4.5, "[Time]", "", { fs: 8 }),
      L(23, 29, 15, 4.5, "العميل :", { fs: 7.5 }), E(0, 29, 23, 9, "[Customer Name]", "", { fs: 8, va: "t" }),
      L(23, 38, 15, 4.5, "المستخدم :", { fs: 7.5 }), E(0, 38, 23, 4.5, "[WrittenBy]", "", { fs: 8 }),
      LN(0, 43, W, 1, { ls: "dashed" })
    ];
    const ph = [TB(0, 0, [16, 12, 10, 36], { h: 5, texts: ["الإجمالي", "السعر", "الكمية", "الصنف"], s: { b: 1, fs: 8, bd: "b", bs: "dashed" } })];
    const det = [TB(0, 0, [16, 12, 10, 36], { h: 5, exprs: ["[Total]", "[Price]", "[Qty]", "[Item Name]"], fmts: ["n2", "n2", "", ""], s: { fs: 8, bd: "" }, cellS: { 3: { al: "r" } } })];
    const foot = [
      LN(0, 0, W, 1, { ls: "dashed" }),
      L(44, 2, 30, 5, "الإجمالي", { fs: 9, b: 1 }), E(0, 2, 44, 5, "[Before Discount]", "n2", { fs: 9, al: "l" }),
      L(44, 7, 30, 5, "الخصم", { fs: 8.5 }), E(0, 7, 44, 5, "[Discount]", "n2", { fs: 8.5, al: "l" }),
      L(44, 12, 30, 6, "الصافى", { fs: 11, b: 1 }), E(0, 12, 44, 6, "[Net Amount]", "n2", { fs: 11, b: 1, al: "l" }),
      L(44, 18, 30, 5, "المدفوع", { fs: 8.5 }), E(0, 18, 44, 5, "[Paid]", "n2", { fs: 8.5, al: "l" }),
      L(44, 23, 30, 5, "الباقى", { fs: 8.5 }), E(0, 23, 44, 5, "[Remain]", "n2", { fs: 8.5, al: "l" }),
      L(44, 28, 30, 5, "الرصيد السابق", { fs: 8 }), E(0, 28, 44, 5, "[Previous Balance]", "n2", { fs: 8, al: "l" }),
      L(44, 33, 30, 5, "الرصيد الحالى", { fs: 8 }), E(0, 33, 44, 5, "[Current Balance]", "n2", { fs: 8, al: "l" }),
      LN(0, 38.5, W, 1, { ls: "dashed" }),
      E(0, 40, W, 5, "[Invoice Footer]", "", { fs: 8, al: "c" }, { shrink: 1 }),
      L(0, 45, W, 5, "شكراً لزيارتكم", { fs: 8.5, b: 1, al: "c" }),
      BC(12, 51, 50, 12, "[Number]", "code128", { showText: 1 })
    ].concat(storeQR((W - 24) / 2, 65, 24));   /* ✦ QR المتجر الإلكتروني */
    return design({ name: title + " كاشير", tx, paper: "Cashier Receipt", bands: [{ type: "ReportHeader", h: 44, ctrls: head }, { type: "PageHeader", h: 5, ctrls: ph }, { type: "Detail", h: 5, ctrls: det }, { type: "ReportFooter", h: 98, ctrls: foot }] });
  }
  /* ---------- سند (استلام / دفع نقدية) A5 */
  function voucher(title, tx, party) {
    const W = 132;
    const c = [
      E(50, 0, 82, 8, "[Company Name]", "", { fs: 13, b: 1, al: "r", color: "#12508f" }), E(50, 8, 82, 5, "[Company Address]", "", { fs: 8 }),
      E(50, 13, 82, 5, "[Company Phone]", "", { fs: 8 }), BC(0, 1, 40, 10, "[Number]", "code128", { showText: 1 }),
      LN(0, 19, W, 2, { lw: 2, color: "#12508f" }),
      L(36, 22, 60, 9, title, { fs: 14, b: 1, al: "c", bd: "lrtb", bw: 2, bc: "#12508f", color: "#12508f" }),
      L(108, 35, 24, 7, "الرقم :", { b: 1 }), E(70, 35, 38, 7, "[Number]", "", { bd: "b", bs: "dotted" }),
      L(46, 35, 20, 7, "التاريخ :", { b: 1 }), E(0, 35, 46, 7, "[Date]", "dd/MM/yyyy", { bd: "b", bs: "dotted" }),
      L(108, 45, 24, 7, party + " :", { b: 1 }), E(0, 45, 108, 7, "[Party Name]", "", { bd: "b", bs: "dotted" }),
      L(108, 55, 24, 7, "المبلغ :", { b: 1 }), E(70, 55, 38, 7, "[Amount]", "n2", { bd: "lrtb", al: "c", b: 1, fs: 11 }),
      E(0, 55, 68, 7, "[Account]", "", { al: "r", color: "#555" }),
      L(108, 65, 24, 7, "مبلغ وقدره :", { b: 1 }), E(0, 65, 108, 7, "[Amount In Words]", "", { bd: "b", bs: "dotted" }),
      L(108, 75, 24, 7, "و ذلك عن :", { b: 1 }), E(0, 75, 108, 7, "[Statement]", "", { bd: "b", bs: "dotted" }),
      L(92, 92, 40, 6, "المستلم", { al: "c", b: 1 }), LN(92, 104, 40, 1, { ls: "dotted" }),
      L(46, 92, 40, 6, "المحاسب", { al: "c", b: 1 }), E(46, 98, 40, 5, "[WrittenBy]", "", { al: "c", fs: 8 }), LN(46, 104, 40, 1, { ls: "dotted" }),
      L(0, 92, 40, 6, "المدير", { al: "c", b: 1 }), LN(0, 104, 40, 1, { ls: "dotted" })
    ];
    return design({ name: title, tx, paper: "A5", bands: [{ type: "ReportHeader", h: 108, ctrls: c }] });
  }
  /* ---------- إيصال استلام / دفع نقدية 80 مم (بنفس مقاس DEXEF «استلام»: 79.1 × 110 مم ، المحتوى 70 مم)
     لمسة ANOUER: شريط عنوان أسود برقم الإيصال ، المبلغ في صندوق بارز ، المبلغ بالحروف ، جدول التفاصيل والرصيد ، التوقيعات */
  /* أيقونة «اليد والنقود» (رسم ANOUER — أبيض على شريط العنوان الأسود) */
  const HAND_ICON = "data:image/svg+xml;charset=utf-8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 84"><g fill="#fff"><circle cx="50" cy="29" r="15"/><circle cx="72" cy="13" r="9"/><path d="M4 50h15v28H4z"/><path d="M21 52c9-6 19-8 29-6l20 4c5 1 7 6 4 9-2 2-5 3-9 2l-15-2 0 3 18 3c7 1 12-1 17-5l15-11c4-3 9-2 10 2 1 3-1 6-4 8L88 72c-6 5-13 7-21 6l-27-3c-6-1-12 0-19 3z"/></g><g fill="#000" font-family="Arial,Helvetica,sans-serif" font-weight="700" text-anchor="middle"><text x="50" y="36" font-size="19">1</text><text x="72" y="17.5" font-size="12">1</text></g></svg>');
  function cash80(recv) {
    const W = 70, title = recv ? "إيصال استلام نقدية" : "إيصال دفع نقدية", tx = recv ? "إيصال استلام نقدية" : "إيصال دفع نقدية";
    const SH = (x, y, w, h, o) => Object.assign({ id: uid(), t: "shape", shape: "round", x, y, w, h, r: 6, fill: "transparent", stroke: "#000", sw: 1 }, o || {});
    const P0 = [0, 0, 0, 0], G = "#ececec";
    const c = [
      /* الرأس: الشعار + اسم الشركة والنشاط */
      { id: uid(), t: "pic", name: "CoLogo", x: 0, y: 0, w: 33, h: 14.2, src: "", expr: "[Company Logo]", sizing: "zoom", s: st({ pad: P0 }) },
      E(33.5, 0.5, 36.5, 8.5, "[Company Name]", "", { fs: 14, b: 1, al: "r", color: "#c04000", pad: [0, 1, 0, 1] }, { grow: 0, fit: 1 }),
      E(33.5, 9, 36.5, 5, "[Activity]", "", { fs: 8, al: "r", color: "#333", pad: [0, 1, 0, 1] }, { grow: 0, fit: 1 }),
      /* الهاتف (مثل DEXEF: خانة «ت» + الرقمين) */
      L(64, 14.5, 6, 5, "ت", { fs: 7.5, b: 1, al: "c", bg: "#000", color: "#fff", pad: P0 }, { grow: 0 }),
      E(0, 14.5, 64, 5, "Concat([Company Phone], Iif(IsNullOrEmpty([Company Mobile]), '', '     |     ' + [Company Mobile]))", "", { fs: 8, b: 1, al: "c", bd: "tlb", bc: "#000", pad: P0 }, { grow: 0, fit: 1 }),
      E(0, 19.8, W, 4.6, "Iif(IsNullOrEmpty([Company Address]), '', 'العنوان : ' + [Company Address])", "", { fs: 7.5, al: "c", color: "#222", pad: P0 }, { grow: 0, fit: 1 }),
      /* شريط العنوان + رقم الإيصال */
      SH(0, 25, W, 10.5, { fill: "#000", stroke: "#000", r: 7 }),
      { id: uid(), t: "pic", name: "HandIcon", x: 22, y: 26.2, w: 11, h: 8.1, src: HAND_ICON, expr: "", sizing: "zoom", s: st({ pad: P0 }) },
      L(33, 25, 37, 10.5, title, { fs: 13.5, b: 1, al: "c", color: "#fff", pad: [0, 1, 0, 0] }, { grow: 0, fit: 1 }),
      SH(1.4, 26.4, 19.2, 7.7, { fill: "#fff", stroke: "#fff", r: 5 }),
      L(1.4, 26.5, 19.2, 2.6, "رقم الإيصال", { fs: 5.5, al: "c", color: "#444", pad: P0 }, { grow: 0 }),
      E(1.4, 29, 19.2, 5, "[Number]", "", { fs: 11, b: 1, al: "c", pad: P0 }, { grow: 0, fit: 1 }),
      /* التاريخ والوقت · الفرع */
      L(55, 36.6, 15, 5, "التاريخ", { fs: 7.5, color: "#444", pad: P0 }, { grow: 0 }),
      E(25, 36.6, 30, 5, "Concat(FormatString('{0:dd-MM-yyyy}', [Date]), '   ', [Time])", "", { fs: 8, b: 1, al: "r", pad: P0 }, { grow: 0, fit: 1 }),
      E(0, 36.6, 25, 5, "[Branch]", "", { fs: 7, al: "l", color: "#444", pad: P0 }, { grow: 0, fit: 1 }),
      LN(0, 42, W, 1, { ls: "dotted", color: "#000" }),
      /* الطرف */
      L(51, 43.3, 19, 6.5, recv ? "استلمنا من" : "دفعنا إلى", { fs: 8, color: "#444", pad: P0 }, { grow: 0 }),
      E(0, 43.3, 51, 6.5, "[Party Name]", "", { fs: 11, b: 1, al: "r", pad: P0 }, { grow: 0, fit: 1 }),
      /* المبلغ (بارز) */
      SH(0, 51, W, 12.5, { sw: 2.2, r: 8 }),
      SH(53, 51, 17, 12.5, { fill: "#000", stroke: "#000", r: 8 }),
      L(53, 51, 17, 12.5, "المبلغ", { fs: 10, b: 1, al: "c", color: "#fff", pad: P0 }, { grow: 0 }),
      E(13, 51, 40, 12.5, "[Amount]", "n2", { fs: 18, b: 1, al: "c", pad: [0, 1, 0, 1] }, { grow: 0, fit: 1 }),
      E(1.5, 51, 11.5, 12.5, "[Currency]", "", { fs: 8.5, b: 1, al: "c", color: "#333", pad: P0 }, { grow: 0, fit: 1 }),
      /* المبلغ بالحروف */
      E(0, 64.5, W, 7.2, "[Amount In Words]", "", { fs: 8, b: 1, al: "c", pad: [0, 1, 0, 1], bd: "b", bs: "dotted", bc: "#000" }, { grow: 0, fit: 1 }),
      /* التفاصيل */
      TB(0, 73, [19.5, 15.5, 19.5, 15.5], { h: 6, texts: ["", recv ? "المستلم" : "الصارف", "", "طريقة الدفع"], exprs: ["[WrittenBy]", "", "[Payment Method]", ""],
        s: { fs: 7.5, bd: "lrtb", bc: "#000", pad: [0, 0.8, 0, 0.8] }, cellS: { 1: { bg: G, fs: 7 }, 3: { bg: G, fs: 7 }, 0: { b: 1 }, 2: { b: 1 } } }),
      TB(0, 79, [19.5, 15.5, 19.5, 15.5], { h: 6, texts: ["", "ليصبح الرصيد", "", "الرصيد السابق"], exprs: ["[Current Balance]", "", "[Previous Balance]", ""], fmts: ["n2", "", "n2", ""],
        s: { fs: 7.5, bd: "lrtb", bc: "#000", pad: [0, 0.8, 0, 0.8] }, cellS: { 1: { bg: G, fs: 7 }, 3: { bg: G, fs: 7 }, 0: { b: 1, fs: 8.5 } } }),
      TB(0, 85, [54.5, 15.5], { h: 6, texts: ["", "البيان"], exprs: ["Iif(IsNullOrEmpty([Statement]), '—', [Statement])", ""],
        s: { fs: 7.5, bd: "lrtb", bc: "#000", pad: [0, 0.8, 0, 0.8] }, cellS: { 0: { al: "r" }, 1: { bg: G, fs: 7 } } }),
      /* التوقيعات */
      L(38, 92.3, 32, 4, recv ? "توقيع المستلم" : "توقيع الصارف", { fs: 7, b: 1, al: "c", pad: P0 }, { grow: 0 }),
      LN(40, 99.6, 28, 1, { ls: "dotted" }),
      L(0, 92.3, 32, 4, recv ? "توقيع الدافع" : "توقيع المستلم", { fs: 7, b: 1, al: "c", pad: P0 }, { grow: 0 }),
      LN(2, 99.6, 28, 1, { ls: "dotted" }),
      L(0, 101.4, W, 3, recv ? "شكراً لثقتكم — هذا الإيصال دليل على استلام المبلغ المذكور" : "هذا الإيصال دليل على صرف المبلغ المذكور أعلاه", { fs: 5.5, al: "c", color: "#555", pad: P0 }, { grow: 0 })
    ];
    const d = design({ name: title + " 80 مم", tx, paper: "Cashier Receipt", pw: 79.1, ph: 110, m: [5.3, 0, 0, 0], bands: [{ type: "ReportHeader", h: 104.6, ctrls: c }] });
    d.roll = 0; d.paper = "Custom"; d.font = "Tahoma"; d.lh = 1.15;
    return d;
  }
  /* ---------- ملصق باركود */
  function label(name, w, h, o) {
    o = o || {};
    const cw = w - 2;
    const c = [
      E(1, 0.5, cw, h * 0.22, "[Item Name]", "", { fs: o.fs || 7, b: 1, al: "c", pad: [0, 0, 0, 0] }, { grow: 0 }),
      BC(2, h * 0.24, cw - 2, h * 0.44, "[Barcode]", "code128", { showText: 1, fs: 6 }),
      E(1, h * 0.7, cw, h * 0.28, "[Price]", "n2", { fs: o.pfs || 10, b: 1, al: "c", pad: [0, 0, 0, 0] }, { grow: 0, fmt: "{0:n2} دج" })
    ];
    const d = design({ name, kind: "bc", paper: "Label", pw: w, ph: h, m: [0, 0, 0, 0], label: { w, h, cols: 1, rows: 1 }, bands: [{ type: "Detail", h, ctrls: c }] });
    return d;
  }
  /* التصاميم الجاهزة (Default Template) */
  RD.BUILTIN = [
    { key: "sale.cash", tx: "مبيعات", paper: "Cashier Receipt", def: 1, mk: () => cashier("فاتورة مبيعات", "مبيعات") },
    { key: "sale.a4", tx: "مبيعات", paper: "A4 Invoice", mk: () => a4Invoice("فاتورة مبيعات", "مبيعات") },
    { key: "sret.cash", tx: "مرتجع مبيعات", paper: "Cashier Receipt", def: 1, mk: () => cashier("مرتجع مبيعات", "مرتجع مبيعات") },
    { key: "sret.a4", tx: "مرتجع مبيعات", paper: "A4 Invoice", mk: () => a4Invoice("مرتجع مبيعات", "مرتجع مبيعات") },
    { key: "pur.a4", tx: "مشتريات", paper: "A4 Invoice", def: 1, mk: () => a4Invoice("فاتورة مشتريات", "مشتريات", "المورد") },
    { key: "pret.a4", tx: "مرتجع مشتريات", paper: "A4 Invoice", def: 1, mk: () => a4Invoice("مرتجع مشتريات", "مرتجع مشتريات", "المورد") },
    { key: "quote.a4", tx: "فاتورة أولية", paper: "A4 Invoice", def: 1, mk: () => a4Invoice("فاتورة أولية / عرض سعر", "فاتورة أولية") },
    { key: "rcv.a5", tx: "إيصال استلام نقدية", paper: "A5", def: 0, mk: () => voucher("إيصال استلام نقدية", "إيصال استلام نقدية", "استلمنا من") },
    { key: "pay.a5", tx: "إيصال دفع نقدية", paper: "A5", def: 0, mk: () => voucher("إيصال دفع نقدية", "إيصال دفع نقدية", "صرفنا إلى") },
    { key: "rcv.80", tx: "إيصال استلام نقدية", paper: "Cashier Receipt", def: 1, mk: () => cash80(true) },
    { key: "pay.80", tx: "إيصال دفع نقدية", paper: "Cashier Receipt", def: 1, mk: () => cash80(false) },
    { key: "bc.38", kind: "bc", tx: "", paper: "Label", def: 1, mk: () => label("ملصق 38×25", 38, 25) },
    { key: "bc.50", kind: "bc", tx: "", paper: "Label", mk: () => label("ملصق 50×30", 50, 30, { fs: 8, pfs: 12 }) }
  ];
  RD.builtin = key => { const b = RD.BUILTIN.find(x => x.key === key); return b ? b.mk() : null; };
  /* تعامل بدون تصميم: تصميم ANOUER الجاهز الأقرب بعنوان التعامل */
  RD.fallbackDesign = function (tx) {
    const b = RD.BUILTIN.find(x => x.tx === tx && x.def) || RD.BUILTIN.find(x => x.tx === tx);
    if (b) return b.mk();
    const vch = VCH.indexOf(tx) >= 0, d = vch ? voucher(tx || "سند", tx, "الاسم") : /مشتري|شراء|توريد|استلام/.test(tx || "") ? a4Invoice(tx, tx, "المورد") : a4Invoice(tx || "فاتورة", tx);
    return d;
  };

  /* ================================================================== البيانات */
  let COMPANY_CACHE = null;
  /* ✦ QR المتجر الإلكتروني في كل الفواتير: رابط المتجر من «ربط المتجر الإلكتروني» (Store.Url) ، ويُطفأ بـ Store.Qr = 0 */
  const STORE_URL_DEF = "https://faridoun-store.onrender.com";
  RD.storeUrl = () => (COMPANY_CACHE ? COMPANY_CACHE["Store Url"] || "" : STORE_URL_DEF);
  RD.storeHost = u => String(u == null ? RD.storeUrl() : u).replace(/^https?:\/\//i, "").replace(/\/+$/, "");
  function withStore(o) {
    const put = s => { s = s || {}; const on = s["Store.Qr"] !== "0", u = String(s["Store.Url"] || STORE_URL_DEF).trim().replace(/\/+$/, ""); o["Store Url"] = on ? u : ""; o["Store Host"] = on ? RD.storeHost(u) : ""; return o; };
    /* ✦ (2026-11-22) حسابات التواصل في كل الإيصالات: Social.Facebook / Social.YouTube / Social.TikTok — تُطفأ بـ Social.On = 0 */
    const soc = s => { s = s || {};
      /* المصدر الأول: «الخصائص ← إعدادات النظام ← حسابات التواصل» (Props.sys.social) */
      let pp = null; try { pp = window.ANOUER_PROPS ? ANOUER_PROPS.get("sys.social", null) : null; } catch (e) { pp = null; }
      if (pp && ("fb" in pp || "yt" in pp || "tt" in pp || "on" in pp)) s = { "Social.Facebook": pp.fb || "", "Social.YouTube": pp.yt || "", "Social.TikTok": pp.tt || "", "Social.On": pp.on === "إخفاء" ? "0" : "1" };
      /* محل صاحب ANOUER (رقم ) قبل أي إعداد: صفحة فيسبوك وقناة يوتيوب الرسميتان افتراضياً */
      if (!Object.keys(s).some(k => /^Social\./.test(k)) && /783405398/.test((String(o["Company Mobile"] || "") + String(o["Company Phone"] || "")).replace(/\D/g, ""))) s = { "Social.Facebook": "anouerpos", "Social.YouTube": "anouerapp", "Social.TikTok": "anouersaed" };
      const on = s["Social.On"] !== "0"; o["Social Facebook"] = on ? RD.socHandle(s["Social.Facebook"]) : ""; o["Social YouTube"] = on ? RD.socHandle(s["Social.YouTube"]) : ""; o["Social TikTok"] = on ? RD.socHandle(s["Social.TikTok"]) : ""; return o; };
    if (!HOST()) return Promise.resolve(soc(RD.SOC_DEMO)).then(() => put({}));
    return call("fm.settings.get", { prefix: "Social." }).then(soc).catch(() => soc({}))
      .then(() => call("fm.settings.get", { prefix: "Store." })).then(put).catch(() => put({}));
  }
  /* ================================================================== شريط «تابعونا» (فيسبوك · يوتيوب · تيك توك) في آخر كل إيصال
     أيقونات بسيطة من تصميم ANOUER (ليست الشعارات الرسمية) + اسم المنصة + الحساب ، بالأسود لتخرج واضحة على الطابعة الحرارية */
  RD.SOC_DEMO = {};
  try { window.addEventListener("anouer:props", e => { const d = e && e.detail; if (!d || /^sys\.social/.test(d.key || "") || (d.keys || []).some(k => /sys\.social/.test(k))) { COMPANY_CACHE = null; RD.company().catch(() => { }); } }); } catch (e) { }
  RD.socHandle = v => {
    v = String(v == null ? "" : v).trim(); if (!v) return "";
    v = v.replace(/^https?:\/\//i, "").replace(/^(www\.|m\.)/i, "").replace(/^(facebook\.com|fb\.com|youtube\.com|tiktok\.com)\/?/i, "").replace(/^(profile\.php\?id=)/i, "").replace(/[?#].*$/, "").replace(/\/+$/, "").replace(/^@+/, "");
    return v ? "@" + v : "";
  };
  const SOC_IC = {
    fb: '<path d="M7.2 10.6h2.4v6.6H7.2zM10.6 16.4v-5.2c0-.6.3-1.1.8-1.4l2.1-1.3.6-2.6c.1-.5.6-.8 1.1-.7.9.2 1.5 1 1.4 1.9l-.3 2.3h2.3c1 0 1.7.9 1.5 1.8l-1.1 4.6c-.2.7-.8 1.2-1.5 1.2h-5.6c-.7 0-1.3-.6-1.3-1.3z"/>',
    yt: '<path d="M10.2 8.4v7.2c0 .6.6.9 1.1.6l5.6-3.6c.5-.3.5-1 0-1.3l-5.6-3.6c-.5-.3-1.1 0-1.1.7z"/>',
    tt: '<path d="M13.4 5.6h2.2c.2 1.7 1.5 3 3.2 3.2v2.2c-1.2 0-2.3-.4-3.2-1v5.4c0 2.5-2 4.5-4.5 4.5S6.6 17.9 6.6 15.4s2-4.5 4.5-4.5c.3 0 .5 0 .8.1v2.3c-.3-.1-.5-.1-.8-.1-1.2 0-2.2 1-2.2 2.2s1 2.2 2.2 2.2 2.4-1 2.4-2.2z"/>'
  };
  RD.SOC_LIST = [["Social Facebook", "fb", "Facebook"], ["Social YouTube", "yt", "YouTube"], ["Social TikTok", "tt", "TikTok"]];
  RD.socialHTML = function (co, o) {
    co = co || {}; o = o || {};
    const L = RD.SOC_LIST.filter(x => co[x[0]]);
    if (!L.length) return null;
    const wide = !!o.wide, k = wide ? 1.18 : 1, H = wide ? 15 : 13.6;
    /* الحساب الطويل يُصغَّر خطّه ليظهر كاملاً داخل مربعه (بدل «…») */
    const cw = +o.cw || (wide ? 190 : 74), tw = Math.min(wide ? 58 : 999, (cw - 1.4 * k * (L.length - 1)) / L.length), room = tw - 5.4 * k - 1.2 * k - 2.2 * k - .8;
    const hfs = t => Math.max(4.6, Math.min(6.6 * k, room / (String(t).length * .62 * .3528))).toFixed(2);
    const tile = x => `<div style="flex:1 1 0;min-width:0;${wide ? "max-width:58mm;" : ""}display:flex;align-items:center;gap:${(1.2 * k).toFixed(2)}mm;padding:${(0.9 * k).toFixed(2)}mm ${(1.1 * k).toFixed(2)}mm;border:.3mm solid #000;border-radius:${(2.2 * k).toFixed(2)}mm;background:#fff">`
      + `<svg viewBox="0 0 24 24" style="width:${(5.4 * k).toFixed(2)}mm;height:${(5.4 * k).toFixed(2)}mm;flex:none;display:block"><rect width="24" height="24" rx="7" fill="#000"/><g fill="#fff">${SOC_IC[x[1]]}</g></svg>`
      + `<div style="min-width:0;display:flex;flex-direction:column;line-height:1.12;text-align:left;direction:ltr">`
      + `<b style="font:800 ${(6.2 * k).toFixed(2)}pt Arial,Tahoma,sans-serif;letter-spacing:.1mm">${esc(x[2])}</b>`
      + `<span style="font:700 ${hfs(co[x[0]])}pt Arial,Tahoma,sans-serif;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(co[x[0]])}</span></div></div>`;
    const html = `<div class="rd-soc" dir="rtl" style="height:${H}mm;box-sizing:border-box;padding-top:${(1.4 * k).toFixed(2)}mm;border-top:.3mm dashed #000;display:flex;flex-direction:column;gap:${(1 * k).toFixed(2)}mm;color:#000">`
      + `<div style="text-align:center;font:800 ${(7 * k).toFixed(2)}pt Tahoma,Arial,sans-serif;line-height:1.1">تابعونا على مواقع التواصل <span style="font-weight:700;font-size:.86em">· عروض وجديد كل يوم</span></div>`
      + `<div style="display:flex;gap:${(1.4 * k).toFixed(2)}mm;direction:ltr;justify-content:center">${L.map(tile).join("")}</div></div>`;
    return { html, h: H };
  };
  RD.company = function () {
    if (COMPANY_CACHE) return Promise.resolve(COMPANY_CACHE);
    const base = { "Company Name": "ANOUER", Currency: "DZD" };
    if (!HOST()) return withStore(Object.assign(base, { "Company Logo": RD.dexLogo || (window.ANOUER_RD_DEXEF && ANOUER_RD_DEXEF.logo) || "" })).then(o => (COMPANY_CACHE = o));
    return call("fm.settings.get", { prefix: "Company." }).then(s => {
      s = s || {};
      const m = { "Company Name": "Name", "Company Name Fr": "NameFr", Activity: "Activity", "Company Address": "Address", "Company Phone": "Phone", "Company Mobile": "Mobile", "Company Email": "Email", NIF: "NIF", NIS: "NIS", RC: "RC", AI: "AI", Currency: "Currency", "Invoice Footer": "InvoiceFooter" };
      const o = {}; Object.keys(m).forEach(k => { o[k] = s["Company." + m[k]] || ""; });
      if (!o["Company Name"]) o["Company Name"] = (document.title.split("|")[1] || "ANOUER").trim();
      if (!o.Currency) o.Currency = "DZD";
      RD.currency = o.Currency;
      o["Company Logo"] = s["Company.Logo"] || RD.dexLogo || "";
      if (o["Company Logo"]) return withStore(o).then(x => (COMPANY_CACHE = x));
      // شعار الشركة المنقول من DEXEF
      return call("fm.settings.get", { prefix: "Reports.logo" }).then(l => { o["Company Logo"] = (l && l["Reports.logo"]) || ""; return o; }).catch(() => o).then(withStore).then(x => (COMPANY_CACHE = x));
    }).catch(() => withStore(base).then(x => (COMPANY_CACHE = x)));
  };
  RD.resetCompany = () => { COMPANY_CACHE = null; };
  const ymd = d => d.getFullYear() + "-" + pad(d.getMonth() + 1, 2) + "-" + pad(d.getDate(), 2);
  const hms = d => pad(d.getHours(), 2) + ":" + pad(d.getMinutes(), 2) + ":" + pad(d.getSeconds(), 2);
  const statusAfter = lbl => { try { const sp = Array.from(document.querySelectorAll(".status > span")).find(x => x.textContent.trim() === lbl); const n = sp && sp.nextElementSibling; return n ? n.textContent.trim() : ""; } catch (e) { return ""; } };
  RD.branchName = () => statusAfter("الفرع") || "الفرع الرئيسى";
  RD.userName = function () {
    const u = statusAfter("المستخدم"); if (u) return u;
    try { if (window.__me && (window.__me.FullName || window.__me.Username)) return window.__me.FullName || window.__me.Username; } catch (e) { }
    return "";
  };
  function custInfo(name) {
    const c = (window.CUSTOMERS_DATA || []).find(x => x && x.name === name);
    return c ? { code: c.no || c.code || "", phone: c.ph || c.phone || c.tel || "", addr: c.address || c.addr || (c.x && (c.x.addr || c.x.address)) || "", bal: +(c.balance != null ? c.balance : c.bal) || 0 } : { code: "", phone: "", addr: "", bal: 0 };
  }
  function isCashCust(name, ci) { return !(ci && ci.code) && (!String(name || "").trim() || /^تعامل\s*نقد[ىي]$/.test(String(name).trim())); }
  /* المبلغ مختصراً كما في DEXEF: 2,400 (الكسور فقط إن وُجدت: 2,400.50) */
  RD.shortAmount = function (n) {
    n = Math.round((+n || 0) * 100) / 100;
    const frac = Math.abs(n % 1) > 0.004;
    return n.toLocaleString("en-US", { minimumFractionDigits: frac ? 2 : 0, maximumFractionDigits: frac ? 2 : 0 });
  };
  /* المبلغ بالحروف بدون «فقط … لا غير» (لخانة «فقط :») */
  RD.amountWords = v => RD.tafqit(v, RD.currencyName(), "سنتيم").replace(/^(سالب )?فقط /, "$1").replace(/ لا غير$/, "");
  /* الخزينة: خزائن الدفع المسجّل في الفاتورة ، وإلا الخزينة الرئيسية */
  RD.treasuryName = function (pays) {
    let T = []; try { T = window.TREASURIES || (typeof TREASURIES !== "undefined" ? TREASURIES : []); } catch (e) { }
    if (!pays) { try { pays = (typeof adj !== "undefined" ? adj : window.adj || {}).pays; } catch (e) { } }
    const ids = pays ? Object.keys(pays).filter(k => +pays[k] > 0) : [];
    const names = ids.map(id => (T.find(t => String(t.id) === String(id)) || {}).name).filter(Boolean);
    return names.length ? names.join(" + ") : ((T[0] && T[0].name) || "الخزينة الرئيسية");
  };
  /* سياسة التعامل (مثل DEXEF): نص قابل للتغيير من إعدادات الشركة PaymentPolicy / PaymentPolicyCredit */
  RD.paymentPolicy = function (type, co) {
    co = co || COMPANY_CACHE || {};
    return type === "آجل" ? (co.PaymentPolicyCredit || "آجل") : (co.PaymentPolicy || "كاش بدون احراج");
  };
  RD.currencyCode = c => { c = String(c || "").trim(); return !c || /^(DZD|DA|د\.?ج|دج|دينار( جزائري)?)$/i.test(c) ? "DZD" : c; };
  function finishInv(h, items) {
    /* ✦ الأذواق (flavors.js): اسم العائلة + كل ذوق وعدده تحت الاسم — وأسطر الأذواق في الفاتورة المحفوظة تُجمع في سطر واحد */
    try { if (window.__flvPrint) items = window.__flvPrint(items) || items; } catch (e) { }
    items.forEach(it => { if (it) delete it._r; });
    /* عدد القطع في الاسم حسب الوحدة: «SNICKERS 1pies» + كرتونة (40) ← «SNICKERS 40pies» — القطعة كما هي */
    try { if (window.ANOUER_UNAME) items.forEach(it => { if (it && it["Item Name"]) it["Item Name"] = ANOUER_UNAME.forLine(it["Item Name"], it.Unite, null, it["Item Code"]); }); } catch (e) { }
    items.forEach((r, i) => { r.Index = i + 1; });
    h["Item Count"] = items.length;
    h["Qty Total"] = items.reduce((s, r) => s + (+r.Qty || 0), 0);
    h["Amount In Words"] = RD.tafqit(h["Net Amount"], RD.currencyName(), "سنتيم");
    h["Amount Short"] = RD.shortAmount(h["Net Amount"]);
    h["Amount Words"] = RD.amountWords(h["Net Amount"]);
    if (!h.Treasury) h.Treasury = RD.treasuryName();
    h["Currency Code"] = RD.currencyCode(COMPANY_CACHE && COMPANY_CACHE.Currency);
    h["Payment Type"] = /آجل|جزئ/.test(h["Payment Method"] || "") && !isCashCust(h["Customer Name"], { code: h["Customer Code"] }) ? "آجل" : "نقدي";
    h["Payment Policy"] = RD.paymentPolicy(h["Payment Type"]);
    h["Payment Policy Line"] = "سياسة التعامل " + h["Payment Policy"];
    return { header: h, items };
  }
  RD.currencyName = cc => { const c = cc || (COMPANY_CACHE && COMPANY_CACHE.Currency) || "DZD"; return /^(DZD|DA|دج|دينار)$/i.test(String(c).trim()) ? "دينار جزائري" : c; };
  /* الفاتورة المفتوحة الآن في شاشة المبيعات (قبل مسحها بعد الحفظ) */
  RD.dataFromCurrentSale = function () {
    const G = id => document.getElementById(id);
    let t = {}; try { t = calc() || {}; } catch (e) { }
    const vr = (window.rows || (typeof rows !== "undefined" ? rows : [])).filter(r => r && r.pid && r.qty > 0);
    const isRet = !!document.querySelector(".inv.retmode");
    const cn = (G("custName") && G("custName").value.trim()) || "تعامل نقدى", ci = custInfo(cn);
    const a = (typeof adj !== "undefined" ? adj : window.adj) || {};
    const now = new Date();
    const prod = id => (window.products || (typeof products !== "undefined" ? products : [])).find(p => p.id === id) || {};
    const items = vr.map(r => {
      let net = 0, tot = 0; try { net = lineNet(r); tot = lineTot(r); } catch (e) { net = +r.price || 0; tot = net * (+r.qty || 0); }
      /* ✦ خصم العروض / خصم الصنف (promos.js + sales-cols.js) — نفس ما يُحفظ في LineDiscount ← يظهر في الوصل وقت البيع */
      try { const q0 = +r.qty || 0, pz = !isRet && !r.ret && window.__pzLineDisc ? +__pzLineDisc(r) || 0 : 0; if (pz > 0.004 && q0 > 0) { tot = Math.round((tot - pz) * 100) / 100; net = tot / q0; } } catch (e) { }
      const p = prod(r.pid), u = (p._u || []).find(x => x.name === r.unit);
      return { "Item Code": p.code || r.code || "", Barcode: (u && u.bc) || String(p.barcode || p.bc || p.code || "").split(/\s+/)[0], Group: p.cat || p.group || "", "Item Name": r.name, Unite: r.unit || "", Qty: +r.qty || 0, Price: +r.price || 0, "Item Discount": Math.max(0, (+r.price || 0) - net) * (+r.qty || 0), "Net Price": net, Total: tot, Description: r.desc || "", Serials: Array.isArray(r.sn) && !r.snSkip ? r.sn.join("، ") : "", _r: isRet || r.ret ? undefined : r };
    });
    const total = +t.total || items.reduce((s, r) => s + r.Total, 0), cashCust = isCashCust(cn, ci), paid = (+a.paid || 0) || (cashCust ? total : 0);   // عميل نقدى بدون دفع مسجّل = مدفوع بالكامل
    let no = (G("invNo") && G("invNo").value) || ""; if (!no) { try { no = String(invCounter); } catch (e) { } }
    const h = { Number: no, Transaction: isRet ? "مرتجع مبيعات" : "مبيعات", Date: ymd(now), Time: hms(now), "Customer Name": cn, "Customer Code": ci.code, "Customer Phone": ci.phone, "Customer Address": ci.addr,
      WrittenBy: RD.userName(), Branch: RD.branchName(), Store: "", "Payment Method": paid >= total ? "نقدى" : (paid > 0 ? "جزئى" : "آجل"), Reference: (G("refNo") && G("refNo").value) || "", Notes: (G("desc") && G("desc").value) || "",
      "Before Discount": +t.before || 0, Discount: +t.disc || 0, Extra: +a.extra || 0, Taxes: +t.tax || 0, "Net Amount": total, Paid: paid, Remain: Math.max(0, total - paid),
      "Previous Balance": ci.bal, "Current Balance": ci.bal + (isRet ? -1 : 1) * (total - paid) };
    /* «القديم + الجديد» (pay-old.js): جزء من المبلغ يذهب للدين السابق ← الرصيد بعد الفاتورة ينقص به */
    try { const po = !isRet && window.__payOldPending && window.__payOldPending(); if (po && po.amt > 0 && po.name === cn) { h["Old Debt Paid"] = po.amt; h["Current Balance"] = Math.round((h["Current Balance"] - po.amt) * 100) / 100; h["Total Received"] = paid + po.amt; } } catch (e) { }
    try { const ws = document.querySelector("#saleWh, .sw-name"); if (ws) h.Store = ws.value || ws.textContent || ""; } catch (e) { }
    return finishInv(h, items);
  };
  /* فاتورة محفوظة (مراجعة المبيعات): البنود من القاعدة عند الإمكان */
  RD.dataFromSaved = function (r, tx) {
    const build = (lines, extra) => {
      const ci = custInfo(r.name);
      const items = lines.map(l => { const q = +l.qty || 0, tot = l.total != null ? +l.total : q * (+l.price || 0) - (+l.disc || 0); return { "Item Code": l.code || "", Barcode: l.barcode || l.code || "", "Item Name": l.name, Unite: l.unit || "", Qty: q, Price: +l.price || 0, "Item Discount": +l.disc || 0, "Net Price": q ? tot / q : +l.price || 0, Total: tot, Group: "", Description: "" }; });
      const total = +r.total || items.reduce((s, x) => s + x.Total, 0);
      if (!(+r.paid) && isCashCust(r.name, ci)) r = Object.assign({}, r, { paid: total, rem: 0 });
      const h = Object.assign({ Number: r.no, Transaction: tx || "مبيعات", Date: r.date || ymd(new Date()), Time: r.time || "", "Customer Name": r.name || "تعامل نقدى", "Customer Code": ci.code, "Customer Phone": ci.phone, "Customer Address": ci.addr,
        WrittenBy: RD.userName(), Branch: RD.branchName(), Store: "", "Payment Method": (+r.paid || 0) >= total ? "نقدى" : "آجل", Treasury: RD.treasuryName(r.pays || {}), Reference: "", Notes: "",
        "Before Discount": +r.before || total, Discount: +r.disc || 0, Extra: 0, Taxes: +r.tax || 0, "Net Amount": total, Paid: +r.paid || 0, Remain: +r.rem || Math.max(0, total - (+r.paid || 0)), "Previous Balance": ci.bal - (total - (+r.paid || 0)), "Current Balance": ci.bal }, extra || {});
      return finishInv(h, items);
    };
    if (r && r.dbId && HOST() && Anouer.invoiceDetail) {
      return Anouer.invoiceDetail(r.dbId).then(d => build(((d && d.Lines) || []).map(l => ({ name: l.ProductName, code: l.ProductCode || "", qty: +l.Qty || 0, unit: l.UnitName || "", price: +l.UnitPrice || 0, disc: +l.LineDiscount || 0, total: l.LineTotal != null ? +l.LineTotal : null })), d ? { Notes: d.Notes || "", Extra: +d.ExtraTotal || 0, Taxes: +d.TaxTotal || 0, Discount: +d.DiscountTotal || 0, "Before Discount": +d.TotalBeforeDiscount || 0, "Net Amount": +d.GrandTotal || +r.total || 0 } : null))
        .catch(() => build(srItemsSafe(r)));
    }
    return Promise.resolve(build(srItemsSafe(r)));
  };
  /* إعادة طباعة: «القديم + الجديد» — «استلام نقدية» آلي (pay-old.js) مرتبط برقم الفاتورة ← نفس إطار إجمالي المدفوع */
  (function () {
    const base = RD.dataFromSaved, r2 = v => Math.round((+v || 0) * 100) / 100;
    const oldPaidFor = r => { const A = window.__AC; if (!A || !A.docs || !r || r.no == null || r.no === "") return Promise.resolve(0);
      return Promise.resolve(A.docs("recv")).then(l => (l || []).filter(d => d && d.data && d.data.auto === "pay-old" && String(d.data.ref || "") === String(r.no) && (!r.name || !d.data.pname || d.data.pname === r.name))
        .reduce((s, d) => s + (+d.data.amt || 0), 0)).catch(() => 0); };
    RD.dataFromSaved = function (r, tx) {
      return base.apply(this, arguments).then(x => {
        if (!x || !x.header || /مرتجع|مشتريات/.test(tx || "") || x.header["Old Debt Paid"]) return x;
        return oldPaidFor(r).then(a => { if (a > 0.004) { const h = x.header; h["Old Debt Paid"] = r2(a); h["Total Received"] = r2((+h.Paid || 0) + a); h["Previous Balance"] = r2((+h["Previous Balance"] || 0) + a); } return x; });
      });
    };
  })();

  function srItemsSafe(r) { try { return (typeof srItems === "function" ? srItems(r) : r._items || []).map(x => ({ name: x.name, qty: x.qty, unit: x.unit, price: x.price, code: x.code })); } catch (e) { return []; } }
  /* بيانات تجريبية (المعاينة والصور المصغّرة) */
  RD.sampleData = function (d) {
    const sc = RD.schemaOf(d.kind, d.tx), now = new Date();
    if (sc === "lbl") return { header: { "Print Date": ymd(now) }, items: [{ "Item Name": "عصير برتقال 1 لتر", "Item Code": "1001", Barcode: "6130001000017", Price: 185, "Old Price": 200, Unite: "قطعة", Group: "مشروبات", Index: 1,
      Price1: 180, Price2: 200, Price3: 30.83, Price4: 175, Price5: 170, Location1: "A1", "Location 2": "عصير برتقال طبيعي", "Location 3": "A1", Description: "6 قطع" }] };
    if (sc === "vch") return { header: { Number: "125", Transaction: d.tx, Date: ymd(now), Time: hms(now), "Party Name": "محمد بن علي", Amount: 15000, "Amount In Words": RD.tafqit(15000, RD.currencyName()), Statement: "دفعة من الحساب", Account: "الخزينة الرئيسية", "Payment Method": "نقدى", WrittenBy: RD.userName() || "ANOUER", Branch: "الفرع الرئيسى", Notes: "", "Previous Balance": 45000, "Current Balance": 30000 }, items: [{ Index: 1, Account: "الخزينة الرئيسية", Amount: 15000, Notes: "دفعة" }] };
    if (sc === "rep") return RD.dataset(d.dataset || "items", true);
    const it = [["حليب كامل الدسم 1 لتر", "قطعة", 6, 110], ["سكر أبيض 1 كغ", "كيس", 2, 135], ["زيت عباد الشمس 5 لتر", "قارورة", 1, 950], ["قهوة مطحونة 250 غ", "علبة", 3, 320], ["ماء معدني 1.5 لتر", "رزمة", 2, 210]];
    const items = it.map((x, i) => ({ "Item Code": String(1001 + i), Barcode: "61300010" + pad(i + 1, 5), "Item Name": x[0], Unite: x[1], Qty: x[2], Price: x[3], "Item Discount": 0, "Net Price": x[3], Total: x[2] * x[3], Description: "" }));
    const total = items.reduce((s, r) => s + r.Total, 0);
    return finishInv({ Number: "1", Transaction: d.tx || "مبيعات", Date: ymd(now), Time: hms(now), "Customer Name": "تعامل نقدى", "Customer Code": "", "Customer Phone": "0555 00 00 00", "Customer Address": "الجزائر العاصمة", WrittenBy: RD.userName() || "ANOUER", Branch: "الفرع الرئيسى", Store: "المخزن الرئيسي", "Payment Method": "نقدى", Reference: "", Notes: "",
      "Before Discount": total, Discount: 0, Extra: 0, Taxes: 0, "Net Amount": total, Paid: total, Remain: 0, "Previous Balance": 0, "Current Balance": 0 }, items);
  };
  RD.dataset = function (k, sample) {
    const now = new Date(); let rows = [];
    if (k === "customers") rows = (window.CUSTOMERS_DATA || []).filter(c => c && c.name && c.id).map(c => ({ Code: c.no || c.code || "", Name: c.name, Phone: c.ph || c.phone || "", Address: c.address || (c.x && c.x.addr) || "", Balance: +(c.balance != null ? c.balance : c.bal) || 0 }));
    else if (k === "sales") rows = (window.SALES_DATA || []).map(s => ({ Number: s.no, Date: s.date, Customer: s.name, Count: s.cnt, Total: s.total, Paid: s.paid, Remain: s.rem }));
    else { let P = []; try { P = window.products || (typeof products !== "undefined" ? products : []); } catch (e) { } rows = P.map(p => ({ Code: p.code || "", Name: p.name, Unite: p.unit || ((p._u || []).find(u => u.base) || {}).name || "", Price: +p.price || 0, Stock: +(p.stock != null ? p.stock : p.qty) || 0, Group: p.cat || p.group || p.grp || "" })); }
    if (sample && rows.length > 40) rows = rows.slice(0, 40);
    rows.forEach((r, i) => { r.Index = i + 1; });
    const ds = RD.DATASETS[k] || RD.DATASETS.items;
    return { header: { "Report Title": ds.t, "Print Date": ymd(now), WrittenBy: RD.userName(), "Row Count": rows.length }, items: rows };
  };

  /* ================================================================== حقول DEXEF (للتصاميم المنقولة من DEXEF كما هي)
     التصميم يحتفظ بأسماء حقول DEXEF الأصلية: [Footer_Net_Amount] ، [Customer Phone1] ، [Item Data].[price3] …
     وهنا تُربط ببيانات ANOUER */
  const TX_TITLE = { "مبيعات": "فاتورة مبيعات", "مرتجع مبيعات": "مرتجع مبيعات", "مشتريات": "فاتورة مشتريات", "مرتجع مشتريات": "مرتجع مشتريات", "فاتورة أولية": "فاتورة أولية", "أمر شراء": "أمر شراء", "إيصال استلام نقدية": "إيصال استلام نقدية", "إيصال دفع نقدية": "إيصال دفع نقدية" };
  RD.dexData = function (data) {
    const h = Object.assign({}, data.header || {}), co = Object.assign({}, data.company || COMPANY_CACHE || {});
    const def = (o, k, v) => { if (!(k in o) || o[k] == null) o[k] = v; };
    const N = k => +h[k] || 0;
    const dt = h.Date ? (String(h.Date).length <= 10 && h.Time ? h.Date + " " + h.Time : h.Date) : "";
    def(h, "Transaction Title", TX_TITLE[h.Transaction] || h.Transaction || "");
    def(h, "TransactionName", h.Transaction || ""); def(h, "TransactoinName", h.Transaction || "");
    def(h, "InvoiceNumber", h.Number); def(h, "BillNum", h.Number); def(h, "QR Text", co["Store Url"] || h.Number || "");   /* ✦ QR = رابط المتجر الإلكتروني (إن كان مفعّلاً) */
    def(h, "Customer Phone1", h["Customer Phone"] || ""); def(h, "Customer Phone2", ""); def(h, "Customer Adress", h["Customer Address"] || "");
    def(h, "Customer VAT Number", ""); def(h, "CustomerField1", ""); def(h, "CustomerName", h["Customer Name"] || h["Party Name"] || "");
    def(h, "Customer Balance", N("Current Balance"));
    def(h, "Footer_Amount", N("Before Discount") || N("Net Amount")); def(h, "Footer_Discount", N("Discount")); def(h, "Footer_Extra", N("Extra"));
    def(h, "Footer_Net_Amount", N("Net Amount")); def(h, "Footer_Payment", N("Paid")); def(h, "Footer_Remain", N("Remain"));
    def(h, "TotalPay", N("Paid")); def(h, "TotalExtra", N("Extra")); def(h, "TotalDiscount", N("Discount")); def(h, "BillTax", N("Taxes")); def(h, "Tax", N("Taxes"));
    def(h, "Note", h.Notes || h.Statement || ""); def(h, "PaymentTerms_DueDate", dt); def(h, "Currency", co.Currency || "DZD");
    // سطر الكاشير المختصر: المبلغ · العملة · نقدى/آجل
    def(h, "Amount Short", RD.shortAmount(N("Net Amount") || N("Amount") || N("Value")));
    def(h, "Amount Words", RD.amountWords(N("Net Amount") || N("Amount") || N("Value")));
    def(h, "Treasury", h.Account || RD.treasuryName());
    def(h, "Currency Code", RD.currencyCode(co.Currency || h.Currency));
    def(h, "Payment Type", /آجل|أجل|اجل|جزئ/.test(String(h["Payment Method"] || "")) && !isCashCust(h["Customer Name"] || h["Party Name"], { code: h["Customer Code"] }) ? "آجل" : "نقدي");
    def(h, "Payment Policy", RD.paymentPolicy(h["Payment Type"], co));
    def(h, "Payment Policy Line", "سياسة التعامل " + h["Payment Policy"]);
    def(h, "Branchname", h.Branch || ""); def(h, "DonationName", ""); def(h, "HorofField", h["Amount In Words"] || "");
    def(h, "Value", N("Amount") || N("Net Amount")); def(h, "AccountName", h["Party Name"] || h.Account || ""); def(h, "AccountBalance", N("Current Balance"));
    def(h, "Operate", h.Statement || ""); def(h, "PaymentIndex", h["Payment Method"] || ""); def(h, "value", h.Value); def(h, "dt", dt); def(h, "Dt", dt);
    if (dt) h.Date = dt;
    // الشركة: «Company Information» و «Company_Data»
    def(co, "currency", co.Currency || "DZD"); def(co, "Field", co.Activity || ""); def(co, "Description", co.Activity || "");
    def(co, "Phone No.1", co["Company Phone"] || ""); def(co, "Phone No.2", co["Company Mobile"] || ""); def(co, "Phone1", co["Company Phone"] || ""); def(co, "Phone2", co["Company Mobile"] || "");
    def(co, "Name", co["Company Name"] || ""); def(co, "street", co["Company Address"] || ""); def(co, "city", ""); def(co, "Email", co["Company Email"] || ""); def(co, "mail", co["Company Email"] || "");
    Object.keys(RD.DEX_CO || {}).forEach(k => { if (!String(co[k] || "").trim()) co[k] = RD.DEX_CO[k]; });
    if (!co["Company Logo"]) co["Company Logo"] = RD.dexLogo || (window.ANOUER_RD_DEXEF && ANOUER_RD_DEXEF.logo) || ""; def(co, "Image", co["Company Logo"]);
    def(co, "Tax ID", co.NIF || ""); def(co, "Tax_Number", co.NIF || ""); def(co, "Trade_Register", co.RC || ""); def(co, "Branch Name", h.Branch || "");
    const items = (data.items || []).map((r, i) => {
      const o = Object.assign({}, r);
      def(o, "RowNumber", o.Index != null ? o.Index : i + 1); def(o, "Item Barcode", o.Barcode || o["Item Code"] || ""); def(o, "NetPrice", +o["Net Price"] || +o.Price || 0);
      def(o, "SalePrice", +o.Price || 0); def(o, "UniteQty", 1); def(o, "DealingQty", +o.Qty || 0); def(o, "DealingUnite", o.Unite || ""); def(o, "DealingPrice", +o.Price || 0);
      def(o, "TotalDiscount", +o["Item Discount"] || 0); def(o, "Tax", 0); def(o, "ItemTxt1", ""); def(o, "Item Description", o.Description || "");
      def(o, "ItemName", o["Item Name"] || ""); def(o, "ItemCode", o["Item Code"] || ""); def(o, "Serial1", ""); def(o, "Item BatchNumber", "");
      for (let k = 1; k <= 8; k++) { def(o, "price" + k, +o["Price" + k] || 0); def(o, "txt" + k, o["Txt" + k] || ""); }
      def(o, "Location1", o.Location1 || ""); def(o, "Location 2", ""); def(o, "Location 3", ""); def(o, "Item Name ENglish", "");
      def(o, "Price", 0); def(o, "Amount", +o.Amount || 0);
      return o;
    });
    return Object.assign({}, data, { header: h, company: co, items });
  };

  /* ================================================================== الإخراج (تصميم + بيانات → صفحات) */
  const mm = v => (Math.round(v * 1000) / 1000) + "mm";
  const BDS = { solid: "solid", dashed: "dashed", dotted: "dotted", double: "double" };
  function styleCSS(s, o) {
    s = s || {}; o = o || {};
    let c = `font-size:${s.fs || 9}pt;`;
    if (s.ff) c += `font-family:${s.ff};`;
    if (s.b) c += "font-weight:700;"; if (s.i) c += "font-style:italic;";
    const td = [s.u ? "underline" : "", s.k ? "line-through" : ""].filter(Boolean).join(" "); if (td) c += `text-decoration:${td};`;
    c += `color:${o.color || s.color || "#000"};`;
    const bg = o.bg != null ? o.bg : s.bg; if (bg) c += `background:${bg};`;
    const bw = (s.bw == null ? 1 : s.bw) + "px", bst = BDS[s.bs] || "solid", bc = s.bc || "#000", bd = s.bd || "";
    if (bd) { "trbl".split("").forEach(k => { if (bd.indexOf(k) >= 0) c += `border-${{ t: "top", r: "right", b: "bottom", l: "left" }[k]}:${bw} ${bst} ${bc};`; }); }
    const p = s.pad || [1, 2, 1, 2]; c += `padding:${p[0]}px ${p[1]}px ${p[2]}px ${p[3]}px;`;
    return c;
  }
  RD.styleCSS = styleCSS;
  const AL = { r: "right", c: "center", l: "left", j: "justify" }, JC = { r: "flex-end", c: "center", l: "flex-start", j: "stretch" }, VA = { t: "flex-start", m: "center", b: "flex-end" };
  function ctrlValue(c, cx) {
    if (c.summary && c.summary.run && c.summary.run !== "none") {
      const fn = c.summary.fn || "sum", e = c.expr || "[" + (c.summary.field || "Total") + "]";
      const scope = c.summary.run === "report" ? cx.allRows : c.summary.run === "group" ? (cx.groupRows || cx.allRows) : (cx.pageRows || cx.allRows);
      const sub = new Ctx(cx); sub.scope = scope;
      const src = fn === "count" ? "Count()" : fn.charAt(0).toUpperCase() + fn.slice(1) + "(" + e + ")";
      return RD.evalExpr(src, sub);
    }
    if (c.expr && String(c.expr).trim()) return RD.evalExpr(c.expr, cx);
    return c.text;
  }
  /* «جديد» بجانب اسم الصنف السريع في كل الفواتير المطبوعة (إضافة صنف سريع) — شارة سوداء تُطبع بوضوح على الطابعات الحرارية */
  function qkTag(c, cx, txt) {
    try {
      const Q = window.ANOUER_QUICK; if (!Q || !Q.isQuickName || !txt || !c) return "";
      const e = String(c.expr || c.text || "");
      if (!/Item\s*Name|ItemName|\[Name\]/i.test(e)) return "";
      if (!Q.isQuickName(String(txt).trim())) return "";
      return '<span class="rd-qk" style="display:inline-block;margin:0 1.2mm;padding:0 1.3mm;border-radius:.9mm;background:#000;color:#fff;font-weight:700;font-size:.78em;line-height:1.45;vertical-align:middle;white-space:nowrap;-webkit-print-color-adjust:exact;print-color-adjust:exact">★ جديد</span>';
    } catch (x) { return ""; }
  }
  RD.ctrlText = function (c, cx) {
    const v = ctrlValue(c, cx);
    if (c.fmt) return RD.format(c.fmt, [v]);
    return v == null ? "" : typeof v === "number" ? fmtOne(v, "") : v instanceof Date ? fmtDate(v, "dd/MM/yyyy") : String(v);
  };
  function condStyle(c, cx) {
    const o = {};
    if (c.bgExpr) { const v = RD.evalExpr(c.bgExpr, cx); if (v && !/^#خطأ/.test(v)) o.bg = String(v); }
    if (c.colorExpr) { const v = RD.evalExpr(c.colorExpr, cx); if (v && !/^#خطأ/.test(v)) o.color = String(v); }
    return o;
  }
  const visible = (c, cx) => c.hidden ? false : c.visExpr && String(c.visExpr).trim() ? truthy(RD.evalExpr(c.visExpr, cx)) : true;
  /* ملاءمة النص داخل إطاره (c.fit): يُصغَّر الخط حتى يدخل النص كاملاً في سطر واحد — أو سطرين إن كان ذلك أوضح —
     بدون التفاف يتراكب على السطر الذي تحته ولا قصّ نصف الكلمة */
  let FCV = null, MS = null, MP = null;
  /* القياس بنفس محرّك العرض (DOM) وليس canvas: نفس الخط المثبّت ، نفس السُمك ، نفس تشكيل الحروف العربية/اللاتينية المختلطة
     ← ما يُقاس هو بالضبط ما يُطبع (لا قصّ لأسماء الوحدات مثل «كرتونة 14حبة» أو «Batte 12Units») */
  const mText = (t, fs, s) => {
    try {
      if (!MS || !MS.isConnected) {
        MS = document.createElement("span"); MS.setAttribute("aria-hidden", "true"); MS.setAttribute("data-dk-skip", "");
        MS.style.cssText = "position:fixed;left:-30000px;top:-30000px;visibility:hidden;pointer-events:none;white-space:pre;line-height:1;padding:0;margin:0;border:0;letter-spacing:normal;word-spacing:normal;text-transform:none;unicode-bidi:plaintext;zoom:1";
        MP = document.createElement("div"); MP.style.cssText = "position:fixed;left:-30000px;top:-30000px;width:100px;height:1px;visibility:hidden;zoom:1";
        (document.body || document.documentElement).appendChild(MS); (document.body || document.documentElement).appendChild(MP);
      }
      MS.style.font = `${s.i ? "italic " : ""}${s.w || (s.b ? 700 : 400)} ${fs}pt ${s.ff || "Tahoma, Arial"}`;
      MS.textContent = t;
      const k = (MP.getBoundingClientRect().width || 100) / 100, w = MS.getBoundingClientRect().width / (k || 1);
      if (w > 0) return w * 1.03;   // هامش أمان صغير (تقريب الطابعة)
    } catch (e) { }
    try { const g = FCV || (FCV = document.createElement("canvas").getContext("2d")); g.font = `${s.i ? "italic " : ""}${s.w || (s.b ? 700 : 400)} ${fs}pt ${s.ff || "Tahoma, Arial"}`; return g.measureText(t).width * 1.06; } catch (e) { return String(t).length * fs * .6; }
  };
  function fitText(c, s, txt, alts) {
    const fs0 = +s.fs || 9, p = s.pad || [1, 2, 1, 2], K = 96 / 25.4, PT = 96 / 72;
    const aw = Math.max(4, (c.fitW || c.w) * K - (+p[1] || 0) - (+p[3] || 0) - 1.5), ah = Math.max(4, c.h * K - (+p[0] || 0) - (+p[2] || 0));
    const fit1 = t0 => {
      const t = String(t0).replace(/\s+/g, " ").trim(); if (!t) return null;
      const one = Math.min(fs0, fs0 * aw / Math.max(1, mText(t, fs0, s)), ah / (1.12 * PT));
      let best = { fs: one, t, lh: 1.12 };
      if (one < fs0 * .7 && t.indexOf(" ") > 0) {
        const ws = t.split(" "); let k = 1, bd = 1e9;
        for (let j = 1; j < ws.length; j++) { const d = Math.abs(mText(ws.slice(0, j).join(" "), fs0, s) - mText(ws.slice(j).join(" "), fs0, s)); if (d < bd) { bd = d; k = j; } }
        const a = ws.slice(0, k).join(" "), b = ws.slice(k).join(" ");
        const two = Math.min(fs0, fs0 * aw / Math.max(1, mText(a, fs0, s), mText(b, fs0, s)), ah / (2 * 1.05 * PT));
        if (two > one * 1.15) best = { fs: two, t: a + "\n" + b, lh: 1.05 };
      }
      return best;
    };
    /* c.fitAlt: صيغ أقصر لنفس المعنى («سعرالقطعة داخل كرتونة» ← «القطعة داخل كرتونة») تُستعمل فقط إن كانت أوضح بكثير */
    let best = fit1(txt); if (!best) return null;
    (alts || []).forEach(a => { const f = fit1(a); if (f && f.fs > best.fs * 1.18) best = f; });
    best.fs = Math.max(4, Math.floor(best.fs * 10) / 10); return best;
  }
  RD.fitText = (c, s, txt, alts) => fitText(c, s, txt, alts);
  function textBox(c, cx, s, grow) {
    let txt = RD.ctrlText(c, cx), ws = c.wrap === 0 ? "nowrap" : (c.multi === 0 ? "normal" : "pre-wrap");
    const al = s.al || "r";
    if (c.fit && !c.angle && String(txt).trim()) {
      const alts = (c.fitAlt || []).map(a => { const m = /^\[([^\]]+)\]$/.exec(String(a)); const v = m ? cx.get(m[1]) : a; return v == null ? "" : String(v); }).filter(Boolean);
      const f = fitText(c, s, txt, alts);
      if (f) return `<div class="rdt" style="display:flex;width:100%;height:100%;align-items:${VA[s.va || "m"]};justify-content:${JC[al]};box-sizing:border-box;overflow:hidden"><span style="display:block;width:100%;text-align:${AL[al]};white-space:pre;font-size:${f.fs}pt;line-height:${f.lh};unicode-bidi:plaintext">${esc(f.t)}${qkTag(c, cx, txt)}</span></div>`;
    }
    if (c.angle) {   // نص مائل / عمودي (Angle)
      const a = ((+c.angle % 360) + 360) % 360, vert = (a > 45 && a < 135) || (a > 225 && a < 315);
      return `<div class="rdt" style="position:relative;width:100%;height:100%;overflow:hidden"><div style="position:absolute;left:50%;top:50%;width:${mm(vert ? c.h : c.w)};height:${mm(vert ? c.w : c.h)};transform:translate(-50%,-50%) rotate(${-a}deg);display:flex;align-items:${VA[s.va || "m"]};justify-content:${JC[al]}"><span style="display:block;width:100%;text-align:${AL[al]};white-space:${ws};line-height:1.25">${esc(txt)}${qkTag(c, cx, txt)}</span></div></div>`;
    }
    return `<div class="rdt" style="display:flex;width:100%;height:100%;align-items:${VA[s.va || "m"]};justify-content:${JC[al]};box-sizing:border-box;${grow ? "min-height:100%;" : "overflow:hidden;"}"><span style="display:block;width:100%;text-align:${AL[al]};white-space:${ws};word-break:break-word;line-height:${(cx.design && cx.design.lh) || 1.25}">${esc(txt)}${qkTag(c, cx, txt)}</span></div>`;
  }
  function ctrlInner(c, cx) {
    const s = c.s || st();
    switch (c.t) {
      case "label": return textBox(c, cx, s, c.grow);
      case "check": {
        const v = c.expr ? truthy(RD.evalExpr(c.expr, cx)) : !!c.checked, gz = Math.min(c.h * 0.6, 4.2);
        const GL = { thumb: v ? "#2bb24c" : "#c9c9c9", toggle: v ? "#2bb24c" : "#c9c9c9", star: v ? "#f5a623" : "#ccc", heart: v ? "#e0245e" : "#ccc", smiley: v ? "#2bb24c" : "#ccc", yesno: v ? "#2bb24c" : "#e53935" };
        const g = c.glyph && GL[c.glyph] ? `<span style="flex:0 0 ${mm(gz)};width:${mm(gz)};height:${mm(gz)};border-radius:50%;background:${GL[c.glyph]};display:inline-block"></span>` : `<span style="font-size:${(s.fs || 9) + 2}pt;line-height:1">${v ? "☑" : "☐"}</span>`;
        return `<div style="display:flex;align-items:center;gap:4px;height:100%;justify-content:${JC[s.al || "r"]}">${g}<span style="line-height:1.1;overflow:hidden">${esc(c.text || "")}</span></div>`;
      }
      case "rtf": {   // نص منسّق ثابت (RichText) — مع دمج [الحقول] داخل النص
        const h = String(c.html || "").replace(/\[([^\[\]<>]+)\]/g, (m0, f) => { const v = cx.get(f.replace(/&amp;/g, "&")); return v == null ? "" : esc(typeof v === "number" ? fmtOne(v, "") : v instanceof Date ? fmtDate(v, "dd/MM/yyyy") : String(v)); });
        return `<div style="width:100%;height:100%;overflow:hidden;line-height:1.2;unicode-bidi:plaintext;white-space:pre-wrap">${h}</div>`;
      }
      case "pic": { let src = c.src || ""; if (c.expr) { const v = RD.evalExpr(c.expr, cx); if (v && !/^#خطأ/.test(v)) src = String(v); } if (!src) return ""; const fit = { zoom: "contain", stretch: "fill", normal: "none", center: "none", cover: "cover", squeeze: "scale-down" }[c.sizing || "zoom"]; return `<img src="${esc(src)}" style="width:100%;height:100%;object-fit:${fit};object-position:${c.sizing === "normal" ? "left top" : "center"};display:block">`; }
      case "barcode": { const v = c.expr ? RD.evalExpr(c.expr, cx) : c.text; return RD.barcodeSVG(v == null ? "" : v, { sym: c.sym, showText: !!c.showText, fs: (c.s && c.s.fs) || 7, color: s.color }); }
      case "line": {
        const col = c.color || "#000", w = c.lw || 1, ls = c.ls || "solid";
        if (c.dir === "v") return `<div style="position:absolute;left:50%;top:0;bottom:0;border-left:${w}px ${ls} ${col}"></div>`;
        if (c.dir === "s" || c.dir === "b") return `<svg viewBox="0 0 100 100" preserveAspectRatio="none" style="width:100%;height:100%;display:block"><line x1="0" y1="${c.dir === "s" ? 100 : 0}" x2="100" y2="${c.dir === "s" ? 0 : 100}" stroke="${col}" stroke-width="${w}" vector-effect="non-scaling-stroke" ${ls === "dashed" ? 'stroke-dasharray="6 4"' : ls === "dotted" ? 'stroke-dasharray="1 3"' : ""}/></svg>`;
        return `<div style="position:absolute;left:0;right:0;top:50%;border-top:${w}px ${ls} ${col}"></div>`;
      }
      case "shape": {
        const f = c.fill || "transparent", sc = c.stroke || "#000", sw = c.sw == null ? 1 : c.sw;
        if (c.shape === "ellipse") return `<div style="width:100%;height:100%;border-radius:50%;background:${f};border:${sw}px solid ${sc};box-sizing:border-box"></div>`;
        if (c.shape === "round") return `<div style="width:100%;height:100%;border-radius:${c.r || 8}px;background:${f};border:${sw}px solid ${sc};box-sizing:border-box"></div>`;
        if (c.shape === "tri") return `<svg viewBox="0 0 100 100" preserveAspectRatio="none" style="width:100%;height:100%;display:block"><polygon points="50,2 98,98 2,98" fill="${f}" stroke="${sc}" stroke-width="${sw}" vector-effect="non-scaling-stroke"/></svg>`;
        /* أشكال DEXEF: خط بزاوية ، صليب (X عند 45°) ، سهم ، نجمة */
        if (c.shape === "sline" || c.shape === "cross" || c.shape === "arrow" || c.shape === "star" || c.shape === "poly") {
          const W = Math.max(1, c.w), H = Math.max(1, c.h), cxp = W / 2, cyp = H / 2, ang = (+c.angle || 0) * Math.PI / 180, L = Math.sqrt(W * W + H * H) / 2;
          const swm = (sw / PX).toFixed(3);
          const seg = a => { const dx = Math.cos(a) * L, dy = -Math.sin(a) * L; return `<line x1="${(cxp - dx).toFixed(3)}" y1="${(cyp - dy).toFixed(3)}" x2="${(cxp + dx).toFixed(3)}" y2="${(cyp + dy).toFixed(3)}" stroke="${sc}" stroke-width="${swm}"/>`; };
          let g = "";
          const ln = (x1, y1, x2, y2) => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${sc}" stroke-width="${swm}"/>`;
          const dirLine = deg => { const d = ((deg % 180) + 180) % 180; return d < 15 || d > 165 ? ln(0, cyp, W, cyp) : Math.abs(d - 90) < 15 ? ln(cxp, 0, cxp, H) : d < 90 ? ln(0, H, W, 0) : ln(0, 0, W, H); };
          if (c.shape === "sline") g = dirLine((+c.angle || 0) + 90);
          else if (c.shape === "cross") g = dirLine(+c.angle || 0) + dirLine((+c.angle || 0) + 90);
          else if (c.shape === "arrow") { const r = Math.min(W, H) / 2; g = `<g transform="rotate(${-(+c.angle || 0)} ${cxp} ${cyp})"><polygon points="${cxp},${cyp - r} ${cxp + r},${cyp} ${cxp + r / 2.2},${cyp} ${cxp + r / 2.2},${cyp + r} ${cxp - r / 2.2},${cyp + r} ${cxp - r / 2.2},${cyp} ${cxp - r},${cyp}" fill="${f}" stroke="${sc}" stroke-width="${swm}"/></g>`; }
          else { const r = Math.min(W, H) / 2 - 0.2, pts = []; for (let i = 0; i < 10; i++) { const rr = i % 2 ? r * 0.45 : r, a = -Math.PI / 2 + i * Math.PI / 5; pts.push((cxp + rr * Math.cos(a)).toFixed(2) + "," + (cyp + rr * Math.sin(a)).toFixed(2)); } g = `<polygon points="${pts.join(" ")}" fill="${f}" stroke="${sc}" stroke-width="${swm}"/>`; }
          return `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="width:100%;height:100%;display:block;overflow:visible">${g}</svg>`;
        }
        return `<div style="width:100%;height:100%;background:${f};border:${sw}px solid ${sc};box-sizing:border-box"></div>`;
      }
      case "pageinfo": {
        const now = new Date();
        let txt = "";
        if (c.info === "pn") txt = RD.format(c.fmt || "{0} / {1}", ["\u0001PN\u0001", "\u0001PC\u0001"]);
        else if (c.info === "num") txt = "\u0001PN\u0001";
        else if (c.info === "user") txt = RD.userName();
        else txt = fmtDate(now, c.fmt || (c.info === "time" ? "HH:mm:ss" : c.info === "date" ? "dd/MM/yyyy" : "dd/MM/yyyy HH:mm"));
        return textBox({ text: txt, wrap: 0 }, cx, s, 0).replace(/\u0001PN\u0001|\u0001PC\u0001/g, m => m);
      }
      case "panel": return "";
      case "pagebreak": return "";
      case "comb": { const v = c.expr ? RD.evalExpr(c.expr, cx) : c.text; return RD.combHTML(c, c.fmt ? RD.format(c.fmt, [v]) : v == null ? "" : String(v)); }
      case "chart": return RD.chartSVG(c, cx.allRows || cx.rows || []);
    }
    return "";
  }
  /* Character Comb: حرف في كل خانة */
  RD.combHTML = function (c, txt) {
    const s = c.s || st(), cwid = Math.max(1, c.cellW || 5), n = Math.max(1, Math.floor(c.w / cwid)), chars = Array.from(String(txt == null ? "" : txt)).slice(0, n);
    const bw = (s.bw == null ? 1 : s.bw) + "px " + (BDS[s.bs] || "solid") + " " + (s.bc || "#000");
    let h = ""; for (let i = 0; i < n; i++) h += `<span style="flex:0 0 ${mm(cwid)};display:flex;align-items:center;justify-content:center;border:${bw};margin-inline-start:-1px;box-sizing:border-box;font:${s.b ? "700 " : ""}${s.fs || 10}pt ${s.ff || "inherit"};color:${s.color || "#000"}">${esc(chars[i] || "")}</span>`;
    return `<div style="display:flex;direction:${c.rtl === 0 ? "ltr" : "inherit"};height:100%;width:100%;background:${s.bg || "transparent"}">${h}</div>`;
  };
  /* Chart: أعمدة / خطوط / دائرة من بنود التفاصيل */
  RD.chartSVG = function (c, rows) {
    const W = Math.max(40, c.w * 4), H = Math.max(30, c.h * 4), xf = c.xf || "Item Name", yf = c.yf || "Total";
    const data = (rows || []).slice(0, 30).map(r => ({ x: String(r[xf] == null ? "" : r[xf]), y: +r[yf] || 0 }));
    const pal = ["#1e6fd0", "#e53935", "#f4a020", "#43a047", "#8e44ad", "#00acc1", "#6d4c41", "#c2185b"];
    const fs = Math.max(6, ((c.s && c.s.fs) || 7) * 1.4), top = c.title ? fs + 6 : 4;
    let g = c.title ? `<text x="${W / 2}" y="${fs + 1}" text-anchor="middle" font-size="${fs + 1}" font-weight="700">${esc(c.title)}</text>` : "";
    if (!data.length) return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:100%">${g}<text x="${W / 2}" y="${H / 2}" text-anchor="middle" font-size="${fs}" fill="#999">No data</text></svg>`;
    if (c.chart === "pie") {
      const tot = data.reduce((s, d) => s + Math.max(0, d.y), 0) || 1, R = Math.min(W * 0.32, (H - top) / 2 - 2), cx0 = R + 4, cy0 = top + (H - top) / 2;
      let a = -Math.PI / 2;
      data.forEach((d, i) => { const da = Math.max(0, d.y) / tot * Math.PI * 2, x1 = cx0 + R * Math.cos(a), y1 = cy0 + R * Math.sin(a), x2 = cx0 + R * Math.cos(a + da), y2 = cy0 + R * Math.sin(a + da); g += da >= Math.PI * 2 - 1e-6 ? `<circle cx="${cx0}" cy="${cy0}" r="${R}" fill="${pal[i % 8]}"/>` : `<path d="M${cx0} ${cy0}L${x1} ${y1}A${R} ${R} 0 ${da > Math.PI ? 1 : 0} 1 ${x2} ${y2}z" fill="${pal[i % 8]}"/>`; a += da; });
      data.slice(0, 10).forEach((d, i) => { const ly = top + 4 + i * (fs + 3); g += `<rect x="${2 * R + 12}" y="${ly}" width="${fs}" height="${fs}" fill="${pal[i % 8]}"/><text x="${2 * R + 15 + fs}" y="${ly + fs - 1}" font-size="${fs}" direction="rtl" unicode-bidi="plaintext">${esc(d.x.slice(0, 22))} (${fmtNum(d.y, "n0")})</text>`; });
      return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:100%;display:block">${g}</svg>`;
    }
    const mx = Math.max.apply(null, data.map(d => d.y).concat([0])) || 1, L = fs * 3.2, B = fs + 6, pw = W - L - 4, ph = H - top - B;
    for (let i = 0; i <= 4; i++) { const y = top + ph - ph * i / 4; g += `<line x1="${L}" x2="${W - 2}" y1="${y}" y2="${y}" stroke="#ddd" stroke-width=".6"/><text x="${L - 2}" y="${y + fs / 3}" text-anchor="end" font-size="${fs * 0.85}" fill="#555">${fmtNum(mx * i / 4, "n0")}</text>`; }
    const bw = pw / data.length;
    if (c.chart === "line") { g += `<polyline fill="none" stroke="${pal[0]}" stroke-width="1.6" points="${data.map((d, i) => (L + bw * (i + 0.5)) + "," + (top + ph - ph * d.y / mx)).join(" ")}"/>`; data.forEach((d, i) => { g += `<circle cx="${L + bw * (i + 0.5)}" cy="${top + ph - ph * d.y / mx}" r="1.8" fill="${pal[0]}"/>`; }); }
    else data.forEach((d, i) => { const h = ph * Math.max(0, d.y) / mx; g += `<rect x="${L + bw * i + bw * 0.15}" y="${top + ph - h}" width="${bw * 0.7}" height="${h}" fill="${pal[i % 8]}"/>`; });
    data.forEach((d, i) => { if (data.length <= 12) g += `<text x="${L + bw * (i + 0.5)}" y="${H - 3}" text-anchor="middle" font-size="${fs * 0.8}" fill="#333" direction="rtl" unicode-bidi="plaintext">${esc(d.x.slice(0, Math.max(3, Math.floor(bw / (fs * 0.5)))))}</text>`; });
    return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:100%;display:block">${g}</svg>`;
  };
  RD.ctrlHTML = function (c) { const cx = new Ctx({ design: { calc: [], params: [] }, data: {}, company: {}, rows: [], allRows: [] }); return ctrlBox(c, cx, c.y); };
  function ctrlBox(c, cx, y, hOverride) {
    if (!visible(c, cx)) return "";
    if (c.t === "pagebreak") return "";
    const s = c.s || st(), cs = condStyle(c, cx);
    const h = hOverride != null ? hOverride : c.h;
    const boxCss = (c.t === "label" || c.t === "rtf" || c.t === "check" || c.t === "pageinfo" || c.t === "panel" || c.t === "barcode" || c.t === "pic" || c.t === "chart") ? styleCSS(s, cs) : "";
    const grow = c.t === "label" && c.grow && hOverride == null;
    return `<div class="rdc" data-id="${c.id}" style="position:absolute;left:${mm(c.x)};top:${mm(y == null ? c.y : y)};width:${mm(c.w)};${grow ? "min-height:" : "height:"}${mm(h)};box-sizing:border-box;${boxCss}${c.t === "line" ? "" : "overflow:" + (grow ? "visible" : "hidden") + ";"}">${ctrlInner(c, cx)}</div>`;
  }
  function tableHTML(c, cx, y, rowsH) {
    if (!visible(c, cx)) return "";
    let h = `<table class="rdtbl" data-id="${c.id}" style="position:absolute;left:${mm(c.x)};top:${mm(y == null ? c.y : y)};width:${mm(c.w)};border-collapse:collapse;table-layout:fixed;border-spacing:0${c.dir ? ";direction:" + c.dir : ""}">`;
    const cols = (c.rows[0] && c.rows[0].cells) || [];
    h += "<colgroup>" + cols.map(cl => `<col style="width:${mm(cl.w)}">`).join("") + "</colgroup>";
    c.rows.forEach((r, ri) => {
      const rh = rowsH && rowsH[ri] != null ? rowsH[ri] : r.h;
      h += `<tr style="height:${mm(rh)}">` + r.cells.map(cl => {
        if (cl.merged) return "";
        const s = cl.s || st(), cs = condStyle(cl, cx), al = s.al || "c";
        const txt = visible(cl, cx) ? RD.ctrlText(cl, cx) : "";
        return `<td${cl.span > 1 ? ` colspan="${cl.span}"` : ""} style="${styleCSS(s, cs)}text-align:${AL[al]};vertical-align:${{ t: "top", m: "middle", b: "bottom" }[s.va || "m"]};white-space:${cl.wrap === 0 ? "nowrap" : (cl.multi === 0 ? "normal" : "pre-wrap")};word-break:break-word;overflow:hidden;line-height:${(cx.design && cx.design.lh) || 1.25};box-sizing:border-box">${esc(txt)}${qkTag(cl, cx, txt)}</td>`;
      }).join("") + "</tr>";
    });
    return h + "</table>";
  }
  /* قياس الارتفاعات الفعلية (Can Grow) ثم دفع العناصر الواقعة أسفل العنصر المتمدد */
  let MEAS = null;
  function measHost() {
    if (MEAS && MEAS.isConnected) return MEAS;
    MEAS = document.createElement("div");
    MEAS.style.cssText = "position:absolute;left:-30000px;top:0;visibility:hidden;pointer-events:none;contain:layout";
    document.body.appendChild(MEAS);
    return MEAS;
  }
  function layoutBand(band, cx, d, cw) {
    const ctrls = band.ctrls || [];
    const list = ctrls.filter(c => visible(c, cx));
    const growers = list.filter(c => (c.t === "label" && c.grow) || c.t === "table");
    let heights = {};
    if (growers.length) {
      const host = measHost();
      host.innerHTML = `<div class="rdb rdmeas" dir="${d.rtl ? "rtl" : "ltr"}" style="position:relative;width:${mm(cw)};font-family:${d.font || "Tahoma"}">${growers.map(c => c.t === "table" ? tableHTML(c, cx, 0) : ctrlBox(c, cx, 0)).join("")}</div>`;
      const root = host.firstChild;
      growers.forEach(c => {
        const el = root.querySelector(`[data-id="${c.id}"]`);
        if (!el) return;
        if (c.t === "table") { heights[c.id] = { h: el.offsetHeight / PX, rows: Array.from(el.rows).map(tr => tr.offsetHeight / PX) }; }
        else heights[c.id] = { h: Math.max(c.h, el.offsetHeight / PX) };
      });
      host.innerHTML = "";
    }
    // دفع العناصر لأسفل بمقدار تمدد ما فوقها
    const sorted = list.slice().sort((a, b) => a.y - b.y);
    const pos = {}; const grows = [];
    // Can Shrink: عنصر نصي فارغ يُطوى ويرتفع ما تحته
    const empty = c => c.t === "label" && c.shrink && String(RD.ctrlText(c, cx)).trim() === "";
    const shrunk = {};
    sorted.forEach(c => { if (empty(c)) shrunk[c.id] = 1; });
    sorted.forEach(c => {
      // العناصر الواقعة فوقه وتتقاطع معه أفقياً: التمدد يدفع للأسفل (الأكبر) ، والطيّ يرفع بمقدار أقرب عنصر فوقه
      const ab = grows.filter(g => c.y >= g.bottom - 0.01 && c.x < g.right - 0.01 && c.x + c.w > g.left + 0.01);
      let shift = 0;
      if (ab.length) {
        const mxPos = Math.max.apply(null, ab.map(g => g.delta));
        if (mxPos > 0.01) shift = mxPos;
        else { const nb = Math.max.apply(null, ab.map(g => g.bottom)); shift = Math.max.apply(null, ab.filter(g => g.bottom >= nb - 0.01).map(g => g.delta)); }
      }
      const hh = shrunk[c.id] ? 0 : heights[c.id] ? heights[c.id].h : c.h, delta = (hh - c.h) + shift;
      pos[c.id] = { y: Math.max(0, c.y + shift), h: hh };
      grows.push({ bottom: c.y + c.h, left: c.x, right: c.x + c.w, delta });
    });
    const shrinkAll = Object.keys(shrunk).length > 0;
    let bh = shrinkAll ? 0 : band.h;
    sorted.forEach(c => { const p = pos[c.id]; if (c.t !== "pagebreak" && !shrunk[c.id]) bh = Math.max(bh, p.y + p.h); });
    if (shrinkAll) { const lowest = grows.reduce((m, g) => g.bottom > m.bottom ? g : m, { bottom: -1, delta: 0 }); bh = Math.max(bh, band.h + Math.min(0, lowest.delta)); }
    if (band.shrink && !list.length) bh = 0;
    const html = sorted.map(c => {
      const p = pos[c.id];
      if (c.t === "table") return tableHTML(c, cx, p.y, heights[c.id] && heights[c.id].rows);
      if (shrunk[c.id]) return "";
      return ctrlBox(c, cx, p.y, (c.t === "label" && c.grow) ? p.h : null);
    }).join("");
    const brk = list.some(c => c.t === "pagebreak");
    return { h: bh, html, brk };
  }
  RD.layoutBand = layoutBand;
  /* التصميم كاملاً → صفحات */
  RD.render = function (d, data, opt) {
    opt = opt || {};
    d = clone(d); RD.sortBands(d);
    if (d.src === "dexef") data = RD.dexData(data || {});
    const pg = Object.assign({}, d.page), m = pg.m.slice();
    if (opt.page) Object.assign(pg, opt.page);
    if (opt.margins) m.splice(0, 4, ...opt.margins);
    const land = !!pg.land, PW = land ? Math.max(pg.w, pg.h || pg.w) : pg.w, PH = land ? Math.min(pg.w, pg.h || pg.w) : pg.h;
    const roll = !PH || d.roll;
    const cw = PW - m[1] - m[3];
    const items = (data.items || []).slice();
    // الترتيب (Group and Sort)
    const sorts = (d.sort || []).filter(x => x.f);
    const groups = d.bands.filter(b => b.type === "GroupHeader" && b.field).sort((a, b) => (a.level || 0) - (b.level || 0));
    const keys = groups.map(g => ({ f: g.field, dir: g.dir || "asc" })).concat(sorts.map(s => ({ f: s.f, dir: s.dir || "asc" })));
    if (keys.length) items.sort((a, b) => { for (const k of keys) { const r = cmp(a[k.f], b[k.f]); if (r) return k.dir === "desc" ? -r : r; } return 0; });
    items.forEach((r, i) => { if (r.Index != null && !opt.keepIndex) r.Index = i + 1; });
    const base = new Ctx({ design: d, data: data.header || {}, company: data.company || COMPANY_CACHE || {}, rows: items, allRows: items, paramValues: opt.params || {} });
    const B = t => d.bands.filter(b => b.type === t);
    const topM = B("TopMargin")[0], botM = B("BottomMargin")[0];
    const flow = [];   // تسلسل البنود: {band, cx}
    B("ReportHeader").forEach(b => flow.push({ band: b, cx: base }));
    const det = B("Detail")[0];
    const gHeads = groups, gFoots = d.bands.filter(b => b.type === "GroupFooter");
    const footOf = g => gFoots.find(f => (f.level || 0) === (g.level || 0));
    const isLbl = d.kind === "bc";
    if (isLbl) {
      // الملصقات: كل نسخة صنف = خلية
      const cells = [];
      items.forEach(r => { const n = Math.max(1, Math.round(r.copies || 1)); for (let k = 0; k < n; k++) cells.push(r); });
      return renderLabels(d, base, cells, opt);
    }
    if (det) {
      const open = groups.map(() => null);
      const groupRowsOf = (gi, start) => { const g = groups[gi], v = items[start][g.field], out = []; for (let i = start; i < items.length; i++) { let same = true; for (let k = 0; k <= gi; k++) if (cmp(items[i][groups[k].field], items[start][groups[k].field]) !== 0) { same = false; break; } if (!same) break; out.push(items[i]); } return out; };
      items.forEach((r, i) => {
        // رؤوس المجموعات المتغيرة
        let changed = -1;
        for (let gi = 0; gi < groups.length; gi++) { const v = r[groups[gi].field]; if (open[gi] === null || cmp(open[gi].v, v) !== 0) { changed = gi; break; } }
        if (changed >= 0) {
          for (let gi = groups.length - 1; gi >= changed; gi--) if (open[gi]) { const f = footOf(groups[gi]); if (f) { const c2 = base.withRow(open[gi].last); c2.groupRows = open[gi].rows; flow.push({ band: f, cx: c2 }); } open[gi] = null; }
          for (let gi = changed; gi < groups.length; gi++) { const rowsG = groupRowsOf(gi, i); open[gi] = { v: r[groups[gi].field], rows: rowsG, last: rowsG[rowsG.length - 1] }; const c2 = base.withRow(r); c2.groupRows = rowsG; flow.push({ band: groups[gi], cx: c2 }); }
        }
        flow.push({ band: det, cx: base.withRow(r), row: r });
      });
      for (let gi = groups.length - 1; gi >= 0; gi--) if (open[gi]) { const f = footOf(groups[gi]); if (f) { const c2 = base.withRow(open[gi].last); c2.groupRows = open[gi].rows; flow.push({ band: f, cx: c2 }); } }
      if (!items.length && (det.ctrls || []).length && opt.emptyDetail !== false) { /* بدون أصناف: لا شيء */ }
    }
    B("ReportFooter").forEach(b => flow.push({ band: b, cx: base, last: 1 }));
    const ph = B("PageHeader"), pf = B("PageFooter");
    const pages = [];
    const lay = (b, cx) => layoutBand(b, cx, d, cw);
    const newPage = () => ({ parts: [], y: 0, rows: [] });
    let cur = newPage();
    const pfH = cx => pf.reduce((s, b) => s + lay(b, cx).h, 0);
    const avail = () => roll ? Infinity : PH - m[0] - m[2] - pfH(base);
    const putPH = () => { ph.forEach(b => { const r = lay(b, base); if (b.skipFirst && !pages.length) return; cur.parts.push({ y: cur.y, html: r.html, h: r.h }); cur.y += r.h; }); };
    // الصفحة الأولى: رأس التقرير أولاً ثم رأس الصفحة (مثل DEXEF)
    let phDone = !ph.length;
    flow.forEach((f, idx) => {
      if (!phDone && f.band.type !== "ReportHeader") { putPH(); phDone = true; }
      const r = lay(f.band, f.cx);
      if (r.h <= 0 && !r.html) return;
      if (!roll && cur.y + r.h > avail() + 0.01 && cur.parts.length && cur.y > 0.01) { pages.push(cur); cur = newPage(); putPH(); phDone = true; }
      cur.parts.push({ y: cur.y, html: r.html, h: r.h });
      if (f.row) cur.rows.push(f.row);
      cur.y += r.h;
      if ((r.brk || f.band.breakAfter) && !roll && idx < flow.length - 1) { pages.push(cur); cur = newPage(); putPH(); phDone = true; }
    });
    /* ✦ شريط «تابعونا» في آخر كل إيصال/فاتورة (حركات فقط — ليس التقارير ولا الملصقات) */
    const soc = (d.kind || "tx") === "tx" && opt.social !== false && d.social !== 0 ? RD.socialHTML(Object.assign({}, COMPANY_CACHE || {}, data.company || {}), { wide: !roll && cw > 120, cw }) : null;
    if (soc) {
      if (!phDone) { putPH(); phDone = true; }
      const gap = 1.5;
      if (!roll && cur.y + gap + soc.h > avail() + 0.01 && cur.parts.length) { pages.push(cur); cur = newPage(); putPH(); }
      cur.parts.push({ y: cur.y + gap, html: soc.html, h: soc.h }); cur.y += gap + soc.h;
    }
    if (!phDone) putPH();
    pages.push(cur);
    const total = pages.length;
    const out = pages.map((p, i) => {
      const cxp = new Ctx(base); cxp.pageRows = p.rows; cxp.page = i + 1;
      const H = roll ? (m[0] + p.y + pfH(cxp) + m[2]) : PH;
      let body = p.parts.map(x => `<div class="rdb" style="position:absolute;left:${mm(m[3])};top:${mm(m[0] + x.y)};width:${mm(cw)};height:${mm(x.h)}">${x.html}</div>`).join("");
      // تذييل الصفحة في أسفلها
      let fy = roll ? m[0] + p.y : PH - m[2] - pfH(cxp);
      pf.forEach(b => { const r = lay(b, cxp); body += `<div class="rdb" style="position:absolute;left:${mm(m[3])};top:${mm(fy)};width:${mm(cw)};height:${mm(r.h)}">${r.html}</div>`; fy += r.h; });
      // بنود الهوامش (تتكرر في كل صفحة)
      if (topM && (topM.ctrls || []).length) { const r = lay(topM, cxp); body = `<div class="rdb" style="position:absolute;left:${mm(m[3])};top:0;width:${mm(cw)};height:${mm(m[0])}">${r.html}</div>` + body; }
      if (botM && (botM.ctrls || []).length) { const r = lay(botM, cxp); body += `<div class="rdb" style="position:absolute;left:${mm(m[3])};top:${mm(H - m[2])};width:${mm(cw)};height:${mm(m[2])}">${r.html}</div>`; }
      body = body.replace(/\u0001PN\u0001/g, String(i + 1)).replace(/\u0001PC\u0001/g, String(total));
      return { w: PW, h: H, html: pageWrap(d, pg, PW, H, body) };
    });
    return { pages: out, w: PW, h: roll ? null : PH, roll, land };
  };
  function wmHTML(pg, W, H) {
    const w = pg.wm; if (!w || (!w.text && !w.img)) return "";
    let h = "";
    if (w.img) h += `<img src="${esc(w.img)}" style="position:absolute;left:0;top:0;width:100%;height:100%;object-fit:${w.imgMode === "stretch" ? "fill" : w.imgMode === "tile" ? "none" : "contain"};opacity:${(w.imgOp == null ? 30 : w.imgOp) / 100}">`;
    if (w.text) { const ang = w.dir === "h" ? 0 : w.dir === "bd" ? 45 : -45; h += `<div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%) rotate(${ang}deg);white-space:nowrap;font:${w.b ? "700 " : ""}${w.size || 48}pt ${w.font || "Arial"};color:${w.color || "#000"};opacity:${(w.op == null ? 15 : w.op) / 100}">${esc(w.text)}</div>`; }
    return `<div style="position:absolute;inset:0;pointer-events:none;overflow:hidden;${w.front ? "z-index:5" : "z-index:0"}">${h}</div>`;
  }
  function pageWrap(d, pg, W, H, body) {
    return `<div class="rdp" dir="${d.rtl ? "rtl" : "ltr"}" style="position:relative;width:${mm(W)};height:${mm(H)};background:${pg.color || "#fff"};overflow:hidden;font-family:${d.font || "Tahoma"};color:#000">${wmHTML(pg, W, H)}<div style="position:absolute;inset:0;z-index:1">${body}</div></div>`;
  }
  /* الملصقات: ورق «Label» (ملصق لكل صفحة) أو A4 مقسّم أعمدة × أسطر */
  function renderLabels(d, base, cells, opt) {
    const lb = d.label || { w: d.page.w, h: d.page.h, cols: 1, rows: 1 };
    const det = RD.band(d, "Detail") || { ctrls: [], h: lb.h };
    const cellHTML = (r, bw) => { const res = layoutBand(Object.assign({}, det, { h: lb.h }), base.withRow(r), d, bw || lb.w); return `<div style="position:absolute;inset:0;overflow:hidden">${res.html}</div>`; };
    if (d.paper !== "A4" && !lb.grid) {
      // ملصق لكل صفحة: بند التفاصيل داخل هوامش الصفحة (تصاميم DEXEF) أو على كامل الملصق
      const m = (d.page && d.page.m) || [0, 0, 0, 0], single = !!lb.single, bw = single ? (lb.bw || lb.w - m[1] - m[3]) : lb.w, bh = single ? Math.max(0.1, (lb.bh || det.h || lb.h)) : lb.h;
      const one = r => { const res = layoutBand(Object.assign({}, det, { h: bh }), base.withRow(r), d, bw); return `<div class="rdb" style="position:absolute;left:${mm(single ? m[3] : 0)};top:${mm(single ? m[0] : 0)};width:${mm(bw)};height:${mm(bh)};overflow:${single ? "visible" : "hidden"}">${res.html}</div>`; };
      const pages = cells.map(r => ({ w: lb.w, h: lb.h, html: pageWrap(d, d.page, lb.w, lb.h, one(r)) }));
      if (!pages.length) pages.push({ w: lb.w, h: lb.h, html: pageWrap(d, d.page, lb.w, lb.h, "") });
      return { pages, w: lb.w, h: lb.h, roll: false, label: 1 };
    }
    const PW = d.page.w, PH = d.page.h, m = d.page.m;
    const cols = Math.max(1, lb.cols || Math.floor((PW - m[1] - m[3]) / lb.w)), rows = Math.max(1, lb.rows || Math.floor((PH - m[0] - m[2]) / lb.h));
    const gx = lb.gx || 0, gy = lb.gy || 0, per = cols * rows, start = Math.max(0, opt.skip || 0);
    const all = new Array(start).fill(null).concat(cells), pages = [];
    for (let i = 0; i < Math.max(1, all.length); i += per) {
      let body = "";
      all.slice(i, i + per).forEach((r, k) => {
        if (!r) return;
        const across = lb.across !== 0;
        const c = across ? k % cols : Math.floor(k / rows), rr = across ? Math.floor(k / cols) : k % rows;
        const x = d.rtl ? PW - m[1] - (c + 1) * lb.w - c * gx : m[3] + c * (lb.w + gx), y = m[0] + rr * (lb.h + gy);
        body += `<div class="rdb" style="position:absolute;left:${mm(x)};top:${mm(y)};width:${mm(lb.w)};height:${mm(lb.h)}">${cellHTML(r)}</div>`;
      });
      pages.push({ w: PW, h: PH, html: pageWrap(d, d.page, PW, PH, body) });
    }
    return { pages, w: PW, h: PH, roll: false, label: 1 };
  }
  /* مستند HTML كامل للطباعة (صفحة لكل مقاس) */
  RD.docHTML = function (res, title) {
    const W = res.w, H = res.roll ? Math.max.apply(null, res.pages.map(p => p.h)) : res.h;
    return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title || "ANOUER")}</title><style>@page{size:${mm(W)} ${mm(H)};margin:0}html,body{margin:0;padding:0;background:#fff}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}.rdp{page-break-after:always;break-after:page}.rdp:last-child{page-break-after:auto;break-after:auto}table{border-collapse:collapse}</style></head><body>${res.pages.map(p => p.html).join("")}</body></html>`;
  };

  /* ================================================================== المخزن (Reports.*) */
  const LSK = "anouer.rd";
  const S = { idx: null, designs: {}, loaded: null };
  const lsGet = () => { try { return JSON.parse(localStorage.getItem(LSK) || "{}") || {}; } catch (e) { return {}; } };
  const lsPut = o => { try { localStorage.setItem(LSK, JSON.stringify(o)); } catch (e) { } };
  let HOST_OK = null;   // يدعم المضيف المفتاح Reports. ؟
  RD.load = function (force) {
    if (S.loaded && !force) return S.loaded;
    const loc = lsGet();
    S.loaded = (HOST() ? call("fm.settings.get", { prefix: "Reports.idx" }).then(o => { HOST_OK = true; return o && o["Reports.idx"] ? JSON.parse(o["Reports.idx"]) : null; }).catch(() => { HOST_OK = false; return null; }) : Promise.resolve(null))
      .then(idx => { S.idx = idx || loc.idx || null; if (!S.idx) S.idx = seedIdx(); normIdx(); return S.idx; })
      .then(idx => (idx.dexef || 0) >= DEXEF_V ? idx : importDexef(idx).catch(e => { console.error("DEXEF import", e); return idx; }))
      .then(idx => cash80Migrate(idx));
    return S.loaded;
  };
  /* ---------- إيصال استلام / دفع نقدية 80 مم (مرة واحدة): يصبح التصميم الافتراضي للتعاملين ، بنفس طابعة تصميم «استلام» السابق
     (التصميم السابق يبقى في القائمة — يمكن إرجاعه افتراضياً من «تصميم التقارير») */
  const CASH80_V = 1;   // التصميم نفسه يُبنى من cash80() عند كل طباعة (ما لم يُعدَّل) — أي تحسين يصل تلقائياً
  function cash80Migrate(x) {
    if (!x || !x.items || (x.cash80 || 0) >= CASH80_V) return Promise.resolve(x);
    [["rcv.80", "إيصال استلام نقدية"], ["pay.80", "إيصال دفع نقدية"]].forEach(([key, tx]) => {
      if (x.removed) x.removed = x.removed.filter(k => k !== key);
      let it = x.items.find(i => i.builtin === key);
      if (!it) { const b = RD.builtin(key); it = { id: "b_" + key.replace(/\W/g, "_"), name: b.name, kind: "tx", tx, tpl: "Default Template", paper: "Cashier Receipt", copies: 1, printer: "", def: false, builtin: key, edited: false, perm: "all", branch: "", created: ymd(new Date()) }; x.items.push(it); }
      const same = x.items.filter(i => i !== it && (i.kind || "tx") === "tx" && i.tx === tx && i.def && (i.tpl || "Default Template") === it.tpl);
      const src = same.find(i => i.printer) || x.items.find(i => i.id === "dx13x" && i.printer);
      if (!it.printer && src) { it.printer = src.printer; it.copies = src.copies || 1; }
      same.forEach(i => { i.def = false; });
      it.def = true;
    });
    x.cash80 = CASH80_V;
    /* عنوان الشركة: كان مكتوباً نصاً في تصميم DEXEF «استلام» — يُنقل إلى بيانات الشركة إن كانت فارغة (أو «الجزائر» المؤقت) */
    const addr = !HOST() ? Promise.resolve() : RD.getDesign({ id: "dx13x" }).then(d => {
      const c = d && [].concat.apply([], (d.bands || []).map(b => b.ctrls || [])).find(k => k.name === "label3" && !k.expr && String(k.text || "").trim());
      if (!c) return;
      return call("fm.settings.get", { prefix: "Company." }).then(s => {
        const cur = String((s || {})["Company.Address"] || "").trim();
        if (cur && cur !== RD.DEX_CO["Company Address"]) return;
        return call("fm.settings.set", { values: { "Company.Address": String(c.text).trim() } }).then(() => { RD.resetCompany(); });
      });
    }).catch(() => { });
    return addr.then(() => putKeys({ "Reports.idx": JSON.stringify(x) })).then(() => x, () => x);
  }
  /* ---------- نقل تصاميم DEXEF (مرة واحدة): كل تصاميم التعاملات والباركود بمقاساتها ، وحذف تصاميم ANOUER الجاهزة */
  function bundleURL() {
    const s = Array.from(document.scripts).find(x => /rd-engine\.js(\?|$)/.test(x.src || ""));
    return s ? s.src.replace(/rd-engine\.js(\?.*)?$/, "rd-dexef-designs.js") : "../assets/js/rd-dexef-designs.js";
  }
  function loadBundle() {
    if (window.ANOUER_RD_DEXEF) return Promise.resolve(window.ANOUER_RD_DEXEF);
    return new Promise((res, rej) => { const sc = document.createElement("script"); sc.src = bundleURL(); sc.onload = () => window.ANOUER_RD_DEXEF ? res(window.ANOUER_RD_DEXEF) : rej(new Error("bundle")); sc.onerror = () => rej(new Error("لم يُعثر على ملف تصاميم DEXEF")); document.head.appendChild(sc); });
  }
  const DEXEF_V = 7;   // 7: فاتورة A5 بدون إطارات بنفس مسافات DEXEF
  const DEXEF_V6 = 6;   // 5: سطر الكاشير في كل تصاميم الكاشير (ومنها المعدّلة) — 6: بنفس مسافات DEXEF
  const DEXEF_V4 = 4;   // 3: سطر الكاشير المختصر (المبلغ · DZD · نقدى/آجل) — 4: فاتورة A5: المبلغ بالحروف + سطر التعامل   // إصدار النقل: عند الزيادة تُحدَّث تصاميم DEXEF غير المعدّلة (مع بقاء الترتيب والافتراضى والطابعات)
  /* بيانات الشركة في DEXEF (تُستعمل إذا كانت خانات الشركة في ANOUER فارغة) */
  RD.DEX_CO = {};
  /* سطر الكاشير المختصر تحت «الرصيد الحالي»: المبلغ · DZD · نقدى/آجل (مثل DEXEF) — يُضاف مرة واحدة */
  RD.patchCashierLine = function (d) {
    if (!d || !d.roll) return false;
    const b = (d.bands || []).find(x => x.type === "ReportFooter"); if (!b) return false;
    const cs = b.ctrls || (b.ctrls = []);
    const txt = c => c.t === "table" ? (c.rows || []).map(r => (r.cells || []).map(x => x.text || "").join(" ")).join(" ") : (c.text || "");
    const rows = cs.filter(c => /الرصيد\s*الحال[يى]/.test(txt(c))).sort((a, z) => (z.y + z.h) - (a.y + a.h));
    const row = rows[0], rb = row ? row.y + row.h : null;
    const line = row ? cs.filter(c => c.t === "line" && c.y >= rb - 0.6 && c.y <= rb + 4).sort((a, z) => a.y - z.y)[0] : null;
    const st0 = Object.assign({}, ((row && row.rows && row.rows[0] && row.rows[0].cells[0]) || row || {}).s || {});
    /* نفس مسافات DEXEF (بالمليمتر من بداية الخط المنقّط): نقدى ≈ 3.3 ، DZD ≈ 21 ، المبلغ ≈ 37.8 ، والسطر ≈ 7.5 مم تحت الخط */
    const H = 6, ws = [14, 20, 14];   // المبلغ · DZD · نقدى (من اليمين)
    const lay = (tb, y) => {
      const lx = line ? line.x : (row ? row.x : 2.3);
      const s0 = Object.assign({}, st0, tb && tb.s && tb.s.ff ? { ff: tb.s.ff } : {}, { fs: 8, b: 0, i: 0, u: 0, bd: "", bg: "", pad: [0, 0, 0, 0], al: "c", va: "m", color: "black" });
      const cell = (e, k, w) => ({ id: uid(), w, text: "", expr: e, fmt: "", s: Object.assign({}, s0, k === "amt" ? { fs: 8.5 } : k === "pay" ? { fs: 7.5 } : {}), name: "LblHorof." + k, wrap: 0 });
      const t = { id: (tb && tb.id) || uid(), t: "table", x: Math.max(0, lx - 3.2), y, w: ws[0] + ws[1] + ws[2], h: H, dir: "rtl", name: "LblHorof", s: s0,
        rows: [{ h: H, cells: [cell("[Amount Short]", "amt", ws[0]), cell("[Currency Code]", "cur", ws[1]), cell("[Payment Type]", "pay", ws[2])] }] };
      return t;
    };
    const yLine = line ? line.y + line.h / 2 + 7.5 - H / 2 : (rb != null ? rb + 4.5 : null);
    // 1) السطر موجود (من تحديث سابق) أو خانة «LblHorof» الأصلية ← بنفس المسافات
    const i = cs.findIndex(c => String(c.name || "").toLowerCase() === "lblhorof");
    if (i >= 0) {
      const c = cs[i];
      if (c.t !== "label" && JSON.stringify(c).indexOf("[Payment Type]") < 0) return false;
      const y = yLine != null ? yLine : c.y;
      const before = JSON.stringify([c.x, c.y, c.w, (c.rows || []).map(r => r.cells.map(x => [x.w, x.s && x.s.fs]))]);
      const t = lay(c, y); cs[i] = t;
      return before !== JSON.stringify([t.x, t.y, t.w, t.rows.map(r => r.cells.map(x => [x.w, x.s.fs]))]);
    }
    if (JSON.stringify(d).indexOf("[Payment Type]") >= 0 || yLine == null) return false;
    // 2) إضافة السطر بعد «الرصيد الحالي» والخط المنقّط
    const y = yLine, X0 = line ? line.x : row.x, SP = line ? line.w : 69.5;
    const busy = cs.some(c => c !== line && c !== row && c.y < y + H && c.y + c.h > y && c.x < X0 + SP && c.x + c.w > X0 && !(c.t === "pic" && c.x >= X0 + SP - 30));
    if (busy) { const sh = y + H + 0.4 - Math.min.apply(null, cs.filter(c => c.y >= y - 0.05 && c !== line && !(c.t === "pic")).map(c => c.y).concat([y + H + 0.4])); if (sh > 0) { cs.forEach(c => { if (c.y >= y - 0.05 && c !== line && c.t !== "pic") c.y += sh; }); b.h = (+b.h || 0) + sh; } }
    cs.push(lay(null, y));
    return true;
  };
  /* فاتورة A5 (DEXEF «مبيعات اي فايف»): بعد «الرصيد الحالى» بدون إطارات وبنفس مسافات DEXEF:
     سطر 1: المبلغ · DZD · نقدي … الخزينة   —   سطر 2: سياسة التعامل … تسعدنا زيارتكم */
  RD.patchA5Line = function (d) {
    if (!d || d.roll || d.paper !== "A5" || d.src !== "dexef") return false;
    const b = (d.bands || []).find(x => x.type === "ReportFooter"); if (!b) return false;
    const cs = b.ctrls || [];
    if (cs.some(c => c.name === "DealLine")) return false;
    const txt = c => c.t === "table" ? (c.rows || []).map(r => (r.cells || []).map(x => (x.text || "") + (x.expr || "")).join(" ")).join(" ") : ((c.text || "") + (c.expr || ""));
    const lab = cs.filter(c => c.t === "table" && /الرصيد\s*الحال[يى]/.test(txt(c))).sort((a, z) => z.y - a.y)[0];
    if (!lab) return false;
    const val = cs.filter(c => c.t === "table" && c.y >= lab.y + lab.h - 0.3 && c.y <= lab.y + lab.h + 2).sort((a, z) => a.y - z.y)[0] || lab;
    const vc = val.y + val.h / 2, X = val.x, W = val.w;
    // حذف سطر الإصدار السابق (بإطارات) ثم إعادة ترتيب ما تحته
    const oldRow = cs.find(c => c.name === "DealRow");
    let rest = cs.filter(c => c !== oldRow && c.y > val.y + val.h - 0.1 && c.t !== "table" && String(c.name || "") !== "LblDonation");
    const ref = cs.find(c => c.name === "LblDonation") || {};
    const st0 = Object.assign({}, (((val.rows || [])[0] || {}).cells || [{}])[0].s || {}, { fs: 8, b: 0, i: 0, u: 0, bd: "", bg: "", color: "black", pad: [0, 0, 0, 0], va: "m", al: "c" });
    const H = 6, y1 = vc + 5.5 - H / 2, y2c = vc + 12.25;
    // سطر 1 (من اليمين): فراغ · المبلغ · DZD · نقدي · فراغ · الخزينة · فراغ  (مقاسات DEXEF على عرض 138 مم)
    const k = W / 138, cell = (e, w, extra) => ({ id: uid(), w: w * k, text: "", expr: e, fmt: "", s: Object.assign({}, st0, extra || {}), name: "DealLine." + (e || "sp"), wrap: 0 });
    const row = { id: uid(), t: "table", x: X, y: y1, w: W, h: H, dir: "rtl", name: "DealLine", s: Object.assign({}, st0),
      rows: [{ h: H, cells: [cell("", 6.9), cell("[Amount Short]", 15, { fs: 8.5 }), cell("[Currency Code]", 15), cell("[Payment Type]", 16.8), cell("", 20.1), cell("[Treasury]", 40), cell("", 24.2)] }] };
    // سطر 2: «تسعدنا زيارتكم» والملاحظات وسياسة التعامل
    let man = cs.find(c => String(c.name || "").toLowerCase() === "lblmanner");
    const others = rest.filter(c => c !== man);
    if (others.length) { const top = Math.min.apply(null, others.map(c => c.y + c.h / 2)), dy = y2c - top; others.forEach(c => { c.y += dy; }); }
    if (!man) { man = { id: uid(), t: "label", name: "LblManner", x: X, y: 0, w: 41 * k, h: 5.8, text: "", expr: "", fmt: "", s: Object.assign({}, st0, { al: "r" }) }; cs.push(man); }
    man.expr = "[Payment Policy Line]"; man.text = ""; man.x = X; man.w = 41 * k; man.y = y2c - man.h / 2; man.s = Object.assign({}, man.s || st0, { al: "r", va: "m", bd: "", bg: "" });
    if (oldRow) cs.splice(cs.indexOf(oldRow), 1);
    cs.push(row);
    const bottom = Math.max.apply(null, cs.map(c => c.y + c.h));
    if (bottom + 1 > (+b.h || 0)) b.h = bottom + 1;
    return true;
  };
  function importDexef(x) {
    return loadBundle().then(B => {
      // حذف التصاميم الجاهزة (الافتراضي) وتصاميمها المحفوظة
      const old = x.items.filter(i => i.builtin);
      x.items = x.items.filter(i => !i.builtin);
      x.removed = RD.BUILTIN.map(b => b.key);
      (B.tpls || []).forEach(t => { if (!x.tpls.some(p => p.name === t)) x.tpls.push({ name: t, perm: "all", owner: "" }); });
      const today = ymd(new Date()), vals = {}, edited = [];
      B.items.forEach(it => {
        const ex = x.items.find(i => i.id === it.id);
        if (ex) {   // موجود: تحديث التصميم فقط إن لم يُعدَّل في ANOUER
          if (!ex.edited && (x.dexef || 0) < DEXEF_V) { const d = B.designs[it.id]; if (d) { d.name = ex.name; RD.patchCashierLine(d); RD.patchA5Line(d); S.designs[it.id] = clone(d); vals["Reports.d." + it.id] = JSON.stringify(d); } }
          else if (ex.edited && (x.dexef || 0) < DEXEF_V) edited.push(ex);
          return;
        }
        if ((x.dexDel || []).indexOf(it.id) >= 0) return;   // حذفه المستخدم
        const hasDef = it.def && x.items.some(i => (i.kind || "tx") === it.kind && i.tx === it.tx && i.tpl === it.tpl && i.def);
        x.items.push({ id: it.id, name: it.name, kind: it.kind, tx: it.tx, tpl: it.tpl, paper: it.paper, copies: it.copies || 1, printer: it.printer || "", def: !!it.def && !hasDef, edited: false, perm: "all", branch: "", created: today, src: "dexef", dexId: it.dexId });
        const d = B.designs[it.id]; if (d) { RD.patchCashierLine(d); RD.patchA5Line(d); S.designs[it.id] = clone(d); vals["Reports.d." + it.id] = JSON.stringify(d); }
      });
      // التصاميم المعدّلة في ANOUER: تبقى كما هي مع إضافة سطر الكاشير فقط
      return Promise.all(edited.map(ex => RD.getDesign(ex).then(d => { if (d && (RD.patchCashierLine(d) | RD.patchA5Line(d))) { S.designs[ex.id] = clone(d); vals["Reports.d." + ex.id] = JSON.stringify(d); } }).catch(() => { })))
        .then(() => finishImport(x, B, vals, old));
    });
  }
  function finishImport(x, B, vals, old) {
    {
      old.forEach(i => { vals["Reports.d." + i.id] = null; delete S.designs[i.id]; });
      if (B.logo) { vals["Reports.logo"] = B.logo; RD.dexLogo = B.logo; }
      x.dexef = DEXEF_V;
      // خانات الشركة الفارغة ← بيانات DEXEF (الهاتف ، العنوان)
      const coFill = !HOST() ? Promise.resolve() : call("fm.settings.get", { prefix: "Company." }).then(s => {
        s = s || {}; const m = { "Company.Phone": RD.DEX_CO["Company Phone"], "Company.Mobile": RD.DEX_CO["Company Mobile"], "Company.Address": RD.DEX_CO["Company Address"] }, v = {};
        Object.keys(m).forEach(k => { if (!String(s[k] || "").trim()) v[k] = m[k]; });
        return Object.keys(v).length ? call("fm.settings.set", { values: v }) : null;
      }).catch(() => { });
      // الحفظ على دفعات (التصاميم كبيرة بسبب الصور)
      const keys = Object.keys(vals), batches = [];
      let cur = {}, size = 0;
      keys.forEach(k => { const n = vals[k] ? vals[k].length : 0; if (size + n > 1500000 && Object.keys(cur).length) { batches.push(cur); cur = {}; size = 0; } cur[k] = vals[k]; size += n; });
      if (Object.keys(cur).length) batches.push(cur);
      batches.push({ "Reports.idx": JSON.stringify(x) });
      return coFill.then(() => batches.reduce((p, b) => p.then(() => putKeys(b)), Promise.resolve())).then(() => { RD.resetCompany && RD.resetCompany(); return x; });
    }
  }
  RD.importDexef = () => { if (!S.idx) return RD.load(); S.idx.dexef = 0; return importDexef(S.idx); };
  function seedIdx() {
    const items = RD.BUILTIN.map(b => ({ id: "b_" + b.key.replace(/\W/g, "_"), name: b.mk().name, kind: b.kind || "tx", tx: b.tx, tpl: "Default Template", paper: b.paper, copies: 1, printer: "", def: !!b.def, builtin: b.key, edited: false, perm: "all", branch: "", created: ymd(new Date()) }));
    return { v: 1, items, tpls: [{ name: "Default Template", perm: "all", owner: "" }], tpl: "Default Template", secs: [] };
  }
  function normIdx() {
    const x = S.idx; x.items = x.items || []; x.tpls = x.tpls || [{ name: "Default Template", perm: "all" }]; x.secs = x.secs || []; if (!x.tpl) x.tpl = "Default Template";
    if (!x.tpls.some(t => t.name === "Default Template")) x.tpls.unshift({ name: "Default Template", perm: "all" });
    // تصاميم جاهزة أُضيفت في إصدار أحدث
    RD.BUILTIN.forEach(b => { const id = "b_" + b.key.replace(/\W/g, "_"); if (!x.items.some(i => i.builtin === b.key) && !(x.removed || []).includes(b.key)) x.items.push({ id, name: b.mk().name, kind: b.kind || "tx", tx: b.tx, tpl: "Default Template", paper: b.paper, copies: 1, printer: "", def: !!b.def && !x.items.some(i => i.tx === b.tx && (i.kind || "tx") === (b.kind || "tx") && i.def), builtin: b.key, edited: false, perm: "all", branch: "", created: ymd(new Date()) }); });
  }
  RD.idx = () => S.idx;
  function putKeys(vals) {
    const loc = lsGet();
    Object.keys(vals).forEach(k => { if (k === "Reports.idx") loc.idx = JSON.parse(vals[k]); else if (k.indexOf("Reports.d.") === 0) { loc.d = loc.d || {}; if (vals[k] == null) delete loc.d[k.slice(10)]; else loc.d[k.slice(10)] = JSON.parse(vals[k]); } });
    lsPut(loc);
    if (!HOST() || HOST_OK === false) return Promise.resolve(true);
    const clean = {}; Object.keys(vals).forEach(k => { clean[k] = vals[k] == null ? "" : vals[k]; });
    return call("fm.settings.set", { values: clean }).then(() => true).catch(e => {
      if (/غير مسموح/.test((e && e.message) || "")) { HOST_OK = false; return true; }   // إصدار قديم: يبقى الحفظ محلياً
      throw e;
    });
  }
  RD.saveIdx = () => putKeys({ "Reports.idx": JSON.stringify(S.idx) });
  RD.getDesign = function (it) {
    if (!it) return Promise.resolve(null);
    if (S.designs[it.id]) return Promise.resolve(clone(S.designs[it.id]));
    const loc = lsGet(), fromLoc = loc.d && loc.d[it.id];
    const fallback = () => { const d = fromLoc || (it.builtin ? RD.builtin(it.builtin) : null); if (d) { d.name = it.name; S.designs[it.id] = d; } return clone(d); };
    if (!HOST() || HOST_OK === false) return Promise.resolve(fallback());
    return call("fm.settings.get", { prefix: "Reports.d." + it.id }).then(o => {
      const v = o && o["Reports.d." + it.id];
      if (v) { try { const d = JSON.parse(v); S.designs[it.id] = d; return clone(d); } catch (e) { } }
      return fallback();
    }).catch(fallback);
  };
  RD.putDesign = function (it, d) {
    S.designs[it.id] = clone(d);
    return putKeys({ ["Reports.d." + it.id]: JSON.stringify(d) });
  };
  RD.dropDesign = function (it) { delete S.designs[it.id]; return putKeys({ ["Reports.d." + it.id]: null }); };
  RD.cacheDrop = id => { delete S.designs[id]; };

  /* التصميم الافتراضي لتعامل (النموذج النشط ← Default Template ← الجاهز) */
  RD.defaultFor = function (tx, kind, branch) {
    kind = kind || "tx";
    return RD.load().then(idx => {
      const ok = i => (i.kind || "tx") === kind && (kind === "bc" || i.tx === tx) && (!i.branch || !branch || i.branch === branch);
      const pick = tpl => idx.items.find(i => ok(i) && i.def && i.tpl === tpl) || null;
      return pick(idx.tpl) || pick("Default Template") || idx.items.find(i => ok(i) && i.tpl === idx.tpl) || idx.items.find(ok) || null;
    });
  };

  /* ================================================================== الطباعة */
  let PRN = null;
  RD.printers = function () {
    if (PRN) return Promise.resolve(PRN);
    if (!HOST()) return Promise.resolve({ printers: [], def: "", host: false });
    return call("print.printers").then(r => (PRN = { printers: (r && r.printers) || [], def: (r && r.def) || "", host: true })).catch(() => ({ printers: [], def: "", host: false }));
  };
  RD.resetPrinters = () => { PRN = null; };
  /* نافذة الطباعة (اختيار الطابعة يدوياً) — إطار مخفي داخل الصفحة */
  /* الطباعة من النافذة نفسها (وليس من إطار مخفي): المتصفح كان يطبع الصفحة الرئيسية الفارغة بدل الفاتورة
     — تُوضع صفحات المستند في حاوية للطباعة فقط ، ويُخفى كل ما عداها ، ومقاس الورقة @page بالضبط */
  RD.printDialog = function (html) {
    const old = document.getElementById("rd-print"); if (old) old.remove();
    const oldS = document.getElementById("rd-print-css"); if (oldS) oldS.remove();
    const pageRule = (/@page\s*\{[^}]*\}/.exec(html) || ["@page{margin:0}"])[0];
    const body = (/<body[^>]*>([\s\S]*)<\/body>/i.exec(html) || [0, html])[1];
    const titleM = /<title>([\s\S]*?)<\/title>/i.exec(html);
    const css = document.createElement("style"); css.id = "rd-print-css";
    css.textContent = `${pageRule}
      @media screen{#rd-print{display:none!important}}
      @media print{html,body{margin:0!important;padding:0!important;background:#fff!important;height:auto!important;min-height:0!important;overflow:visible!important;zoom:1!important}
        body>*:not(#rd-print){display:none!important}
        #rd-print{display:block!important;position:static!important;margin:0!important;padding:0!important}
        #rd-print *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
        #rd-print .rdp{page-break-after:always;break-after:page;margin:0!important;box-shadow:none!important}
        #rd-print .rdp:last-child{page-break-after:auto;break-after:auto}}`;
    const box = document.createElement("div"); box.id = "rd-print"; box.innerHTML = body;
    document.head.appendChild(css); document.body.appendChild(box);
    const t0 = document.title; if (titleM) document.title = titleM[1].replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
    let cleaned = false;
    const clean = () => { if (cleaned) return; cleaned = true; window.removeEventListener("afterprint", clean); document.title = t0; box.remove(); css.remove(); };
    window.addEventListener("afterprint", clean);
    // انتظار تحميل الصور قبل فتح نافذة الطباعة
    const imgs = Array.from(box.querySelectorAll("img")).filter(i => !i.complete);
    Promise.race([Promise.all(imgs.map(i => new Promise(r => { i.onload = i.onerror = r; }))), new Promise(r => setTimeout(r, 3000))]).then(() => {
      setTimeout(() => { try { window.focus(); window.print(); } catch (e) { T("تعذّرت الطباعة", "e"); clean(); } }, 60);
    });
  };
  /* ================= تحويل صفحات المستند إلى صور (للطباعة بـ GDI مثل DEXEF)
     طباعة المتصفح (Chromium) على طابعات الكاشير الحرارية كانت تُخرج ورقاً أبيض طويلاً ،
     لذلك تُرسم كل صفحة صورةً بدقة الطابعة وتُرسل للمضيف ليطبعها بالمقاس الحقيقي بالمليمتر */
  const imgCache = {};
  function toDataUrl(src) {
    if (!src || /^data:/i.test(src)) return Promise.resolve(src);
    if (imgCache[src]) return imgCache[src];
    return (imgCache[src] = fetch(src).then(r => { if (!r.ok) throw 0; return r.blob(); })
      .then(b => new Promise(ok => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.onerror = () => ok(""); fr.readAsDataURL(b); })).catch(() => ""));
  }
  RD.rasterize = function (res, o) {
    o = o || {};
    const list = o.pages || res.pages.map((p, i) => i);
    const XNS = "http://www.w3.org/1999/xhtml";
    return list.reduce((pr, i) => pr.then(out => {
      const p = res.pages[i]; if (!p) return out;
      const W = p.w, H = p.h || res.h || 100;
      const dpi = o.dpi || (W <= 120 ? 203 : 300);
      const wpx = W * 96 / 25.4, hpx = H * 96 / 25.4;
      let sc = dpi / 96; const maxH = 30000; if (hpx * sc > maxH) sc = maxH / hpx;
      const box = document.createElement("div");
      box.setAttribute("style", `width:${wpx}px;height:${hpx}px;margin:0;padding:0;background:#fff;overflow:hidden`);
      box.innerHTML = `<style>*{-webkit-print-color-adjust:exact;print-color-adjust:exact;box-sizing:border-box}table{border-collapse:collapse}.rdp{margin:0!important;box-shadow:none!important}</style>` + p.html;
      const imgs = Array.from(box.querySelectorAll("img"));
      return Promise.all(imgs.map(im => toDataUrl(im.getAttribute("src")).then(u => { if (u) im.setAttribute("src", u); else im.remove(); }))).then(() => {
        const cw = Math.max(1, Math.round(wpx * sc)), ch = Math.max(1, Math.round(hpx * sc)), th = W <= 120 || o.thermal;
        const paint = node => new Promise((ok, bad) => {
          const x = new XMLSerializer().serializeToString(node);
          const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${wpx}" height="${hpx}" viewBox="0 0 ${wpx} ${hpx}"><foreignObject x="0" y="0" width="${wpx}" height="${hpx}">${x.indexOf("xmlns=") < 0 ? x.replace("<div", `<div xmlns="${XNS}"`) : x}</foreignObject></svg>`;
          const im = new Image();
          im.onload = () => { try { const c = document.createElement("canvas"); c.width = cw; c.height = ch; const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, cw, ch); g.setTransform(sc, 0, 0, sc, 0, 0); g.drawImage(im, 0, 0, wpx, hpx); ok(c); } catch (e) { bad(e); } };
          im.onerror = () => bad(new Error("تعذّر تحويل الصفحة " + (i + 1) + " إلى صورة"));
          im.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
        });
        /* العلامة المائية تُرسم في طبقة مستقلة: النص يُحسَّن (أسود حاد) ، والعلامة تحتفظ بشفافيتها الحقيقية
           (على الحرارية: تنقيط ناعم بنسبة الشفافية بدل أن تصير سوداء كاملة أو تختفي) ثم تُدمج بالضرب (multiply) */
        const hasWm = !!box.querySelector(".rr-wm");
        if (!hasWm) return paint(box).then(c => { try { RD.inkBoost(c, th); } catch (e) { console.warn("inkBoost", e); } out.push({ png: c.toDataURL("image/png"), w: W, h: H }); return out; });
        const b1 = box.cloneNode(true); b1.querySelectorAll(".rr-wm").forEach(e => e.remove());
        const b2 = box.cloneNode(true); b2.classList.add("rdwm1");
        b2.insertAdjacentHTML("afterbegin", "<style>.rdwm1 *{visibility:hidden!important}.rdwm1 .rr-wm,.rdwm1 .rr-wm *{visibility:visible!important}.rdwm1 .rr-wm .wmh{display:none!important}</style>");
        return paint(b1).then(c => paint(b2).then(c2 => {
          try { RD.inkBoost(c, th); } catch (e) { console.warn("inkBoost", e); }
          try { if (th) RD.toneDither(c2); } catch (e) { console.warn("toneDither", e); }
          const g = c.getContext("2d"); g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = "multiply"; g.drawImage(c2, 0, 0); g.globalCompositeOperation = "source-over";
          out.push({ png: c.toDataURL("image/png"), w: W, h: H }); return out;
        }));
      });
    }), Promise.resolve([]));
  };
  /* طباعة واضحة جداً (2026): حواف الحروف الرمادية (Anti-aliasing) تخرج باهتة على الطابعات —
     • الطابعة الحرارية (إيصال ≤ 120 مم): صورة أبيض/أسود حادة بدقة الطابعة — النص أسود كامل، والرمادي (الصور، العلامة المائية) بتنقيط Floyd–Steinberg
     • A4 / A5: تعميق الرمادي الفاتح للنص (منحنى تباين) مع بقاء الصور طبيعية */
  /* تنقيط بالدرجات (Floyd–Steinberg) لطبقة العلامة المائية على الطابعة الحرارية: الشفافية = كثافة النقاط */
  RD.toneDither = function (c) {
    const g = c.getContext("2d"), W = c.width, H = c.height; if (!W || !H) return;
    const im = g.getImageData(0, 0, W, H), d = im.data, n = W * H, L = new Float32Array(n);
    for (let p = 0, i = 0; p < n; p++, i += 4) L[p] = .299 * d[i] + .587 * d[i + 1] + .114 * d[i + 2];
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const p = y * W + x, v = L[p]; if (v >= 253) { L[p] = 255; continue; }
      const o = v < 128 ? 0 : 255, e = v - o; L[p] = o;
      if (x + 1 < W) L[p + 1] += e * 7 / 16;
      if (y + 1 < H) { if (x > 0) L[p + W - 1] += e * 3 / 16; L[p + W] += e * 5 / 16; if (x + 1 < W) L[p + W + 1] += e / 16; }
    }
    for (let p = 0, i = 0; p < n; p++, i += 4) { const v = L[p] < 128 ? 0 : 255; d[i] = d[i + 1] = d[i + 2] = v; d[i + 3] = 255; }
    g.putImageData(im, 0, 0);
  };
  RD.inkBoost = function (c, thermal) {
    const g = c.getContext("2d"), W = c.width, H = c.height; if (!W || !H) return;
    const im = g.getImageData(0, 0, W, H), d = im.data, n = W * H;
    if (!thermal) {
      for (let i = 0; i < d.length; i += 4) {
        const r = d[i], gg = d[i + 1], b = d[i + 2], mx = Math.max(r, gg, b), mn = Math.min(r, gg, b);
        if (mx - mn > 40) continue;                                  // لون مشبع (شعار / ختم ملوّن) يبقى كما هو
        const L = .299 * r + .587 * gg + .114 * b; if (L > 238) continue;
        const k = L < 128 ? L * .55 : 70 + (L - 128) * 1.52;         // منحنى: الأسود أعمق، الرمادي الفاتح أوضح
        const f = Math.max(0, Math.min(1, k / Math.max(1, L)));
        d[i] = r * f; d[i + 1] = gg * f; d[i + 2] = b * f;
      }
      g.putImageData(im, 0, 0); return;
    }
    const L = new Float32Array(n);
    for (let p = 0, i = 0; p < n; p++, i += 4) { const a = d[i + 3] / 255; L[p] = (.299 * d[i] + .587 * d[i + 1] + .114 * d[i + 2]) * a + 255 * (1 - a); }
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const p = y * W + x, v = L[p];
      let o;
      if (v < 175) o = 0;                 // حبر النص وحوافه ← أسود كامل (أوضح وأعرض قليلاً)
      else if (v > 238) o = 255;          // خلفية
      else o = v < 212 ? 0 : 255;         // رمادي متوسط (صور / علامة مائية): تنقيط بانتشار الخطأ
      const e = v - o; L[p] = o;
      if (v >= 175 && v <= 238) {
        if (x + 1 < W) L[p + 1] += e * 7 / 16;
        if (y + 1 < H) { if (x > 0) L[p + W - 1] += e * 3 / 16; L[p + W] += e * 5 / 16; if (x + 1 < W) L[p + W + 1] += e / 16; }
      }
    }
    for (let p = 0, i = 0; p < n; p++, i += 4) { const v = L[p] < 128 ? 0 : 255; d[i] = d[i + 1] = d[i + 2] = v; d[i + 3] = 255; }
    g.putImageData(im, 0, 0);
  };
  /* «1-3, 5, 8-» → فهارس الصفحات */
  RD.parsePages = function (txt, n) {
    const out = []; let bad = false;
    String(txt || "").split(/[,;،\s]+/).filter(Boolean).forEach(t => {
      const m = /^(\d*)\s*-\s*(\d*)$/.exec(t) || /^(\d+)$/.exec(t);
      if (!m) { bad = true; return; }
      let a = +m[1] || 1, b = m[2] === undefined ? a : (+m[2] || n);
      if (a > b) { const z = a; a = b; b = z; }
      for (let k = a; k <= Math.min(b, n); k++) if (out.indexOf(k - 1) < 0) out.push(k - 1);
    });
    return bad ? null : out.sort((x, y) => x - y);
  };

  /* ================= نافذة الطباعة (مثل DevExpress / DEXEF تماماً) */
  /* طابعة الفواتير A4 / A5 الثابتة (بطلب المستخدم): «Pantum-P2500-Series» إن كانت مثبّتة (localStorage «anouer.a4Printer» للتغيير) */
  RD.A4_PRINTER = "Pantum-P2500-Series";
  const prnN = s => String(s || "").toLowerCase().replace(/[\s_\-]+/g, "");
  const pickPrn = (L, want) => L.find(x => x === want) || L.find(x => prnN(x) === prnN(want)) || L.find(x => prnN(x).indexOf(prnN(want)) >= 0) || "";
  const isPage = res => !!(res && !res.roll && (+res.w || 0) >= 140);   // A5 (148) / A4 (210) — لا الإيصال 80 مم ولا الملصق
  /* الخصائص ← الأجهزة و الطابعات (dev.printers): pA4 / pA3 / pCashier / pBarcode — لها الأولوية */
  RD.devPrinter = sz => { try { const v = (window.ANOUER_PROPS && ANOUER_PROPS.get("dev.printers", {})) || {}, x = v["p" + sz] || ""; return sz === "A4" && x === "XP-80C" ? "" : x; } catch (e) { return ""; } };
  const isA3 = res => !!(res && !res.roll && (+res.w || 0) >= 290);
  const a4Want = res => { if (isA3(res) && RD.devPrinter("A3")) return RD.devPrinter("A3"); const d = RD.devPrinter("A4"); if (d) return d; try { return localStorage.getItem("anouer.a4Printer") || RD.A4_PRINTER; } catch (e) { return RD.A4_PRINTER; } };
  RD.pagePrinter = res => RD.printers().then(pr => pickPrn((pr && pr.printers) || [], a4Want(res))).catch(() => "");
  RD.hostPrintDialog = function (res, o) {
    o = o || {};
    return RD.printers().then(pr => new Promise((resolve) => {
      const list = (pr.printers || []).slice(), n = res.pages.length;
      if (isPage(res)) { const ap = pickPrn(list, a4Want(res)); if (ap) o = Object.assign({}, o, { printer: ap }); }
      else if (res && res.roll && !o.printer && RD.devPrinter("Cashier")) { const cp0 = pickPrn(list, RD.devPrinter("Cashier")); if (cp0) o = Object.assign({}, o, { printer: cp0 }); }
      let cur = o.printer && list.indexOf(o.printer) >= 0 ? o.printer : (pr.def || list[0] || "");
      const cp = Math.max(0, Math.min(n - 1, o.current || 0));
      const H = res.roll ? Math.max.apply(null, res.pages.map(p => p.h)) : res.h;
      const collIco = on => on
        ? `<svg width="66" height="34" viewBox="0 0 66 34"><g font-size="7" font-family="Segoe UI,Arial" text-anchor="middle">${[0, 22, 44].map((x, k) => `<rect x="${x + 5}" y="2" width="13" height="17" fill="#fff" stroke="#555"/><rect x="${x + 1}" y="6" width="13" height="17" fill="#fff" stroke="#555"/><text x="${x + 7.5}" y="18">1</text><text x="${x + 11.5}" y="11">2</text>`).join("")}</g></svg>`
        : `<svg width="66" height="34" viewBox="0 0 66 34"><g font-size="7" font-family="Segoe UI,Arial" text-anchor="middle">${[[0, 1], [22, 2], [44, 3]].map(([x, k]) => `<rect x="${x + 5}" y="2" width="13" height="17" fill="#fff" stroke="#555"/><rect x="${x + 1}" y="6" width="13" height="17" fill="#fff" stroke="#555"/><text x="${x + 7.5}" y="18">${k}</text><text x="${x + 11.5}" y="11">${k}</text>`).join("")}</g></svg>`;
      const ov = document.createElement("div"); ov.className = "rdpd-ov";
      ov.innerHTML = `<div class="dxpd" dir="ltr" role="dialog" aria-label="Print">
        <div class="dxpd-t"><span class="dxpd-ic"><svg width="16" height="16" viewBox="0 0 16 16"><rect x="4" y="1.5" width="8" height="4" fill="#fff" stroke="#4a6fa5"/><rect x="1.5" y="5.5" width="13" height="6" rx="1" fill="#6d8fc3" stroke="#3d5f93"/><rect x="4" y="9.5" width="8" height="5" fill="#fff" stroke="#4a6fa5"/></svg></span><b>Print</b><button type="button" class="dxpd-x" title="Close">✕</button></div>
        <div class="dxpd-b">
          <fieldset class="dxpd-g"><legend>Printer</legend>
            <div class="dxpd-r"><label class="dxpd-l" for="dxpd-name">Name:</label><select id="dxpd-name" class="dxpd-name">${list.map(x => `<option${x === cur ? " selected" : ""}>${esc(x)}</option>`).join("") || "<option>(no printers)</option>"}</select><button type="button" class="dxpd-btn dxpd-pref">Preferences</button></div>
            <div class="dxpd-r"><span class="dxpd-l">Status:</span><span class="dxpd-v dxpd-st"><i class="dxpd-dot"></i><span>…</span></span></div>
            <div class="dxpd-r"><span class="dxpd-l">Location:</span><span class="dxpd-v dxpd-loc"></span></div>
            <div class="dxpd-r"><span class="dxpd-l">Comment:</span><span class="dxpd-v dxpd-com"></span></div>
            <div class="dxpd-r"><span class="dxpd-l">Document(s) in queue:</span><span class="dxpd-v dxpd-q">0</span></div>
            <div class="dxpd-r dxpd-file"><label class="dxpd-ck"><input type="checkbox" class="dxpd-tofile"> Print to file</label></div>
            <div class="dxpd-r"><span class="dxpd-l">File path:</span><input type="text" class="dxpd-path" disabled><button type="button" class="dxpd-btn dxpd-dots" disabled>...</button></div>
          </fieldset>
          <div class="dxpd-2">
            <fieldset class="dxpd-g"><legend>Page range</legend>
              <label class="dxpd-rb"><input type="radio" name="dxpd-rg" value="all" checked> All</label>
              <label class="dxpd-rb"><input type="radio" name="dxpd-rg" value="cur"> Current page</label>
              <label class="dxpd-rb dis"><input type="radio" name="dxpd-rg" value="sel" disabled> Selection</label>
              <div class="dxpd-rb"><label><input type="radio" name="dxpd-rg" value="pages"> Pages:</label><input type="text" class="dxpd-pages" placeholder="1-${n}"></div>
              <div class="dxpd-hint">Enter page numbers and/or page ranges separated by commas. For example: 1,3,5-12</div>
            </fieldset>
            <fieldset class="dxpd-g"><legend>Copies</legend>
              <div class="dxpd-r"><span class="dxpd-l">Number of copies:</span><span class="dxpd-spin"><input type="text" class="dxpd-cop" value="${Math.max(1, o.copies || 1)}"><span class="dxpd-sb"><button type="button" data-d="1">▲</button><button type="button" data-d="-1">▼</button></span></span></div>
              <div class="dxpd-r dxpd-coll"><span class="dxpd-cico">${collIco(true)}</span><label class="dxpd-ck"><input type="checkbox" class="dxpd-collate" checked> Collate</label></div>
            </fieldset>
          </div>
          <div class="dxpd-r dxpd-bot"><label class="dxpd-ck"><input type="checkbox" class="dxpd-dup"> Print on both sides</label><span class="dxpd-sp"></span><span class="dxpd-l">Paper source:</span><select class="dxpd-src"><option>Sélection automatique</option></select></div>
          <div class="dxpd-info">${Math.round(res.w * 10) / 10} × ${Math.round(H * 10) / 10} mm · ${n} page${n > 1 ? "s" : ""}${o.title ? " · " + esc(o.title) : ""}</div>
        </div>
        <div class="dxpd-f"><button type="button" class="dxpd-btn dxpd-ok">Print</button><button type="button" class="dxpd-btn dxpd-no">Cancel</button></div></div>`;
      document.body.appendChild(ov);
      const $ = q => ov.querySelector(q);
      const close = r => { window.removeEventListener("keydown", key, true); ov.remove(); resolve(r); };
      let infoSeq = 0, dupInit = false, dupMode = "";   /* الوجهين: كما في إعدادات الطابعة (Preferences) — لا يُفرض «وجه واحد» إلا إذا غيّره المستخدم */
      const info = () => {
        const my = ++infoSeq;
        $(".dxpd-st span").textContent = "…"; $(".dxpd-st").className = "dxpd-v dxpd-st";
        call("print.info", { printer: cur }).then(r => {
          if (my !== infoSeq || !r) return;
          $(".dxpd-st span").textContent = r.status || "";
          $(".dxpd-st").className = "dxpd-v dxpd-st " + (r.ready ? "is-ok" : "is-bad");
          $(".dxpd-loc").textContent = r.location || ""; $(".dxpd-com").textContent = r.comment || ""; $(".dxpd-q").textContent = String(r.jobs || 0);
          const src = $(".dxpd-src"), ss = (r.sources || []).length ? r.sources : ["Sélection automatique"];
          src.innerHTML = ss.map(x => `<option>${esc(x)}</option>`).join("");
          const dup = $(".dxpd-dup"); dup.disabled = !r.duplex; dup.checked = !!r.duplex && !!r.dupMode && r.dupMode !== "none"; dupInit = dup.checked; dupMode = r.dupMode || ""; dup.parentNode.classList.toggle("dis", !r.duplex);
        }).catch(() => { if (my !== infoSeq) return; $(".dxpd-st span").textContent = "The printer is ready."; $(".dxpd-st").className = "dxpd-v dxpd-st is-ok"; $(".dxpd-dup").disabled = true; $(".dxpd-dup").parentNode.classList.add("dis"); });
      };
      info();
      $(".dxpd-name").onchange = e => { cur = e.target.value; info(); };
      $(".dxpd-pref").onclick = () => call("print.prefs", { printer: cur }).then(info).catch(e => T("Preferences: " + ((e && e.message) || e), "e"));
      const tf = $(".dxpd-tofile");
      tf.onchange = () => { $(".dxpd-path").disabled = $(".dxpd-dots").disabled = !tf.checked; if (tf.checked && !$(".dxpd-path").value) $(".dxpd-dots").click(); };
      $(".dxpd-dots").onclick = () => call("print.browse", { name: (o.title || "ANOUER").replace(/[\\/:*?"<>|]/g, "_") + ".prn" }).then(r => { if (r && r.ok) $(".dxpd-path").value = r.path; else if (!$(".dxpd-path").value) { tf.checked = false; tf.onchange(); } }).catch(() => { });
      const cop = $(".dxpd-cop"), clamp = v => Math.max(1, Math.min(99, Math.round(+v || 1)));
      ov.querySelectorAll(".dxpd-sb button").forEach(b => { b.onclick = () => { cop.value = clamp(+cop.value + +b.dataset.d); }; });
      cop.onchange = () => { cop.value = clamp(cop.value); };
      cop.onkeydown = e => { if (e.key === "ArrowUp" || e.key === "ArrowDown") { e.preventDefault(); cop.value = clamp(+cop.value + (e.key === "ArrowUp" ? 1 : -1)); } };
      $(".dxpd-collate").onchange = e => { $(".dxpd-cico").innerHTML = collIco(e.target.checked); };
      $(".dxpd-pages").onfocus = () => { ov.querySelector('input[value="pages"]').checked = true; };
      const go = () => {
        const rg = (ov.querySelector('input[name="dxpd-rg"]:checked') || {}).value || "all";
        let pages = null;
        if (rg === "cur") pages = [cp];
        else if (rg === "pages") {
          pages = RD.parsePages($(".dxpd-pages").value, n);
          if (!pages || !pages.length) { $(".dxpd-pages").classList.add("err"); $(".dxpd-pages").focus(); return; }
        }
        if (tf.checked && !$(".dxpd-path").value.trim()) { $(".dxpd-path").classList.add("err"); return; }
        const opt = Object.assign({}, o, { dialog: false, printer: cur, copies: clamp(cop.value), collate: $(".dxpd-collate").checked, pageList: pages,
          duplex: $(".dxpd-dup").disabled || $(".dxpd-dup").checked === dupInit ? "" : ($(".dxpd-dup").checked ? (dupMode === "short" ? "short" : "long") : "none"), source: $(".dxpd-src").selectedIndex > 0 ? $(".dxpd-src").value : "",
          toFile: tf.checked, file: $(".dxpd-path").value.trim() });
        close({ ok: true });
        if (typeof o.onPick === "function" && !tf.checked) { try { o.onPick(cur); } catch (e) { } }
        RD.printResult(res, opt).catch(() => { });
      };
      const key = e => {
        if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); close({ ok: false, cancelled: true }); }
        else if (e.key === "Enter" && e.target.tagName !== "BUTTON" && e.target.tagName !== "SELECT") { e.preventDefault(); e.stopImmediatePropagation(); go(); }
        else e.stopPropagation();
      };
      window.addEventListener("keydown", key, true);
      $(".dxpd-x").onclick = $(".dxpd-no").onclick = () => close({ ok: false, cancelled: true });
      $(".dxpd-ok").onclick = go;
      // سحب النافذة من شريط العنوان
      const dlg = $(".dxpd"), bar = $(".dxpd-t");
      bar.onpointerdown = e => {
        if (e.target.closest("button")) return;
        const r = dlg.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top;
        dlg.style.position = "fixed"; dlg.style.margin = "0"; dlg.style.left = r.left + "px"; dlg.style.top = r.top + "px";
        const mv = ev => { dlg.style.left = Math.max(0, ev.clientX - dx) + "px"; dlg.style.top = Math.max(0, ev.clientY - dy) + "px"; };
        const up = () => { window.removeEventListener("pointermove", mv); window.removeEventListener("pointerup", up); };
        window.addEventListener("pointermove", mv); window.addEventListener("pointerup", up);
      };
      setTimeout(() => { try { $(".dxpd-ok").focus(); } catch (e) { } }, 30);
    }));
  };
  /* طباعة مستند ناتج: direct = مباشرة على طابعة التصميم ، وإلا نافذة الطباعة
     o: {printer, copies, collate, pageList, duplex, source, toFile, file, title, dialog} */
  RD.printResult = function (res, o) {
    o = o || {};
    if (!HOST()) { RD.printDialog(RD.docHTML(res, o.title)); return Promise.resolve({ ok: true, dialog: true }); }
    if (res && res.roll && !o.printer && !o.__pp && !o.dialog && RD.devPrinter("Cashier")) return RD.printers().then(pr => pickPrn((pr && pr.printers) || [], RD.devPrinter("Cashier"))).catch(() => "").then(cp => RD.printResult(res, Object.assign({}, o, { __pp: 1 }, cp ? { printer: cp } : {})));
    if (isPage(res) && !o.__pp && !o.dialog) return RD.pagePrinter(res).then(ap => RD.printResult(res, Object.assign({}, o, { __pp: 1 }, ap ? { printer: ap } : {})));
    if (o.dialog) return RD.hostPrintDialog(res, o);
    const copies = o.copies || 1;
    const done = r => { T((o.toFile ? "تمت الطباعة إلى الملف" : "تمت الطباعة" + (r && r.printer ? " على «" + r.printer + "»" : "")) + (copies > 1 ? " (" + copies + " نسخ)" : ""), "s"); return r; };
    const legacy = () => {   // إصدار قديم من البرنامج بدون print.image
      const sub = o.pageList ? Object.assign({}, res, { pages: o.pageList.map(i => res.pages[i]).filter(Boolean) }) : res;
      const html = RD.docHTML(sub, o.title), H = sub.roll ? Math.max.apply(null, sub.pages.map(p => p.h)) : sub.h;
      return call("print.html", { html, printer: o.printer || "", copies, w: sub.w, h: H, landscape: false }).then(done).catch(e => {
        const msg = (e && e.message) || "";
        if (/mock:|غير معروف|unknown|Unknown action/i.test(msg)) { RD.printDialog(html); return { ok: true, dialog: true }; }
        T("لم تتم الطباعة: " + msg, "e"); throw e;
      });
    };
    if (RD.noImagePrint) return legacy();
    return RD.rasterize(res, { pages: o.pageList }).catch(e => { console.error("rasterize", e); return null; }).then(pages => !pages ? legacy() : call("print.image", {
      pages, printer: o.printer || "", copies, collate: o.collate !== false, duplex: o.duplex || "", source: o.source || "", toFile: !!o.toFile, file: o.file || "", title: o.title || "ANOUER", fit: !!o.fit, paper: o.paper || ""
    }).then(done)).catch(e => {
      const msg = (e && e.message) || String(e || "");
      if (/mock:|غير معروف|unknown|Unknown action|not supported/i.test(msg)) { RD.noImagePrint = true; return legacy(); }
      T("لم تتم الطباعة: " + msg, "e"); throw e;
    });
  };
  RD.exportPdf = function (res, name) {
    const html = RD.docHTML(res, name);
    if (!HOST()) { RD.printDialog(html); return Promise.resolve({ ok: true, dialog: true }); }
    const H = res.roll ? Math.max.apply(null, res.pages.map(p => p.h)) : res.h;
    return call("print.pdf", { html, w: res.w, h: H, fileName: name || "ANOUER" }).then(r => { if (r && r.ok) T("تم حفظ PDF في: " + r.path, "s"); else T("تعذّر إنشاء PDF", "e"); return r; })
      .catch(e => { const msg = (e && e.message) || ""; if (/mock:|unknown/i.test(msg)) { RD.printDialog(html); return { ok: true, dialog: true }; } T("تعذّر إنشاء PDF: " + msg, "e"); throw e; });
  };
  /* الواجهة العامة: طباعة تعامل بالتصميم الافتراضي
     o: {tx, data, mode:"direct"|"preview"|"dialog", item (تصميم محدد), title} */
  /* ترتيب التصاميم (السحب في نافذة الاختيار وفي «تصميم التقارير»): ids بالترتيب الجديد */
  RD.reorder = function (ids) {
    const x = S.idx; if (!x || !ids || ids.length < 2) return Promise.resolve();
    const set = new Set(ids), pos = []; x.items.forEach((it, i) => { if (set.has(it.id)) pos.push(i); });
    const byId = {}; x.items.forEach(it => { byId[it.id] = it; });
    const list = ids.map(id => byId[id]).filter(Boolean);
    if (list.length !== pos.length) return Promise.resolve();
    pos.forEach((p, k) => { x.items[p] = list[k]; });
    return RD.saveIdx();
  };
  /* التصاميم المتاحة لتعامل (النموذج النشط ثم Default Template) */
  RD.candidates = function (tx, kind, branch) {
    kind = kind || "tx";
    return RD.load().then(idx => {
      const ok = i => (i.kind || "tx") === kind && (kind === "bc" || i.tx === tx) && (!i.branch || !branch || i.branch === branch);
      let list = idx.items.filter(i => ok(i) && i.tpl === idx.tpl);
      if (!list.length) list = idx.items.filter(i => ok(i) && i.tpl === "Default Template");
      if (!list.length) list = idx.items.filter(ok);
      return list;
    });
  };
  /* ✦ تفضيلات «اختيار الوصل» لكل تعامل (محفوظة على هذا الجهاز):
     fav: حتى تصميمين مفضّلين ★ يظهران وحدهما في نافذة الاختيار (سرعة) — f6: تصميم «حفظ سريع F6» */
  const RPK = "anouer.rcpt.pref";
  RD.rcptPref = {
    all() { try { return JSON.parse(localStorage.getItem(RPK) || "{}") || {}; } catch (e) { return {}; } },
    get(tx) { const p = RD.rcptPref.all()[String(tx || "مبيعات").replace(/^مرتجع /, "")] || {}; return { fav: Array.isArray(p.fav) ? p.fav.slice(0, 2) : [], f6: p.f6 || "" }; },
    set(tx, v) { const a = RD.rcptPref.all(), k = String(tx || "مبيعات").replace(/^مرتجع /, ""); a[k] = Object.assign(RD.rcptPref.get(tx), v); try { localStorage.setItem(RPK, JSON.stringify(a)); } catch (e) { } return a[k]; }
  };
  /* F6: التصميم المختار ⚡ — وإلا أول إيصال 80 مم (استوديو الإيصال ثم تصاميم الكاشير) */
  RD.f6Item = function (list, tx) {
    list = list || []; const id = RD.rcptPref.get(tx).f6;
    const rc = list.filter(x => x.virtual && x._A && !x._A.a4);   /* «استوديو الإيصال» (الطابعة الحرارية) */
    return list.find(x => x.id === id)
      || rc.find(x => x.use) || rc.find(x => /80/.test((x.name || "") + " " + ((x._d && x._d.w) || ""))) || rc[0]
      || list.find(x => !x.virtual && /cashier|كاشير|80/i.test((x.paper || "") + " " + (x.name || "")))
      || list.find(x => x.def || x.use) || list[0] || null;
  };
  /* ملخص الدفع في رأس نافذة «اختيار الوصل» */
  RD.rcptSummary = function (data) {
    const h = (data && data.header) || {}, r2 = v => Math.round((+v || 0) * 100) / 100;
    const total = r2(h["Net Amount"]), paid = r2(h.Paid), rest = Math.max(0, r2(total - paid));
    return { cust: h["Customer Name"] || "", no: h.Number || "", total, paid, rest, st: paid >= total - 0.004 && total > 0 ? "cash" : paid > 0.004 ? "part" : "none" };
  };
  /* اختيار التصميم للطباعة مثل DEXEF: الافتراضي ✔ ← تصميم وحيد ← نافذة «اختر التصميم» */
  RD.pickDesign = function (tx, kind, o) {
    o = o || {};
    return RD.candidates(tx, kind, RD.branchName()).then(list => {
      if (o.f6 && list.length) return { item: RD.f6Item(list, tx), mode: "direct" };
      /* o.choose (اختيار الوصل بعد دفع العميل): النافذة دائماً حتى مع الافتراضى */
      if (o.choose && list.length && typeof RD.chooseDesign === "function") return RD.chooseDesign(list, Object.assign({ tx }, o));
      const def = list.find(i => i.def);
      if (def) return { item: def };
      if (list.length <= 1) return { item: list[0] || null };
      if (typeof RD.chooseDesign !== "function") return { item: list[0] };
      return RD.chooseDesign(list, Object.assign({ tx }, o));
    });
  };
  RD.printTx = function (o) {
    o = o || {};
    const pick = o.item ? Promise.resolve({ item: o.item }) : RD.pickDesign(o.tx, o.kind, { data: o.data, title: o.title, choose: o.choose, summary: o.summary, f6: o.f6, review: o.review });
    return Promise.all([RD.company(), pick]).then(([co, pk]) => {
      if (!pk || pk.cancel) return { ok: false, cancelled: true };
      const it = pk.item, mode = pk.mode || o.mode;
      return (it ? RD.getDesign(it) : Promise.resolve(null)).then(d => {
        if (!d) d = RD.fallbackDesign(o.tx);
        const data = Object.assign({ company: co }, o.data || {});
        if (mode === "preview" && window.ANOUER_RDP) { ANOUER_RDP.open(d, data, { item: it, title: o.title || d.name }); return { ok: true, preview: true }; }
        const res = RD.render(d, data);
        return RD.printResult(res, { printer: it && it.printer, copies: (it && it.copies) || 1, dialog: mode === "dialog", title: o.title || d.name });
      });
    });
  };
})();
