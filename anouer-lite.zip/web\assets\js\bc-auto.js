/* ANOUER — «AUTO ✨» تيكت ذكي تلقائي (2026)
   تصميم واحد يعمل لكل الأصناف بدون أي إعداد — تيكت واحد لكل صنف، بنفس مقاس تيكت DEXEF بالضبط:
     • صنف بعدة وحدات:  اسم الصنف ← سعر القطعة ← سعر «الوحدة المختارة في السطر، أو أكبر وحدة» (مع عدد القطع) ← سعر القطعة داخل الوحدة الكبرى (مع نسبة التوفير)
     • صنف بوحدة واحدة: اسم الصنف ← السعر ← سعر 5 ومافوق (إن وُجد)
   الطباعة مباشرة على طابعة تصميم الباركود الافتراضي (مثل DEXEF) — صورة أبيض/أسود حادة بمقاس الملصق الحقيقي. */
(function () {
  "use strict";
  if (window.__BCA) return;
  const E = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const RD = () => window.ANOUER_RD, B = () => window.__BCP || {};
  const r1 = v => Math.round(v * 100) / 100;
  const fac = u => +(u && u.factor) || 1;
  const NUMF = "'Arial Black','Segoe UI Black','Segoe UI',Arial,sans-serif", ARF = "'Droid Arabic Kufi','Segoe UI',Tahoma,Arial,sans-serif";
  const money = v => { const n = Math.round((+v || 0) * 100) / 100; return n.toLocaleString("en-US", { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 }); };
  const lvName = id => { try { const n = window.ANOUER_PL && ANOUER_PL.nameOf(id); if (n) return n; } catch (e) { } return id === "6" ? "سعر 5 ومافوق" : "السعر"; };

  /* ---------- المقاس: نفس مقاس تيكت DEXEF (التصميم الافتراضي / آخر تصميم مستعمل) ---------- */
  const DEF = { w: 59.9, h: 39.9, printer: "", from: "" };
  let REF = null;
  async function ref() {
    if (REF) return REF;
    const R = RD(); let L = [];
    try { L = R && R.labelDesigns ? await R.labelDesigns() : []; } catch (e) { L = []; }
    const rec = (() => { try { return JSON.parse(localStorage.getItem("bcp.recent") || "[]") || []; } catch (e) { return []; } })().filter(k => /^rd:/.test(k)).map(k => k.slice(3));
    const cand = [L.find(i => i.def)].concat(rec.map(id => L.find(i => i.id === id))).concat(L).filter(Boolean);
    for (const it of cand.slice(0, 6)) {
      try {
        const d = await R.getDesign(it); const lab = d && (d.label && d.label.w ? d.label : null);
        if (lab && lab.w > 15 && lab.h > 10 && (d.paper !== "A4")) { REF = { w: r1(lab.w), h: r1(lab.h), printer: it.printer || "", from: String(+(it.dexId || it.num) || "") }; return REF; }
      } catch (e) { }
    }
    REF = Object.assign({}, DEF); return REF;
  }

  /* ---------- البيانات ---------- */
  /* «خصم الكمية» (الإضافات): سعر الوحدة بعد الخصم لكل شريحة «N ومافوق» — أكبر الشرائح خصماً آخراً */
  /* + «خصومات الأصناف» النشطة (خصم على كل كمية): بطاقة «عرض» من قطعة واحدة ، وتُطرح أيضاً من أسعار شرائح الكمية (مثل الفاتورة) */
  function qdOf(p, base) {
    let T = []; try { T = window.__qdTiers ? __qdTiers(p) : []; } catch (e) { T = []; }
    if (!(base > 0)) return [];
    let z = null; try { z = window.__pzProd ? __pzProd(p, base) : null; } catch (e) { z = null; }
    const zd = z && z.d > 0 ? z.d : 0, out = [];
    if (zd) out.push({ from: 1, price: Math.max(0, base - zd), pct: Math.round(zd / base * 100), name: z.name, promo: 1 });
    T.forEach(t => { const d = (t.kind === "v" ? t.val : base * t.val / 100) + zd, pr = Math.max(0, base - d); out.push({ from: t.from, price: pr, pct: Math.round(d / base * 100), name: t.name }); });
    return out.filter(t => t.price < base - .004).sort((a, b) => a.from - b.from || b.price - a.price)
      .filter((t, i, l) => !l.some((u, j) => j !== i && u.from === t.from && (u.price < t.price || (u.price === t.price && j < i))));
  }
  function info(j) {
    const f = B().findByCode ? B().findByCode(j.code) : null, p = (f && f.p) || null;
    const us = p && B().unitsOf ? B().unitsOf(p) : [];
    const pr = (u, lv) => { try { return +B().priceOf(p, u, lv) || 0; } catch (e) { return +u.price || 0; } };
    const name = String(j.name || (p && p.name) || "").trim();
    if (!p || !us.length) return { name, single: 1, price: +j.price || 0, p5: 0 };
    /* الوحدة الكبرى = الوحدة المختارة في السطر (باطة / كرتونة …) إن كانت أكبر من القطعة، وإلا أكبر وحدة في الصنف */
    const piece = us.reduce((m, u) => fac(u) < fac(m) ? u : m, us[0]), ch = j.unit ? us.find(x => x.name === j.unit) : null;
    const big = ch && fac(ch) > fac(piece) ? ch : us.reduce((m, u) => fac(u) > fac(m) ? u : m, us[0]);
    if (us.length > 1 && fac(big) > fac(piece)) {
      const pp = pr(piece, "1"), bp = pr(big, "1"), n = fac(big) / fac(piece), inP = n ? bp / n : 0;
      return { name, single: 0, piece: piece.name || "قطعة", big: big.name || "كرتونة", pp, bp, n, inP, save: pp > 0 && inP > 0 ? Math.round((1 - inP / pp) * 100) : 0, qd: qdOf(p, pp) };
    }
    const u = us.find(x => x.name === j.unit) || piece;
    const price = pr(u, "1") || +j.price || 0, p5 = pr(u, "6");
    return { name, single: 1, unit: u.name, price, p5: p5 > 0 && p5 < price - .004 ? p5 : 0, qd: qdOf(p, price) };
  }

  /* ---------- الرسم ---------- */
  function fit(txt, w, h, fs, ff, b) {
    try { const R = RD(); if (R && R.fitText) { const f = R.fitText({ w, h }, { fs, ff, b: b ? 1 : 0, w: b ? 800 : 600, pad: [0, 0, 0, 0] }, txt); if (f) return f; } } catch (e) { }
    return { fs, t: String(txt), lh: 1.1 };
  }
  const T = (x, y, w, h, txt, fs, o) => {
    o = o || {}; const f = fit(txt, w, h, fs, o.ff || ARF, o.b !== 0);
    return `<div style="position:absolute;left:${r1(x)}mm;top:${r1(y)}mm;width:${r1(w)}mm;height:${r1(h)}mm;display:flex;align-items:center;justify-content:${o.al === "l" ? "flex-start" : o.al === "r" ? "flex-end" : "center"};overflow:hidden;${o.css || ""}"><span style="display:block;width:100%;text-align:${o.al === "l" ? "left" : o.al === "r" ? "right" : "center"};white-space:pre;font-family:${o.ff || ARF};font-weight:${o.b === 0 ? 600 : 800};font-size:${f.fs}pt;line-height:${f.lh};unicode-bidi:plaintext;${o.st || ""}">${E(f.t)}</span></div>`;
  };
  /* شارة السعر: «سعر» + اسم الوحدة كما هو مسجّل بالضبط (كرتونة 14حبة ، Batte 12Units …) — كاملاً دائماً:
     سطر واحد إن كان واضحاً ، وإلا سطران: البادئة فوق واسم الوحدة تحتها بخط أعرض */
  function TAG(x, y, w, h, pre, unit, fs, st) {
    const one = pre + (unit ? " " + unit : ""), f1 = fit(one, w, h, fs, ARF, 1);
    const sp = (yy, hh, t, f, wt) => `<div style="position:absolute;left:${r1(x)}mm;top:${r1(yy)}mm;width:${r1(w)}mm;height:${r1(hh)}mm;display:flex;align-items:center;justify-content:center;overflow:hidden"><span style="display:block;width:100%;text-align:center;white-space:pre;font-family:${ARF};font-weight:${wt};font-size:${f.fs}pt;line-height:${/\n/.test(f.t) ? f.lh : 1.05};unicode-bidi:plaintext;${st}">${E(f.t)}</span></div>`;
    if (unit && !/\n/.test(f1.t)) {
      const hp = h * .4, hu = h * .52, fa = fit(pre, w, hp, fs * .8, ARF, 1), fb = fit(unit, w, hu, fs, ARF, 1);
      if (!/\n/.test(fa.t) && !/\n/.test(fb.t) && Math.min(fa.fs / .8, fb.fs) > f1.fs * 1.15) return sp(y + h * .05, hp, pre, fa, 700) + sp(y + h * .43, hu, unit, fb, 800);
    }
    if (unit && /\n/.test(f1.t)) {   // سطران من محرك الملاءمة: نفرض التقسيم الصحيح (البادئة / اسم الوحدة) لا في منتصف اسم الوحدة
      const hp = h * .4, hu = h * .52, fa = fit(pre, w, hp, fs * .8, ARF, 1), fb = fit(unit, w, hu, fs, ARF, 1);
      if (!/\n/.test(fb.t)) return sp(y + h * .05, hp, pre, fa, 700) + sp(y + h * .43, hu, unit, fb, 800);
    }
    return sp(y, h, one, f1, 800);
  }
  function page(j, sz, co) {
    const I = info(j), W = sz.w, H = sz.h, k = Math.min(W / 59.9, H / 39.9), pad = 1.1 * k;
    let h = "";
    /* الإطار + الاسم */
    h += `<div style="position:absolute;left:${r1(pad * .55)}mm;top:${r1(pad * .55)}mm;right:${r1(pad * .55)}mm;bottom:${r1(pad * .55)}mm;border:${r1(.32 * k)}mm solid #000;border-radius:${r1(1.6 * k)}mm"></div>`;
    const nameH = 7.4 * k, iw = W - pad * 2 - 1.2 * k;
    h += T(pad + .6 * k, pad + .25 * k, iw, nameH, I.name || "—", 10.5 * k, { b: 1 });
    const sepY = pad + nameH + .55 * k;
    h += `<div style="position:absolute;left:${r1(pad + 3 * k)}mm;right:${r1(pad + 3 * k)}mm;top:${r1(sepY)}mm;height:0;border-top:${r1(.28 * k)}mm solid #000"></div><div style="position:absolute;left:50%;top:${r1(sepY - .75 * k)}mm;width:${r1(1.5 * k)}mm;height:${r1(1.5 * k)}mm;margin-left:${r1(-.75 * k)}mm;background:#000;transform:rotate(45deg)"></div>`;
    /* التذييل */
    const fH = 2.6 * k, fY = H - pad - fH - .15 * k, cn = String((co && (co["Company Name"] || co.Name)) || "ANOUER").trim();
    h += T(W - pad - 2 * k - iw * .6, fY, iw * .6, fH, cn, 5.2 * k, { al: "r", b: 0 });
    h += T(pad + 2 * k, fY, iw * .32, fH, new Date().toLocaleDateString("en-GB"), 5 * k, { al: "l", b: 0, ff: "'Segoe UI',Arial,sans-serif" });
    /* الأسطر */
    const Q = (I.qd || []).slice(-3), sH = Q.length ? 6.8 * k : 0;   /* شريط «خصم الكمية»: أكبر 3 شرائح */
    const top = sepY + 1.1 * k, bot = fY - .5 * k - (sH ? sH + .55 * k : 0), rows = [];
    if (!I.single) {
      rows.push({ pre: "سعر", u: I.piece, v: money(I.pp), main: 1 });
      rows.push({ pre: "سعر", u: I.big, v: money(I.bp), chip: "×" + (Math.round(I.n * 1000) / 1000) });
      rows.push({ pre: "سعر " + (/^(قطعة|قطعه)$/.test(I.piece) ? "القطعة" : I.piece) + " داخل", u: I.big, v: money(I.inP), out: 1, chip: I.save >= 1 ? "−" + I.save + "%" : "" });
    } else {
      rows.push({ pre: I.unit ? "سعر" : "السعر", u: I.unit || "", v: money(I.price), main: 1 });
      /* سعر 5 ومافوق: يظهر دائماً — بالسعر إن وُجد ، وإلا «لا يوجد سعر حالياً» */
      if (I.p5) rows.push({ pre: lvName("6"), u: "", v: money(I.p5), out: 1, chip: I.price > 0 && I.p5 < I.price ? "−" + Math.round((1 - I.p5 / I.price) * 100) + "%" : "" });
      else if (!Q.length) rows.push({ pre: lvName("6"), u: "", none: 1, out: 1 });
    }
    const gap = .6 * k, rh = (bot - top - gap * (rows.length - 1)) / rows.length, tagW = (W - pad * 2) * .47, x0 = pad + .6 * k, xr = W - pad - .6 * k;
    rows.forEach((r, i) => {
      const y = top + i * (rh + gap), th = Math.min(rh, (rows.length === 1 ? 9.5 : 7.8) * k);
      /* الشارة (يمين) */
      const tx = xr - tagW, ty = y + (rh - th) / 2;
      h += `<div style="position:absolute;left:${r1(tx)}mm;top:${r1(ty)}mm;width:${r1(tagW)}mm;height:${r1(th)}mm;border-radius:${r1(1.2 * k)}mm;${r.out ? `background:#fff;border:${r1(.35 * k)}mm ${r.none ? "dashed" : "solid"} #000;box-sizing:border-box` : "background:#000"}"></div>`;
      h += TAG(tx + .9 * k, ty, tagW - 1.8 * k, th, r.pre, r.u, (r.main ? 10 : 8.5) * k, r.out ? "color:#000" : "color:#fff");
      /* السعر (يسار) + الشارة الصغيرة (العدد / التوفير) */
      const pw = tx - x0 - 1 * k, chipW = r.chip ? Math.min(9.5 * k, pw * .3) : 0, fs = rows.length === 1 ? 30 * k : r.main ? 21 * k : 15 * k;
      if (r.none) {   // لا يوجد سعر: إطار متقطع + أيقونة ساعة صغيرة + نص واضح
        const bh = Math.min(rh * .78, 7.2 * k), by = y + (rh - bh) / 2, ic = bh * .52, bw = pw - .4 * k;
        h += `<div style="position:absolute;left:${r1(x0)}mm;top:${r1(by)}mm;width:${r1(bw)}mm;height:${r1(bh)}mm;border:${r1(.3 * k)}mm dashed #000;border-radius:${r1(bh / 2)}mm;box-sizing:border-box;background:#fff"></div>`;
        h += `<svg style="position:absolute;left:${r1(x0 + bw - ic - 1.4 * k)}mm;top:${r1(by + (bh - ic) / 2)}mm;width:${r1(ic)}mm;height:${r1(ic)}mm" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="2.6" stroke-linecap="round"><circle cx="12" cy="12" r="9.5" fill="#fff"/><path d="M12 6.8V12l3.6 2.2"/></svg>`;
        h += T(x0 + 1.2 * k, by, bw - ic - 3.4 * k, bh, "لا يوجد سعر حالياً", 8 * k, { b: 1 });
      } else
      h += T(x0 + chipW + (chipW ? .6 * k : 0), y, pw - chipW - (chipW ? .6 * k : 0), rh, r.v, fs, { ff: NUMF, b: 1, st: "letter-spacing:-.1mm" });
      if (r.chip) { const ch = Math.min(rh * .62, 4.4 * k); h += `<div style="position:absolute;left:${r1(x0)}mm;top:${r1(y + (rh - ch) / 2)}mm;width:${r1(chipW)}mm;height:${r1(ch)}mm;border-radius:${r1(ch / 2)}mm;border:${r1(.3 * k)}mm solid #000;box-sizing:border-box;background:#fff"></div>` + T(x0 + .3 * k, y + (rh - ch) / 2, chipW - .6 * k, ch, r.chip, 7 * k, { ff: NUMF, b: 1 }); }
    });
    if (Q.length) h += qdStrip(Q, x0, xr, bot + .55 * k, sH, k);
    return `<div class="rdp" style="position:relative;width:${W}mm;height:${H}mm;overflow:hidden;background:#fff;color:#000;direction:ltr;-webkit-print-color-adjust:exact;print-color-adjust:exact">${h}</div>`;
  }

  /* ================= «القاطو والقوفريط»: تيكتان في «بالصنف» — تيكت القطعة + تيكت الكرتونة =================
     يُفعَّل وحده إذا كان في اسم الصنف «قاطو» أو «قوفريط» (وأشكال كتابتهما) وللصنف وحدة كبرى (كرتونة / باطة …) */
  const SPC = /قاطو|قاتو|ڨاطو|gateau|gâteau|قوفريط|قفريط|قوفريت|ڨوفريط|gaufrett?e|wafer/i;
  const kindOf = n => /قوفريط|قفريط|قوفريت|ڨوفريط|gaufrett?e|wafer/i.test(n) ? "w" : "c";
  const ICO = {
    w: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.9"><rect x="2.5" y="6" width="19" height="12" rx="2"/><path d="M7.2 6v12M12 6v12M16.8 6v12M2.5 12h19"/></svg>',
    c: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.9" stroke-linejoin="round"><path d="M5 11h14l-1.6 9.5H6.6z"/><path d="M5 11c0-3.4 3-5.6 7-5.6s7 2.2 7 5.6"/><path d="M9.3 11.3l1 9M14.7 11.3l-1 9"/><circle cx="12" cy="3.3" r="1.4" fill="#fff"/></svg>',
    box: c => `<svg viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="2" stroke-linejoin="round"><path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5z"/><path d="M3 7.5 12 12l9-4.5M12 12v9"/></svg>`
  };
  const bil = u => { u = String(u || "").trim(); return /^[؀-ۿ]/.test(u) ? (/^ال/.test(u) ? "بـ" + u : "بال" + u) : "بـ " + u; };
  const pieceWord = u => /^(قطعة|قطعه)$/.test(String(u || "").trim()) ? "قطعة" : String(u || "قطعة");
  function pairOf(j) {
    try { if (B().mode !== "item") return null; } catch (e) { return null; }
    const I = info(j); if (I.single || !(I.n > 1) || !SPC.test(I.name || "")) return null;
    return I;
  }
  /* الإطار + أيقونة الصنف + الاسم + الفاصل + التذييل (مشترك بين التيكتين) */
  function shell(I, W, H, k, pad, co) {
    const kd = kindOf(I.name), d = 6.4 * k, ix = pad + .7 * k, iy = pad + .55 * k;
    let h = `<div style="position:absolute;left:${r1(pad * .55)}mm;top:${r1(pad * .55)}mm;right:${r1(pad * .55)}mm;bottom:${r1(pad * .55)}mm;border:${r1(.32 * k)}mm solid #000;border-radius:${r1(1.6 * k)}mm"></div>`;
    h += `<div style="position:absolute;left:${r1(ix)}mm;top:${r1(iy)}mm;width:${r1(d)}mm;height:${r1(d)}mm;border-radius:50%;background:#000"></div><div style="position:absolute;left:${r1(ix + d * .14)}mm;top:${r1(iy + d * .14)}mm;width:${r1(d * .72)}mm;height:${r1(d * .72)}mm">${ICO[kd].replace("<svg ", '<svg style="width:100%;height:100%;display:block" ')}</div>`;
    const nameH = 7.4 * k, nx = ix + d + .8 * k;
    h += T(nx, pad + .25 * k, W - pad - .8 * k - nx, nameH, I.name || "—", 10.5 * k, { b: 1, al: "r" });
    const sepY = pad + nameH + .55 * k;
    h += `<div style="position:absolute;left:${r1(pad + 3 * k)}mm;right:${r1(pad + 3 * k)}mm;top:${r1(sepY)}mm;height:0;border-top:${r1(.28 * k)}mm solid #000"></div><div style="position:absolute;left:50%;top:${r1(sepY - .75 * k)}mm;width:${r1(1.5 * k)}mm;height:${r1(1.5 * k)}mm;margin-left:${r1(-.75 * k)}mm;background:#000;transform:rotate(45deg)"></div>`;
    const fH = 2.6 * k, fY = H - pad - fH - .15 * k, cn = String((co && (co["Company Name"] || co.Name)) || "ANOUER").trim(), iw = W - pad * 2 - 1.2 * k;
    h += T(W - pad - 2 * k - iw * .6, fY, iw * .6, fH, cn, 5.2 * k, { al: "r", b: 0 });
    h += T(pad + 2 * k, fY, iw * .32, fH, new Date().toLocaleDateString("en-GB"), 5 * k, { al: "l", b: 0, ff: "'Segoe UI',Arial,sans-serif" });
    return { h, sepY, fY };
  }
  const wrapP = (W, H, h) => `<div class="rdp" style="position:relative;width:${W}mm;height:${H}mm;overflow:hidden;background:#fff;color:#000;direction:ltr;-webkit-print-color-adjust:exact;print-color-adjust:exact">${h}</div>`;
  const svgAt = (x, y, w, svg) => `<div style="position:absolute;left:${r1(x)}mm;top:${r1(y)}mm;width:${r1(w)}mm;height:${r1(w)}mm">${svg.replace("<svg ", '<svg style="width:100%;height:100%;display:block" ')}</div>`;
  /* ① تيكت القطعة */
  function pagePiece(I, sz, co) {
    const W = sz.w, H = sz.h, k = Math.min(W / 59.9, H / 39.9), pad = 1.1 * k, S = shell(I, W, H, k, pad, co);
    let h = S.h;
    const x0 = pad + .6 * k, xr = W - pad - .6 * k, rH = 7.4 * k, rY = S.fY - .55 * k - rH;
    /* السطر السفلي المنقّط: سعر الكرتونة للتذكير */
    h += `<div style="position:absolute;left:${r1(x0)}mm;top:${r1(rY)}mm;width:${r1(xr - x0)}mm;height:${r1(rH)}mm;border:${r1(.3 * k)}mm dashed #000;border-radius:${r1(rH / 2)}mm;box-sizing:border-box"></div>`;
    const ic = 3.6 * k, lab = bil(I.big) + " (" + (Math.round(I.n * 1000) / 1000) + " " + pieceWord(I.piece) + ")", lw = (xr - x0) * .6;
    h += T(xr - 2.2 * k - lw, rY, lw, rH, lab, 6.6 * k, { b: 1, al: "r" });
    h += svgAt(xr - 2.2 * k - lw - ic - .6 * k, rY + (rH - ic) / 2, ic, ICO.box("#000"));
    h += T(x0 + 2 * k, rY, (xr - x0) * .3, rH, money(I.bp), 10.5 * k, { ff: NUMF, b: 1, al: "l", st: "letter-spacing:-.08mm" });
    /* السعر الكبير + الشارة السوداء */
    const top = S.sepY + 1.2 * k, bot = rY - 1 * k, tw = 22 * k, th = Math.min(bot - top, 15 * k), ty = top + (bot - top - th) / 2;
    h += `<div style="position:absolute;left:${r1(xr - tw)}mm;top:${r1(ty)}mm;width:${r1(tw)}mm;height:${r1(th)}mm;border-radius:${r1(1.4 * k)}mm;background:#000"></div>`;
    h += TAG(xr - tw + .9 * k, ty, tw - 1.8 * k, th, "سعر", I.piece, 12.5 * k, "color:#fff");
    h += T(x0, top - .6 * k, xr - tw - 1.4 * k - x0, bot - top + 1.2 * k, money(I.pp), 33 * k, { ff: NUMF, b: 1, st: "letter-spacing:-.15mm" });
    return wrapP(W, H, h);
  }
  /* ② تيكت الكرتونة */
  function pageCarton(I, sz, co) {
    const W = sz.w, H = sz.h, k = Math.min(W / 59.9, H / 39.9), pad = 1.1 * k, S = shell(I, W, H, k, pad, co);
    let h = S.h;
    const x0 = pad + .4 * k, xr = W - pad - .4 * k, bY = S.sepY + 1.3 * k, bH = 7 * k;
    /* الشريط الأسود: «سعر كرتونة» + صندوق + ×N */
    h += `<div style="position:absolute;left:${r1(x0)}mm;top:${r1(bY)}mm;width:${r1(xr - x0)}mm;height:${r1(bH)}mm;border-radius:${r1(1.3 * k)}mm;background:#000"></div>`;
    const pw = 11.5 * k, ph = bH * .66, ic = 4.8 * k, lw = xr - x0 - pw - ic - 5.2 * k;
    h += T(xr - 1.8 * k - lw, bY, lw, bH, "سعر " + I.big, 10.5 * k, { b: 1, al: "r", st: "color:#fff" });
    h += svgAt(xr - 1.8 * k - lw - ic - .8 * k, bY + (bH - ic) / 2, ic, ICO.box("#fff"));
    h += `<div style="position:absolute;left:${r1(x0 + 1.6 * k)}mm;top:${r1(bY + (bH - ph) / 2)}mm;width:${r1(pw)}mm;height:${r1(ph)}mm;border:${r1(.3 * k)}mm solid #fff;border-radius:${r1(ph / 2)}mm;box-sizing:border-box"></div>`;
    h += T(x0 + 2 * k, bY + (bH - ph) / 2, pw - .8 * k, ph, "\u2066×" + (Math.round(I.n * 1000) / 1000) + "\u2069", 8.5 * k, { ff: NUMF, b: 1, st: "color:#fff" });
    /* السطر السفلي: سعر القطعة داخل الكرتونة + «وفّر» */
    const rH = 7 * k, rY = S.fY - .45 * k - rH, sv = I.save >= 1, sw = sv ? 14.6 * k : 0, bx = x0 + .5 * k + (sv ? sw + .9 * k : 0), bw = xr - .5 * k - bx;
    if (sv) {
      h += `<div style="position:absolute;left:${r1(x0 + .5 * k)}mm;top:${r1(rY)}mm;width:${r1(sw)}mm;height:${r1(rH)}mm;border-radius:${r1(rH / 2)}mm;background:#000"></div>`;
      h += T(x0 + .5 * k, rY + .2 * k, sw, rH * .4, "وفّر", 5.4 * k, { b: 1, st: "color:#fff" });
      h += T(x0 + .5 * k, rY + rH * .38, sw, rH * .58, "⁦−" + I.save + "%⁩", 9.5 * k, { ff: NUMF, b: 1, st: "color:#fff" });
    }
    h += `<div style="position:absolute;left:${r1(bx)}mm;top:${r1(rY)}mm;width:${r1(bw)}mm;height:${r1(rH)}mm;border:${r1(.3 * k)}mm solid #000;border-radius:${r1(1.3 * k)}mm;box-sizing:border-box"></div>`;
    const lbw = bw * .44;
    h += T(bx + bw - 1.6 * k - lbw, rY + .3 * k, lbw, rH - .6 * k, pieceWord(I.piece) + " داخل\n" + I.big, 6.2 * k, { b: 1, al: "r", st: "line-height:1.05" });
    h += T(bx + 1.6 * k, rY, bw - lbw - 4 * k, rH, money(I.inP), 11 * k, { ff: NUMF, b: 1, al: "l", st: "letter-spacing:-.08mm" });
    /* السعر الكبير */
    const top = bY + bH + .3 * k, bot = rY - .3 * k;
    h += T(x0, top, xr - x0, bot - top, money(I.bp), 29 * k, { ff: NUMF, b: 1, st: "letter-spacing:-.15mm" });
    return wrapP(W, H, h);
  }

  /* شريط «خصم الكمية»: شارة سوداء «خصم الكمية %» يميناً ثم بطاقة لكل شريحة «N ومافوق» بسعرها — الأكبر خصماً معكوسة (أسود) */
  function qdStrip(Q, x0, xr, y, sh, k) {
    let h = "";
    const labW = 11.2 * k, g = .6 * k, lx = xr - labW, rr = r1(1.3 * k);
    h += `<div style="position:absolute;left:${r1(lx)}mm;top:${r1(y)}mm;width:${r1(labW)}mm;height:${r1(sh)}mm;border-radius:${rr}mm;background:#000"></div>`;
    const ic = 3 * k;
    h += `<svg style="position:absolute;left:${r1(lx + (labW - ic) / 2)}mm;top:${r1(y + .45 * k)}mm;width:${r1(ic)}mm;height:${r1(ic)}mm" viewBox="0 0 24 24"><path d="M12 1.5l2.6 2.1 3.3-.4 1 3.2 3 1.6-1 3.2 1 3.2-3 1.6-1 3.2-3.3-.4L12 22.5l-2.6-2.1-3.3.4-1-3.2-3-1.6 1-3.2-1-3.2 3-1.6 1-3.2 3.3.4z" fill="#fff"/><path d="M8.6 15.4l6.8-6.8" stroke="#000" stroke-width="2.2" stroke-linecap="round"/><circle cx="9" cy="9.2" r="1.7" fill="#000"/><circle cx="15" cy="14.8" r="1.7" fill="#000"/></svg>`;
    h += T(lx + .4 * k, y + ic + .5 * k, labW - .8 * k, sh - ic - .75 * k, Q.some(q => !q.promo) ? "خصم الكمية" : "تخفيض", 5.6 * k, { b: 1, st: "color:#fff" });
    const area = lx - g - x0, n = Q.length, pw = (area - g * (n - 1)) / n;
    Q.forEach((q, i) => {
      const px = lx - g - (i + 1) * pw - i * g, best = i === n - 1 && n > 1, fg = best ? "#fff" : "#000";
      h += `<div style="position:absolute;left:${r1(px)}mm;top:${r1(y)}mm;width:${r1(pw)}mm;height:${r1(sh)}mm;border-radius:${rr}mm;box-sizing:border-box;${best ? "background:#000" : `background:#fff;border:${r1(.32 * k)}mm solid #000`}"></div>`;
      const lab = (q.promo ? "عرض" : q.from + " ومافوق") + (n < 3 && q.pct >= 1 ? "  \u2066−" + q.pct + "%\u2069" : "");   /* عزل «−5%» حتى لا ينقلب في السطر العربي */
      h += T(px + .5 * k, y + .25 * k, pw - 1 * k, sh * .38, lab, 5.8 * k, { b: 1, st: "color:" + fg });
      h += T(px + .5 * k, y + sh * .38, pw - 1 * k, sh * .6, money(q.price), (n === 1 ? 12 : 10) * k, { ff: NUMF, b: 1, st: "color:" + fg + ";letter-spacing:-.08mm" });
    });
    return h;
  }

  /* تيكت واحد لكل صنف (عدد النسخ يُحترم فقط في تبويب «بالصنف») */
  function uniq(js) {
    const seen = new Set(), out = [];
    (js || []).forEach(j => {
      const f = B().findByCode ? B().findByCode(j.code) : null, key = f && f.p ? "p" + f.p.id + "|" + (j.unit || "") : "c" + j.code;   /* نفس الصنف بوحدتين مختلفتين = تيكتان */
      if (seen.has(key)) return; seen.add(key); out.push(Object.assign({}, j, { n: B().mode === "item" ? Math.max(1, j.n || 1) : 1 }));
    });
    return out;
  }
  async function res(js) {
    const sz = await ref(); let co = {}; try { co = RD() && RD().company ? await RD().company() : {}; } catch (e) { }
    const pages = []; uniq(js).forEach(j => {
      const I2 = pairOf(j);
      if (I2) { const a = pagePiece(I2, sz, co), b = pageCarton(I2, sz, co); for (let i = 0; i < j.n; i++) pages.push({ w: sz.w, h: sz.h, html: a }); for (let i = 0; i < j.n; i++) pages.push({ w: sz.w, h: sz.h, html: b }); return; }
      const h = page(j, sz, co); for (let i = 0; i < j.n; i++) pages.push({ w: sz.w, h: sz.h, html: h });
    });
    return { res: { pages, w: sz.w, h: sz.h, roll: false }, sz };
  }
  async function print(js, preview) {
    const { res: R0, sz } = await res(js); if (!R0.pages.length) return 0;
    const R = RD();
    if (preview) {
      const doc = `<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>AUTO</title><style>@page{size:${sz.w}mm ${sz.h}mm;margin:0}body{margin:0;background:#8a8f98}.rdp{margin:10px auto;box-shadow:0 4px 14px rgba(0,0,0,.35)}@media print{body{background:#fff}.rdp{margin:0;box-shadow:none;page-break-after:always}}</style></head><body>${R0.pages.map(p => p.html).join("")}</body></html>`;
      const f = document.getElementById("bcpFr"), pv = document.getElementById("bcpPv"); if (f && pv) { f.srcdoc = doc; pv.classList.add("show"); }
      LAST = { R0, sz };   // زر «طباعة» في المعاينة ← نفس الطباعة المضبوطة
      return R0.pages.length;
    }
    return hostPrint(R0, sz);
  }
  /* الطباعة المضبوطة: نافذة الطباعة الصغيرة (مثل DEXEF) — كل تيكت صورة بمقاسه الحقيقي بالملّيمتر على طابعة التيكت
     (بدل نافذة طباعة المتصفح الكبيرة التي تُصغّر الملصقات وتطبع أوراقاً طويلة) */
  let LAST = null;
  const HOSTP = () => !!(window.Anouer && Anouer.available && Anouer.call && RD() && RD().hostPrintDialog);
  async function hostPrint(R0, sz) {
    const R = RD(), n = R0.pages.length; let tp = ""; try { tp = R.ticketPrinter ? await R.ticketPrinter() : ""; } catch (e) { }
    const prn = tp || sz.printer;   // دائماً طابعة التيكت TSC TDP-225
    if (HOSTP()) { const r = await R.hostPrintDialog(R0, { printer: prn, title: "AUTO — " + n + " تيكت" }); return r && r.ok ? n : 0; }
    await R.printResult(R0, { printer: prn, copies: 1, title: "AUTO" });
    return n;
  }
  function printLast() { if (!LAST) return null; const x = LAST; return hostPrint(x.R0, x.sz); }
  /* معاينة صفحة واحدة (للمعاينة الحيّة في قائمة التصاميم) */
  async function one(job) {
    const sz = await ref(); let co = {}; try { co = RD() && RD().company ? await RD().company() : {}; } catch (e) { }
    const I2 = pairOf(job);
    if (I2) {   /* القاطو والقوفريط: التيكتان جنباً إلى جنب في المعاينة */
      const g = 3, inn = x => x.replace('class="rdp" style="position:relative;', 'style="position:relative;flex:none;box-shadow:0 0 0 .2mm #cbd5e1;');
      return { html: `<div class="rdp" style="display:flex;gap:${g}mm;width:${r1(sz.w * 2 + g)}mm;height:${sz.h}mm;background:transparent">${inn(pagePiece(I2, sz, co))}${inn(pageCarton(I2, sz, co))}</div>`, sz, info: Object.assign({}, I2, { big: I2.big + " · تيكتان" }) };
    }
    return { html: page(job, sz, co), sz, info: info(job) };
  }

  window.__BCA = { print, res, one, info, ref, pairOf, printLast, clearLast() { LAST = null; }, get hasLast() { return !!LAST; }, reset() { REF = null; } };
})();
