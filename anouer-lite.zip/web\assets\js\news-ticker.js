/* ANOUER — شريط الأخبار 2026 (بأسلوب شريط القنوات الإخبارية)
   • شريط متحرك سلس بسرعة ثابتة (px/ث) يتجه كالقنوات العربية (من اليسار إلى اليمين) — يتوقف عند مرور الفأرة
   • لوحة «الأخبار» بشعار ANOUER + شارة «عاجل» نابضة — ساعة رقمية وتاريخ + «مباشر»
   • «عاجل»: شريط أحمر يظهر فوق الشريط عند بدء خبر عاجل (مرة واحدة لكل خبر) مع صوت الأخبار
   • مصادر الأخبار: أخبار «شريط الأخبار» في الخصائص (لجميع المستخدمين) + ملخص البرنامج الحي (مبيعات/خزينة/حد الطلب…)
   • الضغط على خبر يعرض تفاصيله — الإعدادات (المكان/السرعة/الملخص/الساعة) من شاشة «شريط الأخبار» */
(function () {
  "use strict";
  if (window.ANOUER_TICKER) return;
  const LSK = "anouer.newsTicker", CFGK = "news.cfg", ITK = "news.items";
  const HOST = () => !!(window.Anouer && Anouer.available);
  const call = (a, p) => Anouer.call(a, p || {});
  const esc = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const fmt = n => (Math.round((+n || 0) * 100) / 100).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const LS = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) { } } };
  const SS = { get(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { sessionStorage.setItem(k, v); } catch (e) { } } };
  const PROPS = () => window.ANOUER_PROPS;
  const toast = (m, t) => { try { ((window.__FH && __FH.say) || (window.__RV && __RV.say) || console.log)(m, t); } catch (e) { } };
  const DEF = { pos: "bottom", speed: 3, sys: true, clock: true, brk: true, due: true, dueVoice: true };
  const SPEEDS = [0, 38, 55, 75, 100, 135];
  const cfg = () => { let c = {}; try { c = (PROPS() && PROPS().get(CFGK, {})) || {}; } catch (e) { } return Object.assign({}, DEF, c); };

  const SUN = '<svg class="nwx-sun" viewBox="-30 -30 60 60" aria-hidden="true"><circle r="15" fill="none" stroke="currentColor" stroke-width="6.6"/><circle r="5.6" fill="currentColor"/><g stroke="currentColor" stroke-width="3.4" stroke-linecap="round"><path d="M0-21.8V-26.4"/><path d="M0-21.8V-26.4" transform="rotate(45)"/><path d="M0-21.8V-26.4" transform="rotate(90)"/><path d="M0-21.8V-26.4" transform="rotate(135)"/><path d="M0-21.8V-26.4" transform="rotate(180)"/><path d="M0-21.8V-26.4" transform="rotate(225)"/><path d="M0-21.8V-26.4" transform="rotate(270)"/><path d="M0-21.8V-26.4" transform="rotate(315)"/></g></svg>';
  const SEP = '<i class="nwx-sep" aria-hidden="true"><svg viewBox="-30 -30 60 60"><circle r="13" fill="none" stroke="currentColor" stroke-width="7"/><circle r="5" fill="currentColor"/></svg></i>';
  const CAT = { due: "مستحق", urgent: "عاجل", news: "خبر", promo: "عرض", warn: "تنبيه", sale: "مبيعات", buy: "مشتريات", cash: "الخزينة", debt: "الديون", stock: "المخزون", ok: "النظام" };
  const ICO = {
    pause: '<svg viewBox="0 0 16 16"><rect x="3.5" y="2.5" width="3" height="11" rx="1" fill="currentColor"/><rect x="9.5" y="2.5" width="3" height="11" rx="1" fill="currentColor"/></svg>',
    play: '<svg viewBox="0 0 16 16"><path d="M4.5 2.8v10.4L13 8z" fill="currentColor"/></svg>',
    edit: '<svg viewBox="0 0 16 16"><path d="M10.8 2.2l3 3-8 8H2.8v-3z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    x: '<svg viewBox="0 0 16 16"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'
  };

  let DUE = [], dueT = 0, dueQ = [], dueCur = null;
  let el = null, track = null, raf = 0, x = 0, segW = 0, last = 0, hover = false, paused = false, pending = null, data = null, timer = 0, clkT = 0, items = [], brkQ = [], brkOn = false;

  /* ---------------- الأخبار ---------------- */
  const nowLocal = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 16); };
  function userItems() {
    let rows = []; try { rows = (PROPS() && PROPS().get(ITK, [])) || []; } catch (e) { }
    const now = nowLocal();
    return rows.filter(r => r && r.title && r.active !== false && (!r.from || r.from <= now) && (!r.to || r.to >= now))
      .map(r => ({ id: "u:" + (r.title + "|" + (r.from || "")), t: esc(r.title), desc: r.desc || "", cat: r.urgent ? "urgent" : (r.cat || "news"), urgent: !!r.urgent, from: r.from, to: r.to }));
  }
  function sysItems(d) {
    const out = [], s = (d && d.summary) || {};
    if (!d) return [{ t: "مرحباً بك في <b>ANOUER</b> — شريط الأخبار يعرض أخبارك وملخص المبيعات والتنبيهات لحظة بلحظة", cat: "ok" }];
    if (d.text && !userItems().length) d.text.split(/\r?\n/).forEach(t => { if (t.trim()) out.push({ t: "<b>" + esc(t.trim()) + "</b>", cat: "news" }); });
    if (d.summary) {
      out.push({ t: "مبيعات اليوم <b>" + fmt(s.SalesToday) + "</b> دج <small>(" + (s.SalesCountToday || 0) + " فاتورة)</small>", cat: "sale" });
      if (+s.PurchasesToday) out.push({ t: "مشتريات اليوم <b>" + fmt(s.PurchasesToday) + "</b> دج", cat: "buy" });
      out.push({ t: "رصيد الخزينة <b>" + fmt(s.TreasuryBalance) + "</b> دج", cat: "cash" });
      if (+s.Receivables) out.push({ t: "مستحق على العملاء <b>" + fmt(s.Receivables) + "</b> دج", cat: "debt" });
      if (s.LowStockCount) out.push({ t: "<b>" + s.LowStockCount + "</b> صنف وصل لحد الطلب" + ((s.LowStock || []).length ? " — " + s.LowStock.slice(0, 3).map(p => esc(p.Name)).join("، ") : ""), cat: "warn" });
    }
    if (d.counts) out.push({ t: "الأصناف <b>" + fmt(d.counts.products || 0) + "</b> · العملاء <b>" + fmt(d.counts.customers || 0) + "</b>", cat: "stock" });
    if (d.autoBackup && d.autoBackup.Enabled) out.push({ t: "الحفظ التلقائي مفعّل" + (d.autoBackup.LastRun ? " — آخر نسخة " + esc(d.autoBackup.LastRun) : ""), cat: "ok" });
    return out;
  }
  function collect() {
    const c = cfg(), u = userItems();
    const head = { t: "مرحباً بك في <b>" + esc((data && data.company) || "ANOUER") + "</b>", cat: "ok" };
    let l = dueItems().concat(u.filter(x => x.urgent)).concat(u.filter(x => !x.urgent));
    if (c.sys !== false) l = l.concat(sysItems(data));
    if (!l.length) l = [head];
    return l;
  }

  /* ---------------- البناء ---------------- */
  const itemHTML = (it, i) => `<span class="nwx-it c-${it.cat}" data-i="${i}"${it.desc ? ' data-d="1"' : ""}><em>${CAT[it.cat] || "خبر"}</em><span class="nwx-tx">${it.t}</span></span>`;
  function build(list) {
    if (!el) return;
    items = list;
    const one = `<div class="nwx-seg">${list.map(itemHTML).join(SEP)}${SEP}</div>`;
    track.innerHTML = one;
    const vw = el.querySelector(".nwx-crawl").clientWidth || 800;
    segW = track.firstElementChild.getBoundingClientRect().width || 600;
    const n = Math.max(2, Math.ceil(vw / segW) + 1);
    track.innerHTML = one.repeat(n);
    if (x >= segW) x = x % segW;
    el.classList.toggle("has-urg", list.some(i => i.urgent));
    el.classList.toggle("due", DUE.length > 0); const dn = el.querySelector(".nwx-due"); if (dn) dn.textContent = DUE.length ? "مستحق اليوم · " + DUE.length : "";
    const u = list.filter(i => i.urgent);
    el.querySelector(".nwx-cnt").textContent = list.filter(i => i.id).length ? String(list.filter(i => i.id).length) : "";
    if (cfg().brk !== false) u.filter(it => it.cat !== "due").forEach(it => { const k = "nt.seen." + it.id; if (!SS.get(k)) { SS.set(k, "1"); brkQ.push(it); } });
    if (brkQ.length && !brkOn) setTimeout(nextBreak, 600);
  }
  /* أخبار جديدة/محذوفة ← تظهر فوراً (بتلاشٍ ناعم)؛ تحديث الأرقام فقط ← عند نهاية الدورة بلا قفزة */
  const sig = l => l.map(i => i.id || i.cat).join("|");
  function update() {
    const l = collect(); if (!el) return;
    if (!track.firstElementChild || sig(l) !== sig(items)) { pending = null; x = 0; build(l); track.classList.remove("swap"); void track.offsetWidth; track.classList.add("swap"); return; }
    pending = l;
  }
  function loop(t) {
    raf = requestAnimationFrame(loop);
    if (!last) { last = t; return; }
    const dt = Math.min(0.1, (t - last) / 1000); last = t;
    if (!hover && !paused && !brkOn && !document.hidden) x += SPEEDS[Math.max(1, Math.min(5, +cfg().speed || 3))] * dt;
    if (segW && x >= segW) { x -= segW; if (pending) { const p = pending; pending = null; build(p); } }
    track.style.transform = "translate3d(" + x.toFixed(2) + "px,0,0)";
  }

  /* ================================================================ استحقاق دفع العملاء
     • فواتير مبيعات لها «تاريخ استحقاق» حلّ (اليوم أو قبله) وباقٍ عليها ← الشريط يتحول للأحمر
     • «عاجل» بصوت نشرة أخبار (مؤلَّف خصيصاً) + اسم العميل والمبلغ (ونطقه صوتياً إن توفر صوت عربي)
     • يتكرر تلقائياً كل يوم حتى: تحصيل المبلغ ، أو «غداً» (تأجيل يوم) ، أو «إلغاء التنبيه» لهذه الفواتير */
  const DOFF = "news.dueOff", DSNZ = "news.dueSnooze";
  const today = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); };
  const pget = (k, d) => { try { return (PROPS() && PROPS().get(k, d)) || d; } catch (e) { return d; } };
  const pput = (k, v) => { try { if (PROPS() && PROPS().put) return PROPS().put(k, v); } catch (e) { } };
  const DIC = {
    cash: '<svg viewBox="0 0 20 20" width="15" height="15"><rect x="2" y="5" width="16" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="10" cy="10" r="2.6" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>',
    clock: '<svg viewBox="0 0 20 20" width="15" height="15"><circle cx="10" cy="10" r="7" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M10 6v4.5l3 1.8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    mute: '<svg viewBox="0 0 20 20" width="15" height="15"><path d="M3 8h3l4-3.5v11L6 12H3z" fill="currentColor"/><path d="M13.5 7.5l4 5M17.5 7.5l-4 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    bell: '<svg viewBox="0 0 20 20" width="15" height="15"><path d="M5 14V9a5 5 0 0 1 10 0v5l1.5 1.5h-13z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M3 3l14 14" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'
  };
  function dueItems() {
    return cfg().due === false ? [] : DUE.map(d => ({ id: "due:" + d.pid + ":" + d.rem, cat: "due", due: d,
      t: `العميل <b>${esc(d.name)}</b> — ${d.days > 0 ? `متأخر <b>${d.days}</b> يوم عن الدفع` : "موعد الدفع <b>اليوم</b>"} — المستحق <b>${fmt(d.rem)}</b> دج${d.n > 1 ? ` <small>(${d.n} فواتير)</small>` : ""}` }));
  }
  /* العملاء المستحقون (حلّ أجل الدفع وبقي عليهم مبلغ) — مع احترام «غداً» و«إلغاء التنبيه» */
  function dueCalc(L) {
    const t = today(), off = pget(DOFF, {}), snz = pget(DSNZ, {}), g = {};
    (L || []).forEach(r => { if (!r.hasDue || !r.due || r.due > t || !(+r.rem > .01) || off[r.id]) return; if (snz[r.pid] && snz[r.pid] >= t) return;
      const x = g[r.pid] || (g[r.pid] = { pid: r.pid, name: r.pname, no: r.pno, rem: 0, n: 0, due: r.due, ids: [], nos: [] });
      x.rem += +r.rem; x.n++; x.ids.push(r.id); x.nos.push(r.no); if (r.due < x.due) x.due = r.due; });
    const days = d => Math.max(0, Math.round((new Date(t) - new Date(d)) / 864e5));
    return Object.values(g).map(x => Object.assign(x, { rem: Math.round(x.rem * 100) / 100, days: days(x.due) })).sort((a, b) => b.days - a.days || b.rem - a.rem);
  }
  /* معرّف «فتحة البرنامج» الحالية = رقم سطر تسجيل الدخول ← التنبيه يظهر مرة مع كل فتح للبرنامج (لا مرة في اليوم) */
  let RUN = null;
  function runId() {
    if (RUN) return Promise.resolve(RUN);
    const fb = () => (RUN = "d" + today());
    if (!HOST() || !Anouer.authMe) return Promise.resolve(fb());
    return Anouer.authMe().then(m => { const id = m && (m.LoginId || m.loginId); if (!id) return fb(); RUN = "r" + id;
      try { for (let i = localStorage.length - 1; i >= 0; i--) { const k = localStorage.key(i); if (k && k.indexOf("due.alarm.") === 0 && k.indexOf("due.alarm." + RUN + ".") !== 0) localStorage.removeItem(k); } } catch (e) { }
      return RUN; }, fb);
  }
  function dueCheck() {
    if (!el || !HOST() || cfg().due === false) { if (DUE.length) { DUE = []; update(); } return; }
    Promise.all([call("fm.acc.aging", { side: "cu" }), runId()]).then(R => {
      const nd = dueCalc(R[0]), run = R[1]; if (!el) return;
      const was = DUE.map(d => d.pid + ":" + d.rem).join(); DUE = nd;
      if (was !== nd.map(d => d.pid + ":" + d.rem).join()) update();
      /* مرة مع كل فتح للبرنامج لكل عميل: «عاجل» تلقائي بالصوت */
      nd.forEach(d => { const k = "due.alarm." + run + "." + d.pid; if (!LS.get(k)) { LS.set(k, "1"); brkQ.push({ due: d }); } });
      if (brkQ.length && !brkOn) setTimeout(nextBreak, 900);
    }).catch(() => { });
  }
  function dueBanner(d) {
    const ini = String(d.name || "؟").trim().charAt(0);
    return `<span class="nwx-av">${esc(ini)}</span><span class="nwx-dn">${esc(d.name)}</span><span class="nwx-dd">${d.days > 0 ? `متأخر ${d.days} يوم` : "موعد الدفع اليوم"}</span><span class="nwx-dl">المبلغ المستحق</span><b class="nwx-amt" dir="ltr">0</b><span class="nwx-cur">دج</span>${d.n > 1 ? `<small class="nwx-dc">${d.n} فواتير</small>` : `<small class="nwx-dc">فاتورة ${esc(d.nos[0] || "")}</small>`}`;
  }
  function countUp(elx, v) { if (!elx) return; const t0 = performance.now(), D = 1100; const st = t => { const k = Math.min(1, (t - t0) / D), e = 1 - Math.pow(1 - k, 3); elx.textContent = fmt(v * e); if (k < 1) requestAnimationFrame(st); }; requestAnimationFrame(st); }
  function dueAct(a, d) {
    const t = today();
    if (a === "pay") { endBreak(); try { if (window.ANOUER_CASH && ANOUER_CASH.recvFor) ANOUER_CASH.recvFor(d.pid, d.rem, "تحصيل مستحق" + (d.nos.length ? " — فاتورة " + d.nos.join("، ") : "")); else if (window.ANOUER_CASH) ANOUER_CASH.recv(); } catch (e) { } return; }
    if (a === "mute" && muted() && LS.get("due.mute." + t) === "1") { LS.set("due.mute." + t, "0"); const b = el && el.querySelector(".nwx-brk"), m = b && b.querySelector('[data-d="mute"]'); if (m) { m.classList.remove("done"); m.lastChild.textContent = "كتم"; } if (b) clearTimeout(b._t); toast("🔊 عاد صوت المذيع", "i"); sayDue(d); return; }
    if (a === "mute") { LS.set("due.mute." + t, "1"); stopVoice(); const b = el && el.querySelector(".nwx-brk"); if (b) { const m = b.querySelector('[data-d="mute"]'); if (m) { m.classList.add("done"); m.lastChild.textContent = "تشغيل الصوت"; } clearTimeout(b._t); b._t = setTimeout(endBreak, 8000); } toast("🔇 كُتم صوت المذيع لبقية اليوم — التنبيهات تبقى ظاهرة", "i"); return; }
    if (a === "snz") { const s = pget(DSNZ, {}); s[d.pid] = t; pput(DSNZ, s); }
    if (a === "off") { const o = pget(DOFF, {}); d.ids.forEach(id => o[id] = t); pput(DOFF, o); }
    DUE = DUE.filter(x => x.pid !== d.pid); brkQ = brkQ.filter(q => !(q.due && q.due.pid === d.pid));
    endBreak(); update();
    try { toast(a === "off" ? "أُلغي تنبيه استحقاق «" + d.name + "»" : "سيظهر تنبيه «" + d.name + "» غداً", "s"); } catch (e) { }
  }
  /* نغمة «عاجل» مؤلَّفة خصيصاً لـ ANOUER (Web Audio): ضربة عميقة + ثلاث نبضات نحاسية + وتر صاعد */
  let DAC = null;
  function dueSting() {
    try {
      const v = pget("view.gen", {}); if (v.sNewsOn === false) return;
      { const k = +String(v.sNews || "").replace(/\D/g, ""); if (k && k !== 96 && window.ANOUER_PLAY) { window.ANOUER_PLAY(k); return; } }   // نغمة مختارة من الخصائص بدل النغمة المدمجة
      DAC = DAC || new (window.AudioContext || window.webkitAudioContext)(); const ac = DAC; if (ac.state === "suspended") ac.resume();
      const t0 = ac.currentTime + .05, out = ac.createDynamicsCompressor(); out.threshold.value = -10; out.ratio.value = 6; out.connect(ac.destination);
      const master = ac.createGain(); master.gain.value = .9; master.connect(out);
      const rev = ac.createConvolver(), len = ac.sampleRate * 1.6, ir = ac.createBuffer(2, len, ac.sampleRate);
      for (let c = 0; c < 2; c++) { const ch = ir.getChannelData(c); for (let i = 0; i < len; i++) ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3); }
      rev.buffer = ir; const rg = ac.createGain(); rg.gain.value = .22; rev.connect(rg); rg.connect(master);
      const boom = (t, f, g) => { const o = ac.createOscillator(), a = ac.createGain(); o.type = "sine"; o.frequency.setValueAtTime(f * 2.2, t); o.frequency.exponentialRampToValueAtTime(f, t + .18);
        a.gain.setValueAtTime(0, t); a.gain.linearRampToValueAtTime(g, t + .01); a.gain.exponentialRampToValueAtTime(.001, t + .9); o.connect(a); a.connect(master); a.connect(rev); o.start(t); o.stop(t + 1);
        const nb = ac.createBuffer(1, ac.sampleRate * .25, ac.sampleRate), nd = nb.getChannelData(0); for (let i = 0; i < nd.length; i++) nd[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / nd.length, 4);
        const ns = ac.createBufferSource(), nf = ac.createBiquadFilter(), ng = ac.createGain(); ns.buffer = nb; nf.type = "lowpass"; nf.frequency.value = 900; ng.gain.value = g * .5; ns.connect(nf); nf.connect(ng); ng.connect(master); ns.start(t); };
      const stab = (t, notes, d, g) => notes.forEach(f => { [-6, 6].forEach(dt => { const o = ac.createOscillator(), lp = ac.createBiquadFilter(), a = ac.createGain(); o.type = "sawtooth"; o.frequency.value = f; o.detune.value = dt;
        lp.type = "lowpass"; lp.frequency.setValueAtTime(600, t); lp.frequency.exponentialRampToValueAtTime(3600, t + .05); lp.frequency.exponentialRampToValueAtTime(1200, t + d);
        a.gain.setValueAtTime(0, t); a.gain.linearRampToValueAtTime(g, t + .015); a.gain.setValueAtTime(g, t + d * .6); a.gain.exponentialRampToValueAtTime(.001, t + d);
        o.connect(lp); lp.connect(a); a.connect(master); a.connect(rev); o.start(t); o.stop(t + d + .05); }); });
      const N = m => 440 * Math.pow(2, (m - 69) / 12);
      boom(t0, 48, .9);
      stab(t0 + .02, [N(50), N(57), N(62)], .22, .05);                 // D minor
      stab(t0 + .32, [N(50), N(57), N(62)], .14, .045);
      stab(t0 + .5, [N(50), N(57), N(62)], .14, .045);
      stab(t0 + .68, [N(53), N(60), N(65)], .16, .05);                 // F
      boom(t0 + .86, 44, .8);
      stab(t0 + .88, [N(46), N(53), N(58), N(62)], 1.6, .045);         // Bb add9 — نهاية مفتوحة
      stab(t0 + .88, [N(74)], 1.5, .025);
    } catch (e) { try { window.ANOUER_SOUND && ANOUER_SOUND("news"); } catch (e2) { } }
  }
  /* ================================================================ المذيع: صوت بشري طبيعي
     • Gemini TTS (بمفتاح Gemini الموجود في «قراءة فاتورة ورقية») بأداء معلّق مباشر متحمّس — وإلا أفضل صوت عربي في Windows
     • المبلغ يُنطق بالكلمات العربية الصحيحة، والاسم بوضوح ، ويتكرر الإعلان حتى تضغط «كتم» */
  const ONES = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
  const TENS = ["", "", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
  const HUN = ["", "مائة", "مائتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة"];
  function w999(n) { const h = Math.floor(n / 100), r = n % 100, o = []; if (h) o.push(HUN[h]); if (r) o.push(r < 20 ? ONES[r] : (r % 10 ? ONES[r % 10] + " و" : "") + TENS[Math.floor(r / 10)]); return o.join(" و"); }
  function arWords(v) {
    let n = Math.round(+v || 0); if (!n) return "صفر"; const parts = [];
    const sc = [[1e9, "مليار", "ملياران", "مليارات"], [1e6, "مليون", "مليونان", "ملايين"], [1e3, "ألف", "ألفان", "آلاف"]];
    for (const [d, one, two, many] of sc) { const k = Math.floor(n / d); n %= d; if (!k) continue; parts.push(k === 1 ? one : k === 2 ? two : k <= 10 ? w999(k) + " " + many : w999(k) + " " + one); }
    if (n) parts.push(w999(n)); return parts.join(" و");
  }
  const dzd = v => { const n = Math.round(+v || 0), r = n % 100; if (n === 1) return "دينار واحد"; if (n === 2) return "ديناران"; return arWords(n) + " " + (r >= 3 && r <= 10 ? "دنانير" : "دينار"); };
  const dayW = d => d === 1 ? "بيوم واحد" : d === 2 ? "بيومين" : d <= 10 ? "بـ" + arWords(d) + " أيام" : "بـ" + arWords(d) + " يوماً";
  const pick = a => a[Math.floor(Math.random() * a.length)];
  /* صياغة صارمة غاضبة (بلا إهانة للعميل) — تتبدل بين عدة صيغ */
  function script(d) {
    const nm = String(d.name || "").trim(), am = dzd(d.rem);
    return d.days > 0
      ? pick([`تنبيه شديد! العميل ${nm}... متأخّر عن الدفع ${dayW(d.days)}! المبلغ المستحق: ${am}. هذا غير مقبول... حصّل المبلغ فوراً!`,
              `انتبه جيداً! العميل ${nm} لم يدفع بعد... والتأخير ${dayW(d.days)}! المبلغ: ${am}. لا تأجيل بعد اليوم!`,
              `مرة أخرى! العميل ${nm}... ${am} ما زالت عليه، والتأخير ${dayW(d.days)}! يجب التحصيل الآن!`])
      : pick([`انتبه! العميل ${nm}... موعد الدفع اليوم! المبلغ المستحق: ${am}. يجب التحصيل... اليوم!`,
              `اليوم هو الموعد! العميل ${nm}... عليه ${am}. لا تنتظر... حصّل المبلغ الآن!`]);
  }
  /* أسلوب الأداء بصيغة «Say …:» القصيرة (الصيغة الموثقة لنماذج الصوت: توجيه لا يُنطق) — صوت رجل عميق خشن غاضب كإنسان حقيقي */
  const DIRECT = "Say in a deep, gruff, stern and angry male voice, like a real furious human, with natural pauses: ";
  const gKey = () => { try { const v = localStorage.getItem("scan.gkey"); return v ? decodeURIComponent(escape(atob(v))) : ""; } catch (e) { return ""; } };
  const GAPI = "https://generativelanguage.googleapis.com/v1beta/";
  async function ttsModel(key) {
    const c = LS.get("news.ttsModel"); if (c) return c;
    let best = "gemini-2.5-flash-preview-tts";
    try { const r = await fetch(GAPI + "models?pageSize=200", { headers: { "x-goog-api-key": key } }); const j = await r.json(); const l = (j.models || []).map(m => m.name.replace(/^models\//, "")).filter(n => /tts/i.test(n));
      if (l.length) best = l.sort((a, b) => (/flash/.test(b) - /flash/.test(a)) || b.localeCompare(a))[0]; } catch (e) { }
    LS.set("news.ttsModel", best); return best;
  }
  const AUD = new Map();          // نص ← AudioBuffer (لا يُطلب الصوت مرتين)
  let VAC = null, vSrc = null, vTok = 0;
  async function aiVoice(text) {
    const key = gKey(); if (!key) throw new Error("no key");
    const ck = (cfg().dueVoiceName || "Algenib") + "|" + text; if (AUD.has(ck)) return AUD.get(ck);
    const model = await ttsModel(key), voice = cfg().dueVoiceName || "Algenib";   /* Algenib: صوت خشن أجش */
    const r = await fetch(GAPI + "models/" + encodeURIComponent(model) + ":generateContent", { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: DIRECT + text }] }], generationConfig: { responseModalities: ["AUDIO"], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } } } }) });
    if (!r.ok) { if (r.status === 404) LS.set("news.ttsModel", ""); throw new Error("tts " + r.status); }
    const j = await r.json(), part = ((((j.candidates || [])[0] || {}).content || {}).parts || []).find(p => p.inlineData || p.inline_data);
    const id = part && (part.inlineData || part.inline_data); if (!id || !id.data) throw new Error("no audio");
    const rate = +((String(id.mimeType || id.mime_type || "").match(/rate=(\d+)/) || [])[1]) || 24000;
    const bin = atob(id.data), n = bin.length >> 1; VAC = VAC || new (window.AudioContext || window.webkitAudioContext)();
    const buf = VAC.createBuffer(1, n, rate), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) { let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8); if (v >= 32768) v -= 65536; ch[i] = v / 32768; }
    AUD.set(ck, buf); return buf;
  }
  function playBuf(buf) {
    return new Promise(ok => { try { const ac = VAC; if (ac.state === "suspended") ac.resume(); const src = ac.createBufferSource(), g = ac.createGain(), cp = ac.createDynamicsCompressor();
      g.gain.value = 1.15; cp.threshold.value = -14; cp.ratio.value = 4; src.buffer = buf; src.connect(g); g.connect(cp); cp.connect(ac.destination); vSrc = src; src.onended = () => { if (vSrc === src) vSrc = null; ok(); }; src.start(); } catch (e) { ok(); } });
  }
  function sysVoice(text) {
    return new Promise(ok => {
      try {
        if (!window.speechSynthesis) return ok(); const vs = speechSynthesis.getVoices().filter(x => /^ar/i.test(x.lang)); if (!vs.length) return ok();
        const rank = v => (/natural|online|neural/i.test(v.name) ? 10 : 0) + (/DZ|MA|TN/i.test(v.lang) ? 4 : /SA|EG|AE/i.test(v.lang) ? 2 : 0) + (/male|hamed|ismael|shakir|naayf|zaki|hamdan|omar|fahed|taim|moaz|bassel|rami/i.test(v.name) ? 3 : 0);
        const v = vs.sort((a, b) => rank(b) - rank(a))[0];
        const u = new SpeechSynthesisUtterance(text.replace(/\.\.\./g, "، ")); u.voice = v; u.lang = v.lang; u.rate = .92; u.pitch = .72; u.volume = 1;
        u.onend = u.onerror = () => ok(); speechSynthesis.cancel(); speechSynthesis.speak(u);
      } catch (e) { ok(); }
    });
  }
  const muted = () => LS.get("due.mute." + today()) === "1" || cfg().dueVoice === false || pget("view.gen", {}).sNewsOn === false;
  function stopVoice() { vTok++; try { if (vSrc) vSrc.stop(); } catch (e) { } vSrc = null; try { speechSynthesis.cancel(); } catch (e) { } }
  /* يتكلم ويعيد الإعلان كل بضع ثوانٍ ما دام التنبيه ظاهراً — حتى «كتم» أو تحصيل/غداً/إلغاء/إغلاق */
  async function sayDue(d) {
    const tok = ++vTok, text = script(d);
    const stillOn = () => tok === vTok && el && dueCur === d && !muted();
    let buf = null, useAI = !!gKey() && cfg().dueVoiceMode !== "system";
    const lb = el && el.querySelector(".nwx-onair"); if (lb) lb.classList.add("on");
    for (let k = 0; stillOn(); k++) {
      if (useAI && !buf) { try { buf = await aiVoice(text); } catch (e) { useAI = false; console.warn("TTS", e); } }
      if (!stillOn()) break;
      if (buf) await playBuf(buf); else await sysVoice(text);
      if (!stillOn()) break;
      /* أكثر من عميل مستحق: ينتقل المذيع للعميل التالي ويدور على الجميع (ثم يعيد) حتى «كتم» أو تحصيل/غداً/إلغاء */
      if (brkQ.some(q => q.due && q.due.pid !== d.pid)) {
        await new Promise(o => setTimeout(o, 1800)); if (!stillOn()) break;
        if (DUE.some(x => x.pid === d.pid) && !brkQ.some(q => q.due && q.due.pid === d.pid)) brkQ.push({ due: d, again: 1 });
        if (lb) lb.classList.remove("on"); endBreak(); return;
      }
      await new Promise(o => setTimeout(o, Math.min(9000, 5000 + k * 1000)));
    }
    if (tok === vTok && lb) lb.classList.remove("on");
  }
  try { if (window.speechSynthesis) speechSynthesis.getVoices(); } catch (e) { }

  /* ---------------- الساعة ---------------- */
  const DAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  const MONTHS = ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
  function clock() {
    if (!el) return; const d = new Date(), p = v => String(v).padStart(2, "0");
    el.querySelector(".nwx-hh").textContent = p(d.getHours()); el.querySelector(".nwx-mm").textContent = p(d.getMinutes());
    el.querySelector(".nwx-dt").textContent = DAYS[d.getDay()] + " " + d.getDate() + " " + MONTHS[d.getMonth()];
  }

  /* ---------------- عاجل ---------------- */
  function nextBreak() {
    if (!el || brkOn) return; const it = brkQ.shift(); if (!it) return;
    brkOn = true;
    const b = el.querySelector(".nwx-brk");
    b.classList.toggle("dueb", !!it.due); b.querySelector(".nwx-bk").textContent = it.due ? "عاجل · استحقاق" : "عاجل";
    b.querySelector(".nwx-bt").innerHTML = it.due ? dueBanner(it.due) : it.t;
    b.querySelector(".nwx-ba").innerHTML = it.due ? `<button type="button" data-d="pay" title="فتح «استلام نقدية» لهذا العميل بالمبلغ المستحق">${DIC.cash}تحصيل</button><button type="button" data-d="snz" title="لا يظهر هذا العميل حتى الغد">${DIC.clock}غداً</button><button type="button" data-d="off" title="إيقاف التنبيه لهذه الفواتير نهائياً">${DIC.bell}إلغاء التنبيه</button><button type="button" data-d="mute" class="mu" title="كتم صوت المذيع لبقية اليوم">${DIC.mute}<span class="nwx-onair"><i></i><i></i><i></i></span>كتم</button>` : "";
    dueCur = it.due || null;
    if (it.due && muted()) { const m = b.querySelector('[data-d="mute"]'); if (m) { m.classList.add("done"); m.lastChild.textContent = "تشغيل الصوت"; } }
    b.classList.remove("out"); b.classList.add("on");
    clearTimeout(b._t);
    if (it.due) { countUp(b.querySelector(".nwx-amt"), it.due.rem); if (!it.again) dueSting(); const d0 = it.due;
      if (!muted()) setTimeout(() => sayDue(d0), it.again ? 900 : 2300);        /* يبقى ظاهراً ويتكلم حتى «كتم» */
      else b._t = setTimeout(endBreak, 15000); }
    else { try { window.ANOUER_SOUND && ANOUER_SOUND("news"); } catch (e) { } b._t = setTimeout(endBreak, 9000); }
  }
  function endBreak() {
    if (!el) return; const b = el.querySelector(".nwx-brk"); clearTimeout(b._t); dueCur = null; stopVoice();
    b.classList.add("out"); setTimeout(() => { b.classList.remove("on", "out"); brkOn = false; if (brkQ.length) setTimeout(nextBreak, 800); }, 420);
  }

  /* ---------------- التفاصيل ---------------- */
  function pop(it, anchor) {
    closePop();
    const p = document.createElement("div"); p.className = "nwx-pop c-" + it.cat;
    const when = it.from ? String(it.from).replace("T", " ") : "";
    p.innerHTML = `<div class="nwx-ph"><em>${CAT[it.cat] || "خبر"}</em><b>${it.t}</b><button type="button" aria-label="إغلاق">${ICO.x}</button></div>${it.desc ? `<div class="nwx-pd">${esc(it.desc).replace(/\n/g, "<br>")}</div>` : ""}${when ? `<div class="nwx-pf">من <b dir="ltr">${esc(when)}</b>${it.to ? ` إلى <b dir="ltr">${esc(String(it.to).replace("T", " "))}</b>` : ""}</div>` : ""}`;
    document.body.appendChild(p);
    const r = anchor.getBoundingClientRect(), w = p.offsetWidth, h = p.offsetHeight, top = cfg().pos !== "top";
    p.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.left + r.width / 2 - w / 2)) + "px";
    p.style.top = (top ? r.top - h - 10 : r.bottom + 10) + "px"; p.classList.add(top ? "up" : "dn");
    p.querySelector("button").onclick = closePop;
    setTimeout(() => document.addEventListener("mousedown", outside, true), 0);
  }
  const outside = e => { if (!e.target.closest(".nwx-pop")) closePop(); };
  function closePop() { document.querySelectorAll(".nwx-pop").forEach(p => p.remove()); document.removeEventListener("mousedown", outside, true); }

  /* ---------------- العرض ---------------- */
  function place() {
    if (!el) return; const c = cfg();
    el.classList.toggle("top", c.pos === "top"); el.classList.toggle("noclk", c.clock === false);
    const st = document.querySelector("body>.status"), nav = document.querySelector(".nav");
    if (c.pos === "top") { if (nav && nav.parentNode && nav.nextSibling !== el) nav.parentNode.insertBefore(el, nav.nextSibling); }
    else if (st && st.parentNode) { if (st.previousSibling !== el) st.parentNode.insertBefore(el, st); }
    else if (el.parentNode !== document.body) document.body.appendChild(el);
  }
  function mount() {
    el = document.createElement("div"); el.id = "nwxNews"; el.className = "nwx"; el.setAttribute("role", "marquee"); el.setAttribute("aria-label", "شريط الأخبار");
    el.innerHTML = `<div class="nwx-brand"><span class="nwx-logo">${SUN}</span><span class="nwx-bl"><b>الأخبار</b><small>ANOUER</small></span><span class="nwx-urg">عاجل</span><span class="nwx-due" title="عملاء حلّ موعد دفعهم"></span><span class="nwx-cnt" title="عدد الأخبار النشطة"></span></div>
      <div class="nwx-crawl"><div class="nwx-fade r"></div><div class="nwx-track"></div><div class="nwx-fade l"></div>
        <div class="nwx-brk" role="alert"><span class="nwx-bk">عاجل</span><span class="nwx-bt"></span><span class="nwx-ba"></span><button type="button" class="nwx-bx" aria-label="إغلاق">${ICO.x}</button></div></div>
      <div class="nwx-ctl"><button type="button" data-a="p" title="إيقاف / تشغيل">${ICO.pause}</button><button type="button" data-a="e" title="إدارة الأخبار">${ICO.edit}</button><button type="button" data-a="x" title="إخفاء شريط الأخبار">${ICO.x}</button></div>
      <div class="nwx-clk"><span class="nwx-live"><i></i>مباشر</span><span class="nwx-time"><span class="nwx-hh">00</span><i>:</i><span class="nwx-mm">00</span></span><span class="nwx-dt"></span></div>`;
    track = el.querySelector(".nwx-track");
    const crawl = el.querySelector(".nwx-crawl");
    crawl.addEventListener("mouseenter", () => { hover = true; }); crawl.addEventListener("mouseleave", () => { hover = false; });
    crawl.addEventListener("click", e => {
      if (e.target.closest(".nwx-bx")) { endBreak(); return; }
      const da = e.target.closest(".nwx-ba [data-d]"); if (da && dueCur) { dueAct(da.dataset.d, dueCur); return; }
      if (e.target.closest(".nwx-brk")) return;
      const s = e.target.closest(".nwx-it"); if (!s) return; const it = items[+s.dataset.i]; if (!it) return;
      if (it.due) { brkQ.unshift({ due: it.due }); if (brkOn) endBreak(); else nextBreak(); return; }
      if (it.urgent && !brkOn) { brkQ.unshift(it); nextBreak(); return; }
      pop(it, s);
    });
    el.querySelector(".nwx-ctl").addEventListener("click", e => {
      const b = e.target.closest("[data-a]"); if (!b) return; const a = b.dataset.a;
      if (a === "p") { paused = !paused; b.innerHTML = paused ? ICO.play : ICO.pause; el.classList.toggle("paused", paused); }
      else if (a === "x") show(false);
      else if (a === "e") openAdmin();
    });
    el.querySelector(".nwx-brand").addEventListener("click", e => { if (e.target.closest(".nwx-due") && DUE.length && !brkOn) { DUE.forEach(d => brkQ.push({ due: d })); nextBreak(); return; } const u = items.find(i => i.urgent); if (u && !brkOn) { brkQ.unshift(u); nextBreak(); } });
    place();
  }
  function openAdmin() {
    try { if (window.__propsHub) { window.__propsHub(); setTimeout(() => { const t = document.querySelector('.fm-hub .fm-tile[data-k="news"]'); if (t) t.click(); }, 60); return; } } catch (e) { }
    try { toast("افتح: الخصائص ← شريط الأخبار", "i"); } catch (e) { }
  }
  function refresh() {
    if (!el) return;
    const go = () => { place(); if (!HOST()) { data = null; update(); return; } call("fm.news").then(d => { data = d; update(); }).catch(() => update()); };
    const P = PROPS(); if (P && P.load) P.load().then(go, go); else go();
  }
  function show(on, temp) {
    if (!temp) LS.set(LSK, on ? "1" : "0");
    if (!on) { if (el) { cancelAnimationFrame(raf); clearInterval(timer); clearInterval(clkT); clearInterval(dueT); closePop(); el.classList.add("bye"); const e0 = el; setTimeout(() => e0.remove(), 260); el = null; track = null; } return; }
    if (el) { refresh(); return; }
    mount(); x = 0; last = 0; segW = 0;
    build(collect()); refresh(); clock(); setTimeout(refresh, 1800);
    raf = requestAnimationFrame(loop);
    timer = setInterval(refresh, 60000); clkT = setInterval(clock, 1000);
    clearInterval(dueT); setTimeout(dueCheck, 4000); dueT = setInterval(dueCheck, 10 * 60000);
  }
  window.addEventListener("anouer:props", e => { const k = e.detail && e.detail.key; if (!el) return; if (k === CFGK) { place(); update(); } else if (k === ITK) refresh(); });
  addEventListener("resize", () => { if (el && items.length) build(items); });

  /* عند فتح البرنامج والشريط مخفي: إن وُجد عميل مستحق لم يُنبَّه عليه في هذه الفتحة ← يُفتح الشريط للتذكير
     (مؤقتاً — لا يغيّر اختيار المستخدم بإخفاء الشريط) */
  function dueBoot() {
    if (el || !HOST() || cfg().due === false) return;
    Promise.all([call("fm.acc.aging", { side: "cu" }), runId()]).then(R => {
      if (el || cfg().due === false) return;
      if (dueCalc(R[0]).some(d => !LS.get("due.alarm." + R[1] + "." + d.pid))) show(true, true);
    }).catch(() => { });
  }
  setTimeout(() => { const P = PROPS(); if (P && P.load) P.load().then(dueBoot, dueBoot); else dueBoot(); }, 5000);

  window.ANOUER_TICKER = { _say: { arWords, dzd, script }, unmute: () => { LS.set("due.mute." + today(), "0"); }, dueCheck, get dues() { return DUE.slice(); }, dueTest: d => { DUE = [Object.assign({ pid: 0, name: "عميل تجريبي", rem: 25000, n: 1, days: 0, ids: [], nos: ["1"] }, d || {})]; update(); brkQ.push({ due: DUE[0] }); nextBreak(); }, show, refresh, get on() { return !!el; }, cfg, DEF, SPEEDS, breaking: it => { if (!el) show(true); brkQ.push({ t: esc(it.title || it), cat: "urgent", urgent: true }); nextBreak(); } };
})();
