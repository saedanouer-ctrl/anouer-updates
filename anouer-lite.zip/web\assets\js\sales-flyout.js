/* ANOUER — ☰ «الخصائص» أعلى الشريط الأيسر لشاشة المبيعات
   مطابق لـ DEXEF ONE (Dexef.Bill › FrmSales.BtnMenu_Click ⇒ FlyoutMenu.ShowPopup) — لوحة منزلقة 320×611 فيها:
     [تعديل فاتورة] [حذف فاتورة] ……… [إختيار الحقول]
     اسم الفرع * ، اسم المخزن * ، التاريخ ، تبدأ بــ + الرقم * ، نموزج الفاتورة ، حاله الفاتورة ، رقم المرجع # ، الملاحظات
   تعديل/حذف فاتورة ⇒ «بحث عن تعامل» (FrmFindInvoice: الرقم ⇒ التاريخ + الاسم ⇒ موافق) ثم التعديل أو الحذف.
   إختيار الحقول ⇒ Customization (أعمدة الفاتورة). القيم تُحفظ لكل تبويب فاتورة وتُرسل مع الحفظ (__salePayloadHook). */
(function () {
  "use strict";
  if (window.__SFO) return;
  const $ = (s, r) => (r || document).querySelector(s);
  const E = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const RM = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
  const pad = x => String(x).padStart(2, "0");
  const nowHM = () => { const d = new Date(); return pad(d.getHours()) + ":" + pad(d.getMinutes()); };
  const hm12 = t => { const [h, mi] = String(t || nowHM()).split(":").map(Number); return (h % 12 || 12) + ":" + pad(mi || 0) + " " + (h < 12 ? "ص" : "م"); };
  const hh12 = t => { const x = hm12(t).split(" ")[0].split(":"); return pad(x[0]) + ":" + x[1]; };
  const isOrig = m => !!(m && m.orig && (m.date || today()) === (m.orig.date || today()) && m.time === m.orig.time);
  const today = () => { const d = new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); };
  const fmt = v => (Math.round((+v || 0) * 100) / 100).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const PG = (k, d) => { try { return (window.ANOUER_PROPS && ANOUER_PROPS.get(k, d)) || d; } catch (_) { return d; } };
  const PP = (k, v) => { try { if (window.ANOUER_PROPS) return ANOUER_PROPS.put(k, v); } catch (_) {} };
  const say = (m, k) => { try { toast(m, k || "i"); } catch (_) {} };
  let LIN = false; try { LIN = CSS.supports("animation-timing-function", "linear(0, 1)"); } catch (_) {}
  const SPR = (() => { if (!LIN) return "cubic-bezier(.2,1.1,.35,1)"; let x = 0, v = 0; const a = []; for (let i = 0; i <= 66; i++) { v += (-200 * (x - 1) - 24 * v) / 60; x += v / 60; a.push(x); } const p = []; for (let i = 0; i <= 44; i++) p.push(+a[Math.round(i * 66 / 44)].toFixed(4)); p[44] = 1; return "linear(" + p.join(",") + ")"; })();

  const css = `
.sfo{position:fixed;top:0;bottom:0;margin:0;inset-inline-end:auto;left:46px;right:auto;height:100vh;max-height:100vh;width:340px;max-width:92vw;padding:0;border:0;background:transparent;overflow:visible;direction:rtl;font-family:"Segoe UI",Tahoma,Arial,sans-serif;color:#1f2933;outline:0}
.sfo::backdrop{background:rgba(15,23,42,.22);backdrop-filter:blur(2px);transition:background .25s,backdrop-filter .25s}
@starting-style{.sfo[open]::backdrop{background:rgba(15,23,42,0);backdrop-filter:blur(0)}}
.sfo.closing::backdrop{background:rgba(15,23,42,0);backdrop-filter:blur(0)}
.sfo-p{height:100%;background:#fff;box-shadow:18px 0 50px -18px rgba(15,23,42,.45),1px 0 0 #dfe4ea;display:flex;flex-direction:column;will-change:transform}
.sfo-tb{display:flex;gap:6px;padding:10px 12px 8px;border-bottom:1px solid #eef1f4;background:linear-gradient(#fbfcfd,#f5f7fa);align-items:stretch}
.sfo-tb .sp{flex:1}
.sfo-k{width:70px;height:54px;border:1px solid #d9dfe6;border-radius:10px;background:#fff;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;font:600 11.5px "Segoe UI",Tahoma;color:#2f3a45;transition:transform .2s cubic-bezier(.3,1.6,.5,1),box-shadow .2s,border-color .15s,background .15s}
.sfo-k:hover{transform:translateY(-2px);box-shadow:0 8px 16px -10px rgba(15,23,42,.45);border-color:#a9c9ef}
.sfo-k:active{transform:translateY(0) scale(.97)}
.sfo-k:focus-visible{outline:2px solid #1a8cff;outline-offset:2px}
.sfo-k svg{width:22px;height:22px}
.sfo-k.dl{color:#b42318}.sfo-k.dl:hover{border-color:#f0b3ac;background:#fff8f7}
.sfo-b{flex:1;overflow:auto;padding:6px 18px 14px;scrollbar-width:thin}
.sfo-f{position:relative;margin-top:12px}
.sfo-f>label{display:block;font-size:12.5px;color:#3d4753;margin-bottom:3px;text-align:right}
.sfo-f .rq{position:absolute;left:-12px;bottom:10px;color:#d22;font-size:13px}
.sfo-f select,.sfo-f input,.sfo-f textarea{width:100%;box-sizing:border-box;border:0;border-bottom:1px solid #b9c0c9;background:transparent;padding:7px 4px;font:14px "Segoe UI",Tahoma;outline:0;direction:rtl;border-radius:0;transition:border-color .15s,box-shadow .15s,background .15s}
.sfo-f select{cursor:pointer}
.sfo-f select:focus,.sfo-f input:focus,.sfo-f textarea:focus{border-color:#1a8cff;box-shadow:0 1px 0 #1a8cff;background:#f8fbff}
.sfo-f textarea{min-height:56px;resize:vertical;border:1px solid #cfd6de;border-radius:8px;padding:8px 10px}
.sfo-f textarea:focus{box-shadow:0 0 0 3px rgba(26,140,255,.14)}
.sfo-f input[readonly]{color:#6b7684}
.sfo-two{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:end}
.sfo-two .sfo-f{margin-top:0}
.sfo-num{direction:ltr!important;text-align:left;font-family:Consolas,"Segoe UI",monospace!important;font-weight:600}
.sfo-ref{display:flex;align-items:center;gap:4px;border-bottom:1px solid #b9c0c9;transition:border-color .15s}
.sfo-ref:focus-within{border-color:#1a8cff;box-shadow:0 1px 0 #1a8cff}
.sfo-ref input{border:0!important;box-shadow:none!important}
.sfo-ref button{width:28px;height:28px;flex:0 0 auto;border:0;border-radius:7px;background:none;color:#1a6fd0;cursor:pointer;display:grid;place-items:center}
.sfo-ref button:hover{background:#eef5ff}
.sfo-chip{display:inline-flex;align-items:center;gap:6px;font-size:11.5px;color:#56616d;background:#f4f6f9;border:1px solid #e6eaef;border-radius:20px;padding:2px 9px;margin-top:6px}
.sfo-chip.ch{color:#1d4f8f;background:#eef5ff;border-color:#cfe0f5}
.sfo-dt{display:flex;align-items:center;border-bottom:1px solid #b9c0c9;transition:border-color .15s,box-shadow .15s,background .15s;border-radius:6px 6px 0 0}
.sfo-dt:focus-within{border-color:#1a8cff;box-shadow:0 1px 0 #1a8cff;background:#f8fbff}
.sfo-f .sfo-dt input{border:0!important;box-shadow:none!important;background:transparent!important}
.sfo-dt .d{flex:1.4;min-width:0}
.sfo-dt .sep{width:1px;align-self:stretch;margin:7px 2px;background:linear-gradient(#0000,#d5dce4 20%,#d5dce4 80%,#0000)}
.sfo-tm{flex:1;min-width:0;display:flex;align-items:center;gap:4px;padding-inline-start:6px;position:relative}
.sfo-tm svg{width:15px;height:15px;flex:none;color:#1a6fd0}
.sfo-f .sfo-tm input{direction:ltr;text-align:left;font-family:Consolas,"Segoe UI",monospace;font-weight:600;letter-spacing:.3px;padding-inline:2px;min-width:0}
.sfo-tm .ap{flex:none;border:1px solid #cfe0f5;font:700 12px "Segoe UI",Tahoma;color:#1a6fd0;background:#eef5ff;border-radius:6px;padding:2px 7px;cursor:pointer;transition:background .15s,transform .12s}
.sfo-tm .ap:hover{background:#dcebff}.sfo-tm .ap:active{transform:scale(.94)}
.sfo-f .sfo-tm input{font-size:15px}
.sfo-chips{display:flex;flex-wrap:wrap;gap:6px}
.sfo-chip.lv{color:#127a3e;background:#ecf8f0;border-color:#cfeadb}
.sfo-chip.lv i{width:7px;height:7px;border-radius:50%;background:#1fae5b;box-shadow:0 0 0 0 rgba(31,174,91,.5);animation:sfoPulse 1.8s infinite}
@keyframes sfoPulse{0%{box-shadow:0 0 0 0 rgba(31,174,91,.45)}70%{box-shadow:0 0 0 6px rgba(31,174,91,0)}100%{box-shadow:0 0 0 0 rgba(31,174,91,0)}}
.sfo-chip.og{color:#1d4f8f;background:#eef5ff;border-color:#cfe0f5}.sfo-chip.og svg{width:13px;height:13px}
.sfo-chip.mn{color:#8a5a00;background:#fff6e5;border-color:#f6e0b4}
.sfo-chip button{all:unset;cursor:pointer;color:#1a6fd0;font-weight:600;padding:0 2px;border-radius:4px}
.sfo-chip button:hover{background:#dfeeff}
@media (prefers-reduced-motion:reduce){.sfo-chip.lv i{animation:none}}
.sfo-ft{display:flex;align-items:center;gap:8px;padding:10px 14px;border-top:1px solid #eef1f4;font-size:11.5px;color:#8a95a3}
.sfo-ft .sp{flex:1}
.sfo-ft button{height:32px;padding:0 14px;border-radius:8px;border:1px solid #c9d1da;background:#fff;cursor:pointer;font:600 12.5px "Segoe UI",Tahoma;color:#2f3a45}
.sfo-ft button:hover{background:#f4f6f9}
.sfo-ft kbd{font:10.5px Arial;border:1px solid #d5dbe2;border-bottom-width:2px;border-radius:4px;padding:0 4px;background:#fff;color:#56616d}
/* ☰ يتحول إلى ✕ */
.lside .ic.sfo-on{background:#eaf2fd}
.sfo-hb line{transition:transform .35s cubic-bezier(.3,1.4,.5,1),opacity .2s;transform-origin:14px 11px}
.ic.sfo-on .sfo-hb .l1{transform:translateY(8px) rotate(45deg)}
.ic.sfo-on .sfo-hb .l2{opacity:0;transform:scaleX(.2)}
.ic.sfo-on .sfo-hb .l3{transform:translateY(-8px) rotate(-45deg)}
/* «بحث عن تعامل» */
.sff{position:fixed;inset:0;margin:auto;width:max-content;height:max-content;padding:0;border:0;background:transparent;max-width:none;max-height:none;direction:rtl;font-family:"Segoe UI",Tahoma,Arial,sans-serif;color:#1f2933;outline:0}
.sff::backdrop{background:rgba(15,23,42,.35);backdrop-filter:blur(3px)}
.sff-c{width:400px;max-width:92vw;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 30px 70px -14px rgba(15,23,42,.55)}
.sff[open] .sff-c{animation:sffIn .45s cubic-bezier(.2,1.25,.35,1)}
@keyframes sffIn{from{opacity:0;transform:translateY(14px) scale(.95)}}
.sff-h{display:flex;align-items:center;gap:10px;padding:14px 18px;border-bottom:1px solid #eef1f4;background:linear-gradient(#fbfcfd,#f4f6f9)}
.sff-h i{width:34px;height:34px;border-radius:10px;display:grid;place-items:center;background:#e8f2ff;color:#1a6fd0}
.sff-h i.dl{background:#fdecec;color:#c62828}
.sff-h b{font-size:15px;flex:1}
.sff-h .x{border:0;background:none;width:30px;height:30px;border-radius:8px;cursor:pointer;color:#7b8794}.sff-h .x:hover{background:#fdecec;color:#c00}
.sff-b{padding:16px 18px 6px}
.sff-s{display:flex;align-items:center;gap:8px}
.sff-s label{font-size:13px;width:44px}
.sff-s .in{flex:1;display:flex;align-items:center;border:1px solid #cfd6de;border-radius:10px;overflow:hidden;transition:border-color .15s,box-shadow .15s}
.sff-s .in:focus-within{border-color:#1a8cff;box-shadow:0 0 0 3px rgba(26,140,255,.15)}
.sff-s input{flex:1;border:0;outline:0;height:40px;padding:0 12px;font:600 16px Consolas,"Segoe UI",monospace;direction:ltr;text-align:left;min-width:0}
.sff-s button{width:42px;height:40px;border:0;border-inline-start:1px solid #e3e8ee;background:#f6f9fc;color:#1a6fd0;cursor:pointer}
.sff-s button:hover{background:#eaf2fd}
.sff-s .in.bad{border-color:#d22;animation:sffSh .32s}
@keyframes sffSh{25%,75%{transform:translateX(-4px)}50%{transform:translateX(4px)}}
.sff-r{margin-top:14px;border:1px solid #e6eaef;border-radius:10px;padding:10px 12px;display:grid;grid-template-columns:auto 1fr;gap:6px 14px;font-size:13px;background:#fafbfc}
.sff-r[hidden]{display:none}
.sff-r.on{animation:sffIn .35s cubic-bezier(.2,1.2,.35,1)}
.sff-r span{color:#6b7684}.sff-r b{font-weight:600}
.sff-m{min-height:18px;font-size:12px;color:#b42318;margin-top:8px}
.sff-f{display:flex;gap:8px;padding:12px 18px 16px}
.sff-f .sp{flex:1}
.sff-f button{height:38px;padding:0 18px;border-radius:9px;border:1px solid #1580d8;background:linear-gradient(#45b5ff,#0a82e3);color:#fff;font:600 13px "Segoe UI",Tahoma;cursor:pointer}
.sff-f button:disabled{opacity:.45;cursor:not-allowed}
.sff-f button.dl{border-color:#b71c1c;background:linear-gradient(#ef5350,#d32f2f)}
.sff-f button.gh{background:#fff;color:#2f3a45;border-color:#c9d1da}
@media (prefers-reduced-motion:reduce){.sfo *,.sff *,.sfo-hb line{animation:none!important;transition:none!important}}`;
  const st = document.createElement("style"); st.id = "sfoStyle"; st.textContent = css; document.head.appendChild(st);

  const I = {
    edit: '<svg viewBox="0 0 24 24"><path d="M5 3h9l5 5v13H5z" fill="#e8f2ff" stroke="#1a6fd0" stroke-width="1.6" stroke-linejoin="round"/><path d="M9 16l1-3 6-6 2 2-6 6z" fill="#1a6fd0"/></svg>',
    del: '<svg viewBox="0 0 24 24"><path d="M5 3h9l5 5v13H5z" fill="#fdecec" stroke="#c62828" stroke-width="1.6" stroke-linejoin="round"/><path d="M9.5 11.5l5 5M14.5 11.5l-5 5" stroke="#c62828" stroke-width="1.8" stroke-linecap="round"/></svg>',
    cols: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2" fill="#eef1f5" stroke="#4b5563" stroke-width="1.5"/><path d="M9 4v16M15 4v16" stroke="#4b5563" stroke-width="1.5"/><path d="M3 9h18" stroke="#4b5563" stroke-width="1.5"/><circle cx="18" cy="17" r="4" fill="#1a6fd0"/><path d="M18 15v4M16 17h4" stroke="#fff" stroke-width="1.5"/></svg>',
    search: '<svg width="16" height="16" viewBox="0 0 16 16"><circle cx="7" cy="7" r="5.2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M11 11l3.6 3.6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    rcpt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"><path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.2 2"/></svg>',
    x: '<svg width="13" height="13" viewBox="0 0 13 13"><path d="M2 2l9 9M11 2l-9 9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'
  };

  /* ---------- الحالة لكل تبويب فاتورة ---------- */
  const T = () => window.__tabs;
  const tab = () => { const t = T(); return t && t.TABS.find(x => x.key === t.ACTIVE); };
  const isRet = () => { const tb = tab(); return !!(tb && tb.ret) || !!document.querySelector(".inv.retmode"); };
  const dealName = () => isRet() ? "مرتجع مبيعات" : "مبيعات";
  /* «06:19:33 م» ← «18:19» */
  const to24 = t => { const g = /(\d{1,2}):(\d{2})(?::\d{2})?\s*(ص|م|AM|PM)?/i.exec(String(t || "")); if (!g) return ""; let h = +g[1] % 24; const a = (g[3] || "").toLowerCase(); if (a === "م" || a === "pm") h = h % 12 + 12; else if (a === "ص" || a === "am") h = h % 12; return pad(h) + ":" + g[2]; };
  /* فاتورة مفتوحة للتعديل: تاريخها ووقت خروجها الأصليان */
  const origOf = tb => { try { const r = (window.SALES_DATA || []).find(x => String(x.no) === String(tb.edit)); return r ? { date: r.date || "", time: to24(r.time) } : null; } catch (_) { return null; } };
  const meta = () => { const tb = tab(); if (!tb) return {}; if (!tb.sfo) { const o = tb.edit ? origOf(tb) : null; tb.sfo = { orig: o,  branch: "", date: "", time: "", pre: null, num: "", form: "", state: "", po: "", note: "" }; if (o) { tb.sfo.date = o.date && o.date !== today() ? o.date : ""; tb.sfo.time = o.time; } } return tb.sfo; };
  let BR = null;
  async function branches() {
    if (BR) return BR;
    BR = [{ id: "", name: "الفرع الرئيسي" }];
    try { if (window.Anouer && Anouer.call) { const l = await Anouer.call("fm.branches.list"); const a = (l || []).filter(b => b && b.IsActive !== false).map(b => ({ id: String(b.BranchId), name: b.Name })); if (a.length) BR = a; } } catch (_) {}
    return BR;
  }
  /* سياسة الترقيم (الخصائص ← الفواتير ← سياسة ترقيم الفواتير) */
  function prefixes() {
    const out = [{ v: "", t: "—", auto: true }], seen = new Set([""]);
    try { (PG("inv.numbering", []) || []).filter(p => p && p.active !== false).forEach(p => { const g = (p.grid || {})[dealName()] || {}; const pre = String(g.pre || ""); if (!seen.has(pre)) { seen.add(pre); out.push({ v: pre, t: pre || "—", auto: g.auto !== false, start: +g.start || 1, name: p.name }); } }); } catch (_) {}
    return out;
  }
  const FORMS = ["Clean", "Simple", "Professional", "Advanced"];
  function states() {
    const all = PG("inv.states", {}) || {}, l = (all[dealName()] || [{ name: "Draft", type: "Draft", active: true, def: true }]).filter(s => s.active !== false);
    return l.length ? l : [{ name: "Draft", def: true }];
  }
  function nextNo() { try { return String(invCounter); } catch (_) { return ""; } }

  /* ---------- البناء ---------- */
  const dlg = document.createElement("dialog"); dlg.className = "sfo"; dlg.id = "sfo"; dlg.setAttribute("aria-label", "الخصائص");
  document.body.appendChild(dlg);
  let hb = null;
  async function render() {
    const m = meta(), brs = await branches(), pres = prefixes(), sts = states();
    if (m.pre == null) m.pre = (pres[1] || pres[0]).v;
    if (!m.form) m.form = (PG("inv.types", {}) || {}).sel || "Simple";
    if (!m.state) m.state = ((sts.find(s => s.def) || sts[0]) || {}).name || "";
    if (!m.branch) m.branch = brs[0].id;
    const wh = $("#saleWh"), P = pres.find(p => p.v === m.pre) || pres[0], ret = isRet();
    dlg.innerHTML = `<div class="sfo-p" id="sfoP" tabindex="-1">
 <div class="sfo-tb">
  <button type="button" class="sfo-k" data-a="edit" title="تعديل فاتورة محفوظة">${I.edit}تعديل فاتورة</button>
  <button type="button" class="sfo-k dl" data-a="del" title="حذف فاتورة محفوظة">${I.del}حذف فاتورة</button>
  <span class="sp"></span>
  <button type="button" class="sfo-k" data-a="cols" title="إختيار الحقول (أعمدة الفاتورة)">${I.cols}إختيار الحقول</button>
 </div>
 <div class="sfo-b">
  <div class="sfo-f"><label for="sfoBr">اسم الفرع</label><select id="sfoBr">${brs.map(b => `<option value="${E(b.id)}"${b.id === m.branch ? " selected" : ""}>${E(b.name)}</option>`).join("")}</select><span class="rq">*</span></div>
  <div class="sfo-f"><label for="sfoWh">اسم المخزن</label><select id="sfoWh">${wh ? wh.innerHTML : "<option>المخزن الرئيسي</option>"}</select><span class="rq">*</span></div>
  <div class="sfo-f"><label for="sfoDt">التاريخ والوقت</label><div class="sfo-dt"><input type="date" class="d" id="sfoDt" value="${E(m.date || today())}" max="${today()}"><span class="sep"></span><span class="sfo-tm" title="وقت الفاتورة — يتبع الساعة تلقائياً، أو اكتب وقتاً آخر">${I.clock}<input type="text" id="sfoTm" inputmode="numeric" maxlength="5" autocomplete="off" spellcheck="false" value="${E(hh12(m.time))}" aria-label="الوقت (ساعة:دقيقة)"><button type="button" class="ap" id="sfoAp" title="صباحاً / مساءً">${E(hm12(m.time).split(" ")[1])}</button></span></div>
   <div class="sfo-chips">${m.date && m.date !== today() && !m.orig ? '<span class="sfo-chip ch">تاريخ مختلف عن اليوم</span>' : ""}${isOrig(m) ? `<span class="sfo-chip og">${I.rcpt}وقت خروج الفاتورة ${E(hm12(m.time))}</span>` : m.orig ? `<span class="sfo-chip mn">تغيير وقت الفاتورة ← ${E(hm12(m.time || nowHM()))}<button type="button" data-a="orig" title="الرجوع لوقت خروج الفاتورة الأصلي">↺ الأصلي ${E(hm12(m.orig.time))}</button></span>` : m.time ? `<span class="sfo-chip mn">وقت يدوي ${E(hm12(m.time))}<button type="button" data-a="now" title="الرجوع لوقت الساعة">↺ الآن</button></span>` : '<span class="sfo-chip lv"><i></i>وقت الفاتورة = لحظة الحفظ</span>'}</div></div>
  <div class="sfo-f sfo-two"><div class="sfo-f"><label for="sfoPre">تبدأ بــ</label><select id="sfoPre">${pres.map(p => `<option value="${E(p.v)}"${p.v === m.pre ? " selected" : ""}>${E(p.t)}</option>`).join("")}</select></div>
   <div class="sfo-f"><label for="sfoNo">الرقم</label><input id="sfoNo" class="sfo-num" inputmode="numeric" autocomplete="off" value="${E(m.num)}" placeholder="${E(nextNo())}"${P.auto && !m.num ? ' title="ترقيم تلقائي — اتركه فارغاً ليُعطى الرقم التالي"' : ""}><span class="rq">*</span></div></div>
  <div class="sfo-f"><label for="sfoForm">نموزج الفاتورة</label><select id="sfoForm">${FORMS.map(f => `<option${f === m.form ? " selected" : ""}>${f}</option>`).join("")}</select></div>
  <div class="sfo-f"><label for="sfoSt">حاله الفاتورة</label><select id="sfoSt">${sts.map(s => `<option${s.name === m.state ? " selected" : ""}>${E(s.name)}</option>`).join("")}</select></div>
  <div class="sfo-f"><label for="sfoPo">رقم المرجع #</label><div class="sfo-ref"><input id="sfoPo" autocomplete="off" value="${E(ret ? (($("#refNo") || {}).value || "") : m.po)}"${ret ? " readonly" : ""} placeholder="${ret ? "اضغط البحث لاختيار الفاتورة المرتجعة" : ""}"><button type="button" data-a="ref" title="${ret ? "اختيار الفاتورة المراد إرتجاعها" : "بحث عن تعامل"}">${I.search}</button></div></div>
  <div class="sfo-f"><label for="sfoNt">الملاحظات</label><textarea id="sfoNt" maxlength="400">${E(m.note)}</textarea></div>
 </div>
 <div class="sfo-ft"><span><kbd>Esc</kbd> إغلاق</span><span class="sp"></span><button type="button" data-a="close">تم</button></div>
</div>`;
    const sw = $("#sfoWh", dlg); if (wh) sw.value = wh.value;
    wire();
  }
  function wire() {
    const m = meta();
    $("#sfoBr", dlg).onchange = e => { m.branch = e.target.value; };
    $("#sfoWh", dlg).onchange = e => { const w = $("#saleWh"); if (w) { w.value = e.target.value; w.dispatchEvent(new Event("change", { bubbles: true })); } };
    $("#sfoDt", dlg).onchange = e => { m.date = e.target.value && e.target.value !== today() ? e.target.value : ""; if (m.orig && !m.time) m.time = nowHM(); render().then(() => $("#sfoDt", dlg).focus()); };
    { const t = $("#sfoTm", dlg), ap = $("#sfoAp", dlg);
      const set = v => { m.time = v && (m.orig || v !== nowHM()) ? v : ""; render().then(() => { const x = $("#sfoTm", dlg); if (x) x.focus(); }); };
      const parse = () => { const g = /^(\d{1,2}):?(\d{2})$/.exec(t.value.trim()); if (!g) return null; let h = +g[1], mi = +g[2]; if (h < 1 || h > 12 || mi > 59) return null; const pm = ap.textContent.trim() === "م"; h = h % 12 + (pm ? 12 : 0); return pad(h) + ":" + pad(mi); };
      t.oninput = () => { let v = t.value.replace(/[^\d]/g, "").slice(0, 4); if (v.length > 2) v = v.slice(0, v.length - 2) + ":" + v.slice(-2); t.value = v; };
      t.onchange = () => { const v = parse(); if (v) set(v); else { t.value = hh12(m.time); say("اكتب الوقت هكذا 06:30", "w"); } };
      t.onkeydown = e => { if (e.key === "Enter") { e.preventDefault(); t.blur(); } };
      ap.onclick = () => { const [h, mi] = (m.time || nowHM()).split(":").map(Number); set(pad((h + 12) % 24) + ":" + pad(mi)); };
      const nb = dlg.querySelector('[data-a="now"]'); if (nb) nb.onclick = () => { m.time = ""; render(); };
      const ob = dlg.querySelector('[data-a="orig"]'); if (ob) ob.onclick = () => { m.date = m.orig.date && m.orig.date !== today() ? m.orig.date : ""; m.time = m.orig.time; render(); }; }
    $("#sfoPre", dlg).onchange = e => { m.pre = e.target.value; };
    $("#sfoNo", dlg).oninput = e => { e.target.value = e.target.value.replace(/[^\d]/g, ""); m.num = e.target.value; const i = $("#invNo"); if (i) i.value = m.num; };
    $("#sfoForm", dlg).onchange = e => { m.form = e.target.value; PP("inv.types", Object.assign({}, PG("inv.types", {}) || {}, { sel: m.form })); };
    $("#sfoSt", dlg).onchange = e => { m.state = e.target.value; };
    $("#sfoPo", dlg).oninput = e => { if (!isRet()) m.po = e.target.value; };
    $("#sfoNt", dlg).oninput = e => { m.note = e.target.value; };
  }
  dlg.addEventListener("click", e => {
    if (e.target === dlg) { close(); return; }
    const b = e.target.closest("[data-a]"); if (!b) return;
    const a = b.dataset.a;
    if (a === "close") return close();
    if (a === "cols") { const r = b.getBoundingClientRect(); close().then(() => { try { igChooser(r.right + 160, r.top + 30); } catch (_) { say("«إختيار الحقول» غير متاح", "w"); } }); return; }
    if (a === "edit" || a === "del") { close().then(() => findInvoice(a)); return; }
    if (a === "ref") { if (isRet()) { close().then(() => { try { openRef(); } catch (_) {} }); } else close().then(() => findInvoice("view")); return; }
  });
  dlg.addEventListener("cancel", e => { e.preventDefault(); close(); });

  /* الوقت المباشر: يتحدّث كل 15 ثانية ما دام الوقت غير مكتوب يدوياً */
  setInterval(() => { try { if (!dlg.open) return; const m = meta(); if (m.time) return; const t = $("#sfoTm", dlg); if (t && document.activeElement !== t && t.value !== hh12()) { t.value = hh12(); const a = $("#sfoAp", dlg); if (a) a.textContent = hm12().split(" ")[1]; } } catch (_) {} }, 15000);
  async function open(ev) {
    const tb = tab(); if (!tb || tb.view !== "sales") return;
    if (dlg.open) return close();
    hb = ev && ev.currentTarget && ev.currentTarget.nodeType === 1 ? ev.currentTarget : $("[data-sfo]");
    await render();
    // DEXEF: FlyoutMenu.Options.AnchorType = يمين/يسار حسب الاتجاه ⇒ بجوار الشريط الأيسر
    const ls = $(".lside"); if (ls) { const r = ls.getBoundingClientRect(); dlg.style.left = Math.round(r.right) + "px"; dlg.style.top = Math.round(r.top) + "px"; dlg.style.height = Math.round(r.height) + "px"; }
    dlg.classList.remove("closing"); dlg.showModal();
    if (hb) hb.classList.add("sfo-on");
    const p = $("#sfoP", dlg);
    if (!RM()) { p.animate([{ transform: "translateX(-104%)" }, { transform: "none" }], { duration: 560, easing: SPR }); [...p.querySelectorAll(".sfo-f,.sfo-k")].forEach((x, i) => x.animate([{ opacity: 0, transform: "translateX(-14px)" }, { opacity: 1, transform: "none" }], { duration: 380, delay: 60 + i * 28, easing: "cubic-bezier(.2,1,.3,1)", fill: "backwards" })); }
    p.focus({ preventScroll: true });
  }
  function close() {
    if (!dlg.open) return Promise.resolve();
    dlg.classList.add("closing"); if (hb) hb.classList.remove("sfo-on");
    const p = $("#sfoP", dlg), fin = () => { dlg.close(); dlg.classList.remove("closing"); };
    if (RM() || !p) { fin(); return Promise.resolve(); }
    return p.animate([{ transform: "none" }, { transform: "translateX(-104%)" }], { duration: 240, easing: "cubic-bezier(.55,0,.75,.2)", fill: "forwards" }).finished.then(fin, fin);
  }

  /* ---------- «بحث عن تعامل» (FrmFindInvoice) ---------- */
  const fd = document.createElement("dialog"); fd.className = "sff"; fd.id = "sff"; document.body.appendChild(fd);
  let FD = { mode: "edit", rec: null };
  function findInvoice(mode) {
    FD = { mode, rec: null };
    const del = mode === "del";
    fd.innerHTML = `<div class="sff-c"><div class="sff-h"><i class="${del ? "dl" : ""}">${del ? I.del.replace("viewBox", 'width="20" height="20" viewBox') : I.edit.replace("viewBox", 'width="20" height="20" viewBox')}</i><b>بحث عن تعامل</b><button type="button" class="x" data-f="x" aria-label="إغلاق">${I.x}</button></div>
 <div class="sff-b"><div class="sff-s"><label for="sffN">الرقم</label><div class="in" id="sffIn"><input id="sffN" inputmode="numeric" autocomplete="off" placeholder="رقم الفاتورة"><button type="button" data-f="find" title="بحث (Enter)">${I.search}</button></div></div>
  <div class="sff-r" id="sffR" hidden><span>التاريخ</span><b id="sffD"></b><span>الاسم</span><b id="sffNm"></b><span>الإجمالي</span><b id="sffT"></b></div><div class="sff-m" id="sffM"></div></div>
 <div class="sff-f"><button type="button" class="${del ? "dl" : ""}" data-f="ok" id="sffOk" disabled>${del ? "حذف" : mode === "view" ? "موافق" : "موافق"}</button><span class="sp"></span><button type="button" class="gh" data-f="x">إغلاق</button></div></div>`;
    fd.showModal(); setTimeout(() => $("#sffN", fd).focus(), 30);
  }
  /* FindData: البحث بالرقم */
  function findData() {
    const v = $("#sffN", fd).value.trim(), box = $("#sffIn", fd), msg = $("#sffM", fd), R = $("#sffR", fd);
    const L = window.SALES_DATA || [];
    const r = v && L.find(x => String(x.no) === v);
    FD.rec = r || null; $("#sffOk", fd).disabled = !r;
    if (!r) { R.hidden = true; msg.textContent = v ? "لا توجد فاتورة بالرقم " + v : "أدخل رقم الفاتورة"; box.classList.remove("bad"); void box.offsetWidth; box.classList.add("bad"); try { ANOUER_SOUND("err"); } catch (_) {} return; }
    msg.textContent = ""; $("#sffD", fd).textContent = (r.date || "") + (r.time ? "  " + r.time : ""); $("#sffNm", fd).textContent = r.name || "تعامل نقدى"; $("#sffT", fd).textContent = fmt(r.total) + " دج";
    R.hidden = false; R.classList.remove("on"); void R.offsetWidth; R.classList.add("on"); $("#sffOk", fd).focus();
  }
  fd.addEventListener("click", e => {
    if (e.target === fd) { fd.close(); return; }
    const b = e.target.closest("[data-f]"); if (!b) return;
    if (b.dataset.f === "x") return fd.close();
    if (b.dataset.f === "find") return findData();
    if (b.dataset.f === "ok" && FD.rec) { const r = FD.rec; fd.close(); if (FD.mode === "del") { if (window.__srDel) window.__srDel(r); else say("الحذف غير متاح", "e"); } else if (FD.mode === "edit") { if (window.__srEdit) window.__srEdit(r); else say("التعديل غير متاح", "e"); } else { const m = meta(); m.po = String(r.no); } }
  });
  fd.addEventListener("cancel", e => { e.preventDefault(); fd.close(); });

  /* ---------- لوحة المفاتيح (حاجز الصفحة ⇒ سلسلة __viewKey) ---------- */
  const prevVK = window.__viewKey;
  window.__viewKey = function (e) {
    if (fd.open) {
      if (e.key === "Escape") { fd.close(); return true; }
      if (e.key === "Enter") { const a = document.activeElement; if (a && a.id === "sffN") { e.preventDefault(); findData(); return true; } if (a && a.closest && a.closest("[data-f]")) { a.click(); return true; } if (FD.rec) { $("#sffOk", fd).click(); return true; } return true; }
      return false;
    }
    if (dlg.open) {
      if (e.key === "Escape") { close(); return true; }
      return false;
    }
    return prevVK ? prevVK(e) : false;
  };

  /* ---------- الحفظ: الفرع ، التاريخ ، الرقم ، الحالة ، المرجع ، الملاحظات ---------- */
  const prevHook = window.__salePayloadHook;
  window.__salePayloadHook = function (pay, ret) {
    if (prevHook) pay = prevHook(pay, ret) || pay;
    window.__sfoKeepDate = false;
    const tb = tab(), m = tb && tb.sfo; if (!m) return pay;
    if (m.branch && /^\d+$/.test(m.branch)) pay.BranchId = +m.branch;
    if (m.orig && isOrig(m)) { /* تعديل بدون تغيير الوقت: يبقى تاريخ ووقت الفاتورة الأصليان (fm.sale.redate) */ }
    else if ((m.date && m.date !== today()) || m.time) { if (m.orig) window.__sfoKeepDate = true; const d = new Date(); pay.InvoiceDate = (m.date || today()) + "T" + (m.time ? m.time + ":00" : pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds())); }
    if (m.num && !pay.InvoiceNo) pay.InvoiceNo = (m.pre || "") + m.num;
    const extra = [];
    if (m.po && !ret) extra.push("مرجع: " + m.po);
    const sts = states(), def = (sts.find(s => s.def) || sts[0] || {}).name;
    if (m.state && m.state !== def) extra.push("الحالة: " + m.state);
    if (m.note && m.note.trim()) extra.push(m.note.trim());
    if (extra.length) pay.Notes = [pay.Notes || ""].concat(extra).filter(Boolean).join(" | ").slice(0, 500);
    return pay;
  };
  // بعد الحفظ (الفاتورة تُفرَّغ) تعود الخصائص لقيمها الافتراضية
  try {
    const _ri = resetInv;
    resetInv = function () { const tb = tab(); if (tb) tb.sfo = null; return _ri.apply(this, arguments); };
    window.resetInv = resetInv;
  } catch (_) {}

  /* ---------- ربط أيقونة ☰ ---------- */
  function mount() {
    const ic = document.querySelector(".lside .ic"); if (!ic || ic.dataset.sfo != null) return;
    ic.dataset.sfo = ""; ic.title = "الخصائص"; ic.setAttribute("role", "button"); ic.setAttribute("tabindex", "0"); ic.setAttribute("aria-haspopup", "dialog"); ic.style.cursor = "pointer";
    ic.innerHTML = '<svg class="sfo-hb" width="28" height="22" viewBox="0 0 28 22"><line class="l1" x1="1" y1="3" x2="27" y2="3" stroke="#1a6fd0" stroke-width="2.4" stroke-linecap="round"/><line class="l2" x1="1" y1="11" x2="27" y2="11" stroke="#1a6fd0" stroke-width="2.4" stroke-linecap="round"/><line class="l3" x1="1" y1="19" x2="27" y2="19" stroke="#1a6fd0" stroke-width="2.4" stroke-linecap="round"/></svg>';
    ic.addEventListener("click", open);
    ic.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open({ currentTarget: ic }); } });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount); else mount();
  window.__SFO = { open, close, meta, findInvoice };
})();

/* ANOUER — «شريط أدوات السطر» محصّن (2026-11-24)
   • لا تظليل أزرق: نص سطور الفاتورة وشريط الأزرار غير قابل للتحديد (الخانات تبقى قابلة للكتابة والتحديد بداخلها) ،
     النقر المزدوج/الثلاثي لا يظلّل السطر ، Ctrl+A خارج خانة كتابة لا يظلّل الفاتورة ، وأي تظليل شارد داخل الجدول يُمسح فوراً.
   • حماية من الأخطاء (بدون أي تغيير في شكل الواجهة): الضغط المزدوج غير المقصود يُحسب مرة واحدة
     (Remove لا يحذف سطرين ، + Qty / − Qty / Units / Return …) — الحذف بزر Del ولوحة اللمس بلا تغيير. */
(function () {
  "use strict";
  if (window.__ROWGUARD) return; window.__ROWGUARD = 1;
  const css = `#gbody .gr,#gbody .rowbar,#gbody .rowbar *{-webkit-user-select:none;user-select:none}
#gbody .gr input,#gbody .gr textarea{-webkit-user-select:text;user-select:text}
#gbody .gr :not(input):not(textarea)::selection{background:transparent}`;
  const st = document.createElement("style"); st.id = "rowGuardCss"; st.textContent = css;
  (document.head || document.documentElement).appendChild(st);

  const GB = () => document.getElementById("gbody");
  const editable = el => !!(el && (el.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)));
  const visible = el => !!(el && el.offsetParent !== null);

  /* 1) النقر المزدوج/الثلاثي على السطر أو الشريط لا يبدأ تحديداً */
  document.addEventListener("mousedown", e => {
    const g = GB(); if (!g || e.detail < 2 || !g.contains(e.target) || editable(e.target)) return;
    if (e.target.closest(".gr,.rowbar")) e.preventDefault();
  }, true);

  /* 2) Ctrl+A خارج خانة كتابة على شاشة البيع ← لا يظلّل الصفحة كلها */
  document.addEventListener("keydown", e => {
    if (!(e.ctrlKey || e.metaKey) || (e.key !== "a" && e.key !== "A") || e.shiftKey || e.altKey) return;
    const a = document.activeElement, g = GB(); if (editable(a) || !visible(g)) return;
    if (!a || a === document.body || a === document.documentElement || g.contains(a)) e.preventDefault();
  }, true);

  /* 3) أي تظليل شارد داخل جدول الفاتورة يُمسح (إلا داخل خانة الكتابة النشطة) */
  let selT = 0;
  document.addEventListener("selectionchange", () => {
    if (selT) return; selT = requestAnimationFrame(() => { selT = 0;
      try { const s = getSelection(), g = GB(); if (!s || s.isCollapsed || !s.rangeCount || !g || editable(document.activeElement)) return;
        const r = s.getRangeAt(0); if (r.intersectsNode(g) && (g.contains(s.anchorNode) || g.contains(s.focusNode) || r.commonAncestorContainer.contains(g))) s.removeAllRanges(); } catch (_) { }
    });
  });

  /* 4) حماية أزرار شريط السطر من الضغط المزدوج غير المقصود (Remove لا يحذف سطرين بضغطة مزدوجة) */
  const GAP = { "b-plus": 140, "b-minus": 140, "b-qty": 450, "b-units": 320, "b-ret": 450, "b-clr": 700, "b-rm": 450 };
  let last = { k: "", t: 0 };
  const kindOf = b => { for (const c of b.classList) if (GAP[c]) return c; return "x"; };
  document.addEventListener("click", e => {
    const b = e.target.closest && e.target.closest(".rowbar button"); if (!b) return;
    const g = GB(); if (!g || !g.contains(b)) return;
    const k = kindOf(b), now = performance.now(), gap = GAP[k] || 400;
    if (last.k === k && now - last.t < gap) { e.preventDefault(); e.stopImmediatePropagation(); return; }   /* ضغطة مكرّرة بالخطأ */
    last = { k, t: now };
  }, true);
})();
