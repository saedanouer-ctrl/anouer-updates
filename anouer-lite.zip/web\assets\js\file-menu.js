/* ANOUER — شاشات قائمة «ملف» (مطابقة لترتيب DEXEF ONE)
   تُحمَّل بعد bridge.js و dexef-link.js. تستبدل الشاشات المؤقتة («هذه الشاشة لم تُبنَ بعد»)
   بنوافذ تعمل فعلياً على قاعدة بيانات الشركة عبر الجسر (إجراءات fm.* في HostBridge). */
(function () {
  "use strict";
  var FILE = window.__FILE;
  if (!FILE) { console.warn("file-menu: قائمة ملف غير متاحة"); return; }

  // ------------------------------------------------------------------ أدوات عامة
  var B = function () { return !!(window.Anouer && Anouer.available && Anouer.call); };
  var call = function (a, p) { return Anouer.call(a, p || {}); };
  var T = function (m, k) { try { toast(m, k || "i"); } catch (e) { console.log(m); } };
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return "&#" + c.charCodeAt(0) + ";"; }); };
  var fmt = function (n) { return (Math.round((+n || 0) * 100) / 100).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var needHost = function () { if (B()) return true; T("هذه العملية متاحة داخل برنامج ANOUER فقط", "w"); return false; };
  var fail = function (e) { T((e && e.message) || String(e), "e"); };
  var size = function (b) { b = +b || 0; return b > 1048576 ? (b / 1048576).toFixed(1) + " MB" : (b / 1024).toFixed(0) + " KB"; };

  var IC = {
    co: '<svg viewBox="0 0 20 20" fill="#fff"><path d="M10 .5l3 3H7z"/><path d="M10 19.5l3-3H7z"/><rect x="2" y="5.5" width="16" height="2"/><rect x="2" y="9" width="16" height="2"/><rect x="2" y="12.5" width="16" height="2"/></svg>',
    db: '<svg viewBox="0 0 20 20" fill="none" stroke="#fff" stroke-width="1.8"><ellipse cx="9" cy="4.5" rx="6.5" ry="2.6"/><path d="M2.5 4.5v10c0 1.4 2.9 2.6 6.5 2.6s6.5-1.2 6.5-2.6v-10M2.5 9.5c0 1.4 2.9 2.6 6.5 2.6s6.5-1.2 6.5-2.6"/></svg>',
    br: '<svg viewBox="0 0 20 20" fill="#fff"><rect x="1" y="2" width="5" height="4"/><rect x="1" y="8" width="5" height="4"/><rect x="1" y="14" width="5" height="4"/><rect x="8" y="3" width="11" height="2"/><rect x="8" y="9" width="11" height="2"/><rect x="8" y="15" width="11" height="2"/></svg>',
    prop: '<svg viewBox="0 0 20 20" fill="none" stroke="#fff" stroke-width="1.8"><circle cx="10" cy="10" r="3"/><path d="M10 1.5v3M10 15.5v3M1.5 10h3M15.5 10h3M4 4l2.1 2.1M13.9 13.9L16 16M4 16l2.1-2.1M13.9 6.1L16 4"/></svg>',
    xls: '<svg viewBox="0 0 20 20" fill="none" stroke="#fff" stroke-width="1.7"><rect x="2" y="3" width="16" height="14" rx="1"/><path d="M6 7l4 6M10 7l-4 6M12 8h4M12 12h4"/></svg>',
    mob: '<svg viewBox="0 0 20 20" fill="none" stroke="#fff" stroke-width="1.8"><rect x="5" y="1.5" width="10" height="17" rx="2"/><path d="M9 15.5h2"/></svg>',
    del: '<svg viewBox="0 0 20 20" fill="none" stroke="#fff" stroke-width="1.8"><path d="M3 5h14M8 5V3h4v2M5 5l1 12h8l1-12"/></svg>',
    news: '<svg viewBox="0 0 20 20" fill="none" stroke="#fff" stroke-width="1.8"><rect x="1" y="5" width="18" height="10" rx="3"/><circle cx="6" cy="10" r="1" fill="#fff"/><circle cx="10" cy="10" r="1" fill="#fff"/><circle cx="14" cy="10" r="1" fill="#fff"/></svg>'
  };

  // ------------------------------------------------------------------ نافذة عامة
  var stack = [];
  function win(o) {
    var ov = document.createElement("div");
    ov.className = "fm-ov";
    ov.innerHTML =
      '<div class="fm-win" role="dialog" aria-modal="true" tabindex="-1" style="width:' + (o.width || 560) + 'px">' +
      '<div class="fm-hd"><span class="ic">' + (o.icon || "") + '</span><b>' + esc(o.title) + '</b>' +
      '<button type="button" data-x aria-label="إغلاق">✕</button></div>' +
      '<div class="fm-bd"></div><div class="fm-ft"></div></div>';
    var bd = ov.querySelector(".fm-bd"), ft = ov.querySelector(".fm-ft");
    var w = {
      el: ov, body: bd, foot: ft,
      close: function () {
        if (!ov.parentNode) return; ov.remove(); stack.splice(stack.indexOf(w), 1);
        var top = stack[stack.length - 1]; if (top) top.el.querySelector(".fm-win").focus();
        if (o.onClose) o.onClose();
      },
      $: function (sel) { return bd.querySelector(sel); },
      $$: function (sel) { return Array.prototype.slice.call(bd.querySelectorAll(sel)); },
      setButtons: function (btns) {
        ft.innerHTML = "";
        (btns || []).forEach(function (b) {
          if (b === "|") { var s = document.createElement("span"); s.className = "fm-sp"; ft.appendChild(s); return; }
          var e = document.createElement("button");
          e.type = "button"; e.className = "fm-btn " + (b.cls || ""); e.textContent = b.t;
          if (b.id) e.id = b.id;
          e.addEventListener("click", function () { b.fn(w, e); });
          ft.appendChild(e);
        });
        ft.style.display = ft.children.length ? "" : "none";
      },
      busy: function (on) {
        Array.prototype.forEach.call(ft.querySelectorAll("button"), function (b) { b.disabled = !!on; });
        if (!on && (!document.activeElement || document.activeElement === document.body)) ov.querySelector(".fm-win").focus();
      }
    };
    if (typeof o.body === "string") bd.innerHTML = o.body; else if (o.body) bd.appendChild(o.body);
    w.setButtons(o.buttons);
    ov.querySelector("[data-x]").addEventListener("click", w.close);
    ov.addEventListener("mousedown", function (e) { if (e.target === ov && !o.modal) w.close(); });
    document.body.appendChild(ov);
    stack.push(w);
    // التركيز داخل النافذة (وإلا تحجب اختصارات الصفحة مفتاح Esc عندما يكون التركيز على body)
    setTimeout(function () { var f = bd.querySelector("[autofocus]") || bd.querySelector("input:not([type=checkbox]):not([readonly]),select"); (f || ov.querySelector(".fm-win")).focus(); }, 30);
    return w;
  }
  // Esc يغلق النافذة العليا. بعض اختصارات الصفحة تمنع keydown عندما يكون التركيز على body،
  // لذلك نستخدم keyup كاحتياط إن لم يصلنا keydown لنفس الضغطة.
  var escSeen = false;
  document.addEventListener("keydown", function (e) {
    if (!stack.length || e.key !== "Escape") return;
    escSeen = true; e.preventDefault(); e.stopImmediatePropagation(); stack[stack.length - 1].close();
  }, true);
  window.addEventListener("keyup", function (e) {
    if (e.key !== "Escape") return;
    if (!escSeen && stack.length) stack[stack.length - 1].close();
    escSeen = false;
  }, true);

  function confirmBox(msg, onYes, opts) {
    opts = opts || {};
    win({
      title: opts.title || "تأكيد", icon: opts.icon, width: 440, modal: true,
      body: '<div style="font-size:14px;line-height:1.8;padding:6px 0 10px">' + msg + "</div>",
      buttons: [
        { t: opts.yes || "نعم", cls: opts.danger ? "del" : "ok", fn: function (w) { w.close(); onYes(); } },
        { t: "لا", cls: "no", fn: function (w) { w.close(); } }
      ]
    });
  }

  function field(label, html, req) {
    return '<div class="fm-r"><label>' + (req ? '<span class="fm-req">*</span>' : "") + esc(label) + "</label>" + html + "</div>";
  }

  // ==================================================================== 1+3) الشركات
  function companyForm(entry, onSaved) {
    var isNew = !entry;
    var w = win({
      title: isNew ? "إضافة شركة" : "تعديل بيانات الشركة", icon: IC.co, width: 520,
      body:
        '<div class="fm-sec"><div class="fm-st">بيانات الشركة</div><div class="fm-sb">' +
        field("اسم الشركة", '<input class="fm-in" id="coName" style="width:280px" autocomplete="off" value="' + esc(entry ? entry.Name : "") + '">', true) +
        field("الكود", '<input class="fm-in" id="coCode" style="width:120px;text-align:center" value="' + esc(entry ? entry.Code : "") + '" placeholder="تلقائي">') +
        (isNew ? field("قاعدة البيانات", '<input class="fm-in fm-mono" id="coDb" style="width:220px" placeholder="تلقائي">') :
          field("قاعدة البيانات", '<span class="fm-mono">' + esc(entry.Database) + "</span>")) +
        "</div></div>" +
        (isNew ? '<div class="fm-note">تُنشأ للشركة الجديدة قاعدة بيانات مستقلة بكل الجداول والبيانات الأولية (أنواع الفواتير، الوحدات، الخزينة، الصلاحيات). ' +
          'عند أول دخول إليها يكون المستخدم <b>admin</b> وكلمة المرور <b>admin</b>.</div>' : ""),
      buttons: [
        { t: isNew ? "إضافة الشركة" : "حفظ", cls: "ok", id: "coSave", fn: save },
        { t: "إلغاء", cls: "no", fn: function (w) { w.close(); } }
      ]
    });
    var nm = w.$("#coName"), cd = w.$("#coCode"), dbi = w.$("#coDb");
    if (dbi) {
      var auto = function () {
        if (dbi.dataset.touched) return;
        var c = (cd.value || "").replace(/[^A-Za-z0-9_]/g, "");
        dbi.placeholder = c ? "ANOUER_" + c : "تلقائي";
      };
      cd.addEventListener("input", auto);
      dbi.addEventListener("input", function () { dbi.dataset.touched = dbi.value ? "1" : ""; });
    }
    w.body.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); save(w); } });

    function save(w) {
      if (!nm.value.trim()) { nm.classList.add("err"); nm.focus(); return; }
      if (!needHost()) return;
      w.busy(true);
      var pr = isNew
        ? call("fm.company.create", { name: nm.value.trim(), code: cd.value.trim(), database: dbi ? dbi.value.trim() : "" })
        : call("fm.company.update", { database: entry.Database, name: nm.value.trim(), code: cd.value.trim() });
      if (isNew) T("جارٍ إنشاء قاعدة بيانات الشركة ...", "i");
      pr.then(function (res) {
        w.close();
        if (isNew) {
          T("تمت إضافة الشركة: " + res.Name, "s");
          confirmBox("تم إنشاء الشركة <b>" + esc(res.Name) + "</b> (" + esc(res.Database) + ").<br>هل تريد فتحها الآن؟ سيُعاد تشغيل البرنامج.",
            function () { openCompany(res); }, { title: "إضافة شركة", icon: IC.co });
        } else T("تم حفظ بيانات الشركة", "s");
        if (onSaved) onSaved(res);
      }).catch(function (e) { w.busy(false); fail(e); });
    }
  }

  function openCompany(c) {
    if (!needHost()) return;
    T("جارٍ فتح الشركة " + c.Name + " ...", "i");
    call("fm.company.open", { database: c.Database }).then(function (r) {
      if (r && r.same) T("هذه الشركة مفتوحة بالفعل", "i");
    }).catch(fail);
  }

  /** mode: review | open | delete */
  function companiesWin(mode) {
    if (!needHost()) return;
    var titles = { review: "مراجعة الشركات", open: "فتح شركة", "delete": "حذف شركة" };
    var sel = null, data = null;
    var w = win({
      title: titles[mode], icon: mode === "delete" ? IC.del : IC.co, width: 720,
      body: '<div class="fm-scroll" style="max-height:380px"><table class="fm-tbl"><thead><tr><th style="width:60px">الكود</th><th>اسم الشركة</th><th>قاعدة البيانات</th><th style="width:120px">تاريخ الإنشاء</th><th style="width:100px">الحالة</th>' +
        (mode === "review" ? '<th style="width:60px"></th>' : "") + '</tr></thead><tbody id="coRows"><tr><td colspan="6" class="fm-empty">جارٍ التحميل ...</td></tr></tbody></table></div>' +
        (mode === "delete" ? '<div class="fm-note fm-warn" style="margin-top:10px">لا يمكن حذف الشركة المفتوحة حالياً. يمكنك إزالة الشركة من القائمة فقط، أو حذف قاعدة بياناتها نهائياً.</div>' : "") +
        '<div style="margin-top:8px;color:#666" id="coCnt"></div>',
      buttons: buttons()
    });

    function buttons() {
      var b = [];
      if (mode === "review") {
        b.push({ t: "إضافة شركة", fn: function () { companyForm(null, load); } });
        b.push({ t: "فتح", cls: "ok", fn: function () { if (sel && !sel.IsActive) openCompany(sel); } });
      }
      if (mode === "open") b.push({ t: "فتح الشركة", cls: "ok", id: "coOpen", fn: function () { if (sel && !sel.IsActive) openCompany(sel); } });
      if (mode === "delete") {
        b.push({ t: "حذف نهائي", cls: "del", id: "coDrop", fn: function () { del(true); } });
        b.push({ t: "إزالة من القائمة", cls: "ghost", id: "coRemove", fn: function () { del(false); } });
      }
      b.push({ t: "إغلاق", cls: "no", fn: function (w) { w.close(); } });
      return b;
    }

    function render() {
      var tb = w.$("#coRows");
      if (!data.companies.length) { tb.innerHTML = '<tr><td colspan="6" class="fm-empty">لا توجد شركات</td></tr>'; return; }
      tb.innerHTML = data.companies.map(function (c, i) {
        return '<tr data-i="' + i + '"' + (sel === c ? ' class="sel"' : "") + '><td class="fm-mono">' + esc(c.Code) + "</td><td><b>" + esc(c.Name) + "</b></td>" +
          '<td class="fm-mono">' + esc(c.Database) + "</td><td>" + esc(c.CreatedAt || "") + "</td><td>" +
          (c.IsActive ? '<span class="fm-tag">مفتوحة حالياً</span>' : c.IsDefault ? '<span class="fm-tag gray">الافتراضية</span>' : "") + "</td>" +
          (mode === "review" ? '<td><button type="button" class="fm-lnk" data-ed="' + i + '">تعديل</button></td>' : "") + "</tr>";
      }).join("");
      w.$("#coCnt").textContent = "عدد الشركات: " + data.companies.length;
      var disable = !sel || sel.IsActive;
      ["#coOpen", "#coDrop", "#coRemove"].forEach(function (id) { var b = w.foot.querySelector(id); if (b) b.disabled = disable; });
    }

    w.body.addEventListener("click", function (e) {
      var ed = e.target.closest("[data-ed]");
      if (ed) { companyForm(data.companies[+ed.dataset.ed], load); return; }
      var tr = e.target.closest("tr[data-i]");
      if (tr) { sel = data.companies[+tr.dataset.i]; render(); }
    });
    w.body.addEventListener("dblclick", function (e) {
      var tr = e.target.closest("tr[data-i]");
      if (tr && mode !== "delete") { var c = data.companies[+tr.dataset.i]; if (!c.IsActive) openCompany(c); }
    });

    function del(drop) {
      if (!sel || sel.IsActive) return;
      var c = sel;
      confirmBox(drop
        ? "سيتم <b>حذف قاعدة بيانات</b> الشركة «" + esc(c.Name) + "» (" + esc(c.Database) + ") <b>نهائياً</b> بكل فواتيرها وأصنافها وعملائها.<br>لا يمكن التراجع عن هذه العملية. هل أنت متأكد؟"
        : "إزالة الشركة «" + esc(c.Name) + "» من قائمة الشركات فقط؟ (تبقى قاعدة بياناتها على الخادم)",
        function () {
          w.busy(true);
          call("fm.company.delete", { database: c.Database, dropDatabase: drop }).then(function () {
            T(drop ? "تم حذف الشركة نهائياً" : "تمت إزالة الشركة من القائمة", "s");
            sel = null; load();
          }).catch(fail).then(function () { w.busy(false); render(); });
        }, { title: "حذف شركة", icon: IC.del, danger: true, yes: drop ? "حذف نهائي" : "إزالة" });
    }

    function load() {
      call("fm.company.list").then(function (d) {
        data = d;
        if (sel) sel = d.companies.filter(function (c) { return c.Database === sel.Database; })[0] || null;
        render();
      }).catch(fail);
    }
    load();
  }

  // ==================================================================== 2) قاعدة البيانات
  /* ================= «حفظ نسخة احتياطية» و«استرجاع نسخة احتياطية» — مطابقة نوافذ DEXEF ONE بتصميم 2026
     DEXEF: رأس بأيقونة قاعدة بيانات وعنوان برتقالي وسطر إرشاد ، خط فاصل أزرق ، «حدد مكان النسخة الاحتياطيه» + حقل المسار
     بالنجمة الحمراء + «استعراض» ، وزرّا «حفظ / إغلاق» (أو «استرجاع / اغلاق»).
     لمستي: تحذير قرص C ، المساحة الحرة ، اسم الملف قبل الحفظ ، أقراص سريعة (D: / فلاشة) ، شريط تقدّم ، بطاقة نجاح ،
     وفي الاسترجاع: بطاقة معلومات الملف + أحدث النسخ للاختيار بنقرة + تنبيه واضح قبل الاستبدال */
  var BK_IC = {
    db: '<svg viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="bkg1" x1="0" x2="1"><stop offset="0" stop-color="#6b7280"/><stop offset=".45" stop-color="#e5e7eb"/><stop offset="1" stop-color="#4b5563"/></linearGradient></defs>' +
      '<g stroke="#374151" stroke-width="1.4"><path d="M12 15v34c0 4 9 7.5 20 7.5S52 53 52 49V15" fill="url(#bkg1)"/><ellipse cx="32" cy="15" rx="20" ry="7.5" fill="#f3f4f6"/>' +
      '<path d="M12 26.5c0 4 9 7.5 20 7.5s20-3.5 20-7.5M12 38c0 4 9 7.5 20 7.5S52 42 52 38" fill="none"/></g><ellipse cx="32" cy="15" rx="12" ry="3.6" fill="#d1d5db"/></svg>',
    save: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M7.5 10.5L12 15l4.5-4.5"/><path d="M4 15v3.5A2.5 2.5 0 0 0 6.5 21h11a2.5 2.5 0 0 0 2.5-2.5V15"/></svg>',
    rest: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1L3.5 8.4"/><path d="M3.5 3.6v4.8h4.8"/></svg>',
    warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3.5L2.5 20h19z"/><path d="M12 10v4.5M12 17.2v.3" stroke-linecap="round"/></svg>',
    ok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    usb: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><rect x="7" y="9" width="10" height="12" rx="2"/><path d="M9.5 9V4h5v5M10.5 6h.01M13.5 6h.01"/></svg>'
  };
  var bkSize = function (b) { b = +b || 0; return b >= 1073741824 ? (b / 1073741824).toFixed(b >= 107374182400 ? 0 : 1) + " GB" : size(b); };
  var bkDate = function (s) { if (!s) return null; var d = new Date(String(s).replace(" ", "T")); return isNaN(d) ? null : d; };
  function bkAgo(d) { if (!d) return ""; var m = Math.round((Date.now() - d.getTime()) / 60000); return m < 1 ? "الآن" : m < 60 ? "منذ " + m + " دقيقة" : m < 1440 ? "منذ " + Math.floor(m / 60) + " ساعة" : "منذ " + Math.floor(m / 1440) + " يوم"; }
  var bkStamp = function () { var d = new Date(), p = function (n) { return (n < 10 ? "0" : "") + n; }; return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + "_" + p(d.getHours()) + p(d.getMinutes()); };
  function bkWin(o) {
    var w = win({ title: o.title, icon: "", width: 610, body: "", buttons: [] });
    var fw = w.el.querySelector(".fm-win"); fw.classList.add("bk-win"); if (o.cls) fw.classList.add(o.cls);
    w.el.querySelector(".fm-hd .ic").innerHTML = o.hdIc || BK_IC.db;
    return w;
  }
  function bkHead(t, p, ic) { return '<div class="bk-hd"><div class="bk-ic">' + (ic || BK_IC.db) + '</div><div class="bk-ht"><h3>' + esc(t) + "</h3><p>" + esc(p) + '</p></div></div><div class="bk-ln"></div>'; }

  function backup() {
    if (!needHost()) return;
    var w = bkWin({ title: "حفظ نسخة احتياطية" }), info = null, dir = "", busy = false, t0 = 0, tk = 0;
    var db = "ANOUER";
    function infoOf(p) { return call("fm.backup.info", { path: p }).catch(function () { return null; }); }
    function render() {
      var sys = info && info.sys, free = info ? +info.free : -1, lowSp = free >= 0 && free < 2 * 1073741824;
      var drv = ((info && info.drives) || []).filter(function (d) { return !/^c:/i.test(d.name); });
      var last = info && info.last, ld = last ? bkDate(last.date) : null;
      w.body.innerHTML = '<div class="bk">' + bkHead("حفظ نسخة احتياطية", "يجب وضع النسخة الاحتياطية فى مجلد بعيد عن بارتشين C حتى لا تفقد البيانات عند حدوث مشكلة فى النسخة") +
        '<label class="bk-lb" for="bkDir">حدد مكان النسخة الاحتياطيه</label>' +
        '<div class="bk-row"><span class="bk-in' + (sys ? " sys" : "") + '"><input id="bkDir" value="' + esc(dir) + '" spellcheck="false" autocomplete="off" dir="ltr"></span><i class="dxr">*</i><button type="button" class="bk-br" data-a="pick">استعراض</button></div>' +
        '<div class="bk-mt">' +
        (sys ? '<span class="bk-ch w">' + BK_IC.warn + "المجلد على قرص النظام C — اختر قرصاً آخر أو فلاشة</span>" : dir && info && info.exists === false && info.root ? '<span class="bk-ch i">سيُنشأ المجلد تلقائياً</span>' : "") +
        (free >= 0 ? '<span class="bk-ch' + (lowSp ? " w" : "") + '">المساحة الحرة <b dir="ltr">' + bkSize(free) + "</b></span>" : "") +
        '<span class="bk-ch n">اسم الملف <b dir="ltr">' + esc(db + "_" + bkStamp() + ".bak") + "</b></span>" +
        (last ? '<span class="bk-ch">آخر نسخة هنا ' + esc(bkAgo(ld)) + ' · <b dir="ltr">' + bkSize(last.size) + "</b></span>" : "") + "</div>" +
        (drv.length ? '<div class="bk-dv"><span>أقراص سريعة</span>' + drv.map(function (d) { var r = String(d.name).replace(/\\$/, ""); return '<button type="button" data-drv="' + esc(r) + '"' + (dir.toUpperCase().indexOf(r.toUpperCase()) === 0 ? ' class="on"' : "") + ">" + (d.removable ? BK_IC.usb : "") + "<b>" + esc(r) + "</b>" + (d.label ? "<em>" + esc(d.label) + "</em>" : "") + '<small dir="ltr">' + bkSize(d.free) + "</small></button>"; }).join("") + "</div>" : "") +
        '<div class="bk-pg"><div class="bar"><i></i></div><span class="tx">جارٍ حفظ النسخة الاحتياطية ...</span><b class="tm">0.0 ث</b></div>' +
        "</div>";
      w.setButtons([{ t: "حفظ", cls: "bk-ok", id: "bkSave", fn: save }, { t: "إغلاق", cls: "bk-no", fn: function (w) { if (!busy) w.close(); } }]);
      var inp = w.$("#bkDir");
      inp.addEventListener("change", function () { setDir(inp.value.trim()); });
      inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); setDir(inp.value.trim(), true); } });
    }
    function setDir(p, go) { dir = p; infoOf(dir).then(function (i) { info = i || info; render(); if (go) save(w); }); }
    w.body.addEventListener("click", function (e) {
      var b = e.target.closest("button"); if (!b || busy) return;
      if (b.dataset.a === "pick") call("fm.pickFolder", { initial: dir, title: "حدد مكان النسخة الاحتياطيه" }).then(function (r) { if (r && r.path) setDir(r.path); }).catch(fail);
      if (b.dataset.drv) setDir(b.dataset.drv + "\\backup");
    });
    function save(w) {
      if (busy) return;
      dir = (w.$("#bkDir") || { value: dir }).value.trim();
      if (!dir) { var bi = w.$(".bk-in"); if (bi) { bi.classList.remove("shk"); void bi.offsetWidth; bi.classList.add("shk", "bad"); } T("حدد مكان النسخة الاحتياطية", "w"); return; }
      busy = true; w.busy(true); w.el.querySelector(".bk-win").classList.add("run"); t0 = Date.now();
      tk = setInterval(function () { var m = w.$(".bk-pg .tm"); if (m) m.textContent = ((Date.now() - t0) / 1000).toFixed(1) + " ث"; }, 100);
      call("fm.backup", { folder: dir }).then(function (r) {
        clearInterval(tk); busy = false; w.el.querySelector(".bk-win").classList.remove("run");
        if (!r || r.cancelled) { w.busy(false); return; }
        call("fm.settings.set", { values: { "Props.Backup.Folder": dir } }).catch(function () { });
        try { if (typeof SaveSound !== "undefined") SaveSound.play(); } catch (e) { }
        T("تم حفظ النسخة الاحتياطية (" + size(r.size) + ")", "s");
        var nm = String(r.path).split(/[\\/]/).pop(), sec = ((Date.now() - t0) / 1000).toFixed(1);
        w.body.innerHTML = '<div class="bk bk-done">' + bkHead("حفظ نسخة احتياطية", "تم حفظ نسخة احتياطية كاملة لقاعدة بيانات الشركة") +
          '<div class="bk-ok-c"><i class="bk-ck">' + BK_IC.ok + '</i><div><b>تم الحفظ بنجاح</b><span dir="ltr">' + esc(nm) + "</span></div></div>" +
          '<div class="bk-sm"><div><span>الحجم</span><b dir="ltr">' + size(r.size) + '</b></div><div><span>المدة</span><b>' + sec + ' ث</b></div><div class="p"><span>المسار</span><b dir="ltr" title="' + esc(r.path) + '">' + esc(r.path) + "</b></div></div>" +
          (r.sameAsRequested === false ? '<div class="bk-wn">' + BK_IC.warn + "لم يسمح ويندوز لخادم SQL بالكتابة في المجلد الذي اخترته، فحُفظت النسخة في المسار الظاهر أعلاه.</div>" : "") + "</div>";
        w.setButtons([{ t: "فتح المجلد", cls: "bk-ok", fn: function () { call("fm.reveal", { path: r.path }); } }, { t: "إغلاق", cls: "bk-no", fn: function (w) { w.close(); } }]);
      }).catch(function (e) { clearInterval(tk); busy = false; w.busy(false); w.el.querySelector(".bk-win").classList.remove("run"); fail(e); });
    }
    w.body.innerHTML = '<div class="ab-ld"><i></i><i></i><i></i></div>';
    Promise.all([call("fm.settings.get", { prefix: "Props.Backup." }).catch(function () { return {}; }), infoOf("")]).then(function (a) {
      var saved = (a[0] || {})["Props.Backup.Folder"], i0 = a[1] || {}; db = i0.db || db;
      var hasD = (i0.drives || []).some(function (d) { return /^d:/i.test(d.name); });
      dir = saved || (hasD ? "D:\\backup" : "");
      return infoOf(dir).then(function (i) { info = i || i0; if (info && !info.db) info.db = db; render(); setTimeout(function () { var x = w.$("#bkDir"); if (x) x.focus(); }, 40); });
    });
  }

  function restore() {
    if (!needHost()) return;
    var w = bkWin({ title: "استرجاع نسخه احتياطيه", cls: "bk-rs", hdIc: BK_IC.rest }), file = "", fi = null, recent = [], newExe = false, db = "ANOUER";
    function render() {
      var d = fi ? bkDate(fi.date) : null, old = d && (Date.now() - d.getTime()) > 7 * 864e5;
      var nm = file ? String(file).split(/[\\/]/).pop() : "", other = nm && db && nm.toUpperCase().indexOf(String(db).toUpperCase() + "_") < 0 && nm.toUpperCase().indexOf("_" + String(db).toUpperCase() + "_") < 0;
      w.body.innerHTML = '<div class="bk">' + bkHead("استرجاع نسخه احتياطيه", "يرجى تحديد النسخة الاحتياطية . والضغط على استرجاع . و لايمكنك استرجاع النسخة الحالية مرة اخرى", BK_IC.db) +
        '<label class="bk-lb" for="bkFile">مكان النسخه الاحتياطيه</label>' +
        '<div class="bk-row"><span class="bk-in"><input id="bkFile" value="' + esc(file) + '" spellcheck="false" autocomplete="off" dir="ltr" placeholder="اضغط «استعراض» واختر ملف .bak"></span><i class="dxr">*</i><button type="button" class="bk-br" data-a="pick">استعراض</button></div>' +
        (fi ? '<div class="bk-fc"><i>' + BK_IC.db + '</i><div class="t"><b dir="ltr">' + esc(nm) + "</b><span>" + (d ? esc(d.toLocaleString("ar-DZ-u-nu-latn", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })) + " · " + esc(bkAgo(d)) : "") + ' · <b dir="ltr">' + size(fi.size) + "</b></span></div>" +
          (old ? '<em class="w">قديمة — ' + esc(bkAgo(d)) + "</em>" : '<em class="g">حديثة</em>') + "</div>" +
          (other ? '<div class="bk-wn">' + BK_IC.warn + "اسم الملف لا يخص الشركة المفتوحة (" + esc(db) + ") — تأكد أنها النسخة الصحيحة.</div>" : "") : "") +
        (recent.length ? '<div class="bk-rc"><span>أحدث النسخ</span>' + recent.slice(0, 4).map(function (f) { var dd = bkDate(f.date); return '<button type="button" data-f="' + esc(f.path) + '"' + (f.path === file ? ' class="on"' : "") + '><b dir="ltr">' + esc(f.name) + "</b><small>" + esc(bkAgo(dd)) + ' · <bdi>' + size(f.size) + "</bdi></small></button>"; }).join("") + "</div>" : "") +
        '<div class="bk-dg">' + BK_IC.warn + "<div><b>سيتم استبدال كل بيانات الشركة الحالية (" + esc(db) + ") بمحتوى النسخة.</b><span>يحفظ البرنامج نسخة أمان تلقائياً قبل الاسترجاع ، ثم يُعاد تشغيله.</span></div></div>" +
        "</div>";
      w.setButtons([{ t: "استرجاع", cls: "bk-ok", id: "bkGo", fn: go }, { t: "اغلاق", cls: "bk-no", fn: function (w) { w.close(); } }]);
      var inp = w.$("#bkFile"); inp.addEventListener("change", function () { pickPath(inp.value.trim()); });
      setTimeout(function () { try { inp.scrollLeft = inp.scrollWidth; } catch (e) { } }, 0);
    }
    function pickPath(p) {
      file = p; fi = null;
      if (!p) { render(); return; }
      var r0 = recent.filter(function (f) { return f.path === p; })[0];
      if (r0) { fi = { size: r0.size, date: r0.date }; render(); return; }
      call("fm.backup.info", { path: p }).then(function (i) { if (i && i.isFile) fi = { size: i.size, date: i.date }; else if (i && i.xv) T("الملف غير موجود", "w"); render(); }).catch(function () { render(); });
    }
    w.body.addEventListener("click", function (e) {
      var b = e.target.closest("button"); if (!b) return;
      if (b.dataset.f) { pickPath(b.dataset.f); return; }
      if (b.dataset.a === "pick") {
        if (!newExe) { go(w); return; }   /* نسخة البرنامج الحالية: نافذة اختيار الملف داخل «استرجاع» نفسها */
        call("fm.pickBak", { initial: file }).then(function (r) { if (r && r.path) { file = r.path; fi = { size: r.size, date: r.date }; render(); } }).catch(fail);
      }
    });
    function go(w) {
      file = (w.$("#bkFile") || { value: file }).value.trim();
      if (newExe && !file) { var bi = w.$(".bk-in"); if (bi) { bi.classList.remove("shk"); void bi.offsetWidth; bi.classList.add("shk", "bad"); } T("حدد مكان النسخة الاحتياطية", "w"); return; }
      T(newExe ? "تأكيد الاسترجاع ..." : "اختر ملف النسخة الاحتياطية (.bak) ...", "i");
      call("fm.restore", file ? { path: file } : {}).then(function (r) {
        if (r && r.restored) { T("تم استرجاع النسخة الاحتياطية — جارٍ إعادة تشغيل البرنامج ...", "s"); w.close(); }
      }).catch(fail);
    }
    w.body.innerHTML = '<div class="ab-ld"><i></i><i></i><i></i></div>';
    Promise.all([call("fm.backup.info", { path: "" }).catch(function () { return null; }), call("fm.autobackup.list").catch(function () { return null; })]).then(function (a) {
      newExe = !!(a[0] && a[0].xv); if (a[0] && a[0].db) db = a[0].db;
      recent = ((a[1] && a[1].files) || []).slice().sort(function (x, y) { return String(y.date).localeCompare(String(x.date)); });
      render();
    });
  }

  /* ================= الحفظ التلقائي لقاعدة البيانات — تصميم 2026
     بطاقة حالة الحماية (منذ آخر نسخة / بعد كم النسخة القادمة) ، التوقيت بأزرار سريعة ، عدد النسخ بمؤشر خانات ،
     المسار كسلسلة مجلدات بأيقونات ، «المسار القديم» عند تغيير المجلد (فتح / نقل نسخه) ، وقائمة كل النسخ المحفوظة
     (تلقائي / يدوي / أمان) مع إظهار في المجلد ، استرجاع وحذف — ومخطط صغير لأحجام النسخ */
  var AB_IC = {
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 2.8l7.5 3v5.6c0 4.6-3.1 8.4-7.5 9.8-4.4-1.4-7.5-5.2-7.5-9.8V5.8z"/><path class="ck" d="M8.6 12.2l2.4 2.4 4.6-4.8" stroke-linecap="round"/></svg>',
    fold: '<svg viewBox="0 0 24 24"><path d="M3 6.5A1.5 1.5 0 0 1 4.5 5h4.2l2 2.2h8.8A1.5 1.5 0 0 1 21 8.7V18a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18z" fill="#f6c453"/><path d="M3 9.3h18V18a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18z" fill="#fbd775"/></svg>',
    drive: '<svg viewBox="0 0 24 24" fill="none" stroke="#64748b" stroke-width="1.7"><rect x="3" y="7" width="18" height="10" rx="2"/><path d="M7 13h.01M11 13h6"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>',
    stack: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M12 3l8.5 4.5L12 12 3.5 7.5z"/><path d="M3.5 12L12 16.5 20.5 12M3.5 16.5L12 21l8.5-4.5"/></svg>',
    hdd: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M7 15h.01M11 15h6" stroke-linecap="round"/></svg>',
    bolt: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13 2L4.5 13.5H11L10 22l8.5-11.5H12z"/></svg>',
    open: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6M20 4l-8.5 8.5M18 14v4.5A1.5 1.5 0 0 1 16.5 20h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H10"/></svg>',
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5.5A1.5 1.5 0 0 0 14.5 4h-9A1.5 1.5 0 0 0 4 5.5v9A1.5 1.5 0 0 0 5.5 16H8"/></svg>',
    edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"><path d="M4 20h4L19 9l-4-4L4 16z"/></svg>',
    reset: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M4 12a8 8 0 1 0 2.4-5.7L4 8.5M4 4v4.5h4.5"/></svg>',
    move: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h14M13 6l6 6-6 6"/></svg>',
    rest: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7M3 4v5h5"/><path d="M12 8v4l2.5 2.5"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 13h9l1-13"/></svg>',
    file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><ellipse cx="12" cy="6" rx="7" ry="2.8"/><path d="M5 6v12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8V6M5 12c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8"/></svg>'
  };
  var abSize = function (b) { b = +b || 0; return b >= 1073741824 ? (b / 1073741824).toFixed(b >= 107374182400 ? 0 : 1) + " GB" : size(b); };
  var AB_KIND = { auto: ["تلقائي", "a"], manual: ["يدوي", "m"], safe: ["أمان قبل الاسترجاع", "s"] };
  var abDate = function (s) { if (!s) return null; var d = new Date(String(s).replace(" ", "T")); return isNaN(d) ? null : d; };
  function abAgo(d, fut) {
    if (!d) return "";
    var m = Math.round(Math.abs(Date.now() - d.getTime()) / 60000), t;
    if (m < 1) t = "أقل من دقيقة"; else if (m < 60) t = m + " دقيقة"; else if (m < 1440) t = Math.floor(m / 60) + " ساعة" + (m % 60 ? " و " + (m % 60) + " د" : ""); else t = Math.floor(m / 1440) + " يوم";
    return (fut ? "بعد " : "منذ ") + t;
  }
  var abDay = function (d) { var t = new Date(); t.setHours(0, 0, 0, 0); var x = new Date(d); x.setHours(0, 0, 0, 0); var n = Math.round((t - x) / 864e5); return n === 0 ? "اليوم" : n === 1 ? "أمس" : n < 7 ? "منذ " + n + " أيام" : x.toLocaleDateString("ar-DZ-u-nu-latn", { day: "numeric", month: "long", year: "numeric" }); };
  /* المسار كسلسلة مجلدات بأيقونات (C: › Users › Public …) */
  function abCrumbs(p, cls) {
    p = String(p || ""); var parts = p.split(/[\\/]+/).filter(Boolean);
    if (!parts.length) return '<div class="ab-cr ' + (cls || "") + '"><span class="ab-cz">—</span></div>';
    return '<div class="ab-cr ' + (cls || "") + '" title="' + esc(p) + '" dir="ltr">' + parts.map(function (x, i) {
      var root = i === 0 && /:$/.test(x);
      return (i ? '<i class="ab-sep">›</i>' : "") + '<span class="ab-cs' + (i === parts.length - 1 ? " last" : "") + (root ? " root" : "") + '">' + (root ? AB_IC.drive : AB_IC.fold) + "<b>" + esc(x) + "</b></span>";
    }).join("") + "</div>";
  }

  function autoBackupWin() {
    if (!needHost()) return;
    var w = win({ title: "الحفظ التلقائي لقاعدة البيانات", icon: IC.db, width: 1010, body: '<div class="ab-ld"><i></i><i></i><i></i></div>', buttons: [] });
    w.el.querySelector(".fm-win").classList.add("ab-win");
    var D = null, S = null, orig = null, filt = "all", tick = 0;
    var Q = function (s) { return w.$(s); };
    /* «حذف النسخ التي يمر عليها»: يُحفظ أيضاً في Props.AutoBackup.MaxDays — نسخة البرنامج الحالية (قبل build-exe) لا تعرف MaxDays */
    function withDays(st) {
      if (st && st.MaxDays != null) return Promise.resolve(st);
      return call("fm.settings.get", { prefix: "Props.AutoBackup." }).then(function (v) { st.MaxDays = +((v || {})["Props.AutoBackup.MaxDays"] || 0) || 0; st._noDays = 1; return st; }).catch(function () { st.MaxDays = 0; st._noDays = 1; return st; });
    }
    function load(keepForm) {
      return call("fm.autobackup.list").then(function (d) {
        return withDays(d.settings).then(function () {
          D = d; if (!keepForm || !S) { S = JSON.parse(JSON.stringify(d.settings)); orig = JSON.parse(JSON.stringify(d.settings)); }
          render();
        });
      }, function () {
        /* نسخة البرنامج القديمة لا تعرف fm.autobackup.list ← نكتفي بالإعدادات */
        return call("fm.autobackup.get").then(function (d) { return withDays(d.settings).then(function () { D = { settings: d.settings, defaultFolder: d.defaultFolder, folders: [], files: [], total: 0, free: -1, old: 1 }; if (!keepForm || !S) { S = JSON.parse(JSON.stringify(d.settings)); orig = JSON.parse(JSON.stringify(d.settings)); } render(); }); });
      });
    }
    var dirty = function () { if (!orig) return false; return ["Enabled", "IntervalMinutes", "Folder", "Keep", "OnExit"].some(function (k) { return String(S[k]) !== String(orig[k]); }) || (+S.MaxDays || 0) !== (+orig.MaxDays || 0); };
    function hero() {
      var on = !!S.Enabled, last = abDate(orig.LastRun), nxt = abDate(orig.NextRun), per = (+orig.IntervalMinutes || 60) * 60000;
      var pct = on && last ? Math.max(0, Math.min(100, (Date.now() - last.getTime()) / per * 100)) : 0;
      var autos = (D.files || []).filter(function (f) { return f.kind === "auto"; }).length;
      var health = !on ? "off" : orig.LastError && (!last || String(orig.LastError).slice(0, 16) >= String(orig.LastRun).slice(0, 16)) ? "err" : !last ? "wait" : Date.now() - last.getTime() > per * 2.2 ? "late" : "ok";
      var ttl = { off: "الحفظ التلقائي متوقف", err: "آخر محاولة حفظ فشلت", wait: "مفعّل — في انتظار أول نسخة", late: "تأخرت النسخة التلقائية", ok: "بياناتك محمية" }[health];
      var sub = health === "off" ? "فعّل الحفظ التلقائي لتُحفظ نسخة من قاعدة البيانات دورياً دون تدخل منك" :
        (last ? "آخر نسخة " + abAgo(last) : "لم يتم أي حفظ تلقائي بعد") + (on && nxt && nxt > new Date() ? " · النسخة القادمة " + abAgo(nxt, true) : on ? " · كل " + abEvery(S.IntervalMinutes) : "");
      var free = +D.free, cap = +D.cap, used = cap > 0 ? Math.round((cap - free) / cap * 100) : -1;
      return '<div class="ab-hero ' + health + (on !== !!orig.Enabled ? " chg" : "") + '">' +
        '<div class="ab-sh">' + AB_IC.shield + '<svg class="ab-rg" viewBox="0 0 44 44"><circle cx="22" cy="22" r="20" class="bg"/><circle cx="22" cy="22" r="20" class="fg" style="stroke-dashoffset:' + (125.66 * (1 - pct / 100)).toFixed(2) + '"/></svg></div>' +
        '<div class="ab-ht"><b>' + ttl + '</b><span>' + esc(sub) + "</span>" + (health === "err" ? '<em class="ab-er">' + esc(orig.LastError) + "</em>" : "") + "</div>" +
        '<label class="ab-sw" title="تفعيل / إيقاف"><input type="checkbox" id="abOn"' + (on ? " checked" : "") + '><i></i><span>' + (on ? "مفعّل" : "متوقف") + "</span></label></div>" +
        '<div class="ab-kp">' +
        '<div><i>' + AB_IC.stack + "</i><span>النسخ المحفوظة</span><b>" + (D.files || []).length + "</b><small>" + autos + " تلقائية</small></div>" +
        '<div><i>' + AB_IC.file + "</i><span>الحجم الكلي</span><b>" + abSize(D.total) + "</b><small>" + esc(D.db || "") + "</small></div>" +
        '<div><i>' + AB_IC.clock + "</i><span>مدة آخر نسخة</span><b>" + (orig.LastMs ? (orig.LastMs < 1000 ? orig.LastMs + " ms" : (orig.LastMs / 1000).toFixed(1) + " s") : "—") + "</b><small>" + (last ? esc(String(orig.LastRun).slice(0, 16)) : "—") + "</small></div>" +
        '<div class="dk' + (used > 90 ? " bad" : "") + '"><i>' + AB_IC.hdd + "</i><span>المساحة الحرة</span><b>" + (free >= 0 ? abSize(free) : "—") + "</b>" + (used >= 0 ? '<em><u style="width:' + used + '%"></u></em>' : "<small>—</small>") + "</div></div>";
    }
    function abEvery(m) { m = +m || 60; return m % 1440 === 0 ? (m / 1440 === 1 ? "يوم" : m / 1440 + " أيام") : m % 60 === 0 ? (m / 60 === 1 ? "ساعة" : m / 60 + " ساعات") : m + " دقيقة"; }
    /* مصير كل نسخة تلقائية حسب الإعدادات الحالية (قبل الحفظ أيضاً — معاينة مباشرة) */
    function fates() {
      var keep = Math.max(1, +S.Keep || 10), md = +S.MaxDays || 0, now = Date.now(), out = {};
      (D.files || []).filter(function (f) { return f.kind === "auto" && f.folder === "auto"; }).sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); })
        .forEach(function (f, i) {
          var d = abDate(f.date), age = d ? (now - d.getTime()) / 864e5 : 0, r = { age: Math.floor(age) };
          if (i >= keep) r.del = "count";
          else if (md > 0 && i > 0 && age >= md) r.del = "age";
          else if (md > 0 && i > 0) r.left = Math.max(0, Math.ceil(md - age));
          else if (md > 0 && i === 0) r.keep = 1;
          out[f.path] = r;
        });
      return out;
    }
    function ageBlock() {
      var md = +S.MaxDays || 0, on = md > 0, F = fates(), del = Object.keys(F).filter(function (k) { return F[k].del; }), dAge = del.filter(function (k) { return F[k].del === "age"; }).length;
      var sz = (D.files || []).filter(function (f) { return F[f.path] && F[f.path].del; }).reduce(function (a, f) { return a + (+f.size || 0); }, 0);
      var lim = new Date(Date.now() - (md || 10) * 864e5);
      var lp = String(orig.LastPrune || "").split("|");
      return '<div class="ab-age' + (on ? " on" : "") + '"><div class="ab-agh"><label class="ab-sw sm"><input type="checkbox" id="abAgeOn"' + (on ? " checked" : "") + '><i></i><span>حذف النسخ الاحتياطية التي يمر عليها</span></label>' +
        '<div class="ab-st ab-agd"><button type="button" data-dp="-1" aria-label="أقل"' + (on ? "" : " disabled") + '>−</button><input id="abDays" type="number" min="1" max="3650" value="' + (md || S._md || 10) + '"' + (on ? "" : " disabled") + '><button type="button" data-dp="1" aria-label="أكثر"' + (on ? "" : " disabled") + '>+</button><span>يوم</span></div>' +
        '<div class="ab-ch sm">' + [7, 10, 30, 90].map(function (n) { return '<button type="button" data-days="' + n + '" class="' + (md === n ? "on" : "") + '">' + n + "</button>"; }).join("") + "</div></div>" +
        '<div class="ab-agp ' + (!on ? "off" : del.length ? "warn" : "ok") + '">' +
        (!on ? "<span>معطّل — النسخ تبقى حتى يتجاوز عددها " + (+S.Keep || 10) + " فقط</span>" :
          del.length ? "<span>عند الحفظ القادم تُحذف <b>" + del.length + "</b> نسخة" + (dAge ? " (" + dAge + " أقدم من <b>" + esc(lim.toLocaleDateString("ar-DZ-u-nu-latn", { day: "numeric", month: "long" })) + "</b>)" : "") + " · توفير <b dir=\"ltr\">" + size(sz) + "</b></span>" + '<button type="button" data-a="prune">' + AB_IC.trash + "تنظيف الآن</button>" :
            "<span>✔ لا توجد نسخ تلقائية أقدم من " + md + " يوم — أحدث نسخة تبقى دائماً</span>") +
        "</div>" + (on && orig._noDays ? '<p class="ab-hn ab-nb">الإعداد محفوظ ✔ — الحذف التلقائي حسب الأيام يبدأ بعد تحديث البرنامج (build-exe.bat)</p>' : "") + (lp[0] && lp[1] ? '<p class="ab-hn">آخر تنظيف: حُذفت ' + esc(lp[0]) + " نسخة — " + esc(lp[1]) + "</p>" : "") + "</div>";
    }
    function settings() {
      var chips = [[15, "15 د"], [30, "30 د"], [60, "ساعة"], [120, "ساعتين"], [240, "4 ساعات"], [1440, "يومياً"]];
      var keep = Math.max(1, +S.Keep || 10), slots = Math.min(keep, 30), autos = (D.files || []).filter(function (f) { return f.kind === "auto" && f.folder === "auto"; }).length;
      return '<section class="ab-cd ab-tm"><div class="ab-tp"><h4>' + AB_IC.clock + "الحفظ كل</h4>" +
        '<div class="ab-ch">' + chips.map(function (c) { return '<button type="button" data-min="' + c[0] + '" class="' + (+S.IntervalMinutes === c[0] ? "on" : "") + '">' + c[1] + "</button>"; }).join("") + "</div>" +
        '<div class="ab-cu"><span>أو كل</span><input id="abMin" type="number" min="5" max="1440" value="' + (+S.IntervalMinutes || 60) + '"><span>دقيقة</span></div>' +
        '<label class="ab-sw sm"><input type="checkbox" id="abExit"' + (S.OnExit ? " checked" : "") + '><i></i><span>حفظ نسخة عند الخروج من البرنامج</span></label></div>' +
        '<div class="ab-tp"><h4>' + AB_IC.stack + "عدد النسخ المحفوظة</h4>" +
        '<div class="ab-st"><button type="button" data-kp="-1" aria-label="أقل">−</button><input id="abKeep" type="number" min="1" max="500" value="' + keep + '"><button type="button" data-kp="1" aria-label="أكثر">+</button><span>نسخة</span></div>' +
        '<div class="ab-sl" title="' + Math.min(autos, keep) + " من " + keep + ' خانة مستعملة">' + Array.apply(null, { length: slots }).map(function (_, i) { return "<i" + (i < autos ? ' class="f"' : "") + "></i>"; }).join("") + (keep > 30 ? "<em>+" + (keep - 30) + "</em>" : "") + "</div>" +
        '<p class="ab-hn">عند الوصول للعدد تُحذف أقدم نسخة تلقائية وتبقى أحدث ' + keep + " نسخة — النسخ اليدوية لا تُحذف.</p></div>" + ageBlock() + "</section>";
    }
    function pathCard() {
      var ch = orig && S.Folder !== orig.Folder, prev = orig && orig.PrevFolder, pf = (D.folders || []).filter(function (f) { return f.key === "prev"; })[0];
      var isDef = S.Folder === D.defaultFolder;
      return '<section class="ab-cd ab-pc"><h4>' + AB_IC.fold.replace("<svg", '<svg class="fi"') + "مجلد الحفظ" + (isDef ? '<em class="ab-tg">الافتراضي</em>' : "") + "</h4>" +
        (ch ? '<div class="ab-mv"><div><small>المسار الحالي (القديم)</small>' + abCrumbs(orig.Folder, "old") + '</div><i class="ab-ar">' + AB_IC.move + '</i><div><small>المسار الجديد — يُطبَّق عند «حفظ الإعدادات»</small>' + abCrumbs(S.Folder, "new") + "</div></div>"
          : abCrumbs(S.Folder)) +
        '<div class="ab-pb"><button type="button" data-a="pick">' + AB_IC.edit + "تغيير المجلد</button><button type=\"button\" data-a=\"open\">" + AB_IC.open + "فتح المجلد</button><button type=\"button\" data-a=\"copy\">" + AB_IC.copy + "نسخ المسار</button>" +
        (isDef ? "" : '<button type="button" data-a="def">' + AB_IC.reset + "الافتراضي</button>") + "</div>" +
        (prev && !ch ? '<div class="ab-old"><div class="h"><b>المسار القديم</b><span>' + (pf ? (pf.exists ? pf.count + " نسخة · <bdi>" + size(pf.size) + "</bdi>" : "المجلد غير موجود") : "") + "</span></div>" + abCrumbs(prev, "old") +
          '<div class="ab-pb"><button type="button" data-a="openPrev">' + AB_IC.open + "فتح المسار القديم</button>" + (pf && pf.exists && pf.count ? '<button type="button" data-a="moveOld" class="hl">' + AB_IC.move + "نقل نسخه إلى المجلد الحالي</button>" : "") + "</div></div>" : "") +
        "</section>";
    }
    function list() {
      var fs = (D.files || []).slice().sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
      var cnt = { all: fs.length, auto: 0, manual: 0, safe: 0 }; fs.forEach(function (f) { cnt[f.kind] = (cnt[f.kind] || 0) + 1; });
      var show = fs.filter(function (f) { return filt === "all" || f.kind === filt; });
      var spark = fs.slice(0, 24).reverse(), mx = Math.max.apply(null, spark.map(function (f) { return +f.size || 0; }).concat([1]));
      var g = "", day = "", FT = fates();
      show.forEach(function (f) {
        var d = abDate(f.date), dy = d ? abDay(d) : "";
        if (dy !== day) { day = dy; g += '<div class="ab-dy">' + esc(dy) + "</div>"; }
        var fa = FT[f.path] || {}, fb = fa.del === "count" ? '<em class="ab-fx d">ستُحذف — تجاوز العدد</em>' : fa.del === "age" ? '<em class="ab-fx d">ستُحذف — مر عليها ' + fa.age + " يوم</em>" : fa.left != null ? '<em class="ab-fx' + (fa.left <= 3 ? " w" : "") + '">' + (fa.left <= 1 ? "تُحذف غداً" : "تبقى " + fa.left + " يوم") + "</em>" : fa.keep ? '<em class="ab-fx k">محمية — أحدث نسخة</em>' : "";
        var k = AB_KIND[f.kind] || AB_KIND.manual, last = orig.LastFile && f.path.toLowerCase() === String(orig.LastFile).toLowerCase();
        g += '<div class="ab-it k-' + k[1] + (last ? " last" : "") + (fa.del ? " doom" : "") + '" data-p="' + esc(f.path) + '"><i class="ab-fi">' + AB_IC.file + "</i>" +
          '<div class="ab-in"><b dir="ltr" title="' + esc(f.name) + '">' + esc(f.name) + "</b><span>" + '<em class="ab-kd">' + k[0] + "</em>" + (d ? " · " + esc(d.toLocaleTimeString("ar-DZ-u-nu-latn", { hour: "2-digit", minute: "2-digit" })) + " · " + abAgo(d) : "") + (f.folder === "prev" ? ' · <em class="ab-kd o">المسار القديم</em>' : f.folder !== "auto" ? ' · <em class="ab-kd g">' + (f.folder === "manual" ? "مجلد النسخ اليدوية" : "المجلد المشترك") + "</em>" : "") + (last ? ' · <em class="ab-kd n">آخر نسخة</em>' : "") + "</span></div>" + fb +
          '<b class="ab-sz">' + size(f.size) + "</b>" +
          '<div class="ab-ac"><button type="button" data-f="reveal" title="إظهار في المجلد">' + AB_IC.open + '</button><button type="button" data-f="restore" title="استرجاع هذه النسخة">' + AB_IC.rest + '</button><button type="button" data-f="del" class="d" title="حذف">' + AB_IC.trash + "</button></div></div>";
      });
      return '<section class="ab-cd ab-ls"><h4>' + AB_IC.stack + "النسخ المحفوظة" +
        (spark.length > 1 ? '<span class="ab-sp" title="أحجام آخر ' + spark.length + ' نسخة">' + spark.map(function (f) { return '<i class="k-' + (AB_KIND[f.kind] || AB_KIND.manual)[1] + '" style="height:' + Math.max(12, Math.round((+f.size || 0) / mx * 100)) + '%"></i>'; }).join("") + "</span>" : "") + "</h4>" +
        '<div class="ab-fl">' + [["all", "الكل"], ["auto", "تلقائي"], ["manual", "يدوي"], ["safe", "أمان"]].map(function (x) { return '<button type="button" data-fl="' + x[0] + '" class="' + (filt === x[0] ? "on" : "") + '">' + x[1] + "<b>" + (cnt[x[0]] || 0) + "</b></button>"; }).join("") + "</div>" +
        '<div class="ab-li">' + (g || '<div class="ab-em">' + AB_IC.stack + "<b>" + (D.old ? "قائمة النسخ تحتاج نسخة البرنامج الجديدة (build-exe.bat)" : "لا توجد نسخ محفوظة بعد") + "</b><span>" + (D.old ? "" : "اضغط «نسخ الآن» لإنشاء أول نسخة") + "</span></div>") + "</div></section>";
    }
    function render() {
      var sc = Q(".ab-li") ? Q(".ab-li").scrollTop : 0;
      w.body.innerHTML = '<div class="abk">' + hero() + '<div class="ab-mn"><div class="ab-c1">' + settings() + pathCard() + '</div><div class="ab-c2">' + list() + "</div></div></div>";
      if (Q(".ab-li")) Q(".ab-li").scrollTop = sc;
      btns();
    }
    function btns() {
      w.setButtons([
        { t: dirty() ? "حفظ الإعدادات •" : "حفظ الإعدادات", cls: "ok", fn: save },
        { t: "نسخ الآن", id: "abNow", fn: runNow },
        "|",
        { t: "إغلاق", cls: "no", fn: function (w) { if (dirty()) confirmBox("لم تحفظ التعديلات على إعدادات الحفظ التلقائي .. هل تريد الإغلاق دون حفظ ؟", function () { w.close(); }, { title: "إغلاق", yes: "إغلاق دون حفظ" }); else w.close(); } }
      ]);
      var nb = w.foot.querySelector("#abNow"); if (nb) nb.innerHTML = AB_IC.bolt + "<span>نسخ الآن</span>";
    }
    function save(w) {
      var payload = { Enabled: !!S.Enabled, IntervalMinutes: Math.max(5, Math.min(1440, +S.IntervalMinutes || 60)), Folder: String(S.Folder || "").trim() || D.defaultFolder, Keep: Math.max(1, Math.min(500, +S.Keep || 10)), OnExit: !!S.OnExit, MaxDays: Math.max(0, Math.min(3650, +S.MaxDays || 0)) };
      w.busy(true);
      call("fm.autobackup.set", payload).then(function () {
        return call("fm.settings.set", { values: { "Props.AutoBackup.MaxDays": String(payload.MaxDays) } }).catch(function () { });
      }).then(function () {
        T(payload.Enabled ? "✔ تم تفعيل الحفظ التلقائي كل " + abEvery(payload.IntervalMinutes) + (payload.MaxDays ? " — وحذف النسخ التي يمر عليها " + payload.MaxDays + " يوم" : "") : "تم إيقاف الحفظ التلقائي", "s");
        try { if (typeof SaveSound !== "undefined") SaveSound.play(); } catch (e) { }
        w.busy(false); S = null; load();
      }).catch(function (e) { w.busy(false); fail(e); });
    }
    function runNow(w) {
      var nb = w.foot.querySelector("#abNow"); w.busy(true); if (nb) nb.classList.add("run");
      w.el.querySelector(".ab-win").classList.add("ab-busy");
      var t0 = Date.now();
      call("fm.autobackup.run").then(function (r) {
        T("✔ تم حفظ نسخة في " + ((Date.now() - t0) / 1000).toFixed(1) + " ث", "s");
        try { if (typeof SaveSound !== "undefined") SaveSound.play(); } catch (e) { }
        return load(true).then(function () { var el = Q('.ab-it[data-p="' + String(r.path).replace(/["\\]/g, "\\$&") + '"]'); if (el) { el.classList.add("nw"); el.scrollIntoView({ block: "nearest" }); } });
      }).catch(fail).then(function () { w.busy(false); w.el.querySelector(".ab-win").classList.remove("ab-busy"); var b = w.foot.querySelector("#abNow"); if (b) b.classList.remove("run"); });
    }
    w.body.addEventListener("click", function (e) {
      var t = e.target.closest("button"); if (!t) return;
      if (t.dataset.min) { S.IntervalMinutes = +t.dataset.min; render(); return; }
      if (t.dataset.kp) { S.Keep = Math.max(1, Math.min(500, (+S.Keep || 10) + +t.dataset.kp)); render(); return; }
      if (t.dataset.fl) { filt = t.dataset.fl; render(); return; }
      if (t.dataset.days) { S.MaxDays = +t.dataset.days; S._md = S.MaxDays; render(); return; }
      if (t.dataset.dp) { S.MaxDays = Math.max(1, Math.min(3650, (+S.MaxDays || S._md || 10) + +t.dataset.dp)); S._md = S.MaxDays; render(); return; }
      var a = t.dataset.a;
      if (a === "pick") call("fm.pickFolder", { initial: S.Folder }).then(function (r) { if (r && r.path) { S.Folder = r.path; render(); } }).catch(fail);
      else if (a === "open") call("fm.reveal", { path: S.Folder }).catch(fail);
      else if (a === "openPrev") call("fm.reveal", { path: orig.PrevFolder }).catch(fail);
      else if (a === "def") { S.Folder = D.defaultFolder; render(); }
      else if (a === "copy") { var txt = S.Folder; (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(function () { T("تم نسخ المسار", "s"); }).catch(function () { T(txt, "i"); }); }
      else if (a === "prune") {
        var F2 = fates(), n2 = Object.keys(F2).filter(function (k) { return F2[k].del; }).length;
        confirmBox("حذف <b>" + n2 + "</b> نسخة تلقائية قديمة الآن ؟<br><span style=\"color:#64748b;font-size:12px\">تُحفظ الإعدادات الحالية أولاً — النسخ اليدوية ونسخ الأمان وأحدث نسخة لا تُحذف.</span>", function () {
          var payload = { Enabled: !!S.Enabled, IntervalMinutes: Math.max(5, Math.min(1440, +S.IntervalMinutes || 60)), Folder: String(S.Folder || "").trim() || D.defaultFolder, Keep: Math.max(1, Math.min(500, +S.Keep || 10)), OnExit: !!S.OnExit, MaxDays: Math.max(0, Math.min(3650, +S.MaxDays || 0)) };
          w.$$(".ab-it.doom").forEach(function (x) { x.classList.add("gone"); });
          call("fm.autobackup.set", payload).then(function () { return call("fm.settings.set", { values: { "Props.AutoBackup.MaxDays": String(payload.MaxDays) } }).catch(function () { }); }).then(function () { return call("fm.autobackup.prune"); })
            .then(function (r) { T("✔ تم حذف " + ((r && r.deleted) || 0) + " نسخة قديمة", "s"); S = null; setTimeout(load, 240); })
            .catch(function (e) { fail(/غير معروف|NotSupported/.test((e && e.message) || "") ? { message: "«تنظيف الآن» يحتاج نسخة البرنامج الجديدة (build-exe.bat)" } : e); load(true); });
        }, { title: "تنظيف النسخ القديمة", icon: IC.del, danger: true, yes: "حذف" });
      }
      else if (a === "moveOld") confirmBox("نقل كل النسخ من «المسار القديم» إلى مجلد الحفظ الحالي ؟", function () {
        call("fm.autobackup.moveOld").then(function (r) { T("✔ تم نقل " + r.moved + " نسخة إلى المجلد الحالي", "s"); load(true); }).catch(fail);
      }, { title: "نقل النسخ القديمة", yes: "نقل" });
      var it = t.closest(".ab-it"); if (!it || !t.dataset.f) return;
      var p = it.dataset.p, nm = it.querySelector(".ab-in b").textContent;
      if (t.dataset.f === "reveal") call("fm.reveal", { path: p }).catch(fail);
      else if (t.dataset.f === "restore") { T("تأكيد الاسترجاع ...", "i"); call("fm.restore", { path: p }).then(function (r) { if (r && r.restored) T("تم الاسترجاع — جارٍ إعادة تشغيل البرنامج ...", "s"); }).catch(fail); }
      else if (t.dataset.f === "del") confirmBox("حذف النسخة «" + esc(nm) + "» نهائياً من القرص ؟", function () {
        call("fm.autobackup.delete", { path: p }).then(function () { it.classList.add("gone"); T("تم حذف النسخة", "s"); setTimeout(function () { load(true); }, 220); }).catch(fail);
      }, { title: "حذف نسخة", icon: IC.del, danger: true, yes: "حذف" });
    });
    w.body.addEventListener("change", function (e) {
      var t = e.target;
      if (t.id === "abOn") { S.Enabled = t.checked; render(); }
      else if (t.id === "abExit") { S.OnExit = t.checked; btns(); }
      else if (t.id === "abMin") { S.IntervalMinutes = Math.max(5, Math.min(1440, +t.value || 60)); render(); }
      else if (t.id === "abKeep") { S.Keep = Math.max(1, Math.min(500, +t.value || 10)); render(); }
      else if (t.id === "abAgeOn") { S.MaxDays = t.checked ? (S._md || 10) : 0; if (t.checked) S._md = S.MaxDays; render(); }
      else if (t.id === "abDays") { S.MaxDays = Math.max(1, Math.min(3650, +t.value || 10)); S._md = S.MaxDays; render(); }
    });
    /* العدّادات «منذ / بعد» تتحدث كل 30 ثانية ما دامت النافذة مفتوحة */
    tick = setInterval(function () { if (!w.el.isConnected) { clearInterval(tick); return; } var h = Q(".ab-hero"); if (h && D && !w.el.querySelector(".ab-busy")) { var f = document.activeElement; if (!f || !w.body.contains(f) || f.tagName === "BUTTON") render(); } }, 30000);
    load().catch(function (e) { w.close(); fail(e); });
  }

  function wipeWin() {
    if (!needHost()) return;
    var opts = [["Invoices", "الفواتير والحركات (المبيعات، المشتريات، المرتجعات، المدفوعات، السندات)"], ["Products", "الأصناف ووحداتها"], ["Customers", "العملاء"], ["Suppliers", "الموردون"]];
    var w = win({
      title: "محو محتويات البرنامج", icon: IC.del, width: 560,
      body:
        '<div class="fm-note fm-danger">تحذف هذه العملية البيانات المحددة من الشركة المفتوحة حالياً. يحفظ البرنامج نسخة احتياطية تلقائية قبل المحو.</div>' +
        '<div class="fm-sec"><div class="fm-st">البيانات المراد محوها</div><div class="fm-sb">' +
        opts.map(function (o, i) { return '<div class="fm-r"><label class="fm-ck" style="width:auto"><input type="checkbox" data-k="' + o[0] + '"' + (i === 0 ? " checked" : "") + ">" + esc(o[1]) + "</label></div>"; }).join("") +
        '<div style="color:#666;font-size:11px;margin-top:4px">محو الأصناف أو العملاء أو الموردين يستلزم محو الحركات المرتبطة بهم. عند محو الحركات فقط تُصفَّر أرصدة المخزون والخزينة وتعود أرصدة العملاء والموردين للرصيد الافتتاحي.</div>' +
        "</div></div>" +
        field("للتأكيد اكتب «محو»", '<input class="fm-in" id="wpTxt" style="width:140px" autocomplete="off">'),
      buttons: [
        { t: "محو", cls: "del", id: "wpGo", fn: go },
        { t: "حفظ نسخة احتياطية أولاً", cls: "ghost", fn: function () { backup(); } },
        "|",
        { t: "إلغاء", cls: "no", fn: function (w) { w.close(); } }
      ]
    });
    var btn = w.foot.querySelector("#wpGo");
    var upd = function () {
      var any = w.$$("[data-k]").some(function (c) { return c.checked; });
      if (w.$$("[data-k]").some(function (c) { return c.checked && c.dataset.k !== "Invoices"; })) w.$('[data-k="Invoices"]').checked = true;
      btn.disabled = !(any && w.$("#wpTxt").value.trim() === "محو");
    };
    w.body.addEventListener("input", upd); w.body.addEventListener("change", upd); upd();

    function go(w) {
      var p = { confirm: "محو" };
      w.$$("[data-k]").forEach(function (c) { p[c.dataset.k] = c.checked; });
      w.busy(true); T("جارٍ حفظ نسخة أمان ثم المحو ...", "i");
      call("fm.wipe", p).then(function (r) {
        w.close();
        var lines = Object.keys(r.counts || {}).map(function (k) { return "<li>" + esc(k) + ": <b>" + r.counts[k] + "</b></li>"; }).join("");
        win({
          title: "محو محتويات البرنامج", icon: IC.del, width: 520,
          body: '<div class="fm-note fm-ok">تم المحو بنجاح.</div><ul style="margin:6px 18px;line-height:1.9">' + lines + "</ul>" +
            field("نسخة الأمان", '<input class="fm-in fm-mono" readonly style="flex:1" value="' + esc(r.backup) + '">') +
            '<div class="fm-note">يُعاد تحميل الشاشة لعرض البيانات بعد المحو.</div>',
          buttons: [{ t: "تم", cls: "ok", fn: function () { location.reload(); } }],
          onClose: function () { location.reload(); }
        });
      }).catch(function (e) { w.busy(false); upd(); fail(e); });
    }
  }

  // ==================================================================== 4) الفروع
  function branchForm(b, onSaved) {
    var isNew = !b;
    var w = win({
      title: isNew ? "إضافة فرع" : "تعديل فرع", icon: IC.br, width: 460,
      body: '<div class="fm-sec"><div class="fm-sb">' +
        field("كود الفرع", '<input class="fm-in" id="brCode" style="width:120px;text-align:center" value="' + esc(b ? b.Code : "") + '">', true) +
        field("اسم الفرع", '<input class="fm-in" id="brName" style="width:240px" value="' + esc(b ? b.Name : "") + '">', true) +
        '<div class="fm-r"><label></label><label class="fm-ck"><input type="checkbox" id="brAct"' + (!b || b.IsActive ? " checked" : "") + ">نشط</label></div>" +
        "</div></div>",
      buttons: [
        { t: "حفظ", cls: "ok", fn: save },
        { t: "إلغاء", cls: "no", fn: function (w) { w.close(); } }
      ]
    });
    if (isNew) call("fm.branches.list").then(function (l) {
      var c = w.$("#brCode"); if (!c.value) c.value = "BR" + String((l.length || 0) + 1).padStart(2, "0");
    }).catch(function () { });
    w.body.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); save(w); } });
    function save(w) {
      var code = w.$("#brCode"), name = w.$("#brName");
      code.classList.toggle("err", !code.value.trim()); name.classList.toggle("err", !name.value.trim());
      if (!code.value.trim() || !name.value.trim()) return;
      if (!needHost()) return;
      w.busy(true);
      call("fm.branches.save", { BranchId: b ? b.BranchId : 0, Code: code.value.trim(), Name: name.value.trim(), IsActive: w.$("#brAct").checked })
        .then(function () { T("تم حفظ الفرع: " + name.value.trim(), "s"); w.close(); if (onSaved) onSaved(); })
        .catch(function (e) { w.busy(false); fail(e); });
    }
  }

  function branchesWin() {
    if (!needHost()) return;
    var list = [];
    var w = win({
      title: "مراجعة الفروع", icon: IC.br, width: 640,
      body: '<div class="fm-scroll"><table class="fm-tbl"><thead><tr><th style="width:80px">الكود</th><th>اسم الفرع</th><th style="width:80px">المستخدمون</th><th style="width:80px">الفواتير</th><th style="width:70px">الحالة</th><th style="width:110px"></th></tr></thead><tbody id="brRows"></tbody></table></div>' +
        '<div style="margin-top:8px;color:#666;font-size:11px">الفرع المرتبط بفواتير أو مستخدمين لا يُحذف بل يتم إيقافه.</div>',
      buttons: [
        { t: "إضافة فرع", cls: "ok", fn: function () { branchForm(null, load); } },
        "|",
        { t: "إغلاق", cls: "no", fn: function (w) { w.close(); } }
      ]
    });
    function load() {
      call("fm.branches.list").then(function (l) {
        list = l;
        w.$("#brRows").innerHTML = l.length ? l.map(function (b, i) {
          return "<tr><td class=\"fm-mono\">" + esc(b.Code) + "</td><td><b>" + esc(b.Name) + "</b></td><td>" + b.Users + "</td><td>" + b.Invoices + "</td><td>" +
            (b.IsActive ? '<span class="fm-tag">نشط</span>' : '<span class="fm-tag gray">موقوف</span>') + "</td>" +
            '<td><button type="button" class="fm-lnk" data-ed="' + i + '">تعديل</button><button type="button" class="fm-lnk red" data-del="' + i + '">حذف</button></td></tr>';
        }).join("") : '<tr><td colspan="6" class="fm-empty">لا توجد فروع</td></tr>';
      }).catch(fail);
    }
    w.body.addEventListener("click", function (e) {
      var ed = e.target.closest("[data-ed]"), dl = e.target.closest("[data-del]");
      if (ed) branchForm(list[+ed.dataset.ed], load);
      if (dl) {
        var b = list[+dl.dataset.del];
        confirmBox("حذف الفرع «" + esc(b.Name) + "»؟" + (b.Users || b.Invoices ? "<br>الفرع مرتبط بحركات، لذلك سيتم إيقافه بدل حذفه." : ""), function () {
          call("fm.branches.delete", { id: b.BranchId }).then(function () { T("تم", "s"); load(); }).catch(fail);
        }, { title: "حذف فرع", icon: IC.br, danger: true, yes: "حذف" });
      }
    });
    load();
  }

  // ==================================================================== 5) الخصائص (Ctrl+O)
  var PROPS = [
    ["Company.Name", "اسم الشركة", 300, true], ["Company.NameFr", "الاسم باللاتينية", 300], ["Company.Activity", "النشاط", 300],
    ["Company.Address", "العنوان", 360], ["Company.Phone", "الهاتف", 180], ["Company.Mobile", "الموبايل", 180], ["Company.Email", "البريد الإلكتروني", 260],
    ["Company.NIF", "الرقم الجبائي (NIF)", 220], ["Company.NIS", "رقم التعريف الإحصائي (NIS)", 220], ["Company.RC", "السجل التجاري (RC)", 220],
    ["Company.AI", "رقم المادة (AI)", 220], ["Company.Currency", "العملة", 0], ["Company.InvoiceFooter", "تذييل الفاتورة", 360]
  ];
  /* ✦ (2026-11-22) حسابات التواصل — تظهر في آخر كل الإيصالات والفواتير بشريط «تابعونا» */
  var SOCP = [["Social.Facebook", "فيسبوك", "anouerpos"], ["Social.YouTube", "يوتيوب", "@anouerapp"], ["Social.TikTok", "تيك توك", "@anouersaed"]];
  function propertiesWin() {
    if (!needHost()) return;
    var w = win({ title: "إعدادات النظام", icon: IC.prop, width: 640, body: '<div class="fm-empty">جارٍ التحميل ...</div>', buttons: [] });
    Promise.all([call("fm.settings.get", { prefix: "Company." }), call("fm.company.list"), call("fm.settings.get", { prefix: "Social." }).catch(function () { return {}; })]).then(function (res) {
      var s = Object.assign({}, res[0] || {}, res[2] || {}), cl = res[1];
      var active = (cl.companies || []).filter(function (c) { return c.IsActive; })[0];
      if (!s["Company.Name"] && active) s["Company.Name"] = active.Name;
      var inp = function (p) {
        var v = s[p[0]] || "";
        if (p[0] === "Company.Currency") {
          v = v || "DZD";
          return '<select class="fm-in" data-k="' + p[0] + '" style="width:200px">' + [["DZD", "دينار جزائري"], ["EUR", "يورو"], ["USD", "دولار أمريكي"], ["MAD", "درهم مغربي"], ["TND", "دينار تونسي"]]
            .map(function (c) { return '<option value="' + c[0] + '"' + (c[0] === v ? " selected" : "") + ">" + c[0] + " — " + c[1] + "</option>"; }).join("") + "</select>";
        }
        return '<input class="fm-in" data-k="' + p[0] + '" style="width:' + p[2] + 'px" value="' + esc(v) + '"' + (p[0] === "Company.NameFr" || p[0] === "Company.Email" ? ' dir="ltr"' : "") + ">";
      };
      w.body.innerHTML =
        '<div class="fm-sec"><div class="fm-st">بيانات الشركة</div><div class="fm-sb">' + PROPS.slice(0, 7).map(function (p) { return field(p[1], inp(p), p[3]); }).join("") + "</div></div>" +
        '<div class="fm-sec"><div class="fm-st">البيانات الضريبية والتجارية</div><div class="fm-sb">' + PROPS.slice(7, 11).map(function (p) { return field(p[1], inp(p)); }).join("") + "</div></div>" +
        '<div class="fm-sec"><div class="fm-st">إعدادات عامة</div><div class="fm-sb">' + PROPS.slice(11).map(function (p) { return field(p[1], inp(p)); }).join("") +
        field("قاعدة البيانات", '<span class="fm-mono">' + esc(cl.active) + "</span>") + "</div></div>" +
        '<div class="fm-sec"><div class="fm-st">حسابات التواصل في الإيصالات</div><div class="fm-sb">' +
        SOCP.map(function (p) { return field(p[1], '<input class="fm-in" data-k="' + p[0] + '" dir="ltr" style="width:260px" placeholder="' + p[2] + '" value="' + esc(s[p[0]] || "") + '">'); }).join("") +
        field("في الإيصالات", '<select class="fm-in" data-k="Social.On" style="width:200px"><option value="1"' + (s["Social.On"] !== "0" ? " selected" : "") + '>إظهار شريط «تابعونا»</option><option value="0"' + (s["Social.On"] === "0" ? " selected" : "") + ">إخفاء</option></select>") +
        '<div style="font-size:11.5px;color:#64748b;margin:2px 0 0">اكتب اسم الحساب فقط (مثل <b dir="ltr">@anouerapp</b>) أو الرابط كاملاً — يظهر في آخر كل إيصال وفاتورة. اترك الخانة فارغة لإخفاء المنصة.</div>' +
        "</div></div>";
      w.setButtons([
        { t: "حفظ", cls: "ok", fn: function (w) {
          var name = w.$('[data-k="Company.Name"]');
          if (!name.value.trim()) { name.classList.add("err"); name.focus(); return; }
          var vals = {};
          w.$$("[data-k]").forEach(function (e) { vals[e.dataset.k] = e.value.trim(); });
          w.busy(true);
          call("fm.settings.set", { values: vals }).then(function () { try { if (window.ANOUER_RD && ANOUER_RD.resetCompany) { ANOUER_RD.resetCompany(); ANOUER_RD.company(); } } catch (x) { } T("تم حفظ خصائص الشركة", "s"); w.close(); refreshNews(); })
            .catch(function (e) { w.busy(false); fail(e); });
        } },
        { t: "إلغاء", cls: "no", fn: function (w) { w.close(); } }
      ]);
    }).catch(function (e) { w.close(); fail(e); });
  }

  // ==================================================================== 5-ب) الخصائص — لوحة DEXEF (أيقونة الترس + Ctrl+O)
  var HUB_IC = {
    sys: '<svg viewBox="0 0 48 48"><path d="M24 5a19 19 0 0 1 17.6 11.8" fill="none" stroke="#5aa9e6" stroke-width="3.4" stroke-linecap="round"/><path d="M43 10.5l-1.2 7.4-7.2-2" fill="none" stroke="#5aa9e6" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M24 43A19 19 0 0 1 6.4 31.2" fill="none" stroke="#5aa9e6" stroke-width="3.4" stroke-linecap="round"/><path d="M5 37.5l1.2-7.4 7.2 2" fill="none" stroke="#5aa9e6" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/><g fill="#1f6fd0"><circle cx="24" cy="24" r="7.2"/><rect x="22.2" y="13" width="3.6" height="5" rx="1"/><rect x="22.2" y="30" width="3.6" height="5" rx="1"/><rect x="13" y="22.2" width="5" height="3.6" rx="1"/><rect x="30" y="22.2" width="5" height="3.6" rx="1"/><rect x="22.2" y="13" width="3.6" height="5" rx="1" transform="rotate(45 24 24)"/><rect x="22.2" y="30" width="3.6" height="5" rx="1" transform="rotate(45 24 24)"/><rect x="13" y="22.2" width="5" height="3.6" rx="1" transform="rotate(45 24 24)"/><rect x="30" y="22.2" width="5" height="3.6" rx="1" transform="rotate(45 24 24)"/></g><circle cx="24" cy="24" r="3" fill="#fff"/></svg>',
    inv: '<svg viewBox="0 0 48 48"><path d="M12 5h17l9 9v29H12z" fill="#d7a9ef"/><path d="M29 5v9h9z" fill="#a35bc9"/></svg>',
    wh: '<svg viewBox="0 0 48 48"><rect x="7" y="7" width="27" height="8" rx="4" fill="#5fa9df"/><rect x="7" y="18" width="27" height="8" rx="4" fill="#5fa9df"/><rect x="7" y="29" width="22" height="8" rx="4" fill="#5fa9df"/><rect x="11" y="10" width="19" height="2" fill="#bfe0f6"/><rect x="11" y="21" width="19" height="2" fill="#bfe0f6"/><path d="M37 44V29m-6 6l6-6 6 6" fill="none" stroke="#1f6fd0" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    cust: '<svg viewBox="0 0 48 48"><circle cx="29" cy="15" r="8.5" fill="#7b2a8e"/><path d="M15 42c0-10 6.5-15 14-15s14 5 14 15z" fill="#7b2a8e"/><circle cx="19" cy="16" r="8.5" fill="#fff" stroke="#9b3fb3" stroke-width="2.6"/><path d="M5 42c0-10 6.5-15 14-15s14 5 14 15z" fill="#fff" stroke="#9b3fb3" stroke-width="2.6"/></svg>',
    tax: '<svg viewBox="0 0 48 48"><rect x="8" y="6" width="26" height="30" rx="4" fill="#a3231f"/><rect x="14" y="12" width="26" height="30" rx="4" fill="#8e1b17" stroke="#fff" stroke-width="2.2"/><rect x="19" y="20" width="16" height="3" rx="1.5" fill="#fff"/><rect x="19" y="27" width="16" height="3" rx="1.5" fill="#fff"/></svg>',
    usr: '<svg viewBox="0 0 48 48"><circle cx="24" cy="15" r="9" fill="#8fb4e8"/><path d="M7 42c0-10 7.5-15 17-15s17 5 17 15z" fill="#1f5fa8"/><path d="M19 27h10l-5 8z" fill="#8fb4e8"/></svg>',
    dev: '<svg viewBox="0 0 48 48"><rect x="4" y="8" width="9" height="32" rx="1.5" fill="#1f5fa8"/><rect x="6.5" y="12" width="4" height="2.5" fill="#8fb4e8"/><rect x="16" y="8" width="29" height="22" rx="2" fill="#1f5fa8"/><rect x="19" y="11" width="23" height="16" fill="#fff"/><rect x="27" y="30" width="7" height="6" fill="#1f5fa8"/><rect x="21" y="36" width="19" height="3.5" rx="1.5" fill="#1f5fa8"/></svg>',
    view: '<svg viewBox="0 0 48 48"><circle cx="11" cy="12" r="5" fill="#e08a5a"/><circle cx="11" cy="27" r="5" fill="#e08a5a"/><rect x="20" y="9" width="23" height="6" rx="3" fill="#f2b79a"/><rect x="20" y="18" width="23" height="4" rx="2" fill="#f7d5c4"/><rect x="20" y="24" width="23" height="6" rx="3" fill="#f2b79a"/><rect x="20" y="33" width="23" height="4" rx="2" fill="#f7d5c4"/></svg>',
    news: '<svg viewBox="0 0 48 48"><rect x="5" y="5" width="38" height="38" rx="6" fill="#a6b0d9"/><circle cx="16" cy="32" r="3.6" fill="#2f3a8f"/><path d="M13 21a14 14 0 0 1 14 14M13 12a23 23 0 0 1 23 23" fill="none" stroke="#2f3a8f" stroke-width="4" stroke-linecap="round"/></svg>',
    fld: '<svg viewBox="0 0 48 48"><g fill="#8e6c8c"><rect x="7" y="8" width="9" height="14" rx="4"/><rect x="20" y="8" width="9" height="14" rx="4" opacity=".55"/><rect x="33" y="8" width="9" height="14" rx="4" opacity=".55"/><rect x="7" y="26" width="9" height="14" rx="4" opacity=".55"/><rect x="20" y="26" width="9" height="14" rx="4"/><rect x="33" y="26" width="9" height="14" rx="4" opacity=".55"/></g></svg>',
    add: '<svg viewBox="0 0 48 48"><rect x="6" y="11" width="36" height="28" rx="3" fill="#b8b06b"/><rect x="10" y="7" width="32" height="12" rx="2" fill="#8c8442"/><rect x="6" y="19" width="36" height="20" rx="3" fill="#cfc88c"/></svg>',
    rep: '<svg viewBox="0 0 48 48"><path d="M10 6l32 32-4 4L6 10z" fill="#5c88d6"/><path d="M38 6l4 4-29 29-8 3 3-8z" fill="#2f5fb8"/><path d="M5 42l3-8 5 5z" fill="#1d3f80"/></svg>'
  };
  function feh(path) {   /* عنصر من قائمة «الفهرس» بالمسار */
    var list = window.__FEH || [], it = null;
    path.forEach(function (t) { it = (list || []).filter(function (x) { return x.t === t; })[0]; list = it && it.sub; });
    return it;
  }
  function runItem(it, name) { if (it && it.run) { try { it.run(); return true; } catch (e) { } } T("«" + name + "» غير متوفر في هذا الإصدار", "i"); return false; }
  function soon(name) { T("«" + name + "» — هذه الإعدادات لم تُبنَ بعد في ANOUER", "i"); }
  var HUB = [
    ["sys", "إعدادات النظام", function () { propertiesWin(); }],
    ["inv", "الفواتير", function () { soon("الفواتير"); }],
    ["wh", "المخازن", function () { runItem(feh(["دليل الأصناف", "المخازن"]), "المخازن"); }],
    ["cust", "العملاء و الموردين", function () { runItem(feh(["دليل العملاء و الموردين", "المجموعات"]), "العملاء و الموردين"); }],
    ["tax", "الضرائب", function () { soon("الضرائب"); }],
    ["usr", "صلاحيات\nالمستخدمين", function () { var it = null; (window.__FEH || []).forEach(function (x) { if (x.t === "المستخدمين") it = x; (x.sub || []).forEach(function (y) { if (y.t === "المستخدمين") it = y; }); }); runItem(it, "صلاحيات المستخدمين"); }],
    ["dev", "الأجهزة و الطابعات", function () { soon("الأجهزة و الطابعات"); }],
    ["view", "طريقة العرض", function () { soon("طريقة العرض"); }],
    ["news", "شريط الأخبار", function () { showNews(!newsOn()); }],
    ["fld", "الحقول الإضافية", function () { soon("الحقول الإضافية"); }],
    ["add", "الإضافات", function () { soon("الإضافات"); }],
    ["rep", "تصميم التقارير", function () { if (window.ANOUER_RDM) window.ANOUER_RDM.open(); else soon("تصميم التقارير"); }]
  ];
  var hubEl = null, hubKey = null;
  /* مفاتيح اللوحة: تمر عبر window.__viewKey قبل حاجز المفاتيح العام */
  (function () { var prev = window.__viewKey; window.__viewKey = function (e) { if (hubKey && hubKey(e)) return true; return prev ? prev(e) : false; }; })();
  function propsHub() {
    if (hubEl) { hubEl.remove(); hubEl = null; }
    var ov = document.createElement("div");
    ov.className = "fm-hub";
    ov.innerHTML = '<div class="fm-hubw" role="dialog" aria-modal="true" aria-label="الخصائص" tabindex="-1"><div class="fm-hubh"><b>الخصائص</b><span class="sp"></span>' +
      '<button type="button" data-h="min" title="تصغير">—</button><button type="button" data-h="max" title="تكبير">☐</button><button type="button" data-h="x" title="إغلاق (Esc)">✕</button></div>' +
      '<div class="fm-hubb"><div class="fm-hubg">' + HUB.map(function (h, i) {
        return '<button type="button" class="fm-tile" data-i="' + i + '" data-k="' + h[0] + '"><span class="ti">' + HUB_IC[h[0]] + '</span><span class="tt">' + esc(h[1]).replace("\n", "<br>") + "</span></button>";
      }).join("") + "</div></div></div>";
    document.body.appendChild(ov); hubEl = ov;
    var close = function () { if (hubEl === ov) hubEl = null; ov.remove(); hubKey = null; };
    var key = function (e) {
      if (!ov.parentNode || document.querySelector(".fm-ov,.rdm-ov.show,.rdx-ov.show,.rdp-ov.show,.rdm-dov")) return false;   // «تصميم التقارير» فوق اللوحة
      if (ov.__ppKey) return ov.__ppKey(e);
      var ts = Array.prototype.slice.call(ov.querySelectorAll(".fm-tile")), i = ts.indexOf(document.activeElement);
      if (e.key === "Escape") { close(); }
      else if (e.key === "ArrowLeft" || e.key === "ArrowRight") { i = i < 0 ? 0 : (i + (e.key === "ArrowLeft" ? 1 : -1) + ts.length) % ts.length; ts[i].focus(); }
      else if (e.key === "ArrowDown" || e.key === "ArrowUp") { i = i < 0 ? 0 : Math.max(0, Math.min(ts.length - 1, i + (e.key === "ArrowDown" ? 5 : -5))); ts[i].focus(); }
      else if (e.key === "Enter" && i >= 0) { ts[i].click(); }
      else return /^F\d+$/.test(e.key) || e.ctrlKey;   // لا تصل اختصارات الشاشة خلف النافذة
      return true;
    };
    hubKey = key;
    ov.addEventListener("click", function (e) {
      var h = e.target.closest("[data-h]");
      if (h) { if (h.dataset.h === "max") ov.classList.toggle("max"); else close(); return; }
      var t = e.target.closest(".fm-tile"); if (!t) return;
      var it = HUB[+t.dataset.i];
      if (window.__propsTile && window.__propsTile(it[0], ov, close)) return;   // شاشات الخصائص (props.js) — مطابقة DEXEF
      if (it[0] !== "sys") close();
      it[2]();
    });
    ov.addEventListener("mousedown", function (e) { if (e.target === ov) close(); });
    setTimeout(function () { var f = ov.querySelector(".fm-tile"); if (f) f.focus(); }, 30);
  }
  window.__propsHub = propsHub;
  window.__news = { show: function (on) { showNews(on); }, refresh: function () { refreshNews(); }, get on() { return newsOn(); } };

  // ==================================================================== 6) استيراد من إكسيل
  var XLSX_URL = "/assets/js/vendor/xlsx.full.min.js";
  var xlsxP = null;
  function loadXLSX() {
    if (window.XLSX) return Promise.resolve(window.XLSX);
    if (!xlsxP) xlsxP = new Promise(function (res, rej) {
      var s = document.createElement("script");
      s.src = XLSX_URL; s.onload = function () { window.XLSX ? res(window.XLSX) : rej(new Error("تعذّر تحميل مكتبة إكسيل")); };
      s.onerror = function () { xlsxP = null; rej(new Error("مكتبة قراءة إكسيل غير موجودة: " + XLSX_URL)); };
      document.head.appendChild(s);
    });
    return xlsxP;
  }
  var norm = function (s) { return String(s || "").trim().toLowerCase().replace(/[\s_\-.:]+/g, " ").replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي"); };

  var IMPORTS = {
    products: {
      title: "استيراد الأصناف", action: "products.import",
      fields: [
        ["Code", "الكود", true, ["الكود", "كود", "كود الصنف", "رقم الصنف", "الرقم", "code", "ref", "reference", "référence", "item code"]],
        ["Name", "اسم الصنف", true, ["اسم الصنف", "الاسم", "الصنف", "البيان", "name", "designation", "désignation", "libelle", "libellé", "item"]],
        ["Category", "المجموعة", false, ["المجموعه", "المجموعة", "الفئة", "التصنيف", "القسم", "category", "famille", "groupe", "group"]],
        ["UnitName", "الوحدة", false, ["الوحدة", "الوحده", "وحدة", "unit", "unite", "unité", "uom"]],
        ["Factor", "المعامل", false, ["المعامل", "عدد القطع", "عدد الوحدات", "القطع", "معامل التحويل", "العبوه", "العبوة", "factor", "colisage", "qte/colis"]],
        ["Price", "سعر البيع", false, ["سعر البيع", "السعر", "سعر", "price", "prix", "prix vente", "pv"]],
        ["Cost", "سعر الشراء", false, ["سعر الشراء", "التكلفه", "التكلفة", "cost", "prix achat", "pa", "cout"]],
        ["Barcode", "الباركود", false, ["الباركود", "باركود", "barcode", "code barre", "code barres", "ean", "gencod"]],
        ["Price5", "سعر 5 فما فوق", false, ["سعر 5ومافوق", "سعر 5 ومافوق", "سعر 5 وما فوق", "سعر 5 فما فوق", "سعر5", "5ومافوق", "5 فما فوق", "السعر 1", "price5", "prix 5"]],
        ["Stock", "الرصيد", false, ["الرصيد", "الكميه", "الكمية", "المخزون", "الرصيد الحالي", "stock", "qte", "quantite", "quantité"]]
      ],
      note: "كل سطر = وحدة صنف (قطعة، كرتونة ...) بسعرها ومعاملها وباركودها. الصنف الموجود يُحدَّث سعره ورصيده، و«سعر 5 فما فوق» يظهر في عمود «السعر 1» بشاشة المبيعات."
    },
    customers: {
      title: "استيراد العملاء", action: "fm.import.customers",
      fields: [
        ["Code", "الكود", false, ["الكود", "كود", "كود العميل", "الرقم", "code", "ref"]],
        ["Name", "اسم العميل", true, ["الاسم", "اسم العميل", "العميل", "name", "nom", "client", "raison sociale"]],
        ["Phone", "الهاتف", false, ["الهاتف", "التليفون", "الموبايل", "رقم الهاتف", "phone", "tel", "tél", "téléphone", "telephone", "mobile"]],
        ["Address", "العنوان", false, ["العنوان", "address", "adresse"]],
        ["OpeningBalance", "الرصيد الافتتاحي", false, ["الرصيد الافتتاحي", "الرصيد الإفتتاحى", "الرصيد", "balance", "solde", "solde initial"]]
      ],
      note: "العميل الموجود بنفس الكود تُحدَّث بياناته (الاسم/الهاتف/العنوان) دون تغيير رصيده. الكود الفارغ يُولَّد تلقائياً."
    },
    suppliers: {
      title: "استيراد الموردين", action: "fm.import.suppliers",
      fields: [
        ["Code", "الرقم", false, ["الرقم", "الكود", "كود", "كود المورد", "رقم المورد", "code", "ref"]],
        ["Name", "اسم المورد", true, ["الاسم", "اسم المورد", "المورد", "name", "nom", "fournisseur", "raison sociale"]],
        ["Phone", "تليفون 1", false, ["تليفون 1", "تليفون1", "الهاتف", "التليفون", "تليفون", "الموبايل", "phone", "tel", "tél", "téléphone", "telephone", "mobile"]],
        ["Address", "العنوان", false, ["العنوان", "address", "adresse"]],
        ["OpeningBalance", "الرصيد الافتتاحي", false, ["الرصيد الافتتاحي", "الرصيد الإفتتاحى", "الرصيد", "balance", "solde"]],
        ["CreditLimit", "حد الإئتمان", false, ["حد الإئتمان", "حد الائتمان", "حد الإئتمان", "credit", "plafond"]],
        ["Group", "المجموعة", false, ["المجموعة", "المجموعه", "group", "groupe"]],
        ["Active", "نشط", false, ["نشط", "active", "actif"]]
      ],
      note: "المورد الموجود بنفس الكود تُحدَّث بياناته دون تغيير رصيده. الكود الفارغ يُولَّد تلقائياً."
    }
  };

  function toNum(v) {
    if (v == null || v === "") return null;
    if (typeof v === "number") return isFinite(v) ? v : null;
    var s = String(v).replace(/[\s ]/g, "").replace(/[٠-٩]/g, function (d) { return "٠١٢٣٤٥٦٧٨٩".indexOf(d); });
    if (/^-?\d{1,3}(,\d{3})+(\.\d+)?$/.test(s)) s = s.replace(/,/g, "");
    else s = s.replace(",", ".");
    s = s.replace(/[^\d.\-]/g, "");
    var n = parseFloat(s);
    return isFinite(n) ? n : null;
  }
  var cellStr = function (v) { if (v == null) return ""; if (v instanceof Date) return v.toISOString().slice(0, 10); if (typeof v === "number" && Math.floor(v) === v && Math.abs(v) > 1e11) return v.toFixed(0); return String(v).trim(); };

  // ---------------------------------------------------------------- نافذة الاستيراد (تصميم بخطوات)
  var IMX = {
    file: '<svg viewBox="0 0 48 48"><rect x="9" y="4" width="26" height="40" rx="3" fill="#e7f4ec" stroke="#1d7a46" stroke-width="2"/><path d="M35 4v9h9" fill="#cdebd8" stroke="#1d7a46" stroke-width="2" stroke-linejoin="round"/><path d="M27 4l8 0 9 9v27a4 4 0 0 1-4 4H27" fill="none"/><rect x="3" y="18" width="22" height="16" rx="2" fill="#1d7a46"/><path d="M8 22l6 8M14 22l-6 8" stroke="#fff" stroke-width="2.2" stroke-linecap="round"/><path d="M29 22h9M29 27h9M29 32h9" stroke="#1d7a46" stroke-width="2" stroke-linecap="round"/></svg>',
    up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/></svg>',
    ok: '<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="7" fill="#2e8b57"/><path d="M4.6 8.2l2.2 2.2 4.6-4.8" stroke="#fff" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    no: '<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="7" fill="#c9d1db"/><path d="M5 8h6" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/></svg>',
    req: '<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="7" fill="#d84a3a"/><path d="M8 4.5v4.2M8 11v.4" stroke="#fff" stroke-width="1.9" stroke-linecap="round"/></svg>'
  };

  function importWin(kind) {
    var cfg = IMPORTS[kind], isP = kind === "products";
    var wb = null, sheetRows = [], headerRow = 0, map = {}, fileName = "", fileSize = 0, cache = {};
    var w = win({
      title: cfg.title + " من إكسيل", icon: IC.xls, width: 1120,
      body:
        '<div class="ix">' +
        '<ol class="ix-steps"><li class="on" data-s="1"><i>1</i><span>اختيار الملف</span></li><li data-s="2"><i>2</i><span>ربط الأعمدة</span></li><li data-s="3"><i>3</i><span>المعاينة والاستيراد</span></li></ol>' +
        '<section class="ix-card" id="ixFileCard">' +
        ' <div class="ix-drop" id="ixDrop" tabindex="0"><span class="ix-ic">' + IMX.file + '</span><div><b>اسحب ملف إكسيل هنا</b><span>أو انقر لاختيار ملف — xlsx، xls، ods، csv</span></div><button type="button" class="fm-btn" id="imPick"><span class="ix-bi">' + IMX.up + '</span>اختيار ملف</button></div>' +
        ' <div class="ix-filebar" id="ixFileBar" hidden><span class="ix-ic sm">' + IMX.file + '</span><div class="ix-fn"><b id="imFile"></b><span id="imFileMeta"></span></div>' +
        '  <label class="ix-sheet" id="ixSheetBox" hidden>ورقة العمل<select class="fm-in" id="imSheet"></select></label>' +
        '  <button type="button" class="fm-btn ghost" id="imRepick">تغيير الملف</button></div>' +
        ' <input type="file" id="imF" accept=".xlsx,.xlsm,.xls,.ods,.csv" hidden>' +
        '</section>' +
        '<div id="imMapBox" hidden>' +
        ' <section class="ix-card"><header class="ix-h"><b>ربط الأعمدة</b><span>تم التعرّف على الأعمدة تلقائياً من صف العناوين — عدّل أي خانة عند الحاجة.</span></header>' +
        '  <div class="ix-map" id="imMap"></div>' +
        (isP ? '  <div class="ix-opts"><label class="ix-tg"><input type="checkbox" id="imMerge" checked><i></i><span><b>دمج الأصناف التي لها نفس الاسم</b><small>الكود الثاني للصنف (مثل باركود القطعة) يُحفظ باركوداً لوحدته بدل إنشاء صنف مكرر، ويُطابَق الصنف الموجود بالاسم.</small></span></label></div>' : "") +
        ' </section>' +
        ' <div class="ix-stats" id="imStats"></div>' +
        ' <section class="ix-card ix-pv"><header class="ix-h"><b>معاينة</b><span id="imPvNote"></span></header><div class="ix-tw"><table class="ix-tbl" id="imPrev"></table></div><div class="ix-info" id="imInfo"></div></section>' +
        '</div>' +
        '<div id="imRes"></div>' +
        '<p class="ix-tip">' + esc(cfg.note) + "</p>" +
        "</div>",
      buttons: [
        { t: "استيراد", cls: "ok ix-go", id: "imGo", fn: go },
        isP ? { t: "فحص الأصناف المكررة", cls: "ghost", fn: function () { dupesWin(); } } : null,
        "|",
        { t: "إغلاق", cls: "no", fn: function (w) { w.close(); } }
      ].filter(Boolean)
    });
    var goBtn = w.foot.querySelector("#imGo"); goBtn.disabled = true;
    var fi = w.$("#imF"), sh = w.$("#imSheet"), drop = w.$("#ixDrop");
    var pick = function () { fi.click(); };
    w.$("#imPick").addEventListener("click", function (e) { e.stopPropagation(); pick(); });
    w.$("#imRepick").addEventListener("click", pick);
    drop.addEventListener("click", pick);
    drop.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(); } });
    ["dragenter", "dragover"].forEach(function (ev) { w.el.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add("hot"); }); });
    ["dragleave", "drop"].forEach(function (ev) { w.el.addEventListener(ev, function (e) { e.preventDefault(); if (ev === "drop" || e.target === drop) drop.classList.remove("hot"); }); });
    w.el.addEventListener("drop", function (e) { var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]; if (f) readFile(f); });
    fi.addEventListener("change", function () { var f = fi.files && fi.files[0]; fi.value = ""; if (f) readFile(f); });
    sh.addEventListener("change", function () { useSheet(sh.value); });
    var mgc = w.$("#imMerge"); if (mgc) mgc.addEventListener("change", function () { if (sheetRows.length) renderPreview(); });

    function setStep(n) { w.$$(".ix-steps li").forEach(function (li) { var s = +li.dataset.s; li.classList.toggle("on", s === n); li.classList.toggle("done", s < n); }); }

    function readFile(f) {
      if (!/\.(xlsx|xlsm|xls|ods|csv)$/i.test(f.name)) { T("صيغة الملف غير مدعومة: " + f.name, "w"); return; }
      drop.classList.add("busy"); drop.querySelector("b").textContent = "جارٍ قراءة " + f.name + " ...";
      loadXLSX().then(function (XLSX) {
        return f.arrayBuffer().then(function (buf) {
          if (/\.csv$/i.test(f.name)) {
            var txt = new TextDecoder("utf-8").decode(buf);
            if (txt.indexOf("�") >= 0) { try { txt = new TextDecoder("windows-1256").decode(buf); } catch (e) { } }
            return XLSX.read(txt.replace(/^﻿/, ""), { type: "string", cellDates: true });
          }
          return XLSX.read(buf, { type: "array", cellDates: true });
        });
      }).then(function (book) {
        wb = book; fileName = f.name; fileSize = f.size; cache = {};
        var names = book.SheetNames.filter(function (n) { return rowsOf(n).length > 0; });
        if (!names.length) { T("الملف لا يحتوي على بيانات", "w"); resetDrop(); return; }
        w.$("#imFile").textContent = f.name;
        w.$("#imFileMeta").textContent = size(f.size) + " — " + book.SheetNames.length + " ورقة";
        sh.innerHTML = names.map(function (n) { return '<option value="' + esc(n) + '">' + esc(n) + " (" + Math.max(0, rowsOf(n).length - 1) + " سطر)</option>"; }).join("");
        w.$("#ixSheetBox").hidden = names.length < 2;
        drop.hidden = true; w.$("#ixFileBar").hidden = false; resetDrop();
        useSheet(names[0]);
      }).catch(function (e) { resetDrop(); fail(e); });
    }
    function resetDrop() { drop.classList.remove("busy"); drop.querySelector("b").textContent = "اسحب ملف إكسيل هنا"; }

    function rowsOf(name) {
      if (cache[name]) return cache[name];
      var rows = XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, raw: true, defval: "", blankrows: false });
      return (cache[name] = rows.filter(function (r) { return r.some(function (c) { return cellStr(c) !== ""; }); }));
    }

    function useSheet(name) {
      sheetRows = rowsOf(name);
      var best = 0, bestScore = -1;
      for (var i = 0; i < Math.min(10, sheetRows.length); i++) { var sc = scoreHeader(sheetRows[i]); if (sc > bestScore) { best = i; bestScore = sc; } }
      headerRow = best;
      var hdr = sheetRows[headerRow] || [], used = {};
      map = {};
      // مطابقة تامة أولاً لكل الحقول، ثم مطابقة جزئية للأعمدة غير المستخدمة
      cfg.fields.forEach(function (f) {
        var al = f[3].map(norm), idx = -1;
        hdr.forEach(function (h, j) { if (idx < 0 && !used[j] && al.indexOf(norm(h)) >= 0) idx = j; });
        map[f[0]] = idx; if (idx >= 0) used[idx] = 1;
      });
      cfg.fields.forEach(function (f) {
        if (map[f[0]] >= 0) return;
        var al = f[3].map(norm), idx = -1;
        hdr.forEach(function (h, j) { var n = norm(h); if (idx < 0 && !used[j] && n && al.some(function (a) { return a.length > 2 && (n.indexOf(a) >= 0 || a.indexOf(n) >= 0); })) idx = j; });
        map[f[0]] = idx; if (idx >= 0) used[idx] = 1;
      });
      renderMap(); renderPreview();
      w.$("#imMapBox").hidden = false;
      w.$("#imRes").innerHTML = "";
      setStep(2);
    }
    function scoreHeader(r) {
      var n = 0;
      cfg.fields.forEach(function (f) { var al = f[3].map(norm); if (r.some(function (h) { return al.indexOf(norm(h)) >= 0; })) n++; });
      return n;
    }
    function sample(j) {
      for (var i = headerRow + 1; i < Math.min(sheetRows.length, headerRow + 30); i++) { var v = cellStr((sheetRows[i] || [])[j]); if (v) return v; }
      return "";
    }
    function renderMap() {
      var hdr = sheetRows[headerRow] || [];
      var opts = '<option value="-1">— غير موجود —</option>' + hdr.map(function (h, j) { return '<option value="' + j + '">' + esc(cellStr(h) || "عمود " + (j + 1)) + "</option>"; }).join("");
      w.$("#imMap").innerHTML = cfg.fields.map(function (f) {
        return '<div class="ix-f" data-f="' + f[0] + '"><div class="ix-fl"><span class="ix-st"></span><b>' + esc(f[1]) + (f[2] ? '<em>*</em>' : "") + '</b></div>' +
          '<select class="fm-in">' + opts + '</select><small class="ix-smp"></small></div>';
      }).join("");
      w.$$(".ix-f").forEach(function (box) {
        var s = box.querySelector("select"), k = box.dataset.f;
        s.value = String(map[k]);
        s.addEventListener("change", function () { map[k] = +s.value; paintMap(); renderPreview(); });
      });
      paintMap();
    }
    function paintMap() {
      w.$$(".ix-f").forEach(function (box) {
        var k = box.dataset.f, f = cfg.fields.filter(function (x) { return x[0] === k; })[0], on = map[k] >= 0;
        var need = f[2] && !on && !(isP && k === "Code" && map.Barcode >= 0);
        box.classList.toggle("on", on); box.classList.toggle("need", need);
        box.querySelector(".ix-st").innerHTML = on ? IMX.ok : need ? IMX.req : IMX.no;
        var smp = on ? sample(map[k]) : "";
        box.querySelector(".ix-smp").textContent = on ? (smp ? "مثال: " + smp : "العمود فارغ") : (k === "Factor" && isP ? "يُستنتج من اسم الوحدة" : need ? "مطلوب" : "لن يُستورد");
      });
    }

    function buildRows() {
      var out = [], data = sheetRows.slice(headerRow + 1), bad = 0;
      data.forEach(function (r) {
        var g = function (k) { var i = map[k]; return i >= 0 ? r[i] : ""; };
        var o = {};
        cfg.fields.forEach(function (f) { var v = g(f[0]); o[f[0]] = /^(Price|Price5|Cost|Factor|OpeningBalance|Stock|CreditLimit)$/.test(f[0]) ? toNum(v) : cellStr(v); });
        if ("Active" in o) { var av = String(o.Active).trim().toLowerCase(); o.Active = map.Active >= 0 && av !== "" ? !/^(0|false|no|لا|غير نشط|×|x)$/.test(av) : null; }
        if ("Group" in o && !o.Group) o.Group = null;
        if ("CreditLimit" in o && !(map.CreditLimit >= 0)) o.CreditLimit = null;
        if (isP) {
          if (!o.Code) o.Code = o.Barcode;
          if (!o.UnitName) o.UnitName = "قطعة";
          if (!(map.Factor >= 0)) { var mm = String(o.UnitName).match(/(\d+)/); o.Factor = mm && +mm[1] > 1 ? +mm[1] : 1; }
          if (!o.Factor || o.Factor <= 0) o.Factor = 1;
          if (!o.Barcode) o.Barcode = null;
          if (!o.Category) o.Category = null;
          if (!(map.Stock >= 0)) o.Stock = null;
          if (!(map.Price5 >= 0) || !(o.Price5 > 0)) o.Price5 = null;
          if (!o.Code || !o.Name) { bad++; return; }
        } else if (!o.Name) { bad++; return; }
        out.push(o);
      });
      var info = { rows: out, bad: bad, merged: 0, total: data.length };
      if (isP) {
        if (mgc && mgc.checked) info.merged = mergeByName(out, info);
        var cs = {}, warn = 0;
        info.rows.forEach(function (r) {
          cs[r.Code] = 1;
          r._w = map.Factor >= 0 && r.Factor === 1 && /\d/.test(r.UnitName) && !/^قطع|^حبة/.test(r.UnitName) && +(String(r.UnitName).match(/(\d+)/) || [0, 0])[1] > 1;
          if (r._w) warn++;
        });
        info.codes = Object.keys(cs).length; info.warn = warn;
      }
      return info;
    }
    /** نفس الاسم = نفس الصنف: الكود الأول هو كود الصنف، والأكواد الأخرى تُحفظ باركوداً لوحداتها. */
    function mergeByName(rows, info) {
      var isBc = function (c) { return /^\d{8,14}$/.test(c); };
      var main = {};
      rows.forEach(function (r) { var k = r.Name.trim(); if (!isBc(r.Code) && !(k in main)) main[k] = r.Code; });
      rows.forEach(function (r) { var k = r.Name.trim(); if (!(k in main)) main[k] = r.Code; });
      var out = [], seen = {}, merged = 0;
      rows.forEach(function (r) {
        var m = main[r.Name.trim()];
        if (m !== r.Code) { if (!r.Barcode) r.Barcode = r.Code; r.Code = m; merged++; }
        var k = r.Code + "\u0001" + r.UnitName;
        if (seen[k]) { if (!seen[k].Barcode && r.Barcode) seen[k].Barcode = r.Barcode; if (seen[k].Stock == null && r.Stock != null) seen[k].Stock = r.Stock; return; }
        seen[k] = r; out.push(r);
      });
      info.rows = out;
      return merged;
    }

    function stat(v, l, cls) { return '<div class="ix-s ' + (cls || "") + '"><b>' + v + "</b><span>" + l + "</span></div>"; }
    function renderPreview() {
      var b = buildRows(), shown = b.rows.slice(0, 100);
      var numF = /^(Price|Price5|Cost|Factor|OpeningBalance|Stock|CreditLimit)$/;
      var cols = cfg.fields.filter(function (f) { return map[f[0]] >= 0 || (isP && f[0] === "Factor"); });
      w.$("#imPrev").innerHTML = "<thead><tr><th class=\"n\">#</th>" + cols.map(function (f) { return "<th" + (numF.test(f[0]) ? ' class="num"' : "") + ">" + esc(f[1]) + "</th>"; }).join("") + "</tr></thead><tbody>" +
        (shown.length ? shown.map(function (o, i) {
          return "<tr" + (o._w ? ' class="w"' : "") + '><td class="n">' + (i + 1) + "</td>" + cols.map(function (f) {
            var v = o[f[0]], isN = numF.test(f[0]);
            return "<td" + (isN ? ' class="num"' : "") + (o._w && f[0] === "Factor" ? ' title="الوحدة تحتوي رقماً والمعامل 1 — تأكد من عمود عدد القطع"' : "") + ">" +
              (v == null || v === "" ? '<span class="ix-nil">—</span>' : typeof v === "boolean" ? (v ? "نعم" : "لا") : esc(isN ? (f[0] === "Factor" || f[0] === "Stock" ? String(+v) : fmt(v)) : v)) + "</td>";
          }).join("") + "</tr>";
        }).join("") : '<tr><td colspan="' + (cols.length + 1) + '" class="fm-empty">لا توجد سطور صالحة — راجع ربط الأعمدة</td></tr>') + "</tbody>";
      w.$("#imPvNote").textContent = b.rows.length > 100 ? "أول 100 سطر من " + b.rows.length : b.rows.length + " سطر";
      var req = cfg.fields.filter(function (f) { return f[2] && !(map[f[0]] >= 0) && !(isP && f[0] === "Code" && map.Barcode >= 0); });
      w.$("#imStats").innerHTML =
        stat(b.total, "سطر في الورقة") + stat(b.rows.length, isP ? "سطر وحدة للاستيراد" : "سطر للاستيراد", "ok") +
        (isP ? stat(b.codes, "صنف", "pri") + stat(b.merged, "سطر مدموج بالاسم") : "") +
        stat(b.bad, "سطر ناقص يُتجاهل", b.bad ? "bad" : "") +
        (isP && b.warn ? stat(b.warn, "تحقق من المعامل", "warn") : "");
      w.$("#imInfo").innerHTML = req.length ? '<span class="ix-err">حدد العمود المطلوب: ' + req.map(function (f) { return esc(f[1]); }).join("، ") + "</span>" :
        (isP && b.warn ? '<span class="ix-wtx">السطور المظللة: اسم الوحدة يحتوي رقماً (مثل «كرتونة 24Units») لكن عدد القطع في الملف 1.</span>' : "");
      goBtn.disabled = !b.rows.length || req.length > 0;
      goBtn.textContent = b.rows.length ? "استيراد " + (isP ? b.codes + " صنف" : b.rows.length + " سطر") : "استيراد";
      setStep(req.length ? 2 : 3);
    }

    function go(w) {
      if (!needHost()) return;
      var b = buildRows();
      if (!b.rows.length) return;
      var rows = b.rows.map(function (r) { var o = {}; Object.keys(r).forEach(function (k) { if (k !== "_w") o[k] = r[k]; }); return o; });
      var groups = [], idx = {};
      rows.forEach(function (r) {
        var k = isP ? String(r.Code).trim() : "#" + groups.length;
        if (!(k in idx)) { idx[k] = groups.length; groups.push([]); }
        groups[idx[k]].push(r);
      });
      var chunks = [], cur = [];
      groups.forEach(function (g) { if (cur.length && cur.length + g.length > 200) { chunks.push(cur); cur = []; } cur = cur.concat(g); });
      if (cur.length) chunks.push(cur);
      var byName = !!(mgc && mgc.checked);

      var tot = { Total: 0, Ok: 0, Failed: 0, ProductsAffected: 0, Details: [] }, done = 0, t0 = Date.now();
      w.busy(true); goBtn.disabled = true;
      w.$$(".ix-f select, #imMerge, #imSheet, #imRepick").forEach(function (e) { e.disabled = true; });
      var res = w.$("#imRes");
      var prog = function () {
        var pct = Math.round(done * 100 / rows.length), sec = Math.round((Date.now() - t0) / 1000);
        res.innerHTML = '<section class="ix-card ix-prog"><div class="ix-ph"><b>جارٍ الاستيراد ...</b><span>' + done + " / " + rows.length + " سطر — " + sec + " ث</span><em>" + pct + '%</em></div><div class="ix-bar"><i style="width:' + pct + '%"></i></div></section>';
      };
      prog();
      var timer = setInterval(prog, 1000);
      var step = function (n) {
        if (n >= chunks.length) return Promise.resolve();
        return call(cfg.action, { rows: chunks[n], fileName: fileName, matchByName: byName }).then(function (r) {
          tot.Total += r.Total || 0; tot.Ok += r.Ok || 0; tot.Failed += r.Failed || 0; tot.ProductsAffected += r.ProductsAffected || 0;
          (r.Details || []).forEach(function (d) { if (tot.Details.length < 200) tot.Details.push(d); });
        }, function (e) {
          tot.Total += chunks[n].length; tot.Failed += chunks[n].length; tot.Details.push("دفعة " + (n + 1) + ": " + ((e && e.message) || e));
        }).then(function () { done += chunks[n].length; prog(); return step(n + 1); });
      };
      step(0).then(function () {
        clearInterval(timer);
        w.busy(false); goBtn.disabled = true;
        w.$$(".ix-f select, #imMerge, #imSheet, #imRepick").forEach(function (e) { e.disabled = false; });
        var sec = Math.round((Date.now() - t0) / 1000);
        var det = tot.Details.slice(0, 40).map(function (d) { return "<li>" + esc(d) + "</li>"; }).join("");
        res.innerHTML = '<section class="ix-card ix-done ' + (tot.Failed ? "warn" : "") + '"><div class="ix-dh"><span class="ix-ic sm">' + (tot.Failed ? IMX.req : IMX.ok) + "</span><b>" +
          (tot.Failed ? "انتهى الاستيراد مع بعض الأخطاء" : "تم الاستيراد بنجاح") + "</b><span>المدة " + sec + " ث — " + (isP ? "الأصناف" : "البيانات") + " متاحة الآن في البرنامج</span></div>" +
          '<div class="ix-stats">' + stat(tot.Ok, "سطر مستورد", "ok") + (isP ? stat(tot.ProductsAffected, "صنف جديد أو محدَّث", "pri") : "") + stat(tot.Failed, "سطر فشل", tot.Failed ? "bad" : "") + "</div>" +
          (det ? '<details class="ix-det"' + (tot.Failed ? " open" : "") + "><summary>التفاصيل</summary><ul>" + det + "</ul></details>" : "") + "</section>";
        res.scrollIntoView({ block: "nearest" });
        T(tot.Failed ? "انتهى الاستيراد مع أخطاء" : "تم الاستيراد بنجاح", tot.Failed ? "w" : "s");
        try {
          var L = window.__anouerLink, nop = function () { };
          if (L && isP && L.loadProducts) Promise.resolve(L.loadProducts()).catch(nop);
          if (L && kind === "customers" && L.loadCustomers) Promise.resolve(L.loadCustomers()).catch(nop);
          if (kind === "suppliers" && window.ANOUER_SUPPLIERS) Promise.resolve(ANOUER_SUPPLIERS.reload()).catch(nop);
        } catch (e) { }
      });
    }
  }

  // ---------------------------------------------------------------- دمج الأصناف المكررة
  function dupesWin() {
    if (!needHost()) return;
    var w = win({ title: "الأصناف المكررة", icon: IC.xls, width: 760, body: '<div class="fm-empty">جارٍ الفحص ...</div>', buttons: [] });
    call("fm.products.dupes").then(function (r) {
      if (!r.Groups) {
        w.body.innerHTML = '<div class="fm-note fm-ok">لا توجد أصناف مكررة بنفس الاسم.</div>';
        w.setButtons([{ t: "إغلاق", cls: "no", fn: function (w) { w.close(); } }]);
        return;
      }
      w.body.innerHTML =
        '<div class="fm-note fm-warn">يوجد <b>' + r.Groups + "</b> صنفاً مسجلاً أكثر من مرة بنفس الاسم. عند الدمج يبقى صنف واحد لكل اسم (الأكثر استخداماً في الفواتير)، " +
        "وتُنقل إليه الوحدات والباركود وسطور الفواتير، ويُحفظ أعلى رصيد. يحفظ البرنامج نسخة احتياطية قبل الدمج.</div>" +
        '<div class="fm-scroll" style="max-height:340px"><table class="fm-tbl"><thead><tr><th>الصنف</th><th style="width:130px">الكود المحتفَظ به</th><th style="width:200px">يُدمج فيه</th></tr></thead><tbody>' +
        r.Sample.map(function (g) { return "<tr><td>" + esc(g.Name) + '</td><td class="fm-mono">' + esc(g.KeepCode) + '</td><td class="fm-mono">' + g.MergedCodes.map(esc).join("، ") + "</td></tr>"; }).join("") +
        "</tbody></table></div>" + (r.Groups > r.Sample.length ? '<div style="margin-top:6px;color:#666">يعرض أول ' + r.Sample.length + " من " + r.Groups + "</div>" : "");
      w.setButtons([
        { t: "دمج " + r.Groups + " صنف مكرر", cls: "ok", fn: function (w) {
          w.busy(true); T("جارٍ حفظ نسخة احتياطية ثم الدمج ...", "i");
          call("fm.products.dedupe").then(function (x) {
            w.body.innerHTML = '<div class="fm-note fm-ok">تم الدمج: حُذف <b>' + x.ProductsRemoved + "</b> صنف مكرر — نُقلت <b>" + x.UnitsMoved + "</b> وحدة ودُمجت <b>" + x.UnitsMerged + "</b> وحدة متطابقة.</div>" +
              field("نسخة الأمان", '<input class="fm-in fm-mono" readonly style="flex:1" value="' + esc(x.Backup) + '">') +
              (x.Notes && x.Notes.length ? '<details class="ix-det"><summary>ملاحظات (' + x.Notes.length + ")</summary><ul>" + x.Notes.map(function (n) { return "<li>" + esc(n) + "</li>"; }).join("") + "</ul></details>" : "");
            w.setButtons([{ t: "تم", cls: "ok", fn: function (w) { w.close(); } }]);
            T("تم دمج الأصناف المكررة", "s");
            try { var L = window.__anouerLink; if (L && L.loadProducts) Promise.resolve(L.loadProducts()).catch(function () { }); } catch (e) { }
          }).catch(function (e) { w.busy(false); fail(e); });
        } },
        "|",
        { t: "إغلاق", cls: "no", fn: function (w) { w.close(); } }
      ]);
    }).catch(function (e) { w.close(); fail(e); });
  }

  // ==================================================================== 7) شريط الأخبار
  var NEWS_KEY = "anouer.newsTicker";
  var newsEl = null, newsTimer = null;
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { } }

  function newsMessages(d) {
    var m = [], s = d.summary || {};
    if (d.text) d.text.split(/\r?\n/).forEach(function (t) { if (t.trim()) m.push("<b>" + esc(t.trim()) + "</b>"); });
    m.push("مرحباً بك في <b>" + esc(d.company || "ANOUER") + "</b>");
    if (d.summary) {
      m.push("مبيعات اليوم: <b>" + fmt(s.SalesToday) + "</b> دج (" + (s.SalesCountToday || 0) + " فاتورة)");
      m.push("مشتريات اليوم: <b>" + fmt(s.PurchasesToday) + "</b> دج");
      m.push("رصيد الخزينة: <b>" + fmt(s.TreasuryBalance) + "</b> دج");
      if (s.Receivables) m.push("مستحق على العملاء: <b>" + fmt(s.Receivables) + "</b> دج");
      if (s.LowStockCount) m.push("تنبيه: <b>" + s.LowStockCount + "</b> صنف وصل لحد الطلب" + ((s.LowStock || []).length ? " (" + s.LowStock.slice(0, 3).map(function (p) { return esc(p.Name); }).join("، ") + ")" : ""));
    }
    if (d.counts) m.push("الأصناف: <b>" + (d.counts.products || 0) + "</b> — العملاء: <b>" + (d.counts.customers || 0) + "</b>");
    if (d.autoBackup && d.autoBackup.Enabled) m.push("الحفظ التلقائي مفعّل" + (d.autoBackup.LastRun ? " — آخر نسخة: " + esc(d.autoBackup.LastRun) : ""));
    return m;
  }

  function newsOn() { return window.ANOUER_TICKER ? window.ANOUER_TICKER.on : !!newsEl; }
  function showNews(on) {
    if (window.ANOUER_TICKER) { window.ANOUER_TICKER.show(on); return; }   /* شريط الأخبار 2026 (news-ticker.js) */
    lsSet(NEWS_KEY, on ? "1" : "0");
    clearInterval(newsTimer); newsTimer = null;
    if (!on) { if (newsEl) { newsEl.remove(); newsEl = null; } return; }
    if (!newsEl) {
      newsEl = document.createElement("div");
      newsEl.id = "fmNews";
      newsEl.innerHTML = '<div class="lb">' + IC.news + '<span>الأخبار</span></div><div class="tk"><div></div></div>' +
        '<button type="button" class="bt" data-ed title="تعديل رسالة الشريط">✎</button><button type="button" class="bt" data-x title="إخفاء شريط الأخبار">✕</button>';
      var nav = document.querySelector(".nav");
      if (nav && nav.parentNode) nav.parentNode.insertBefore(newsEl, nav.nextSibling); else document.body.prepend(newsEl);
      newsEl.querySelector("[data-x]").addEventListener("click", function () { showNews(false); });
      newsEl.querySelector("[data-ed]").addEventListener("click", newsTextWin);
    }
    refreshNews();
    newsTimer = setInterval(refreshNews, 60000);
  }
  function setTicker(msgs) {
    if (!newsEl) return;
    var html = msgs.map(function (x) { return "<span>" + x + "</span>"; }).join("◆");
    var tk = newsEl.querySelector(".tk>div");
    tk.innerHTML = html + "◆" + html;
    var len = tk.textContent.length;
    tk.style.setProperty("--dur", Math.max(20, Math.round(len / 6)) + "s");
  }
  function refreshNews() {
    if (window.ANOUER_TICKER) { window.ANOUER_TICKER.refresh(); return; }
    if (!newsEl) return;
    if (!B()) { setTicker(["مرحباً بك في <b>ANOUER</b>", "شريط الأخبار يعرض ملخص المبيعات والتنبيهات داخل البرنامج"]); return; }
    call("fm.news").then(function (d) { setTicker(newsMessages(d)); }).catch(function () { });
  }
  function newsTextWin() {
    if (!needHost()) return;
    call("fm.settings.get", { prefix: "News." }).then(function (s) {
      win({
        title: "رسالة شريط الأخبار", icon: IC.news, width: 520,
        body: '<div style="margin-bottom:6px">رسائل تظهر في بداية شريط الأخبار (سطر لكل رسالة):</div>' +
          '<textarea id="nwT" style="width:100%;height:110px;border:1px solid #b6bcc4;padding:6px;font:inherit;resize:vertical">' + esc(s["News.Text"] || "") + "</textarea>",
        buttons: [
          { t: "حفظ", cls: "ok", fn: function (w) {
            call("fm.settings.set", { values: { "News.Text": w.$("#nwT").value } }).then(function () { T("تم الحفظ", "s"); w.close(); refreshNews(); }).catch(fail);
          } },
          { t: "إلغاء", cls: "no", fn: function (w) { w.close(); } }
        ]
      });
    }).catch(fail);
  }

  // ==================================================================== 8) ربط البرنامج بالموبايل
  /** رمز QR باستخدام مولّد المصفوفة الموجود في الصفحة (qrMatrix). */
  function qrSvgOf(text) {
    if (typeof qrMatrix !== "function") return "";
    var m = qrMatrix(text); if (!m) return "";
    var n = m.length, q = 3, d = "";
    m.forEach(function (row, y) { row.forEach(function (b, x) { if (b) d += "M" + (x + q) + " " + (y + q) + "h1v1h-1z"; }); });
    return '<svg viewBox="0 0 ' + (n + 2 * q) + " " + (n + 2 * q) + '" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
  }
  function mobileWin() {
    if (!needHost()) return;
    var w = win({ title: "ربط البرنامج بالموبايل", icon: IC.mob, width: 640, body: '<div class="fm-empty">جارٍ التحميل ...</div>', buttons: [] });
    function render(st, port) {
      var url = (st.urls || [])[0] || "";
      var qr = "";
      try { if (url) qr = qrSvgOf(url); } catch (e) { }
      w.body.innerHTML = st.running
        ? '<div class="fm-note fm-ok">الربط يعمل. امسح الرمز بكاميرا الموبايل المتصل بنفس شبكة الواي فاي لفتح لوحة المتابعة.</div>' +
          '<div class="fm-qr"><div class="q">' + (qr || '<div class="fm-empty">QR</div>') + "</div><div style=\"flex:1\">" +
          (st.urls || []).map(function (u) { return '<div class="fm-url"><input class="fm-in fm-mono" readonly value="' + esc(u) + '"><button type="button" class="fm-lnk" data-cp="' + esc(u) + '">نسخ</button></div>'; }).join("") +
          '<div class="fm-note" style="font-size:11px">تعرض اللوحة على الموبايل: مبيعات ومشتريات اليوم، رصيد الخزينة، مستحقات العملاء والموردين ونواقص المخزون (قراءة فقط) وتتحدّث كل 30 ثانية. ' +
          "الرابط يحوي رمزاً سرياً يتغيّر عند كل تشغيل، فلا يستطيع أحد الدخول بدونه.</div></div></div>"
        : '<div class="fm-note">يتيح الربط متابعة المبيعات والخزينة من الموبايل عبر شبكة المحل المحلية (Wi-Fi) دون إنترنت.</div>' +
          field("المنفذ (Port)", '<input class="fm-in fm-mono" id="mbPort" type="number" min="1024" max="65535" style="width:100px;text-align:center" value="' + (port || st.port || 8787) + '">') +
          '<div class="fm-note fm-warn" style="font-size:11px">عند أول تشغيل قد يطلب جدار حماية ويندوز السماح لبرنامج ANOUER بالوصول للشبكة — اختر «السماح» للشبكات الخاصة.</div>' +
          (st.error ? '<div class="fm-note fm-danger">' + esc(st.error) + "</div>" : "") +
          (!(st.ips || []).length ? '<div class="fm-note fm-danger">لم يتم العثور على اتصال شبكة محلية على هذا الجهاز.</div>' : "");
      w.setButtons(st.running
        ? [{ t: "إيقاف الربط", cls: "del", fn: function () { call("fm.mobile.stop").then(function (s) { render(s); }).catch(fail); } }, "|", { t: "إغلاق", cls: "no", fn: function (w) { w.close(); } }]
        : [{ t: "تشغيل الربط", cls: "ok", fn: function (w) {
            var p = +w.$("#mbPort").value || 8787; w.busy(true);
            call("fm.mobile.start", { port: p }).then(function (s) { render(s); T("تم تشغيل الربط بالموبايل", "s"); }).catch(function (e) { w.busy(false); fail(e); });
          } }, "|", { t: "إغلاق", cls: "no", fn: function (w) { w.close(); } }]);
    }
    w.body.addEventListener("click", function (e) {
      var cp = e.target.closest("[data-cp]");
      if (cp) { try { navigator.clipboard.writeText(cp.dataset.cp).then(function () { T("تم نسخ الرابط", "s"); }); } catch (x) { } }
    });
    Promise.all([call("fm.mobile.status"), call("fm.settings.get", { prefix: "Mobile." }).catch(function () { return {}; })])
      .then(function (r) { render(r[0], +(r[1] || {})["Mobile.Port"] || 0); }).catch(function (e) { w.close(); fail(e); });
  }

  // ==================================================================== ربط عناصر القائمة
  function find(list, t) { return (list || []).filter(function (x) { return x.t === t; })[0]; }
  function sub(item, t) { return item && find(item.sub, t); }
  function bind(item, fn) { if (item) item.run = fn; }

  var co1 = FILE[0], dbm = FILE[1], co2 = FILE[2], br = find(FILE, "الفروع"), xl = find(FILE, "استيراد من إكسيل");
  /* «الشركات» → شاشات companies.js (تبويبات DEXEF: بيانات المؤسسة / مراجعة الشركات) ، والنوافذ القديمة احتياط */
  var CO = function () { return window.ANOUER_COMPANIES; };
  var addCo = function () { if (CO()) CO().add(); else if (needHost()) companyForm(null); };
  bind(sub(co1, "إضافة شركة"), addCo);
  bind(sub(co1, "مراجعة الشركات"), function () { if (CO()) CO().review(); else companiesWin("review"); });
  bind(sub(dbm, "حفظ نسخة احتياطية"), backup);
  bind(sub(dbm, "استرجاع نسخة احتياطية"), restore);
  bind((dbm && dbm.sub || []).filter(function (x) { return /الحفظ التلقائ/.test(x.t); })[0], autoBackupWin);
  bind(sub(dbm, "محو محتويات البرنامج"), wipeWin);
  /* «الشركات» الثانية (مثل DEXEF): إضافة شركة ← إنشاء ودخول مباشر ، فتح شركة ← شاشة «الشركات الموجودة» بالفروع */
  bind(sub(co2, "إضافة شركة"), function () { if (CO()) CO().add({ enter: true }); else if (needHost()) companyForm(null); });
  bind(sub(co2, "فتح شركة"), function () { if (CO()) CO().open(); else companiesWin("open"); });
  bind(sub(co2, "حذف شركة"), function () { companiesWin("delete"); });
  /* «الفروع» → شاشات branches.js (تبويبات DEXEF: إضافة فرع / مراجعة الفروع) ، والنوافذ القديمة احتياط */
  var BRS = function () { return window.ANOUER_BRANCHES; };
  bind(sub(br, "إضافة فرع"), function () { if (BRS()) BRS().add(); else if (needHost()) branchForm(null); });
  bind(sub(br, "مراجعة الفروع"), function () { if (BRS()) BRS().review(); else branchesWin(); });
  bind(find(FILE, "الخصائص"), propsHub);
  /* أيقونة الترس (شريط العنوان) ← الخصائص (مطابق DEXEF) */
  (function () { var g = document.getElementById("gearBtn"); if (g) { g.addEventListener("click", function (e) { e.stopPropagation(); propsHub(); }); g.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); propsHub(); } }); } })();
  /* «استيراد من إكسيل» → معالج DEXEF بالخطوات (import-wiz.js) ، والنافذة القديمة احتياط */
  var IMW = function (k) { if (window.ANOUER_IMPORT) ANOUER_IMPORT.open(k); else importWin(k); };
  bind(sub(xl, "استيراد الأصناف"), function () { IMW("products"); });
  bind(sub(xl, "استيراد العملاء"), function () { IMW("customers"); });
  bind(sub(xl, "استيراد الموردين"), function () { IMW("suppliers"); });
  window.__FMX = { win: win, IMPORTS: IMPORTS, loadXLSX: loadXLSX, toNum: toNum, cellStr: cellStr, IMX: IMX, norm: norm, call: call, T: T, needHost: needHost, esc: esc, fmt: fmt, size: size, fail: fail, IC: IC, dupesWin: dupesWin, oldWin: importWin };
  bind(find(FILE, "شريط الأخبار"), function () { showNews(!newsOn()); });
  /* «ربط البرنامج بالموبايل» → نافذة mobile-link.js (رمز فوري + الأجهزة المتصلة) ، والنافذة القديمة احتياط */
  bind(find(FILE, "ربط البرنامج بالموبايل"), function () { if (window.ANOUER_MOBILE) ANOUER_MOBILE.open(); else mobileWin(); });

  // Alt+F4 داخل الصفحة = خروج (المضيف يلتقطها عادةً قبل الصفحة)
  document.addEventListener("keydown", function (e) {
    if (e.altKey && e.key === "F4") { var ex = find(FILE, "خروج"); if (ex) { e.preventDefault(); ex.run(); } }
  });

  if (lsGet(NEWS_KEY) === "1") showNews(true);

  window.ANOUER_FILE_MENU = {
    companies: companiesWin, addCompany: companyForm, backup: backup, restore: restore, autoBackup: autoBackupWin,
    wipe: wipeWin, branches: branchesWin, addBranch: branchForm, properties: propertiesWin, importWin: importWin,
    news: showNews, mobile: mobileWin, openCompany: openCompany, propsHub: propsHub,
    deleteCompanies: function () { companiesWin("delete"); }
  };
})();
