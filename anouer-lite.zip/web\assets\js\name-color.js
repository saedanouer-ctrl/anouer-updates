/* ANOUER — «اسم الشركة عادي ، والنوع ملوّن» (2026)
   يكتشف اسم الشركة وحده من كل الأصناف: الكلمات الأولى المشتركة بين عدة أصناف (بنة الزمان · MAXON · MAXON GALETTE …)
   ← الباقي (النوع: بيسطاش ، جوز ، (Framboise) …) يُكتب بلون ثابت لكل نوع وخط عريض ، والوزن/الحجم (5كلغ ، 100gr) في شارة رمادية.
   يُطبَّق في: نافذة «اختيار الأصناف» (item-search.js) ، قائمة الاقتراحات عند الكتابة في الفاتورة (#sugg) ، أسطر الفاتورة (طبقة فوق خانة الاسم).
   API: ANOUER_NC.html(name, q?) → HTML  ·  ANOUER_NC.parts(name) */
(function () {
  "use strict";
  if (window.ANOUER_NC) return;
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const nt = s => String(s || "").toLowerCase().replace(/[أإآٱ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/[ـ]/g, "");
  const PRODS = () => { try { return Array.isArray(products) ? products : []; } catch (e) { return []; } };
  const LEAD = /^[(\[].*[)\]]$/;   /* «(25دينار)» في أول الاسم: يبقى عادياً ولا يدخل في حساب الشركة */
  const SZ = /^(\d+([.,]\d+)?\s*(كلغ|كغ|كيلو|غ|غرام|gr|grs|g|kg|ml|cl|l|لتر|ل|مل|pies|pcs|p|units?|u)|\d+\s*(x|×)\s*\d+\s*(p|pies|g|gr)?|\d+pies\s*x\s*\d+|\d+(x|×)\d+(pies|p)?)$/i;
  const PAL = ["#e11d48", "#ea580c", "#b45309", "#16a34a", "#0d9488", "#0284c7", "#4f46e5", "#9333ea", "#db2777", "#4d7c0f", "#c2410c", "#0e7490"];
  const hash = s => { let h = 7; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); };
  const toks = name => String(name || "").trim().split(/\s+/).filter(Boolean);

  /* عدّاد البادئات: كم صنفاً يبدأ بنفس 1..4 كلمات */
  let CNT = null, SIG = "";
  function counts() {
    const P = PRODS(); let h = P.length; for (let i = 0; i < P.length; i += 37) h = (h * 31 + String(P[i] && P[i].name || "").length) | 0;
    const sig = P.length + ":" + h; if (CNT && sig === SIG) return CNT; SIG = sig; CNT = new Map(); CACHE.clear();
    const seen = new Set();
    P.forEach(p => {
      if (!p || p.active === false) return;
      const t = toks(p.name); let s = 0; while (s < t.length && LEAD.test(t[s])) s++;
      const key = nt(t.join(" ")); if (seen.has(key)) return; seen.add(key);
      let k = ""; for (let j = s; j < Math.min(t.length - 1, s + 4); j++) { k += (k ? " " : "") + nt(t[j]); CNT.set(k, (CNT.get(k) || 0) + 1); }
    });
    return CNT;
  }
  const CACHE = new Map();
  function parts(name) {
    const C = counts(), key = String(name || ""); if (CACHE.has(key)) return CACHE.get(key);
    const t = toks(key); let s = 0; while (s < t.length && LEAD.test(t[s])) s++;
    let k = 0, acc = "";
    for (let j = s; j < Math.min(t.length - 1, s + 4); j++) { acc += (acc ? " " : "") + nt(t[j]); const n = C.get(acc) || 0, need = j === s ? 2 : 3; if (n >= need) k = j - s + 1; else break; }
    let r = null;
    if (k) {
      const co = t.slice(0, s + k), rest = t.slice(s + k), sz = rest.filter(x => SZ.test(x)), vv = rest.filter(x => !SZ.test(x));
      const v = vv.join(" ");
      if (v) r = { co: co.join(" "), v, sz, col: PAL[hash(nt(v.replace(/[()\[\]]/g, "")).replace(/\s+/g, "")) % PAL.length] };
    }
    if (CACHE.size > 4000) CACHE.clear();
    CACHE.set(key, r); return r;
  }
  /* تظليل كلمات البحث داخل جزء من النص */
  function mk(s, q) {
    s = String(s); const ws = String(q || "").trim().split(/\s+/).filter(w => w.length > 0).map(w => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    if (!ws.length) return esc(s);
    try { const re = new RegExp("(" + ws.join("|") + ")", "gi"); return s.split(re).map((x, i) => i % 2 ? "<mark>" + esc(x) + "</mark>" : esc(x)).join(""); } catch (e) { return esc(s); }
  }
  function html(name, q) {
    const r = parts(name); if (!r) return mk(name, q);
    return `<span class="nc-co">${mk(r.co, q)}</span> <span class="nc-v" style="--nc:${r.col}">${mk(r.v, q)}</span>${r.sz.map(x => ` <span class="nc-sz">${mk(x, q)}</span>`).join("")}`;
  }

  const css = document.createElement("style");
  css.textContent = `.nc-v{color:var(--nc);font-weight:800}.nc-co{font-weight:inherit}
.nc-sz{display:inline-block;padding:0 6px;margin:0 2px;border-radius:8px;background:#f1f5f9;border:1px solid #e2e8f0;color:#64748b;font-size:.82em;font-weight:700;line-height:1.5;vertical-align:middle;unicode-bidi:plaintext}
.nc-ov{position:absolute;z-index:2;pointer-events:none;display:flex;align-items:center;justify-content:flex-start;direction:rtl;white-space:pre;overflow:hidden;box-sizing:border-box}
.gr.ncp{position:relative}
#gbody .nm.ncp-h:not(:focus){color:transparent!important}
#gbody .nm:focus~.nc-ov,#gbody .nm.isr-hide~.nc-ov{display:none}
html[data-theme="dark"] .nc-sz,body.dark .nc-sz{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.15);color:#cbd5e1}`;
  (document.head || document.documentElement).appendChild(css);

  /* ---------- أسطر الفاتورة: طبقة ملوّنة فوق خانة الاسم (تختفي عند الكتابة) ---------- */
  let T = 0;
  const later = () => { if (T) return; T = requestAnimationFrame(() => { T = 0; paintRows(); }); };
  function paintRows() {
    const gb = document.getElementById("gbody"); if (!gb) return;
    gb.querySelectorAll(".gr").forEach(g => {
      const nm = g.querySelector("input.nm"); let ov = g.querySelector(":scope > .nc-ov");
      const val = nm ? nm.value : "", r = nm && nm.classList.contains("has") && val ? parts(val) : null;
      if (!r) { if (ov) ov.remove(); if (nm) nm.classList.remove("ncp-h"); return; }
      const cs = getComputedStyle(nm), gr = g.getBoundingClientRect(), nr = nm.getBoundingClientRect();
      if (!nr.width) return;
      if (!nm.classList.contains("ncp-h") || !nm.dataset.ncc) nm.dataset.ncc = nm.classList.contains("ncp-h") ? getComputedStyle(g).color : cs.color;   /* لون النص الأصلي قبل إخفائه */
      if (!ov) { ov = document.createElement("div"); ov.className = "nc-ov"; g.appendChild(ov); g.classList.add("ncp"); }
      ov.style.cssText = `left:${nr.left - gr.left}px;top:${nr.top - gr.top}px;width:${nr.width}px;height:${nr.height}px;font-size:${cs.fontSize};font-weight:${cs.fontWeight};font-family:${cs.fontFamily};color:${nm.dataset.ncc};padding:0 ${cs.paddingRight} 0 ${cs.paddingLeft};letter-spacing:${cs.letterSpacing}`;
      if (ov.dataset.v !== val) { ov.dataset.v = val; ov.innerHTML = "<span>" + html(val) + "</span>"; }
      nm.classList.add("ncp-h");
    });
  }
  document.addEventListener("input", e => { const nm = e.target; if (nm && nm.matches && nm.matches("#gbody input.nm")) { nm.classList.remove("ncp-h"); const ov = nm.parentElement && nm.parentElement.querySelector(":scope > .nc-ov"); if (ov) ov.remove(); } }, true);
  document.addEventListener("focusout", e => { if (e.target && e.target.matches && e.target.matches("#gbody input.nm")) setTimeout(later, 260); }, true);

  /* ---------- قائمة الاقتراحات في الفاتورة (#sugg) ---------- */
  function paintSugg(s) {
    let q = ""; try { q = (window.sTarget && sTarget.value) || ""; } catch (e) { }
    if (!q) { const a = document.activeElement; if (a && a.matches && a.matches("#gbody input.nm")) q = a.value; }
    const P = PRODS();
    [...s.children].forEach(d => {
      if (d.dataset.nc) return; const sp = d.querySelector(":scope > span"); if (!sp) return;
      const id = d.dataset.id, p = id != null ? P.find(x => String(x.id) === String(id)) : null, nm = p ? p.name : sp.textContent;
      if (sp.textContent.trim() !== String(nm).trim()) return;   /* اسم مختصر (الأذواق…) ← يبقى كما هو */
      d.dataset.nc = "1"; if (parts(nm)) sp.innerHTML = html(nm, q);
    });
  }
  function boot() {
    const gb = document.getElementById("gbody");
    if (gb && !gb.__nc) { gb.__nc = 1; new MutationObserver(later).observe(gb, { childList: true, subtree: true }); try { new ResizeObserver(later).observe(gb); } catch (e) { } later(); }
    const s = document.getElementById("sugg");
    if (s && !s.__nc) { s.__nc = 1; new MutationObserver(() => paintSugg(s)).observe(s, { childList: true }); }
    if (!gb || !s) setTimeout(boot, 800);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
  window.addEventListener("resize", later);

  window.ANOUER_NC = { html, parts, paintRows, reset() { CNT = null; CACHE.clear(); } };
})();
