/* ANOUER — «الأقساط» (الإضافات ← 3-الخدمات) — 2026
   حسب وصف DEXEF: «بيع الشىء بثمن مؤجل يدفع على أقساط معلومة فى أوقات محددة، أكثر من ثمن الحال»
   ─ عقد التقسيط يُجدوِل ديناً على العميل (باقي فاتورة آجلة أو دينه الحالي) على أقساط بتواريخ محددة.
   ─ «الزيادة» (أكثر من ثمن الحال) تُرحَّل قيداً محاسبياً على شجرة الحسابات: مدين العميل / دائن حساب إيراد من «4 الإيرادات».
   ─ التحصيل = «إيصال استلام نقدية» حقيقي (الخزينة ← العميل ← تسوية الفاتورة) يظهر في مراجعة الاستلام وكشف العميل.
   ─ توزيع المدفوع على الأقساط بالأقدم فالأقدم (FIFO) ← يدعم الدفع الجزئي والمسبق والسداد الكامل.
   ─ مطابقة تلقائية: لو حُذف إيصال من شاشة الاستلام يرجع القسط «غير مدفوع» وحده.
   التخزين: العقود في فهرس القاعدة (النوع inst) · نظم التقسيط والإعدادات في الخصائص (inst.cfg). */
(function () {
  "use strict";
  if (window.ANOUER_INST) return;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const r2 = n => Math.round((+n || 0) * 100) / 100;
  const N = n => r2(n).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const num = v => { const x = parseFloat(String(v == null ? "" : v).replace(/,/g, "")); return isFinite(x) ? x : 0; };
  const T = (m, k) => { try { toast(m, k || "i"); } catch (e) { console.log(m); } };
  const snd = k => { try { if (window.ANOUER_SOUND) ANOUER_SOUND(k); } catch (e) { } };
  const PR = () => window.ANOUER_PROPS, A = () => window.__AC, FH = () => window.__FH;
  const HOST = () => !!(window.Anouer && Anouer.available);
  const p2 = n => String(n).padStart(2, "0");
  const ymd = d => d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate());
  const today = () => ymd(new Date());
  const D0 = s => new Date(String(s).slice(0, 10) + "T12:00:00");
  const addDays = (s, n) => { const d = D0(s); d.setDate(d.getDate() + n); return ymd(d); };
  const addMonths = (s, n) => { const d = D0(s), day = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + n); const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); d.setDate(Math.min(day, last)); return ymd(d); };
  const diff = (a, b) => Math.round((D0(b) - D0(a)) / 864e5);   /* b − a بالأيام */
  const dmy = s => { const p = String(s || "").slice(0, 10).split("-"); return p.length === 3 ? p[2] + "/" + p[1] + "/" + p[0] : String(s || ""); };
  const MON = ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
  const nice = s => { const d = D0(s); return d.getDate() + " " + MON[d.getMonth()] + (d.getFullYear() !== new Date().getFullYear() ? " " + d.getFullYear() : ""); };
  const rel = s => { const n = diff(today(), s); return n === 0 ? "اليوم" : n === 1 ? "غداً" : n === -1 ? "أمس" : n > 1 ? "بعد " + n + " يوم" : "متأخر " + (-n) + " يوم"; };
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const USER = () => window.__USER_NAME || "ANOUER";
  const BR = () => ((window.__RV && __RV.BR) || ["الفرع الرئيسي"])[0];
  const EVERY = { m: ["شهري", "شهر"], "2w": ["كل أسبوعين", "أسبوعين"], w: ["أسبوعي", "أسبوع"] };
  const KIND = "inst", VIEW = "inst_hub", TITLE = "الأقساط";

  /* ---------------- أيقونات ---------------- */
  const sv = (p, w) => `<svg viewBox="0 0 24 24" width="${w || 18}" height="${w || 18}" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
  const IC = {
    logo: sv('<rect x="3" y="5" width="18" height="15" rx="3.5"/><path d="M3 10h18M8 3v4M16 3v4"/><path d="M8 14.5h2.5M13.5 14.5H16M8 17h2.5" stroke-width="2.2"/>', 22),
    plus: sv('<path d="M12 5v14M5 12h14"/>'), gear: sv('<circle cx="12" cy="12" r="3.2"/><path d="M19 12a7 7 0 0 0-.1-1.3l2-1.5-2-3.4-2.3 1a7 7 0 0 0-2.2-1.300L14 3h-4l-.4 2.500a7 7 0 0 0-2.200 1.300l-2.300-1-2 3.400 2 1.500A7 7 0 0 0 5 12c0 .400 0 .900.100 1.300l-2 1.500 2 3.400 2.300-1a7 7 0 0 0 2.200 1.300L10 21h4l.400-2.500a7 7 0 0 0 2.200-1.300l2.300 1 2-3.400-2-1.500c.100-.400.100-.900.100-1.300z"/>'),
    x: sv('<path d="M6 6l12 12M18 6L6 18"/>'), cash: sv('<rect x="2.500" y="6" width="19" height="12" rx="2.500"/><circle cx="12" cy="12" r="2.600"/><path d="M6 9.500v5M18 9.500v5"/>'),
    ok: sv('<path d="M5 12.500l4.500 4.500L19 7.500"/>'), clock: sv('<circle cx="12" cy="12" r="8.500"/><path d="M12 7.500V12l3 2"/>'), fire: sv('<path d="M12 3c1 3.500 5 5 5 9.500A5 5 0 0 1 7 12.500c0-1.500.700-2.700 1.500-3.500.300 1.500 1 2.200 2 2.500C10 8.500 10.500 5.500 12 3z"/>'),
    cal: sv('<rect x="3.500" y="5" width="17" height="15" rx="3"/><path d="M3.500 10h17M8 3v4M16 3v4"/>'), wa: sv('<path d="M4 20l1.300-4.200A8 8 0 1 1 8.300 19z"/><path d="M9 9.500c.500 2.500 2.500 4.500 5 5l1.200-1.300 2 .900c-.300 1.500-1.700 2.200-3 2-3.500-.600-6.500-3.600-7-7-.200-1.300.500-2.700 2-3l.900 2z" stroke-width="1.300"/>'),
    print: sv('<path d="M7 8V4h10v4M7 17H5a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"/><rect x="7" y="14" width="10" height="6" rx="1"/>'),
    user: sv('<circle cx="12" cy="8" r="4"/><path d="M4 20c1-4 4-6 8-6s7 2 8 6"/>'), doc: sv('<path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4M10 12h5M10 16h5"/>'),
    search: sv('<circle cx="11" cy="11" r="6.500"/><path d="M16 16l4.500 4.500"/>'), spark: sv('<path d="M12 3l1.800 5.200L19 10l-5.200 1.800L12 17l-1.800-5.200L5 10l5.200-1.800z"/><path d="M19 16l.700 2 2 .700-2 .700-.700 2-.700-2-2-.700 2-.700z" stroke-width="1.300"/>'),
    trash: sv('<path d="M5 7h14M10 7V4.500h4V7M7 7l1 13h8l1-13"/>'), chart: sv('<path d="M4 20V10M10 20V4M16 20v-8M21 20H3"/>'), back: sv('<path d="M9 6l6 6-6 6"/>'),
    lock: sv('<rect x="5" y="10.500" width="14" height="9.500" rx="2.500"/><path d="M8 10.500V8a4 4 0 0 1 8 0v2.500"/>'), bolt: sv('<path d="M13 3L5 13.500h6L10 21l8-10.500h-6z"/>')
  };

  /* ---------------- الإعدادات (الخصائص) ---------------- */
  const ADD_DEF = ["disc", "qdisc", "bonus", "extra"];
  const DEF = {
    plans: [{ id: "p3", name: "3 أشهر", n: 3, every: "m", pct: 0, down: 0 }, { id: "p6", name: "6 أشهر", n: 6, every: "m", pct: 5, down: 20 },
      { id: "p10", name: "10 أشهر", n: 10, every: "m", pct: 8, down: 20 }, { id: "p12", name: "سنة كاملة", n: 12, every: "m", pct: 10, down: 25 }],
    round: 10, acc: null, tr: 0, remind: 3
  };
  const cfg = () => { const c = Object.assign({}, DEF, (PR() && PR().get("inst.cfg", {})) || {}); if (!Array.isArray(c.plans) || !c.plans.length) c.plans = DEF.plans.map(p => Object.assign({}, p)); return c; };
  const saveCfg = c => PR() ? Promise.resolve(PR().put("inst.cfg", c)) : Promise.resolve();
  const enList = () => { try { return (PR() && PR().get("add.enabled", ADD_DEF)) || ADD_DEF; } catch (e) { return ADD_DEF; } };
  const liteLock = () => { try { return !!(window.ANOUER_LITE && ANOUER_LITE.on && ANOUER_LITE.pro && !ANOUER_LITE.pro()); } catch (e) { return false; } };
  const licOk = () => !liteLock() && (!(window.ANOUER_EDITION || {}).dist || !window.ANOUER_LIC || ANOUER_LIC.ok("inst"));   /* نسخة العملاء: تجربة شهر أو كود تفعيل · LITE: يحتاج PRO */
  const on = () => enList().indexOf("inst") >= 0 && licOk();
  function setOn(v) { const l = enList().slice(), i = l.indexOf("inst"); if (v && i < 0) l.push("inst"); if (!v && i >= 0) l.splice(i, 1); return PR() ? Promise.resolve(PR().put("add.enabled", l)) : Promise.resolve(); }

  /* ---------------- العقود (فهرس القاعدة — النوع inst) ---------------- */
  let LIST = [], LOADED = false;
  const toC = r => Object.assign({ sched: [], pays: [] }, r.data || {}, { id: r.id, no: String(r.no || "") });
  function load(force) {
    if (!FH() || !FH().DB) return Promise.resolve(LIST);
    return FH().DB.list(KIND, force).then(l => { LIST = (l || []).map(toC); LOADED = true; return LIST; }).catch(e => { console.warn("inst load", e); return LIST; });
  }
  function saveC(c) {
    const data = Object.assign({}, c); delete data.id; delete data.no;
    return FH().DB.save(KIND, { id: c.id || 0, no: c.no || "", name: "عقد " + c.no + " - " + c.cname, active: c.status !== "cancel", data })
      .then(r => { c.id = (r && r.id) || c.id; if (r && r.no) c.no = String(r.no); return load(true); }).then(() => LIST.find(x => x.id === c.id) || c);
  }

  /* الحالة المحسوبة: المدفوع يوزَّع على الأقساط بالأقدم فالأقدم */
  function calc(c, at) {
    at = at || today();
    const total = r2(c.sched.reduce((s, x) => s + (+x.amt || 0), 0));
    let pool = r2((c.pays || []).filter(p => !p.lost).reduce((s, p) => s + (+p.amt || 0) + (+p.disc || 0), 0));
    const paid = Math.min(pool, total);
    let late = 0, lateN = 0, next = null, firstLate = "", dueToday = 0;
    const rows = c.sched.map(x => {
      const amt = +x.amt || 0, pd = Math.min(amt, Math.max(0, pool)); pool = r2(pool - pd);
      const rem = r2(amt - pd), open = rem > 0.005;
      const st = !open ? "paid" : x.due < at ? "late" : x.due === at ? "today" : pd > 0 ? "part" : "wait";
      const row = { n: x.n, due: x.due, amt, paid: r2(pd), rem: open ? rem : 0, st };
      if (open) { if (!next) next = row; if (x.due < at) { late += rem; lateN++; firstLate = firstLate || x.due; } if (x.due === at) dueToday += rem; }
      return row;
    });
    const rem = r2(total - paid);
    const status = c.status === "cancel" ? "cancel" : c.status === "closed" ? "closed" : rem <= 0.005 ? "done" : late > 0 ? "late" : "on";
    return { rows, total, paid: r2(paid), rem, late: r2(late), lateN, lateDays: firstLate ? diff(firstLate, at) : 0, next, dueToday: r2(dueToday), status, pct: total ? Math.min(100, Math.round(paid / total * 100)) : 0 };
  }
  const live = c => c.status !== "cancel" && c.status !== "closed";
  const ST = { on: ["منتظم", "on"], late: ["متأخر", "late"], done: ["مكتمل ✓", "done"], closed: ["مغلق", "off"], cancel: ["ملغى", "off"] };

  /* جدول الأقساط: القسط = الإجمالي ÷ العدد مقرَّباً لأسفل للخطوة ، والباقي في آخر قسط */
  function build(o) {
    const n = Math.max(1, Math.min(120, o.n | 0)), step = +o.round || 1, fin = r2(o.fin);
    let each = step > 1 ? Math.floor(fin / n / step) * step : r2(Math.floor(fin / n * 100) / 100);
    if (!(each > 0)) each = r2(fin / n);
    const rows = [];
    for (let i = 0; i < n; i++) {
      const due = o.every === "m" ? addMonths(o.first, i) : addDays(o.first, (o.every === "w" ? 7 : 14) * i);
      rows.push({ n: i + 1, due, amt: i < n - 1 ? each : r2(fin - each * (n - 1)) });
    }
    return rows;
  }

  /* ---------------- المحاسبة (شجرة الحسابات) ---------------- */
  /* حسابات الإيراد الفرعية تحت «4 الإيرادات» */
  function revAccounts() {
    return A().coaTree().then(t => {
      const out = [], root = t.byNo["4"]; const walk = n => { if (!n.kids.length) out.push({ id: n.id, no: n.no, name: n.name }); else n.kids.forEach(walk); };
      (root ? root.kids : t.roots.filter(r => String(r.no)[0] === "4")).forEach(walk);
      return out;
    }).catch(() => []);
  }
  function revAcc() {
    const c = cfg(); if (c.acc && c.acc.id) return Promise.resolve(c.acc);
    return revAccounts().then(l => l.find(a => a.no === "4133") || l.find(a => /تشغيلية أخرى|أخرى|متنوعة/.test(a.name)) || l[0] || null);
  }
  const treasuries = () => A().accounts("tr", true).then(l => (l || []).filter(t => t.active !== false));
  /* قيد الزيادة: مدين العميل / دائن حساب الإيراد */
  function postMarkup(c) {
    const m = r2(c.markup); if (!(m > 0)) return Promise.resolve(null);
    return revAcc().then(acc => {
      if (!acc) throw new Error("اختر حساب إيراد الزيادة من إعدادات الأقساط (شجرة الحسابات)");
      const AC = A(), date = c.date || today(), stmt = "زيادة تقسيط — عقد رقم " + c.no + " — " + c.cname;
      const rows = [{ t: "cu", no: c.cno || "", name: c.cname, aid: c.cid, dr: m, cr: 0, note: "عقد تقسيط " + c.no }, { t: "gl", no: acc.no, name: acc.name, aid: acc.id, dr: 0, cr: m, note: "زيادة البيع بالتقسيط" }];
      const fx = [{ t: "cu", id: c.cid, d: -m }], lg = [{ t: "gl", id: acc.id, d: -m, name: acc.name, what: "قيد" }];
      return AC.nextNo("je").then(no => {
        const notes = "قيد رقم " + no + " - " + stmt;
        const data = { date, time: AC.nowT(), br: BR(), stmt, cc: "", notes: "آلي — موديول الأقساط", rows, dr: m, cr: m, total: m, fx, lg, user: USER(), inst: c.id };
        return AC.post(fx, [], { date, no: String(no), notes }).then(() => AC.saveDoc("je", { id: 0, no, data }).catch(e => AC.post([], fx, { date, no: String(no), notes: "عكس " + notes }).then(() => { throw e; })))
          .then(r => { dirty("je"); return { id: r.id, no: String(r.no || no), fx, acc: { no: acc.no, name: acc.name } }; });
      });
    });
  }
  function unpostMarkup(c) {
    if (!c.je || !c.je.id) return Promise.resolve();
    const AC = A();
    return AC.post([], c.je.fx || [], { date: today(), no: String(c.je.no || ""), notes: "إلغاء عقد تقسيط " + c.no }).then(() => AC.delDoc("je", c.je.id)).then(() => dirty("je"));
  }
  function dirty(kind) {
    const AC = A(); try { AC.invalidate(); delete AC.PC.cu; delete AC.AC.tr; } catch (e) { }
    try { if (window.__AC_REFRESH) __AC_REFRESH(kind); } catch (e) { }
  }
  /* إيصال استلام نقدية (الخزينة ← العميل ← تسوية الفاتورة إن وُجدت) */
  function receive(c, o) {
    const AC = A(), amt = r2(o.amt), disc = r2(o.disc || 0), date = o.date || today();
    const acc = { type: "tr", id: o.tr.id, name: o.tr.name };
    const getDue = c.inv && c.inv.id ? AC.dues("cu", { id: c.cid, name: c.cname }).then(l => (l || []).find(d => String(d.id) === String(c.inv.id)) || null).catch(() => null) : Promise.resolve(null);
    return Promise.all([AC.nextNo("recv"), getDue]).then(([no, due]) => {
      const note = o.note || ("قسط — عقد تقسيط رقم " + c.no);
      const meta = { party: c.cname, notes: "استلام نقدية رقم " + no + " - " + note, what: AC.TITLE.recv };
      const af = AC.accFx(acc, amt, meta);
      const fx = af.fx.concat([{ t: "cu", id: c.cid, d: r2(amt + disc) }]), alloc = [];
      if (due && +due.rem > 0.005) { const a = r2(Math.min(amt + disc, +due.rem)); alloc.push({ id: due.id, no: due.no, date: due.date, type: due.type, total: due.total, amt: a }); fx.push({ t: "inv", id: due.id, d: a }); }
      const data = { date, time: AC.nowT(), br: BR(), side: "cu", pid: c.cid, pno: c.cno || "", pname: c.cname, amt, disc, cur: "DZD", rate: 1, acc, notes: note, ref: "عقد تقسيط " + c.no, st: "", cc: "", dacc: "خصم مسموح به ( مدين )",
        alloc, fx, lg: af.lg, user: USER(), mod: new Date().toLocaleString("sv-SE").slice(0, 16), modBy: "", inst: c.id };
      return AC.post(fx, [], { date, no: String(no), notes: meta.notes }).then(() => AC.saveDoc("recv", { id: 0, no, data }).catch(e => AC.post([], fx, { date, no: String(no), notes: "عكس " + meta.notes }).then(() => { throw e; })))
        .then(r => { dirty("recv"); try { window.dispatchEvent(new CustomEvent("anouer:cash-saved", { detail: { kind: "recv", side: "cu", pid: c.cid } })); } catch (e) { }
          return { id: r.id, no: String(r.no || no), data }; });
    });
  }
  /* مطابقة مع إيصالات الاستلام: إيصال محذوف ← الدفعة تُعلَّم «محذوفة» (لا تُحسب) ، مبلغ معدَّل ← يُحدَّث */
  function reconcile() {
    if (!A() || !LIST.some(c => (c.pays || []).some(p => p.vid))) return Promise.resolve(0);
    return A().docs("recv", true).then(docs => {
      if (!Array.isArray(docs)) return 0;
      const by = {}; docs.forEach(d => by[d.id] = d);
      const jobs = []; let n = 0;
      LIST.forEach(c => { let ch = false;
        (c.pays || []).forEach(p => { if (!p.vid) return; const d = by[p.vid];
          if (!d) { if (!p.lost && docs.length) { p.lost = true; ch = true; n++; } return; }
          if (p.lost) { p.lost = false; ch = true; }
          const a = +d.data.amt || 0, ds = +d.data.disc || 0; if (Math.abs(a - p.amt) > 0.005 || Math.abs(ds - (+p.disc || 0)) > 0.005) { p.amt = a; p.disc = ds; ch = true; } });
        if (ch) jobs.push(saveC(c)); });
      return Promise.all(jobs).then(() => n);
    }).catch(() => 0);
  }

  /* ---------------- نافذة عامة ---------------- */
  const STACK = [];
  function modal(o) {
    const ov = document.createElement("div"); ov.className = "qst-ov" + (o.side ? " side" : "");
    ov.innerHTML = `<div class="qst-m ${o.cls || ""}" role="dialog" aria-modal="true" aria-label="${esc(o.title)}" style="${o.w ? "width:" + o.w + "px" : ""}">
      <div class="qst-mh"><span class="ic">${o.icon || IC.logo}</span><div class="t"><b>${esc(o.title)}</b>${o.sub ? `<small>${o.sub}</small>` : ""}</div><span class="sp"></span>${o.head || ""}<button type="button" class="qst-x" data-x title="إغلاق (Esc)">${IC.x}</button></div>
      <div class="qst-mb">${o.body || ""}</div>${o.foot ? `<div class="qst-mf">${o.foot}</div>` : ""}</div>`;
    document.body.appendChild(ov); (void ov.offsetWidth, ov.classList.add("in"));
    const M = { el: ov, w: ov.querySelector(".qst-m"), body: ov.querySelector(".qst-mb"), q: s => ov.querySelector(s), qa: s => [...ov.querySelectorAll(s)] };
    M.close = () => { const i = STACK.indexOf(M); if (i >= 0) STACK.splice(i, 1); ov.classList.remove("in"); document.removeEventListener("keydown", key, true); setTimeout(() => ov.remove(), 200); if (o.onClose) o.onClose(); };
    const key = e => {
      if (STACK[STACK.length - 1] !== M) return;
      if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); M.close(); return; }
      if (o.onKey && o.onKey(e) === true) { e.preventDefault(); e.stopImmediatePropagation(); return; }
      if (e.key === "Enter" && o.onEnter && e.target.tagName !== "TEXTAREA" && e.target.tagName !== "BUTTON") { e.preventDefault(); e.stopImmediatePropagation(); o.onEnter(); return; }
      if (/^F\d+$/.test(e.key)) { e.preventDefault(); e.stopImmediatePropagation(); return; }
      e.stopPropagation();
    };
    document.addEventListener("keydown", key, true); STACK.push(M);
    ov.addEventListener("mousedown", e => { if (e.target === ov) { if (o.side) M.close(); else { M.w.classList.remove("shk"); void M.w.offsetWidth; M.w.classList.add("shk"); } } });
    ov.querySelector("[data-x]").onclick = M.close;
    return M;
  }
  const ask = (m, y) => { try { askConfirm(m, y); } catch (e) { if (confirm(m)) y(); } };
  const hue = s => { let h = 0; for (const ch of String(s || "")) h = (h * 31 + ch.charCodeAt(0)) % 360; return h; };
  const avatar = name => `<span class="qst-av" style="--h:${hue(name)}">${esc(String(name || "؟").trim().slice(0, 1))}</span>`;
  const ring = (pct, cls) => `<span class="qst-ring ${cls || ""}" style="--p:${pct}"><b>${pct}<small>%</small></b></span>`;
  const chip = (t, k) => `<i class="qst-chip ${k || ""}">${t}</i>`;
  const busyBtn = (b, v) => { if (!b) return; b.disabled = !!v; b.classList.toggle("busy", !!v); };

  /* ================= المركز ================= */
  const S = { tab: "due", q: "", f: "all", per: "m" };
  let ROOT = null;
  function center(go) {
    const H = FH(); if (!H) { T("شاشة الأقساط غير متاحة", "w"); return; }
    const el = H.mkView(VIEW, TITLE);
    if (!el.dataset.b) {
      el.dataset.b = "1"; el.classList.add("qst-vw"); ROOT = el;
      el.innerHTML = `<div class="qst-root"><div class="qst-hero"><i class="bl a"></i><i class="bl b"></i>
          <div class="qst-top"><span class="qst-logo">${IC.logo}</span><div class="qst-tt"><h2>الأقساط</h2><p>بيع مريح للزبون · تحصيل منظّم لك</p></div><span class="sp"></span>
            <button type="button" class="qst-btn glass" data-a="set" title="نظم التقسيط والإعدادات">${IC.gear}<span>الإعدادات</span></button>
            <button type="button" class="qst-btn pri" data-a="new">${IC.plus}<span>عقد تقسيط جديد</span></button></div>
          <div class="qst-kpis" data-kpi></div></div>
        <div class="qst-bar"><div class="qst-seg" data-seg>${[["due", "المستحقة", IC.clock], ["all", "العقود", IC.doc], ["pay", "التحصيلات", IC.cash], ["rep", "التقارير", IC.chart]].map(t => `<button type="button" data-t="${t[0]}">${t[2]}<span>${t[1]}</span><em></em></button>`).join("")}</div>
          <span class="sp"></span><label class="qst-srch">${IC.search}<input data-q placeholder="ابحث بالعميل أو رقم العقد…" autocomplete="off" spellcheck="false"></label></div>
        <div class="qst-body" data-body></div></div>`;
      el.addEventListener("click", onClick);
      const q = el.querySelector("[data-q]"); q.addEventListener("input", () => { S.q = q.value.trim(); drawBody(); }); q.addEventListener("keydown", e => e.stopPropagation());
      try { window.__RV.VIEW_SHOW[VIEW] = () => refresh(); } catch (e) { }
    }
    H.tabOpen(VIEW, TITLE, VIEW);
    if (go) S.tab = go;
    refresh(true);
  }
  function refresh(first) {
    if (!ROOT) return;
    if (!on()) { drawOff(); return; }
    if (first && !LOADED) ROOT.querySelector("[data-body]").innerHTML = `<div class="qst-load"><i></i><i></i><i></i></div>`;
    load(true).then(() => reconcile()).then(n => { if (n) T("مطابقة الأقساط: " + n + " إيصال استلام محذوف — رجع قسطه غير مدفوع", "w"); draw(); });
  }
  function drawOff() {
    ROOT.classList.add("qst-isoff"); ROOT.querySelector("[data-kpi]").innerHTML = "";
    ROOT.querySelector("[data-body]").innerHTML = `<div class="qst-off"><span class="big">${IC.logo}</span><h3>فعّل البيع بالتقسيط</h3>
      <p>قسّط دين العميل على دفعات بتواريخ محددة، وحصّل كل قسط بإيصال استلام حقيقي يدخل الخزينة وكشف العميل. الزيادة على ثمن الحال تُرحَّل قيداً على شجرة الحسابات.</p>
      <div class="pts"><span>${IC.cal} جدول أقساط تلقائي</span><span>${IC.cash} تحصيل بضغطة</span><span>${IC.fire} متابعة المتأخرين</span><span>${IC.chart} تقارير A4</span></div>
      <button type="button" class="qst-btn pri xl" data-a="enable">${IC.bolt}<span>تفعيل الأقساط</span></button></div>`;
  }
  /* ملخص كل العقود الحيّة */
  function summary() {
    const t = today(), w = addDays(t, 7), m0 = t.slice(0, 8) + "01";
    const s = { act: 0, late: 0, lateN: 0, lateC: 0, today: 0, todayN: 0, week: 0, rem: 0, month: 0, monthN: 0, due: [] };
    LIST.forEach(c => {
      (c.pays || []).forEach(p => { if (!p.lost && String(p.date) >= m0) { s.month += (+p.amt || 0); s.monthN++; } });
      if (!live(c)) return; const k = calc(c, t); if (k.status === "done") return;
      s.act++; s.rem += k.rem; if (k.late > 0) { s.late += k.late; s.lateC++; }
      k.rows.forEach(r => { if (!r.rem) return; if (r.st === "late") s.lateN++; if (r.st === "today") { s.today += r.rem; s.todayN++; } if (r.due > t && r.due <= w) s.week += r.rem; s.due.push({ c, k, r }); });
    });
    s.due.sort((a, b) => a.r.due.localeCompare(b.r.due) || String(a.c.cname).localeCompare(String(b.c.cname), "ar"));
    return s;
  }
  function draw() {
    if (!ROOT) return; if (!on()) return drawOff();
    ROOT.classList.remove("qst-isoff");
    const s = summary();
    const K = (cls, ic, v, l, sub, go) => `<button type="button" class="qst-k ${cls}" data-go="${go}"><span class="i">${ic}</span><b>${v}</b><span class="l">${l}</span>${sub ? `<small>${sub}</small>` : ""}</button>`;
    ROOT.querySelector("[data-kpi]").innerHTML =
      K("a", IC.doc, s.act, "عقد نشط", "المتبقي " + N(s.rem) + " DZD", "all") +
      K("b", IC.clock, N(s.today), "مستحق اليوم", s.todayN ? s.todayN + " قسط" : "لا شيء اليوم", "due") +
      K("c", IC.fire, N(s.late), "متأخر", s.lateC ? s.lateC + " عميل · " + s.lateN + " قسط" : "كل شيء في وقته 👌", "due") +
      K("d", IC.cal, N(s.week), "خلال 7 أيام", "قادمة", "due") +
      K("e", IC.cash, N(s.month), "محصّل هذا الشهر", s.monthN ? s.monthN + " إيصال" : "", "pay");
    const em = { due: s.todayN + s.lateN, all: s.act };
    ROOT.querySelectorAll("[data-seg] button").forEach(b => { b.classList.toggle("on", b.dataset.t === S.tab); const e = b.querySelector("em"), v = em[b.dataset.t]; e.textContent = v || ""; e.hidden = !v; });
    drawBody(s);
  }
  const match = c => { const q = S.q; if (!q) return true; const H = FH(), n = H && H.norm ? H.norm : x => String(x).toLowerCase(); return n(c.cname + " " + c.no + " " + (c.inv ? c.inv.no : "")).includes(n(q)); };
  function drawBody(s) {
    const body = ROOT.querySelector("[data-body]"); s = s || summary();
    if (S.tab === "due") {
      const t = today(), w = addDays(t, 7), L = s.due.filter(x => match(x.c));
      const G = [["late", "متأخرة", IC.fire, L.filter(x => x.r.st === "late")], ["today", "اليوم", IC.clock, L.filter(x => x.r.st === "today")], ["week", "خلال 7 أيام", IC.cal, L.filter(x => x.r.due > t && x.r.due <= w)], ["later", "لاحقاً", IC.cal, L.filter(x => x.r.due > w).slice(0, 60)]];
      const row = x => `<div class="qst-row ${x.r.st}" data-open="${x.c.id}">${avatar(x.c.cname)}<div class="who"><b>${esc(x.c.cname)}</b><small>عقد ${esc(x.c.no)} · القسط ${x.r.n} من ${x.c.sched.length}${x.r.paid ? " · مدفوع منه " + N(x.r.paid) : ""}</small></div>
        <div class="when"><b>${esc(nice(x.r.due))}</b><small>${esc(rel(x.r.due))}</small></div><div class="amt"><b>${N(x.r.rem)}</b><small>DZD</small></div>
        <span class="acts"><button type="button" class="qst-ib" data-wa="${x.c.id}:${x.r.n}" title="تذكير واتساب">${IC.wa}</button><button type="button" class="qst-btn sm pri" data-pay="${x.c.id}">${IC.cash}<span>تحصيل</span></button></span></div>`;
      body.innerHTML = L.length ? `<div class="qst-agenda">${G.filter(g => g[3].length).map(g => `<section class="qst-g ${g[0]}"><h4>${g[2]}<span>${g[1]}</span><em>${g[3].length}</em><i></i><b>${N(g[3].reduce((a, x) => a + x.r.rem, 0))} <small>DZD</small></b></h4>${g[3].map(row).join("")}</section>`).join("")}</div>`
        : empty(S.q ? "لا توجد نتائج" : LIST.length ? "لا توجد أقساط مستحقة 🎉" : "ابدأ بأول عقد تقسيط", S.q ? "" : LIST.length ? "كل الأقساط مدفوعة" : "اختر العميل، المبلغ ونظام التقسيط — والباقي علينا", !S.q && !LIST.length);
    } else if (S.tab === "all") {
      const F = [["all", "الكل"], ["on", "منتظم"], ["late", "متأخر"], ["done", "مكتمل"], ["off", "مغلق / ملغى"]];
      const L = LIST.map(c => ({ c, k: calc(c) })).filter(x => match(x.c) && (S.f === "all" || (S.f === "off" ? (x.k.status === "closed" || x.k.status === "cancel") : x.k.status === S.f)))
        .sort((a, b) => (b.k.late > 0) - (a.k.late > 0) || (a.k.status === "done") - (b.k.status === "done") || String(b.c.date).localeCompare(String(a.c.date)) || (+b.c.no || 0) - (+a.c.no || 0));
      const card = x => { const c = x.c, k = x.k, st = ST[k.status];
        return `<article class="qst-card ${st[1]}" data-open="${c.id}"><header>${avatar(c.cname)}<div><b>${esc(c.cname)}</b><small>عقد ${esc(c.no)} · ${esc(dmy(c.date))}${c.inv && c.inv.no ? " · فاتورة " + esc(c.inv.no) : ""}</small></div>${chip(st[0] + (k.status === "late" ? " " + k.lateDays + " يوم" : ""), st[1])}</header>
          <div class="mid">${ring(k.pct, st[1])}<div class="nums"><span><small>الإجمالي</small><b>${N(k.total)}</b></span><span><small>المدفوع</small><b class="g">${N(k.paid)}</b></span><span><small>المتبقي</small><b class="${k.rem ? "r" : ""}">${N(k.rem)}</b></span></div></div>
          <footer>${k.next ? `<span class="nx">${IC.cal}القسط ${k.next.n}/${c.sched.length} · <b>${N(k.next.rem)}</b> · ${esc(nice(k.next.due))}</span>` : `<span class="nx fin">${IC.ok}تم السداد بالكامل</span>`}<span class="sp"></span>${k.next && live(c) ? `<button type="button" class="qst-btn sm pri" data-pay="${c.id}">${IC.cash}<span>تحصيل</span></button>` : ""}</footer></article>`; };
      body.innerHTML = `<div class="qst-flt">${F.map(f => `<button type="button" data-f="${f[0]}" class="${S.f === f[0] ? "on" : ""}">${f[1]}</button>`).join("")}<span class="sp"></span><small>${L.length} عقد</small></div>` +
        (L.length ? `<div class="qst-cards">${L.map(card).join("")}</div>` : empty(LIST.length ? "لا توجد عقود بهذه التصفية" : "ابدأ بأول عقد تقسيط", "", !LIST.length));
    } else if (S.tab === "pay") {
      const P = []; LIST.forEach(c => (c.pays || []).forEach(p => { if (match(c)) P.push({ c, p }); }));
      P.sort((a, b) => String(b.p.date).localeCompare(String(a.p.date)) || String(b.p.vno).localeCompare(String(a.p.vno), "en", { numeric: true }));
      const byM = {}; P.forEach(x => { const m = String(x.p.date).slice(0, 7); (byM[m] = byM[m] || []).push(x); });
      body.innerHTML = P.length ? `<div class="qst-agenda">${Object.keys(byM).sort().reverse().map(m => `<section class="qst-g gpay"><h4>${IC.cash}<span>${MON[+m.slice(5) - 1]} ${m.slice(0, 4)}</span><em>${byM[m].filter(x => !x.p.lost).length}</em><i></i><b>${N(byM[m].filter(x => !x.p.lost).reduce((a, x) => a + (+x.p.amt || 0), 0))} <small>DZD</small></b></h4>
          ${byM[m].map(x => `<div class="qst-row paid${x.p.lost ? " lost" : ""}" data-open="${x.c.id}">${avatar(x.c.cname)}<div class="who"><b>${esc(x.c.cname)}</b><small>عقد ${esc(x.c.no)} · إيصال استلام ${esc(x.p.vno || "—")}${x.p.trName ? " · " + esc(x.p.trName) : ""}${x.p.lost ? " · <u>الإيصال محذوف</u>" : ""}</small></div>
            <div class="when"><b>${esc(nice(x.p.date))}</b><small>${esc(x.p.by || "")}</small></div><div class="amt"><b>${N(x.p.amt)}</b><small>${+x.p.disc ? "+ خصم " + N(x.p.disc) : "DZD"}</small></div>
            <span class="acts">${x.p.vid && !x.p.lost ? `<button type="button" class="qst-ib" data-prv="${x.p.vid}" title="طباعة الإيصال">${IC.print}</button>` : ""}</span></div>`).join("")}</section>`).join("")}</div>`
        : empty("لا توجد تحصيلات بعد", "كل قسط تحصّله يظهر هنا بإيصاله");
    } else {
      const PER = [["m", "هذا الشهر"], ["pm", "الشهر الماضي"], ["q", "آخر 3 أشهر"], ["y", "هذه السنة"], ["all", "كل الفترات"]];
      const R = [["due", "الأقساط المستحقة والمتأخرة", "كل قسط لم يُدفع حتى نهاية الفترة — مرتبة حسب التأخير", IC.fire, "c"], ["pays", "تحصيلات الأقساط", "إيصالات الاستلام خلال الفترة حسب التاريخ", IC.cash, "e"],
        ["bal", "أرصدة عقود التقسيط", "الإجمالي · المدفوع · المتبقي · المتأخر لكل عقد", IC.doc, "a"], ["cust", "مديونية الأقساط حسب العميل", "مجموع ما على كل عميل من أقساط", IC.user, "d"]];
      body.innerHTML = `<div class="qst-flt">${PER.map(f => `<button type="button" data-per="${f[0]}" class="${S.per === f[0] ? "on" : ""}">${f[1]}</button>`).join("")}</div>
        <div class="qst-reps">${R.map(r => `<button type="button" class="qst-rep ${r[4]}" data-rep="${r[0]}"><span class="i">${r[3]}</span><b>${r[1]}</b><small>${r[2]}</small><em>فتح A4 ←</em></button>`).join("")}</div>`;
    }
  }
  const empty = (t, s, cta) => `<div class="qst-empty"><span>${IC.spark}</span><b>${t}</b>${s ? `<small>${s}</small>` : ""}${cta ? `<button type="button" class="qst-btn pri" data-a="new">${IC.plus}<span>عقد تقسيط جديد</span></button>` : ""}</div>`;
  const byId = id => LIST.find(c => String(c.id) === String(id));
  function onClick(e) {
    const t = e.target;
    const a = t.closest("[data-a]"); if (a) { const k = a.dataset.a; if (k === "new") wizard(); else if (k === "set") settings(); else if (k === "enable") setOn(true).then(() => { snd("ok"); T("✔ تم تفعيل الأقساط", "s"); badge(); refresh(true); }); return; }
    const sg = t.closest("[data-seg] button"); if (sg) { S.tab = sg.dataset.t; draw(); return; }
    const go = t.closest("[data-go]"); if (go) { S.tab = go.dataset.go; draw(); return; }
    const f = t.closest("[data-f]"); if (f) { S.f = f.dataset.f; drawBody(); return; }
    const pr = t.closest("[data-per]"); if (pr) { S.per = pr.dataset.per; drawBody(); return; }
    const rp = t.closest("[data-rep]"); if (rp) { report(rp.dataset.rep); return; }
    const wa = t.closest("[data-wa]"); if (wa) { const m = wa.dataset.wa.split(":"); remind(byId(m[0]), +m[1]); return; }
    const pv = t.closest("[data-prv]"); if (pv) { printVoucher(+pv.dataset.prv || pv.dataset.prv); return; }
    const py = t.closest("[data-pay]"); if (py) { collect(byId(py.dataset.pay)); return; }
    const op = t.closest("[data-open]"); if (op) { detail(byId(op.dataset.open)); return; }
  }

  /* ================= عقد جديد ================= */
  function wizard(pre) {
    pre = pre || {};
    const C = cfg(), AC = A(); if (!AC) { T("موديول الحسابات غير محمّل", "w"); return; }
    const W = { cust: null, src: "debt", inv: null, dues: [], plan: C.plans[0] ? C.plans[0].id : "", n: C.plans[0] ? C.plans[0].n : 3, pct: C.plans[0] ? C.plans[0].pct : 0, every: C.plans[0] ? C.plans[0].every : "m", first: "", downNow: true, hi: 0, list: [] };
    const M = modal({ title: "عقد تقسيط جديد", sub: "قسّط دين العميل على دفعات مريحة", icon: IC.plus, cls: "qst-wz", w: 900,
      body: `<div class="qst-wzg"><div class="qst-form">
          <div class="qst-st"><i>1</i>العميل</div>
          <div class="qst-f"><label>العميل<em>*</em></label><div class="qst-pick"><span class="in">${IC.user}<input data-k="cust" placeholder="اكتب اسم العميل أو رقمه…" autocomplete="off" spellcheck="false"></span><div class="qst-pl" data-pl hidden></div></div></div>
          <div class="qst-cinfo" data-ci hidden></div>
          <div class="qst-st"><i>2</i>المبلغ</div>
          <div class="qst-f2"><div class="qst-f"><label>المبلغ المراد تقسيطه<em>*</em></label><span class="in u"><input data-k="amount" inputmode="decimal" placeholder="0"><b>DZD</b></span></div>
            <div class="qst-f"><label>المقدَّم (اختياري)</label><span class="in u"><input data-k="down" inputmode="decimal" placeholder="0"><b>DZD</b></span></div></div>
          <label class="qst-ck" data-dn hidden><input type="checkbox" data-k="downNow" checked><i></i><span>استلام المقدَّم الآن في الخزينة (إيصال استلام نقدية)</span></label>
          <div class="qst-st"><i>3</i>نظام التقسيط</div>
          <div class="qst-plans" data-plans>${C.plans.map(p => `<button type="button" data-p="${esc(p.id)}"><b>${esc(p.name)}</b><small>${+p.pct ? "زيادة " + p.pct + "%" : "بدون زيادة"}</small></button>`).join("")}<button type="button" data-p="">${IC.spark}<b>مخصّص</b><small>حدّد بنفسك</small></button></div>
          <div class="qst-f3"><div class="qst-f"><label>عدد الأقساط</label><span class="qst-stp"><button type="button" data-s="-1">−</button><input data-k="n" inputmode="numeric"><button type="button" data-s="1">+</button></span></div>
            <div class="qst-f"><label>الزيادة على ثمن الحال</label><span class="in u"><input data-k="pct" inputmode="decimal" placeholder="0"><b>%</b></span></div>
            <div class="qst-f"><label>الدورية</label><div class="qst-sg" data-ev>${Object.keys(EVERY).map(k => `<button type="button" data-e="${k}">${EVERY[k][0]}</button>`).join("")}</div></div></div>
          <div class="qst-f2"><div class="qst-f"><label>تاريخ أول قسط</label><span class="in"><input type="date" data-k="first"></span></div>
            <div class="qst-f"><label>ملاحظات</label><span class="in"><input data-k="notes" placeholder="مثال: ثلاجة + غسالة" autocomplete="off"></span></div></div>
        </div>
        <aside class="qst-prev" data-pv></aside></div>`,
      foot: `<span class="qst-hint" data-hint></span><span class="sp"></span><button type="button" class="qst-btn ghost" data-x2>إلغاء</button><button type="button" class="qst-btn pri" data-save>${IC.ok}<span>حفظ العقد</span></button>`,
      onKey: e => { const pl = M.q("[data-pl]"); if (pl.hidden || e.target !== K("cust")) return false;
        if (e.key === "ArrowDown" || e.key === "ArrowUp") { W.hi = Math.max(0, Math.min(W.list.length - 1, W.hi + (e.key === "ArrowDown" ? 1 : -1))); drawPl(); return true; }
        if (e.key === "Enter") { if (W.list[W.hi]) pick(W.list[W.hi]); return true; } return false; },
      onEnter: () => save() });
    const K = k => M.q('[data-k="' + k + '"]');
    M.q("[data-x2]").onclick = M.close;
    let PARTIES = [];
    AC.parties("cu", true).then(l => { PARTIES = l || []; if (pre.cid) { const p = PARTIES.find(x => String(x.id) === String(pre.cid)); if (p) pick(p, pre); } else if (pre.cname) { const p = PARTIES.find(x => x.name === pre.cname); if (p) pick(p, pre); } });
    const norm = s => (FH() && FH().norm ? FH().norm(s) : String(s).toLowerCase());
    function drawPl() {
      const pl = M.q("[data-pl]"); if (!W.list.length) { pl.hidden = true; return; }
      pl.hidden = false; pl.innerHTML = W.list.map((p, i) => `<button type="button" data-i="${i}" class="${i === W.hi ? "hi" : ""}">${avatar(p.name)}<span><b>${esc(p.name)}</b><small>${esc(p.no || "")}</small></span>${-p.bal > 0.005 ? chip("عليه " + N(-p.bal), "late") : p.bal > 0.005 ? chip("له " + N(p.bal), "on") : chip("لا دين", "off")}</button>`).join("");
      const h = pl.querySelector(".hi"); if (h) h.scrollIntoView({ block: "nearest" });
    }
    K("cust").addEventListener("input", () => { W.cust = null; M.q("[data-ci]").hidden = true; const q = norm(K("cust").value.trim());
      W.list = q ? PARTIES.filter(p => norm(p.name).includes(q) || String(p.no || "").includes(q)).slice(0, 8) : PARTIES.slice().sort((a, b) => a.bal - b.bal).slice(0, 8); W.hi = 0; drawPl(); upd(); });
    K("cust").addEventListener("focus", () => { if (!W.cust) K("cust").dispatchEvent(new Event("input")); });
    M.q("[data-pl]").addEventListener("mousedown", e => { const b = e.target.closest("[data-i]"); if (b) { e.preventDefault(); pick(W.list[+b.dataset.i]); } });
    K("cust").addEventListener("blur", () => setTimeout(() => { M.q("[data-pl]").hidden = true; }, 150));
    function pick(p, pr) {
      W.cust = p; K("cust").value = p.name; M.q("[data-pl]").hidden = true; W.inv = null; W.dues = []; W.src = "debt";
      const debt = Math.max(0, r2(-p.bal));
      const ci = M.q("[data-ci]"); ci.hidden = false;
      const paint = () => { ci.innerHTML = `<div class="hd">${avatar(p.name)}<div><b>${esc(p.name)}</b><small>الدين الحالي: <u class="${debt ? "r" : ""}">${N(debt)} DZD</u></small></div></div>
          <div class="src"><button type="button" data-src="debt" class="${W.src === "debt" ? "on" : ""}">${IC.user}<span>دين العميل الحالي<small>${N(debt)}</small></span></button>
          ${W.dues.map(d => `<button type="button" data-src="${esc(d.id)}" class="${W.inv && String(W.inv.id) === String(d.id) ? "on" : ""}">${IC.doc}<span>فاتورة ${esc(d.no)}<small>${esc(dmy(d.date))} · الباقي ${N(d.rem)}</small></span></button>`).join("")}</div>`; };
      paint();
      ci.onclick = e => { const b = e.target.closest("[data-src]"); if (!b) return; if (b.dataset.src === "debt") { W.src = "debt"; W.inv = null; K("amount").value = debt || ""; } else { const d = W.dues.find(x => String(x.id) === b.dataset.src); W.src = "inv"; W.inv = d; K("amount").value = r2(d.rem); } paint(); upd(); };
      if (!K("amount").value) K("amount").value = debt || "";
      AC.dues("cu", p).then(l => { W.dues = (l || []).filter(d => +d.rem > 0.005).slice(0, 12); const busyInv = new Set(LIST.filter(c => live(c) && c.inv && calc(c).status !== "done").map(c => String(c.inv.id))); W.dues = W.dues.filter(d => !busyInv.has(String(d.id)));
        if (pr && pr.inv) { const d = W.dues.find(x => String(x.no) === String(pr.inv) || String(x.id) === String(pr.inv)); if (d) { W.src = "inv"; W.inv = d; K("amount").value = r2(d.rem); } }
        paint(); upd(); }).catch(() => { });
      upd(); setTimeout(() => K("amount").select(), 30);
    }
    function setPlan(id) { W.plan = id; const p = C.plans.find(x => x.id === id); if (p) { W.n = p.n; W.pct = +p.pct || 0; W.every = p.every || "m"; K("n").value = W.n; K("pct").value = W.pct || "";
        if (+p.down > 0 && !num(K("down").value)) { const a = num(K("amount").value); if (a > 0) K("down").value = r2(Math.round(a * p.down / 100)); } }
      upd(); }
    M.q("[data-plans]").onclick = e => { const b = e.target.closest("[data-p]"); if (b) { setPlan(b.dataset.p); if (!b.dataset.p) K("n").select(); } };
    M.q("[data-ev]").onclick = e => { const b = e.target.closest("[data-e]"); if (b) { W.every = b.dataset.e; W.first = ""; K("first").value = ""; W.plan = matchPlan(); upd(); } };
    M.qa("[data-s]").forEach(b => b.onclick = () => { K("n").value = Math.max(1, Math.min(120, (parseInt(K("n").value, 10) || 0) + (+b.dataset.s))); W.plan = ""; upd(); });
    const matchPlan = () => { const p = C.plans.find(x => x.n === (parseInt(K("n").value, 10) || 0) && (+x.pct || 0) === num(K("pct").value) && x.every === W.every); return p ? p.id : ""; };
    ["amount", "down", "n", "pct", "first", "downNow"].forEach(k => K(k).addEventListener(k === "downNow" || k === "first" ? "change" : "input", () => { if (k === "n" || k === "pct") W.plan = matchPlan(); if (k === "first") W.first = K("first").value; upd(); }));
    function read() {
      const amount = r2(num(K("amount").value)), down = r2(num(K("down").value)), n = Math.max(0, Math.min(120, parseInt(K("n").value, 10) || 0)), pct = Math.max(0, num(K("pct").value));
      const fin = r2(amount - down), markup = r2(Math.round(fin * pct / 100)), total = r2(fin + markup);
      const first = W.first || (W.every === "m" ? addMonths(today(), 1) : addDays(today(), W.every === "w" ? 7 : 14));
      const sched = n > 0 && total > 0 ? build({ fin: total, n, every: W.every, first, round: C.round }) : [];
      return { amount, down, n, pct, fin, markup, total, first, sched, downNow: K("downNow").checked };
    }
    function upd() {
      const v = read(), debt = W.cust ? Math.max(0, r2(-W.cust.bal)) : 0;
      if (!K("first").value) K("first").value = v.first;
      M.q("[data-dn]").hidden = !(v.down > 0);
      M.qa("[data-plans] button").forEach(b => b.classList.toggle("on", b.dataset.p === W.plan));
      M.qa("[data-ev] button").forEach(b => b.classList.toggle("on", b.dataset.e === W.every));
      const each = v.sched[0] ? v.sched[0].amt : 0, last = v.sched.length ? v.sched[v.sched.length - 1] : null;
      M.q("[data-pv]").innerHTML = `<div class="qst-tk"><div class="qst-th"><small>القسط ${EVERY[W.every][0]}</small><b>${N(each)}<em>DZD</em></b><span>${v.n || 0} قسط${last && Math.abs(last.amt - each) > 0.005 ? " · الأخير " + N(last.amt) : ""}</span></div>
          <div class="qst-ln"><span>المبلغ</span><b>${N(v.amount)}</b></div><div class="qst-ln"><span>المقدَّم</span><b>− ${N(v.down)}</b></div>
          <div class="qst-ln"><span>الزيادة ${v.pct ? "(" + v.pct + "%)" : ""}</span><b class="${v.markup ? "p" : ""}">+ ${N(v.markup)}</b></div>
          <div class="qst-ln tot"><span>إجمالي الأقساط</span><b>${N(v.total)}</b></div>
          ${last ? `<div class="qst-ln sm"><span>من ${esc(nice(v.sched[0].due))}</span><b>إلى ${esc(nice(last.due))}</b></div>` : ""}</div>
        <div class="qst-sc">${v.sched.map(s => `<div><i>${s.n}</i><span>${esc(nice(s.due))}</span><b>${N(s.amt)}</b></div>`).join("") || `<p>أدخل المبلغ وعدد الأقساط لترى الجدول</p>`}</div>`;
      const h = M.q("[data-hint]");
      h.className = "qst-hint"; h.textContent = "";
      if (W.cust && v.fin > debt + 0.01 + (v.downNow ? 0 : 0)) { h.classList.add("w"); h.textContent = "⚠ المبلغ أكبر من دين العميل الحالي (" + N(debt) + ") — العقد يجدوِل ديناً موجوداً ولا ينشئ ديناً جديداً"; }
      else if (v.markup > 0) { h.textContent = "✦ الزيادة " + N(v.markup) + " تُرحَّل قيداً: مدين العميل / دائن حساب الإيراد"; }
      return v;
    }
    K("n").value = W.n; K("pct").value = W.pct || ""; if (pre.amount) K("amount").value = pre.amount;
    upd(); setTimeout(() => K("cust").focus(), 60);
    let saving = false;
    function save() {
      if (saving) return; const v = read(), sb = M.q("[data-save]");
      const fail = (m, k) => { T(m, "w"); snd("error"); if (k) { K(k).focus(); K(k).closest(".in, .qst-stp").classList.add("bad"); setTimeout(() => K(k).closest(".in, .qst-stp").classList.remove("bad"), 1400); } };
      if (!W.cust || !W.cust.id) return fail("اختر العميل من القائمة", "cust");
      if (!(v.amount > 0)) return fail("أدخل المبلغ المراد تقسيطه", "amount");
      if (v.down < 0 || v.down >= v.amount) return fail("المقدَّم يجب أن يكون أقل من المبلغ", "down");
      if (!(v.n >= 1)) return fail("أدخل عدد الأقساط", "n");
      if (!v.first || v.first < addDays(today(), -366)) return fail("تاريخ أول قسط غير صحيح", "first");
      const go = () => {
        saving = true; busyBtn(sb, true);
        const c = { cid: W.cust.id, cno: W.cust.no || "", cname: W.cust.name, date: today(), inv: W.inv ? { id: W.inv.id, no: W.inv.no, date: W.inv.date } : null, amount: v.amount, down: v.down, pct: v.pct, markup: v.markup, total: v.total,
          n: v.n, every: W.every, first: v.first, plan: (C.plans.find(p => p.id === W.plan) || {}).name || "مخصّص", sched: v.sched, pays: [], je: null, downV: null, status: "on", notes: K("notes").value.trim(), user: USER(), created: new Date().toLocaleString("sv-SE").slice(0, 16) };
        const warn = [];
        FH().DB.next(KIND).catch(() => String(LIST.reduce((m, x) => Math.max(m, +x.no || 0), 0) + 1)).then(no => { c.no = String(no); return saveC(c); })
          .then(sc => { Object.assign(c, { id: sc.id, no: sc.no });
            return v.markup > 0 ? postMarkup(c).then(je => { c.je = je; }).catch(e => { warn.push("تعذّر ترحيل قيد الزيادة: " + (e.message || e)); }) : null; })
          .then(() => v.down > 0 && v.downNow ? treasuries().then(trs => { const tr = trs.find(t => String(t.id) === String(C.tr)) || trs[0]; if (!tr) throw new Error("لا توجد خزينة");
              return receive(c, { amt: v.down, tr, note: "مقدَّم — عقد تقسيط رقم " + c.no }).then(d => { c.downV = { vid: d.id, vno: d.no, amt: v.down, date: today(), trName: tr.name }; }); }).catch(e => { warn.push("تعذّر استلام المقدَّم: " + (e.message || e)); }) : null)
          .then(() => (c.je || c.downV) ? saveC(c) : c)
          .then(() => { saving = false; M.close(); snd("save"); T("✔ تم حفظ عقد التقسيط رقم " + c.no + " — " + v.n + " قسط × " + N(v.sched[0].amt), "s"); warn.forEach(w => setTimeout(() => T(w, "w"), 900));
            if (ROOT && $("v_" + VIEW)) { S.tab = "all"; draw(); } setTimeout(() => detail(byId(c.id)), 250); })
          .catch(e => { saving = false; busyBtn(sb, false); T("تعذّر حفظ العقد: " + (e.message || e), "e"); });
      };
      const debt = Math.max(0, r2(-W.cust.bal));
      if (v.fin > debt + 0.01) ask("المبلغ المقسَّط (" + N(v.fin) + ") أكبر من دين العميل الحالي (" + N(debt) + ").\nعقد التقسيط يجدوِل ديناً موجوداً ولا يضيف ديناً جديداً على العميل.\nهل تريد المتابعة؟", go); else go();
    }
    M.q("[data-save]").onclick = save;
    return M;
  }

  /* ================= تحصيل ================= */
  function collect(c, done) {
    if (!c) return; const k = calc(c);
    if (!live(c) || k.rem <= 0.005) { T("هذا العقد مسدَّد أو مغلق", "i"); return; }
    const C = cfg(), nx = k.next;
    const M = modal({ title: "تحصيل قسط", sub: esc(c.cname) + " · عقد " + esc(c.no), icon: IC.cash, cls: "qst-col", w: 480,
      body: `<div class="qst-colh">${avatar(c.cname)}<div><b>${esc(c.cname)}</b><small>القسط ${nx.n} من ${c.sched.length} · ${esc(nice(nx.due))} · ${esc(rel(nx.due))}</small></div>${ring(k.pct, ST[k.status][1])}</div>
        <div class="qst-big"><input data-k="amt" inputmode="decimal" value="${nx.rem}"><b>DZD</b></div>
        <div class="qst-quick"><button type="button" data-v="${nx.rem}">القسط الحالي<small>${N(nx.rem)}</small></button>${k.late > nx.rem + 0.005 ? `<button type="button" data-v="${k.late}" class="l">كل المتأخر<small>${N(k.late)}</small></button>` : ""}<button type="button" data-v="${k.rem}" class="f">سداد كامل<small>${N(k.rem)}</small></button></div>
        <div class="qst-f2"><div class="qst-f"><label>الخزينة</label><span class="in"><select data-k="tr"><option>…</option></select></span></div><div class="qst-f"><label>التاريخ</label><span class="in"><input type="date" data-k="date" value="${today()}" max="${today()}"></span></div></div>
        <div class="qst-f2"><div class="qst-f"><label>خصم تعجيل السداد (اختياري)</label><span class="in u"><input data-k="disc" inputmode="decimal" placeholder="0"><b>DZD</b></span></div><div class="qst-f"><label>ملاحظة</label><span class="in"><input data-k="note" autocomplete="off"></span></div></div>
        <div class="qst-after" data-af></div>`,
      foot: `<label class="qst-ck sm"><input type="checkbox" data-k="prn"><i></i><span>طباعة الإيصال</span></label><span class="sp"></span><button type="button" class="qst-btn ghost" data-x2>إلغاء</button><button type="button" class="qst-btn pri" data-ok>${IC.ok}<span>تحصيل</span></button>`,
      onEnter: () => go() });
    const K = x => M.q('[data-k="' + x + '"]'); M.q("[data-x2]").onclick = M.close;
    let TRS = [];
    treasuries().then(l => { TRS = l; K("tr").innerHTML = l.map(t => `<option value="${esc(t.id)}"${String(t.id) === String(C.tr) ? " selected" : ""}>${esc(t.name)}</option>`).join("") || "<option value=''>لا توجد خزينة</option>"; });
    const upd = () => { const a = r2(num(K("amt").value)), d = r2(num(K("disc").value)), after = Math.max(0, r2(k.rem - a - d));
      const c2 = Object.assign({}, c, { pays: (c.pays || []).concat([{ amt: a, disc: d }]) }), k2 = calc(c2);
      M.q("[data-af]").innerHTML = a + d > k.rem + 0.005 ? `<span class="w">⚠ المبلغ أكبر من المتبقي في العقد (${N(k.rem)})</span>` : `<span>المتبقي بعد التحصيل <b>${N(after)}</b></span>${k2.next ? `<span>القسط القادم <b>${N(k2.next.rem)}</b> · ${esc(nice(k2.next.due))}</span>` : `<span class="g">🎉 يكتمل العقد</span>`}`;
      M.qa(".qst-quick button").forEach(b => b.classList.toggle("on", Math.abs(+b.dataset.v - a) < 0.005)); };
    M.q(".qst-quick").onclick = e => { const b = e.target.closest("[data-v]"); if (b) { K("amt").value = b.dataset.v; upd(); K("amt").select(); } };
    K("amt").addEventListener("input", upd); K("disc").addEventListener("input", upd); upd();
    setTimeout(() => K("amt").select(), 60);
    let saving = false;
    function go() {
      if (saving) return; const a = r2(num(K("amt").value)), d = r2(num(K("disc").value)), tr = TRS.find(t => String(t.id) === K("tr").value), date = K("date").value || today();
      if (!(a > 0)) { T("أدخل المبلغ", "w"); K("amt").focus(); return; }
      if (d < 0) { T("الخصم لا يمكن أن يكون سالباً", "w"); return; }
      if (a + d > k.rem + 0.005) { T("المبلغ + الخصم أكبر من المتبقي في العقد (" + N(k.rem) + ")", "w"); K("amt").select(); return; }
      if (!tr) { T("اختر الخزينة", "w"); return; }
      if (date > today()) { T("التاريخ في المستقبل", "w"); return; }
      saving = true; busyBtn(M.q("[data-ok]"), true);
      const prn = K("prn").checked, note = K("note").value.trim();
      const fresh = byId(c.id) || c;
      receive(fresh, { amt: a, disc: d, tr, date, note: "قسط " + nx.n + "/" + c.sched.length + " — عقد تقسيط رقم " + c.no + (note ? " - " + note : "") })
        .then(doc => { fresh.pays = (fresh.pays || []).concat([{ id: uid(), date, amt: a, disc: d, vid: doc.id, vno: doc.no, tr: tr.id, trName: tr.name, by: USER(), note }]);
          return saveC(fresh).then(() => doc).catch(e => { T("تم إنشاء إيصال الاستلام رقم " + doc.no + " لكن تعذّر تحديث العقد: " + (e.message || e), "e"); throw e; }); })
        .then(doc => { if (String(C.tr) !== String(tr.id)) { const c2 = cfg(); c2.tr = tr.id; saveCfg(c2); }
          M.close(); snd("save"); const kk = calc(byId(c.id) || fresh);
          celebrate(kk.status === "done" ? "🎉 اكتمل عقد " + c.cname : "✔ تم تحصيل " + N(a) + " DZD", "إيصال استلام رقم " + doc.no + (kk.status === "done" ? "" : " · المتبقي " + N(kk.rem)), kk.status === "done");
          if (prn) printVoucher(doc.id); draw(); done && done(); })
        .catch(e => { saving = false; busyBtn(M.q("[data-ok]"), false); if (!/تعذّر تحديث العقد/.test(String(e && e.message))) T("تعذّر التحصيل: " + ((e && e.message) || e), "e"); });
    }
    M.q("[data-ok]").onclick = go;
  }
  function celebrate(t, s, big) {
    const d = document.createElement("div"); d.className = "qst-toast" + (big ? " big" : "");
    d.innerHTML = `<span class="ic">${IC.ok}</span><div><b>${esc(t)}</b><span>${esc(s)}</span></div>${big ? "<i></i><i></i><i></i><i></i><i></i><i></i>" : ""}`;
    document.body.appendChild(d); (void d.offsetWidth, d.classList.add("in")); setTimeout(() => { d.classList.remove("in"); setTimeout(() => d.remove(), 320); }, big ? 4200 : 3200);
  }
  function printVoucher(vid) {
    A().docs("recv", true).then(l => { const d = l.find(x => String(x.id) === String(vid)); if (!d) { T("الإيصال غير موجود", "w"); return; }
      if (window.ANOUER_CASH && ANOUER_CASH.printDoc) ANOUER_CASH.printDoc("recv", d); else T("طباعة الإيصالات غير متاحة", "w"); });
  }
  function remind(c, n) {
    if (!c) return; const k = calc(c), r = k.rows.find(x => x.n === n) || k.next; if (!r) return;
    const co = (window.ANOUER_RD && ANOUER_RD.company) ? ANOUER_RD.company().catch(() => ({})) : Promise.resolve({});
    Promise.resolve(co).then(o => { const shop = (o && o["Company Name"]) || "";
      const txt = "السلام عليكم " + c.cname + " 🌷\nنذكّركم بالقسط رقم " + r.n + " من " + c.sched.length + " بقيمة " + N(r.rem) + " DZD، " + (r.due < today() ? "وكان موعده " : "وموعده ") + dmy(r.due) + "." + (k.late > r.rem + 0.005 ? "\nمجموع المتأخر: " + N(k.late) + " DZD." : "") + "\nالمتبقي في العقد: " + N(k.rem) + " DZD.\nشكراً لثقتكم" + (shop ? " — " + shop : "");
      const fin = ok => { T(ok ? "✔ نُسخ نص التذكير — الصقه في محادثة العميل (Ctrl+V)" : "تعذّر النسخ — انسخ النص يدوياً", ok ? "s" : "w"); try { if (window.ANOUER_WA && ANOUER_WA.open) ANOUER_WA.open(); } catch (e) { } };
      (navigator.clipboard && navigator.clipboard.writeText ? navigator.clipboard.writeText(txt) : Promise.reject()).then(() => fin(true), () => { const ta = document.createElement("textarea"); ta.value = txt; document.body.appendChild(ta); ta.select(); let ok = false; try { ok = document.execCommand("copy"); } catch (e) { } ta.remove(); fin(ok); }); });
  }

  /* ================= تفاصيل العقد (لوحة جانبية) ================= */
  function detail(c) {
    if (!c) return;
    const M = modal({ title: "عقد تقسيط رقم " + c.no, sub: esc(c.cname), icon: IC.doc, cls: "qst-dt", side: true, body: "" });
    const paint = () => {
      const x = byId(c.id); if (!x) { M.close(); return; } c = x;
      const k = calc(c), st = ST[k.status], lv = live(c);
      const SL = { paid: "مدفوع", late: "متأخر", today: "اليوم", part: "مدفوع جزئياً", wait: "قادم" };
      M.body.innerHTML = `<div class="qst-dh ${st[1]}">${ring(k.pct, st[1] + " lg")}<div class="nfo"><b>${esc(c.cname)}</b><small>${esc(c.plan || "")} · ${c.sched.length} قسط ${esc(EVERY[c.every] ? EVERY[c.every][0] : "")} · منذ ${esc(dmy(c.date))}</small>
            <div>${chip(st[0] + (k.status === "late" ? " " + k.lateDays + " يوم" : ""), st[1])}${c.inv && c.inv.no ? chip("فاتورة " + esc(c.inv.no), "off") : ""}${c.je && c.je.no ? chip("قيد الزيادة " + esc(c.je.no), "off") : ""}</div></div></div>
        ${!c.je && +c.markup > 0 && lv ? `<div class="qst-warn">${IC.fire}<span>قيد الزيادة (${N(c.markup)}) لم يُرحَّل على حساب العميل بعد.</span><button type="button" class="qst-btn sm" data-d="je">ترحيل الآن</button></div>` : ""}
        <div class="qst-facts"><span><small>المبلغ</small><b>${N(c.amount)}</b></span><span><small>المقدَّم</small><b>${N(c.down)}</b></span><span><small>الزيادة${+c.pct ? " " + c.pct + "%" : ""}</small><b>${N(c.markup)}</b></span><span class="t"><small>إجمالي الأقساط</small><b>${N(k.total)}</b></span><span><small>المدفوع</small><b class="g">${N(k.paid)}</b></span><span><small>المتبقي</small><b class="${k.rem ? "r" : ""}">${N(k.rem)}</b></span></div>
        ${c.notes ? `<p class="qst-note">📝 ${esc(c.notes)}</p>` : ""}
        <div class="qst-acts2">${lv && k.rem > 0.005 ? `<button type="button" class="qst-btn pri" data-d="pay">${IC.cash}<span>تحصيل</span></button><button type="button" class="qst-btn" data-d="wa">${IC.wa}<span>تذكير</span></button>` : ""}<button type="button" class="qst-btn" data-d="print">${IC.print}<span>طباعة الجدول</span></button><span class="sp"></span>${lv ? `<button type="button" class="qst-btn dng" data-d="del" title="${(c.pays || []).length || c.downV ? "إغلاق العقد" : "حذف العقد"}">${IC.trash}</button>` : ""}</div>
        <h5>جدول الأقساط</h5>
        <div class="qst-tl">${k.rows.map(r => `<div class="${r.st}"><i>${r.st === "paid" ? IC.ok : r.n}</i><div><b>${esc(nice(r.due))}</b><small>${r.st === "late" ? esc(rel(r.due)) : SL[r.st] + (r.st === "wait" || r.st === "part" ? " · " + esc(rel(r.due)) : "")}${r.paid && r.rem ? " · دُفع " + N(r.paid) : ""}</small></div><span><b>${N(r.amt)}</b>${r.rem && r.paid ? `<small>الباقي ${N(r.rem)}</small>` : ""}</span></div>`).join("")}</div>
        ${(c.pays || []).length || c.downV ? `<h5>الإيصالات</h5><div class="qst-pays">${c.downV ? `<div><span class="v">${IC.cash}مقدَّم · إيصال ${esc(c.downV.vno)}</span><small>${esc(dmy(c.downV.date))}</small><b>${N(c.downV.amt)}</b><button type="button" class="qst-ib" data-prv="${c.downV.vid}" title="طباعة">${IC.print}</button></div>` : ""}
          ${(c.pays || []).slice().reverse().map(p => `<div class="${p.lost ? "lost" : ""}"><span class="v">${IC.cash}إيصال ${esc(p.vno || "—")}${p.lost ? " · محذوف" : ""}</span><small>${esc(dmy(p.date))}${p.trName ? " · " + esc(p.trName) : ""}</small><b>${N(p.amt)}${+p.disc ? `<em>+${N(p.disc)} خصم</em>` : ""}</b>${p.vid && !p.lost ? `<button type="button" class="qst-ib" data-prv="${p.vid}" title="طباعة">${IC.print}</button>` : "<span></span>"}</div>`).join("")}</div>` : ""}`;
    };
    paint();
    M.body.onclick = e => {
      const pv = e.target.closest("[data-prv]"); if (pv) return printVoucher(pv.dataset.prv);
      const b = e.target.closest("[data-d]"); if (!b) return; const a = b.dataset.d;
      if (a === "pay") collect(c, paint);
      else if (a === "wa") remind(c);
      else if (a === "print") schedDoc(c);
      else if (a === "je") { busyBtn(b, true); postMarkup(c).then(je => { c.je = je; return saveC(c); }).then(() => { T("✔ تم ترحيل قيد الزيادة رقم " + c.je.no, "s"); paint(); }).catch(er => { busyBtn(b, false); T("تعذّر الترحيل: " + (er.message || er), "e"); }); }
      else if (a === "del") {
        const has = (c.pays || []).some(p => !p.lost) || c.downV;
        if (has) ask("إغلاق عقد التقسيط رقم " + c.no + " ؟\nلن تُحذف الإيصالات المحصَّلة ولا قيد الزيادة — يتوقف فقط تتبّع الأقساط الباقية.", () => { c.status = "closed"; saveC(c).then(() => { T("تم إغلاق العقد", "s"); paint(); draw(); }); });
        else ask("حذف عقد التقسيط رقم " + c.no + " ؟" + (c.je ? "\nسيُعكس قيد الزيادة (" + N(c.markup) + ") من حساب العميل." : ""), () => {
          unpostMarkup(c).then(() => FH().DB.del(KIND, c.id)).then(() => load(true)).then(() => { snd("del"); T("تم حذف العقد", "s"); M.close(); draw(); }).catch(er => T("تعذّر الحذف: " + (er.message || er), "e")); });
      }
    };
    return M;
  }

  /* ================= التقارير (صفحات A4 — reports.js) ================= */
  const RP = () => window.ANOUER_REPORTS;
  function perOf() {
    const t = today(), y = t.slice(0, 4), m = +t.slice(5, 7), ms = t.slice(0, 8) + "01";
    if (S.per === "m") return [ms, addDays(addMonths(ms, 1), -1), "هذا الشهر"];
    if (S.per === "pm") return [addMonths(ms, -1), addDays(ms, -1), "الشهر الماضي"];
    if (S.per === "q") return [addMonths(ms, -2), addDays(addMonths(ms, 1), -1), "آخر 3 أشهر"];
    if (S.per === "y") return [y + "-01-01", y + "-12-31", "سنة " + y];
    return ["2000-01-01", "2099-12-31", "كل الفترات"];
  }
  const perChips = p => S.per === "all" ? [["الفترة", "كل الفترات"]] : [["في الفترة من", dmy(p[0]).replace(/\//g, "-")], ["الى", dmy(p[1]).replace(/\//g, "-")]];
  function report(id) {
    if (!RP() || !RP().docTab) { T("التقارير غير متاحة", "w"); return; }
    const p = perOf(), t = today(), end = p[1] < t ? p[1] : (S.per === "all" ? "2099-12-31" : p[1]);
    if (id === "due") {
      const rows = []; LIST.filter(live).forEach(c => { const k = calc(c); k.rows.forEach(r => { if (r.rem && r.due <= end) rows.push({ g: r.due < t ? 0 : r.due === t ? 1 : 2, cname: c.cname, no: c.no, k: r.n + " / " + c.sched.length, due: dmy(r.due).replace(/\//g, "-"), _d: r.due, days: r.due < t ? diff(r.due, t) : "", amt: r.amt, paid: r.paid, rem: r.rem, _cls: r.due < t ? "neg" : "", _party: null }); }); });
      rows.sort((a, b) => a._d.localeCompare(b._d));
      const G = ["متأخرة", "مستحقة اليوم", "قادمة"].map((ttl, i) => ({ title: ttl, rows: rows.filter(r => r.g === i) })).filter(g => g.rows.length);
      RP().docTab("الأقساط المستحقة والمتأخرة", { chips: [["حتى تاريخ", dmy(end === "2099-12-31" ? t : end).replace(/\//g, "-")]], groups: G.length ? G : [{ title: null, rows: [] }],
        cols: [{ t: "العميل", k: "cname", w: 52, cls: "l" }, { t: "رقم العقد", k: "no", w: 16 }, { t: "القسط", k: "k", w: 16 }, { t: "تاريخ الاستحقاق", k: "due", w: 24 }, { t: "أيام التأخير", k: "days", w: 16 }, { t: "قيمة القسط", k: "amt", w: 22, n: 1, sum: 1 }, { t: "المدفوع", k: "paid", w: 20, n: 1, sum: 1 }, { t: "المتبقي", k: "rem", w: 22, n: 1, sum: 1, hc: "#c0392b" }] });
    } else if (id === "pays") {
      const rows = []; LIST.forEach(c => (c.pays || []).forEach(x => { if (!x.lost && x.date >= p[0] && x.date <= p[1]) rows.push({ date: dmy(x.date).replace(/\//g, "-"), _d: x.date, cname: c.cname, no: c.no, vno: x.vno, tr: x.trName || "", by: x.by || "", amt: +x.amt || 0, disc: +x.disc || 0 }); }));
      rows.sort((a, b) => a._d.localeCompare(b._d) || String(a.vno).localeCompare(String(b.vno), "en", { numeric: true }));
      RP().docTab("تحصيلات الأقساط", { chips: perChips(p), rows, cols: [{ t: "التاريخ", k: "date", w: 22 }, { t: "العميل", k: "cname", w: 54, cls: "l" }, { t: "رقم العقد", k: "no", w: 16 }, { t: "رقم الإيصال", k: "vno", w: 18 }, { t: "الخزينة", k: "tr", w: 30 }, { t: "المستخدم", k: "by", w: 20 }, { t: "المبلغ", k: "amt", w: 22, n: 1, sum: 1, hc: "#2e8b57" }, { t: "الخصم", k: "disc", w: 16, n: 1, sum: 1 }] });
    } else if (id === "bal") {
      const rows = LIST.filter(c => c.status !== "cancel").map(c => { const k = calc(c); return { no: c.no, date: dmy(c.date).replace(/\//g, "-"), cname: c.cname, n: c.sched.length, total: k.total, paid: k.paid, rem: k.rem, late: k.late, st: ST[k.status][0].replace(" ✓", ""), next: k.next ? dmy(k.next.due).replace(/\//g, "-") : "", _cls: k.late > 0 ? "neg" : "" }; })
        .sort((a, b) => (+a.no || 0) - (+b.no || 0));
      RP().docTab("أرصدة عقود التقسيط", { land: true, chips: [["حتى تاريخ", dmy(t).replace(/\//g, "-")]], rows, cols: [{ t: "رقم العقد", k: "no", w: 14 }, { t: "التاريخ", k: "date", w: 20 }, { t: "العميل", k: "cname", w: 54, cls: "l" }, { t: "عدد الأقساط", k: "n", w: 14 }, { t: "الإجمالي", k: "total", w: 22, n: 1, sum: 1 }, { t: "المدفوع", k: "paid", w: 22, n: 1, sum: 1, hc: "#2e8b57" }, { t: "المتبقي", k: "rem", w: 22, n: 1, sum: 1 }, { t: "المتأخر", k: "late", w: 20, n: 1, sum: 1, hc: "#c0392b" }, { t: "القسط القادم", k: "next", w: 20 }, { t: "الحالة", k: "st", w: 16 }] });
    } else {
      const m = {}; LIST.filter(live).forEach(c => { const k = calc(c); if (k.status === "done") return; const g = m[c.cid] || (m[c.cid] = { cname: c.cname, cnt: 0, total: 0, paid: 0, rem: 0, late: 0, next: "" }); g.cnt++; g.total += k.total; g.paid += k.paid; g.rem += k.rem; g.late += k.late; if (k.next && (!g.next || k.next.due < g.next)) g.next = k.next.due; });
      const rows = Object.values(m).map(g => Object.assign(g, { next: g.next ? dmy(g.next).replace(/\//g, "-") : "", _cls: g.late > 0 ? "neg" : "" })).sort((a, b) => b.rem - a.rem);
      RP().docTab("مديونية الأقساط حسب العميل", { chips: [["حتى تاريخ", dmy(t).replace(/\//g, "-")]], rows, cols: [{ t: "العميل", k: "cname", w: 60, cls: "l" }, { t: "عدد العقود", k: "cnt", w: 16 }, { t: "الإجمالي", k: "total", w: 24, n: 1, sum: 1 }, { t: "المدفوع", k: "paid", w: 24, n: 1, sum: 1, hc: "#2e8b57" }, { t: "المتبقي", k: "rem", w: 24, n: 1, sum: 1 }, { t: "المتأخر", k: "late", w: 22, n: 1, sum: 1, hc: "#c0392b" }, { t: "أقرب قسط", k: "next", w: 22 }] });
    }
  }
  function schedDoc(c) {
    if (!RP() || !RP().docTab) { T("الطباعة غير متاحة", "w"); return; }
    const k = calc(c), SL = { paid: "مدفوع", late: "متأخر", today: "مستحق اليوم", part: "مدفوع جزئياً", wait: "قادم" };
    STACK.slice().forEach(m => m.close());
    RP().docTab("جدول أقساط — عقد " + c.no, { title: "جدول أقساط العميل", chips: [["رقم العقد", c.no], ["التاريخ", dmy(c.date).replace(/\//g, "-")]],
      bx2: [[["العميل", c.cname], ["الرقم", c.cno || ""], ["نظام التقسيط", (c.plan || "") + " · " + c.sched.length + " قسط"]], [["المبلغ", N(c.amount), "", "n"], ["المقدَّم", N(c.down), "", "n"], ["الزيادة", N(c.markup), "", "n"]]],
      rows: k.rows.map(r => ({ due: dmy(r.due).replace(/\//g, "-"), amt: r.amt, paid: r.paid, rem: r.rem, st: SL[r.st], sig: "", _cls: r.st === "late" ? "neg" : "" })),
      cols: [{ t: "تاريخ الاستحقاق", k: "due", w: 30 }, { t: "قيمة القسط", k: "amt", w: 28, n: 1, sum: 1 }, { t: "المدفوع", k: "paid", w: 26, n: 1, sum: 1, hc: "#2e8b57" }, { t: "المتبقي", k: "rem", w: 26, n: 1, sum: 1 }, { t: "الحالة", k: "st", w: 26 }, { t: "التوقيع", k: "sig", w: 34, nosort: 1 }] });
  }

  /* ================= الإعدادات + نظم التقسيط ================= */
  function settings() {
    const C = cfg(); let plans = C.plans.map(p => Object.assign({}, p));
    const M = modal({ title: "إعدادات الأقساط", sub: "نظم التقسيط · الحسابات · التقريب", icon: IC.gear, cls: "qst-set", w: 640,
      body: `<h5>نظم التقسيط</h5><div class="qst-pe" data-pe></div><button type="button" class="qst-btn sm" data-add>${IC.plus}<span>نظام جديد</span></button>
        <h5>المحاسبة — شجرة الحسابات</h5>
        <div class="qst-f"><label>حساب إيراد «الزيادة على ثمن الحال» (4 الإيرادات)</label><span class="in"><select data-k="acc"><option value="">جاري التحميل…</option></select></span><small class="hlp">قيد الزيادة: مدين العميل / دائن هذا الحساب — يظهر في «قيود المحاسبة» وكشف حساب العميل.</small></div>
        <div class="qst-f2"><div class="qst-f"><label>الخزينة الافتراضية للتحصيل</label><span class="in"><select data-k="tr"><option value="">…</option></select></span></div>
          <div class="qst-f"><label>تقريب قيمة القسط</label><span class="in"><select data-k="round">${[[1, "بدون تقريب"], [10, "لأقرب 10"], [50, "لأقرب 50"], [100, "لأقرب 100"], [500, "لأقرب 500"], [1000, "لأقرب 1000"]].map(o => `<option value="${o[0]}"${+C.round === o[0] ? " selected" : ""}>${o[1]} DZD</option>`).join("")}</select></span><small class="hlp">الفرق يُضاف لآخر قسط.</small></div></div>
        <label class="qst-ck"><input type="checkbox" data-k="on" ${on() ? "checked" : ""}><i></i><span>الأقساط مفعّلة</span></label>`,
      foot: `<span class="sp"></span><button type="button" class="qst-btn ghost" data-x2>إلغاء</button><button type="button" class="qst-btn pri" data-ok>${IC.ok}<span>حفظ</span></button>` });
    const K = x => M.q('[data-k="' + x + '"]'); M.q("[data-x2]").onclick = M.close;
    const drawP = () => { M.q("[data-pe]").innerHTML = `<div class="h"><span>الاسم</span><span>عدد الأقساط</span><span>الدورية</span><span>الزيادة %</span><span>المقدَّم %</span><span></span></div>` + plans.map((p, i) => `<div data-i="${i}"><input data-c="name" value="${esc(p.name)}" maxlength="24"><input data-c="n" inputmode="numeric" value="${p.n}"><select data-c="every">${Object.keys(EVERY).map(e => `<option value="${e}"${p.every === e ? " selected" : ""}>${EVERY[e][0]}</option>`).join("")}</select><input data-c="pct" inputmode="decimal" value="${+p.pct || 0}"><input data-c="down" inputmode="decimal" value="${+p.down || 0}"><button type="button" class="qst-ib" data-rm title="حذف">${IC.trash}</button></div>`).join(""); };
    drawP();
    const readP = () => { M.qa("[data-pe] [data-i]").forEach(r => { const p = plans[+r.dataset.i]; p.name = r.querySelector('[data-c="name"]').value.trim(); p.n = Math.max(1, Math.min(120, parseInt(r.querySelector('[data-c="n"]').value, 10) || 1)); p.every = r.querySelector('[data-c="every"]').value; p.pct = Math.max(0, num(r.querySelector('[data-c="pct"]').value)); p.down = Math.max(0, Math.min(90, num(r.querySelector('[data-c="down"]').value))); }); };
    M.q("[data-pe]").onclick = e => { const b = e.target.closest("[data-rm]"); if (!b) return; readP(); if (plans.length <= 1) { T("يلزم نظام واحد على الأقل", "w"); return; } plans.splice(+b.closest("[data-i]").dataset.i, 1); drawP(); };
    M.q("[data-add]").onclick = () => { readP(); if (plans.length >= 12) { T("12 نظاماً كحد أقصى", "w"); return; } plans.push({ id: "p" + uid(), name: "نظام جديد", n: 6, every: "m", pct: 0, down: 0 }); drawP(); const l = M.qa('[data-pe] [data-c="name"]').pop(); l.focus(); l.select(); };
    let ACCS = [];
    Promise.all([revAccounts(), revAcc(), A() ? treasuries().catch(() => []) : []]).then(([l, cur, trs]) => { ACCS = l;
      K("acc").innerHTML = l.map(a => `<option value="${esc(a.id)}"${cur && String(cur.id) === String(a.id) ? " selected" : ""}>${esc(a.no)} — ${esc(a.name)}</option>`).join("") || `<option value="">لا توجد حسابات إيرادات</option>`;
      K("tr").innerHTML = trs.map(t => `<option value="${esc(t.id)}"${String(t.id) === String(C.tr) ? " selected" : ""}>${esc(t.name)}</option>`).join(""); });
    M.q("[data-ok]").onclick = () => {
      readP(); const bad = plans.find(p => !p.name); if (bad) { T("أدخل اسم كل نظام تقسيط", "w"); return; }
      const names = plans.map(p => p.name); if (names.some((n, i) => names.indexOf(n) !== i)) { T("اسم نظام مكرر", "w"); return; }
      const a = ACCS.find(x => String(x.id) === K("acc").value);
      const c2 = Object.assign({}, C, { plans, round: +K("round").value || 1, tr: K("tr").value || C.tr, acc: a ? { id: a.id, no: a.no, name: a.name } : C.acc });
      const want = K("on").checked;
      saveCfg(c2).then(() => want !== (enList().indexOf("inst") >= 0) ? setOn(want) : null).then(() => { M.close(); snd("save"); T("✔ تم حفظ إعدادات الأقساط", "s"); badge(); refresh(); });
    };
  }

  /* ================= فاتورة المبيعات: «قسّط الباقي» بعد حفظ فاتورة آجلة ================= */
  let PEND = null, HOOKED = false;
  function hookAfterSave() {
    if (HOOKED) return; HOOKED = true; const prev = window.__sxAfterSave;
    window.__sxAfterSave = function (r) { try { if (PEND) { const p = PEND; PEND = null; const no = r && (r.invoiceNo || r.InvoiceNo); if (no && on()) setTimeout(() => offer(p.cust, String(no), p.inst), p.inst ? 500 : 900); } } catch (e) { } return prev ? prev.apply(this, arguments) : undefined; };
  }
  function wrapSave() {
    try { if (typeof doSave !== "function" || doSave.__qst) return; } catch (e) { return; }
    const orig = doSave;
    const w = function () {
      try { PEND = null; if (on() && HOST() && !document.querySelector(".inv.retmode")) { const nm = (($("custName") || {}).value || "").trim(); if (nm && nm !== "تعامل نقدى" && nm !== "تعامل نقدي") { PEND = { cust: nm, inst: !!(window.__saleInst && __saleInst()) }; hookAfterSave(); } } } catch (e) { PEND = null; }
      return orig.apply(this, arguments);
    };
    w.__qst = 1; try { doSave = w; } catch (e) { }
  }
  /* direct = الفاتورة حُفظت بالتعامل «تقسيط» (قائمة كاش / أجل / تقسيط) ← يُفتح العقد مباشرة ، وإلا شريط اقتراح */
  function offer(cname, invNo, direct) {
    const AC = A(); if (!AC) return;
    AC.parties("cu", true).then(l => { const p = (l || []).find(x => x.name === cname); if (!p) return;
      return AC.dues("cu", p).then(d => { const inv = (d || []).find(x => String(x.no) === invNo);
        if (!inv || !(+inv.rem > 0.005)) { if (direct) T("الفاتورة " + invNo + " مدفوعة بالكامل — لا يوجد باقٍ للتقسيط", "i"); return; }
        if (direct) { load(true).then(() => wizard({ cid: p.id, inv: invNo })); return; }
        document.querySelectorAll(".qst-offer").forEach(x => x.remove());
        const el = document.createElement("div"); el.className = "qst-offer";
        el.innerHTML = `<span class="ic">${IC.logo}</span><div><b>باقي ${N(inv.rem)} DZD على ${esc(cname)}</b><small>فاتورة ${esc(invNo)} — قسّطه على دفعات؟</small></div><button type="button" class="qst-btn pri sm" data-go>${IC.bolt}<span>تقسيط</span></button><button type="button" class="qst-ib" data-no title="لاحقاً">${IC.x}</button>`;
        document.body.appendChild(el); (void el.offsetWidth, el.classList.add("in"));
        const out = () => { el.classList.remove("in"); setTimeout(() => el.remove(), 300); }; const tm = setTimeout(out, 12000);
        el.querySelector("[data-no]").onclick = () => { clearTimeout(tm); out(); };
        el.querySelector("[data-go]").onclick = () => { clearTimeout(tm); out(); load(true).then(() => wizard({ cid: p.id, inv: invNo })); };
      }); }).catch(() => { });
  }
  /* تذكير عند فتح البرنامج: أقساط اليوم والمتأخرة */
  function morning() {
    if (!on() || !FH()) return;
    load(true).then(() => { const s = summary(), n = s.todayN + s.lateN; if (!n) return;
      const el = document.createElement("div"); el.className = "qst-offer am";
      el.innerHTML = `<span class="ic">${IC.clock}</span><div><b>${n} قسط ${s.lateN ? "مستحق ومتأخر" : "مستحق اليوم"}</b><small>${N(s.today + s.late)} DZD${s.lateC ? " · " + s.lateC + " عميل متأخر" : ""}</small></div><button type="button" class="qst-btn pri sm" data-go><span>عرض</span></button><button type="button" class="qst-ib" data-no title="إغلاق">${IC.x}</button>`;
      document.body.appendChild(el); (void el.offsetWidth, el.classList.add("in"));
      const out = () => { el.classList.remove("in"); setTimeout(() => el.remove(), 300); }; const tm = setTimeout(out, 14000);
      el.querySelector("[data-no]").onclick = () => { clearTimeout(tm); out(); };
      el.querySelector("[data-go]").onclick = () => { clearTimeout(tm); out(); open("due"); }; });
  }

  /* ---------------- لوحة الإضافات + قائمة «الإضافات» ---------------- */
  function open(tab) {
    const run = () => center(tab);
    if ((window.ANOUER_EDITION || {}).dist && window.ANOUER_LIC && ANOUER_LIC.gate) {
      if (liteLock() && ANOUER_LITE.gate) return ANOUER_LITE.gate(TITLE, run);
      return ANOUER_LIC.gate("inst", run);
    }
    run();
  }
  document.addEventListener("click", e => { const c = e.target.closest && e.target.closest('.pp-card[data-a="inst"]'); if (!c) return; e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); open(); }, true);
  function badge() { const c = document.querySelector('.pp-card[data-a="inst"]'); if (!c) return; let b = c.querySelector(".qst-badge"); if (!b) { c.classList.add("loy-addon", "qst-addon"); c.insertAdjacentHTML("beforeend", '<span class="loy-badge qst-badge"></span>'); b = c.querySelector(".qst-badge"); } b.classList.toggle("off", !on()); b.innerHTML = IC.logo + (on() ? "مفعّلة" : "غير مفعّلة"); }
  new MutationObserver(() => { const c = document.querySelector('.pp-card[data-a="inst"]:not([data-qst])'); if (!c) return; c.dataset.qst = 1; badge(); }).observe(document.body, { childList: true, subtree: true });
  function addMenu() {
    const M = window.__MENUS, L = M && M["الإضافات"]; if (!L) return false;
    if (L.some(i => i.t === TITLE)) return true;
    try { if (window.__NAVIC) window.__NAVIC.inst = '<svg viewBox="0 0 20 20"><rect x="1.500" y="3.500" width="17" height="14" rx="3" fill="#ede9fe"/><rect x="1.500" y="3.500" width="17" height="4.500" rx="2" fill="#7c3aed"/><path d="M6 2v3M14 2v3" stroke="#4c1d95" stroke-width="1.600" stroke-linecap="round"/><rect x="4.500" y="10.500" width="3" height="2.200" rx=".6" fill="#7c3aed"/><rect x="8.500" y="10.500" width="3" height="2.200" rx=".6" fill="#db2777"/><rect x="12.500" y="10.500" width="3" height="2.200" rx=".6" fill="#c4b5fd"/><rect x="4.500" y="13.800" width="3" height="2.200" rx=".6" fill="#c4b5fd"/></svg>'; } catch (e) { }
    const k = Math.max(L.findIndex(x => x.t === "التبرعات"), L.findIndex(x => x.t === "نقاط الولاء"), L.findIndex(x => x.t === "كوبونات الخصم"));
    L.splice(k >= 0 ? k + 1 : L.length, 0, { t: TITLE, ic: "inst", run: () => open() });
    return true;
  }
  function boot() {
    wrapSave();
    if (!addMenu()) { let n = 0; const iv = setInterval(() => { if (addMenu() || ++n > 20) clearInterval(iv); }, 500); }
    setTimeout(morning, 9000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => setTimeout(boot, 700)); else setTimeout(boot, 700);

  window.ANOUER_INST = { open, on, setOn, cfg, list: () => LIST, load, calc, build, wizard: p => wizard(p), collect: id => collect(byId(id)), detail: id => detail(byId(id)), settings, reconcile, summary };
})();
