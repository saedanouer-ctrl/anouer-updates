/* ANOUER — «تيكت العروض A5» لرفوف السوبرماركت (2026)
   ست تصاميم ملوّنة بمقاس A5 (148×210 مم) تُختار من قائمة تصاميم الباركود مثل AUTO:
     offa5:1 «عرض خاص — أحمر جريء»   offa5:2 «سوبرماركت — أصفر»   offa5:3 «عرض الأسبوع — 2026»
     offa5:4 «طازج — أخضر»   offa5:5 «عرض حصري — أسود و ذهبي»   offa5:6 «عرض محدود ⚡ — برتقالي»
     offa5:7/8/9 «خصم 5 ومافوق»: مقارنة الحبة مع 5 ومافوق ، سلّم الأسعار ، ×5 مودرن
       (سعر 5 ومافوق للصنف ← وإلا «خصم الكمية» ← وإلا السعر المكتوب في السطر إن كان أقل من سعر البيع)
   السعر الجديد / القديم (بالترتيب):
     1) السعر المكتوب في سطر الصنف أقل من سعر البيع ← هو سعر العرض ، وسعر البيع = السعر القديم
     2) «خصومات الأصناف» النشطة ← سعر بعد الخصم ، وسعر البيع = السعر القديم
     3) السعر القديم المسجّل في الصنف (oldPrice) أكبر من سعر البيع
     وإلا: السعر بشارة «سعر ممتاز».
   تحت السعر: سعر الوحدة الكبرى (الكرتونة …) أو «5 ومافوق» + شرائح «خصم الكمية».
   الطباعة: نافذة الطباعة تاع ANOUER على طابعة A4/A5 — صفحة A5 لكل تيكت. */
(function () {
  "use strict";
  if (window.__BCO) return;
  const E = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const RD = () => window.ANOUER_RD, B = () => window.__BCP || {}, A = () => window.__BCA;
  const r1 = v => Math.round(v * 100) / 100;
  const W = 148, H = 210;
  const NUMF = "'Arial Black','Segoe UI Black','Segoe UI',Arial,sans-serif", ARF = "'Droid Arabic Kufi','Tajawal','Segoe UI',Tahoma,Arial,sans-serif";
  const money = v => { const n = Math.round((+v || 0) * 100) / 100; return n.toLocaleString("en-US", { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 }); };
  const STYLES = [
    { k: "offa5:1", id: "A5-1", name: "🏷️ عرض خاص — أحمر جريء (A5)" },
    { k: "offa5:2", id: "A5-2", name: "🏷️ سوبرماركت — أصفر (A5)" },
    { k: "offa5:3", id: "A5-3", name: "🏷️ عرض الأسبوع — 2026 (A5)" },
    { k: "offa5:4", id: "A5-4", name: "🏷️ طازج — أخضر (A5)" },
    { k: "offa5:5", id: "A5-5", name: "🏷️ عرض حصري — أسود و ذهبي (A5)" },
    { k: "offa5:6", id: "A5-6", name: "🏷️ عرض محدود ⚡ — برتقالي (A5)" },
    { k: "offa5:7", id: "A5-7", name: "🏷️ خصم 5 ومافوق — مقارنة زرقاء (A5)" },
    { k: "offa5:8", id: "A5-8", name: "🏷️ خصم 5 ومافوق — سلّم الأسعار (A5)" },
    { k: "offa5:9", id: "A5-9", name: "🏷️ خصم 5 ومافوق — ×5 مودرن (A5)" }
  ];
  const isKey = k => /^offa5:[1-9]$/.test(String(k || ""));

  /* ---------- البيانات ---------- */
  function data(j) {
    const I = (A() && A().info) ? A().info(j) : { name: j.name || "", single: 1, price: +j.price || 0, p5: 0, qd: [] };
    const f = B().findByCode ? B().findByCode(j.code) : null, p = (f && f.p) || null;
    let unit, base, extra = [];
    if (I.single) {
      unit = I.unit || ""; base = +I.price || 0;
      if (I.p5) extra.push({ t: "5 ومافوق", v: I.p5 });
    } else {
      const bigSel = j.unit && j.unit === I.big;
      unit = bigSel ? I.big : I.piece; base = bigSel ? I.bp : I.pp;
      if (bigSel) extra.push({ t: "سعر " + I.piece, v: I.pp });
      else extra.push({ t: "سعر " + I.big + " (×" + (Math.round(I.n * 1000) / 1000) + ")", v: I.bp });
      if (I.inP > 0 && I.save >= 1) extra.push({ t: "القطعة داخل " + I.big, v: I.inP, pct: I.save });
    }
    (I.qd || []).filter(q => !q.promo).slice(-2).forEach(q => extra.push({ t: q.from + " ومافوق", v: q.price, pct: q.pct }));
    extra = extra.slice(0, 2);
    let now = base, old = 0, why = "";
    const jp = +j.price || 0, promo = (I.qd || []).find(q => q.promo);
    if (jp > 0 && base > 0 && jp < base - .004) { now = jp; old = base; why = "price"; }
    else if (promo && base > 0) { now = promo.price; old = base; why = "promo"; }
    else if (p && +p.oldPrice > base + .004) { old = +p.oldPrice; why = "old"; }
    if (!(now > 0)) now = jp || base;
    const pct = old > 0 && now < old ? Math.round((1 - now / old) * 100) : 0;
    return { name: String(I.name || j.name || (p && p.name) || "").trim() || "—", unit, now, old: pct > 0 ? old : 0, pct, save: pct > 0 ? old - now : 0, extra, code: j.code || "" };
  }

  /* ---------- أدوات الرسم ---------- */
  function fit(txt, w, h, fs, ff, b) {
    try { const R = RD(); if (R && R.fitText) { const f = R.fitText({ w, h }, { fs, ff, b: b ? 1 : 0, w: b ? 800 : 600, pad: [0, 0, 0, 0] }, txt); if (f) return f; } } catch (e) { }
    /* بدون محرك الملاءمة: تقدير عرض الحروف */
    const mmPt = .3528, cw = .56 * mmPt, len = Math.max(1, String(txt).length); let s = Math.min(fs, w / (len * cw), h / (1.15 * mmPt));
    return { fs: Math.max(4, Math.floor(s * 10) / 10), t: String(txt), lh: 1.1 };
  }
  const box = (x, y, w, h, css) => `<div style="position:absolute;left:${r1(x)}mm;top:${r1(y)}mm;width:${r1(w)}mm;height:${r1(h)}mm;${css || ""}"></div>`;
  function T(x, y, w, h, txt, fs, o) {
    o = o || {}; const f = fit(txt, w, h, fs, o.ff || ARF, o.b !== 0);
    const al = o.al === "l" ? "left" : o.al === "r" ? "right" : "center";
    return `<div style="position:absolute;left:${r1(x)}mm;top:${r1(y)}mm;width:${r1(w)}mm;height:${r1(h)}mm;display:flex;align-items:center;overflow:hidden;${o.css || ""}"><span style="display:block;width:100%;text-align:${al};white-space:pre;font-family:${o.ff || ARF};font-weight:${o.b === 0 ? 600 : 800};font-size:${f.fs}pt;line-height:${/\n/.test(f.t) ? (f.lh || 1.1) : 1.05};color:${o.c || "#000"};unicode-bidi:plaintext;${o.st || ""}">${E(f.t)}</span></div>`;
  }
  /* السعر الكبير: الجزء الصحيح ضخم ثم الكسور «,00» صغيرة فوق على اليمين (مثل 540,00) + «دج» تحتها */
  function PRICE(x, y, w, h, v, col, o) {
    o = o || {};
    const n = Math.round((+v || 0) * 100) / 100, ip = Math.floor(n + 1e-9), dc = Math.round((n - ip) * 100), I = ip.toLocaleString("en-US");
    const sw = w * .2, f = fit(I, w - sw - 1, h, o.max || 150, NUMF, 1), sfs = Math.max(9, f.fs * .34);
    const ihW = Math.min(w - sw - 1, I.length * f.fs * .3528 * .66 + 2), tot = ihW + sw, x0 = x + (w - tot) / 2;
    let h2 = `<div style="position:absolute;left:${r1(x0)}mm;top:${r1(y)}mm;width:${r1(ihW)}mm;height:${r1(h)}mm;display:flex;align-items:center;justify-content:center"><span style="font-family:${NUMF};font-weight:900;font-size:${f.fs}pt;line-height:1;color:${col};letter-spacing:-.6mm;white-space:pre;${o.st || ""}">${E(I)}</span></div>`;
    const top = y + h * .14;
    h2 += `<div style="position:absolute;left:${r1(x0 + ihW)}mm;top:${r1(top)}mm;width:${r1(sw)}mm;display:flex;flex-direction:column;align-items:flex-start;gap:.6mm;direction:ltr">` +
      `<span style="font-family:${NUMF};font-weight:900;font-size:${r1(sfs)}pt;line-height:1;color:${col}">,${String(dc).padStart(2, "0")}</span>` +
      `<span style="font-family:${ARF};font-weight:800;font-size:${r1(sfs * .78)}pt;line-height:1.1;color:${o.cur || col};padding-left:1.5mm">دج</span></div>`;
    return h2;
  }
  const strike = (x, y, w, h, txt, fs, col, line) => T(x, y, w, h, txt, fs, { ff: NUMF, c: col }) + box(x + w * .2, y + h / 2 - .4, w * .6, .9, `background:${line};transform:rotate(-8deg);border-radius:1mm`);
  const logo = (co, x, y, s) => { const L = co && co["Company Logo"]; return L ? `<img src="${E(L)}" style="position:absolute;left:${r1(x)}mm;top:${r1(y)}mm;width:${r1(s)}mm;height:${r1(s)}mm;object-fit:contain">` : ""; };
  const today = () => new Date().toLocaleDateString("en-GB");
  const burst = (x, y, s, fill, stroke) => `<svg style="position:absolute;left:${r1(x)}mm;top:${r1(y)}mm;width:${r1(s)}mm;height:${r1(s)}mm" viewBox="0 0 100 100"><path d="${(() => { let d = ""; for (let i = 0; i < 32; i++) { const a = i / 32 * Math.PI * 2, r = i % 2 ? 41 : 50; d += (i ? "L" : "M") + (50 + r * Math.sin(a)).toFixed(2) + " " + (50 - r * Math.cos(a)).toFixed(2); } return d + "Z"; })()}" fill="${fill}" stroke="${stroke || "none"}" stroke-width="1.6"/></svg>`;
  const wrap = h => `<div class="rdp" style="position:relative;width:${W}mm;height:${H}mm;overflow:hidden;background:#fff;color:#000;direction:ltr;-webkit-print-color-adjust:exact;print-color-adjust:exact">${h}</div>`;

  /* ---------- التصميم 1: «عرض خاص» — أحمر جريء ---------- */
  function s1(D, co) {
    let h = "";
    h += box(0, 0, W, 58, "background:linear-gradient(160deg,#ff3b3b 0%,#e10600 55%,#9e0000 100%);clip-path:polygon(0 0,100% 0,100% 80%,0 100%)");
    h += box(0, 0, W, 58, "background:repeating-linear-gradient(135deg,rgba(255,255,255,.07) 0 3mm,transparent 3mm 7mm);clip-path:polygon(0 0,100% 0,100% 80%,0 100%)");
    h += logo(co, W - 26, 5, 20);
    h += T(8, 6, W - 40, 9, String(co["Company Name"] || "ANOUER"), 13, { al: "r", c: "#ffe9e9", b: 0 });
    h += T(8, 15, W - 16, 22, "عرض خاص", 58, { c: "#fff", st: "text-shadow:0 1mm 0 rgba(0,0,0,.18)" });
    h += T(8, 36, W - 16, 7, "SPECIAL OFFER", 11, { c: "#ffd6d6", ff: "'Segoe UI',Arial,sans-serif", b: 0, st: "letter-spacing:1.6mm" });
    /* الشارة النجمية */
    const bs = 44, bx = 5, by = 34;
    h += burst(bx, by, bs, "#ffd60a", "#b38f00");
    if (D.pct) { h += T(bx + 6, by + 10, bs - 12, 16, "−" + D.pct + "%", 34, { ff: NUMF, c: "#b10000" }); h += T(bx + 8, by + 26, bs - 16, 7, "تخفيض", 13, { c: "#7a0000" }); }
    else { h += T(bx + 7, by + 13, bs - 14, 9, "سعر", 15, { c: "#7a0000" }); h += T(bx + 7, by + 21, bs - 14, 11, "ممتاز", 22, { c: "#b10000" }); }
    /* الاسم + الوحدة */
    h += T(52, 60, W - 60, 24, D.name, 30, { al: "r" });
    if (D.unit) h += T(W - 58, 85, 50, 8, "سعر ال" + D.unit.replace(/^ال/, ""), 14, { al: "r", c: "#e10600" });
    h += box(8, 95, W - 16, .9, "background:linear-gradient(90deg,transparent,#e10600 20%,#e10600 80%,transparent)");
    /* السعر */
    h += PRICE(6, D.old ? 98 : 102, W - 12, D.old ? 58 : 70, D.now, "#e10600", { max: 170 });
    if (D.old) {
      h += T(W / 2 + 1, 157, 34, 9, "بدلاً من", 15, { al: "l", c: "#475569" });
      h += strike(W / 2 - 47, 156, 46, 11, money(D.old) + " دج", 22, "#475569", "#e10600");
      h += T(8, 167, W - 16, 9, "وفّر " + money(D.save) + " دج", 16, { c: "#047857" });
    }
    /* الأسعار الإضافية */
    const ex = D.extra, ey = 179, eh = 17, gap = 4, ew = ex.length ? (W - 16 - gap * (ex.length - 1)) / ex.length : 0;
    ex.forEach((e, i) => {
      const x = W - 8 - (i + 1) * ew - i * gap;
      h += box(x, ey, ew, eh, "border-radius:4mm;background:#111;");
      h += T(x + 2, ey + 1, ew - 4, 6.5, e.t + (e.pct ? "  ⁦−" + e.pct + "%⁩" : ""), 12, { c: "#ffd60a" });
      h += T(x + 2, ey + 7, ew - 4, 9, money(e.v) + " دج", 22, { ff: NUMF, c: "#fff" });
    });
    /* التذييل */
    h += box(0, H - 10, W, 10, "background:#e10600");
    h += T(W - 90, H - 9.2, 84, 8.4, "🛒 " + String(co["Company Name"] || "ANOUER"), 12, { al: "r", c: "#fff" });
    h += T(6, H - 9.2, 50, 8.4, today(), 11, { al: "l", c: "#ffe1e1", ff: "'Segoe UI',Arial,sans-serif", b: 0 });
    return wrap(h);
  }

  /* ---------- التصميم 2: «سوبرماركت» — أصفر ---------- */
  function s2(D, co) {
    let h = box(0, 0, W, H, "background:#ffd60a");
    h += box(0, 0, W, H, "background:radial-gradient(circle at 80% 18%,rgba(255,255,255,.45),transparent 45%)");
    /* الشريط العلوي */
    h += box(0, 0, W, 30, "background:#111");
    h += logo(co, W - 25, 5, 20);
    h += T(10, 4, W - 40, 22, D.pct ? "تخفيض" : "سعر الأسبوع", 44, { c: "#ffd60a", al: "r" });
    /* بطاقة الاسم */
    h += box(14, 38, W - 22, 40, "background:#fff;border-radius:6mm;box-shadow:0 1.5mm 0 #111");
    h += T(40, 41, W - 52, 26, D.name, 30);
    if (D.unit) h += T(40, 67, W - 52, 9, "سعر ال" + D.unit.replace(/^ال/, ""), 14, { c: "#e10600" });
    /* ملصق دائري مائل فوق ركن البطاقة */
    h += `<div style="position:absolute;left:4mm;top:28mm;width:36mm;height:36mm;border-radius:50%;background:radial-gradient(circle at 35% 30%,#ff5a4f,#e10600 60%,#a30000);border:1.2mm solid #fff;box-shadow:0 1.5mm 3mm rgba(0,0,0,.3);transform:rotate(-12deg)"></div>`;
    h += `<div style="position:absolute;left:4mm;top:28mm;width:36mm;height:36mm;transform:rotate(-12deg);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;line-height:1">${D.pct ? `<span style="font-family:${NUMF};font-weight:900;font-size:24pt">−${D.pct}%</span><span style="font-family:${ARF};font-weight:800;font-size:11pt;margin-top:1mm">تخفيض</span>` : `<span style="font-family:${NUMF};font-weight:900;font-size:15pt;letter-spacing:.4mm">PROMO</span><span style="font-family:${ARF};font-weight:800;font-size:11pt;margin-top:1mm">عرض</span>`}</div>`;
    /* السعر */
    h += PRICE(6, 84, W - 12, D.old ? 64 : 86, D.now, "#111", { max: 180, cur: "#e10600" });
    if (D.old) {
      h += box(24, 150, W - 48, 14, "background:#fff;border-radius:7mm;border:.8mm solid #111");
      h += T(W / 2 + 2, 151.5, W / 2 - 28, 11, "السعر القديم", 14, { al: "r" });
      h += strike(30, 151.5, W / 2 - 34, 11, money(D.old), 22, "#111", "#e10600");
      h += T(10, 166, W - 20, 9, "وفّر " + money(D.save) + " دج", 17, { c: "#b10000" });
    }
    const ex = D.extra, ey = 177, eh = 16, gap = 4, ew = ex.length ? (W - 20 - gap * (ex.length - 1)) / ex.length : 0;
    ex.forEach((e, i) => {
      const x = W - 10 - (i + 1) * ew - i * gap;
      h += box(x, ey, ew, eh, "border-radius:3mm;background:#fff;border:.7mm solid #111");
      h += T(x + 2, ey + .8, ew - 4, 6, e.t + (e.pct ? "  ⁦−" + e.pct + "%⁩" : ""), 11.5, { c: "#e10600" });
      h += T(x + 2, ey + 6.6, ew - 4, 8.6, money(e.v) + " دج", 21, { ff: NUMF });
    });
    h += box(0, H - 11, W, 11, "background:#111");
    h += T(W - 90, H - 10, 84, 9, String(co["Company Name"] || "ANOUER"), 13, { al: "r", c: "#ffd60a" });
    h += T(6, H - 10, 50, 9, today(), 11, { al: "l", c: "#fff", ff: "'Segoe UI',Arial,sans-serif", b: 0 });
    return wrap(h);
  }

  /* ---------- التصميم 3: «عرض الأسبوع» — مودرن 2026 ---------- */
  function s3(D, co) {
    let h = box(0, 0, W, H, "background:linear-gradient(180deg,#f8f7ff,#ffffff 40%,#fdf4ff)");
    h += box(0, 0, W, 50, "background:linear-gradient(120deg,#4f46e5 0%,#7c3aed 45%,#db2777 100%);border-radius:0 0 12mm 12mm");
    h += `<svg style="position:absolute;left:0;top:0;width:${W}mm;height:50mm" viewBox="0 0 148 50" preserveAspectRatio="none"><circle cx="18" cy="6" r="22" fill="rgba(255,255,255,.10)"/><circle cx="132" cy="44" r="18" fill="rgba(255,255,255,.08)"/><circle cx="96" cy="-4" r="12" fill="rgba(255,255,255,.12)"/></svg>`;
    h += logo(co, W - 24, 5, 18);
    h += T(8, 5, W - 36, 8, String(co["Company Name"] || "ANOUER"), 12, { al: "r", c: "#e9e5ff", b: 0 });
    h += T(8, 14, W - 16, 20, "عرض الأسبوع ✦", 46, { c: "#fff" });
    h += T(8, 35, W - 16, 8, "WEEKLY DEAL · 2026", 11, { c: "#f5d0fe", ff: "'Segoe UI',Arial,sans-serif", b: 0, st: "letter-spacing:1.2mm" });
    /* بطاقة زجاجية */
    h += box(8, 56, W - 16, 112, "background:#fff;border-radius:8mm;box-shadow:0 3mm 8mm -2mm rgba(79,70,229,.28);border:.5mm solid #ede9fe");
    if (D.pct) {
      h += box(14, 61, 34, 13, "border-radius:6.5mm;background:linear-gradient(120deg,#db2777,#f43f5e)");
      h += T(15, 62, 32, 11, "−" + D.pct + "%", 22, { ff: NUMF, c: "#fff" });
    } else {
      h += box(14, 61, 40, 13, "border-radius:6.5mm;background:#ede9fe");
      h += T(15, 62, 38, 11, "سعر ممتاز", 15, { c: "#6d28d9" });
    }
    h += T(14, 76, W - 28, 24, D.name, 28);
    if (D.unit) h += T(14, 100, W - 28, 7, "سعر ال" + D.unit.replace(/^ال/, ""), 13, { c: "#7c3aed" });
    h += PRICE(12, D.old ? 106 : 108, W - 24, D.old ? 46 : 56, D.now, "#5b21b6", { max: 150, cur: "#db2777" });
    if (D.old) {
      h += strike(W / 2 + 2, 152, W / 2 - 16, 10, money(D.old) + " دج", 19, "#94a3b8", "#db2777");
      h += box(16, 152.5, W / 2 - 22, 10, "border-radius:5mm;background:#dcfce7");
      h += T(17, 153, W / 2 - 24, 9, "وفّر " + money(D.save) + " دج", 13.5, { c: "#047857" });
    }
    const ex = D.extra, ey = 174, eh = 20, gap = 4, ew = ex.length ? (W - 16 - gap * (ex.length - 1)) / ex.length : 0;
    ex.forEach((e, i) => {
      const x = W - 8 - (i + 1) * ew - i * gap;
      h += box(x, ey, ew, eh, `border-radius:5mm;background:${i ? "#fdf2f8" : "#eef2ff"};border:.5mm solid ${i ? "#fbcfe8" : "#c7d2fe"}`);
      h += T(x + 2, ey + 1.6, ew - 4, 6.5, e.t + (e.pct ? "  ⁦−" + e.pct + "%⁩" : ""), 12, { c: i ? "#be185d" : "#4338ca" });
      h += T(x + 2, ey + 8.4, ew - 4, 10, money(e.v) + " دج", 22, { ff: NUMF, c: "#1e1b4b" });
    });
    h += T(8, H - 11, W - 16, 8, String(co["Company Name"] || "ANOUER") + "  ·  " + today(), 11, { c: "#7c3aed", b: 0 });
    return wrap(h);
  }

  /* الأسعار الإضافية (مشتركة للتصاميم 4-6) */
  function extras(D, ey, eh, x0, x1, st) {
    let h = ""; const ex = D.extra, gap = 4, ew = ex.length ? (x1 - x0 - gap * (ex.length - 1)) / ex.length : 0;
    ex.forEach((e, i) => {
      const x = x1 - (i + 1) * ew - i * gap;
      h += box(x, ey, ew, eh, st.bg(i));
      h += T(x + 2, ey + eh * .08, ew - 4, eh * .38, e.t + (e.pct ? "  ⁦−" + e.pct + "%⁩" : ""), 12, { c: st.t(i) });
      h += T(x + 2, ey + eh * .44, ew - 4, eh * .5, money(e.v) + " دج", 22, { ff: NUMF, c: st.v(i) });
    });
    return h;
  }
  const leaf = (x, y, s, rot, col) => `<svg style="position:absolute;left:${r1(x)}mm;top:${r1(y)}mm;width:${r1(s)}mm;height:${r1(s)}mm;transform:rotate(${rot}deg)" viewBox="0 0 40 40"><path d="M4 36C4 16 16 4 36 4c0 20-12 32-32 32z" fill="${col}"/><path d="M6 34L30 10" stroke="rgba(255,255,255,.55)" stroke-width="1.6" stroke-linecap="round"/></svg>`;

  /* ---------- التصميم 4: «طازج» — أخضر ---------- */
  function s4(D, co) {
    let h = box(0, 0, W, H, "background:linear-gradient(180deg,#fbf6ea,#f4ecd6)");
    h += box(0, 0, W, 54, "background:linear-gradient(150deg,#22c55e,#15803d 70%,#14532d);border-radius:0 0 50% 50% / 0 0 14mm 14mm");
    h += leaf(4, 4, 18, -10, "rgba(255,255,255,.18)") + leaf(116, 30, 22, 160, "rgba(255,255,255,.14)");
    h += logo(co, W - 25, 5, 19);
    h += T(8, 6, W - 36, 8, String(co["Company Name"] || "ANOUER"), 12, { al: "r", c: "#dcfce7", b: 0 });
    h += T(8, 15, W - 16, 22, D.pct ? "عرض طازج" : "منتوج اليوم", 48, { c: "#fff" });
    h += T(8, 37, W - 16, 8, "FRESH · BIO · 2026", 11, { c: "#bbf7d0", ff: "'Segoe UI',Arial,sans-serif", b: 0, st: "letter-spacing:1.4mm" });
    /* ختم دائري */
    h += `<div style="position:absolute;left:6mm;top:44mm;width:34mm;height:34mm;border-radius:50%;background:#fbf6ea;border:1.2mm dashed #15803d;box-shadow:0 0 0 1.4mm #fbf6ea,0 0 0 2.2mm #15803d;display:flex;flex-direction:column;align-items:center;justify-content:center;transform:rotate(-10deg);line-height:1">${D.pct ? `<span style="font-family:${NUMF};font-weight:900;font-size:21pt;color:#b91c1c">−${D.pct}%</span><span style="font-family:${ARF};font-weight:800;font-size:10pt;color:#15803d;margin-top:1mm">تخفيض</span>` : `<span style="font-size:20pt">🌿</span><span style="font-family:${ARF};font-weight:800;font-size:11pt;color:#15803d;margin-top:1mm">جودة</span>`}</div>`;
    h += T(44, 58, W - 52, 24, D.name, 30, { al: "r", c: "#14532d" });
    if (D.unit) h += T(W - 60, 82, 52, 8, "سعر ال" + D.unit.replace(/^ال/, ""), 14, { al: "r", c: "#15803d" });
    h += box(10, 92, W - 20, D.old ? 61 : 76, "background:#fff;border-radius:9mm;border:.8mm solid #bbf7d0;box-shadow:0 2mm 0 #15803d");
    h += PRICE(12, 94, W - 24, D.old ? 56 : 70, D.now, "#15803d", { max: 165, cur: "#b45309" });
    if (D.old) {
      h += T(W / 2 + 1, 158.5, 36, 9, "بدلاً من", 15, { al: "l", c: "#78716c" });
      h += strike(W / 2 - 47, 157.5, 46, 11, money(D.old) + " دج", 21, "#78716c", "#b91c1c");
      h += T(8, 168.5, W - 16, 8, "وفّر " + money(D.save) + " دج", 15, { c: "#b91c1c" });
    }
    h += extras(D, 179, 17, 8, W - 8, { bg: i => `border-radius:4mm;background:${i ? "#fff7ed" : "#dcfce7"};border:.6mm solid ${i ? "#fdba74" : "#86efac"}`, t: i => i ? "#c2410c" : "#15803d", v: () => "#14532d" });
    h += box(0, H - 10, W, 10, "background:#15803d");
    h += T(W - 90, H - 9.3, 84, 8.6, "🌿 " + String(co["Company Name"] || "ANOUER"), 12, { al: "r", c: "#fff" });
    h += T(6, H - 9.3, 50, 8.6, today(), 11, { al: "l", c: "#dcfce7", ff: "'Segoe UI',Arial,sans-serif", b: 0 });
    return wrap(h);
  }

  /* ---------- التصميم 5: «عرض حصري» — أسود و ذهبي ---------- */
  function s5(D, co) {
    const G = "#e8c46a", G2 = "#b8892b";
    let h = box(0, 0, W, H, "background:radial-gradient(circle at 50% 30%,#2a2a2e,#0b0b0d 70%)");
    h += box(5, 5, W - 10, H - 10, `border:.5mm solid ${G};border-radius:3mm`);
    h += box(7, 7, W - 14, H - 14, `border:.25mm solid rgba(232,196,106,.45);border-radius:2.4mm`);
    h += logo(co, W / 2 - 9, 11, 18);
    h += T(10, 30, W - 20, 7, String(co["Company Name"] || "ANOUER").toUpperCase(), 11, { c: G, ff: "'Segoe UI',Arial,sans-serif", b: 0, st: "letter-spacing:1.8mm" });
    h += T(10, 38, W - 20, 18, "عرض حصري", 40, { c: "#fff" });
    h += `<div style="position:absolute;left:30mm;right:30mm;top:58mm;height:.5mm;background:linear-gradient(90deg,transparent,${G},transparent)"></div><div style="position:absolute;left:${r1(W / 2 - 1.6)}mm;top:${r1(56.6)}mm;width:3.2mm;height:3.2mm;background:${G};transform:rotate(45deg)"></div>`;
    h += T(12, 63, W - 24, 24, D.name, 28, { c: "#fafafa" });
    if (D.unit) h += T(12, 87, W - 24, 7, "سعر ال" + D.unit.replace(/^ال/, ""), 13, { c: G });
    h += PRICE(10, 96, W - 20, D.old ? 56 : 68, D.now, G, { max: 165, cur: "#fff", st: `text-shadow:0 .6mm 0 ${G2}` });
    if (D.old) {
      h += strike(W / 2 - 24, 155, 48, 10, money(D.old) + " دج", 20, "#9ca3af", G);
      if (D.pct) { h += box(W / 2 - 22, 166, 44, 10, `border-radius:5mm;background:linear-gradient(90deg,${G2},${G});`); h += T(W / 2 - 21, 166.5, 42, 9, "وفّر \u2066" + D.pct + "%\u2069", 15, { c: "#111" }); }
    }
    h += extras(D, 178.5, 17, 12, W - 12, { bg: () => `border-radius:3mm;background:rgba(255,255,255,.04);border:.4mm solid ${G}`, t: () => G, v: () => "#fff" });
    h += T(10, H - 13, W - 20, 5.5, today(), 9, { c: "#9ca3af", ff: "'Segoe UI',Arial,sans-serif", b: 0, st: "letter-spacing:.6mm" });
    return wrap(h);
  }

  /* ---------- التصميم 6: «عرض محدود ⚡» — برتقالي ---------- */
  function s6(D, co) {
    let h = box(0, 0, W, H, "background:#fff");
    h += box(0, 0, W, 92, "background:linear-gradient(135deg,#ff8a00 0%,#ff5e00 55%,#f43f5e 100%);clip-path:polygon(0 0,100% 0,100% 72%,0 100%)");
    h += `<svg style="position:absolute;left:0;top:0;width:${W}mm;height:92mm" viewBox="0 0 148 92" preserveAspectRatio="none"><path d="M0 0L148 0 148 66 0 92Z" fill="none"/><g fill="rgba(255,255,255,.12)"><circle cx="20" cy="70" r="30"/><circle cx="140" cy="10" r="22"/></g></svg>`;
    h += logo(co, W - 25, 5, 19);
    h += T(8, 6, W - 36, 8, String(co["Company Name"] || "ANOUER"), 12, { al: "r", c: "#fff7ed", b: 0 });
    /* البرق */
    h += `<svg style="position:absolute;left:8mm;top:8mm;width:24mm;height:30mm" viewBox="0 0 24 30"><path d="M14 0L2 17h8l-3 13L22 11h-9z" fill="#ffe14d" stroke="#7c2d12" stroke-width=".8" stroke-linejoin="round"/></svg>`;
    h += T(30, 12, W - 58, 22, "عرض محدود", 44, { c: "#fff", st: "text-shadow:0 .8mm 0 rgba(124,45,18,.35)" });
    h += box(36, 36, W - 72, 9, "border-radius:4.5mm;background:rgba(0,0,0,.22)");
    h += T(37, 36.4, W - 74, 8.2, "⏱ حتى نفاد الكمية", 13, { c: "#fff" });
    /* بطاقة السعر بشكل «تيكت» مع ثقب */
    h += `<div style="position:absolute;left:12mm;top:58mm;width:${W - 24}mm;height:${D.old ? 104 : 112}mm;background:#fff;border-radius:7mm;box-shadow:0 3mm 8mm -2mm rgba(244,63,94,.35);border:.6mm solid #fed7aa"></div>`;
    h += `<div style="position:absolute;left:${r1(W / 2 - 3.5)}mm;top:62mm;width:7mm;height:7mm;border-radius:50%;background:#fff7ed;border:.6mm solid #fdba74"></div>`;
    if (D.pct) { h += box(W - 50, 52, 38, 14, "border-radius:7mm;background:#111;transform:rotate(6deg)"); h += `<div style="position:absolute;left:${W - 50}mm;top:52mm;width:38mm;height:14mm;transform:rotate(6deg);display:flex;align-items:center;justify-content:center;font-family:${NUMF};font-weight:900;font-size:20pt;color:#ffe14d">−${D.pct}%</div>`; }
    h += T(18, 72, W - 36, 22, D.name, 28, { c: "#1c1917" });
    if (D.unit) h += T(18, 94, W - 36, 7, "سعر ال" + D.unit.replace(/^ال/, ""), 13, { c: "#ea580c" });
    h += PRICE(14, 101, W - 28, D.old ? 50 : 62, D.now, "#ea580c", { max: 160, cur: "#f43f5e" });
    if (D.old) {
      h += strike(W / 2 + 2, 151, W / 2 - 18, 10, money(D.old) + " دج", 19, "#a8a29e", "#f43f5e");
      h += box(18, 151.5, W / 2 - 24, 9.5, "border-radius:4.75mm;background:#fff1f2");
      h += T(19, 152, W / 2 - 26, 8.5, "وفّر " + money(D.save) + " دج", 13.5, { c: "#e11d48" });
    }
    h += extras(D, 176, 18, 12, W - 12, { bg: i => `border-radius:4mm;background:${i ? "#1c1917" : "#fff7ed"};border:.6mm solid ${i ? "#1c1917" : "#fdba74"}`, t: i => i ? "#fdba74" : "#c2410c", v: i => i ? "#fff" : "#1c1917" });
    h += T(8, H - 11, W - 16, 8, String(co["Company Name"] || "ANOUER") + "  ·  " + today(), 11, { c: "#ea580c", b: 0 });
    return wrap(h);
  }

  /* ---------- بيانات «خصم 5 ومافوق»: سعر الحبة + شرائح الكمية ----------
     الشريحة الأولى: «سعر 5 ومافوق» للصنف ، وإلا «خصم الكمية» ، وإلا السعر المكتوب في السطر (أقل من سعر البيع) = سعر 5 ومافوق */
  function qdata(j) {
    const I = (A() && A().info) ? A().info(j) : { name: j.name || "", single: 1, price: +j.price || 0, p5: 0, qd: [] };
    const unit = I.single ? (I.unit || "") : I.piece, base = +(I.single ? I.price : I.pp) || 0;
    let T0 = [];
    if (I.single && I.p5 > 0 && I.p5 < base - .004) T0.push({ from: 5, price: +I.p5 });
    (I.qd || []).filter(q => !q.promo && q.from > 1).forEach(q => T0.push({ from: q.from, price: q.price }));
    const jp = +j.price || 0;
    if (!T0.length && jp > 0 && jp < base - .004) T0.push({ from: 5, price: jp });
    if (!I.single && I.inP > 0 && I.inP < base - .004 && I.n > 1) T0.push({ from: Math.round(I.n), price: I.inP, big: I.big });
    const seen = {}; let lo = base; T0 = T0.filter(t => !seen[t.from] && (seen[t.from] = 1)).sort((a, b) => a.from - b.from).filter(t => t.price < lo - .004 && (lo = t.price, 1)).slice(0, 3);   /* سلّم نازل فقط */
    const q = T0[0] || null;
    return { name: String(I.name || j.name || "").trim() || "—", unit, base, tiers: T0, q, save: q ? base - q.price : 0, pct: q && base > 0 ? Math.round((1 - q.price / base) * 100) : 0 };
  }
  const cubes = (x, y, s, n, col, col2) => { let h = ""; const pos = [[0, 2], [1, 2], [2, 2], [.5, 1], [1.5, 1], [1, 0]].slice(0, n); pos.forEach(([a, b]) => { h += `<div style="position:absolute;left:${r1(x + a * s)}mm;top:${r1(y + b * s * .86)}mm;width:${r1(s * .92)}mm;height:${r1(s * .8)}mm;border-radius:${r1(s * .16)}mm;background:linear-gradient(160deg,${col},${col2});box-shadow:inset 0 -.8mm 0 rgba(0,0,0,.18)"></div>`; }); return h; };
  const qLab = t => t.big ? "داخل " + t.big : t.from + " ومافوق";

  /* ---------- التصميم 7: «اشري أكثر… وفّر أكثر» — مقارنة زرقاء ---------- */
  function s7(_, co, j) {
    const D = qdata(j); let h = box(0, 0, W, H, "background:linear-gradient(180deg,#eff6ff,#ffffff 45%)");
    h += box(0, 0, W, 50, "background:linear-gradient(135deg,#0ea5e9,#2563eb 60%,#1e3a8a);border-radius:0 0 10mm 10mm");
    h += logo(co, W - 25, 5, 19);
    h += T(8, 6, W - 36, 8, String(co["Company Name"] || "ANOUER"), 12, { al: "r", c: "#dbeafe", b: 0 });
    h += T(34, 15, W - 62, 18, "اشري أكثر… وفّر أكثر", 32, { c: "#fff" });
    h += T(34, 34, W - 62, 9, "خصم الكمية · 5 ومافوق", 15, { c: "#bae6fd" });
    h += cubes(7, 12, 7.4, 6, "#7dd3fc", "#0284c7");
    h += T(10, 54, W - 20, 22, D.name, 28, { c: "#0f172a" });
    /* بطاقة الحبة الواحدة (يمين) */
    const cy = 80, chh = 74, gw = 4, rw = 46, lw = W - 16 - rw - gw;
    h += box(W - 8 - rw, cy + 10, rw, chh - 10, "border-radius:6mm;background:#fff;border:.6mm solid #cbd5e1");
    h += T(W - 8 - rw + 2, cy + 13, rw - 4, 8, "حبة واحدة", 14, { c: "#64748b" });
    h += T(W - 8 - rw + 2, cy + 23, rw - 4, 9, "1 → 4", 14, { ff: NUMF, c: "#94a3b8" });
    h += T(W - 8 - rw + 2, cy + 36, rw - 4, 18, money(D.base), 30, { ff: NUMF, c: "#334155" });
    h += T(W - 8 - rw + 2, cy + 55, rw - 4, 7, "دج", 13, { c: "#64748b" });
    /* بطاقة 5 ومافوق (يسار — مميزة) */
    h += box(8, cy, lw, chh, "border-radius:7mm;background:linear-gradient(160deg,#2563eb,#1e40af);box-shadow:0 3mm 8mm -2mm rgba(37,99,235,.55)");
    if (D.q) {
      h += box(8 + lw / 2 - 20, cy - 5, 40, 11, "border-radius:5.5mm;background:#facc15;box-shadow:0 1mm 0 #a16207");
      h += T(8 + lw / 2 - 19, cy - 4.4, 38, 10, qLab(D.q), 15, { c: "#422006" });
      h += PRICE(10, cy + 9, lw - 4, 44, D.q.price, "#fff", { max: 120, cur: "#fde68a" });
      h += T(10, cy + 55, lw - 4, 8, "سعر الحبة", 13, { c: "#bfdbfe" });
      h += T(10, cy + 63, lw - 4, 8, "وفّر " + money(D.save) + " دج على كل حبة", 12, { c: "#fde68a" });
    } else h += T(12, cy + 25, lw - 8, 24, "اسأل عن\nسعر الجملة", 22, { c: "#fff" });
    /* مثال المجموع */
    if (D.q) {
      const n = Math.max(5, D.q.from), tot = D.q.price * n, ref = D.base * n;
      h += box(8, 160, W - 16, 18, "border-radius:5mm;background:#eff6ff;border:.5mm dashed #93c5fd");
      h += T(10, 161, W - 20, 8, n + " حبات بـ " + money(tot) + " دج", 17, { c: "#1e3a8a" });
      h += T(10, 169, W - 20, 7.5, "بدل " + money(ref) + " دج — تربح " + money(ref - tot) + " دج", 12.5, { c: "#047857" });
    }
    if (D.tiers[1]) { const t = D.tiers[1]; h += box(8, 181, W - 16, 13, "border-radius:4mm;background:#0f172a"); h += T(10, 181.5, W - 20, 12, qLab(t) + "  ←  " + money(t.price) + " دج", 17, { c: "#fde68a" }); }
    h += box(0, H - 10, W, 10, "background:#1e3a8a");
    h += T(W - 90, H - 9.3, 84, 8.6, String(co["Company Name"] || "ANOUER"), 12, { al: "r", c: "#fff" });
    h += T(6, H - 9.3, 50, 8.6, today(), 11, { al: "l", c: "#bfdbfe", ff: "'Segoe UI',Arial,sans-serif", b: 0 });
    return wrap(h);
  }

  /* ---------- التصميم 8: «سلّم الأسعار» — كل ما تشري أكثر السعر ينقص ---------- */
  function s8(_, co, j) {
    const D = qdata(j); let h = box(0, 0, W, H, "background:#fff");
    h += box(0, 0, W, 64, "background:linear-gradient(140deg,#f43f5e,#e11d48 50%,#9f1239)");
    h += `<svg style="position:absolute;left:0;top:0;width:${W}mm;height:64mm" viewBox="0 0 148 64" preserveAspectRatio="none"><g fill="rgba(255,255,255,.08)"><rect x="96" y="40" width="14" height="24"/><rect x="112" y="28" width="14" height="36"/><rect x="128" y="14" width="14" height="50"/></g></svg>`;
    h += logo(co, W - 25, 5, 19);
    /* شارة «5+» الكبيرة */
    h += `<div style="position:absolute;left:7mm;top:7mm;width:42mm;height:42mm;border-radius:50%;background:#fff;box-shadow:0 2mm 5mm rgba(0,0,0,.25);display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:.95"><span style="font-family:${NUMF};font-weight:900;font-size:40pt;color:#e11d48">${D.q ? (D.q.big ? Math.round(D.q.from) : D.q.from) : 5}+</span><span style="font-family:${ARF};font-weight:800;font-size:11pt;color:#9f1239;margin-top:1mm">ومافوق</span></div>`;
    h += T(52, 9, W - 80, 8, String(co["Company Name"] || "ANOUER"), 12, { al: "r", c: "#ffe4e6", b: 0 });
    h += T(52, 19, W - 58, 16, "خصم الكمية", 34, { al: "r", c: "#fff" });
    h += T(52, 36, W - 58, 9, "كل ما تشري أكثر… السعر ينقص", 14, { al: "r", c: "#fecdd3" });
    h += T(10, 68, W - 20, 22, D.name, 28, { c: "#0f172a" });
    if (D.unit) h += T(10, 89, W - 20, 7, "السعر لل" + D.unit.replace(/^ال/, ""), 13, { c: "#e11d48" });
    /* السلّم */
    const L = [{ from: 1, price: D.base, one: 1 }].concat(D.tiers), n = L.length, y0 = 98, stepH = n > 3 ? 19 : n > 2 ? 24 : 30, gap = 3;
    L.forEach((t, i) => {
      const y = y0 + i * (stepH + gap), wdt = (W - 20) * (0.7 + 0.3 * i / Math.max(1, n - 1)), x = W - 10 - wdt, best = i === n - 1 && n > 1;
      h += box(x, y, wdt, stepH, `border-radius:4mm;background:${best ? "linear-gradient(90deg,#e11d48,#f43f5e)" : i ? "#ffe4e6" : "#f1f5f9"};${best ? "box-shadow:0 2mm 4mm -1mm rgba(225,29,72,.5)" : ""}`);
      h += T(W - 10 - 42, y, 40, stepH, t.one ? "حبة واحدة" : qLab(t), best ? 17 : 15, { al: "r", c: best ? "#fff" : i ? "#9f1239" : "#475569" });
      h += T(x + 3, y + 1, wdt - 48, stepH - 2, money(t.price) + " دج", best ? 34 : 24, { al: "l", ff: NUMF, c: best ? "#fff" : i ? "#e11d48" : "#334155" });
      if (!t.one && D.base > 0) { const pc = Math.round((1 - t.price / D.base) * 100); if (pc >= 1) h += T(x + wdt - 66, y + 1, 20, stepH - 2, "−" + pc + "%", 13, { ff: NUMF, c: best ? "#fde68a" : "#be123c" }); }
    });
    if (!D.q) h += T(10, y0 + stepH + 8, W - 20, 12, "اكتب سعر 5 ومافوق في خانة «السعر»", 13, { c: "#94a3b8" });
    else if (n <= 3) {   /* مثال المجموع تحت السلّم */
      const t = L[n - 1], k = t.big ? Math.round(t.from) : Math.max(5, t.from), tot = t.price * k, ey = y0 + n * (stepH + gap) + 3;
      h += box(10, ey, W - 20, 19, "border-radius:5mm;background:#fff1f2;border:.5mm dashed #fda4af");
      h += T(12, ey + 1, W - 24, 9, k + " × " + money(t.price) + " = " + money(tot) + " دج", 18, { ff: NUMF, c: "#9f1239" });
      h += T(12, ey + 10, W - 24, 8, "بدل " + money(D.base * k) + " دج — تربح " + money(D.base * k - tot) + " دج", 12.5, { c: "#047857" });
    }
    h += box(0, H - 10, W, 10, "background:#9f1239");
    h += T(W - 90, H - 9.3, 84, 8.6, String(co["Company Name"] || "ANOUER"), 12, { al: "r", c: "#fff" });
    h += T(6, H - 9.3, 50, 8.6, today(), 11, { al: "l", c: "#fecdd3", ff: "'Segoe UI',Arial,sans-serif", b: 0 });
    return wrap(h);
  }

  /* ---------- التصميم 9: «×5» مودرن — فيروزي و أسود ---------- */
  function s9(_, co, j) {
    const D = qdata(j), n = D.q ? (D.q.big ? Math.round(D.q.from) : D.q.from) : 5;
    let h = box(0, 0, W, H, "background:#0f172a");
    h += box(0, 0, W, H, "background:radial-gradient(circle at 85% 8%,rgba(45,212,191,.35),transparent 40%),radial-gradient(circle at 10% 95%,rgba(56,189,248,.25),transparent 45%)");
    h += logo(co, W - 25, 6, 19);
    h += T(8, 7, W - 36, 8, String(co["Company Name"] || "ANOUER"), 12, { al: "r", c: "#99f6e4", b: 0 });
    /* «×5» ضخمة مفرّغة */
    h += `<div style="position:absolute;left:6mm;top:6mm;font-family:${NUMF};font-weight:900;font-size:92pt;line-height:1;color:transparent;-webkit-text-stroke:.7mm #2dd4bf;opacity:.9">×${n}</div>`;
    h += T(8, 46, W - 16, 10, "خصم " + n + " ومافوق", 20, { c: "#2dd4bf" });
    h += T(8, 58, W - 16, 22, D.name, 28, { c: "#fff" });
    /* بطاقة السعر */
    h += box(10, 84, W - 20, 82, "border-radius:9mm;background:linear-gradient(160deg,#14b8a6,#0e7490);box-shadow:0 3mm 10mm -2mm rgba(20,184,166,.6)");
    if (D.q) {
      h += box(W / 2 - 26, 89, 52, 10, "border-radius:5mm;background:rgba(15,23,42,.35)");
      h += T(W / 2 - 25, 89.4, 50, 9, "سعر ال" + (D.unit || "حبة").replace(/^ال/, "") + " · " + qLab(D.q), 12.5, { c: "#ccfbf1" });
      h += PRICE(12, 100, W - 24, 46, D.q.price, "#fff", { max: 150, cur: "#ccfbf1" });
      h += box(W / 2 + 2, 149, W / 2 - 18, 11, "border-radius:5.5mm;background:rgba(255,255,255,.16)");
      h += T(W / 2 + 3, 149.5, W / 2 - 20, 10, "الحبة وحدها " + money(D.base), 12, { c: "#e0f2fe" });
      h += box(16, 149, W / 2 - 22, 11, "border-radius:5.5mm;background:#facc15");
      h += T(17, 149.5, W / 2 - 24, 10, "وفّر ⁦" + D.pct + "%⁩", 15, { c: "#422006" });
    } else {
      h += PRICE(12, 96, W - 24, 52, D.base, "#fff", { max: 150, cur: "#ccfbf1" });
      h += T(12, 150, W - 24, 10, "اكتب سعر " + n + " ومافوق في خانة «السعر»", 12, { c: "#ccfbf1" });
    }
    if (D.q) {
      const tot = D.q.price * n;
      h += box(10, 171, W - 20, 22, "border-radius:6mm;background:rgba(255,255,255,.06);border:.4mm solid rgba(45,212,191,.5)");
      h += T(14, 172, W - 28, 10, n + " × " + money(D.q.price) + " = " + money(tot) + " دج", 19, { ff: NUMF, c: "#fff" });
      h += T(14, 182, W - 28, 9, "بدل " + money(D.base * n) + " دج", 13, { c: "#5eead4" });
    }
    h += T(8, H - 11, W - 16, 8, today(), 10, { c: "#64748b", ff: "'Segoe UI',Arial,sans-serif", b: 0, st: "letter-spacing:.6mm" });
    return wrap(h);
  }
  const DRAW = { "offa5:1": s1, "offa5:2": s2, "offa5:3": s3, "offa5:4": s4, "offa5:5": s5, "offa5:6": s6, "offa5:7": s7, "offa5:8": s8, "offa5:9": s9 };

  /* ---------- الطباعة ---------- */
  async function company() { try { return RD() && RD().company ? (await RD().company()) || {} : {}; } catch (e) { return {}; } }
  function uniq(js) {
    const seen = new Set(), out = [];
    (js || []).forEach(j => { const k = String(j.code) + "|" + (j.unit || "") + "|" + (+j.price || 0); if (seen.has(k)) return; seen.add(k); out.push(Object.assign({}, j, { n: B().mode === "item" ? Math.max(1, j.n || 1) : 1 })); });
    return out;
  }
  async function res(js, key) {
    const co = await company(), fn = DRAW[key] || s1, pages = [];
    uniq(js).forEach(j => { const h = fn(data(j), co, j); for (let i = 0; i < j.n; i++) pages.push({ w: W, h: H, html: h }); });
    return { pages, w: W, h: H, roll: false };
  }
  /* الورقة الموضوعة في الطابعة للتيكتات: A5 (نص A4) افتراضياً — localStorage «bco.paper» = A5 / A4 */
  const PAPER = () => { try { const v = String(localStorage.getItem("bco.paper") || "A5").toUpperCase(); return /^A[456]$/.test(v) ? v : "A5"; } catch (e) { return "A5"; } };
  let LAST = null;
  const HOSTP = () => !!(window.Anouer && Anouer.available && Anouer.call && RD() && RD().hostPrintDialog);
  async function hostPrint(R0, key) {
    const n = R0.pages.length, st = STYLES.find(s => s.k === key) || STYLES[0];
    /* fit + paper: نطبع على ورقة A5 الحقيقية (ماشي الورقة المسجّلة في الطابعة) والتيكت يملأ منطقتها القابلة للطباعة في الوسط */
    if (HOSTP()) { const r = await RD().hostPrintDialog(R0, { title: "تيكت العروض A5 — " + n, fit: true, paper: PAPER() }); return r && r.ok ? n : 0; }
    if (RD() && RD().printResult) { await RD().printResult(R0, { title: st.name, fit: true, paper: PAPER() }); return n; }
    return 0;
  }
  async function print(js, preview, key) {
    const R0 = await res(js, key); if (!R0.pages.length) return 0;
    if (preview) {
      const doc = `<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>A5</title><style>@page{size:${W}mm ${H}mm;margin:0}body{margin:0;background:#8a8f98}.rdp{margin:12px auto;box-shadow:0 6px 20px rgba(0,0,0,.35)}@media print{body{background:#fff}.rdp{margin:0;box-shadow:none;page-break-after:always}}</style></head><body>${R0.pages.map(p => p.html).join("")}</body></html>`;
      const f = document.getElementById("bcpFr"), pv = document.getElementById("bcpPv"); if (f && pv) { f.srcdoc = doc; pv.classList.add("show"); }
      LAST = { R0, key }; return R0.pages.length;
    }
    LAST = null; return hostPrint(R0, key);
  }
  function printLast() { if (!LAST) return null; const x = LAST; LAST = null; return hostPrint(x.R0, x.key); }
  async function one(job, key) { const co = await company(), qk = /^offa5:[789]$/.test(key); const inf = qk ? qdata(job) : data(job); return { html: (DRAW[key] || s1)(data(job), co, job), sz: { w: W, h: H }, info: qk ? { pct: inf.pct, q: inf.q } : inf }; }

  window.__BCO = { STYLES, isKey, print, res, one, data, qdata, printLast, clearLast() { LAST = null; }, get hasLast() { return !!LAST; } };
})();
