/* ANOUER — «القديم + الجديد» في نافذة الدفع (مبيعات)
   عميل عليه دين سابق ← شريط ذكي فوق لوحة الأرقام: الدين السابق + زر «دفع القديم والجديد» (F8).
   ضغطة واحدة: المطلوب = الفاتورة + الدين السابق ، ويُملأ المبلغ كاملاً في الخزينة المختارة ← «موافق».
   عند «موافق»: تُحفظ الفاتورة مدفوعة بالكامل ، ثم يُسجَّل «استلام نقدية» تلقائياً بباقي المبلغ على الدين السابق
   (موزّعاً على أقدم الفواتير المفتوحة) — والزائد عن الاثنين يبقى «باقي» يُرد للعميل. دفع جزئي؟ يُغطّي الفاتورة أولاً ثم الدين.
   2026-11-22: دفع أكثر من الفاتورة بدون تشغيل الزر والعميل عليه دين ← إطار «الباقي على الدين؟» (Enter = خصم من الدين ، 2 = إرجاع نقداً)
   حتى لا يضيع الباقي كـ«مرتجع» والكاشير يحسب أنه نزل من الدين. */
(function () {
  "use strict";
  if (window.__payOld) return; window.__payOld = 1;
  const $ = id => document.getElementById(id);
  const r2 = v => Math.round((+v || 0) * 100) / 100;
  const F = v => { try { return pFmt(v); } catch (e) { return r2(v).toLocaleString("en-US", { maximumFractionDigits: 2 }); } };
  const T = (m, k) => { try { toast(m, k || "i"); } catch (e) { } };
  const isRet = () => !!document.querySelector(".inv.retmode");
  const custName = () => { const e = $("custName"); return e ? e.value.trim() : ""; };
  const isCash = n => !n || /^(تعامل|عميل)?\s*نقد[ىي]$/.test(n);
  const custRec = () => { const n = custName(); if (isCash(n)) return null; return (window.CUSTOMERS_DATA || []).find(c => c.name === n) || null; };
  const debtOf = c => c ? r2(Math.max(0, +c.bal || 0)) : 0;
  const host = () => !!(window.Anouer && Anouer.available);

  const IC = {
    wal: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H18v3"/><rect x="3" y="7.5" width="18" height="12" rx="2.5"/><path d="M16.5 13.5h.01"/><path d="M21 11h-4a2.5 2.5 0 0 0 0 5h4"/></svg>',
    ok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>'
  };

  /* ---------------------------------------------------------------- الشريط */
  let rb = null;
  function ensure() {
    if (rb && rb.isConnected) return rb;
    const sum = document.querySelector("#pay .pay-sum"); if (!sum) return null;
    rb = document.createElement("div"); rb.className = "po-rb"; rb.hidden = true; rb.setAttribute("aria-live", "polite");
    rb.innerHTML = `<span class="po-ic">${IC.wal}</span>
      <div class="po-t"><small class="po-k"></small><b class="po-d"></b><div class="po-bar"><i></i></div></div>
      <button type="button" class="po-btn" title="دفع الفاتورة + الدين السابق معاً (F8)"><span class="po-pi">${IC.plus}</span><span class="po-l"><b class="po-l1"></b><em class="po-l2"></em></span></button>`;
    sum.insertAdjacentElement("afterend", rb);
    rb.querySelector(".po-btn").addEventListener("mousedown", e => e.preventDefault());
    rb.querySelector(".po-btn").addEventListener("click", toggle);
    return rb;
  }
  function paint() {
    const pay = $("pay"); if (!pay || typeof P === "undefined" || !P) return;
    const el = ensure(); if (!el) return;
    const show = !!(P.__oldDebt > 0.004);
    el.hidden = !show; pay.classList.toggle("po-has", show);
    if (!show) return;
    const on = !!P.__oldOn, inv = r2(P.__t0 ? P.__t0.total : P.t.total), debt = P.__oldDebt, paid = r2(payPaid());
    el.classList.toggle("on", on);
    if (!on) {
      el.querySelector(".po-k").innerHTML = `الدين السابق على <b>${esc2(P.__oldName)}</b>`;
      el.querySelector(".po-d").innerHTML = `${F(debt)} <em>DZD</em>`;
      el.querySelector(".po-l1").textContent = "دفع القديم والجديد";
      el.querySelector(".po-l2").textContent = F(r2(inv + debt)) + " DZD · F8";
      el.dataset.st = "off"; el.style.setProperty("--po-p", 0);
      return;
    }
    const oldPaid = Math.min(debt, Math.max(0, r2(paid - inv))), after = r2(debt - oldPaid), pct = debt > 0 ? oldPaid / debt * 100 : 0;
    el.style.setProperty("--po-p", pct.toFixed(1));
    el.dataset.st = after <= 0.004 ? "clear" : oldPaid > 0 ? "part" : "none";
    el.querySelector(".po-k").innerHTML = after <= 0.004 ? `🎉 حساب <b>${esc2(P.__oldName)}</b> يصبح صافياً` : `الفاتورة <b>${F(inv)}</b> + الدين <b>${F(debt)}</b>`;
    el.querySelector(".po-d").innerHTML = after <= 0.004 ? `سداد الدين: ${F(oldPaid)} <em>DZD</em>` : `يبقى من الدين: ${F(after)} <em>DZD</em>`;
    el.querySelector(".po-l1").textContent = "القديم + الجديد ✓";
    el.querySelector(".po-l2").textContent = "اضغط للإلغاء · F8";
  }
  const esc2 = s => String(s || "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);

  /* تشغيل/إيقاف: المطلوب = الفاتورة + الدين ، ويُملأ المبلغ كاملاً (مثل «دفع الكل») */
  function toggle() {
    if (typeof P === "undefined" || !P || !(P.__oldDebt > 0)) return;
    if (!P.__oldOn) {
      P.__t0 = P.t; P.t = Object.assign({}, P.t, { total: r2(P.t.total + P.__oldDebt) }); P.__oldOn = true;
      try { payAll(); } catch (e) { payRender(); }
      try { if (typeof QtySound !== "undefined") QtySound.play(); } catch (e) { }
      const el = ensure(); if (el) { el.classList.remove("po-pop"); void el.offsetWidth; el.classList.add("po-pop"); }
    } else {
      P.t = P.__t0 || P.t; P.__t0 = null; P.__oldOn = false;
      /* المبلغ المملوء كان للاثنين ← نعيده لمبلغ الفاتورة */
      try { payAll(); } catch (e) { payRender(); }
    }
  }

  /* ---------------------------------------------------------------- «استلام نقدية» آلي */
  function saveRecv(o) {
    const A = window.__AC; if (!A) return Promise.reject(new Error("وحدة الحسابات غير محمّلة"));
    const today = new Date().toLocaleString("sv-SE").slice(0, 10);
    return A.parties("cu", true).then(l => {
      const p = (l || []).find(x => o.cid != null && String(x.id) === String(o.cid)) || (l || []).find(x => x.name === o.name);
      if (!p) throw new Error("العميل «" + o.name + "» غير موجود في الحسابات");
      return A.accounts("tr", true).then(trs => {
        const tr = (trs || []).find(t => String(t.id) === String(o.trId)) || (trs || []).find(t => t.name === o.trName) || (trs || [])[0];
        if (!tr) throw new Error("لا توجد خزينة");
        const acc = { type: "tr", id: tr.id, name: tr.name };
        return Promise.resolve(A.dues("cu", p)).catch(() => []).then(ds => {
          let left = r2(o.amt); const alloc = [];
          (ds || []).slice().sort((a, b) => String(a.date || "").localeCompare(String(b.date || ""))).forEach(d => {
            if (left <= 0.004) return; const a = r2(Math.min(left, +d.rem || 0)); if (a <= 0) return;
            alloc.push({ id: d.id, no: d.no, date: d.date, type: d.type, total: d.total, amt: a }); left = r2(left - a);
          });
          return A.nextNo("recv").then(no => {
            const notes = "سداد الدين السابق مع فاتورة المبيعات" + (o.invNo ? " رقم " + o.invNo : "");
            const meta = { party: p.name, notes: "استلام نقدية رقم " + no + " - " + notes, what: A.TITLE.recv };
            const af = A.accFx(acc, o.amt, meta);
            const fx = af.fx.concat([{ t: "cu", id: p.id, d: r2(o.amt) }]);
            alloc.forEach(a => fx.push({ t: "inv", id: a.id, d: a.amt }));
            const data = { date: today, time: A.nowT(), br: "الفرع الرئيسى", side: "cu", pid: p.id, pno: p.no, pname: p.name, amt: r2(o.amt), disc: 0, cur: "DZD", rate: 1,
              acc, notes, ref: o.invNo ? String(o.invNo) : "", st: "", cc: "", dacc: "خصم مسموح به ( مدين )", alloc, fx, lg: af.lg, user: window.__USER_NAME || "ANOUER",
              mod: new Date().toLocaleString("sv-SE").slice(0, 16), modBy: "", auto: "pay-old" };
            return A.post(fx, [], { date: today, no: String(no), notes: meta.notes })
              .then(() => A.saveDoc("recv", { id: 0, no, data }).catch(e => A.post([], fx, { date: today, no: String(no) }).then(() => { throw e; })))
              .then(r => {
                try { A.invalidate(); delete A.PC.cu; delete A.AC.tr; } catch (e) { }
                try { window.dispatchEvent(new CustomEvent("anouer:cash-saved", { detail: { kind: "recv", side: "cu", pid: p.id } })); } catch (e) { }
                return { no: r.no || no, after: r2(o.debt - o.amt), name: p.name, alloc: alloc.length };
              });
          });
        });
      });
    });
  }
  let PEND = null;
  /* وصل الفاتورة يُبنى لحظة الحفظ (قبل تسجيل سداد الدين) ← نخبره بالمبلغ المدفوع على الدين ليطبع الرصيد الصحيح */
  window.__payOldPending = () => PEND ? { name: PEND.name, cid: PEND.cid, amt: +PEND.amt || 0 } : null;
  function runPend(r) {
    const o = PEND; PEND = null; if (!o) return;
    clearTimeout(o.t);
    o.invNo = r && (r.invoiceNo || r.InvoiceNo) || "";
    saveRecv(o).then(x => {
      T(`✔ استلام نقدية رقم ${x.no}: ${F(o.amt)} DZD على الدين السابق` + (x.after <= 0.004 ? " — 🎉 حساب " + x.name + " صافٍ" : " — يبقى " + F(x.after)), "s");
      /* الأرصدة: accounts.js ← post يحدّث CUSTOMERS_DATA ويطلق «anouer:customers» */
    }).catch(e => {
      T("⚠ حُفظت الفاتورة لكن لم يُسجَّل سداد الدين (" + F(o.amt) + "): " + ((e && e.message) || e) + " — سجّله من «استلام نقدية»", "e");
      try { alert("حُفظت الفاتورة، لكن تعذّر تسجيل «استلام نقدية» بمبلغ " + F(o.amt) + " DZD على الدين السابق للعميل " + o.name + ".\n\n" + ((e && e.message) || e) + "\n\nسجّله يدوياً من الحسابات ← استلام نقدية (Ctrl+R)."); } catch (x) { }
    });
  }
  const nrm = s => String(s || "").replace(/\s+/g, " ").trim();
  window.addEventListener("anouer:sale-saved", e => {
    const d = e.detail || {}; if (!PEND) return;
    const cid = d.pay && d.pay.CustomerId;
    if ((cid != null && PEND.cid != null && String(cid) === String(PEND.cid)) || !d.cust || nrm(d.cust) === nrm(PEND.name)) runPend(d.r);
  });


  /* ---------------------------------------------------------------- «الباقي على الدين؟» (دفع زائد + دين سابق) */
  let OVB = false, OV2 = null, KEY2 = null;
  const IC2 = {
    debt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H18v3"/><rect x="3" y="7.5" width="18" height="12" rx="2.5"/><path d="M21 11h-4a2.5 2.5 0 0 0 0 5h4"/><path d="m8 13.5 2 2 3.5-3.5"/></svg>',
    cash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="6" width="19" height="12" rx="2.6"/><circle cx="12" cy="12" r="2.6"/><path d="M6 9.5v5M18 9.5v5"/></svg>',
    back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>',
    spark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M18 6l-2.5 2.5M8.5 15.5 6 18"/></svg>'
  };
  function close2(now) {
    if (!OV2) return; const o = OV2; OV2 = null;
    if (KEY2) { removeEventListener("keydown", KEY2, true); KEY2 = null; }
    if (now) o.remove(); else { o.classList.add("out"); setTimeout(() => o.remove(), 160); }
  }
  function askOver(fn, ctx, args, inv, paid) {
    const pay = $("pay"); if (!pay) { OVB = true; try { return fn.apply(ctx, args); } finally { OVB = false; } }
    close2(true);
    const debt = r2(P.__oldDebt), ch = r2(paid - inv), toDebt = r2(Math.min(ch, debt)), back = r2(ch - toDebt), after = r2(debt - toDebt);
    const pct = debt > 0 ? Math.min(100, toDebt / debt * 100) : 0, RAD = 32, CIR = 2 * Math.PI * RAD;
    const subD = after <= 0.004 ? "🎉 حساب " + P.__oldName + " يصبح صافياً" + (back > 0.004 ? " — ويُرجَع للعميل " + F(back) : "")
                                : "يُسجَّل «استلام نقدية» " + F(toDebt) + " — يبقى من الدين " + F(after);
    OV2 = document.createElement("div"); OV2.className = "pq26-ov po26";
    OV2.innerHTML = `<div class="pq26" role="alertdialog" aria-label="الباقي على الدين">
      <div class="pq26-hd"><button type="button" class="pq26-x" data-a="back" title="رجوع (Esc)">✕</button>
        <div class="pq26-ring"><svg viewBox="0 0 78 78"><defs><linearGradient id="po26G" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#34d399"/><stop offset="1" stop-color="#0d9488"/></linearGradient></defs>
          <circle class="bg" cx="39" cy="39" r="${RAD}" fill="none" stroke-width="8"/><circle class="fg" cx="39" cy="39" r="${RAD}" fill="none" stroke-width="8" stroke-dasharray="${CIR}" stroke-dashoffset="${CIR}"/></svg><b>${Math.round(pct)}%</b></div>
        <div class="pq26-tt"><small><i>${IC2.spark}</i>العميل عليه دين سابق</small><b>الباقي من المدفوع</b><div class="am"><strong>${F(ch)}</strong><span>DZD</span></div></div></div>
      <div class="pq26-nums"><div><small>الفاتورة</small><b>${F(inv)}</b></div><div class="p"><small>المدفوع</small><b>${F(paid)}</b></div><div class="r"><small>الدين السابق</small><b>${F(debt)}</b></div></div>
      <div class="pq26-cu">العميل: <b>${esc2(P.__oldName)}</b><em>بعد الخصم: ${after <= 0.004 ? "صافٍ ✓" : F(after)}</em></div>
      <div class="pq26-ops">
        <button type="button" class="pq26-op pri" data-a="debt"><span class="ic" style="background:linear-gradient(135deg,#10b981,#0f766e)">${IC2.debt}</span><span class="tx"><b>خصم الباقي من الدين (${F(toDebt)})</b><small>${esc2(subD)}</small></span><kbd>1</kbd></button>
        <button type="button" class="pq26-op" data-a="cash"><span class="ic" style="background:linear-gradient(135deg,#64748b,#334155)">${IC2.cash}</span><span class="tx"><b>إرجاع الباقي للعميل نقداً (${F(ch)})</b><small>الدين السابق يبقى ${F(debt)} DZD</small></span><kbd>2</kbd></button>
      </div>
      <div class="pq26-ft"><button type="button" class="bk" data-a="back">${IC2.back}رجوع للوحة الأرقام</button><span>Enter = خصم من الدين · Esc = رجوع</span></div></div>`;
    pay.appendChild(OV2);
    requestAnimationFrame(() => requestAnimationFrame(() => { const fg = OV2 && OV2.querySelector(".fg"); if (fg) fg.style.strokeDashoffset = String(CIR * (1 - pct / 100)); }));
    try { if (window.ANOUER_SOUND) ANOUER_SOUND("warn"); } catch (e) { }
    const act = k => {
      if (k === "back") { close2(); return; }
      close2(true);
      if (k === "debt") {
        if (!(P.__oldDebt > 0) || P.__oldOn) return;
        P.__t0 = P.t; P.t = Object.assign({}, P.t, { total: r2(P.t.total + P.__oldDebt) }); P.__oldOn = true;
        return fn.apply(ctx, args);
      }
      if (k === "cash") { OVB = true; try { return fn.apply(ctx, args); } finally { OVB = false; } }
    };
    OV2.addEventListener("click", e => { const b = e.target.closest("[data-a]"); if (b) act(b.dataset.a); });
    KEY2 = e => {
      if (!OV2) return;
      const k = { Escape: "back", Enter: "debt", "1": "debt", "2": "cash" }[e.key];
      if (k || /^[0-9.]$|^Backspace$|^F\d+$/.test(e.key)) { e.preventDefault(); e.stopImmediatePropagation(); }
      if (k) act(k);
    };
    addEventListener("keydown", KEY2, true);
  }

  /* ---------------------------------------------------------------- الأغلفة (الأبعد = آخر من يلف) */
  function hook() {
    if (typeof payRender !== "function" || typeof payOk !== "function" || typeof openPay !== "function" || typeof payClose !== "function") return false;
    if (!window.payOk.__pd && !window.__payDealLate) { window.__payDealLate = Date.now(); return false; }   /* ننتظر pay-deal ليلفّ أولاً */
    if (window.payRender.__po) return true;
    const pr = window.payRender;
    const wR = function () { const r = pr.apply(this, arguments); try { paint(); } catch (e) { console.error(e); } return r; };
    wR.__po = 1; Object.assign(wR, { __pd: pr.__pd, __dn: pr.__dn }); window.payRender = wR; try { payRender = wR; } catch (e) { }

    const op = window.openPay;
    const wO = function () {
      const r = op.apply(this, arguments);
      try {
        if (typeof P !== "undefined" && P) {
          const c = isRet() ? null : custRec();
          P.__oldDebt = debtOf(c); P.__oldName = c ? c.name : ""; P.__oldCid = c ? c.id : null; P.__oldOn = false; P.__t0 = null;
          paint();
        }
      } catch (e) { console.error(e); }
      return r;
    };
    wO.__po = 1; wO.__pd = op.__pd; wO.__defs = op.__defs; window.openPay = wO; try { openPay = wO; } catch (e) { }

    const pc = window.payClose;
    const wC = function () { try { close2(true); const pay = $("pay"); if (pay) pay.classList.remove("po-has"); if (rb) rb.hidden = true; } catch (e) { } return pc.apply(this, arguments); };
    wC.__po = 1; wC.__pd = pc.__pd; window.payClose = wC; try { payClose = wC; } catch (e) { }

    const po = window.payOk;
    const wK = function () {
      /* دفع أكثر من الفاتورة والعميل عليه دين سابق ← نسأل: الباقي على الدين أم يُرجَع للعميل؟ */
      try {
        if (!OVB && typeof P !== "undefined" && P && !P.__oldOn && P.__oldDebt > 0.004 && !isRet()) {
          const inv0 = r2(P.t.total), paid0 = r2(payPaid());
          if (paid0 > 0 && paid0 - inv0 > 0.004) { askOver(wK, this, arguments, inv0, paid0); return; }
        }
      } catch (e) { console.error(e); }
      if (typeof P === "undefined" || !P || !P.__oldOn || !(P.__oldDebt > 0)) return po.apply(this, arguments);
      const inv = r2(P.__t0.total), debt = P.__oldDebt, paid = r2(payPaid());
      const oldPaid = r2(Math.min(debt, Math.max(0, paid - inv)));
      /* نعيد النافذة لحالتها الأصلية (الفاتورة فقط) ونطرح جزء الدين من الخزينة صاحبة أكبر مبلغ */
      P.t = P.__t0; P.__oldOn = false;
      let trId = null, trName = "";
      if (oldPaid > 0) {
        const ids = TREASURIES.map(x => x.id).sort((a, b) => pNum(P.amt[b]) - pNum(P.amt[a]));
        trId = ids[0]; trName = (TREASURIES.find(x => x.id === trId) || {}).name || "";
        let left = oldPaid;
        ids.forEach(id => { if (left <= 0) return; const v = pNum(P.amt[id]), take = Math.min(v, left); P.amt[id] = String(r2(v - take)); left = r2(left - take); });
      }
      const hasRows = (typeof rows !== "undefined") && rows.some(r => r.pid && r.qty > 0);
      if (oldPaid > 0) {
        PEND = { name: P.__oldName, cid: P.__oldCid, amt: oldPaid, debt, trId, trName };
        if (!hasRows || !host()) {   /* بدون أصناف (سداد فقط) أو وضع المعاينة: يُسجَّل فوراً */
          const r = po.apply(this, arguments); setTimeout(() => runPend(null), hasRows ? 400 : 0); return r;
        }
        PEND.t = setTimeout(() => {
          if (!PEND) return; const o = PEND; PEND = null;
          T("⚠ لم يصل تأكيد حفظ الفاتورة — لم يُسجَّل سداد الدين (" + F(o.amt) + "). سجّله من «استلام نقدية».", "e");
          try { alert("تنبيه: لم يصل تأكيد حفظ الفاتورة خلال دقيقة ونصف، فلم يُسجَّل سداد الدين السابق.\n\nالعميل: " + o.name + "\nالمبلغ على الدين: " + F(o.amt) + " DZD\n\nتأكّد من الفاتورة في «مراجعة المبيعات» ثم سجّل المبلغ من الحسابات ← استلام نقدية (Ctrl+R)."); } catch (x) { }
        }, 90000);
      }
      return po.apply(this, arguments);
    };
    wK.__po = 1; wK.__pd = po.__pd; window.payOk = wK; try { payOk = wK; } catch (e) { }
    return true;
  }
  if (!hook()) { let k = 0; const t = setInterval(() => { if (hook() || ++k > 60) clearInterval(t); }, 250); }

  /* F8 = القديم + الجديد (قبل حارس مفاتيح F في نافذة الدفع) */
  window.addEventListener("keydown", e => {
    if (e.key !== "F8" || typeof P === "undefined" || !P || !$("payOv") || !$("payOv").classList.contains("show")) return;
    if (!(P.__oldDebt > 0)) return;
    e.preventDefault(); e.stopImmediatePropagation(); toggle();
  }, true);
})();
