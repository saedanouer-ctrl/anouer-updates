/* ANOUER — قائمة «الإضافات» (مطابقة DEXEF ONE، مع إصلاح أخطائه):
   خصومات الأصناف · خصم الكمية (حفظ دائم) · البونص (اللوحة، مراجعة البونص، نظرة عامة، التقارير) · تكاليف الأصناف الإضافية ·
   خصومات الفواتير · شرائح الخصم · كوبونات الخصم · الخصائص (لوحة الإضافات).
   كل البيانات تُحفظ في قاعدة ANOUER (الفهرس العام fm.cat) وتُطبَّق فعلياً في فاتورة المبيعات:
   خصم الصنف + خصم الكمية على سعر السطر، البونص كسطر مجاني، خصم الفاتورة التلقائي، الكوبون، شرائح الخصم. */
(function () {
  "use strict";
  const H = window.__FH, RV = window.__RV, main = document.querySelector(".main");
  if (!H || !RV || !main) { console.warn("promos: __FH/__RV غير متاح"); return; }
  const { DB, Grid, Dlg, mkView, tabOpen, esc, say, num, prods, lsGet, lsSet, norm, printList, csvList, r2, ctxMenu } = H;
  const fmt = v => H.fmt(v);
  const BR = RV.BR || ["الفرع الرئيسي"];
  const P = () => window.ANOUER_PURCHASES;
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const call = (a, p) => Anouer.call(a, p || {});
  const ask = (m, y) => { try { askConfirm(m, y); } catch (e) { if (confirm(m)) y(); } };
  const snd = k => { try { ANOUER_SOUND(k); } catch (e) { } };
  const p2 = n => String(n).padStart(2, "0");
  const ymd = d => d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate());
  const today = () => ymd(new Date());
  const addM = (d, m) => { const x = new Date(d); x.setMonth(x.getMonth() + m); return x; };
  const addD = (s, n) => { const x = new Date(s + "T00:00:00"); x.setDate(x.getDate() + n); return ymd(x); };
  const SRCH = RV.SRCH || "";

  /* ================================================================ المخزن */
  const KINDS = ["idisc", "qdisc", "bonus", "icost", "invdisc", "slice", "coupon"];
  const D = {}; KINDS.forEach(k => D[k] = []);
  const subs = {};
  const on = (k, f) => (subs[k] = subs[k] || []).push(f);
  const emit = k => (subs[k] || []).forEach(f => { try { f(); } catch (e) { console.warn(e); } });
  const toRec = r => Object.assign({}, r.data || {}, { id: r.id, no: r.no, name: r.name, active: r.active !== false });
  function load(k, force) { return DB.list(k, force).then(l => { D[k] = (l || []).map(toRec); if (k === "slice") setTimeout(() => { try { fillSlices(); } catch (e) { } }, 0); return D[k]; }).catch(e => { console.warn("promos load", k, e); return D[k]; }); }
  function saveRec(k, x) {
    const data = Object.assign({}, x); ["id", "no", "name", "active"].forEach(f => delete data[f]);
    return DB.save(k, { id: x.id || 0, no: x.no || "", name: x.name, active: x.active !== false, data })
      .then(r => { x.id = (r && r.id) || x.id; if (r && r.no) x.no = r.no; return load(k, true); }).then(() => { emit(k); return x; });
  }
  function delRec(k, x) { return DB.del(k, x.id).then(() => load(k, true)).then(() => emit(k)); }
  const nextNo = k => DB.next(k).catch(() => String(D[k].length + 1));
  const isOn = x => x && x.active !== false;
  /* ✦ (2026-11-22) نسخة العملاء: كل إضافة خصم تعمل في الفواتير فقط إذا كانت مفعّلة بكودها (ANOUER_LIC) — وفي LITE تحتاج PRO */
  const _fo = {};
  const featOk = mod => {
    const n = Date.now(), c = _fo[mod]; if (c && n - c.t < 4000) return c.v;
    let v = true;
    try { if (window.ANOUER_LITE && ANOUER_LITE.on && ANOUER_LITE.pro && !ANOUER_LITE.pro()) v = false;
      else if ((window.ANOUER_EDITION || {}).dist && window.ANOUER_LIC) v = !!ANOUER_LIC.ok(mod); } catch (e) { }
    _fo[mod] = { t: n, v }; return v;
  };
  const inPer = (x, d) => { d = d || today(); return (!x.from || x.from <= d) && (!x.to || x.to >= d); };

  /* المستخدم الحالي (للصلاحيات) — من الجلسة */
  const UT = [["admin", "مدير النظام"], ["branch", "مدير الفرع"], ["adv", "مستخدم متقدم"], ["user", "مستخدم"]];
  let ME = null;
  function loadMe() {
    if (!(window.Anouer && Anouer.available && Anouer.authMe)) return;
    Anouer.authMe().then(u => { if (!u) return; const n = String(u.RoleName || "").toLowerCase();
      ME = /admin|مدير النظام/.test(n) ? "admin" : /branch|فرع/.test(n) ? "branch" : /adv|متقدم/.test(n) ? "adv" : "user"; }).catch(() => { });
  }
  const roleOk = x => !x.roleOn || !(x.roles || []).length || !ME || x.roles.includes(ME);

  /* ================================================================ أيقونات */
  const IC = {
    pct: '<svg viewBox="0 0 48 48" width="60" height="60"><path d="M24 2l5 5 7-1 2 7 6 4-3 6 3 6-6 4-2 7-7-1-5 5-5-5-7 1-2-7-6-4 3-6-3-6 6-4 2-7 7 1z" fill="#1d7fc4"/><text x="24" y="31" text-anchor="middle" font-family="Arial" font-weight="700" font-size="19" fill="#fff">%</text></svg>',
    drop: s => `<svg width="${s}" height="${s}" viewBox="0 0 40 40" aria-hidden="true"><path d="M20 2C20 2 7 14 7 25a13 13 0 0 0 26 0c0-5-3-9-6-12-1 3-3 5-5 5 1-6-1-12-2-16z" fill="#0a78d4"/><text x="20" y="30" text-anchor="middle" font-family="Arial" font-weight="700" font-size="14" fill="#fff">%</text></svg>`,
    bonus: '<svg viewBox="0 0 56 30" width="60" height="34"><rect x="2" y="3" width="52" height="24" rx="12" fill="none" stroke="#1d6fb8" stroke-width="4"/><path d="M14 15h10" stroke="#1d6fb8" stroke-width="4" stroke-linecap="round"/><path d="M37 9v12M31 15h12" stroke="#1d6fb8" stroke-width="4" stroke-linecap="round"/></svg>',
    cost: '<svg viewBox="0 0 48 48" width="56" height="56"><rect x="6" y="10" width="36" height="30" rx="4" fill="#e9f2fc" stroke="#1d6fb8" stroke-width="3"/><path d="M6 18h36" stroke="#1d6fb8" stroke-width="3"/><circle cx="24" cy="29" r="6" fill="#f08a24"/><path d="M24 25v8M21 29h6" stroke="#fff" stroke-width="2"/></svg>',
    calc: '<svg viewBox="0 0 40 40" width="44" height="44"><rect x="2" y="2" width="17" height="17" rx="2" fill="#1e88e5"/><rect x="21" y="2" width="17" height="17" rx="2" fill="#1e88e5"/><rect x="2" y="21" width="17" height="17" rx="2" fill="#1e88e5"/><rect x="21" y="21" width="17" height="17" rx="2" fill="#1e88e5"/><g stroke="#fff" stroke-width="2.6" stroke-linecap="round"><path d="M10.5 6.5v8M6.5 10.5h8M25.5 10.5h8M7 26l7 7M14 26l-7 7M25.5 27.5h8M25.5 32h8"/></g></svg>',
    cart: '<svg width="14" height="14" viewBox="0 0 16 16" aria-hidden="true"><path d="M1 2h2.5l1.6 7h7l1.4-5H4.4" fill="none" stroke="#e8590c" stroke-width="1.6"/><circle cx="6" cy="13" r="1.3" fill="#e8590c"/><circle cx="11.5" cy="13" r="1.3" fill="#e8590c"/></svg>',
    back: '<svg width="30" height="30" viewBox="0 0 30 30" aria-hidden="true"><circle cx="15" cy="15" r="13" fill="#fff" stroke="#3b78bd" stroke-width="2"/><path d="M8 15h13M16 9l6 6-6 6" fill="none" stroke="#3b78bd" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    sales: '<svg width="14" height="14" viewBox="0 0 16 16"><rect x="1" y="9" width="3" height="6" fill="#e8590c"/><rect x="6" y="5" width="3" height="10" fill="#1d7fc4"/><rect x="11" y="2" width="3" height="13" fill="#2e8b57"/></svg>',
    pur: '<svg width="14" height="14" viewBox="0 0 16 16"><path d="M1 2h2.5l1.6 7h7l1.4-5H4.4" fill="none" stroke="#e53935" stroke-width="1.8"/><circle cx="6" cy="13" r="1.4" fill="#e53935"/><circle cx="11.5" cy="13" r="1.4" fill="#e53935"/></svg>',
    both: '<svg width="14" height="14" viewBox="0 0 16 16" fill="#1d7fc4"><rect x="1" y="3" width="14" height="2"/><rect x="1" y="7" width="14" height="2"/><rect x="1" y="11" width="14" height="2"/></svg>',
    rep: '<svg viewBox="0 0 26 22" width="26" height="22"><g fill="none" stroke="#2a8fe8" stroke-width="1.7"><rect x="1" y="1" width="9" height="5" rx="1"/><rect x="13" y="8" width="11" height="5" rx="1"/><rect x="1" y="15" width="9" height="5" rx="1"/><path d="M10 3.5h3v8M10 17.5h3v-6"/></g></svg>'
  };
  const APPLY = [["s", "المبيعات", IC.sales], ["p", "المشتريات", IC.pur], ["sp", "المشتريات و المبيعات", IC.both]];
  const KIND = [["p", "بالنسبة", "%"], ["v", "بالقيمة", "DZD"]];
  const levelsAll = () => window.ANOUER_PL ? ANOUER_PL.all().map(x => [x.id, x.name]) : [["last", "سعر اخر تعامل"], ["1", "سعر البيع"], ["2", "التجزئة"], ["3", "عابر سبيل"], ["4", "سعر استطلاع"], ["5", "الجملة"], ["6", "سعر 5ومافوق"]];

  /* ================================================================ فترة البحث (مثل DEXEF + هجري صحيح) */
  const PER = [["all", "الكل"], ["py", "العام السابق"], ["pyn", "العام السابق الى الان"], ["cy", "السنة الحالية"], ["q1", "ربع السنة الأول"], ["q2", "ربع السنة الثانى"], ["q3", "ربع السنة الثالث"], ["q4", "ربع السنة الاخير"],
    ["l3", "الثلاث شهور السابقة"], ["cm", "الشهر الحالى"], ["cw", "الأسبوع الحالى"], ["td", "اليوم"], ["cu", "فترة محددة"]];
  function perRange(k) {
    const t = new Date(), y = t.getFullYear(), m = t.getMonth(), q = n => [ymd(new Date(y, n * 3, 1)), ymd(new Date(y, n * 3 + 3, 0))];
    switch (k) {
      case "all": return ["2000-01-01", "2099-12-31"];
      case "py": return [y - 1 + "-01-01", y - 1 + "-12-31"];
      case "pyn": return [y - 1 + "-01-01", ymd(t)];
      case "cy": return [y + "-01-01", y + "-12-31"];
      case "q1": return q(0); case "q2": return q(1); case "q3": return q(2); case "q4": return q(3);
      case "cm": return [ymd(new Date(y, m, 1)), ymd(new Date(y, m + 1, 0))];
      case "cw": { const s = new Date(t); s.setDate(t.getDate() - ((t.getDay() + 1) % 7)); const e = new Date(s); e.setDate(s.getDate() + 6); return [ymd(s), ymd(e)]; }
      case "td": return [ymd(t), ymd(t)];
      default: return [ymd(new Date(y, m - 3, 1)), ymd(t)];
    }
  }
  function hijri(s) {
    try { const d = new Date(s + "T12:00:00"), p = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura-nu-latn", { day: "numeric", month: "numeric", year: "numeric" }).formatToParts(d), g = t => (p.find(x => x.type === t) || {}).value || "";
      return { d: g("day"), m: g("month"), y: g("year").replace(/\D/g, "") }; } catch (e) { return { d: "", m: "", y: "" }; }
  }
  /* زر فترة البحث: يفتح نافذة «فترة العرض» ويعيد {k,from,to} */
  function perButton(host, st, onChange) {
    const b = document.createElement("button"); b.type = "button"; b.className = "pz-perb";
    const lbl = () => { b.innerHTML = `<span>${esc((PER.find(x => x[0] === st.k) || PER[8])[1])}</span><i>▾</i>`; b.title = st.from + " ← " + st.to; };
    lbl(); host.appendChild(b);
    b.addEventListener("click", () => {
      const old = document.querySelector(".pz-perp"); if (old) { old.remove(); return; }
      const pp = document.createElement("div"); pp.className = "pz-perp";
      const hj = s => { const h = hijri(s); return `<span class="hj"><input readonly value="${h.d}"><input readonly value="${h.m}"><input readonly value="${h.y}"></span>`; };
      const draw = () => { pp.innerHTML = `<div class="r"><label>فترة العرض</label><span class="pz-sel"><select data-k="k">${PER.map(x => `<option value="${x[0]}"${x[0] === st.k ? " selected" : ""}>${esc(x[1])}</option>`).join("")}</select></span></div>
        <div class="hh"><span></span><b>هجري</b></div>
        <div class="r"><label>من التاريخ</label><input type="date" data-k="from" value="${st.from}">${hj(st.from)}</div>
        <div class="r"><label>الى التاريخ</label><input type="date" data-k="to" value="${st.to}">${hj(st.to)}</div>
        <div class="ft"><button type="button" class="pz-ok">موافق</button></div>`; };
      draw(); document.body.appendChild(pp);
      const r = b.getBoundingClientRect(); pp.style.top = (r.bottom + 4) + "px"; pp.style.left = Math.max(6, Math.min(r.right - pp.offsetWidth, innerWidth - pp.offsetWidth - 6)) + "px";
      pp.addEventListener("change", e => { const k = e.target.dataset.k;
        if (k === "k") { st.k = e.target.value; if (st.k !== "cu") { const x = perRange(st.k); st.from = x[0]; st.to = x[1]; } draw(); }
        else if (k === "from" || k === "to") { st[k] = e.target.value; st.k = "cu"; draw(); } });
      const close = ok => { pp.remove(); document.removeEventListener("mousedown", out, true); if (ok) { lbl(); onChange(st); } };
      const out = e => { if (!pp.contains(e.target) && e.target !== b && !b.contains(e.target)) close(false); };
      setTimeout(() => document.addEventListener("mousedown", out, true), 0);
      pp.addEventListener("click", e => { if (e.target.closest(".pz-ok")) { if (st.from > st.to) { say("تاريخ البداية بعد تاريخ النهاية", "w"); return; } close(true); } });
      pp.addEventListener("keydown", e => { if (e.key === "Escape") { e.stopPropagation(); close(false); } if (e.key === "Enter") { e.preventDefault(); close(true); } });
    });
    return { label: lbl };
  }

  /* ================================================================ عناصر النماذج */
  const sel = (k, opts, w, icon) => `<span class="qd-sel pz-s" style="width:${w || 120}px">${icon ? `<span class="ki" data-ki="${k}">${icon}</span>` : ""}<select data-k="${k}">${opts.map(o => `<option value="${esc(o[0])}">${esc(o[1])}</option>`).join("")}</select></span>`;
  const inp = (k, w, type, ph) => `<input class="qd-in" data-k="${k}" style="width:${w || 120}px"${type === "date" ? ' type="date"' : type === "num" ? ' inputmode="decimal" data-num="1"' : ""} autocomplete="off"${ph ? ` placeholder="${esc(ph)}"` : ""}>`;
  const tg = k => `<button type="button" class="pz-tg" data-k="${k}" role="switch" aria-checked="false"><i></i><span>لا</span></button>`;
  const ms = (k, w, ph) => `<span class="pz-ms" data-k="${k}" tabindex="0" style="width:${w || 220}px" role="button" aria-haspopup="listbox"><span class="v">${esc(ph || "")}</span><i>▾</i></span>`;
  const R = (lbl, ctrl, req, cls, k) => `<div class="qd-r pz-r ${cls || ""}"${k ? ` data-row="${k}"` : ""}><label>${esc(lbl)}</label>${ctrl}${req ? '<span class="req">*</span>' : ""}</div>`;
  /* نافذة بنمط DEXEF: أقسام بشريط ملوّن (أو كتلة عنوان ملوّنة) */
  function pzDlg(o) {
    const ov = document.createElement("div"); ov.className = "qd-ov pz-ov show";
    ov.innerHTML = `<div class="qd pz-d ${o.cls || ""}" role="dialog" aria-modal="true" style="width:${o.w || 535}px;height:${o.h ? o.h + "px" : "auto"}">
      <button type="button" class="qd-x" data-x="1" aria-label="إغلاق" title="إغلاق (Esc)"><svg width="13" height="13" viewBox="0 0 14 14"><path d="M1 1l12 12M13 1L1 13" stroke="#444" stroke-width="1.2"/></svg></button>
      ${o.head || `<h2 class="qd-t pz-t">${esc(o.title)}</h2>`}
      <div class="qd-main pz-main">${o.side != null ? `<div class="qd-act pz-act">${o.side}</div>` : ""}<div class="qd-form">${o.body}</div></div>
      <div class="qd-f"><button type="button" class="qd-ok" data-ok="1">${esc(o.okText || "موافق")}</button><button type="button" class="qd-cl" data-x="1">${esc(o.closeText || "إغلاق")}</button></div></div>`;
    document.body.appendChild(ov);
    const root = ov.querySelector(".pz-d"), q = k => root.querySelector(`[data-k="${k}"]`);
    const X = {
      ov, root, q,
      get(k) { const e = q(k); if (!e) return undefined; if (e.classList.contains("pz-tg")) return e.classList.contains("on"); if (e.classList.contains("pz-ms")) return (e._v || []).slice(); if (e.dataset.num) return e.value.trim() === "" ? "" : num(e.value); if (e.type === "checkbox") return e.checked; return e.value; },
      set(k, v) { const e = q(k); if (!e) return; if (e.classList.contains("pz-tg")) { e.classList.toggle("on", !!v); e.setAttribute("aria-checked", !!v); e.querySelector("span").textContent = v ? "نعم" : "لا"; }
        else if (e.classList.contains("pz-ms")) { e._v = (v || []).slice(); msLbl(e); } else if (e.type === "checkbox") e.checked = !!v; else e.value = v == null ? "" : v; },
      close() { ov.remove(); window.removeEventListener("keydown", key, true); if (o.onClose) o.onClose(); },
      fail(k, m) { const e = typeof k === "string" ? q(k) : k; if (e) { e.classList.add("bad"); const f = e.matches("input,select") ? e : e.querySelector("input,select"); if (f) f.focus(); else if (e.focus) e.focus(); } snd("error"); say(m, "e"); return false; },
      vis(k, show) { const r = root.querySelector(`[data-row="${k}"]`); if (r) r.hidden = !show; }
    };
    function key(e) {
      if (!document.body.contains(ov)) { window.removeEventListener("keydown", key, true); return; }
      if (document.querySelector(".pz-msp,.pz-sug")) return;
      if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); X.close(); }
      else if ((e.key === "F2" || (e.ctrlKey && (e.key === "s" || e.key === "S"))) && o.onOk) { e.preventDefault(); e.stopImmediatePropagation(); o.onOk(X); }
      else if (e.key === "Enter" && e.target.tagName !== "TEXTAREA" && !e.target.closest(".pz-grid") && root.contains(e.target)) {
        const fs = Array.from(root.querySelectorAll("input:not([readonly]):not([disabled]),select,textarea,.pz-tg,.pz-ms")).filter(x => x.offsetParent);
        const i = fs.indexOf(e.target); if (i >= 0) { e.preventDefault(); e.stopImmediatePropagation(); if (i < fs.length - 1) fs[i + 1].focus(); else if (o.onOk) o.onOk(X); }
      }
    }
    window.addEventListener("keydown", key, true);
    root.addEventListener("click", e => {
      if (e.target.closest("[data-x]")) { X.close(); return; }
      if (e.target.closest("[data-ok]")) { if (o.onOk) o.onOk(X); return; }
      const t = e.target.closest(".pz-tg"); if (t) { X.set(t.dataset.k, !t.classList.contains("on")); t.classList.remove("bad"); if (o.onToggle) o.onToggle(t.dataset.k, X.get(t.dataset.k), X); return; }
      const m = e.target.closest(".pz-ms"); if (m && o.msOpts) msOpen(m, o.msOpts(m.dataset.k), () => { m.classList.remove("bad"); if (o.onToggle) o.onToggle(m.dataset.k, m._v, X); });
    });
    root.addEventListener("keydown", e => { const m = e.target.closest && e.target.closest(".pz-ms"); if (m && (e.key === " " || e.key === "F4" || (e.altKey && e.key === "ArrowDown")) && o.msOpts) { e.preventDefault(); m.click(); } });
    root.addEventListener("input", e => { const t = e.target; t.classList.remove("bad"); const s = t.closest(".bad"); if (s) s.classList.remove("bad");
      if (t.dataset.num) { const c = t.value.replace(/,/g, ".").replace(/[^0-9.]/g, "").replace(/^(\d*\.?\d*).*$/, "$1"); if (c !== t.value) t.value = c; } });
    ov.addEventListener("mousedown", e => { if (e.target === ov) root.animate([{ transform: "scale(1)" }, { transform: "scale(1.012)" }, { transform: "scale(1)" }], { duration: 180 }); });
    return X;
  }
  function msLbl(e) { const l = e._opts || [], v = e._v || [], s = e.querySelector(".v");
    const names = v.map(id => (l.find(o => o[0] === id) || [id, id])[1]); s.textContent = names.length ? names.join(", ") : (e.dataset.ph || ""); e.title = names.join(" ، "); }
  /* قائمة اختيار متعدد (Select All + Cancel/OK) */
  function msOpen(anchor, opts, done) {
    const old = document.querySelector(".pz-msp"); if (old) old.remove();
    anchor._opts = opts; const sel0 = new Set(anchor._v || []);
    const pp = document.createElement("div"); pp.className = "pz-msp"; pp.setAttribute("role", "listbox");
    pp.innerHTML = `<div class="l"><label class="all"><span>(Select All)</span><input type="checkbox" data-all="1"></label>${opts.map(o => `<label><span>${esc(o[1])}</span><input type="checkbox" data-v="${esc(o[0])}"${sel0.has(o[0]) ? " checked" : ""}></label>`).join("")}</div>
      <div class="f"><span class="g" aria-hidden="true"></span><button type="button" data-c="1">Cancel</button><button type="button" data-o="1">OK</button></div>`;
    document.body.appendChild(pp);
    const r = anchor.getBoundingClientRect(); pp.style.width = Math.max(r.width, 220) + "px";
    pp.style.left = Math.max(6, Math.min(r.right - pp.offsetWidth, innerWidth - pp.offsetWidth - 6)) + "px";
    pp.style.top = (r.bottom + pp.offsetHeight + 4 > innerHeight ? Math.max(6, r.top - pp.offsetHeight - 2) : r.bottom + 2) + "px";
    const boxes = () => Array.from(pp.querySelectorAll("input[data-v]")), all = pp.querySelector("[data-all]");
    const syncAll = () => { const b = boxes(); all.checked = b.length && b.every(x => x.checked); all.indeterminate = !all.checked && b.some(x => x.checked); };
    syncAll();
    pp.addEventListener("change", e => { if (e.target.dataset.all) boxes().forEach(x => x.checked = e.target.checked); syncAll(); });
    const close = ok => { if (ok) { anchor._v = boxes().filter(x => x.checked).map(x => x.dataset.v); msLbl(anchor); if (done) done(); } pp.remove(); document.removeEventListener("mousedown", out, true); window.removeEventListener("keydown", k, true); anchor.focus(); };
    const out = e => { if (!pp.contains(e.target) && !anchor.contains(e.target)) close(false); };
    const k = e => { if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); close(false); } else if (e.key === "Enter") { e.preventDefault(); e.stopImmediatePropagation(); close(true); } };
    setTimeout(() => { document.addEventListener("mousedown", out, true); window.addEventListener("keydown", k, true); }, 0);
    pp.addEventListener("click", e => { if (e.target.closest("[data-o]")) close(true); else if (e.target.closest("[data-c]")) close(false); });
    const f = pp.querySelector("input"); if (f) f.focus();
  }

  /* ================================================================ بحث الأصناف (قائمة منسدلة) */
  function findProds(q, max) {
    const t = norm(q || "").trim(), l = prods();
    const r = t ? l.filter(p => norm(p.name).includes(t) || String(p.code || "").includes(String(q).trim()) || String(p.barcode || "").split(/\s+/).includes(String(q).trim())) : l.slice();
    return r.slice(0, max || 80);
  }
  function suggest(input, onPick, have) {
    /* نافذة اختيار الصنف الموحّدة (item-pick.js) — الاسم/الكود/السعر/الرصيد + الفلترة والترتيب */
    if (window.ANOUER_IPICK) { ANOUER_IPICK.attach(input, onPick, { have: have ? () => new Set([...have()].map(String)) : null }); return; }
    let pp = document.querySelector(".pz-sug"); if (pp) pp.remove();
    pp = document.createElement("div"); pp.className = "pz-sug qi-dd open"; pp.setAttribute("role", "listbox");
    pp.innerHTML = `<div class="qi-ddh"><div></div><div>الاسم</div><div>الكود</div><div>السعر</div></div><div class="qi-ddb"></div>`;
    document.body.appendChild(pp);
    const body = pp.querySelector(".qi-ddb"); let list = [], idx = 0;
    const pos = () => { const r = input.getBoundingClientRect(), W = Math.min(Math.max(r.width, 440), innerWidth - 12), Hh = 280; pp.style.width = W + "px"; pp.style.height = Hh + "px";
      pp.style.left = Math.max(6, Math.min(r.right - W, innerWidth - W - 6)) + "px"; pp.style.top = (r.bottom + Hh + 8 > innerHeight ? Math.max(6, r.top - Hh - 2) : r.bottom + 2) + "px"; };
    const draw = () => { list = findProds(input.value, 80); if (idx >= list.length) idx = Math.max(0, list.length - 1); const hv = have ? have() : new Set();
      body.innerHTML = list.length ? list.map((p, k) => { const h = hv.has(String(p.id)); return `<div class="qi-ddr${k === idx ? " act" : ""}${h ? " in" : ""}" data-i="${k}"><div class="ck">${k === idx ? "←" : h ? "✔" : ""}</div><div>${esc(p.name)}</div><div class="cd">${esc(p.code)}</div><div class="pr">${fmt(p.price)}</div></div>`; }).join("") : '<div class="qi-ddn">لا توجد أصناف مطابقة</div>';
      const a = body.querySelector(".act"); if (a) a.scrollIntoView({ block: "nearest" }); };
    const close = () => { pp.remove(); input.removeEventListener("input", onIn); input.removeEventListener("keydown", onKey); document.removeEventListener("mousedown", out, true); };
    const pick = k => { const p = list[k]; if (!p) return; close(); onPick(p); };
    const onIn = () => { idx = 0; draw(); };
    const onKey = e => {
      if (e.key === "ArrowDown") { e.preventDefault(); idx = Math.min(list.length - 1, idx + 1); draw(); }
      else if (e.key === "ArrowUp") { e.preventDefault(); idx = Math.max(0, idx - 1); draw(); }
      else if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); pick(idx); }
      else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); }
    };
    const out = e => { if (!pp.contains(e.target) && e.target !== input) close(); };
    input.addEventListener("input", onIn); input.addEventListener("keydown", onKey);
    setTimeout(() => document.addEventListener("mousedown", out, true), 0);
    pp.addEventListener("mousedown", e => { const r = e.target.closest(".qi-ddr"); e.preventDefault(); if (r) pick(+r.dataset.i); });
    pos(); draw();
  }
  const prodOf = it => { const l = prods(); return (it.pid && l.find(p => String(p.id) === String(it.pid))) || (it.code && l.find(p => String(p.code) === String(it.code))) || null; };
  const defUnitName = p => (p && p._d && p._d.name) || (p && p.unit) || "قطعة";
  const itemRec = p => ({ pid: p.id, code: String(p.code || ""), name: p.name, unit: defUnitName(p), qty: 0, used: 0 });

  /* ================================================================ شاشة البطاقات (نمط DEXEF) + شاشة الأصناف */
  function cardScreen(cfg) {
    const view = cfg.view, el = mkView(view, cfg.title);
    el.classList.add("pz-vw");
    const st = { q: "", br: BR[0], ap: "s", st: "on", per: { k: "l3", from: perRange("l3")[0], to: perRange("l3")[1] }, cur: null, rows: [] };
    el.innerHTML = `<div class="qdv pz-v"><div class="qdv-top pz-top">
        <div><label>البحث</label><div class="qdv-sbox"><span>${SRCH}</span><input data-q placeholder="Enter text to search..." autocomplete="off"></div></div>
        <button type="button" class="qdv-add" data-add title="${esc(cfg.addTip || "إضافة")}" aria-label="إضافة">+</button>
        <div class="pz-tf"><label>اسم الفرع</label><span class="qd-sel" style="width:160px"><select data-br>${BR.map(b => `<option>${esc(b)}</option>`).join("")}</select></span></div>
        ${cfg.apply ? `<div class="pz-tf"><label>يطبق أثناء</label>${sel("ap", APPLY, 160, IC.sales).replace('data-k="ap"', 'data-ap="1" data-k="ap"')}</div>` : ""}
        ${cfg.status ? `<div class="pz-tf"><label>الحالة</label><span class="qd-sel" style="width:110px"><select data-st><option value="on">نشط</option><option value="off">غير نشط</option><option value="all">الكل</option></select></span></div>` : ""}
        ${cfg.period ? `<div class="pz-tf" data-perh><label>فترة البحث</label></div>` : ""}
      </div>
      <div class="qdv-body"><div class="qdv-info"><h1>${esc(cfg.title)}</h1><p>${esc(cfg.desc)}</p></div><div class="qdv-cards" data-cards></div><div class="qi pz-items" data-items hidden></div></div></div>`;
    const Q = s => el.querySelector(s), cards = Q("[data-cards]"), items = Q("[data-items]");
    if (cfg.period) perButton(Q("[data-perh]"), st.per, () => render());
    const list = () => D[cfg.kind].filter(x => (x.branch || BR[0]) === st.br && (!cfg.apply || (x.apply || "s") === st.ap || (x.apply === "sp" && st.ap !== "sp") || (st.ap === "sp" && x.apply))
      && (!cfg.status || st.st === "all" || (st.st === "on") === isOn(x))
      && (!cfg.period || st.per.k === "all" || ((!x.to || x.to >= st.per.from) && (!x.from || x.from <= st.per.to)))
      && (!st.q || norm(x.name + " " + (x.items || []).map(i => i.name).join(" ")).includes(norm(st.q)))).sort((a, b) => (+a.no || 0) - (+b.no || 0));
    function render() {
      if (st.cur) return;
      const l = list();
      cards.innerHTML = l.length ? l.map(x => { const c = cfg.card(x); return `<div class="qdv-c pz-c${isOn(x) && (!x.to || x.to >= today()) ? "" : " off"}" tabindex="0" role="button" data-id="${x.id}" title="${esc(cfg.items ? "اختيار الأصناف" : "تعديل")}">
          <span class="qdv-ci">${cfg.cardIcon || IC.drop(40)}</span><div class="qdv-cm"><b title="${esc(x.name)}">${esc(c.t)}</b><span class="qdv-cd">${(c.d || []).map(d => `<em>${esc(d)}</em>`).join("")}</span></div>
          <span class="qdv-cn" title="${esc(c.nt || "")}">${esc(c.n != null ? c.n : "")}${c.n != null ? IC.cart : ""}</span><button type="button" class="qdv-cx" data-del="${x.id}" title="حذف" aria-label="حذف">✕</button></div>`; }).join("")
        : `<div class="qdv-none">${esc(cfg.empty || "لا توجد بيانات .. اضغط + للإضافة")}</div>`;
    }
    const byId = id => D[cfg.kind].find(x => String(x.id) === String(id));
    function del(x) { ask("هل تريد حذف «" + x.name + "» ؟", () => delRec(cfg.kind, x).then(() => { snd("del"); say("تم الحذف", "e"); }).catch(e => say(e.message, "e"))); }
    function edit(x) { cfg.dialog(x, st.br, saved => { if (saved && !x && cfg.items) openItems(saved); }); }
    Q("[data-q]").addEventListener("input", e => { st.q = e.target.value.trim(); if (st.cur) back(); render(); });
    Q("[data-br]").addEventListener("change", e => { st.br = e.target.value; if (st.cur) back(); render(); });
    if (cfg.apply) { const s = Q("[data-ap]"); s.addEventListener("change", () => { st.ap = s.value; const ki = s.parentNode.querySelector(".ki"); if (ki) ki.innerHTML = (APPLY.find(a => a[0] === s.value) || APPLY[0])[2]; render(); }); }
    if (cfg.status) Q("[data-st]").addEventListener("change", e => { st.st = e.target.value; render(); });
    Q("[data-add]").addEventListener("click", () => edit(null));
    cards.addEventListener("click", e => { const d = e.target.closest("[data-del]"); if (d) { e.stopPropagation(); const x = byId(d.dataset.del); if (x) del(x); return; }
      const c = e.target.closest(".pz-c"); if (!c) return; const x = byId(c.dataset.id); if (!x) return; if (cfg.items) openItems(x); else edit(x); });
    cards.addEventListener("keydown", e => { const c = e.target.closest(".pz-c"); if (!c) return; const x = byId(c.dataset.id);
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); if (cfg.items) openItems(x); else edit(x); } else if (e.key === "Delete") { e.preventDefault(); del(x); } else if (e.key === "F2") { e.preventDefault(); edit(x); } });
    cards.addEventListener("contextmenu", e => { const c = e.target.closest(".pz-c"); if (!c) return; e.preventDefault(); const x = byId(c.dataset.id);
      ctxMenu([].concat(cfg.items ? [["اختيار الأصناف", "Enter", "", () => openItems(x)]] : [], [["تعديل", "F2", "", () => edit(x)], [isOn(x) ? "إيقاف" : "تنشيط", "", "", () => { x.active = !isOn(x); saveRec(cfg.kind, x).then(() => say(x.active ? "تم التنشيط" : "تم الإيقاف", "i")); }], ["حذف", "Del", "", () => del(x)]]), { x: e.clientX, y: e.clientY }); });
    on(cfg.kind, () => { if (st.cur) { const x = byId(st.cur.id); if (x) { st.cur = x; Q("[data-iname]") && (Q("[data-iname]").textContent = x.name); } } render(); });

    /* ---------- شاشة الأصناف (عند الضغط على البطاقة) ---------- */
    const cols = cfg.items ? cfg.items.cols : [];
    const tpl = "34px " + cols.map(c => c.w).join(" ") + " 40px";
    function openItems(x) {
      st.cur = x; st.rows = (x.items || []).map(r => Object.assign({}, r));
      items.innerHTML = `<div class="qi-top"><button type="button" class="qi-back" data-back title="رجوع" aria-label="رجوع">${IC.back}</button><button type="button" class="qi-pick" data-pick>اختيار الاصناف</button><span class="qi-name" data-iname>${esc(x.name)}</span><button type="button" class="qi-edit" data-edit>${esc(cfg.editLink || "تعديل البيانات")}</button></div>
        <div class="qi-gh" style="grid-template-columns:${tpl}"><div class="c0"></div>${cols.map(c => `<div>${esc(c.t)}</div>`).join("")}<div class="cx"></div></div>
        <div class="qi-add" data-addrow tabindex="0" role="button">Click here to add a new row</div><div data-rows></div>
        <div class="qi-bar"><button type="button" class="qi-save" data-save>حفظ</button><span class="pz-cnt" data-cnt></span></div>`;
      cards.style.display = "none"; items.hidden = false; drawRows(); Q("[data-pick]").focus();
    }
    function drawRows() {
      const R0 = Q("[data-rows]"); if (!R0) return;
      R0.innerHTML = st.rows.map((r, i) => `<div class="qi-r${r.pid || r.code ? "" : " new"}" data-i="${i}" style="grid-template-columns:${tpl}"><div class="c0"><span class="ar">←</span><span>${i + 1}</span></div>${cols.map(c => {
        if (c.k === "name" && !(r.pid || r.code)) return `<div class="cn"><div class="qi-cb"><input data-k="name" placeholder="اكتب اسم الصنف أو الكود..." autocomplete="off"></div></div>`;
        if (c.ed) return `<div class="cq"><input data-k="${c.k}" inputmode="decimal" value="${esc(r[c.k] == null ? "" : r[c.k])}"></div>`;
        return `<div class="c${c.k === "code" ? "c" : c.k === "name" ? "n" : "u"}">${esc(c.f ? c.f(r) : r[c.k] == null ? "" : r[c.k])}</div>`; }).join("")}<div class="cx"><button type="button" class="qi-x" data-del="${i}" title="حذف" aria-label="حذف">✕</button></div></div>`).join("");
      const n = st.rows.filter(r => r.pid || r.code).length; const c = Q("[data-cnt]"); if (c) c.textContent = n ? n + " صنف" : "";
    }
    const haveSet = () => new Set(st.rows.filter(r => r.pid).map(r => String(r.pid)));
    function addRow() { let b = st.rows.findIndex(r => !(r.pid || r.code)); if (b < 0) { st.rows.push({}); b = st.rows.length - 1; drawRows(); }
      const i = Q(`[data-rows] .qi-r[data-i="${b}"] input[data-k="name"]`); if (i) { i.focus(); suggest(i, p => pickAt(b, p), haveSet); } }
    function pickAt(i, p) { if (st.rows.some((r, k) => k !== i && String(r.pid) === String(p.id))) { snd("error"); say("«" + p.name + "» مضاف مسبقاً", "w"); return; }
      st.rows[i] = Object.assign(itemRec(p), cfg.items.def ? cfg.items.def(p) : {}); drawRows();
      const nx = cols.find(c => c.ed); const f = nx && Q(`[data-rows] .qi-r[data-i="${i}"] input[data-k="${nx.k}"]`); if (f) { f.focus(); f.select(); } }
    function back() { st.cur = null; st.rows = []; items.hidden = true; items.innerHTML = ""; cards.style.display = ""; render(); }
    function saveItems() {
      const x = st.cur; if (!x) return;
      const rows = st.rows.filter(r => r.pid || r.code);
      for (const r of rows) for (const c of cols) if (c.ed) { const v = String(r[c.k] == null ? "" : r[c.k]).trim(); const n = v === "" ? 0 : num(v); if (!(n >= 0)) { snd("error"); say("القيمة غير صالحة للصنف «" + r.name + "»", "e"); return; } r[c.k] = n; }
      if (cfg.items.check) { const m = cfg.items.check(x, rows); if (m) { snd("error"); say(m, "w"); return; } }
      x.items = rows; saveRec(cfg.kind, x).then(() => { snd("save"); say("تم حفظ أصناف «" + x.name + "» (" + rows.length + " صنف)", "s"); back(); }).catch(e => say(e.message, "e"));
    }
    items.addEventListener("click", e => {
      if (e.target.closest("[data-back]")) { back(); return; }
      if (e.target.closest("[data-save]")) { saveItems(); return; }
      if (e.target.closest("[data-edit]")) { const x = st.cur; cfg.dialog(x, st.br); return; }
      if (e.target.closest("[data-addrow]")) { addRow(); return; }
      if (e.target.closest("[data-pick]")) {
        if (P() && P().pickItems) P().pickItems({ title: "تحديد الاصناف", onPick: l => { const hv = haveSet(); let n = 0; st.rows = st.rows.filter(r => r.pid || r.code);
          l.forEach(p => { if (hv.has(String(p.id))) return; st.rows.push(Object.assign(itemRec(p), cfg.items.def ? cfg.items.def(p) : {})); n++; });
          drawRows(); say(n ? "تمت إضافة " + n + " صنف" : "الأصناف المحددة موجودة مسبقاً", n ? "s" : "i"); } });
        else addRow();
        return;
      }
      const d = e.target.closest("[data-del]"); if (d) { st.rows.splice(+d.dataset.del, 1); snd("del"); drawRows(); }
    });
    items.addEventListener("keydown", e => { if (e.target.matches("[data-addrow]") && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); addRow(); }
      else if (e.target.dataset && e.target.dataset.k && e.target.dataset.k !== "name" && e.key === "Enter") { e.preventDefault(); addRow(); } });
    items.addEventListener("focusin", e => { const t = e.target; if (t.dataset && t.dataset.k === "name" && !document.querySelector(".pz-sug")) suggest(t, p => pickAt(+t.closest(".qi-r").dataset.i, p), haveSet); });
    items.addEventListener("input", e => { const t = e.target; if (!t.dataset || !t.dataset.k || t.dataset.k === "name") return; const i = +t.closest(".qi-r").dataset.i; const c = t.value.replace(/,/g, ".").replace(/[^0-9.]/g, ""); if (c !== t.value) t.value = c; st.rows[i][t.dataset.k] = t.value; });
    if (RV.VIEW_SHOW) RV.VIEW_SHOW[view] = () => { render(); };
    return { open: () => { tabOpen(view, cfg.title, view); if (st.cur) back(); render(); setTimeout(() => { const s = Q("[data-q]"); if (s) s.focus(); }, 50); }, render, openItems, edit };
  }

  /* ================================================================ 1) خصومات الأصناف */
  function idiscDialog(x, br, done) {
    const t = new Date();
    const X = pzDlg({ title: "خصومات الأصناف", w: 520, cls: "pz-id",
      head: `<div class="pz-hd"><b>خصومات الأصناف</b></div>`, side: IC.pct,
      body: `<div class="qd-sec o">${R("الفرع", sel("branch", BR.map(b => [b, b]), 160), 1)}
          <div class="pz-2">${R("الرقم", inp("no", 64), 0, "col")}${R("الاسم", inp("name", 240), 1, "col")}</div></div>
        <div class="qd-sec"><div class="pz-2">${R("يطبق أثناء", sel("apply", APPLY, 130, IC.sales), 0, "col")}${R("كيفية الخصم", sel("kind", KIND, 110, "%"), 1, "col")}</div>
          <div class="pz-2">${R("خصم المبيعات", inp("sval", 120, "num"), 1, "col", "sval")}${R("خصم المشتريات", inp("pval", 120, "num"), 1, "col", "pval")}</div>
          ${R("يطبق على مستوى أسعار محدد", tg("lvOn") + ms("levels", 220, "اختر مستويات الأسعار"), 0, "col wide")}
          ${R("يطبق على صلاحية محددة", tg("roleOn") + ms("roles", 220, "اختر الصلاحيات"), 0, "col wide")}</div>
        <div class="qd-sec"><div class="pz-2">${R("فترة الخصم من", inp("from", 125, "date"), 0, "col")}${R("إلى", inp("to", 125, "date"), 1, "col")}</div>
          ${R("يتم انتهاء الخصم بمجرد انتهاء الكمية المعرفة للصنف", tg("endQty"), 0, "col wide")}</div>`,
      msOpts: k => k === "levels" ? levelsAll() : UT,
      onToggle: (k, v, X) => ui(X), onOk: save });
    const ui = X => { const ap = X.get("apply"), k = X.get("kind");
      X.vis("sval", ap !== "p"); X.vis("pval", ap !== "s");
      const ki = X.root.querySelector('[data-ki="kind"]'); if (ki) ki.textContent = k === "v" ? "DZD" : "%";
      const ai = X.root.querySelector('[data-ki="apply"]'); if (ai) ai.innerHTML = (APPLY.find(a => a[0] === ap) || APPLY[0])[2];
      X.q("levels").style.visibility = X.get("lvOn") ? "" : "hidden"; X.q("roles").style.visibility = X.get("roleOn") ? "" : "hidden"; };
    X.root.addEventListener("change", () => ui(X));
    X.q("levels").dataset.ph = "اختر مستويات الأسعار"; X.q("roles").dataset.ph = "اختر الصلاحيات";
    X.q("levels")._opts = levelsAll(); X.q("roles")._opts = UT;
    const v = x || { branch: br, apply: "s", kind: "p", sval: "", pval: "", lvOn: false, levels: [], roleOn: false, roles: [], from: ymd(t), to: ymd(addM(t, 3)), endQty: false };
    ["branch", "name", "apply", "kind", "sval", "pval", "lvOn", "levels", "roleOn", "roles", "from", "to", "endQty"].forEach(k => X.set(k, v[k]));
    X.q("no").readOnly = true;
    if (x) X.set("no", x.no); else nextNo("idisc").then(n => X.set("no", n));
    ui(X); setTimeout(() => X.q("name").focus(), 30);
    function save(X) {
      const o = { branch: X.get("branch"), name: X.get("name").trim(), apply: X.get("apply"), kind: X.get("kind"), sval: X.get("sval"), pval: X.get("pval"),
        lvOn: X.get("lvOn"), levels: X.get("levels"), roleOn: X.get("roleOn"), roles: X.get("roles"), from: X.get("from"), to: X.get("to"), endQty: X.get("endQty") };
      if (!o.name) return X.fail("name", "أدخل اسم الخصم");
      if (o.apply !== "p" && !(o.sval > 0)) return X.fail("sval", "أدخل قيمة خصم المبيعات");
      if (o.apply !== "s" && !(o.pval > 0)) return X.fail("pval", "أدخل قيمة خصم المشتريات");
      if (o.kind === "p" && ((o.apply !== "p" && o.sval > 100) || (o.apply !== "s" && o.pval > 100))) return X.fail(o.sval > 100 ? "sval" : "pval", "نسبة الخصم يجب ألا تتجاوز 100%");
      if (o.lvOn && !o.levels.length) return X.fail("levels", "اختر مستوى سعر واحد على الأقل");
      if (o.roleOn && !o.roles.length) return X.fail("roles", "اختر صلاحية واحدة على الأقل");
      if (!o.to) return X.fail("to", "أدخل تاريخ نهاية الخصم");
      if (o.from && o.to < o.from) return X.fail("to", "تاريخ النهاية قبل تاريخ البداية");
      const rec = x ? Object.assign(x, o) : Object.assign({ no: X.get("no"), items: [], active: true }, o);
      saveRec("idisc", rec).then(r => { snd("save"); say("تم حفظ الخصم: " + o.name, "s"); X.close(); if (done) done(x ? null : r); }).catch(e => say(e.message, "e"));
    }
  }
  const S_IDISC = cardScreen({ view: "pz_idisc", kind: "idisc", title: "خصومات الأصناف", apply: true, period: true, cardIcon: IC.drop(40),
    desc: "هو خصم يتم احتسابه على الأصناف .. ولا يتم تسجيل قيد محاسبى بهذا الخصم ..ويتم حسابه إما بنسبة من سعر الصنف أو بقيمة معينة على كمية الصنف خلال فترة زمنية محددة",
    addTip: "إضافة خصم", editLink: "تعديل بيانات الخصم", empty: "لا توجد خصومات أصناف في هذه الفترة .. اضغط + للإضافة",
    card: x => ({ t: (x.items && x.items.length ? x.items[0].name + (x.items.length > 1 ? " (+" + (x.items.length - 1) + ")" : "") + " — " : "") + x.name + "  " + (x.kind === "v" ? fmt(x.apply === "p" ? x.pval : x.sval) + " DZD" : fmt(x.apply === "p" ? x.pval : x.sval) + "%"), d: [x.from || "", x.to || ""], n: (x.items || []).length, nt: "عدد الأصناف" }),
    dialog: idiscDialog,
    items: { cols: [{ k: "code", t: "الكود", w: "150px" }, { k: "name", t: "اسم الصنف", w: "minmax(200px,1fr)" }, { k: "unit", t: "الوحدة", w: "140px" }, { k: "qty", t: "الكمية المعرفة", w: "130px", ed: 1 }, { k: "used", t: "الكمية المستخدمة", w: "140px" }],
      check: (x, rows) => x.endQty && rows.some(r => !(+r.qty > 0)) ? "الخصم ينتهي بانتهاء الكمية .. أدخل «الكمية المعرفة» لكل صنف" : "" } });

  /* ================================================================ 2) تكاليف الأصناف الإضافية (لا تفتح في DEXEF — مبنية بنفس الأسلوب) */
  function icostDialog(x, br, done) {
    const X = pzDlg({ title: "تكاليف الأصناف الإضافية", w: 470, head: `<div class="pz-hd"><b>تكاليف الأصناف الإضافية</b></div>`, side: IC.cost + '<span>نشط</span>' + tg("active"),
      body: `<div class="qd-sec o">${R("الفرع", sel("branch", BR.map(b => [b, b]), 160), 1)}<div class="pz-2">${R("الرقم", inp("no", 70), 0, "col")}${R("اسم التكلفة", inp("name", 250, "", "مثال: تعبئة وتغليف، مصنعية"), 1, "col")}</div></div>
        <div class="qd-sec"><div class="pz-2">${R("يطبق أثناء", sel("apply", APPLY, 130, IC.sales), 0, "col")}${R("كيفية التكلفة", sel("kind", KIND, 110, "%"), 1, "col")}</div>
          ${R("قيمة التكلفة", inp("val", 120, "num"), 1, "col")}
          ${R("ملاحظات", '<textarea class="pz-area" data-k="notes" rows="2"></textarea>', 0, "col wide")}</div>`,
      onToggle: () => ui(), onOk: save });
    const ui = () => { const ki = X.root.querySelector('[data-ki="kind"]'); if (ki) ki.textContent = X.get("kind") === "v" ? "DZD" : "%"; const ai = X.root.querySelector('[data-ki="apply"]'); if (ai) ai.innerHTML = (APPLY.find(a => a[0] === X.get("apply")) || APPLY[0])[2]; };
    X.root.addEventListener("change", ui);
    const v = x || { branch: br, apply: "s", kind: "v", val: "", notes: "", active: true };
    ["branch", "name", "apply", "kind", "val", "notes"].forEach(k => X.set(k, v[k])); X.set("active", v.active !== false);
    X.q("no").readOnly = true; if (x) X.set("no", x.no); else nextNo("icost").then(n => X.set("no", n));
    ui(); setTimeout(() => X.q("name").focus(), 30);
    function save(X) {
      const o = { branch: X.get("branch"), name: X.get("name").trim(), apply: X.get("apply"), kind: X.get("kind"), val: X.get("val"), notes: X.get("notes"), active: X.get("active") };
      if (!o.name) return X.fail("name", "أدخل اسم التكلفة");
      if (!(o.val > 0)) return X.fail("val", "أدخل قيمة التكلفة");
      if (o.kind === "p" && o.val > 100) return X.fail("val", "النسبة يجب ألا تتجاوز 100%");
      const rec = x ? Object.assign(x, o) : Object.assign({ no: X.get("no"), items: [] }, o);
      saveRec("icost", rec).then(r => { snd("save"); say("تم حفظ التكلفة: " + o.name, "s"); X.close(); if (done) done(x ? null : r); }).catch(e => say(e.message, "e"));
    }
  }
  const S_ICOST = cardScreen({ view: "pz_icost", kind: "icost", title: "تكاليف الأصناف الإضافية", apply: true, status: true, cardIcon: IC.drop(40),
    desc: "هي تكاليف اضافية يتم تحميلها على بعض الأصناف نظراً لطبيعتها .. مثل تكاليف التعبئة و التغليف و مصنعيات الذهب الى أخره",
    addTip: "إضافة تكلفة", editLink: "تعديل بيانات التكلفة", empty: "لا توجد تكاليف إضافية .. اضغط + للإضافة",
    card: x => ({ t: x.name + "  +" + fmt(x.val) + (x.kind === "p" ? "%" : " DZD"), d: [(APPLY.find(a => a[0] === x.apply) || APPLY[0])[1]], n: (x.items || []).length, nt: "عدد الأصناف" }),
    dialog: icostDialog,
    items: { cols: [{ k: "code", t: "الكود", w: "160px" }, { k: "name", t: "اسم الصنف", w: "minmax(220px,1fr)" }, { k: "unit", t: "الوحدة", w: "160px" }] } });

  /* ================================================================ 3) البونص */
  function bonusDialog(x, br, done) {
    const t = new Date();
    const X = pzDlg({ title: "بونص الأصناف", w: 440, cls: "pz-bd",
      head: `<div class="pz-bh"><span class="ic">${IC.bonus}</span><div><b>بونص الأصناف</b><p>تم بناء هذا العرض على أساس الكمية .. ففي حالة شراء العميل لكمية معينة من الصنف .. يتم إضافة عدد قطع من نفس الصنف بناء على هذه الكمية</p></div></div>`,
      body: `<div class="pz-band"><div class="pz-lb o">بيانات أساسية</div><div class="pz-bx">${R("الرقم", inp("no", 110), 1)}${R("الاسم", inp("name", 210), 1)}${R("اسم الفرع", sel("branch", BR.map(b => [b, b]), 130), 1)}${R("نشط", tg("active"))}</div></div>
        <div class="pz-band"><div class="pz-lb">الفترة</div><div class="pz-bx">${R("من تاريخ", inp("from", 125, "date"), 1)}${R("إلى تاريخ", inp("to", 125, "date"), 1)}</div></div>
        <div class="pz-band grow"><div class="pz-lb">البونص</div><div class="pz-bx"><div class="qd-greq">*</div><div class="qd-gw pz-grid" data-k="tiers"><div class="qd-gh pz-gh3"><div>كمية العرض</div><div>البونص</div><div></div></div><div data-tg></div></div>
          <div class="pz-hint">مثال: كمية العرض 10 والبونص 1 ← عند بيع 20 قطعة يُضاف 2 مجاناً</div></div></div>`,
      onOk: save });
    let T = x ? (x.tiers || []).map(r => ({ offer: String(r.offer), bonus: String(r.bonus) })) : [];
    const tgEl = X.root.querySelector("[data-tg]");
    const drawT = () => { if (!T.length || T[T.length - 1].offer !== "" || T[T.length - 1].bonus !== "") T.push({ offer: "", bonus: "" });
      tgEl.innerHTML = T.map((r, i) => `<div class="qd-gr pz-gh3" data-i="${i}"><div><input data-t="offer" inputmode="decimal" value="${esc(r.offer)}" aria-label="كمية العرض"></div><div><input data-t="bonus" inputmode="decimal" value="${esc(r.bonus)}" aria-label="البونص"></div><div class="qd-gx"><button type="button" data-tdel="${i}" aria-label="حذف" title="حذف">✕</button></div></div>`).join(""); };
    tgEl.addEventListener("input", e => { const t2 = e.target; if (!t2.dataset.t) return; const c = t2.value.replace(/,/g, ".").replace(/[^0-9.]/g, ""); if (c !== t2.value) t2.value = c; const i = +t2.closest("[data-i]").dataset.i; T[i][t2.dataset.t] = t2.value;
      X.q("tiers").classList.remove("bad"); if (i === T.length - 1 && t2.value !== "") { T.push({ offer: "", bonus: "" }); tgEl.insertAdjacentHTML("beforeend", `<div class="qd-gr pz-gh3" data-i="${T.length - 1}"><div><input data-t="offer" inputmode="decimal"></div><div><input data-t="bonus" inputmode="decimal"></div><div class="qd-gx"><button type="button" data-tdel="${T.length - 1}" aria-label="حذف">✕</button></div></div>`); } });
    tgEl.addEventListener("click", e => { const d = e.target.closest("[data-tdel]"); if (!d) return; T.splice(+d.dataset.tdel, 1); snd("del"); drawT(); });
    tgEl.addEventListener("keydown", e => { if (e.key !== "Enter" || !e.target.dataset.t) return; e.preventDefault(); e.stopPropagation(); const ins = Array.from(tgEl.querySelectorAll("input")), k = ins.indexOf(e.target); if (ins[k + 1]) { ins[k + 1].focus(); ins[k + 1].select(); } else save(X); });
    drawT();
    const v = x || { branch: br, from: ymd(t), to: ymd(addM(t, 3)), active: true };
    ["branch", "name", "from", "to"].forEach(k => X.set(k, v[k])); X.set("active", v.active !== false);
    X.q("no").readOnly = true; if (x) X.set("no", x.no); else nextNo("bonus").then(n => X.set("no", n));
    setTimeout(() => X.q("name").focus(), 30);
    function save(X) {
      const o = { branch: X.get("branch"), name: X.get("name").trim(), from: X.get("from"), to: X.get("to"), active: X.get("active") };
      if (!o.name) return X.fail("name", "أدخل اسم البونص");
      if (!o.from) return X.fail("from", "أدخل تاريخ البداية"); if (!o.to) return X.fail("to", "أدخل تاريخ النهاية");
      if (o.to < o.from) return X.fail("to", "تاريخ النهاية قبل تاريخ البداية");
      const used = T.filter(r => r.offer !== "" || r.bonus !== ""), tiers = [];
      if (!used.length) return X.fail(X.q("tiers"), "أدخل شريحة بونص واحدة على الأقل (كمية العرض والبونص)");
      for (const r of used) { const a = num(r.offer), b = num(r.bonus); if (!(a > 0) || !(b > 0)) return X.fail(X.q("tiers"), "أكمل بيانات الشريحة: كمية العرض والبونص أكبر من صفر"); tiers.push({ offer: a, bonus: b }); }
      tiers.sort((a, b) => a.offer - b.offer);
      for (let i = 1; i < tiers.length; i++) if (tiers[i].offer === tiers[i - 1].offer) return X.fail(X.q("tiers"), "كمية العرض " + tiers[i].offer + " مكررة");
      o.tiers = tiers;
      const rec = x ? Object.assign(x, o) : Object.assign({ no: X.get("no"), items: [] }, o);
      saveRec("bonus", rec).then(r => { snd("save"); say("تم حفظ البونص: " + o.name, "s"); X.close(); if (done) done(x ? null : r); }).catch(e => say(e.message, "e"));
    }
  }
  const S_BREV = cardScreen({ view: "pz_brev", kind: "bonus", title: "بونص الأصناف", cardIcon: IC.drop(40),
    desc: "تم بناء هذا العرض على أساس الكمية .. ففي حالة شراء العميل لكمية معينة من الصنف .. يتم إضافة عدد قطع من نفس الصنف بناء على هذه الكمية",
    addTip: "إضافة بونص", editLink: "تعديل بيانات البونص", empty: "لا يوجد بونص .. اضغط + للإضافة",
    card: x => ({ t: x.name + "  (" + (x.tiers || []).map(t => t.offer + "←" + t.bonus).join(" ، ") + ")", d: [x.from || "", x.to || ""], n: (x.items || []).length, nt: "عدد الأصناف" }),
    dialog: bonusDialog,
    items: { cols: [{ k: "code", t: "الكود", w: "minmax(140px,.6fr)" }, { k: "name", t: "اسم الصنف", w: "minmax(260px,1.4fr)" }, { k: "unit", t: "الوحدة", w: "minmax(140px,.6fr)" }] } });

  /* لوحة البونص (البلاطات — مطابقة DEXEF) */
  function bonusHub() {
    const v = "pz_bhub", el = mkView(v, "البونص");
    if (!el.dataset.b) {
      el.dataset.b = "1"; el.classList.add("pz-vw");
      const T = [["dash", "DashBoard", "#0b5e4a", "1 / 3", "1 / 2", '<svg viewBox="0 0 24 24" width="30" height="30" fill="#fff"><rect x="3" y="15" width="3.4" height="6"/><rect x="8" y="11" width="3.4" height="10"/><rect x="13" y="7" width="3.4" height="14"/><rect x="18" y="3" width="3.4" height="18"/></svg>', 1],
        ["items", "الاصناف", "#0e3a6e", "3 / 4", "1 / 2", '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="#fff" stroke-width="1.8"><rect x="8" y="2" width="13" height="15" rx="1"/><rect x="5" y="5" width="13" height="15" rx="1" fill="#0e3a6e"/><rect x="2" y="8" width="13" height="14" rx="1" fill="#0e3a6e"/></svg>'],
        ["cust", "إضافة  عميل", "#4a4a4a", "4 / 5", "1 / 2", '<svg viewBox="0 0 24 24" width="26" height="26" fill="#fff"><circle cx="12" cy="8" r="4.5"/><path d="M3 22c0-5 4-8 9-8s9 3 9 8z"/></svg>'],
        ["pret", "مرتجع<br>المشتريات", "#6c3fc4", "5 / 6", "1 / 2", '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="#fff" stroke-width="2.4"><path d="M20 12a8 8 0 0 1-14 5.3M4 12A8 8 0 0 1 18 6.7"/><path d="M18 2v5h-5M6 22v-5h5"/></svg>'],
        ["sret", "مرتجع المبيعات", "#930032", "6 / 7", "1 / 2", '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="#fff" stroke-width="1.8"><rect x="4" y="2" width="14" height="18" rx="1"/><path d="M7 6h8M7 10h8M7 14h4"/><circle cx="17" cy="17" r="4.5" fill="#930032"/><path d="M15 17a2 2 0 1 1 1 1.7M15 15v2h2"/></svg>'],
        ["add", "إضافة بونص", "#243b5a", "1 / 3", "2 / 3", '<svg viewBox="0 0 24 24" width="28" height="28"><circle cx="12" cy="12" r="10" fill="#fff"/><path d="M12 7v10M7 12h10" stroke="#243b5a" stroke-width="2.6"/></svg>', 1],
        ["pinv", "فاتورة مشتريات", "#d0582e", "3 / 5", "2 / 3", '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="#fff" stroke-width="1.8"><rect x="4" y="2" width="14" height="18" rx="1"/><path d="M7 6h8M7 10h8M7 14h5"/><path d="M12 22l4-5 3 3 3-5" stroke-width="2"/></svg>']];
      el.innerHTML = `<div class="pz-hub"><h3>البونص</h3><div class="pz-tiles">${T.map(t => `<button type="button" class="pz-tile${t[6] ? " big" : ""}" data-t="${t[0]}" style="--c:${t[2]};grid-column:${t[3]};grid-row:${t[4]}"><span class="i">${t[5]}</span><span class="l">${t[1]}</span></button>`).join("")}</div></div>`;
      el.addEventListener("click", e => { const b = e.target.closest(".pz-tile"); if (!b) return; const k = b.dataset.t;
        try {
          if (k === "dash") bonusDash();
          else if (k === "add") { S_BREV.open(); setTimeout(() => S_BREV.edit(null), 80); }
          else if (k === "items") openTab("irev", "مراجعة الأصناف", "irev");
          else if (k === "cust") { try { cuReset(); } catch (x) { } openTab("cust", "إضافة عميل", "cust"); }
          else if (k === "pret") P().newReturn();
          else if (k === "sret") newReturn();
          else if (k === "pinv") P().newInvoice();
        } catch (x) { say("تعذّر فتح الشاشة", "e"); } });
    }
    tabOpen(v, "البونص", v);
  }

  /* نظرة عامة على البونص (عام / التقارير) */
  const BD = { per: { k: "l3", from: perRange("l3")[0], to: perRange("l3")[1] }, br: BR[0], tab: "gen", days: 5, lines: null, ov: null };
  function fetchBonus(from, to) {
    if (HOST()) return call("fm.promo.bonus", { from, to }).then(l => l || []).catch(e => { if (/غير معروف|NotSupported/.test(e.message || "")) say("لوحة البونص تتطلب نسخة البرنامج الجديدة (build-exe)", "w"); else say(e.message, "e"); return []; });
    const out = []; (window.SAVED_INV || []).forEach(inv => (inv.rows || []).forEach(r => { if (+r.bonus > 0 && inv.date >= from && inv.date <= to) out.push({ id: inv.no, no: inv.no, date: inv.date, type: "Sale", party: inv.name, pid: r.pid, code: "", name: r.name, unit: r.unit, qty: +r.bonus, factor: 1 }); }));
    return Promise.resolve(out);
  }
  function fetchOverview(from, to) {
    if (HOST()) return call("fm.promo.overview", { from, to }).catch(() => ({ daily: [], types: [] }));
    const by = {}; (window.SAVED_INV || []).forEach(inv => { if (inv.date >= from && inv.date <= to) by[inv.date] = (by[inv.date] || 0) + (inv.rows || []).reduce((s, r) => s + (+r.qty || 0), 0); });
    return Promise.resolve({ daily: Object.keys(by).sort().map(d => ({ d, q: by[d] })), types: [{ code: "Sale", q: Object.values(by).reduce((a, b) => a + b, 0) }] });
  }
  function bars(data) {
    if (!data.length) return '<div class="pz-nodata">لا توجد حركة في هذه الفترة</div>';
    const W = 760, Hh = 250, pl = 64, pb = 30, mx = Math.max(...data.map(x => +x.q || 0), 1);
    const raw = mx / 6, mag = Math.pow(10, Math.floor(Math.log10(raw))), st = [1, 2, 2.5, 5, 10].map(k => k * mag).find(k => k >= raw) || mag * 10, top = Math.ceil(mx / st) * st, bw = Math.max(2, (W - pl - 10) / data.length - 2);
    const ticks = Array.from({ length: Math.round(top / st) + 1 }, (_, i) => i * st);
    return `<svg viewBox="0 0 ${W} ${Hh}" class="pz-bars" direction="ltr" style="direction:ltr" preserveAspectRatio="none">${ticks.map(t => { const y = Hh - pb - (t / top) * (Hh - pb - 10); return `<line x1="${pl}" x2="${W}" y1="${y}" y2="${y}" stroke="#eef0f3"/><text x="${pl - 6}" y="${y + 3}" text-anchor="end">${fmt(t)}</text>`; }).join("")}
      ${data.map((x, i) => { const h = (+x.q || 0) / top * (Hh - pb - 10), xx = pl + i * (bw + 2); return `<rect x="${xx}" y="${Hh - pb - h}" width="${bw}" height="${h}" fill="#1f6fd8"><title>${x.d}: ${fmt(x.q)}</title></rect>`; }).join("")}
      ${data.map((x, i) => i % Math.max(1, Math.ceil(data.length / 9)) ? "" : `<text x="${pl + i * (bw + 2) + bw / 2}" y="${Hh - 10}" text-anchor="middle">${x.d}</text>`).join("")}</svg>`;
  }
  const TYPES = [["Opening", "رصيد افتتاحي", "#36b6c9"], ["Purchase", "مشتريات", "#e53935"], ["SaleReturn", "مرتجع مبيعات", "#f57c00"], ["Sale", "مبيعات", "#2f6fbe"], ["Adjust", "تسوية جردية", "#3f4fa0"], ["Waste", "هالك المخزون", "#7b2d3b"]];
  function donut(types) {
    const vals = TYPES.map(t => +((types.find(x => x.code === t[0]) || {}).q) || 0), tot = vals.reduce((a, b) => a + b, 0);
    let a0 = -Math.PI / 2; const arcs = tot ? vals.map((v, i) => { if (!v) return ""; const a1 = a0 + v / tot * Math.PI * 2, L = a1 - a0 > Math.PI ? 1 : 0, R1 = 80, R2 = 52,
      p = (r, a) => (100 + r * Math.cos(a)).toFixed(2) + " " + (100 + r * Math.sin(a)).toFixed(2), d = `M${p(R1, a0)}A${R1} ${R1} 0 ${L} 1 ${p(R1, a1)}L${p(R2, a1)}A${R2} ${R2} 0 ${L} 0 ${p(R2, a0)}Z`; a0 = a1; return `<path d="${d}" fill="${TYPES[i][2]}"><title>${TYPES[i][1]}: ${fmt(v)}</title></path>`; }).join("") : '<circle cx="100" cy="100" r="66" fill="none" stroke="#e4e8ee" stroke-width="28"/>';
    return `<div class="pz-don"><svg viewBox="0 0 200 200" width="210" height="210">${arcs}<text x="100" y="96" text-anchor="middle" class="t">TOTAL</text><text x="100" y="116" text-anchor="middle" class="v">${fmt(tot)}</text></svg>
      <div class="lg">${TYPES.map((t, i) => `<span><i style="background:${t[2]}"></i>${t[1]}<b>${vals[i] ? fmt(vals[i]) : ""}</b></span>`).join("")}</div></div>`;
  }
  function bonusDash() {
    const v = "pz_bdash", el = mkView(v, "نظرة عامة");
    if (!el.dataset.b) {
      el.dataset.b = "1"; el.classList.add("pz-vw");
      el.innerHTML = `<div class="pz-dash"><div class="pz-dtop"><h2>البونص</h2><span class="sp"></span><span class="qd-sel" style="width:170px"><select data-br>${BR.map(b => `<option>${esc(b)}</option>`).join("")}</select></span><span data-perh></span></div>
        <div class="pz-dmain"><div class="pz-dside"><button type="button" class="on" data-tab="gen"><svg viewBox="0 0 24 24" width="30" height="30"><rect x="3" y="12" width="4" height="9" fill="#e8590c"/><rect x="10" y="6" width="4" height="15" fill="#1d7fc4"/><rect x="17" y="2" width="4" height="19" fill="#2e8b57"/></svg><span>عام</span></button><button type="button" data-tab="rep"><svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="#5c6b80" stroke-width="1.6"><rect x="4" y="2" width="16" height="20" rx="1"/><path d="M8 7h8M8 11h8M8 15h8M8 19h5"/></svg><span>التقارير</span></button></div>
        <div class="pz-dbody" data-body></div></div></div>`;
      perButton(el.querySelector("[data-perh]"), BD.per, () => { BD.lines = null; draw(); });
      el.querySelector("[data-br]").addEventListener("change", e => { BD.br = e.target.value; draw(); });
      el.querySelector(".pz-dside").addEventListener("click", e => { const b = e.target.closest("[data-tab]"); if (!b) return; BD.tab = b.dataset.tab; el.querySelectorAll(".pz-dside button").forEach(x => x.classList.toggle("on", x === b)); draw(); });
    }
    tabOpen(v, "نظرة عامة", v); draw();
    function draw() {
      const body = el.querySelector("[data-body]");
      if (BD.tab === "rep") { body.innerHTML = repTiles(); return; }
      body.innerHTML = `<div class="pz-dgrid"><section class="pz-p top"><h4>الاصناف الاكثر مبيعا بالبونص <span class="zm">⌕</span></h4><div class="pz-tb" data-top><div class="pz-wait">جاري التحميل…</div></div></section>
        <section class="pz-p chart"><h4>حركة المخزون اليومية <span class="zm">⌕</span></h4><div data-chart><div class="pz-wait">جاري التحميل…</div></div></section>
        <section class="pz-p stat"><h4>احصائيات <span class="zm">⌕</span></h4><div data-stat></div></section>
        <section class="pz-p exp"><h4>البونص الاوشك على الانتهاء <label class="dy">الايام<input type="number" min="1" value="${BD.days}" data-days></label></h4><div class="pz-tb" data-exp></div></section></div>`;
      const expDraw = () => { const lim = addD(today(), BD.days), l = D.bonus.filter(x => isOn(x) && x.to && x.to >= today() && x.to <= lim && (x.branch || BR[0]) === BD.br);
        const rows = []; l.forEach(x => ((x.items || []).length ? x.items : [{ name: "(" + x.name + ") بدون أصناف" }]).forEach(it => rows.push([it.name, x.to])));
        body.querySelector("[data-exp]").innerHTML = `<div class="h two"><span>الصنف</span><span>تاريخ الانتهاء</span></div>${rows.length ? rows.map(r => `<div class="r two"><span>${esc(r[0])}</span><span>${esc(r[1])}</span></div>`).join("") : '<div class="pz-nodata">لا يوجد بونص ينتهي خلال ' + BD.days + ' أيام</div>'}`; };
      body.querySelector("[data-days]").addEventListener("input", e => { BD.days = Math.max(1, +e.target.value || 1); expDraw(); });
      expDraw();
      const got = BD.lines ? Promise.resolve(BD.lines) : fetchBonus(BD.per.from, BD.per.to).then(l => (BD.lines = l));
      got.then(l => { const by = {}; l.filter(x => x.type === "Sale").forEach(x => { const k = x.pid; by[k] = by[k] || { name: x.name, n: new Set(), q: 0, pid: x.pid }; by[k].n.add(x.id); by[k].q += (+x.qty || 0) * (+x.factor || 1); });
        const top = Object.values(by).sort((a, b) => b.q - a.q).slice(0, 30);
        body.querySelector("[data-top]").innerHTML = `<div class="h"><span>الصنف</span><span>عدد التعاملات</span><span>الكمية</span><span></span></div>${top.length ? top.map(t => `<div class="r"><span title="${esc(t.name)}">${esc(t.name)}</span><span>${t.n.size}</span><span>${fmt(t.q)}</span><button type="button" class="zb" data-rp="item:${t.pid}" title="حركة البونص مع الصنف">⌕</button></div>`).join("") : '<div class="pz-nodata">لا يوجد بونص في المبيعات لهذه الفترة</div>'}`;
      });
      fetchOverview(BD.per.from, BD.per.to).then(o => { body.querySelector("[data-chart]").innerHTML = bars(o.daily || []); body.querySelector("[data-stat]").innerHTML = donut(o.types || []); });
      body.onclick = e => { const z = e.target.closest("[data-rp]"); if (z) { const m = z.dataset.rp.split(":"); openReport({ k: "item", title: "حركة البونص مع صنف", type: "", pid: m[1] }); } };
    }
  }
  /* التقارير — مطابقة DEXEF (أسماء كاملة بدل المقطوعة) */
  const REPS = [["", [["item", "حركة البونص مع صنف"], ["all", "حركة البونص"], ["sort", "حركة البونص مرتبة بـ"], ["with", "حركة البونص مع"]]],
    ["فواتير المبيعات", [["Sale:all", "المبيعات موضحا البونص"], ["Sale:sort", "المبيعات موضحا البونص مرتبة بـ"], ["Sale:with", "حركة المبيعات موضحا البونص مع"]]],
    ["مرتجع المبيعات", [["SaleReturn:all", "مرتجع المبيعات موضحا البونص"], ["SaleReturn:sort", "مرتجع المبيعات موضحا البونص مرتبة بـ"], ["SaleReturn:with", "مرتجع المبيعات موضحا البونص مع"]]],
    ["المشتريات", [["Purchase:all", "المشتريات موضحا البونص"], ["Purchase:sort", "المشتريات موضحا البونص مرتبة بـ"], ["Purchase:with", "المشتريات موضحا البونص مع"]]],
    ["مرتجع المشتريات", [["PurchaseReturn:all", "مرتجع المشتريات موضحا البونص"], ["PurchaseReturn:sort", "مرتجع المشتريات موضحا البونص مرتبة بـ"], ["PurchaseReturn:with", "مرتجع المشتريات موضحا البونص مع"]]]];
  const TNAME = { Sale: "مبيعات", SaleReturn: "مرتجع مبيعات", Purchase: "مشتريات", PurchaseReturn: "مرتجع مشتريات" };
  function repTiles() {
    setTimeout(() => { const b = document.querySelector("#v_pz_bdash [data-body]"); if (b) b.onclick = e => { const t = e.target.closest("[data-rep]"); if (!t) return; const id = t.dataset.rep, m = id.split(":");
      openReport({ k: m.length > 1 ? m[1] : m[0], type: m.length > 1 ? m[0] : "", title: t.dataset.t }); }; }, 0);
    return `<div class="pz-reps">${REPS.map(g => `<div class="col"><h5>${esc(g[0])}</h5>${g[1].map((r, i) => `<button type="button" class="pz-rep${!g[0] && i === 0 ? " hot" : ""}" data-rep="${r[0]}" data-t="${esc(r[1])}">${IC.rep}<span>${esc(r[1])}</span></button>`).join("")}</div>`).join("")}</div>`;
  }
  function openReport(o) {
    const st = { from: BD.per.from, to: BD.per.to, sort: "date", by: "party", val: "", pid: o.pid || "" };
    const X = Dlg({ title: o.title, w: Math.min(1060, innerWidth - 40), noFoot: 1 });
    X.body.innerHTML = `<div class="pz-rp"><div class="pz-rpf"><label>من<input type="date" data-f="from" value="${st.from}"></label><label>إلى<input type="date" data-f="to" value="${st.to}"></label>
      ${o.k === "item" ? `<label>الصنف<input data-f="item" placeholder="اختر الصنف…" autocomplete="off" value="${esc(((prods().find(p => String(p.id) === String(st.pid)) || {}).name) || "")}"></label>` : ""}
      ${o.k === "sort" ? `<label>مرتبة بـ<select data-f="sort"><option value="date">التاريخ</option><option value="name">الصنف</option><option value="party">${o.type && o.type.startsWith("Purchase") ? "المورد" : "العميل"}</option><option value="qty">كمية البونص</option></select></label>` : ""}
      ${o.k === "with" ? `<label>مع<select data-f="by"><option value="party">${o.type && o.type.startsWith("Purchase") ? "المورد" : "العميل / المورد"}</option><option value="name">الصنف</option></select></label><label>القيمة<input data-f="val" placeholder="اكتب الاسم…" autocomplete="off"></label>` : ""}
      <span class="sp"></span><button type="button" class="fh-btn blue" data-go>عرض</button><button type="button" class="fh-btn" data-pr>طباعة</button><button type="button" class="fh-btn" data-xl>تصدير</button></div><div class="pz-rpg" data-g></div><div class="pz-rpt" data-t></div></div>`;
    const cols = [{ t: "التاريخ", w: "92px", f: r => r.date }, { t: "نوع المستند", w: "96px", f: r => TNAME[r.type] || r.type }, { t: "الرقم", w: "70px", f: r => r.no }, { t: "العميل / المورد", w: "minmax(110px,1fr)", f: r => r.party }, { t: "الكود", w: "96px", f: r => r.code }, { t: "الصنف", w: "minmax(150px,1.4fr)", f: r => r.name }, { t: "الوحدة", w: "80px", f: r => r.unit }, { t: "كمية البونص", w: "90px", f: r => fmt(r.qty), v: r => +r.qty, num: 1 }];
    const G = Grid(X.body.querySelector("[data-g]"), { cols, empty: "لا توجد حركة بونص" });
    let data = [];
    const go = () => { fetchBonus(st.from, st.to).then(l => {
        data = l.filter(r => (!o.type || r.type === o.type) && (!st.pid || String(r.pid) === String(st.pid)) && (o.k !== "with" || !st.val || norm(r[st.by] || "").includes(norm(st.val))));
        if (o.k === "sort") data.sort((a, b) => st.sort === "qty" ? b.qty - a.qty : String(a[st.sort] || "").localeCompare(String(b[st.sort] || ""), "ar"));
        G.set(data); X.body.querySelector("[data-t]").textContent = data.length ? "عدد الأسطر: " + data.length + " — إجمالي كمية البونص: " + fmt(data.reduce((s, r) => s + (+r.qty || 0), 0)) : ""; }); };
    X.body.addEventListener("change", e => { const f = e.target.dataset.f; if (f && f !== "item") { st[f] = e.target.value; if (f !== "val") go(); } });
    X.body.addEventListener("input", e => { if (e.target.dataset.f === "val") { st.val = e.target.value.trim(); go(); } });
    const it = X.body.querySelector('[data-f="item"]'); if (it) it.addEventListener("focus", () => suggest(it, p => { it.value = p.name; st.pid = p.id; go(); }));
    X.body.querySelector("[data-go]").addEventListener("click", go);
    X.body.querySelector("[data-pr]").addEventListener("click", () => printList(o.title + " (" + st.from + " — " + st.to + ")", cols, data));
    X.body.querySelector("[data-xl]").addEventListener("click", () => csvList(o.title, cols, data));
    if (o.k !== "item" || st.pid) go(); else setTimeout(() => it && it.focus(), 50);
  }

  /* ================================================================ 4) خصومات الفواتير */
  function invdiscDialog(x, br) {
    const X = pzDlg({ title: "الخصم على الفاتورة", w: 600, cls: "pz-iv", head: `<div class="pz-ivh">الخصم على الفاتورة</div>`,
      body: `<div class="pz-band"><div class="pz-lb r">بيانات أساسية</div><div class="pz-bx">${R("اسم الفرع", sel("branch", BR.map(b => [b, b]), 160), 1)}${R("اسم الخصم", inp("name", 230), 1)}${R("نشط", tg("active"))}</div></div>
        <div class="pz-band"><div class="pz-lb o">الشروط</div><div class="pz-bx">${R("اذا كانت قيمة الفاتورة أكبر من", inp("gt", 110, "num"), 1, "pzw1")}${R("و أقل من", inp("lt", 110, "num", "بدون حد"), 0, "pzw1")}
          ${R("طريقة تطبيق الخصم", sel("kind", KIND, 110, "%"), 1, "pzw1")}${R("الخصم", inp("val", 110, "num"), 1, "pzw1")}${R("متاح لمن يمتلك الصلاحية", ms("roles", 220, "كل الصلاحيات"), 0, "pzw1")}</div></div>
        <div class="pz-band"><div class="pz-lb">طرق التطبيق</div><div class="pz-bx">${R("يطبق تلقائياً على الفاتورة دون تدخل المستخدم", tg("auto"), 0, "pzw2")}
          ${R("يطبق خلال فترة معينة", tg("perOn") + `<span class="pz-dts" data-row="dts"><label>في الفترة من تاريخ ${inp("from", 125, "date")}</label><label>الى تاريخ ${inp("to", 125, "date")}</label></span>`, 0, "pzw2")}
          ${R("يطبق على التعاملات النقدية فقط", tg("cash"), 0, "pzw2")}${R("يطبق على التعاملات الأجلة فقط", tg("credit"), 0, "pzw2")}
          ${R("يطبق على أساس عملة معينة", tg("curOn") + `<span class="qd-sel" data-row="cur" style="width:110px"><select data-k="cur"><option>DZD</option><option>EUR</option><option>USD</option></select></span>`, 0, "pzw2")}</div></div>`,
      msOpts: () => UT,
      onToggle: (k, v, X) => { if (k === "cash" && v) X.set("credit", false); if (k === "credit" && v) X.set("cash", false); ui(); }, onOk: save });
    const ui = () => { X.vis("dts", X.get("perOn")); X.vis("cur", X.get("curOn")); const ki = X.root.querySelector('[data-ki="kind"]'); if (ki) ki.textContent = X.get("kind") === "v" ? "DZD" : "%"; };
    X.root.addEventListener("change", ui); X.q("roles").dataset.ph = "كل الصلاحيات"; X.q("roles")._opts = UT;
    const t = new Date(), v = x || { branch: br, kind: "p", roles: [], auto: false, perOn: false, from: ymd(t), to: ymd(addM(t, 1)), cash: false, credit: false, curOn: false, cur: "DZD", active: true };
    ["branch", "name", "gt", "lt", "kind", "val", "roles", "auto", "perOn", "from", "to", "cash", "credit", "curOn", "cur"].forEach(k => X.set(k, v[k])); X.set("active", v.active !== false);
    ui(); setTimeout(() => X.q("name").focus(), 30);
    function save(X) {
      const o = {}; ["branch", "gt", "lt", "kind", "val", "roles", "auto", "perOn", "from", "to", "cash", "credit", "curOn", "cur", "active"].forEach(k => o[k] = X.get(k)); o.name = X.get("name").trim();
      if (!o.name) return X.fail("name", "أدخل اسم الخصم");
      if (o.gt === "" || !(o.gt >= 0)) return X.fail("gt", "أدخل الحد الأدنى لقيمة الفاتورة");
      if (o.lt !== "" && !(o.lt > o.gt)) return X.fail("lt", "«أقل من» يجب أن تكون أكبر من «أكبر من»");
      if (!(o.val > 0)) return X.fail("val", "أدخل قيمة الخصم");
      if (o.kind === "p" && o.val > 100) return X.fail("val", "النسبة يجب ألا تتجاوز 100%");
      if (o.kind === "v" && o.val > o.gt && o.gt > 0) return X.fail("val", "قيمة الخصم أكبر من الحد الأدنى للفاتورة");
      if (o.perOn) { if (!o.from) return X.fail("from", "أدخل تاريخ البداية"); if (!o.to) return X.fail("to", "أدخل تاريخ النهاية"); if (o.to < o.from) return X.fail("to", "تاريخ النهاية قبل تاريخ البداية"); }
      const rec = x ? Object.assign(x, o) : Object.assign({ no: "" }, o);
      saveRec("invdisc", rec).then(() => { snd("save"); say("تم حفظ خصم الفاتورة: " + o.name, "s"); X.close(); }).catch(e => say(e.message, "e"));
    }
  }
  const S_INVD = cardScreen({ view: "pz_invd", kind: "invdisc", title: "خصومات الفواتير", status: true, cardIcon: IC.drop(40),
    desc: "هو خصم يتم احتسابه على اجمالي الفاتورة .. ولا يتم تسجيل قيد محاسبي بهذا الخصم .. ويمكن وضع شروط معينة لتنفيذ هذا النوع من الخصومات",
    addTip: "إضافة خصم", empty: "لا توجد خصومات فواتير .. اضغط + للإضافة",
    card: x => ({ t: x.name + "  " + fmt(x.val) + (x.kind === "p" ? "%" : " DZD") + (x.auto ? "  — تلقائي" : ""), d: ["أكبر من " + fmt(x.gt) + (x.lt !== "" && x.lt != null ? " وأقل من " + fmt(x.lt) : ""), x.perOn ? x.from + " ← " + x.to : ""] }),
    dialog: invdiscDialog });

  /* ================================================================ 5) شرائح الخصم (شبكة — مطابقة DEXEF) */
  const DX_SLICES = [["1مليون", 20], ["500 خمسة مئة الف", 10]];
  const DX_COUPONS = [["عملاء مميزين", 2, 50000, 500], ["عرض الصيف", 5, 5000, 200]];
  function seedDexef() {
    if (lsGet("pz.seeded", false)) return Promise.resolve();
    return Promise.all([load("slice"), load("coupon")]).then(() => {
      const jobs = [];
      if (!D.slice.length) jobs.push(DB.bulk("slice", DX_SLICES.map((s, i) => ({ no: "DX" + (i + 1), name: s[0], data: JSON.stringify({ branch: BR[0], pct: s[1], edit: true, notes: "", src: "dexef" }) }))));
      if (!D.coupon.length) jobs.push(DB.bulk("coupon", DX_COUPONS.map((c, i) => ({ no: String(i + 1), name: c[0], data: JSON.stringify({ branch: BR[0], pct: c[1], minInv: c[2], maxDisc: c[3], days: "", from: "", to: "", src: "dexef" }) })))
        .then(() => load("coupon", true)).then(() => Promise.all(D.coupon.filter(x => x.src === "dexef" && isOn(x)).map(x => { x.active = false; return saveRec("coupon", x); }))));   /* في DEXEF هذه الكوبونات غير نشطة */
      return Promise.all(jobs).then(() => { lsSet("pz.seeded", true); return Promise.all([load("slice", true), load("coupon", true)]); }).then(() => { emit("slice"); emit("coupon"); });
    }).catch(e => console.warn("seed", e));
  }
  function sliceDialog(x, br) {
    const X = pzDlg({ title: "شرائح الخصم", w: 400, cls: "pz-sl", head: `<div class="pz-slh">شرائح الخصم</div>`,
      body: `<div class="pz-slt">البيانات الاساسية</div><div class="qd-sec o">${R("الفرع", sel("branch", BR.map(b => [b, b]), 160), 1, "col")}${R("الاسم", inp("name", 280), 1, "col")}${R("نسبة الخصم", '<span class="pz-in">' + inp("pct", 90, "num") + '<b class="pz-u">%</b></span>', 1, "col")}</div>
        <div class="qd-sec">${R("الحاله", tg("active"), 0, "col")}${R("التعديل", '<label class="pz-ck"><input type="checkbox" data-k="edit"><span>يمكن التعديل على قيمة الخصم أثناء التعامل</span></label>', 0, "col")}</div>
        <div class="qd-sec slp-autosec"><div class="slp-autoh">✦ شريحة ذكية 2026</div>${R("تطبيق تلقائي", '<label class="pz-ck"><input type="checkbox" data-k="auto"><span>تُطبَّق وحدها في فاتورة المبيعات عندما يصل إجماليها إلى</span></label>', 0, "col")}${R("حد الفاتورة", '<span class="pz-in">' + inp("minInv", 140, "num", "مثال 500000") + '<b class="pz-u">DZD</b></span>', 0, "col")}</div>
        <div class="qd-sec">${R("ملاحظات", '<textarea class="pz-area" data-k="notes" rows="3"></textarea>', 0, "col wide")}</div>`, onOk: save });
    const v = x || { branch: br, pct: "", edit: true, notes: "", active: true, auto: false, minInv: "" };
    ["branch", "name", "pct", "edit", "notes", "auto", "minInv"].forEach(k => X.set(k, v[k])); X.set("active", v.active !== false);
    const mi = X.q("minInv"), ac = X.q("auto"), syncA = () => { mi.disabled = !ac.checked; mi.closest(".pz-r").style.opacity = ac.checked ? "" : ".55"; }; ac.addEventListener("change", () => { syncA(); if (ac.checked) mi.focus(); }); syncA();
    const at = X.q("active"); const lab = () => { at.querySelector("span").textContent = at.classList.contains("on") ? "نشط" : "غير نشط"; }; lab(); at.addEventListener("click", () => setTimeout(lab, 0));
    setTimeout(() => X.q("name").focus(), 30);
    function save(X) {
      const o = { branch: X.get("branch"), name: X.get("name").trim(), pct: X.get("pct"), edit: X.get("edit"), notes: X.get("notes"), active: X.get("active"), auto: !!X.get("auto"), minInv: X.get("minInv") };
      if (!o.name) return X.fail("name", "أدخل اسم الشريحة");
      if (!(o.pct > 0) || o.pct > 100) return X.fail("pct", "نسبة الخصم يجب أن تكون بين 0 و 100");
      if (o.auto && !(+o.minInv > 0)) return X.fail("minInv", "أدخل حد الفاتورة للتطبيق التلقائي");
      if (!o.auto) o.minInv = "";
      const rec = x ? Object.assign(x, o) : Object.assign({ no: "" }, o);
      saveRec("slice", rec).then(() => { snd("save"); say("تم حفظ الشريحة: " + o.name, "s"); X.close(); }).catch(e => say(e.message, "e"));
    }
  }
  function gridScreen(cfg) {
    const v = cfg.view, el = mkView(v, cfg.title);
    const st = { br: BR[0], st: "on", q: "" };
    let G = null;
    if (!el.dataset.b) {
      el.dataset.b = "1"; el.classList.add("pz-vw", "pz-gv");
      el.innerHTML = cfg.layout === "slice"
        ? `<div class="pz-gs"><h2>${esc(cfg.title)}</h2><p>${esc(cfg.desc)}</p><div class="pz-gbar"><button type="button" class="pz-new" data-add>جديد</button><span class="qd-sel" style="width:160px"><select data-br>${BR.map(b => `<option>${esc(b)}</option>`).join("")}</select></span>
            <span class="qd-sel pz-stsel" style="width:110px"><select data-st><option value="on">نشط</option><option value="off">غير نشط</option><option value="all">الكل</option></select></span><span class="sp"></span>
            <button type="button" class="pz-tb" data-cols>${H.IC.cols}<span>اختيار الحقول</span></button><button type="button" class="pz-tb" data-print>${H.IC.print}<span>عرض للطباعة</span></button></div><div class="slp-strip" data-strip></div><div class="pz-gw" data-g></div></div>`
        : `<div class="qdv pz-v"><div class="qdv-top pz-top"><div><label>البحث</label><div class="qdv-sbox"><span>${SRCH}</span><input data-q placeholder="Enter text to search..." autocomplete="off"></div></div><button type="button" class="qdv-add" data-add aria-label="إضافة">+</button>
            <div class="pz-tf"><label>اسم الفرع</label><span class="qd-sel" style="width:160px"><select data-br>${BR.map(b => `<option>${esc(b)}</option>`).join("")}</select></span></div>
            <div class="pz-tf"><label>الحالة</label><span class="qd-sel" style="width:110px"><select data-st><option value="on">نشط</option><option value="off">غير نشط</option><option value="all">الكل</option></select></span></div></div>
            <div class="qdv-body pz-cb"><div class="qdv-info"><h1>${esc(cfg.title)}</h1><p>${esc(cfg.desc)}</p></div><div class="pz-gw" data-g></div></div></div>`;
      const hid = new Set(lsGet("pz.hide." + v, []));
      const mk = () => { const g = el.querySelector("[data-g]"); g.innerHTML = ""; G = Grid(g, { cols: cfg.cols.filter((c, i) => !hid.has(i)), empty: cfg.empty, onOpen: r => cfg.dialog(r, st.br), onDel: r => del(r),
        ctx: (r, e) => ctxMenu([["تعديل", "Enter", "", () => cfg.dialog(r, st.br)], [isOn(r) ? "إيقاف" : "تنشيط", "", "", () => { r.active = !isOn(r); saveRec(cfg.kind, r); }], ["حذف", "Del", "", () => del(r)]], { x: e.clientX, y: e.clientY }) }); el._G = G; draw(); };
      el._mk = mk;
      el.querySelector("[data-add]").addEventListener("click", () => cfg.dialog(null, st.br));
      el.querySelector("[data-br]").addEventListener("change", e => { st.br = e.target.value; draw(); });
      el.querySelector("[data-st]").addEventListener("change", e => { st.st = e.target.value; draw(); });
      const q = el.querySelector("[data-q]"); if (q) q.addEventListener("input", () => { st.q = q.value.trim(); draw(); });
      const c = el.querySelector("[data-cols]"); if (c) c.addEventListener("click", () => H.fieldsChooser(cfg.title, cfg.cols, h => { hid.clear(); h.forEach(i => hid.add(i)); lsSet("pz.hide." + v, Array.from(hid)); mk(); }, Array.from(hid)));
      const pr = el.querySelector("[data-print]"); if (pr) pr.addEventListener("click", () => printList(cfg.title, cfg.cols.filter((c2, i) => !hid.has(i)), curList()));
      on(cfg.kind, () => draw());
      el._st = st; mk();
    }
    function curList() { const s = el._st || st; return D[cfg.kind].filter(x => (x.branch || BR[0]) === s.br && (s.st === "all" || (s.st === "on") === isOn(x)) && (!s.q || norm(x.name + " " + (x.no || "")).includes(norm(s.q)))).sort((a, b) => (parseInt(a.no, 10) || 0) - (parseInt(b.no, 10) || 0)); }
    function draw() { if (el._G) el._G.set(curList()); if (cfg.kind === "slice") stripDraw(); }
    /* ✦ بطاقات الشرائح (2026): كل شريحة نشطة ببطاقة — النسبة كبيرة ، الاسم ، وحد التطبيق التلقائي */
    function stripDraw() {
      const box = el.querySelector("[data-strip]"); if (!box) return;
      const L = curList().filter(isOn).sort((a, b) => (+a.pct || 0) - (+b.pct || 0));
      box.innerHTML = L.map((x, i) => `<button type="button" class="slp-card t${i % 5}" data-sid="${x.id}"><span class="slp-cp">${fmt(+x.pct || 0).replace(/\.00$/, "")}<i>%</i></span><span class="slp-cb"><b>${esc(x.name)}</b><small>${x.auto && +x.minInv ? "⚡ تلقائي من " + fmt(x.minInv) + " DZD" : "يدوي — يُختار من الفاتورة"}</small></span></button>`).join("")
        + `<button type="button" class="slp-card add" data-sadd><span class="slp-cp">+</span><span class="slp-cb"><b>شريحة جديدة</b><small>نسبة · حد تلقائي</small></span></button>`;
      if (!box.dataset.w) { box.dataset.w = "1"; box.addEventListener("click", e => { const c = e.target.closest("[data-sid]"); if (c) { const r = D.slice.find(z => String(z.id) === c.dataset.sid); if (r) cfg.dialog(r, (el._st || st).br); } else if (e.target.closest("[data-sadd]")) cfg.dialog(null, (el._st || st).br); }); }
    }
    function del(r) { ask("هل تريد حذف «" + r.name + "» ؟", () => delRec(cfg.kind, r).then(() => { snd("del"); say("تم الحذف", "e"); }).catch(e => say(e.message, "e"))); }
    tabOpen(v, cfg.title, v); load(cfg.kind).then(draw);
  }
  const openSlices = () => seedDexef().then(() => gridScreen({ view: "pz_slice", kind: "slice", title: "شرائح الخصم", layout: "slice", empty: "لا توجد شرائح خصم",
    desc: "هو خصم تجارى يقدم الى العميل فى صورة نسبة مئوية . و يمكن ان يقدم اكثر من خصم للعميل فى الفاتورة الواحدة",
    cols: [{ t: "الاسم", w: "minmax(220px,1.4fr)", f: r => r.name }, { t: "نسبة الخصم", w: "200px", f: r => (+r.pct || 0).toFixed(2) + "%", v: r => +r.pct || 0, num: 1 }, { t: "تلقائي من", w: "170px", f: r => r.auto && +r.minInv ? fmt(r.minInv) + " DZD" : "—", v: r => r.auto ? +r.minInv || 0 : 0, num: 1 }, { t: "الملاحظات", w: "minmax(200px,1.2fr)", f: r => r.notes || "" }, { t: "الحالة", w: "110px", chk: 1, v: r => isOn(r) }],
    dialog: sliceDialog }));

  /* ================================================================ 6) كوبونات الخصم */
  function couponDialog(x, br) {
    const X = pzDlg({ title: "كوبونات الخصم", w: 530, cls: "pz-cp", head: "", side: IC.calc + '<label class="pz-ck v"><input type="checkbox" data-k="active"><span>نشط</span></label>',
      body: `<div class="qd-sec o">${R("اسم الفرع", sel("branch", BR.map(b => [b, b]), 170), 1, "col")}<div class="pz-2">${R("الرقم", inp("no", 80), 1, "col")}${R("الاسم", inp("name", 230), 1, "col")}</div></div>
        <div class="qd-sec">${R("نسبة الخصم", '<span class="pz-in">' + inp("pct", 90, "num") + '<b class="pz-u">%</b></span>', 1, "col")}${R("ينتهي صلاحية بعد مرور", '<span class="pz-in">' + inp("days", 90, "num", "اختياري") + '<b class="pz-u">يوم</b></span>', 0, "col")}
          <div class="pz-2">${R("تاريخ بداية العرض", inp("from", 125, "date"), 1, "col")}${R("تاريخ انتهاء العرض", inp("to", 125, "date"), 1, "col")}</div>
          <div class="pz-2">${R("أقل قيمة للفاتورة", inp("minInv", 120, "num"), 0, "col")}${R("لا تزيد قيمة الخصم عن", '<span class="pz-in">' + inp("maxDisc", 120, "num", "بدون حد") + '<b class="pz-u">DZD</b></span>', 0, "col")}</div></div>`,
      okText: "موافق", closeText: "إلغاء", onOk: save });
    const t = new Date(), v = x || { branch: br, pct: "", days: "", from: ymd(t), to: ymd(addM(t, 1)), minInv: "", maxDisc: "", active: true };
    ["branch", "name", "pct", "days", "from", "to", "minInv", "maxDisc"].forEach(k => X.set(k, v[k])); X.set("active", v.active !== false);
    X.q("days").addEventListener("input", () => { const d = parseInt(X.q("days").value, 10), f = X.get("from"); if (d > 0 && f) X.set("to", addD(f, d)); });
    if (x) X.set("no", x.no); else nextNo("coupon").then(n => X.set("no", n));
    setTimeout(() => X.q(x ? "name" : "name").focus(), 30);
    function save(X) {
      const o = {}; ["branch", "pct", "days", "from", "to", "minInv", "maxDisc", "active"].forEach(k => o[k] = X.get(k)); o.name = X.get("name").trim(); const no = String(X.get("no") || "").trim();
      if (!no) return X.fail("no", "أدخل رقم الكوبون");
      if (D.coupon.some(c => String(c.no) === no && (!x || c.id !== x.id))) return X.fail("no", "رقم الكوبون " + no + " مستخدم من قبل");
      if (!o.name) return X.fail("name", "أدخل اسم الكوبون");
      if (!(o.pct > 0) || o.pct > 100) return X.fail("pct", "نسبة الخصم يجب أن تكون بين 0 و 100");
      if (!o.from) return X.fail("from", "أدخل تاريخ بداية العرض"); if (!o.to) return X.fail("to", "أدخل تاريخ انتهاء العرض");
      if (o.to < o.from) return X.fail("to", "تاريخ الانتهاء قبل تاريخ البداية");
      const rec = x ? Object.assign(x, o, { no }) : Object.assign({ no }, o);
      saveRec("coupon", rec).then(() => { snd("save"); say("تم حفظ الكوبون: " + o.name, "s"); X.close(); }).catch(e => say(e.message, "e"));
    }
  }
  const couponEnd = x => { let e = x.to || ""; if (+x.days > 0 && x.from) { const d = addD(x.from, +x.days); if (!e || d < e) e = d; } return e; };
  const openCoupons = () => seedDexef().then(() => gridScreen({ view: "pz_coupon", kind: "coupon", title: "كوبونات الخصم", empty: "لا توجد كوبونات",
    desc: "هى كوبونات يتم اعطائها للعملاء .. بنسبة خصم معينة ولها تاريخ صلاحية . تشجع العملاء للرجوع و الشراء مرة أخرى و استخدام هذا الكوبون",
    cols: [{ t: "الرقم", w: "110px", f: r => r.no, v: r => parseInt(r.no, 10) || 0 }, { t: "الاسم", w: "minmax(200px,1.6fr)", f: r => r.name }, { t: "نسبة الخصم", w: "110px", f: r => fmt(r.pct), v: r => +r.pct, num: 1 },
      { t: "حتى تاريخ", w: "130px", f: r => couponEnd(r) }, { t: "قيمة الفاتورة", w: "120px", f: r => r.minInv === "" || r.minInv == null ? "" : fmt(r.minInv), v: r => +r.minInv || 0, num: 1 }, { t: "حد أقصى للخصم", w: "130px", f: r => r.maxDisc === "" || r.maxDisc == null ? "" : fmt(r.maxDisc), v: r => +r.maxDisc || 0, num: 1 }],
    dialog: couponDialog }));

  /* ================================================================ محرك الخصومات في فاتورة المبيعات */
  const curBr = () => BR[0];
  const curTier = () => { try { return window.__saleTier ? __saleTier() : "1"; } catch (e) { return "1"; } };
  const inRet = () => !!document.querySelector(".inv.retmode");
  const rowProd = r => r && r.pid ? prods().find(p => String(p.id) === String(r.pid)) : null;
  /* «الأذواق»: سطر صنف مجمّع (MILKA B+bu+E…) ← كل أذواق العائلة؛ خصم/بونص/خصم كمية على ذوق واحد يُطبَّق على الصنف المجمّع */
  const famOf = (r, p) => { try { return window.ANOUER_FLV ? ANOUER_FLV.members(r && r.pid != null ? r.pid : p.id) : null; } catch (e) { return null; } };
  const candOf = (r, p) => { const own = [{ id: r.pid, code: p ? p.code : null }], fm = famOf(r, p); return fm ? own.concat(fm.filter(m => String(m.id) !== String(r.pid)).map(m => ({ id: m.id, code: m.code }))) : own; };
  const itemMatch = (x, r, p) => { const L = x.items || []; for (const c of candOf(r, p)) { const it = L.find(it => (it.pid && String(it.pid) === String(c.id)) || (it.code && c.code != null && String(it.code) === String(c.code))); if (it) return it; } return null; };
  const codeMatch = (items, r, p) => { const L = items || []; for (const c of candOf(r, p)) { if (c.code == null || c.code === "") continue; const it = L.find(i => i && i.code && String(i.code) === String(c.code)); if (it) return it; } return null; };
  const rowF = r => { try { return typeof unitFactor === "function" ? unitFactor(r) : (+r.factor || 1); } catch (e) { return +r.factor || 1; } };
  /* كمية العرض/الخصم حسب الإعداد «كيفية إحتساب كمية البونص فى الفاتورة» (الخصائص ← المخازن ← خصائص المخزون) */
  function qtyBy(r, p) {
    const f = rowF(r) || 1, base = (+r.qty || 0) * f;
    let m = "بالوحدة الصغرى"; try { m = (window.ANOUER_PROPS && ANOUER_PROPS.get("wh.stock", {}).bonusQty) || m; } catch (e) { }
    if (m === "بوحدة الفاتورة") return +r.qty || 0;
    if (m === "بالوحدة الكبرى") { const mx = Math.max(1, ...((p && p._u) || []).map(u => +u.factor || 1)); return base / mx; }
    return base;
  }
  /* الشريحة المطابقة؛ الكمية الأكبر من آخر شريحة تأخذ آخر شريحة (الخصم يزداد مع الكمية) */
  function tierOf(tiers, q) {
    const T = (tiers || []).filter(t => t && t.to !== "" && t.to != null).slice().sort((a, b) => (+a.from || 0) - (+b.from || 0)); if (!T.length || !(q > 0)) return null;
    const hit = T.find((t, i) => q >= (+t.from || 0) && (q < +t.to || (i === T.length - 1 ? q <= +t.to : q === +t.to)));
    return hit || (q > +T[T.length - 1].to ? T[T.length - 1] : null);
  }
  function idiscBest(r, p, price) {
    let best = null; if (!featOk("idisc")) return null;
    D.idisc.forEach(x => { if (!isOn(x) || (x.apply || "s") === "p" || (x.branch || curBr()) !== curBr() || !inPer(x) || !roleOk(x)) return;
      if (x.lvOn && (x.levels || []).length && !x.levels.includes(curTier())) return;
      const it = itemMatch(x, r, p); if (!it) return;
      if (x.endQty && +it.qty > 0 && (+it.used || 0) >= +it.qty) return;
      const v = +x.sval || 0, d = x.kind === "v" ? v : price * v / 100;   /* بالقيمة: على وحدة البيع في السطر */
      if (d > 0 && (!best || d > best.d)) best = { d, x }; });
    return best;
  }
  /* خصم الصنف النشط لصنف في نتائج البحث (عمود «سعر تعريفي») — يشمل الصنف المجمّع إن كان أحد أذواقه عليه خصم */
  window.__pzProd = (p, basePrice) => {
    try { if (!p || inRet()) return null; const pr = +basePrice || +p.price || 0; if (!(pr > 0)) return null;
      const b = idiscBest({ pid: p.id, price: pr, qty: 1 }, p, pr); if (!b) return null; const d = Math.min(b.d, pr);
      const it = itemMatch(b.x, { pid: p.id }, p), ip = it && (it.pid || it.code) ? prodOf(it) : null;
      return { name: b.x.name, d, per: pr - d, pct: d / pr * 100, val: b.x.kind === "v" ? fmt(b.x.sval) + " DZD" : fmt(b.x.sval) + "%", to: b.x.to || "", via: ip && String(ip.id) !== String(p.id) ? ip.name : "" };
    } catch (e) { return null; }
  };
  /* شرائح «خصم الكمية» النشطة لصنف (لتيكت الأسعار AUTO): [{from, kind:"p"|"v", val, name}] — تشمل عائلة «الأذواق» */
  window.__qdTiers = p => {
    try {
      const QDL = window.__QD && __QD.list; if (!QDL || !p || !featOk("qdisc")) return [];
      let hit = null;
      QDL.forEach(x => { if (hit || !x.active || (x.branch || curBr()) !== curBr() || !inPer(x)) return;
        const it = codeMatch(x.items, { pid: p.id }, p); if (!it) return;
        if (+it.qty > 0 && (+it.used || 0) >= +it.qty) return;
        const T = (x.tiers || []).filter(t => t && t.to !== "" && t.to != null && +t.pct > 0).map(t => ({ from: Math.max(1, Math.ceil(+t.from || 0)), val: +t.pct })).sort((a, b) => a.from - b.from);
        if (T.length) hit = { x, T }; });
      return hit ? hit.T.map(t => ({ from: t.from, kind: hit.x.kind === "v" ? "v" : "p", val: t.val, name: hit.x.name, end: hit.x.to || "" })) : [];
    } catch (e) { return []; }
  };
  function promoFor(r) {
    const out = { disc: 0, tags: [], bonus: 0 };
    if (!r || !r.pid || r.ret || inRet()) return out;
    const p = rowProd(r), price = +r.price || 0, f = rowF(r) || 1, qb = qtyBy(r, p);
    /* خصومات الأصناف */
    const best = idiscBest(r, p, price);
    if (best) { out.disc += best.d; out.tags.push({ t: best.x.name, v: best.x.kind === "v" ? fmt(best.x.sval) + " DZD" : fmt(best.x.sval) + "%", k: "idisc", id: best.x.id }); }
    /* خصم الكمية (شاشة خصم الكمية) */
    try {
      const QDL = window.__QD && __QD.list;
      if (QDL && featOk("qdisc")) {
        let bq = null;
        QDL.forEach(x => { if (!x.active || (x.branch || curBr()) !== curBr() || !inPer(x)) return;
          const it = codeMatch(x.items, r, p); if (!it) return;
          if (+it.qty > 0 && (+it.used || 0) >= +it.qty) return;   /* «الكمية» المحددة للصنف نفدت */
          const base = +r.qty || 0;   /* الشرائح بكمية الفاتورة كما تُكتب في السطر (10 كراتين = 10) */
          const tr = tierOf(x.tiers, base); if (!tr) return;
          const d = x.kind === "v" ? (+tr.pct || 0) : price * (+tr.pct || 0) / 100;   /* بالقيمة: على وحدة البيع في السطر (الكرتونة/القطعة) */
          if (d > 0 && (!bq || d > bq.d)) bq = { d, x, tr }; });
        if (bq) { out.disc += bq.d; out.tags.push({ t: bq.x.name, v: bq.x.kind === "v" ? fmt(bq.tr.pct) + " DZD" : fmt(bq.tr.pct) + "%", k: "qd", qd: bq.x }); }
      }
    } catch (e) { }
    out.disc = Math.min(out.disc, price);
    /* البونص */
    let bb = 0, bx = null;
    if (featOk("bonus")) D.bonus.forEach(x => { if (!isOn(x) || (x.branch || curBr()) !== curBr() || !inPer(x)) return; if (!itemMatch(x, r, p)) return;
      (x.tiers || []).forEach(t => { if (qb >= t.offer && t.offer > 0) { const b = Math.floor(qb / t.offer) * t.bonus; if (b > bb) { bb = b; bx = x; } } }); });
    if (bb > 0) { const uf = qb > 0 ? ((+r.qty || 0) * f) / qb : 1; out.bonus = r2(bb * uf); out.tags.push({ t: bx.name, v: "+" + fmt(out.bonus) + " بونص", k: "bonus" }); }   /* البونص دائماً بالوحدة الصغرى */
    return out;
  }
  function invAuto(before) {
    if (!featOk("invdisc")) return null;
    let best = null; const deal = window.__saleDeal ? __saleDeal() : "cash";
    D.invdisc.forEach(x => { if (!isOn(x) || !x.auto || (x.branch || curBr()) !== curBr() || !roleOk(x)) return;
      if (x.perOn && !inPer(x)) return; if (x.cash && deal !== "cash") return; if (x.credit && deal !== "credit") return; if (x.curOn && x.cur && x.cur !== "DZD") return;
      if (!(before > (+x.gt || 0))) return; if (x.lt !== "" && x.lt != null && !(before < +x.lt)) return;
      const d = x.kind === "v" ? +x.val : before * (+x.val) / 100; if (d > 0 && (!best || d > best.d)) best = { d, x }; });
    return best;
  }
  function couponFind(code) {
    const c = String(code || "").trim(); if (!c) return null;
    return D.coupon.find(x => String(x.no) === c) || D.coupon.find(x => norm(x.name) === norm(c)) || null;
  }
  function couponCheck(x, before) {
    if (!featOk("coupon")) return "«كوبونات الخصم» إضافة تحتاج تفعيل — اطلب كود التفعيل";
    if (!x) return "رقم الكوبون غير صحيح";
    if (!isOn(x)) return "الكوبون «" + x.name + "» غير نشط";
    if ((x.branch || curBr()) !== curBr()) return "الكوبون لا يخص هذا الفرع";
    const d = today(), end = couponEnd(x);
    if (x.from && d < x.from) return "الكوبون يبدأ في " + x.from;
    if (end && d > end) return "انتهت صلاحية الكوبون في " + end;
    if (+x.minInv > 0 && before < +x.minInv) return "أقل قيمة للفاتورة لاستخدام الكوبون: " + fmt(x.minInv) + " DZD";
    return "";
  }
  function couponAmt(x, before) { let a = before * (+x.pct || 0) / 100; if (+x.maxDisc > 0) a = Math.min(a, +x.maxDisc); return r2(a); }

  /* ربط الفاتورة: صافي السعر، البونص، الشارات، خصم الفاتورة، الكوبون، الشرائح */
  function hookInvoice() {
    if (typeof lineNet !== "function" || typeof renderRows !== "function") return;
    const _ln = lineNet;
    /* صافي السعر يبقى من سعر الوحدة (لا يُنقصه خصم الصنف/الكمية) — الخصم يظهر في «الخصم» أسفل الإجمالي */
    window.lineNet = lineNet = function (r) { const b = _ln.apply(this, arguments); if (r && r.pid) r._pz = promoFor(r); return b; };
    const pzBase = r => { const z = r && r.pid ? (r._pz = promoFor(r)) : null; return z && z.disc > 0 ? r2(z.disc * (+r.qty || 0) * (_ln(r) / (+r.price || 1) || 1)) : 0; };
    /* + خصومات السطر اليدوية من أعمدة Customization (sales-cols.js): خصم الصنف/الكميه/النقدى/المجاني/ضريبة الخصم */
    const pzLine = r => { const b = pzBase(r); try { return window.__rowXLine ? __rowXLine(r, b) : b; } catch (e) { return b; } };
    window.__pzLineDisc = pzLine; window.__pzBase = pzBase;
    const _rr = renderRows;
    window.renderRows = renderRows = function () {
      const res = _rr.apply(this, arguments);
      try { (rows || []).forEach((r, i) => { const z = r && r._pz; if (!z || !z.tags.length) return; const g = document.querySelector(`#gbody .gr[data-row="${i}"]`); if (!g) return;
        const nc = g.querySelector('[data-c="n"]'), dsc = z.tags.filter(t => t.k !== "bonus");
        if (nc && dsc.length) { nc.insertAdjacentHTML("afterbegin", `<i class="pz-tag" title="${esc(dsc.map(t => t.t + ": " + t.v).join(" + "))}">−${esc(dsc.map(t => t.v).join("+"))}</i>`); }
        const bn = z.tags.find(t => t.k === "bonus"), qc = g.querySelector('[data-c="q"]');
        if (bn && qc) qc.insertAdjacentHTML("beforeend", `<i class="pz-bn" title="${esc(bn.t)}: ${esc(bn.v)} (سطر مجاني عند الحفظ)">+${fmt(z.bonus)}</i>`); }); } catch (e) { }
      return res;
    };
    if (typeof calc === "function") {
      const _c = calc;
      window.calc = calc = function () {
        try {
          const gross = (rows || []).reduce((s, r) => s + lineTot(r), 0);
          adj.pdisc = inRet() ? 0 : r2((rows || []).reduce((s, r) => s + (r && !r.ret ? pzLine(r) : 0), 0));   /* خصومات الأصناف + خصم الكمية */
          const before = gross - adj.pdisc;
          const a = inRet() ? null : invAuto(before);
          adj.idisc = a ? r2(a.d) : 0; adj.idiscName = a ? a.x.name : "";
          if (adj.couponId) { const x = D.coupon.find(c => String(c.id) === String(adj.couponId)); const m = couponCheck(x, before); adj.coupon = m ? 0 : couponAmt(x, before); }
        } catch (e) { }
        const t = _c.apply(this, arguments);
        try { const el = document.getElementById("tDisc"); if (el) { const parts = []; if (adj.pdisc) parts.push("خصومات الأصناف / الكمية: " + fmt(adj.pdisc)); if (adj.cash) parts.push("نقدي: " + fmt(adj.cash)); if (adj.coupon) parts.push("كوبون " + (adj.couponCode || "") + ": " + fmt(adj.coupon)); if (adj.idisc) parts.push("خصم الفاتورة «" + adj.idiscName + "»: " + fmt(adj.idisc)); el.title = parts.join(" + "); el.classList.toggle("pz-auto", !!(adj.idisc || adj.pdisc)); } } catch (e) { }
        return t;
      };
    }
    /* حفظ: الكمية المستخدمة لخصومات الأصناف المحدودة */
    if (typeof doSave === "function") {
      const _ds = doSave;
      window.doSave = doSave = function () {
        const snap = (rows || []).filter(r => r && r.pid && +r.qty > 0 && r._pz).map(r => ({ r, z: r._pz }));
        const res = _ds.apply(this, arguments);
        try { const touched = new Set(); snap.forEach(o => o.z.tags.filter(t => t.k === "idisc").forEach(t => { const x = D.idisc.find(y => y.id === t.id); if (!x || !x.endQty) return; const it = itemMatch(x, o.r, rowProd(o.r)); if (it) { it.used = (+it.used || 0) + (+o.r.qty || 0) * rowF(o.r); touched.add(x); } }));
          touched.forEach(x => saveRec("idisc", x));
          snap.forEach(o => o.z.tags.filter(t => t.k === "qd" && t.qd).forEach(t => { const p = rowProd(o.r), it = codeMatch(t.qd.items, o.r, p); if (it && +it.qty > 0) { it.used = (+it.used || 0) + (+o.r.qty || 0) * rowF(o.r); qdSave(t.qd); } }));
        } catch (e) { }
        return res;
      };
    }
  }
  /* نافذة الكوبون (F9): كوبونات حقيقية بدل الأكواد التجريبية */
  function hookCoupon() {
    if (typeof openM !== "function" || typeof confirmM !== "function") return;
    const _om = openM, _cm = confirmM;
    window.openM = openM = function (m) {
      const res = _om.apply(this, arguments);
      try {
        if (m === "coupon" && !window.ANOUER_CPN) {
          const t = calc(), ok = D.coupon.filter(x => !couponCheck(x, t.before));
          document.getElementById("mBody").innerHTML = `<div class="r"><span>رقم الكوبون</span><input id="mVal" value="${esc(adj.couponCode || "")}" placeholder="رقم أو اسم الكوبون" autocomplete="off"></div>
            <div class="pz-cpl">${ok.length ? ok.map(x => `<button type="button" data-cp="${esc(x.no)}"><b>${esc(x.no)}</b> ${esc(x.name)} — ${fmt(x.pct)}%${+x.maxDisc > 0 ? " (حد " + fmt(x.maxDisc) + ")" : ""}</button>`).join("") : '<span class="n">لا توجد كوبونات صالحة لهذه الفاتورة</span>'}</div>
            ${adj.couponCode ? '<div class="pz-cpc">الكوبون الحالي: ' + esc(adj.couponCode) + " — اترك الحقل فارغاً لإلغائه</div>" : ""}`;
          const v = document.getElementById("mVal"); v.focus(); v.select(); v.addEventListener("keydown", e => { if (e.key === "Enter") confirmM(); });
          document.querySelector(".pz-cpl").addEventListener("click", e => { const b = e.target.closest("[data-cp]"); if (b) { v.value = b.dataset.cp; confirmM(); } });
        } else if (m === "disc" && !window.ANOUER_DPAD) {
          const t = calc(), l = (featOk("invdisc") ? D.invdisc : []).filter(x => isOn(x) && !x.auto && (x.branch || curBr()) === curBr() && roleOk(x) && (!x.perOn || inPer(x)) && t.before > (+x.gt || 0) && (x.lt === "" || x.lt == null || t.before < +x.lt));
          if (l.length) { document.getElementById("mBody").insertAdjacentHTML("beforeend", `<div class="pz-cpl"><span class="h">خصومات الفواتير المتاحة:</span>${l.map(x => `<button type="button" data-ix="${x.id}">${esc(x.name)} — ${fmt(x.val)}${x.kind === "p" ? "%" : " DZD"}</button>`).join("")}</div>`);
            document.querySelector(".pz-cpl").addEventListener("click", e => { const b = e.target.closest("[data-ix]"); if (!b) return; const x = D.invdisc.find(y => String(y.id) === b.dataset.ix); document.getElementById("mType").value = x.kind === "p" ? "p" : "v"; document.getElementById("mVal").value = x.val; }); }
        }
      } catch (e) { console.warn(e); }
      return res;
    };
    window.confirmM = confirmM = function () {
      try {
        if (mode === "coupon") {
          const v = (document.getElementById("mVal").value || "").trim(), t = calc();
          if (!v) { adj.coupon = 0; adj.couponCode = ""; adj.couponId = null; toast("تم إلغاء الكوبون", "i"); closeM(); calc(); return; }
          const x = couponFind(v), m = couponCheck(x, t.before);
          if (m) { toast(m, "e"); return; }
          adj.couponId = x.id; adj.couponCode = x.no; adj.coupon = couponAmt(x, t.before);
          toast("تم تطبيق الكوبون «" + x.name + "»: خصم " + fmt(x.pct) + "% = " + fmt(adj.coupon) + " DZD", "s"); closeM(); calc(); return;
        }
      } catch (e) { console.warn(e); }
      return _cm.apply(this, arguments);
    };
    if (typeof resetInv === "function") { const _ri = resetInv; window.resetInv = resetInv = function () { const r = _ri.apply(this, arguments); try { adj.couponId = null; adj.idisc = 0; } catch (e) { } return r; }; }
  }
  /* شرائح الخصم ← قائمة «شرائح الخصم» في فاتورة المبيعات والمشتريات وبطاقات العملاء/الموردين */
  /* ✦ نسخة العملاء: «شرائح الخصم» إضافة بتفعيل (ANOUER_LIC «slices» — تجربة ثم كود) ، وفي LITE تحتاج PRO */
  let _lk = { t: 0, v: false };
  const slLiteLock = () => !!(window.ANOUER_LITE && ANOUER_LITE.on && ANOUER_LITE.pro && !ANOUER_LITE.pro());
  const slLicLock = () => { _fo.slices = null; return !!((window.ANOUER_EDITION || {}).dist && window.ANOUER_LIC && !ANOUER_LIC.ok("slices")); };
  const slLocked = force => { const n = Date.now(); if (force || n - _lk.t > 4000) _lk = { t: n, v: slLiteLock() || slLicLock() }; return _lk.v; };
  const slUnlock = run => { const go = () => { _lk.t = 0; try { fillSlices(); } catch (e) { } run && run(); };
    if (slLiteLock()) return ANOUER_LITE.gate("شرائح الخصم", go);
    if ((window.ANOUER_EDITION || {}).dist && window.ANOUER_LIC) return ANOUER_LIC.gate("slices", go);
    go(); };
  function fillSlices() {
    const act = slLocked(true) ? [] : D.slice.filter(x => isOn(x) && (x.branch || curBr()) === curBr()).sort((a, b) => (+a.pct || 0) - (+b.pct || 0));
    const s = document.getElementById("slice");
    if (s) { const v = s.value; s.innerHTML = '<option value="0">-</option>' + act.map(x => `<option value="${(+x.pct || 0) / 100}" title="${esc(x.name)} — ${fmt(x.pct)}%">${esc(x.name)}</option>`).join(""); if (Array.from(s.options).some(o => o.value === v)) s.value = v; else if (v !== "0") { s.value = "0"; try { renderRows(); } catch (e) { } } s.title = "شرائح الخصم — تُدار من الإضافات ← شرائح الخصم"; }
    try { const SL = P() && P().slices; if (SL) { SL.length = 1; act.forEach(x => SL.push([x.name + " (" + fmt(x.pct) + "%)", +x.pct || 0])); } } catch (e) { }
  }
  document.addEventListener("focusin", e => { const t = e.target; if (!t.matches || !t.matches('select[data-f="disc"]')) return;
    const v = t.value, act = D.slice.filter(isOn); t.innerHTML = '<option value=""></option>' + act.map(x => `<option>${esc(x.name)}</option>`).join("") + (v && !act.some(x => x.name === v) ? `<option>${esc(v)}</option>` : ""); t.value = v; });

  /* ================================================================ خصم الكمية: حفظ دائم في القاعدة (كان في الذاكرة فقط) */
  function qdLoad() {
    return load("qdisc").then(l => { const QD = window.__QD && __QD.list; if (!QD) return;
      QD.length = 0; l.forEach(x => QD.push({ code: parseInt(x.no, 10) || 0, name: x.name, active: x.active, branch: x.branch || BR[0], kind: x.kind || "p", from: x.from, to: x.to, method: x.method || "q", tiers: x.tiers || [], items: x.items || [], _id: x.id }));
      __QD.render(); try { renderRows(); } catch (e) { } });
  }
  /* يُرجع وعداً يُرفض عند الفشل (حتى لا تظهر «تم الحفظ» والخصم لم يُحفظ) — والحفظ متسلسل لكل خصم:
     إن فُتحت أصناف خصم جديد قبل أن يعود رقمه من القاعدة ، ينتظر الحفظ الثاني الأول (بدل إدخال نسخة ثانية تُرفض بسبب الاسم) */
  function qdSave(x) {
    const row = no => ({ id: x._id || 0, no, name: x.name, active: x.active !== false, data: { branch: x.branch, kind: x.kind, from: x.from, to: x.to, method: x.method, tiers: x.tiers, items: x.items || [] } });
    /* رقم مستعمل (القائمة لم تُحمَّل بعد عند الإضافة) ← رقم جديد من القاعدة */
    const run = () => DB.save("qdisc", row(String(x.code || ""))).catch(e => { if (!x._id && /مستخدم/.test((e && e.message) || "")) { x.code = 0; return DB.save("qdisc", row("")); } throw e; })
      .then(r => { x._id = (r && r.id) || x._id; if (r && r.no && !x.code) x.code = parseInt(r.no, 10) || x.code; return load("qdisc", true); }).then(() => x);
    const p = (x._q || Promise.resolve()).catch(() => { }).then(run);
    x._q = p;
    return p;
  }
  /* يُرفض عند الفشل ، وبدون رقم داخلي (خصم أُضيف للتو) يُبحث عنه في القاعدة بالرقم ثم الاسم */
  function qdDel(x) {
    return (x._q || Promise.resolve()).catch(() => { }).then(() => x._id ? x._id : load("qdisc", true).then(l => { const r = l.find(z => String(z.no) === String(x.code)) || l.find(z => z.name === x.name); return r ? r.id : 0; }))
      .then(id => id ? DB.del("qdisc", id) : null).then(() => load("qdisc", true));
  }

  /* ================================================================ الربط بالقائمة */
  const openFeature = k => {
    if (k === "idisc") return load("idisc").then(() => S_IDISC.open());
    if (k === "bonus") return load("bonus").then(bonusHub);
    if (k === "brev") return load("bonus").then(() => S_BREV.open());
    if (k === "icost") return load("icost").then(() => S_ICOST.open());
    if (k === "invdisc") return load("invdisc").then(() => S_INVD.open());
    if (k === "slice") return openSlices();
    if (k === "coupon") return openCoupons();
    if (k === "props") { try { if (window.__propsTile && window.__propsTile("add", null, () => { })) return; } catch (e) { } say("تعذّر فتح لوحة الإضافات", "e"); }
  };
  /* خصومات الفواتير اليدوية المتاحة ← أزرار سريعة في لوحة «الخصم النقدى» (disc-pad.js) */
  window.__discPresets = () => { try { if (!featOk("invdisc")) return []; const t = calc(); return D.invdisc.filter(x => isOn(x) && !x.auto && (x.branch || curBr()) === curBr() && roleOk(x) && (!x.perOn || inPer(x)) && t.before > (+x.gt || 0) && (x.lt === "" || x.lt == null || t.before < +x.lt)).map(x => ({ t: x.name, kind: x.kind === "p" ? "p" : "v", val: +x.val || 0 })); } catch (e) { return []; } };
  window.ANOUER_PROMO = { open: openFeature, data: D, load, promoFor, invAuto, couponFind, couponCheck, couponAmt, couponEnd, qdSave, qdDel, bonusDash, fillSlices };
  /* أدوات الواجهة المشتركة (تستعملها «كوتة الأصناف» وغيرها) */
  window.ANOUER_PROMO.ui = { pzDlg, R, sel, inp, tg, ms, msOpen, perButton, perRange, PER, suggest, IC, ask, snd, today, ymd, addD, addM, prodOf, defUnitName, rowF, inRet, rowProd };

  /* ================================================================ ✦ شرائح الخصم في فاتورة المبيعات (2026)
     زر أنيق بدل القائمة الرمادية: نافذة صغيرة ببطاقات الشرائح (النسبة + كم يوفّر العميل في هذه الفاتورة) ،
     شارة «توفير» تحت الزر ، و«الشريحة الذكية»: تُطبَّق وحدها عندما يصل إجمالي الفاتورة إلى حدّها (ما لم يختر الكاشير بنفسه) */
  function slicePro() {
    const s = document.getElementById("slice"); if (!s || s.dataset.slp) return; s.dataset.slp = "1";
    const fld = s.closest(".fld") || s.parentNode;
    s.classList.add("slp-native"); s.tabIndex = -1;
    const b = document.createElement("button"); b.type = "button"; b.className = "slp-btn"; b.setAttribute("aria-haspopup", "listbox");
    const chip = document.createElement("span"); chip.className = "slp-save";
    s.after(b); fld.appendChild(chip); fld.classList.add("slp-fld");
    let manual = false, autoV = null, busy = false, pop = null;
    const RW = () => { try { return Array.isArray(rows) ? rows : []; } catch (e) { return []; } };
    const gross = () => RW().reduce((t, r) => t + (r && !r.ret ? (+r.qty || 0) * (+r.price || 0) : 0), 0);
    const tiers = () => D.slice.filter(x => isOn(x) && (x.branch || curBr()) === curBr()).sort((a, b) => (+a.pct || 0) - (+b.pct || 0));
    const curT = () => { const v = +s.value || 0; if (!v) return null; return tiers().find(x => Math.abs((+x.pct || 0) / 100 - v) < 1e-9) || { name: fmt(v * 100) + "%", pct: v * 100 }; };
    const pctTxt = p => fmt(+p || 0).replace(/\.00$/, "") + "%";
    function paint() {
      if (slLocked()) { b.classList.remove("on", "auto"); b.classList.add("lock"); b.innerHTML = `<span class="slp-nm">🔒 شرائح الخصم</span><i class="slp-car">▾</i>`; b.title = "شرائح الخصم — إضافة تحتاج تفعيل"; chip.classList.remove("show"); chip.textContent = ""; return; }
      b.classList.remove("lock");
      const t = curT(), g = gross(), sv = t ? r2(g * (+t.pct || 0) / 100) : 0;
      b.classList.toggle("on", !!t); b.classList.toggle("auto", !!t && autoV != null && !manual);
      b.innerHTML = t ? `<b class="slp-pc">−${pctTxt(t.pct)}</b><span class="slp-nm">${esc(t.name)}</span><i class="slp-car">▾</i>` : `<span class="slp-nm none">بدون شريحة</span><i class="slp-car">▾</i>`;
      b.title = t ? "شريحة الخصم: " + t.name + " (" + pctTxt(t.pct) + ")" + (autoV != null && !manual ? " — طُبّقت تلقائياً" : "") : "اختر شريحة خصم";
      chip.textContent = sv > 0 ? "توفير " + fmt(sv) + " DZD" : ""; chip.classList.toggle("show", sv > 0);
    }
    function setV(v, why) {
      v = String(v); if (s.value === v) { paint(); return; }
      if (!Array.from(s.options).some(o => o.value === v)) return;
      busy = true; s.value = v; try { renderRows(); } catch (e) { } finally { busy = false; } paint();
    }
    function close() { if (pop) { pop.remove(); pop = null; document.removeEventListener("mousedown", out, true); window.removeEventListener("keydown", key, true); b.focus(); } }
    function out(e) { if (pop && !pop.contains(e.target) && e.target !== b && !b.contains(e.target)) close(); }
    function key(e) {
      if (!pop) return; const it = Array.from(pop.querySelectorAll(".slp-it")), i = it.indexOf(document.activeElement);
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); }
      else if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); e.stopPropagation(); const n = it[(i + (e.key === "ArrowDown" ? 1 : -1) + it.length) % it.length]; if (n) n.focus(); }
    }
    function open() {
      if (pop) { close(); return; }
      if (slLocked(true)) { slUnlock(() => { paint(); if (!slLocked(true)) setTimeout(open, 60); }); return; }
      const g = gross(), L = tiers(), cv = +s.value || 0;
      pop = document.createElement("div"); pop.className = "slp-pop"; pop.setAttribute("role", "listbox"); pop.setAttribute("data-dk-skip", "");
      pop.innerHTML = `<div class="slp-ph"><b>شرائح الخصم</b><span>إجمالي الفاتورة ${fmt(g)} DZD</span></div>`
        + `<button type="button" class="slp-it none${cv ? "" : " cur"}" data-v="0"><span class="slp-ip">—</span><span class="slp-ib"><b>بدون شريحة</b><small>إلغاء خصم الشريحة</small></span></button>`
        + (L.length ? L.map((x, i) => { const p = +x.pct || 0, sv = r2(g * p / 100), lim = x.auto && +x.minInv, reach = !lim || g >= +x.minInv;
            return `<button type="button" class="slp-it t${i % 5}${Math.abs(p / 100 - cv) < 1e-9 ? " cur" : ""}" data-v="${p / 100}"><span class="slp-ip">${pctTxt(p)}</span><span class="slp-ib"><b>${esc(x.name)}</b><small>${g > 0 ? "يوفّر " + fmt(sv) + " DZD" : "خصم " + pctTxt(p) + " على كل الأسطر"}${lim ? ` · <em class="${reach ? "rch" : ""}">${reach ? "⚡ الفاتورة وصلت حدّها" : "⚡ تلقائي من " + fmt(x.minInv)}</em>` : ""}</small></span></button>`; }).join("")
          : `<div class="slp-empty">لا توجد شرائح نشطة — أضفها من «شرائح الخصم»</div>`)
        + `<button type="button" class="slp-man" data-man>⚙ إدارة الشرائح</button>`;
      document.body.appendChild(pop);
      const r = b.getBoundingClientRect(), W = 300; pop.style.width = W + "px";
      pop.style.left = Math.max(8, Math.min(innerWidth - W - 8, r.right - W)) + "px";
      const h = pop.offsetHeight; pop.style.top = (r.bottom + 6 + h > innerHeight - 8 ? Math.max(8, r.top - h - 6) : r.bottom + 6) + "px";
      pop.addEventListener("click", e => { const it = e.target.closest(".slp-it"); if (it) { manual = true; autoV = null; setV(it.dataset.v); snd("click"); close(); return; } if (e.target.closest("[data-man]")) { close(); slUnlock(openSlices); } });
      document.addEventListener("mousedown", out, true); window.addEventListener("keydown", key, true);
      (pop.querySelector(".slp-it.cur") || pop.querySelector(".slp-it")).focus();
    }
    b.addEventListener("click", open);
    b.addEventListener("keydown", e => { if (e.key === "ArrowDown" || e.key === "F4") { e.preventDefault(); open(); } });
    s.addEventListener("change", () => { if (!busy) { manual = true; autoV = null; } paint(); });
    /* الشريحة الذكية */
    function autoTier() {
      if (busy) return;
      if (slLocked()) { if (+s.value) setV("0"); paint(); return; }
      const L = RW(); if (!L.length) { manual = false; if (autoV != null) { autoV = null; if (+s.value) setV("0"); } paint(); return; }
      if (manual) { paint(); return; }
      const g = gross(), best = tiers().filter(x => x.auto && +x.minInv > 0 && g >= +x.minInv).sort((a, b) => (+b.pct || 0) - (+a.pct || 0))[0];
      if (best) { const v = String((+best.pct || 0) / 100); if (s.value !== v) { const up = !(+s.value) || +v > +s.value; autoV = v; setV(v); if (up) { snd("save"); say("⚡ الفاتورة وصلت شريحة «" + best.name + "» — خصم " + pctTxt(best.pct) + " طُبّق تلقائياً", "s"); } } }
      else if (autoV != null) { autoV = null; setV("0"); say("الفاتورة نزلت تحت حد الشريحة — أُلغي الخصم التلقائي", "i"); }
      paint();
    }
    if (typeof calc === "function") { const _c = calc; window.calc = calc = function () { const r = _c.apply(this, arguments); try { setTimeout(autoTier, 0); } catch (e) { } return r; }; }
    if (typeof resetInv === "function") { const _ri = resetInv; window.resetInv = resetInv = function () { manual = false; autoV = null; const r = _ri.apply(this, arguments); paint(); return r; }; }
    on("slice", () => setTimeout(() => { autoTier(); paint(); }, 0));
    paint();
  }

  /* الإقلاع */
  try { slicePro(); } catch (e) { console.warn("slicePro", e); }
  Promise.all(["idisc", "bonus", "icost", "invdisc", "slice"].map(k => load(k))).then(() => seedDexef()).then(() => { fillSlices(); try { renderRows(); } catch (e) { } });
  qdLoad();
  on("slice", fillSlices);
  ["idisc", "bonus", "invdisc", "coupon"].forEach(k => on(k, () => { try { renderRows(); } catch (e) { } }));
  hookInvoice(); hookCoupon(); loadMe();
})();
