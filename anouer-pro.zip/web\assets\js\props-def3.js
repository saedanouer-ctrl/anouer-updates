/* ANOUER — تعريفات شاشات «الخصائص» (مطابقة DEXEF ONE) — الجزء 3:
   صلاحيات المستخدمين، الأجهزة و الطابعات، طريقة العرض، شريط الأخبار، الحقول الإضافية، الإضافات، تصميم التقارير */
(function () {
  "use strict";
  const P = window.__PP, D = window.__PPD; if (!P || !D) return;
  const { TILES, IC, esc, T, clone, today, get, put, tg, sel, num, txt, optHTML, rowHTML, fHTML, collect, wire, setTg, dlg, ask, gridHTML, wireFilter, listTab, sepWin, frame, HOST, call } = P;
  const BR = () => (window.__FH && window.__FH.BR) || ["الفرع الرئيسي"];
  const PERIODS = ["الكل", "اليوم", "الاسبوع الحالي", "الشهر الحالى", "الشهر السابق", "الثلاث شهور السابقة", "السنة الحالية"];

  // ==================================================================== 6) صلاحيات المستخدمين
  const PO = [["all", "جميع الصلاحيات", '<b class="po ok">✔</b>'], ["add", "إضافة فقط", '<b class="po gr">+</b>'], ["view", "مراجعة فقط", '<b class="po bl">⌕</b>'], ["addv", "إضافة مع عرض البيانات", '<b class="po gr">▦</b>'], ["adde", "اضافة مع إمكانية التعديل فقط", '<b class="po bl">✎</b>'], ["addp", "إضافة مع عرض و طباعة البيانات", '<b class="po dk">≣</b>'], ["off", "غير مفعل", '<b class="po rd">—</b>']];
  const L = (t, sub) => ({ t, sub: (sub || []).map(x => typeof x === "string" ? { t: x } : x) });
  const PTREE = [
    L("الصلاحيات الادارية", ["المستخدمين", "الفروع", "الشركات", "النسخ الاحتياطى", "إغلاق اليومية", "حذف البيانات"]),
    L("الفهرس", ["دليل الأصناف", "دليل العملاء و الموردين", "دليل الحسابات", "المخازن", "الخزائن و البنوك", "الموظفين", "مراكز التكلفة"]),
    L("الفواتير", [L("صلاحيات إستخدام الفاتورة", ["تغيير سعر الصنف", "عمل خصم على الفاتورة", "حذف صنف من الفاتورة", "البيع بأقل من التكلفة", "البيع على المكشوف", "تغيير تاريخ الفاتورة"]),
      L("المشتريات", D.PUR_TYPES), L("المبيعات", [L("التعاملات", ["المبيعات", "مرتجع المبيعات", "عروض الأسعار", "أوامر التوريد"]), L("التحكم بالأسعار", ["سعر البيع", "سعر الجملة", "سعر نصف الجملة", "آخر سعر"]), L("خصائص الكاشير", ["فتح درج الكاشير", "إعادة طباعة آخر فاتورة", "محو محتويات الفاتورة"])]),
      L("دورة المخازن", D.WH_TYPES)]),
    L("الاعدادات", ["الخصائص", "تصميم التقارير", "الحقول الإضافية", "الإضافات"]),
    L("خصائص البرنامج", ["إعدادات النظام", "الفواتير", "المخازن", "العملاء و الموردين", "الضرائب", "الأجهزة و الطابعات", "طريقة العرض"]),
    L("التعاملات المالية", D.ACC_TYPES.concat(["الشيكات", "السلف"])),
    L("التقارير", ["تقارير المبيعات", "تقارير المشتريات", "تقارير المخازن", "تقارير الحسابات", "تقارير العملاء و الموردين", "التقارير الإدارية"]),
    L("التنبيهات", ["حد الطلب", "تواريخ الصلاحية", "الشيكات المستحقة", "الأقساط المستحقة", "أعمار الديون"])];
  function flat(nodes, pre, lv, out) { nodes.forEach((n, i) => { const k = pre + i; out.push({ k, t: n.t, lv, kids: !!(n.sub && n.sub.length) }); if (n.sub) flat(n.sub, k + ".", lv + 1, out); }); return out; }
  function groupEditor(row, done) {
    const v = row || { name: "", perms: {}, by: "ANOUER", date: today(), active: true };
    const F = flat(PTREE, "", 0, []), pv = Object.assign({}, v.perms);
    const val = k => pv[k] || "all";
    const d = dlg({ title: "مجموعة الصلاحيات", w: 1090, cls: "pp-pg", body: "", buttons: [
      { t: "حفظ", cls: "green", fn: d => { const nm = d.$(".pp-pgn input"); if (!nm.value.trim()) { nm.classList.add("err"); nm.focus(); T("أدخل اسم المجموعة", "w"); return; } v.name = nm.value.trim(); v.perms = pv; d.close(); done(v); T("تم الحفظ", "s"); } },
      { t: "إغلاق", cls: "blue", fn: d => d.close() }] });
    d.body.innerHTML = `<div class="pp-pgn"><label>اسم المجموعة</label><i class="pp-req">*</i><input class="pp-txt" value="${esc(v.name)}" style="width:270px"></div>
      <div class="pp-pgt"><table class="pp-tree2"><colgroup><col><col style="width:44%"></colgroup><tbody>${F.map(n => `<tr data-k="${n.k}" data-lv="${n.lv}"${n.lv ? ' style="display:none"' : ""}><td style="padding-right:${8 + n.lv * 22}px">${n.kids ? '<i class="pp-car">›</i>' : '<i class="pp-car no"></i>'}<span class="pp-fold">${IC.fold}</span>${esc(n.t)}</td><td class="pv"><button type="button" class="pp-pvb">${PO.find(o => o[0] === val(n.k))[2]} ${PO.find(o => o[0] === val(n.k))[1]}</button></td></tr>`).join("")}</tbody></table></div>`;
    const tb = d.body.querySelector("tbody");
    const kidsOf = k => Array.from(tb.querySelectorAll("tr")).filter(r => r.dataset.k.indexOf(k + ".") === 0);
    const directKids = (k, lv) => kidsOf(k).filter(r => +r.dataset.lv === lv + 1);
    const paint = tr => { const o = PO.find(x => x[0] === val(tr.dataset.k)); tr.querySelector(".pp-pvb").innerHTML = o[2] + " " + o[1]; };
    tb.addEventListener("click", e => {
      const tr = e.target.closest("tr"); if (!tr) return;
      tb.querySelectorAll("tr.sel").forEach(x => x.classList.remove("sel")); tr.classList.add("sel");
      const b = e.target.closest(".pp-pvb");
      if (b) {
        const r = b.getBoundingClientRect();
        P.ctxMenu(r.left, r.bottom, PO.map(o => [o[1], () => { pv[tr.dataset.k] = o[0]; kidsOf(tr.dataset.k).forEach(c => { pv[c.dataset.k] = o[0]; paint(c); }); paint(tr); }]));
        const m = document.querySelector(".pp-ctx"); if (m) { m.classList.add("pp-pom"); m.style.width = r.width + "px"; m.querySelectorAll("button").forEach((x, i) => x.innerHTML = PO[i][2] + " " + esc(PO[i][1])); }
        return;
      }
      if (e.target.closest(".pp-car") || e.target.closest("td:first-child")) {
        const op = !tr.classList.contains("op"); tr.classList.toggle("op", op);
        const lv = +tr.dataset.lv;
        if (op) directKids(tr.dataset.k, lv).forEach(c => c.style.display = "");
        else kidsOf(tr.dataset.k).forEach(c => { c.style.display = "none"; c.classList.remove("op"); });
      }
    });
    setTimeout(() => d.$(".pp-pgn input").focus(), 30);
  }

  function usersWin() {
    const w = sepWin({ title: "", cls: "pp-usrw" });
    frame(TILES.usr, w.body, w.close, { logo: true });
  }
  TILES.usr = {
    id: "usr", title: "صلاحيات المستخدمين", sep: true, open: () => usersWin(), saveCls: "green",
    tabs: [
      { id: "gen", t: "عام", type: "form", rows: [
        ["h", "عام"], ["tg", "allParties", "المستخدم الذى لم يحدد له جهات التعامل يكون متاح له جميع الجهات ؟", true], ["gap", 20],
        ["h", "إغلاقات اليومية"],
        ["sel", "openBy", "كيفية فتح يومية جديدة للمستخدم ؟", "بواسطة المدير", { opts: ["بواسطة المدير", "بواسطة المستخدم", "تلقائياً"], w: 170 }],
        ["sel", "approveBy", "كيفية إعتماد قيمة إغلاق اليومية ؟", "بواسطة المستخدم", { opts: ["بواسطة المستخدم", "بواسطة المدير"], w: 170 }], ["gap", 14],
        ["num", "maxHours", "أقصى عدد ساعات لترك اليومية مفتوحة لدى المستخدم هو ؟", 24, { unit: "ساعة", min: 1 }],
        ["tg", "editClosed", "إمكانية تعديل المستخدم لقيمة اليومية المغلقة طالما لم تعتمد", true],
        ["tg", "seePrev", "إمكانية اطلاع المستخدم على قيمة إغلاق اليوميات السابقة", true],
        ["tg", "editInClosed", "إمكانيه التعديل او الحذف على التعاملات التى توجد فى اليوميات المغلقة", false]
      ] },
      { id: "groups", t: "مجموعة الصلاحيات", type: "list", title: "مجموعة الصلاحيات", desc: "يمكنك من هنا تحديد صلاحية فئة معينة من المستخدمين . وما الذى يمكنكهم الوصول إليه فى البرنامج . ومن تم عند إضافة مستخدم تقوم بإضافة هذه السماحية له",
        seed: [{ name: "صلاحية المسموحة بيها للعمال", by: "ANOUER", date: "2023-10-19", perms: {}, active: true }],
        cols: [["name", "الاسم"], ["by", "مضاف بواسطة", "25%"], ["date", "تاريخ الإضافة", 150, "eq"]], editor: groupEditor },
      { id: "notif", t: "الإشعارات", type: "list", title: "الإشعارات ( التنبيهات )", desc: "من هنا يتم إضافة سياسة التنبيهات . فعلى سبيل المثال مستخدمين المخازن يجب ظهور تنبيهات المخازن فقط دون غيرها من التنبيهات .. فيتم تقسيم التنبيهات حسب المستخدم .. ومن تم عند إضافة مستخدم يتم إعطاءه نوع التنبيه الذى تم تحديده من هنا",
        seed: [{ name: "اشعارات جديدة 2023", items: ["حد الطلب", "تواريخ الصلاحية"], active: true }], cols: [["name", "الاسم"]], dTitle: "الإشعارات", dW: 520,
        form: [["txt", "name", "الاسم", "", { req: 1, w: 280 }], ["html", '<div class="pp-fh">التنبيهات</div>'], ...["حد الطلب", "تواريخ الصلاحية", "الشيكات المستحقة", "الأقساط المستحقة", "أعمار الديون", "الأصناف الراكدة", "فواتير الأجل المستحقة"].map((n, i) => ["chk", "n" + i, n, true, { bare: 1, cap: n }]), ["chk", "active", "الحالة", true, { cap: "نشط" }]] },
      { id: "shifts", t: "ورديات العمل", type: "list", title: "ورديات العمل", desc: "هى فترات العمل للموظفين . مثل الفترة الصباحية و الفترة المسائية ويتم من خلالها ضبط الحضور والانصراف",
        cols: [["no", "الرقم", 110, "eq"], ["name", "الاسم", "40%"], ["notes", "الملاحظات"]], dTitle: "ورديات العمل", blank: rows => ({ no: rows.length + 1, name: "", from: "08:00", to: "16:00", notes: "", active: true }),
        form: [["num", "no", "الرقم", 1, { w: 90 }], ["txt", "name", "الاسم", "", { req: 1, w: 260 }], ["time", "from", "من الساعة", "08:00"], ["time", "to", "الى الساعة", "16:00"], ["num", "grace", "فترة السماح بالتأخير", 15, { unit: "دقيقة", min: 0 }], ["txt", "notes", "الملاحظات", "", { w: 300 }], ["chk", "active", "الحالة", true, { cap: "نشط" }]] },
      { id: "depts", t: "الأقسام", type: "list", title: "الأقسام", desc: "من هنا يتم إضافة جميع الأقسام الموجودة داخل الشركة . تساعدك كثيراً فى تحديد صلاحيات المستخدمين", branch: true,
        cols: [["name", "الاسم"], ["no", "الرقم", 120, "eq"], ["mgr", "مدير القسم", "25%"], ["notes", "الملاحظات", "25%"]], dTitle: "الأقسام", blank: rows => ({ no: rows.length + 1, name: "", mgr: "", notes: "", branch: BR()[0], active: true }),
        form: [["num", "no", "الرقم", 1, { w: 90 }], ["txt", "name", "الاسم", "", { req: 1, w: 260 }], ["sel", "branch", "الفرع", "", { w: 200, opts: () => BR() }], ["txt", "mgr", "مدير القسم", "", { w: 220 }], ["txt", "notes", "الملاحظات", "", { w: 300 }], ["chk", "active", "الحالة", true, { cap: "نشط" }]] },
      { id: "jobs", t: "الوظائف", type: "list", title: "الوظائف", desc: "يمكنك من هنا إضافة جميع الوظايف الموجودة داخل الشركه . ويساعدك هذا كثيرا فى الدورة المستندية",
        seed: [{ name: "KHELD", no: 1, notes: "", active: true }], cols: [["name", "الاسم"], ["no", "الرقم", 150, "eq"], ["notes", "الملاحظات", "30%"]], dTitle: "الوظائف", blank: rows => ({ no: rows.length + 1, name: "", notes: "", active: true }),
        form: [["num", "no", "الرقم", 1, { w: 90 }], ["txt", "name", "الاسم", "", { req: 1, w: 260 }], ["txt", "notes", "الملاحظات", "", { w: 300 }], ["chk", "active", "الحالة", true, { cap: "نشط" }]] },
      { id: "cashier", t: "صلاحيات الكاشير", type: "form", rows: [
        ["h", "الرقم السرى لمدير الصالة"], ["txt", "pw", "الرقم السرى", "", { pw: 1, w: 170 }], ["txt", "pw2", "إعادة الرقم السرى", "", { pw: 1, w: 170 }],
        ["h", "الحالات الواجب ادخال الرقم السرى فيها"],
        ["tg", "delItem", "حذف صنف من الفاتورة ؟", false], ["tg", "disc", "وضع خصم على الفاتورة ؟", false], ["num", "maxDisc", "أقصى مبلغ الخصم ؟", 0, { min: 0 }], ["tg", "drawer", "فتح درج الكاشير ؟", false],
        ["tg", "price", "التعديل على سعر الصنف بالفاتورة ؟", false], ["tg", "qty", "التعديل على كمية الصنف ؟", false], ["tg", "clear", "محو محتويات الفاتورة ؟", false], ["tg", "ret", "عمل مرتجع المبيعات من الفاتورة ؟", true],
        ["tg", "edit", "التعديل على الفاتورة ؟", false], ["tg", "del", "حذف فاتورة ؟", false], ["tg", "reprint", "إعادة طباعة أخر فاتورة ؟", true]
      ], beforeSave(v) { if (v.pw !== v.pw2) return "الرقم السرى غير متطابق"; const on = ["delItem", "disc", "drawer", "price", "qty", "clear", "ret", "edit", "del", "reprint"].filter(k => v[k]); if (on.length && !v.pw) return "أدخل الرقم السرى لمدير الصالة — بعض الحالات مفعّلة"; if (v.pw && String(v.pw).length < 4) return "الرقم السرى 4 خانات على الأقل"; } }
    ]
  };

  // ==================================================================== 7) الأجهزة و الطابعات
  const DEV_TILES = [["printers", "الطابعات", '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M6 9V3h12v6"/><rect x="2" y="9" width="20" height="9" rx="2"/><path d="M6 14h12v7H6z" fill="#fff" stroke="none"/></svg>'],
    ["scale", "ميزان الباركود", '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M9 3h6"/><path d="M12 3v3"/><path d="M5 9a7 7 0 0 0 14 0z"/><path d="M12 15a6 6 0 1 0 0-12" opacity="0"/><path d="M10 11l2-2"/></svg>'],
    ["display", "شاشة العرض", '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><rect x="3" y="4" width="18" height="13" rx="1"/><path d="M8 13l7-6M10 7h5v5"/></svg>'],
    ["caller", "Caller ID", '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><rect x="6" y="2" width="12" height="20" rx="2"/><path d="M9 6h6M9 10h1M12 10h1M15 10h0M9 14h1M12 14h1M9 18h6"/></svg>'],
    ["qr", "QR Barcode", '<svg viewBox="0 0 24 24" fill="#fff"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="5" y="5" width="3" height="3" fill="#2e7cf0"/><rect x="16" y="5" width="3" height="3" fill="#2e7cf0"/><rect x="5" y="16" width="3" height="3" fill="#2e7cf0"/><rect x="14" y="14" width="3" height="3"/><rect x="18" y="18" width="3" height="3"/><rect x="18" y="14" width="3" height="2"/><rect x="14" y="18" width="2" height="3"/></svg>']];
  const PRN = ["", "Microsoft Print to PDF", "XP-80C", "POS-80", "Xprinter XP-365B", "Canon LBP", "HP LaserJet", "EPSON L3150", "Godex G500"];
  /* المقاسات الأربعة: [المقاس، الاستعمال، الوصف التلقائي، أيقونة] — القيم تُقرأ فى rd-engine / rd-hooks عند الطباعة */
  const PRN_SZ = [["A4", "الفواتير والتقارير A4 / A5", "Pantum-P2500-Series إن وُجدت", '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 2h9l4 4v16H6z"/><path d="M15 2v4h4M9 11h7M9 15h7M9 19h4"/></svg>'],
    ["A3", "الملصقات والتقارير الكبيرة A3", "نفس طابعة A4", '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="16" rx="1"/><path d="M7 9h10M7 13h10M7 17h6"/></svg>'],
    ["Cashier", "إيصالات الكاشير 80 مم", "حسب التصميم", '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 2h12v20l-2-1.5-2 1.5-2-1.5-2 1.5-2-1.5L6 22z"/><path d="M9 7h6M9 11h6M9 15h4"/></svg>'],
    ["Barcode", "ملصقات الباركود والتيكت", "TSC TDP-225 إن وُجدت", '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 5v14M7 5v14M11 5v14M14 5v14M18 5v14M20 5v14"/></svg>']];
  /* «XP-80C» كانت قيمة افتراضية خاطئة لورق A4 (طابعة حرارية 80 مم) — تُعامل كأنها غير محددة */
  const prnVal = (v, s) => { const x = v["p" + s] || ""; return s === "A4" && x === "XP-80C" ? "" : x; };
  const PRN_TEST = { A4: [210, 297], A3: [297, 420], Cashier: [80, 120], Barcode: [50, 30] };
  function prnTestHTML(sz, prn) {
    const [w, h] = PRN_TEST[sz], small = sz === "Barcode", d = new Date().toLocaleString("ar-DZ");
    return `<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>@page{size:${w}mm ${h}mm;margin:0}body{margin:0;font-family:Segoe UI,Tahoma,Arial}.b{box-sizing:border-box;width:${w}mm;height:${h}mm;padding:${small ? 1.5 : 6}mm;border:${small ? .3 : .6}mm dashed #000;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:${small ? .5 : 3}mm}h1{margin:0;font-size:${small ? 9 : sz === "Cashier" ? 18 : 30}pt;letter-spacing:1px}p{margin:0;font-size:${small ? 6 : 11}pt}</style></head><body><div class="b"><h1>ANOUER</h1><p>صفحة تجريبية — ورق ${sz} (${w}×${h} مم)</p><p>${esc(prn || "الطابعة الافتراضية")}</p>${small ? "" : `<p>${esc(d)}</p><p>✔ إذا ظهرت هذه الصفحة كاملة فالربط صحيح</p>`}</div></body></html>`;
  }
  function wirePrinters(host) {
    const rows = [...host.querySelectorAll(".pp-prr")];
    if (!rows.length) return;
    const stat = (r, list, def) => {
      const s = r.querySelector(".pp-prs"), st = r.querySelector(".pp-prst"), v = s.value;
      st.className = "pp-prst " + (!HOST() ? "" : !v ? "auto" : list.indexOf(v) >= 0 ? "ok" : "bad");
      st.title = !HOST() ? "" : !v ? "تلقائي" + (def ? " — الافتراضية: " + def : "") : list.indexOf(v) >= 0 ? "مثبّتة على هذا الجهاز ✔" : "غير موجودة على هذا الجهاز";
    };
    const fill = (list, def) => rows.forEach(r => {
      const s = r.querySelector(".pp-prs"), cur = s.value, all = list.slice();
      if (cur && all.indexOf(cur) < 0) all.unshift(cur);
      s.innerHTML = s.options[0].outerHTML + all.map(p => `<option value="${esc(p)}"${p === cur ? " selected" : ""}>${esc(p)}${p === def ? "  ★ الافتراضية" : ""}${list.indexOf(p) < 0 ? "  ⚠ غير موجودة" : ""}</option>`).join("");
      s.value = cur; s.onchange = () => stat(r, list, def); stat(r, list, def);
      r.querySelector(".pp-prt").onclick = () => {
        const sz = r.dataset.sz, p = s.value, [w, h] = PRN_TEST[sz];
        if (!HOST()) { T("الطباعة التجريبية تعمل داخل برنامج ANOUER", "w"); return; }
        const b = r.querySelector(".pp-prt"); b.disabled = true; b.textContent = "…";
        call("print.html", { html: prnTestHTML(sz, p), printer: p, copies: 1, w, h, landscape: false })
          .then(x => T("✔ أُرسلت صفحة تجريبية " + sz + " إلى «" + ((x && x.printer) || p || "الطابعة الافتراضية") + "»", "s"))
          .catch(e => T("لم تتم الطباعة: " + ((e && e.message) || e), "e"))
          .then(() => { b.disabled = false; b.textContent = "تجربة"; });
      };
    });
    if (HOST()) call("print.printers").then(r => fill((r && r.printers) || [], (r && r.def) || "")).catch(() => fill(PRN.filter(Boolean), ""));
    else fill(PRN.filter(Boolean), "");
  }
  /* ميزان الباركود: شكل اللاصقة مباشرة + تجربة قراءة باركود حقيقى */
  function wireScale(host) {
    const box = host.querySelector(".pp-sc"); if (!box) return;
    const ctl = k => host.querySelector(`[data-pk="${k}"]`);
    let test = "";
    const draw = () => {
      const v = collect(host), C = window.__scaleCfg ? __scaleCfg(v) : null; if (!C) { box.innerHTML = ""; return; }
      const sample = (C.preV.length >= C.nPre ? C.preV.slice(-C.nPre) : (C.preV + "0".repeat(C.nPre)).slice(0, C.nPre)) + "12345678901234".slice(0, C.nCode).padStart(C.nCode, "0") + String(Math.round(1.25 * C.div)).padStart(C.nW, "0").slice(-C.nW);
      const chk = Math.max(0, C.len - C.body), warn = C.len < C.body ? `مجموع الخانات (${C.body}) أكبر من عدد خانات الباركود (${C.len})` : chk > 1 ? `عدد خانات الباركود (${C.len}) أكبر من المجموع + رقم التحقق (${C.body + 1})` : "";
      const seg = (cls, t, cap) => `<span class="sg ${cls}"><b>${t.split("").map(x => `<i>${x}</i>`).join("")}</b><small>${cap}</small></span>`;
      const r = test && window.__scaleParse ? __scaleParse(test, v) : null;
      box.innerHTML = `<div class="pp-sch"><b>شكل اللاصقة</b><span>${C.len} خانة</span></div>
        <div class="pp-scs">${seg("pre", sample.slice(0, C.nPre), "تعريفى")}${seg("code", sample.slice(C.nPre, C.nPre + C.nCode), "كود الصنف")}${seg("w", sample.slice(C.nPre + C.nCode), "الوزن" + (C.div > 1 ? " ÷" + C.div : ""))}${chk ? seg("ck", "7".repeat(chk).slice(0, 1) + "0".repeat(Math.max(0, chk - 1)), "تحقق") : ""}</div>
        ${warn ? `<div class="pp-scw">⚠ ${warn}</div>` : `<div class="pp-sco">✔ مثال: ${sample}${chk ? "7" : ""} ← الصنف ${sample.slice(C.nPre, C.nPre + C.nCode)} بكمية ${(1.25).toFixed(C.div > 1 ? 3 : 0).replace(/\.?0+$/, "") || 1}</div>`}
        <div class="pp-sct"><input class="pp-scin" placeholder="امسح لاصقة من الميزان للتجربة…" value="${esc(test)}" inputmode="numeric">${r ? (r.p ? `<span class="ok">✔ «${esc(r.p.name)}» — الكمية ${r.qty}</span>` : `<span class="bad">✖ ${esc(r.err)}</span>`) : `<span class="mut">النتيجة تظهر هنا</span>`}</div>`;
      const ti = box.querySelector(".pp-scin"); ti.oninput = () => { test = ti.value.trim(); const pos = ti.selectionStart; draw(); const n = box.querySelector(".pp-scin"); n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) { } };
    };
    host.querySelectorAll(".pp-dv [data-pk]").forEach(e => { e.addEventListener("input", draw); e.addEventListener("change", draw); e.addEventListener("click", () => setTimeout(draw, 0)); });
    draw();
  }
  /* شاشة العرض: منافذ COM والشاشات الحقيقية من البرنامج + معاينة مباشرة + تجربة */
  function wireDisplay(host) {
    const box = host.querySelector(".pp-dsp"); if (!box) return;
    const q = k => host.querySelector(`[data-pk="${k}"]`), kindV = () => (q("kind") || {}).value || "";
    const upd = () => {
      const vfd = /VFD|COM/.test(kindV());
      host.querySelectorAll(".pp-dkc").forEach(r => r.style.display = vfd ? "" : "none");
      host.querySelectorAll(".pp-dk2").forEach(r => r.style.display = vfd ? "none" : "");
      box.classList.toggle("vfd", vfd);
      const m = (q("msg") || {}).value || "أهلاً بكم", ml = String((q("msgL") || {}).value || "WELCOME").replace(/[^\x20-\x7e]/g, "");
      box.querySelector(".pp-dspw").textContent = m;
      box.querySelector(".l1").textContent = (ml || "WELCOME").slice(0, 20).padEnd(20, "\u00a0"); box.querySelector(".l2").textContent = "ANOUER".padEnd(20, "\u00a0");
    };
    host.querySelectorAll(".pp-dv [data-pk]").forEach(e => { e.addEventListener("input", upd); e.addEventListener("change", upd); });
    const st = box.querySelector(".pp-dsps");
    if (HOST()) {
      call("dev.ports").then(r => { const s = q("port"), cur = s.value, L = (r && r.ports) || []; s.innerHTML = `<option value="">—</option>` + (cur && L.indexOf(cur) < 0 ? `<option selected>${esc(cur)}</option>` : "") + L.map(p => `<option${p === cur ? " selected" : ""}>${esc(p)}</option>`).join(""); if (!L.length) st.textContent = "لا توجد منافذ COM على هذا الجهاز"; }).catch(() => { });
      call("dev.screens").then(r => { const s = q("screen"), cur = s.value, L = (r && r.screens) || []; s.innerHTML = `<option value="">تلقائى — الشاشة الثانية</option>` + L.map(x => `<option value="${x.i}"${String(x.i) === cur ? " selected" : ""}>الشاشة ${x.i + 1} — ${x.w}×${x.h}${x.primary ? " (الرئيسية)" : ""}</option>`).join(""); if (L.length < 2) st.textContent = "شاشة واحدة موصولة — ستظهر شاشة العميل كنافذة معاينة صغيرة"; }).catch(() => { });
    } else {
      const s = q("port"), cur = s.value; s.innerHTML = `<option value="">—</option>` + COM.filter(Boolean).map(p => `<option${p === cur ? " selected" : ""}>${p}</option>`).join("");
    }
    box.querySelector(".pp-dspt").onclick = () => {
      const v = Object.assign(get("dev.display", {}), collect(host)); v.use = true;
      if (/VFD|COM/.test(v.kind || "") && !v.port) { T("اختر المنفذ SerialPort أولاً", "w"); return; }
      const was = get("dev.display", {}).use;
      put("dev.display", Object.assign(collect(host), { use: true })).then(() => { if (window.__dispTest) __dispTest(); if (!was) { const tgl = q("use"); if (tgl) setTg(tgl, true); } });
    };
    upd();
  }
  /* هوية المتصل: منافذ COM حقيقية + فحص الموديم + آخر المكالمات */
  function wireCaller(host) {
    const box = host.querySelector(".pp-cid"); if (!box) return;
    const q = k => host.querySelector(`[data-pk="${k}"]`), st = box.querySelector(".pp-cids"), lg = box.querySelector(".pp-cidl");
    const hist = () => { const L = (window.__cidLog ? __cidLog() : []).slice(0, 5); box.querySelector(".pp-cidh").innerHTML = L.length ? `<b>آخر المكالمات</b>${L.map(x => `<div><span dir="ltr">${esc(x.num)}</span><em>${esc(x.who || "غير مسجل")}</em><small>${new Date(x.at).toLocaleString("ar-DZ", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</small></div>`).join("")}` : ""; };
    if (HOST()) call("dev.ports").then(r => { const s = q("port"), cur = s.value, L = (r && r.ports) || []; s.innerHTML = `<option value="">—</option>` + (cur && L.indexOf(cur) < 0 ? `<option selected>${esc(cur)}</option>` : "") + L.map(p => `<option${p === cur ? " selected" : ""}>${esc(p)}</option>`).join(""); if (!L.length) { st.className = "pp-cids bad"; st.textContent = "لا توجد منافذ COM — هل الموديم موصول؟"; } }).catch(() => { });
    else { const s = q("port"), cur = s.value; s.innerHTML = `<option value="">—</option>` + COM.filter(Boolean).map(p => `<option${p === cur ? " selected" : ""}>${p}</option>`).join(""); }
    if (HOST()) call("dev.cid.status").then(r => { if (r && r.open) { st.className = "pp-cids ok"; st.textContent = "● متصل على " + r.port; } }).catch(() => { });
    box.querySelector(".pp-conn").onclick = () => {
      const v = Object.assign(collect(host), { use: true }); if (!v.port) { T("اختر المنفذ SerialPort أولاً", "w"); return; }
      const tg = q("use"); if (tg && !tg.classList.contains("on")) setTg(tg, true);
      st.className = "pp-cids"; st.textContent = "…جارى الفحص"; lg.innerHTML = "";
      put("dev.caller", v).then(() => window.__callerConnect ? __callerConnect() : null).then(r => {
        if (!r) { st.className = "pp-cids bad"; st.textContent = "✖ لم يتم الاتصال"; return; }
        st.className = "pp-cids " + (r.cid ? "ok" : r.modem ? "warn" : "bad"); st.textContent = r.cid ? "● متصل — إظهار الرقم مفعل" : r.modem ? "● الموديم يرد — جرّب أمر تفعيل آخر" : "● المنفذ لا يرد";
        lg.innerHTML = (r.log || []).map(x => `<code class="${/OK$/.test(x) ? "ok" : /ERROR$/.test(x) ? "bad" : ""}">${esc(x)}</code>`).join("");
      });
    };
    box.querySelector(".pp-cidt").onclick = () => { const c = (window.CUSTOMERS_DATA || []).find(x => x.ph); if (window.__callerTest) __callerTest(c ? c.ph : "0555123456"); setTimeout(hist, 300); };
    hist();
  }
  const COM = [""].concat([1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => "COM" + n));
  const DEV_FORMS = {
    printers: { h: "الطابعات", d: "يقدم البرنامج أربعة مقاسات للورق يمكنك الطباعة عليها .. وكل مقاس له طابعة مناسبة له .<br>كل ما عليك فعله هو ربط المقاس المناسب بالطابعة الخاصة به", html: v => `<div class="pp-prl">${PRN_SZ.map(z => { const cur = prnVal(v, z[0]); return `<div class="pp-prr" data-sz="${z[0]}"><div class="pp-pri">${z[3]}</div><div class="pp-prm"><b>طابعة ورق ${z[0]}</b><small>${z[1]}</small></div><select class="pp-prs" data-pk="p${z[0]}" data-t="txt"><option value="">تلقائي — ${esc(z[2])}</option>${cur ? `<option selected value="${esc(cur)}">${esc(cur)}</option>` : ""}</select><span class="pp-prst" title="الحالة"></span><button type="button" class="pp-prt" title="طباعة صفحة تجريبية">تجربة</button></div>`; }).join("")}</div><div class="pp-prnote">«تلقائي» = يستعمل البرنامج الطابعة المحددة فى التصميم ثم الطابعة الافتراضية لويندوز</div>` },
    scale: { h: "ميزان الباركود", d: "عند إستخدامك لجهاز ميزان الباركود يقوم هذا الميزان بطباعة لاصقة باركود . هذه اللاصقة دائماً يكون عدد موحد من الأرقام تبدأ بأرقام تعريفية و تقسم الباقى على الوزن و كود الصنف كما يلى .",
      html: v => `<table class="pp-dv">${[["tg", "use", "استخدام جهاز الباركود فى البرنامج", false], ["sel", "div", "طريقة احتساب الكمية", "بدون قسمة", ["بدون قسمة", "القسمة على 10", "القسمة على 100", "القسمة على 1000"]], ["num", "len", "عدد خانات الباركود", 13], ["num2", "pre", "الأرقام التعريفية للباركود", 2], ["num", "code", "عدد ارقام كود الصنف", 5], ["num", "w", "عدد ارقام وزن القطعة", 5]].map(r => devRow(r, v)).join("")}</table><div class="pp-mut sm">الرقم الاخير هو الرقم التعريفى لحالة القراءه</div><div class="pp-sc"></div>` },
    display: { h: "شاشة العرض", d: "هى الشاشة التى تظهر للعميل عند الوقوف أمام الكاشير .<br>حيث تظهر هذه الشاشة قيمة الصنف المضاف بالإضافة إلى إجمالى قيمة الفاتورة",
      html: v => `<table class="pp-dv">${[["tg", "use", "استخدام شاشة العرض", false], ["sel", "kind", "نوع الشاشة", "شاشة ثانية (HDMI / VGA)", ["شاشة ثانية (HDMI / VGA)", "شاشة VFD صغيرة (COM)"]]].map(r => devRow(r, v)).join("")}
        <tr class="pp-dk2"><td class="l">الشاشة</td><td><select class="pp-sel" data-pk="screen" data-t="sel" style="width:240px"><option value="">تلقائى — الشاشة الثانية</option>${v.screen !== undefined && v.screen !== "" ? `<option value="${esc(v.screen)}" selected>الشاشة ${+v.screen + 1}</option>` : ""}</select></td></tr>
        <tr class="pp-dkc"><td class="l">SerialPort</td><td><select class="pp-sel" data-pk="port" data-t="sel" style="width:170px"><option value="">—</option>${v.port ? `<option selected>${esc(v.port)}</option>` : ""}</select></td></tr>
        <tr class="pp-dkc"><td class="l">سرعة المنفذ (Baud)</td><td>${sel(["9600", "2400", "4800", "19200", "38400"], String(v.baud || "9600"), "baud", 170)}</td></tr>
        ${devRow(["txt", "msg", "الرسالة الترحيبية", "أهلاً بكم"], v)}
        <tr class="pp-dkc"><td class="l">رسالة VFD (حروف لاتينية)</td><td>${txt(v.msgL !== undefined ? v.msgL : "WELCOME", "msgL", 220)}</td></tr></table>
        <div class="pp-dsp"><div class="pp-dspv"><div class="pp-dspm"><i>A</i><b class="pp-dspw"></b><small>نسعد بخدمتكم</small></div><div class="pp-dspl"><span class="l1"></span><span class="l2"></span></div></div><div class="pp-dspa"><button type="button" class="pp-btn blue sm pp-dspt">تجربة على الشاشة</button><span class="pp-dsps"></span></div></div>` },
    caller: { h: "هوية المتصل", d: "عند ربط جهاز الحاسب بخط التليفون الذى يدعم خاصية إظهار الرقم . عن طريق الموديم .<br>تسهل عليك هذه الخاصية استلام الطلبات عن طريق الهاتف",
      html: v => `<table class="pp-dv">${devRow(["tg", "use", "تفعيل خاصية هوية المتصل", false], v)}
        <tr><td class="l">SerialPort</td><td><select class="pp-sel" data-pk="port" data-t="sel" style="width:170px"><option value="">—</option>${v.port ? `<option selected>${esc(v.port)}</option>` : ""}</select></td></tr>
        <tr><td class="l">سرعة المنفذ (Baud)</td><td>${sel(["9600", "19200", "38400", "57600", "115200", "2400"], String(v.baud || "9600"), "baud", 170)}</td></tr>
        <tr><td class="l">أمر تفعيل إظهار الرقم</td><td>${sel(["AT+VCID=1", "AT#CID=1", "AT%CCID=1", "AT+CLIP=1", "AT#CC1", "AT*ID1"], v.init || "AT+VCID=1", "init", 170)}</td></tr></table>
        <div class="pp-cid"><div class="pp-cida"><button type="button" class="pp-btn blue sm pp-conn">🔌 اتصال وفحص الموديم</button><button type="button" class="pp-btn sm pp-cidt">📞 محاكاة مكالمة</button><span class="pp-cids"></span></div><div class="pp-cidl"></div><div class="pp-cidh"></div></div>` },
    qr: { h: "QR Barcode", d: "هى عبارة عن باركود ياتى على المنتجات التى تخضع الى رقابة عالية من الدولة . ويتم تصنيف هذا الباركود على عدة مراحل يكون تصميمها على النحو التالى",
      html: v => `<div class="pp-qrw${v.use ? "" : " off"}"><table class="pp-dv">${[["tg", "use", "استخدام طريقة التكويد بال QR فى البرنامج", false], ["sel", "order", "طريقة الترتيب فى قراءة الباركود", "تاريخ الصلاحية اولا", ["تاريخ الصلاحية اولا", "رقم التشغيلة اولا", "رمز الصنف اولا"]]].map(r => devRow(r, v)).join("")}</table>
        <table class="pp-qr"><thead><tr><th></th><th></th><th>الرمز التعريفى<br>(AI)</th><th>عدد الأحرف<br>بعد الرمز التعريفى</th></tr></thead><tbody>${QR_F.map(r => `<tr class="qf-${r[0]}"><td class="qn">${r[1]} <span dir="ltr">(${r[4]})</span></td><td class="qline"><i></i></td><td>${num(v[r[0] + "Ai"] || r[2], r[0] + "Ai", 70, { min: 0, max: 9999 })}</td><td>${num(v[r[0] + "Len"] || r[3], r[0] + "Len", 70, { min: 1, max: 90 })}${r[5] ? '<b class="qreq">*</b>' : ""}</td></tr>`).join("")}</tbody></table>
        <div class="pp-qrx"><b class="qx-h">مثال توضيحى</b>
          <div class="qx-top">${QR_DM}<div class="qx-lab"><div>GTIN: 06280000000000</div><div>SN: X123456789SFDA</div><div>EXPIRY: 151008</div><div>BATCH/LOT: 123SFDA</div></div></div>
          <div class="qx-str" dir="ltr"><em class="r">]d2</em> <em class="a">01</em> 06280000000000 <em class="a">21</em> X123456789SFDA <em class="r">&lt;GS&gt;</em> <em class="a">17</em> 151008 <em class="a">10</em> 123SFDA</div>
          <table class="qx-tb" dir="ltr"><tr><td class="r">]d2</td><td class="a">01</td><td>06280000000000</td><td class="a">21</td><td>X123456789SFDA</td><td class="r">&lt;GS&gt;</td><td class="a">17</td><td>151008</td><td class="a">10</td><td>123SFDA</td></tr>
            <tr class="cap"><td>FNC opening character</td><td>AI</td><td>GTIN</td><td>AI</td><td>Serial Number</td><td>FNC separator</td><td>AI</td><td>Expiration date</td><td>AI</td><td>Batch number</td></tr></table></div>
        <div class="pp-qrt"><div class="pp-sch"><b>تجربة القراءة</b><span>امسح رمز علبة دواء أو اكتبه</span></div><input class="pp-scin pp-qrin" placeholder="]d201062800000000002 1X123…  أو (01)…(17)…(10)…" inputmode="text"><div class="pp-qrr"></div></div></div>` }
  };
  /* [المفتاح ، الاسم ، AI ، الطول ، الاسم اللاتينى ، إجبارى] */
  const QR_F = [["gtin", "رمز الصنف", "01", 14, "GTIN", true], ["exp", "تاريخ الصلاحية", "17", 6, "Expiry date"], ["lot", "رقم التشغيلة", "10", 20, "Batch number"], ["sn", "رقم التسلسلى", "21", 20, "Serial number"]];
  const QR_DM = '<svg class="qx-dm" viewBox="0 0 90 90" shape-rendering="crispEdges"><path d="M0 0h5v5h-5zM10 0h5v5h-5zM20 0h5v5h-5zM30 0h5v5h-5zM40 0h5v5h-5zM50 0h5v5h-5zM60 0h5v5h-5zM70 0h5v5h-5zM80 0h5v5h-5zM0 5h5v5h-5zM5 5h5v5h-5zM20 5h5v5h-5zM35 5h5v5h-5zM55 5h5v5h-5zM60 5h5v5h-5zM65 5h5v5h-5zM80 5h5v5h-5zM85 5h5v5h-5zM0 10h5v5h-5zM25 10h5v5h-5zM30 10h5v5h-5zM40 10h5v5h-5zM45 10h5v5h-5zM50 10h5v5h-5zM55 10h5v5h-5zM60 10h5v5h-5zM65 10h5v5h-5zM0 15h5v5h-5zM5 15h5v5h-5zM15 15h5v5h-5zM20 15h5v5h-5zM45 15h5v5h-5zM50 15h5v5h-5zM55 15h5v5h-5zM60 15h5v5h-5zM70 15h5v5h-5zM80 15h5v5h-5zM85 15h5v5h-5zM0 20h5v5h-5zM15 20h5v5h-5zM20 20h5v5h-5zM30 20h5v5h-5zM40 20h5v5h-5zM45 20h5v5h-5zM60 20h5v5h-5zM65 20h5v5h-5zM70 20h5v5h-5zM0 25h5v5h-5zM5 25h5v5h-5zM10 25h5v5h-5zM15 25h5v5h-5zM20 25h5v5h-5zM30 25h5v5h-5zM40 25h5v5h-5zM45 25h5v5h-5zM55 25h5v5h-5zM65 25h5v5h-5zM70 25h5v5h-5zM75 25h5v5h-5zM80 25h5v5h-5zM85 25h5v5h-5zM0 30h5v5h-5zM15 30h5v5h-5zM25 30h5v5h-5zM30 30h5v5h-5zM45 30h5v5h-5zM55 30h5v5h-5zM60 30h5v5h-5zM70 30h5v5h-5zM75 30h5v5h-5zM80 30h5v5h-5zM0 35h5v5h-5zM5 35h5v5h-5zM15 35h5v5h-5zM25 35h5v5h-5zM30 35h5v5h-5zM40 35h5v5h-5zM55 35h5v5h-5zM60 35h5v5h-5zM75 35h5v5h-5zM80 35h5v5h-5zM85 35h5v5h-5zM0 40h5v5h-5zM15 40h5v5h-5zM35 40h5v5h-5zM40 40h5v5h-5zM45 40h5v5h-5zM55 40h5v5h-5zM65 40h5v5h-5zM80 40h5v5h-5zM0 45h5v5h-5zM5 45h5v5h-5zM15 45h5v5h-5zM20 45h5v5h-5zM40 45h5v5h-5zM50 45h5v5h-5zM55 45h5v5h-5zM60 45h5v5h-5zM65 45h5v5h-5zM70 45h5v5h-5zM75 45h5v5h-5zM80 45h5v5h-5zM85 45h5v5h-5zM0 50h5v5h-5zM10 50h5v5h-5zM15 50h5v5h-5zM45 50h5v5h-5zM50 50h5v5h-5zM55 50h5v5h-5zM75 50h5v5h-5zM0 55h5v5h-5zM5 55h5v5h-5zM15 55h5v5h-5zM25 55h5v5h-5zM65 55h5v5h-5zM85 55h5v5h-5zM0 60h5v5h-5zM5 60h5v5h-5zM30 60h5v5h-5zM45 60h5v5h-5zM70 60h5v5h-5zM0 65h5v5h-5zM5 65h5v5h-5zM15 65h5v5h-5zM25 65h5v5h-5zM35 65h5v5h-5zM40 65h5v5h-5zM50 65h5v5h-5zM65 65h5v5h-5zM70 65h5v5h-5zM75 65h5v5h-5zM85 65h5v5h-5zM0 70h5v5h-5zM5 70h5v5h-5zM10 70h5v5h-5zM25 70h5v5h-5zM35 70h5v5h-5zM45 70h5v5h-5zM50 70h5v5h-5zM70 70h5v5h-5zM80 70h5v5h-5zM0 75h5v5h-5zM5 75h5v5h-5zM10 75h5v5h-5zM35 75h5v5h-5zM40 75h5v5h-5zM45 75h5v5h-5zM50 75h5v5h-5zM55 75h5v5h-5zM60 75h5v5h-5zM70 75h5v5h-5zM75 75h5v5h-5zM85 75h5v5h-5zM0 80h5v5h-5zM10 80h5v5h-5zM15 80h5v5h-5zM20 80h5v5h-5zM30 80h5v5h-5zM45 80h5v5h-5zM55 80h5v5h-5zM60 80h5v5h-5zM65 80h5v5h-5zM70 80h5v5h-5zM80 80h5v5h-5zM0 85h5v5h-5zM5 85h5v5h-5zM10 85h5v5h-5zM15 85h5v5h-5zM20 85h5v5h-5zM25 85h5v5h-5zM30 85h5v5h-5zM35 85h5v5h-5zM40 85h5v5h-5zM45 85h5v5h-5zM50 85h5v5h-5zM55 85h5v5h-5zM60 85h5v5h-5zM65 85h5v5h-5zM70 85h5v5h-5zM75 85h5v5h-5zM80 85h5v5h-5zM85 85h5v5h-5z" fill="#111"/></svg>';
  function wireQr(host) {
    const wrapEl = host.querySelector(".pp-qrw"), tgl = host.querySelector('.pp-qrw [data-pk="use"]');
    const lock = () => { const on = tgl && tgl.classList.contains("on"); if (wrapEl) wrapEl.classList.toggle("off", !on);
      host.querySelectorAll('.pp-qrw [data-pk]:not([data-pk="use"]), .pp-qrin').forEach(e => { e.disabled = !on; e.tabIndex = on ? 0 : -1; }); };
    if (tgl) tgl.addEventListener("change", lock); lock();
    const box = host.querySelector(".pp-qrt"); if (!box) return;
    const inp = box.querySelector(".pp-qrin"), out = box.querySelector(".pp-qrr");
    const draw = () => {
      const t = inp.value.trim(); if (!t) { out.innerHTML = '<span class="mut">النتيجة تظهر هنا: الصنف · الصلاحية · التشغيلة · الرقم التسلسلى</span>'; return; }
      const r = window.__qrParse ? __qrParse(t, collect(host)) : null;
      if (!r) { out.innerHTML = '<span class="bad">✖ لم يُفهم الرمز — تحقق من الرموز التعريفية وعدد الأحرف</span>'; return; }
      const days = r.expIso ? Math.floor((new Date(r.expIso) - new Date(new Date().toDateString())) / 864e5) : null;
      const chip = (c, k, v) => `<span class="qc ${c}"><small>${k}</small><b dir="ltr">${esc(v)}</b></span>`;
      out.innerHTML = chip(r.p ? "ok" : "bad", "الصنف", r.p ? r.p.name : r.gtin + " — غير موجود") + (r.p ? chip("n", "GTIN", r.gtin) : "") +
        (r.expIso ? chip(days < 0 ? "bad" : days <= 30 ? "warn" : "ok", days < 0 ? "منتهى الصلاحية" : "الصلاحية", r.expIso) : chip("n", "الصلاحية", "—")) + chip("n", "التشغيلة", r.lot || "—") + chip("n", "الرقم التسلسلى", r.sn || "—");
    };
    inp.addEventListener("input", draw); inp.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); draw(); } });
    host.querySelectorAll(".pp-qr [data-pk]").forEach(e => e.addEventListener("input", draw));
    draw();
  }
  function devRow(r, v) {
    const [t, k, lab, def, opts] = r, d = v[k] !== undefined ? v[k] : def;
    let c = "";
    if (t === "tg") c = tg(!!d, k); else if (t === "sel") c = sel(opts, d, k, 170); else if (t === "num") c = num(d, k, 90); else if (t === "txt") c = txt(d, k, 220);
    else if (t === "num2") c = num(d, k, 90) + `<span class="pp-unit">وهما</span>` + num(v[k + "V"] !== undefined ? v[k + "V"] : 2, k + "V", 90);
    return `<tr><td class="l">${esc(lab)}</td><td>${c}</td></tr>`;
  }
  TILES.dev = {
    id: "dev", title: "الأجهزة و الطابعات",
    tabs: [
      { id: "devices", t: "الأجهزة و الطابعات", render(host, ctx) {
        let cur = "printers";
        const draw = () => {
          const v = get("dev." + cur, {}), f = DEV_FORMS[cur];
          host.innerHTML = `<div class="pp-dev"><div class="pp-lt dark">الأجهزة و الطابعات</div><div class="pp-dvt">${DEV_TILES.map(t => `<button type="button" class="pp-dtile${t[0] === cur ? " on" : ""}" data-d="${t[0]}">${t[2]}<span>${t[1]}</span></button>`).join("")}</div>
            <div class="pp-dvf"><div class="pp-h">${esc(f.h)}</div><div class="pp-ld">${f.d}</div>${f.html(v)}</div></div>`;
          wire(host); wirePrinters(host); wireScale(host); wireDisplay(host); wireCaller(host); wireQr(host);
          host.querySelectorAll(".pp-dtile").forEach(b => b.onclick = () => { cur = b.dataset.d; draw(); });
        };
        draw();
        return () => put("dev." + cur, Object.assign(get("dev." + cur, {}), collect(host)));
      } },
      { id: "reader", t: "قارئ الأسعار", render(host, ctx) {
        /* مثل DEXEF ONE: حركة الصور (بصورة تلقائية / مع كل خبر) ، مدة الخبر ، مدة الأسعار ، الأخبار (الرسالة + لون الخلفية + لون الخط) */
        const k = "dev.reader", v = Object.assign({ anim: "مع كل خبر", newsSec: 5, priceSec: 7, news: [] }, get(k, {}));
        if (v.anim !== "بصورة تلقائية") v.anim = "مع كل خبر";
        v.news = (v.news || []).map(n => ({ t: n.t || "", bg: n.bg || "#c04000", fg: n.fg || "#ffffff" }));
        if (!Array.isArray(v.bgLib)) v.bgLib = ["aisle", "mesh"]; if (!Array.isArray(v.bgMine)) v.bgMine = []; v.bgItems = !!v.bgItems;
        const shrinkImg = f => new Promise(res => { const r = new FileReader(); r.onload = () => { const im = new Image(); im.onload = () => { const k = Math.min(1, 1920 / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement("canvas"); c.width = Math.round(im.naturalWidth * k); c.height = Math.round(im.naturalHeight * k); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL("image/jpeg", .86)); }; im.onerror = () => res(""); im.src = r.result; }; r.onerror = () => res(""); r.readAsDataURL(f); });
        const SW_BG = ["#c04000", "#dc2626", "#ea580c", "#ca8a04", "#16a34a", "#0d9488", "#0284c7", "#1e40af", "#7c3aed", "#db2777", "#111827", "#ffffff"];
        const SW_FG = ["#ffffff", "#111827", "#fde047", "#a5f3fc", "#fecaca", "#bbf7d0"];
        const editNews = i => {
          const n = i >= 0 ? Object.assign({}, v.news[i]) : { t: "", bg: "#c04000", fg: "#ffffff" };
          const sw = (L, cur, f) => L.map(c => `<button type="button" class="rn-sw${c.toLowerCase() === String(cur).toLowerCase() ? " on" : ""}" data-${f}="${c}" style="background:${c}" title="${c}"></button>`).join("");
          const body = `<div class="rn-ed"><label class="rn-l">الرسالة</label><textarea class="rn-t" rows="4" placeholder="مثال: تخفيضات نهاية الأسبوع على كل الشوكولاتة 🍫">${esc(n.t)}</textarea>
            <div class="rn-cols"><div><label class="rn-l">لون الخلفية</label><div class="rn-sws">${sw(SW_BG, n.bg, "bg")}<input type="color" class="rn-c" data-c="bg" value="${esc(n.bg)}" title="لون آخر"></div></div>
            <div><label class="rn-l">لون الخط</label><div class="rn-sws">${sw(SW_FG, n.fg, "fg")}<input type="color" class="rn-c" data-c="fg" value="${esc(n.fg)}" title="لون آخر"></div></div></div>
            <label class="rn-l">معاينة على الشاشة</label><div class="rn-pv"><div class="rn-pvn"></div></div></div>`;
          const d = dlg({ title: "الأخبار", w: 520, cls: "rn-dlg", body, buttons: [
            { t: "حفظ", cls: "blue", fn: d => { n.t = d.$(".rn-t").value.trim(); if (!n.t) { T("اكتب الرسالة أولاً", "w"); d.$(".rn-t").focus(); return; } if (i >= 0) v.news[i] = n; else v.news.push(n); d.close(); draw(); } },
            { t: "إغلاق", fn: d => d.close() }] });
          const pv = () => { const e = d.$(".rn-pvn"); e.style.background = n.bg; e.style.color = n.fg; e.textContent = d.$(".rn-t").value.trim() || "نص الخبر يظهر هنا"; d.$$(".rn-sw").forEach(b => b.classList.toggle("on", (b.dataset.bg || b.dataset.fg).toLowerCase() === String(b.dataset.bg ? n.bg : n.fg).toLowerCase())); d.$$(".rn-c").forEach(c => c.value = n[c.dataset.c]); };
          d.$(".rn-t").addEventListener("input", pv);
          d.$$(".rn-sw").forEach(b => b.onclick = () => { if (b.dataset.bg) n.bg = b.dataset.bg; else n.fg = b.dataset.fg; pv(); });
          d.$$(".rn-c").forEach(c => c.oninput = () => { n[c.dataset.c] = c.value; pv(); });
          pv(); setTimeout(() => d.$(".rn-t").focus(), 50);
        };
        const draw = () => {
          host.innerHTML = `<div class="pp-form rd-f"><div class="pp-h">شاشة قارئ الأسعار</div>
            ${rowHTML(["sel", "anim", "كيفية حركة الصور فى الخلفية ؟", v.anim, { opts: ["بصورة تلقائية", "مع كل خبر"], w: 170 }], v)}
            ${rowHTML(["num", "newsSec", "مدة عرض الخبر على الشاشة ؟", v.newsSec, { unit: "ثانية", min: 1 }], v)}
            ${rowHTML(["num", "priceSec", "مدة عرض أسعار الصنف على الشاشة ؟", v.priceSec, { unit: "ثانية", min: 1 }], v)}
            <div class="pp-rdh"><div class="pp-h">صور الخلفية</div><span class="rb-n">${(v.bgLib.length + v.bgMine.length) || "—"} مختارة</span></div>
            <div class="rb-g">${(window.ANOUER_RBG ? ANOUER_RBG.list : []).map(b => `<button type="button" class="rb-it${v.bgLib.indexOf(b.id) >= 0 ? " on" : ""}" data-lib="${b.id}" title="${esc(b.t)}"><i style="background-image:url(&quot;${ANOUER_RBG.url(b.id)}&quot;)"></i><span>${esc(b.t)}</span><b>✓</b></button>`).join("")}
              ${v.bgMine.map((u, i) => `<div class="rb-it on mine"><i style="background-image:url(&quot;${u}&quot;)"></i><span>صورتى ${i + 1}</span><button type="button" class="rb-del" data-mdel="${i}" title="حذف">✕</button></div>`).join("")}
              ${v.bgMine.length < 12 ? `<label class="rb-it rb-add"><input type="file" accept="image/*" multiple hidden><i>＋</i><span>صورة من جهازك</span></label>` : ""}</div>
            <label class="rb-ck"><input type="checkbox" data-bgitems${v.bgItems ? " checked" : ""}> إضافة صور أصنافى للخلفية أيضاً</label>
            <div class="pp-rdh"><div class="pp-h">الأخبار</div><button type="button" class="pp-plus" title="إضافة خبر">+</button></div>
            <table class="pp-grid rd-g"><colgroup><col style="width:34px"><col><col style="width:120px"><col style="width:120px"><col style="width:76px"></colgroup><thead><tr><th></th><th>الخبر</th><th>لون الخلفية</th><th>لون الخط</th><th></th></tr></thead><tbody>
            ${v.news.length ? v.news.map((n, i) => `<tr data-r="${i}"><td class="c rd-i">${i + 1}</td><td><div class="rd-nw" style="background:${esc(n.bg)};color:${esc(n.fg)}">${esc(n.t)}</div></td><td class="c"><span class="rd-cl"><i style="background:${esc(n.bg)}"></i>${esc(n.bg)}</span></td><td class="c"><span class="rd-cl"><i style="background:${esc(n.fg)}"></i>${esc(n.fg)}</span></td>
              <td class="c rd-a"><button type="button" class="pp-ib" data-up="${i}" title="أعلى"${i ? "" : " disabled"}>▲</button><button type="button" class="pp-ib" data-del="${i}" title="حذف">${IC.del}</button></td></tr>`).join("")
              : `<tr><td colspan="5" class="rd-empty">لا توجد أخبار — اضغط <b>+</b> لإضافة أول خبر (عرض، تخفيض، ترحيب …)</td></tr>`}</tbody></table>
            <div class="rd-run"><button type="button" class="pp-btn sm rd-pv">👁 معاينة</button><button type="button" class="pp-btn blue sm rd-go">▶ تشغيل شاشة قارئ الأسعار</button>
              <span class="rd-tip">تُفتح أيضاً من «ملف ← شاشة قارئ الأسعار» · الخروج: Esc مرتين</span></div></div>`;
          wire(host);
          host.querySelector(".pp-plus").onclick = () => { read(); editNews(-1); };
          host.querySelectorAll("[data-lib]").forEach(b => b.onclick = () => { read(); const id = b.dataset.lib, i = v.bgLib.indexOf(id); if (i >= 0) v.bgLib.splice(i, 1); else v.bgLib.push(id); draw(); });
          host.querySelectorAll("[data-mdel]").forEach(b => b.onclick = () => { read(); v.bgMine.splice(+b.dataset.mdel, 1); draw(); });
          const fi = host.querySelector(".rb-add input"); if (fi) fi.onchange = async () => { read(); for (const f of [...fi.files].slice(0, 12 - v.bgMine.length)) { const u = await shrinkImg(f); if (u) v.bgMine.push(u); } draw(); };
          const bi = host.querySelector("[data-bgitems]"); if (bi) bi.onchange = () => { v.bgItems = bi.checked; };
          host.querySelectorAll("tbody tr[data-r]").forEach(tr => tr.addEventListener("dblclick", () => { read(); editNews(+tr.dataset.r); }));
          host.querySelectorAll(".rd-nw").forEach(e => e.onclick = () => { read(); editNews(+e.closest("tr").dataset.r); });
          host.querySelectorAll("[data-del]").forEach(b => b.onclick = e => { e.stopPropagation(); read(); v.news.splice(+b.dataset.del, 1); draw(); });
          host.querySelectorAll("[data-up]").forEach(b => b.onclick = e => { e.stopPropagation(); read(); const i = +b.dataset.up; if (i > 0) { const t = v.news[i - 1]; v.news[i - 1] = v.news[i]; v.news[i] = t; draw(); } });
          const run = pv => { read(); put(k, v).then(() => { if (window.ANOUER_PRD) ANOUER_PRD.open({ preview: pv }); else T("شاشة قارئ الأسعار غير محمّلة", "e"); }); };
          host.querySelector(".rd-pv").onclick = () => run(true);
          host.querySelector(".rd-go").onclick = () => run(false);
        };
        const read = () => { const c = collect(host); v.anim = c.anim || v.anim; v.newsSec = Math.max(1, +c.newsSec || 5); v.priceSec = Math.max(1, +c.priceSec || 7); };
        draw();
        return () => { read(); return put(k, v).then(draw); };
      } }
    ]
  };

  // ==================================================================== 8) طريقة العرض
  let actx = null;
  /* أصوات DEXEF الأصلية (assets/sounds/Sound_N.wav) — نفس الملفات ونفس الأرقام؛ يُستعمل نغم مُولَّد فقط إن تعذّر الملف */
  const SND_HAVE = [10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99];
  const SND_CACHE = {}; let sndCur = null;
  function synth(n) {
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const o = actx.createOscillator(), g = actx.createGain(), f = 300 + (n % 50) * 22;
      o.type = ["sine", "triangle", "square"][n % 3]; o.frequency.value = f;
      g.gain.setValueAtTime(.0001, actx.currentTime); g.gain.exponentialRampToValueAtTime(.25, actx.currentTime + .02); g.gain.exponentialRampToValueAtTime(.0001, actx.currentTime + .45);
      o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + .5);
    } catch (e) { }
  }
  function playSound(n) {
    n = +n || 0; if (SND_HAVE.indexOf(n) < 0) { synth(n); return; }
    try {
      if (sndCur) { try { sndCur.pause(); sndCur.currentTime = 0; } catch (e) { } }
      const a = SND_CACHE[n] || (SND_CACHE[n] = new Audio("/assets/sounds/Sound_" + n + ".wav"));
      a.currentTime = 0; sndCur = a;
      const pr = a.play(); if (pr && pr.catch) pr.catch(() => synth(n));
    } catch (e) { synth(n); }
  }
  window.ANOUER_PLAY = playSound;
  /* تشغيل بصوت مرتفع (نغمة الخروج): Web Audio يرفع أي نغمة مختارة إلى أعلى مستوى واضح بدون تشويش
     (تكبير تلقائي حسب ذروة الصوت + ضاغط يمنع التقطيع) — إن تعذّر نرجع للتشغيل العادي */
  let AC = null; const BUF = {};
  function loudBuf(n) {
    if (BUF[n]) return BUF[n];
    return (BUF[n] = fetch("/assets/sounds/Sound_" + n + ".wav").then(r => r.arrayBuffer()).then(ab => {
      AC = AC || new (window.AudioContext || window.webkitAudioContext)();
      return new Promise((ok, no) => AC.decodeAudioData(ab, ok, no));
    }).catch(e => { delete BUF[n]; throw e; }));
  }
  function playLoud(n) {
    n = +n || 0; if (SND_HAVE.indexOf(n) < 0) { synth(n); return; }
    try {
      loudBuf(n).then(b => {
        if (AC.state === "suspended") AC.resume().catch(() => { });
        let pk = 0; for (let c = 0; c < b.numberOfChannels; c++) { const d = b.getChannelData(c); for (let i = 0; i < d.length; i += 4) { const v = Math.abs(d[i]); if (v > pk) pk = v; } }
        const src = AC.createBufferSource(), g = AC.createGain(), cp = AC.createDynamicsCompressor();
        g.gain.value = Math.min(16, Math.max(1, 0.98 / (pk || 1))) * 1.35;
        cp.threshold.value = -6; cp.knee.value = 6; cp.ratio.value = 12; cp.attack.value = 0.002; cp.release.value = 0.12;
        src.buffer = b; src.connect(g); g.connect(cp); cp.connect(AC.destination);
        if (sndCur) { try { sndCur.pause(); } catch (e) { } }
        src.start(0);
      }).catch(() => { const a = new Audio("/assets/sounds/Sound_" + n + ".wav"); a.volume = 1; a.play().catch(() => synth(n)); });
    } catch (e) { playSound(n); }
  }
  window.ANOUER_PLAY_LOUD = playLoud;
  /* تحميل مسبق لأصوات الأحداث المستعملة حتى تُسمع فوراً (مثل حوار الخروج) */
  setTimeout(() => { try { const v = get("view.gen", {}); [["sSave", 56], ["sNews", 96], ["sErr", 27], ["sEdit", 54], ["sDel", 86], ["sExit", 60]].forEach(m => { const k = +String(v[m[0]] || ("Sound_" + m[1])).replace(/\D/g, "") || m[1]; if (SND_HAVE.indexOf(k) >= 0 && !SND_CACHE[k]) { const a = new Audio("/assets/sounds/Sound_" + k + ".wav"); a.preload = "auto"; SND_CACHE[k] = a; } if (m[0] === "sExit" && SND_HAVE.indexOf(k) >= 0) loudBuf(k).catch(() => { }); }); } catch (e) { } }, 1500);
  const SND_LAST = {};
  window.ANOUER_SOUND = ev => { const now = Date.now(), g = ev === "error" ? "err" : ev; if (now - (SND_LAST[g] || 0) < 450) return; SND_LAST[g] = now; const v = get("view.gen", {}); const m = { save: ["sSave", 56], news: ["sNews", 96], err: ["sErr", 27], error: ["sErr", 27], edit: ["sEdit", 54], del: ["sDel", 86], exit: ["sExit", 60] }[ev]; if (!m) return; if (v[m[0] + "On"] === false) return; const k = +String(v[m[0]] || ("Sound_" + m[1])).replace(/\D/g, "") || m[1]; if (ev === "exit") playLoud(k); else playSound(k); };

  /* حوار الخروج من البرنامج (مطابق DEXEF): أيقونة الخروج، «هل تريد الخروج من البرنامج ؟»، نعم / لا — مع نغمة التنبيه بالخروج */
  const EXIT_IC = '<svg viewBox="0 0 48 48"><defs><linearGradient id="exG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a95ff"/><stop offset="1" stop-color="#0b5ad0"/></linearGradient></defs><rect x="2" y="2" width="44" height="44" rx="11" fill="url(#exG)"/><rect x="2.6" y="2.6" width="42.8" height="42.8" rx="10.4" fill="none" stroke="#fff" stroke-opacity=".28"/><path d="M10.5 10.5h12v27h-12z" fill="#fff" fill-opacity=".16" stroke="#fff" stroke-opacity=".7" stroke-width="2" stroke-linejoin="round"/><circle cx="30" cy="11.2" r="3.6" fill="#fff"/><g fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M28.6 16.4l-4.2 9.8"/><path d="M27.8 18.2l5.4 3 3.6-1.8"/><path d="M26.6 18.4l-5.4 1.8-2.4 4"/><path d="M24.4 26.2l6 3.6.6 7.4"/><path d="M24.4 26.2l-3.2 6.2-5.4 1.6"/></g></svg>';
  let exitDlg = null;
  /* مطابق DEXEF: لا يُسمح بالخروج وفي البرنامج فاتورة بها أصناف لم تُحفظ (مبيعات / مرتجع / مشتريات …) */
  function busyInvoice() {
    const TB = window.__tabs; if (!TB || !TB.TABS) return null;
    const P = window.ANOUER_PURCHASES, list = TB.TABS.slice().sort((a, b) => (b.key === TB.ACTIVE) - (a.key === TB.ACTIVE));
    for (const t of list) {
      try {
        if (t.view === "sales" && (TB.sessInfo(t.key) || {}).n) return t;
        const d = P && P.docs && P.docs[t.key];
        if (d && d.isDirty && d.isDirty()) return t;
      } catch (e) { }
    }
    return null;
  }
  window.__busyInvoice = busyInvoice;
  window.__askExit = function () {
    if (exitDlg) return;
    const em = document.getElementById("emOv");
    if (em && em.classList.contains("show")) return;
    const bi = busyInvoice();
    if (bi && window.__emAlert) {
      try { if (window.__tabs.ACTIVE !== bi.key) window.__tabs.activate(bi.key); } catch (e) { }
      window.__emAlert("لا يمكنك غلق الفاتورة طالما يوجد أصناف مضافة بداخلها");
      return;
    }
    try { ANOUER_SOUND("exit"); } catch (e) { }
    const yes = () => { try { if (window.Anouer && Anouer.available && Anouer.exitApp) { Anouer.exitApp(); return; } } catch (e) { } try { if (window.__host) __host("win.close", { force: true }); } catch (e) { } };
    exitDlg = window.__PP.dlg({ title: "", w: 590, cls: "pp-exit", body: `<div class="pp-exit-b"><span class="ic">${EXIT_IC}</span><span class="msg">هل تريد الخروج من البرنامج ؟</span></div>`,
      buttons: [{ t: "نعم", cls: "green", fn: d => { d.close(); yes(); } }, { t: "لا", cls: "blue", fn: d => d.close() }], onClose: () => { exitDlg = null; } });
    if (exitDlg) setTimeout(() => { const b = exitDlg.foot.querySelectorAll(".pp-btn")[1]; if (b) b.focus(); }, 30);
  };
  const SOUNDS = [["sSave", "نغمة الحفظ بنجاح", 56], ["sNews", "نغمة الاشعارات الجديدة", 96], ["sErr", "نغمة الخطأ", 27], ["sEdit", "نغمة التنبيه بالتعديل", 54], ["sDel", "نغمة التنبيه بالحذف", 86], ["sExit", "نغمة التنبيه بالخروج من البرنامج", 60]];
  const SND_OPTS = SND_HAVE.map(n => "Sound_" + n);
  const VIEW_DOCS = [["المبيعات", [["فاتورة المبيعات", "فاتورة الكاشير"], ["فاتورة مرتجع المبيعات", "فاتورة الكاشير"], ["عرض سعر", "الفاتورة المتقدمة"], ["أمر توريد", "الفاتورة المتقدمة"], ["فاتورة أولية", "الفاتورة المتقدمة"], ["تدقيق المبيعات", "الفاتورة المتقدمة"], ["فحص المبيعات المرتجعة", "الفاتورة المتقدمة"]]],
    ["المشتريات", [["فاتورة المشتريات", "الفاتورة المتقدمة"], ["طلبية شراء", "الفاتورة المتقدمة"], ["إذن استلام", "الفاتورة المتقدمة"], ["فاتورة مرتجع المشتريات", "الفاتورة المتقدمة"], ["أمر توريد شراء", "الفاتورة المتقدمة"]]],
    ["المخازن", D.WH_TYPES.map(n => [n, "الفاتورة المتقدمة"])]];
  const VIEW_KINDS = ["الفاتورة المتقدمة", "فاتورة الكاشير", "فاتورة اللمس", "فاتورة الكاشير ملأ الشاشة", "فاتورة اللمس ملأ الشاشة"];
  const VK_IC = { "الفاتورة المتقدمة": '<svg viewBox="0 0 16 16"><rect x="2" y="1.5" width="12" height="13" rx="1" fill="#fff" stroke="#1d6fd6"/><path d="M4 5h8M4 8h8M4 11h5" stroke="#1d6fd6"/><circle cx="12" cy="12" r="2.6" fill="#1d6fd6"/><path d="M12 10.6v2.8M10.6 12h2.8" stroke="#fff" stroke-width=".9"/></svg>',
    "فاتورة الكاشير": '<svg viewBox="0 0 16 16"><rect x="1.5" y="6" width="13" height="8.5" rx="1" fill="#1d6fd6"/><rect x="3" y="2" width="10" height="4" rx="1" fill="#6aa5ee"/><g fill="#fff"><rect x="3.5" y="8" width="2" height="1.5"/><rect x="7" y="8" width="2" height="1.5"/><rect x="10.5" y="8" width="2" height="1.5"/><rect x="3.5" y="11" width="2" height="1.5"/><rect x="7" y="11" width="2" height="1.5"/><rect x="10.5" y="11" width="2" height="1.5"/></g></svg>',
    "فاتورة اللمس": '<svg viewBox="0 0 16 16"><path d="M6 14.5c-2 0-3.5-1.5-3.5-3.5V8.5a1 1 0 0 1 2 0V10V3.5a1 1 0 0 1 2 0V8V5.5a1 1 0 0 1 2 0V8V6.5a1 1 0 0 1 2 0V8V7.5a1 1 0 0 1 2 0V11c0 2-1.5 3.5-3.5 3.5z" fill="#1d6fd6"/></svg>' };
  VK_IC["فاتورة الكاشير ملأ الشاشة"] = VK_IC["فاتورة الكاشير"]; VK_IC["فاتورة اللمس ملأ الشاشة"] = VK_IC["فاتورة اللمس"];
  /* معاينة مصغّرة بشكل كل نوع (كما فى DEXEF) */
  function invPreview(kind) {
    const full = /ملأ الشاشة/.test(kind), k = /اللمس/.test(kind) ? "touch" : /الكاشير/.test(kind) ? "cash" : "adv";
    if (k === "adv") return `<div class="pp-ivp adv${full ? " full" : ""}"><div class="t"><i></i><i></i><b></b><i></i></div><div class="ab"><div class="side">${["#2e8b57", "#1f6fd0", "#5b7fa6", "#1f6fd0", "#0b4e93", "#6c8aa8", "#4d8ad8", "#3f6f9f"].map(c => `<em style="background:${c}"></em>`).join("")}</div><div class="bd"><div class="ttl">فاتورة مبيعات</div><div class="hd">${"<span></span>".repeat(8)}</div><div class="g"><p class="h"></p>${"<p></p>".repeat(3)}<p class="s"></p>${"<p></p>".repeat(7)}</div><div class="f"><span class="n">33</span><span class="bx"></span><span class="bt"></span><span class="bt"></span></div></div></div></div>`;
    if (k === "cash") return `<div class="pp-ivp cash${full ? " full" : ""}"><div class="t"><i></i><i></i><b></b></div><div class="cb"><div class="ls"><div class="hd">${"<span></span>".repeat(6)}</div><div class="g">${"<p></p>".repeat(4)}<p class="s"></p>${"<p></p>".repeat(7)}</div><div class="fb"><em></em><em></em><em></em><em></em></div><div class="fg"><b></b><b></b><b></b></div></div><div class="rs"><div class="q"></div><div class="l">${"<p></p>".repeat(14)}</div><div class="or">38.10</div><div class="tt">${"<p></p>".repeat(5)}</div></div></div></div>`;
    return `<div class="pp-ivp touch${full ? " full" : ""}"><div class="t"><i></i><b></b><i></i></div><div class="tb"><div class="ls"><div class="hd"><em></em></div><div class="g">${"<p></p>".repeat(9)}</div><div class="or">390.00</div><div class="tt">${"<p></p>".repeat(5)}</div></div><div class="md"><div class="tl">${"<p></p>".repeat(15)}</div><div class="bb"><em></em><em></em><em></em><em></em><em></em><em></em></div><div class="sv"><b></b><b></b></div></div><div class="rs">${"<p></p>".repeat(5)}</div></div></div>`;
  }
  /* فاتورة اللمس متاحة لفاتورة المبيعات ومرتجعها فقط — باقي المستندات: المتقدمة / الكاشير / الكاشير ملأ الشاشة */
  const vkOpts = doc => /^فاتورة (مرتجع )?المبيعات$/.test(doc) ? VIEW_KINDS : VIEW_KINDS.filter(k => !/اللمس/.test(k));
  /* صور حقيقية لكل واجهة (assets/img/vk) — فاتورة المبيعات/مرتجعها لها واجهات البيع ، وباقي المستندات واجهات المستند */
  const VK_NA = new Set(["فاتورة أولية", "تدقيق المبيعات", "فحص المبيعات المرتجعة", "أمر توريد شراء", "إذن إضافة", "تسوية جردية"]);   // مستندات لم تُبنَ بعد فى البرنامج
  const isSaleInv = doc => /^فاتورة (مرتجع )?المبيعات$/.test(doc);
  const vkImg = (doc, kind) => "/assets/img/vk/" + (isSaleInv(doc) ? "sale" : "doc") + "-" + (/اللمس/.test(kind) ? "touch" : /الكاشير/.test(kind) ? "cash" : "adv") + (/ملأ الشاشة/.test(kind) ? "-full" : "") + ".jpg";
  const VK_DESC = { "الفاتورة المتقدمة": "لوحة أوامر جانبية + جدول أصناف واسع — للعمل المكتبى والفواتير الطويلة",
    "فاتورة الكاشير": "شاشة نقطة البيع: بحث سريع ، إجمالى كبير ، وأزرار F للدفع والحفظ",
    "فاتورة اللمس": "مربعات أصناف ومجموعات كبيرة للمس بالإصبع — مثالية للشاشات اللمسية",
    "فاتورة الكاشير ملأ الشاشة": "نفس الكاشير بدون شريط القوائم والتبويبات — تركيز كامل على البيع",
    "فاتورة اللمس ملأ الشاشة": "واجهة اللمس على كامل الشاشة — للمحلات والمطاعم" };
  function viewTypesDlg() {
    const v = get("view.types", {});
    const row = r => { const na = VK_NA.has(r[0]), val = v[r[0]] || r[1], ok = vkOpts(r[0]).includes(val) ? val : r[1];
      return `<div class="pp-ar${na ? " na" : ""}" data-doc="${esc(r[0])}"><span class="l">${esc(r[0])}${na ? '<em class="pp-vtna">قريباً</em>' : ""}</span><span class="v2"><span class="vi">${VK_IC[ok] || VK_IC["الفاتورة المتقدمة"]}</span>${sel(vkOpts(r[0]), ok, null, 170).replace("<select", `<select data-doc="${esc(r[0])}" data-def="${esc(r[1])}"${na ? " disabled" : ""}`)}</span></div>`; };
    const d = dlg({ title: "", w: 1120, cls: "pp-vt", body: `<div class="pp-vth"><div class="pp-lt dark">أنواع الفواتير</div><div class="pp-ld">يوفر البرنامج ثلاثة تصميمات للفواتير تعمل جميعها بنفس الخصائص و لكنها مختلفة فى طريقة عرضها فقط حتى توافر على المستخدم البيئة المناسبة للتعامل اليومى . يرجى أختيار التصميم المناسب لكل نوع من أنواع الفواتير المعروضة</div><div class="pp-vtn"><i>✦</i><span>التغيير يُطبَّق على <b>الفواتير الجديدة</b> فقط (زر <kbd>+</kbd>) — الفاتورة التى تعمل عليها الآن تبقى بنفس شكلها حتى تحفظها أو تغلقها.</span></div></div>
      <div class="pp-vtb"><div class="pp-vtl">${VIEW_DOCS.map(g => `<div class="pp-ag"><div class="pp-agh"><span>${g[0]}</span><i>⌃</i></div><div class="pp-agb">${g[1].map(row).join("")}</div></div>`).join("")}</div>
      <div class="pp-vtr"><div class="pp-vtbtn"><button type="button" class="pp-btn green big pp-vs">حفظ</button><button type="button" class="pp-btn blue big pp-vc">اغلاق</button></div>
        <div class="pp-vtpv"><div class="vkp"><div class="vkp-bar"><i></i><i></i><i></i><b class="vkp-t"></b><span class="vkp-bd"></span></div>
          <div class="vkp-st" title="تكبير"><img class="vkp-a on" alt=""><img class="vkp-b" alt=""><span class="vkp-zm">⤢ تكبير</span><span class="vkp-ld"></span></div></div>
          <div class="vkp-d"></div><div class="vkp-th"></div></div></div></div>`, buttons: [] });
    const P = d.$(".pp-vtpv"), A = P.querySelector(".vkp-a"), B = P.querySelector(".vkp-b"), ST = P.querySelector(".vkp-st");
    let cur = "فاتورة المبيعات", shown = "", tok = 0;
    const selOf = doc => d.body.querySelector(`select[data-doc="${doc.replace(/"/g, '\\"')}"]`);
    function show(doc) {
      const s = selOf(doc); if (!s || VK_NA.has(doc)) return; cur = doc; const kind = s.value, src = vkImg(doc, kind);
      d.$$(".pp-vtl .pp-ar").forEach(r => r.classList.toggle("cur", r.dataset.doc === doc));
      P.querySelector(".vkp-t").textContent = doc + "  ·  " + kind;
      P.querySelector(".vkp-bd").textContent = /ملأ الشاشة/.test(kind) ? "ملأ الشاشة" : /اللمس/.test(kind) ? "لمس" : "";
      P.querySelector(".vkp-bd").hidden = !P.querySelector(".vkp-bd").textContent;
      P.querySelector(".vkp-d").textContent = VK_DESC[kind] || "";
      P.querySelector(".vkp-th").innerHTML = vkOpts(doc).map(k => `<button type="button" class="vkp-tb${k === kind ? " on" : ""}" data-k="${esc(k)}" title="${esc(k)}"><img src="${vkImg(doc, k)}" alt="" loading="lazy"><span>${esc(k.replace(/^(ال)?فاتورة /, ""))}</span></button>`).join("");
      if (src === shown) return; shown = src; const t = ++tok; ST.classList.add("ld");
      const im = new Image(); im.onload = im.onerror = () => { if (t !== tok) return; ST.classList.remove("ld");
        const on = A.classList.contains("on") ? A : B, off = on === A ? B : A; off.src = src; off.classList.add("on"); on.classList.remove("on"); };
      im.src = src;
    }
    show(cur);
    d.body.addEventListener("click", e => {
      const h = e.target.closest(".pp-agh"); if (h) { h.parentNode.classList.toggle("col"); return; }
      const tb = e.target.closest(".vkp-tb"); if (tb) { const s = selOf(cur); if (s && s.value !== tb.dataset.k) { s.value = tb.dataset.k; s.dispatchEvent(new Event("change", { bubbles: true })); } return; }
      if (e.target.closest(".vkp-st")) { zoom(); return; }
      const r = e.target.closest(".pp-vtl .pp-ar"); if (r && !r.classList.contains("na")) show(r.dataset.doc);
    });
    d.body.addEventListener("focusin", e => { const s = e.target.closest("select[data-doc]"); if (s) show(s.dataset.doc); });
    d.body.addEventListener("change", e => { const s = e.target.closest("select[data-doc]"); if (!s) return; s.parentNode.querySelector(".vi").innerHTML = VK_IC[s.value] || ""; show(s.dataset.doc); });
    function zoom() {
      const z = document.createElement("div"); z.className = "vkp-zov"; z.innerHTML = `<figure><img src="${shown}" alt=""><figcaption>${esc(P.querySelector(".vkp-t").textContent)}</figcaption></figure><button type="button" class="vkp-zx" aria-label="إغلاق">✕</button>`;
      document.body.appendChild(z); requestAnimationFrame(() => z.classList.add("in"));
      const close = () => { z.classList.remove("in"); window.removeEventListener("keydown", k, true); setTimeout(() => z.remove(), 200); };
      const k = e => { if (e.key === "Escape" || e.key === "Enter") { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); close(); } };
      window.addEventListener("keydown", k, true); z.addEventListener("click", close);
    }
    d.$(".pp-vc").onclick = () => d.close();
    d.$(".pp-vs").onclick = () => {
      const o = {}, was = {}; d.$$("select[data-doc]").forEach(s => { o[s.dataset.doc] = s.value; was[s.dataset.doc] = v[s.dataset.doc] || s.dataset.def; });
      try { if (window.__vk) __vk.stampAll(); } catch (e) { }   // الفواتير المفتوحة تحتفظ بشكلها الحالي
      put("view.types", o).then(() => { T("تم الحفظ", "s"); d.close(); try { if (window.__touchApply) __touchApply(); if (window.__vk) __vk.apply(); if (window.__vkNotice) __vkNotice(was, o); } catch (e) { } });
    };
  }
  const BGS = ["linear-gradient(135deg,#c9b38f,#7a6a50)", "linear-gradient(135deg,#9fc5e8,#d9c9a3)", "linear-gradient(135deg,#f5f5f5,#dcdcdc)", "linear-gradient(135deg,#1c3b4a,#6b9aa6)", "linear-gradient(135deg,#0f2a12,#7fb069)", "linear-gradient(135deg,#a8c6df,#e8f1f8)", "linear-gradient(135deg,#d9a066,#5b3a1c)", "linear-gradient(135deg,#355c7d,#c06c84)", "linear-gradient(135deg,#ffecd2,#fcb69f)"];
  function applyBg() { const v = get("view.bg", {}); const h = document.getElementById("homeView"); if (!h) return; h.style.background = v.img ? `url("${v.img}") center/cover` : v.grad || ""; }
  setTimeout(() => P.load().then(applyBg), 1500);
  TILES.view = {
    id: "view", title: "طريقة العرض",
    tabs: [
      { id: "gen", t: "عام", type: "form", rows: [
        ["h", "عام"], ["tg", "askSave", "ظهور رسالة تنبيه قبل حفظ أى تعامل ؟", false], ["tg", "askEdit", "ظهور رسالة تنبيه قبل التعديل أى تعامل ؟", true],
        ["sel", "totals", "ظهور شاشة الاجماليات بعد حفظ الفاتورة", "ظهور دائماً", { opts: ["ظهور دائماً", "فى الكاشير فقط", "عدم الظهور"], w: 170 }],
        ["sel", "enter", "طريقة إستخدام Enter فى التنقل بين حقول الفاتورة", "إضافة الصنف مباشرة", { opts: ["إضافة الصنف مباشرة", "الانتقال للخانة التالية", "الانتقال للصنف التالى"], w: 170 }],
        ["sel", "savePrint", "عند الضغط على حفظ و طباعة ما الذى تود فعله ؟", "عرض التعامل أولاً قبل طباعة", { opts: ["عرض التعامل أولاً قبل طباعة", "الطباعة مباشرة", "الحفظ بدون طباعة"], w: 170 }],
        ["gap", 16], ["h", "النغمات"]
      ].concat(SOUNDS.map(s => ["tg", s[0] + "On", s[1], true, { lb: ["مفعلة", "غير مفعلة"], extra: "", cls: "pp-sndr" }])),
      onRender(host, v) {
        /* قيمة قديمة فارغة ← الافتراضى (حتى لا تظهر القائمة فارغة) */
        [["totals", "ظهور دائماً"], ["enter", "إضافة الصنف مباشرة"]].forEach(m => { const e = host.querySelector(`select[data-pk="${m[0]}"]`); if (e && !e.value) e.value = m[1]; });
        const HINT = { "إضافة الصنف مباشرة": "يُضاف الصنف ويبقى المؤشر فى خانة البحث للصنف التالى", "الانتقال للخانة التالية": "Enter ينقل: الكمية ← السعر ← … ثم يرجع للبحث", "الانتقال للصنف التالى": "Enter داخل أى خانة بالسطر يعتمدها ويرجع للبحث مباشرة" };
        const es = host.querySelector('select[data-pk="enter"]'); if (es) { const h = document.createElement("div"); h.className = "pp-ehint"; const up = () => { h.textContent = "↵ " + (HINT[es.value] || ""); }; up(); es.addEventListener("change", up); es.closest(".pp-row").after(h); }
        SOUNDS.forEach(s => {
          const t = host.querySelector(`[data-pk="${s[0]}On"]`), c = t.closest(".pp-ctl"), x = document.createElement("span"); x.className = "pp-snd";
          x.innerHTML = sel(SND_OPTS.map(o => [o, "نغمة " + o.replace(/\D/g, "")]), v[s[0]] || "Sound_" + s[2], s[0], 104) + `<button type="button" class="pp-play" title="استماع" aria-label="استماع"><svg viewBox="0 0 12 12"><path d="M3.5 2.2v7.6L10 6z"/></svg></button>`;
          c.appendChild(x);
          const sl = x.querySelector("select"), pb = x.querySelector(".pp-play");
          const sync = () => { const on = t.classList.contains("on"); x.classList.toggle("off", !on); sl.disabled = !on; pb.disabled = !on; };
          sync(); new MutationObserver(sync).observe(t, { attributes: true, attributeFilter: ["class"] });
          const play = () => { pb.classList.remove("pl"); void pb.offsetWidth; pb.classList.add("pl"); clearTimeout(pb._t); pb._t = setTimeout(() => pb.classList.remove("pl"), 900); playSound(+sl.value.replace(/\D/g, "")); };
          pb.onclick = play; sl.addEventListener("change", play);   // اختيار نغمة = سماعها مباشرة
        });
      } },
      { id: "types", t: "أنواع الفواتير", render(host, ctx) { host.innerHTML = '<div class="pp-empty2"><button type="button" class="pp-btn blue">أنواع الفواتير ...</button></div>'; host.querySelector("button").onclick = viewTypesDlg; setTimeout(viewTypesDlg, 0); return null; } },
      { id: "bg", t: "صورة الخلفية", render(host, ctx) {
        const v = get("view.bg", {});
        const tiles = [["#1f8f8a", "الشركات", 1, 1], ["#444", "سجل الفترات", 1, 1], ["#8b2cc9", "الحضور والانصراف", 2, 1], ["#0d8a3a", "الرواتب", 2, 1], ["#6a8c2a", "نظام الفترات", 2, 1], ["#2e8de6", "الموظفين", 2, 1], ["#6b57c9", "الفروق المالية", 2, 1], ["#7d6bd6", "التحويل", 1, 1], ["#123f73", "تحديد الأعمال", 1, 1], ["#1fa198", "التوقيع والزيارات", 2, 1], ["#2f2f2f", "المهام", 1, 1], ["#a11f5d", "الاجراءات", 1, 1], ["#5b2f7a", "انهاء الموظفين", 2, 1]];
        const pv = () => v.img ? `url("${v.img}") center/cover` : (v.grad || "#fff");
        host.innerHTML = `<div class="pp-bg"><button type="button" class="pp-bgsave">حفظ <span>✓</span></button>
          <div class="pp-bgpv" style="background:${pv()}"><div class="pp-bgt">${tiles.map(t => `<span style="background:${t[0]};grid-column:span ${t[2]}">${esc(t[1])}</span>`).join("")}</div></div>
          <div class="pp-bgth">${BGS.map((g, i) => `<button type="button" class="pp-bgi${v.grad === g && !v.img ? " on" : ""}" data-i="${i}" style="background:${g}"></button>`).join("")}</div>
          <div class="pp-bgbt"><button type="button" class="pp-btn ol pp-browse">تصفح</button><a href="#" class="pp-nobg">بدون خلفية</a><input type="file" accept="image/*" hidden></div></div>`;
        const box = host.querySelector(".pp-bgpv"), fi = host.querySelector("input[type=file]");
        const upd = () => { box.style.background = pv(); host.querySelectorAll(".pp-bgi").forEach((b, i) => b.classList.toggle("on", !v.img && v.grad === BGS[i])); };
        host.querySelectorAll(".pp-bgi").forEach(b => b.onclick = () => { v.img = ""; v.grad = BGS[+b.dataset.i]; upd(); });
        host.querySelector(".pp-browse").onclick = () => fi.click();
        fi.onchange = () => { const f = fi.files[0]; if (!f) return; if (f.size > 3 * 1048576) { T("حجم الصورة كبير (الحد 3 ميجا)", "w"); return; } const r = new FileReader(); r.onload = () => { v.img = r.result; upd(); }; r.readAsDataURL(f); };
        host.querySelector(".pp-nobg").onclick = e => { e.preventDefault(); v.img = ""; v.grad = ""; upd(); };
        host.querySelector(".pp-bgsave").onclick = () => put("view.bg", v).then(() => { applyBg(); T("تم حفظ صورة الخلفية", "s"); });
        return null;
      } }
    ]
  };

  // ==================================================================== 9) شريط الأخبار
  function newsSync(rows) {
    const d0 = new Date(), now = new Date(d0.getTime() - d0.getTimezoneOffset() * 6e4).toISOString().slice(0, 16);
    const live = rows.filter(r => r.active !== false && (!r.from || r.from <= now) && (!r.to || r.to >= now));
    const text = live.map(r => r.title).join("\n");
    const done = () => { if (window.ANOUER_TICKER) { if (live.length && !window.ANOUER_TICKER.on) window.ANOUER_TICKER.show(true); else window.ANOUER_TICKER.refresh(); return; } if (window.__news) { if (live.length && !window.__news.on) window.__news.show(true); else window.__news.refresh(); } };
    if (HOST()) call("fm.settings.set", { values: { "News.Text": text } }).then(done).catch(() => { }); else done();
  }
  TILES.news = {
    id: "news", title: "شريط الأخبار",
    custom(box, back) {
      let rows = get("news.items", []), fAct = true, per = "الثلاث شهور السابقة";
      const fmtDt = s => s ? s.replace("T", " ") : "";
      const draw = () => {
        const lim = { "اليوم": 1, "الاسبوع الحالي": 7, "الشهر الحالى": 31, "الشهر السابق": 62, "الثلاث شهور السابقة": 92, "السنة الحالية": 366 }[per];
        const since = lim ? new Date(Date.now() - lim * 864e5).toISOString().slice(0, 10) : "";
        const vis = rows.map((r, i) => Object.assign({ __i: i }, r)).filter(r => (fAct ? r.active !== false : r.active === false) && (!since || (r.added || "") >= since));
        box.innerHTML = `<div class="pp-nw"><div class="pp-nwr"><button type="button" class="pp-back">${IC.back}</button><div class="pp-lt dark">شريط الأخبار</div><div class="pp-ld">تستخدم إدارة الأخبار كنوع من أنواع التنبيهات التى تظهر على جميع المستخدمين .. فى صورة شريط اخبار متحرك</div><button type="button" class="pp-btn blue wide pp-new">إضافة خبر</button><button type="button" class="pp-btn wide nwx-cfgb">إعدادات الشريط</button><button type="button" class="pp-btn wide nwx-prvb">${window.ANOUER_TICKER && window.ANOUER_TICKER.on ? "إخفاء الشريط" : "إظهار الشريط"}</button></div>
          <div class="pp-nwl"><div class="pp-tb top"><div class="pp-fl"><label>فترة البحث</label><select class="pp-sel pp-per" style="width:170px">${optHTML(PERIODS, per)}</select></div><div class="pp-fl"><label>الحالة</label><select class="pp-sel pp-st" style="width:80px"><option value="1"${fAct ? " selected" : ""}>نشط</option><option value="0"${fAct ? "" : " selected"}>غير نشط</option></select></div></div>
          ${gridHTML([["added", "تاريخ الإضافة", 150, "eq"], ["title", "الخبر", "38%"], ["desc", "التفاصيل"]], vis.map(r => Object.assign({}, r, { title: (r.urgent ? "🔴 عاجل — " : "") + r.title })))}</div></div>`;
        box.querySelector(".pp-back").onclick = back;
        box.querySelector(".pp-per").onchange = e => { per = e.target.value; draw(); };
        box.querySelector(".pp-st").onchange = e => { fAct = e.target.value === "1"; draw(); };
        const tbl = box.querySelector(".pp-grid"); wireFilter(tbl);
        box.querySelector(".pp-new").onclick = () => ed(-1);
        box.querySelector(".nwx-cfgb").onclick = cfgDlg;
        box.querySelector(".nwx-prvb").onclick = e => { const K = window.ANOUER_TICKER; if (!K) return; K.show(!K.on); e.target.textContent = K.on ? "إخفاء الشريط" : "إظهار الشريط"; };
        tbl.addEventListener("dblclick", e => { const tr = e.target.closest("tr[data-r]"); if (tr) ed(+tr.dataset.r); });
        tbl.addEventListener("click", e => { const tr = e.target.closest("tr[data-r]"); if (!tr) return; tbl.querySelectorAll("tr.sel").forEach(x => x.classList.remove("sel")); tr.classList.add("sel"); });
        tbl.addEventListener("contextmenu", e => { const tr = e.target.closest("tr[data-r]"); if (!tr) return; e.preventDefault(); P.ctxMenu(e.clientX, e.clientY, [["تعديل", () => ed(+tr.dataset.r)], ["حذف", () => ask("حذف الخبر ؟", () => { rows.splice(+tr.dataset.r, 1); put("news.items", rows).then(() => { draw(); newsSync(rows); }); })]]); });
      };
      const ed = i => {
        const now = new Date(), iso = d => new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 16);
        const v = i < 0 ? { title: "", from: iso(now), to: iso(new Date(now.getTime() + 36e5)), desc: "", active: true } : clone(rows[i]);
        dlg({ title: "", w: 440, cls: "pp-nwd", body: `<div class="pp-nwt">شريط الاخبار</div><div class="pp-form2 col">
          ${fHTML(["txt", "title", "العنوان", v.title, { req: 1 }], {})}
          <div class="pp-fr col"><label>يبدأ فى <i class="pp-req">*</i></label><div class="pp-fc"><input class="pp-txt" type="datetime-local" data-pk="from" data-t="txt" value="${esc(v.from)}"></div></div>
          <div class="pp-fr col"><label>ينتهى فى <i class="pp-req">*</i></label><div class="pp-fc"><input class="pp-txt" type="datetime-local" data-pk="to" data-t="txt" value="${esc(v.to)}"></div></div>
          <div class="pp-fr col"><label>نوع الخبر</label><div class="pp-fc"><select class="pp-sel" data-pk="cat" data-t="txt">${[["news", "خبر"], ["promo", "عرض / تخفيض"], ["warn", "تنبيه"]].map(o => `<option value="${o[0]}"${(v.cat || "news") === o[0] ? " selected" : ""}>${o[1]}</option>`).join("")}</select></div></div>
          ${fHTML(["area", "desc", "الوصف", v.desc, { h: 110 }], {})}
          <div class="nwx-ed-row"><label class="pp-chk blk nwx-ed-urg"><input type="checkbox" data-pk="urgent" data-t="chk"${v.urgent ? " checked" : ""}> <b>عاجل</b> <small>يظهر بشريط أحمر فوق الأخبار مع صوت</small></label><label class="pp-chk blk end"><input type="checkbox" data-pk="active" data-t="chk"${v.active !== false ? " checked" : ""}> نشط</label></div></div>`,
          buttons: [{ t: "موافق", cls: "blue2 big", fn: d => { const nv = collect(d.body); if (!nv.title.trim()) { T("أدخل العنوان", "w"); d.$('[data-pk="title"]').focus(); return; } if (nv.to && nv.from && nv.to < nv.from) { T("تاريخ الانتهاء قبل تاريخ البدء", "w"); return; }
            nv.added = i < 0 ? today() : (rows[i].added || today()); if (i < 0) rows.unshift(nv); else rows[i] = nv; put("news.items", rows).then(() => { d.close(); draw(); newsSync(rows); T("تم الحفظ", "s"); }); } },
            { t: "إغلاق", cls: "blue big", fn: d => d.close() }] });
      };
      /* إعدادات الشريط: المكان، السرعة، ملخص البرنامج، الساعة، «عاجل» */
      const cfgDlg = () => {
        const K = window.ANOUER_TICKER, c = Object.assign({}, (K && K.DEF) || {}, get("news.cfg", {}));
        const sp = ["", "بطيء جداً", "بطيء", "متوسط", "سريع", "سريع جداً"];
        const dd = dlg({ title: "إعدادات شريط الأخبار", w: 470, cls: "nwx-cfg", body: `<div class="nwx-cfg-b">
          <div class="nwx-cr"><label>مكان الشريط</label><div class="nwx-seg2" data-k="pos"><button type="button" data-v="bottom"${c.pos !== "top" ? ' class="on"' : ""}>أسفل الشاشة</button><button type="button" data-v="top"${c.pos === "top" ? ' class="on"' : ""}>أعلى الشاشة</button></div></div>
          <div class="nwx-cr"><label>سرعة الحركة <b class="nwx-spl">${sp[c.speed] || "متوسط"}</b></label><input type="range" min="1" max="5" step="1" value="${+c.speed || 3}" class="nwx-sp"></div>
          <label class="nwx-cr nwx-ck"><input type="checkbox" class="nwx-sys"${c.sys !== false ? " checked" : ""}><span><b>ملخص البرنامج الحي</b><small>مبيعات اليوم، الخزينة، الديون، حد الطلب…</small></span></label>
          <label class="nwx-cr nwx-ck"><input type="checkbox" class="nwx-clkc"${c.clock !== false ? " checked" : ""}><span><b>الساعة والتاريخ</b><small>ساعة رقمية + «مباشر»</small></span></label>
          <label class="nwx-cr nwx-ck"><input type="checkbox" class="nwx-brkc"${c.brk !== false ? " checked" : ""}><span><b>تنبيه «عاجل»</b><small>شريط أحمر مع صوت عند بدء خبر عاجل</small></span></label>
          <button type="button" class="nwx-test">▶ تجربة خبر عاجل</button></div>`,
          buttons: [{ t: "حفظ", cls: "green", fn: d => {
            const b = d.body, nv = { pos: b.querySelector('[data-k="pos"] .on').dataset.v, speed: +b.querySelector(".nwx-sp").value, sys: b.querySelector(".nwx-sys").checked, clock: b.querySelector(".nwx-clkc").checked, brk: b.querySelector(".nwx-brkc").checked };
            put("news.cfg", nv).then(() => { d.close(); T("تم حفظ إعدادات الشريط", "s"); if (K && !K.on) K.show(true); }); } },
            { t: "إغلاق", cls: "blue", fn: d => d.close() }],
 });
        const d = dd.body;
        d.querySelector('[data-k="pos"]').addEventListener("click", e => { const t = e.target.closest("button"); if (!t) return; t.parentNode.querySelectorAll("button").forEach(x => x.classList.toggle("on", x === t)); });
        d.querySelector(".nwx-sp").addEventListener("input", e => { d.querySelector(".nwx-spl").textContent = sp[e.target.value]; });
        d.querySelector(".nwx-test").onclick = () => { if (K) K.breaking({ title: "هذا مثال على خبر عاجل في شريط أخبار ANOUER" }); };
      };
      draw();
      setTimeout(() => { const b = box.querySelector(".pp-new"); if (b) b.focus(); }, 30);
    }
  };

  // ==================================================================== 10) الحقول الإضافية
  const FTYPES = ["نص", "رقم", "تاريخ", "اختيارات", "نعم / لا"];
  function itemsDlg(f, onDone) {
    const items = clone(f.items || []);
    const d = dlg({ title: "البنود", w: 440, cls: "pp-items", body: "", buttons: [{ t: "إضافة", cls: "green", fn: () => { read(); items.push({ v: "", def: false }); draw(); const i = d.body.querySelectorAll('[data-f="v"]'); i[i.length - 1].focus(); } }], onClose: () => { read(); f.items = items.filter(x => String(x.v).trim()); onDone(); } });
    const read = () => d.body.querySelectorAll("tr[data-r]").forEach(tr => { const it = items[+tr.dataset.r]; it.v = tr.querySelector('[data-f="v"]').value; it.def = tr.querySelector('[data-f="def"]').checked; });
    const draw = () => {
      d.body.innerHTML = `<table class="pp-grid pp-ed"><colgroup><col style="width:22px"><col><col style="width:70px"><col style="width:34px"><col style="width:34px"></colgroup><thead><tr><th></th><th>البند</th><th>افتراضى</th><th></th><th></th></tr></thead><tbody>${items.map((it, i) => `<tr data-r="${i}"><td class="c pp-arw">${i === 0 ? "←" : ""}</td><td><input data-f="v" value="${esc(it.v)}" readonly></td><td class="c"><input type="checkbox" data-f="def"${it.def ? " checked" : ""}></td><td class="c"><button type="button" class="pp-ib" data-e="${i}">${IC.edit}</button></td><td class="c"><button type="button" class="pp-ib" data-d="${i}">${IC.del}</button></td></tr>`).join("")}</tbody></table>`;
      d.body.querySelectorAll("[data-e]").forEach(b => b.onclick = () => { const i = b.closest("tr").querySelector('[data-f="v"]'); i.readOnly = false; i.focus(); i.select(); });
      d.body.querySelectorAll("[data-d]").forEach(b => b.onclick = () => { read(); items.splice(+b.dataset.d, 1); draw(); });
      d.body.querySelectorAll('[data-f="def"]').forEach(c => c.onchange = () => { if (c.checked) d.body.querySelectorAll('[data-f="def"]').forEach(o => { if (o !== c) o.checked = false; }); });
      d.body.querySelectorAll('[data-f="v"]').forEach(i => { if (!i.value) i.readOnly = false; i.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); i.readOnly = true; } }); });
    };
    draw();
  }
  const fldTab = (id, t) => ({ id, t, render(host, ctx) {
    const k = "fld." + id, v = get(k, { rows: Array.from({ length: 8 }, (_, i) => ({ on: false, name: "", type: "نص", items: [] })) });
    const draw = () => {
      host.innerHTML = `<table class="pp-fld"><thead><tr><th>البيان</th><th>استخدام</th><th>مسمى الحقل</th><th>نوع الحقل</th><th></th></tr></thead><tbody>${v.rows.map((r, i) => `<tr data-r="${i}"><td class="l">مسمى الحقل ${i + 1}</td><td>${tg(r.on)}</td><td><i class="pp-req">*</i><input class="pp-txt" data-f="name" value="${esc(r.name)}"${r.on ? "" : " disabled"}></td><td><span class="pp-ft2">${r.type === "اختيارات" ? '<b class="pp-ok">✔</b>' : '<b class="pp-tic">▤</b>'}${sel(FTYPES, r.type, null, 110).replace("<select", '<select data-f="type"')}</span></td><td>${r.type === "اختيارات" ? `<button type="button" class="pp-btn blue sm pp-items-b"${r.on ? "" : " disabled"}>البنود</button>` : ""}</td></tr>`).join("")}</tbody></table>`;
      wire(host);
      host.querySelectorAll("tr[data-r]").forEach(tr => {
        const r = v.rows[+tr.dataset.r];
        tr.querySelector(".pp-tg").addEventListener("change", () => { read(); draw(); });
        tr.querySelector('[data-f="type"]').addEventListener("change", () => { read(); draw(); });
        const b = tr.querySelector(".pp-items-b"); if (b) b.onclick = () => { read(); itemsDlg(r, () => { b.classList.toggle("green", !!(r.items && r.items.length)); }); };
        if (b && r.items && r.items.length) b.classList.add("green");
      });
    };
    const read = () => host.querySelectorAll("tr[data-r]").forEach(tr => { const r = v.rows[+tr.dataset.r]; r.on = tr.querySelector(".pp-tg").classList.contains("on"); r.name = tr.querySelector('[data-f="name"]').value.trim(); r.type = tr.querySelector('[data-f="type"]').value; });
    draw();
    return () => { read(); const bad = v.rows.findIndex(r => r.on && !r.name); if (bad >= 0) { T("أدخل مسمى الحقل " + (bad + 1), "w"); host.querySelectorAll('[data-f="name"]')[bad].focus(); return Promise.reject(); } return put(k, v); };
  } });
  /* شرائح الأسعار (مثل DEXEF ONE): ثمانية أسعار بالإضافة لسعر الشراء وسعر البيع — استخدام + مسمى السعر
     = نفس المستويات 2 … 9 فى قائمة الشريحة أعلى الفاتورة وقائمة الأسعار (price-levels.js) */
  const ORD = ["الأول", "الثانى", "الثالث", "الرابع", "الخامس", "السادس", "السابع", "الثامن"];
  const tiersTab = { id: "tiers", t: "شرائح الأسعار", render(host) {
    const PL = window.ANOUER_PL; if (!PL || !PL.levels) { host.innerHTML = '<div class="pp-empty2">شرائح الأسعار غير متاحة</div>'; return null; }
    const L = PL.levels();
    host.innerHTML = `<div class="pp-sub" style="margin:4px 0 14px;line-height:1.7">يستخدم البرنامج ثمانية أسعار بالإضافة الى سعر الشراء وسعر البيع .. يمكنك استخدام أى منهم عن طريق تفعيله ووضع أسم لهذا السعر حتى يتم التعامل بهذا الإسم .. مثال سعر الموزعين و سعر البيع بالأجل .. الى اخره</div>
      <table class="pp-fld pp-tiers"><thead><tr><th>البيان</th><th>استخدام</th><th>مسمى السعر</th><th></th></tr></thead><tbody>${L.map((x, i) => `<tr data-id="${x.id}"><td class="l">السعر ${ORD[i]}</td><td>${tg(x.on)}</td><td><i class="pp-req">*</i><input class="pp-txt" data-f="name" value="${esc(x.name)}" placeholder="${esc(x.def)}" maxlength="30"${x.on ? "" : " disabled"}></td><td><span class="pp-tlv" title="رقمه فى قائمة الشريحة">${x.id}</span></td></tr>`).join("")}</tbody></table>
      <div class="pp-tnote">✦ الأسعار المفعّلة تظهر فوراً فى قائمة <b>شريحة الأسعار</b> أعلى فاتورة المبيعات وفى قائمة الأسعار بالزر الأيمن ، بنفس الأسماء. «سعر البيع» و «سعر اخر تعامل» ثابتان دائماً.</div>`;
    wire(host);
    host.querySelectorAll("tr[data-id]").forEach(tr => tr.querySelector(".pp-tg").addEventListener("change", () => { const on = tr.querySelector(".pp-tg").classList.contains("on"), i = tr.querySelector('[data-f="name"]'); i.disabled = !on; if (on && !i.value) { i.value = i.placeholder; } if (on) i.focus(); }));
    return () => {
      const list = [...host.querySelectorAll("tr[data-id]")].map(tr => ({ id: tr.dataset.id, on: tr.querySelector(".pp-tg").classList.contains("on"), name: tr.querySelector('[data-f="name"]').value.trim() }));
      const bad = list.findIndex(x => x.on && !x.name); if (bad >= 0) { T("أدخل مسمى السعر " + ORD[bad], "w"); host.querySelectorAll('[data-f="name"]')[bad].focus(); return Promise.reject(); }
      const names = list.filter(x => x.on).map(x => x.name.replace(/\s+/g, " ")), dup = names.find((n, i) => names.indexOf(n) !== i || n === PL.nameOf("1")); if (dup) { T("الاسم «" + dup + "» مكرر", "w"); return Promise.reject(); }
      PL.setLevels(list); return Promise.resolve();
    };
  } };
  TILES.fld = { id: "fld", title: "الحقول الإضافية", tabs: [fldTab("items", "الأصناف"), fldTab("cust", "العملاء"), fldTab("sup", "الموردين"), fldTab("inv", "الفواتير"), fldTab("jobs", "أوامر التشغيل"), tiersTab, fldTab("assets", "الأصول الثابتة")] };

  // ==================================================================== 11) الإضافات
  const ADDONS = [["1-Modules", [["einv", "الفاتورة الالكترونية السعودية", "منظومة الفوترة الإلكترونية هى إجراء يهدف إلى تحويل عملية إصدار الفواتير والإشعارات الورقية إلى عملية إلكترونية تسمح بتبادل الفواتير والإشعارات المدينة والدائنة ومعالجتها بصيغة إلكترونية منظمة بين البائع والمشترى بتنسيق إلكترونى متكامل."], ["erec", "الإيصال الإلكترونى", "الإيصال الإلكترونى هو وثيقة رقمية تصدر لتوثيق المعاملات التجارية بين البائع والمشترى، تشمل بيانات الطرفين، تفاصيل المنتجات أو الخدمات المقدمة، الكميات، الأسعار، الضرائب، والتواريخ. يهدف الإيصال الإلكترونى إلى زيادة الشفافية، مكافحة التهرب الضريبى، وتسهيل عمليات المراجعة الضريبية."], ["assets", "الاصول الثابتة", "هى إدارة للأصول الملموسة التى تقتنيها المنشأة بغرض استخدامها فى مزاولة نشاطها وليس بغرض إعادة بيعها مثل الأرض، المبانى، الآلات، السيارات، الأثاث .. و توزيع إهلاكها وإجراءاتها للغير."], ["maint", "الصيانة", "هى عبارة عن إدارة طلبات الصيانة بداية من إدارة الاستلام و التشخيص و حتى التسليم للعميل مع متابعة قطع الغيار المستخدمة."]]],
    ["2-العروض", [["disc", "خصومات الاصناف", "هو خصم يتم احتسابه على الأصناف .. ولا يتم تسجيل قيد محاسبى بهذا الخصم ..ويتم حسابه إما بنسبة من سعر الصنف أو بقيمة معينة على كمية الصنف خلال فترة زمنية محددة", 1], ["qdisc", "خصم الكمية", "هو خصم يتم إحتسابه على كمية الصنف .. وقد يكون هذا الخصم بنسبة مئوية واحدة او بعدة نسب مئوية تزداد كلما زاد حجم الشراء وذلك لتشجيع الشراء بكميات كبيرة", 1], ["bonus", "البونص", "تم بناء هذا العرض على أساس الكمية .. ففى حالة شراء العميل لكمية معينة من الصنف .. يتم اضافة عدد قطع من نفس الصنف بناء على هذه الكمية", 1], ["extra", "تكاليف الاصناف الإضافية", "هى تكاليف اضافية يتم تحميلها على بعض الأصناف نظراً لطبيعتها .. مثل تكاليف التعبئه و التغليف و مصنعيات الذهب الى أخره", 1], ["invdisc", "خصومات الفواتير", "هو خصم يتم احتسابه على اجمالى الفاتورة .. ويمكن وضع شروط معينة لتنفيذه (قيمة الفاتورة ، نقدى / آجل ، فترة محددة)", 1], ["slices", "شرائح الخصم", "خصم تجارى بنسبة مئوية يُختار من الفاتورة .. ومع «الشريحة الذكية» يُطبَّق وحده عندما يصل إجمالى الفاتورة إلى حدّها", 1], ["coupon", "كوبونات الخصم", "كوبونات بأرقام خاصة يستعملها العميل للحصول على خصم فى الفاتورة .. بنسبة وحد أدنى وتاريخ صلاحية", 1]]],
    ["3-الخدمات", [["reps", "مناديب المبيعات", "تستخدم إذا كان لديكم مناديب وتريد حساب النسب الخاصة بهم.. وإصدار تقارير بها .بالإضافة الى اضافة حصص الموظفين الى مرتباتهم"], ["inst", "الاقساط", "بيع الشىء بثمن مؤجل يدفع على أقساط معلومة فى أوقات محددة، أكثر من ثمن الحال"], ["loyal", "نقاط الولاء", "هو وسيلة لتكريم العملاء الأوفياء . وذلك بإعطائهم نقاط على كل عملية شراء يقومون بها . ويتم تحويل هذه النقاط الى خصومات"], ["don", "التبرعات", "هي جهات خيرية يقوم العميل بالتبرع بباقي الفاتورة إلى إحدى هذه الجهات"], ["cons", "بضاعة الامانة", "هى بضاعة ينقل حيازتها -وليس ملكيتها- من مالكها ويسمى الموكل الى شخص اخر يقوم ببيعها مقابل عمولة حسب الاتفاق ويسمى الوكيل وبناء عليه لا تسجل فى سجلات الوكيل كمشتريات"], ["ship", "خدمات الشحن", "هى المبالغ المالية التى تحصل عليها الشركة أو التى تخصمها نظير تقديم خدمة النقل لديها"], ["contr", "العقود", "هى بمثابة اتفاق يتم بينك وبين ( عميل أو مورد ) نظير تقديم خدمة معينة خلال فترة زمنية . و بمجرد استحقاق كل فترة يتم .. وضع المبلغ نظير هذه الخدمة كمديونية على حساب العميل أو المورد ... مثال عقود الإيجارات لمبنى الشركة . أو عقد تقديم خدمة معينة لعميل نظير إيراد شهرى"], ["wbonus", "بونص على المسحوبات", "هو خصم يتم إعطاءه للعملاء الأوفياء . بناء على قيمة مسحوباتهم خلال فترة زمنية محددة"], ["budget", "الموازنات", "هى خطة واقعية للمستقبل وهى تعبير كمّى عن الاهداف التى تسعى الإدارة إلى تحقيقها فى المدى القصير والمدى الطويل، ويمكن تعريف الموازنة على أنها مجموعة من الأدوات التى تستخدمها الإدارة فى تحقيق أهدافها"]]],
    ["الفواتير", [["invexp", "مصروفات الفواتير", "هى جميع التكاليف الاضافية التى تضاف على الفاتورة نظير الحصول على خدمات إضافية"], ["cashd", "الخصم النقدى", "يسمى أيضاً بخصم تعجيل الدفع .. ويستخدم لحث العميل على السداد نقدياً أو خلال فترة قصيرة .. حتى يستفيد من الخصم"], ["insur", "شركات التأمين", "تستخدم شركات التأمين فى حالة تقديم خدمات الى العميل و بحيث تقوم شركة التأمين بتحمل نسبة معينة من قيمة الخدمة المقدمة"], ["quota", "كوتة الاصناف", "هو نظام تطبقه بعض الشركات على أصناف ذات طبيعة خاصة، مثل الألبان و الأدوية ، وبعض الأصناف المستوردة، بغية الحفاظ على مخزون الشركة، ويكون لكل عميل عدد معين من كل صنف يباع إليه خلال فترة"]]]];
  function addonsWin() {
    const w = sepWin({ title: "الإضافات", icon: '<svg viewBox="0 0 16 16"><rect x="2" y="4" width="12" height="9" rx="1" fill="#1d6fd6"/><rect x="4" y="2" width="8" height="3" fill="#1d6fd6"/></svg>', cls: "pp-addw" });
    const on = () => get("add.enabled", ADDONS.reduce((a, c) => a.concat(c[1].filter(x => x[3]).map(x => x[0])), []));
    let q = "";
    const draw = () => {
      const en = on();
      w.body.innerHTML = `<div class="pp-adh"><span class="sp"></span><label class="pp-ads">⌕<input placeholder="Enter text to search..." dir="ltr" value="${esc(q)}"></label></div>
        <div class="pp-adk">${ADDONS.map(c => `<div class="pp-adc"><div class="pp-adch">${esc(c[0])}</div><div class="pp-adcb">${c[1].filter(a => !q || (a[1] + a[2]).indexOf(q) >= 0).map(a => `<button type="button" class="pp-card${en.indexOf(a[0]) >= 0 ? " en" : ""}" data-a="${a[0]}"><i class="bar"></i><b>${esc(a[1])}</b><p>${esc(a[2])}</p>${en.indexOf(a[0]) >= 0 ? '<span class="ok">✔</span>' : '<span class="pa">Pa</span>'}</button>`).join("")}</div></div>`).join("")}</div>`;
      const s = w.body.querySelector(".pp-ads input"); s.oninput = () => { q = s.value.trim(); const pos = s.selectionStart; draw(); const n = w.body.querySelector(".pp-ads input"); n.focus(); n.setSelectionRange(pos, pos); };
      w.body.querySelectorAll(".pp-card").forEach(b => b.onclick = () => {
        const id = b.dataset.a, a = ADDONS.reduce((x, c) => x.concat(c[1]), []).find(x => x[0] === id), en2 = on(), is = en2.indexOf(id) >= 0;
        dlg({ title: a[1], w: 480, body: `<div class="pp-addd"><b>${esc(a[1])}</b><p>${esc(a[2])}</p><div class="st">الحالة : ${is ? '<b class="g">مفعلة</b>' : '<b class="r">غير مفعلة</b>'}</div></div>`,
          buttons: [{ t: is ? "إلغاء التفعيل" : "تفعيل", cls: is ? "red" : "green", fn: d => { const l = on(); if (is) l.splice(l.indexOf(id), 1); else l.push(id); put("add.enabled", l).then(() => { d.close(); draw(); T(is ? "تم إلغاء تفعيل «" + a[1] + "»" : "تم تفعيل «" + a[1] + "»", "s"); }); } }, { t: "إغلاق", cls: "blue", fn: d => d.close() }] });
      });
    };
    draw();
  }
  TILES.add = { id: "add", title: "الإضافات", sep: true, open: () => addonsWin(), tabs: [] };

  // ==================================================================== 12) تصميم التقارير
  const REP_ROOT = [["deals", "التعاملات"], ["bc", "الباركود"], ["added", "التقارير المضافة"], ["edited", "التقارير المعدلة"], ["secs", "الأقسام"]];
  const REP_SUB = { deals: [["المبيعات"], ["المشتريات"], ["المخازن"], ["الحسابات"]], bc: [["ملصق صنف 38×25"], ["ملصق صنف 50×30"], ["ملصق رف"]], secs: [["المبيعات"], ["المشتريات"], ["المخازن"], ["العملاء و الموردين"], ["الحسابات"]] };
  function reportsWin() {
    const w = sepWin({ title: "ANOUER Report Designer", icon: '<svg viewBox="0 0 16 16"><path d="M2 14L12 4l2 2L4 16z" fill="#555"/><path d="M10 2l4 4" stroke="#555" stroke-width="2"/></svg>', cls: "pp-repw" });
    let path = [];
    const added = () => get("rep.added", []);
    const draw = () => {
      let items;
      if (!path.length) items = REP_ROOT.map(r => ({ id: r[0], t: r[1], fold: 1 }));
      else if (path[0] === "added" || path[0] === "edited") items = added().filter(r => (path[0] === "added") !== !!r.edited).map((r, i) => ({ id: "r" + i, t: r.name, rep: r }));
      else if (path.length === 1) items = [{ id: "def", t: "Default Template", tpl: 1, on: !get("rep.tpl", "") }].concat((REP_SUB[path[0]] || []).map(r => ({ id: r[0], t: r[0], fold: 1 })));
      else items = [{ id: "def", t: "Default Template", tpl: 1, on: get("rep.tpl." + path.join("/"), "def") === "def" }, { id: "a4", t: "A4 — " + path[1], tpl: 1, on: get("rep.tpl." + path.join("/"), "def") === "a4" }, { id: "cash", t: "Cashier 80mm — " + path[1], tpl: 1, on: get("rep.tpl." + path.join("/"), "def") === "cash" }];
      const nm = path.map(p => (REP_ROOT.find(r => r[0] === p) || [p, p])[1]).join(" / ");
      w.body.innerHTML = `<div class="pp-rph"><button type="button" class="pp-btn green pp-new">جديد</button><span class="sp"></span><select class="pp-sel" style="width:200px">${optHTML(BR(), BR()[0])}</select></div>
        ${path.length ? `<div class="pp-rpp"><button type="button" class="pp-up" title="رجوع">${IC.up}</button><b>${esc(nm)}</b></div>` : ""}
        <div class="pp-rpg${path.length ? " sub" : ""}">${items.map(it => it.fold ? `<button type="button" class="pp-rf" data-id="${esc(it.id)}">${IC.fold}<span>${esc(it.t)}</span></button>` : `<button type="button" class="pp-rt${it.on ? " on" : ""}" data-id="${esc(it.id)}">${it.on ? '<i class="ck">✔</i>' : ""}${IC.fold}<span>${esc(it.t)}</span></button>`).join("") || '<div class="pp-empty2">لا توجد تقارير</div>'}</div>`;
      w.body.querySelector(".pp-new").onclick = () => dlg({ title: "تقرير جديد", w: 440, body: `<div class="pp-form2">${fHTML(["txt", "name", "اسم التقرير", "", { req: 1, w: 240 }], {})}${fHTML(["sel", "sec", "القسم", "المبيعات", { w: 200, opts: REP_SUB.secs.map(x => x[0]) }], {})}${fHTML(["sel", "size", "مقاس الورق", "A4", { w: 120, opts: ["A4", "A5", "Cashier 80mm", "Barcode"] }], {})}</div>`,
        buttons: [{ t: "حفظ", cls: "green", fn: d => { const v = collect(d.body); if (!v.name.trim()) { T("أدخل اسم التقرير", "w"); return; } const l = added(); l.push(Object.assign(v, { date: today() })); put("rep.added", l).then(() => { d.close(); path = ["added"]; draw(); T("تم إضافة التقرير", "s"); }); } }, { t: "إغلاق", cls: "blue", fn: d => d.close() }] });
      const up = w.body.querySelector(".pp-up"); if (up) up.onclick = () => { path.pop(); draw(); };
      w.body.querySelectorAll(".pp-rf").forEach(b => b.ondblclick = () => { path.push(b.dataset.id); draw(); });
      w.body.querySelectorAll(".pp-rf").forEach(b => b.onkeydown = e => { if (e.key === "Enter") { path.push(b.dataset.id); draw(); } });
      w.body.querySelectorAll(".pp-rt").forEach(b => b.onclick = () => { if (path.length) { put(path.length > 1 ? "rep.tpl." + path.join("/") : "rep.tpl", b.dataset.id === "def" ? (path.length > 1 ? "def" : "") : b.dataset.id).then(draw); } });
    };
    draw();
  }
  TILES.rep = { id: "rep", title: "تصميم التقارير", sep: true, open: () => (window.ANOUER_RDM ? window.ANOUER_RDM.open() : reportsWin()), tabs: [] };
})();
