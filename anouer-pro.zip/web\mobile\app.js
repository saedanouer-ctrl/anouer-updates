/* ANOUER POS — البيع من الهاتف داخل المحل (يتصل ببرنامج ANOUER عبر الواي فاي) */
(function () {
  "use strict";
  var VER = "1.5 · 2026";
  /* وضع الإنترنت: التطبيق مفتوح من خادم المتجر (https://…/pos/) — يعمل من أي مكان وحتى والجهاز مقفول */
  var BASE = location.pathname.replace(/\/[^\/]*$/, ""), CLOUD = /^\/pos$/.test(BASE);
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var K = window.__K || "";
  var LS = {
    get: function (k, d) { try { var v = localStorage.getItem("anp." + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem("anp." + k, JSON.stringify(v)); } catch (e) { } },
    del: function (k) { try { localStorage.removeItem("anp." + k); } catch (e) { } }
  };
  var S = {
    sid: LS.get("sid", ""), user: LS.get("user", ""), name: LS.get("name", ""), company: LS.get("company", "ANOUER"),
    tr: LS.get("tr", []), trId: LS.get("trId", 0), pk: LS.get("pk", "p"), snd: LS.get("snd", true), vib: LS.get("vib", true),
    cat: [], idx: {}, cart: LS.get("cart", []), cust: LS.get("cust", null), disc: 0, note: "",
    tab: "pos", g: "", q: "", shown: 60, net: "ok", pc: LS.get("pc", null), queue: LS.get("queue", []), catAt: LS.get("catAt", ""),
    mode: LS.get("mode", "sale"), buy: LS.get("buy", false), pb: null, sup: {}, pbAt: "", offimg: LS.get("offimg", true)
  };
  /* ------------------------------------------------------------ تخزين الهاتف (IndexedDB)
     الأصناف كلها تُحفظ في الهاتف مهما كان عددها (localStorage محدود بـ 5 ميغا ويفشل بصمت) — التطبيق يفتح بآخر أصناف حتى بدون أي اتصال */
  var DBP = null, CATWAIT = false;
  function idb() {
    if (DBP) return DBP;
    DBP = new Promise(function (ok, no) {
      try { var r = indexedDB.open("anp", 1); r.onupgradeneeded = function () { r.result.createObjectStore("kv"); }; r.onsuccess = function () { ok(r.result); }; r.onerror = function () { no(r.error); }; r.onblocked = function () { no(new Error("blocked")); }; }
      catch (e) { no(e); }
    });
    DBP.catch(function () { DBP = null; }); return DBP;
  }
  function kvSet(k, v) {
    return idb().then(function (db) { return new Promise(function (ok, no) { var t = db.transaction("kv", "readwrite"); t.objectStore("kv").put(v, k); t.oncomplete = function () { ok(true); }; t.onerror = t.onabort = function () { no(t.error); }; }); })
      .catch(function () { try { localStorage.setItem("anp." + k, JSON.stringify(v)); } catch (e) { } return false; });
  }
  function kvGet(k) {
    return idb().then(function (db) { return new Promise(function (ok, no) { var r = db.transaction("kv").objectStore("kv").get(k); r.onsuccess = function () { ok(r.result); }; r.onerror = function () { no(r.error); }; }); })
      .catch(function () { return undefined; }).then(function (v) { if (v != null) return v; try { return JSON.parse(localStorage.getItem("anp." + k) || "null"); } catch (e) { return null; } });
  }
  function saveCat(items) { kvSet("cat", items).then(function (ok) { if (ok) try { localStorage.removeItem("anp.cat"); } catch (e) { } }); }
  try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(function () { }); } catch (e) { }
  /* وضع الشراء: سلة ومورد منفصلان عن البيع */
  if (S.mode === "buy") { S.cart = LS.get("pcart", []); S.cust = LS.get("psup", null); }
  (function () { var c = LS.get("pb", null); if (c && c.p) { S.pb = c.p; S.sup = c.sup || {}; S.pbAt = c.at || ""; } })();
  function BUY() { return S.mode === "buy"; }
  var CUR = "د.ج";

  /* ------------------------------------------------------------ أدوات */
  function esc(t) { return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) { return "&#" + c.charCodeAt(0) + ";"; }); }
  function r2(n) { return Math.round((+n || 0) * 100) / 100; }
  function fm(n, d) { d = d == null ? 2 : d; return (r2(n)).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d }); }
  function fq(n) { return (+n || 0).toLocaleString("en-US", { maximumFractionDigits: 3 }); }
  function N(n, d) { return '<bdi class="n">' + fm(n, d) + "</bdi>"; }
  function ic(id, cls) { return '<svg class="i ' + (cls || "") + '"><use href="#i-' + id + '"/></svg>'; }
  function fold(s) {
    return String(s || "").toLowerCase().replace(/[ً-ْـ]/g, "").replace(/[أإآٱ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/ؤ/g, "و").replace(/ئ/g, "ي")
      .replace(/[٠-٩]/g, function (c) { return String(c.charCodeAt(0) - 1632); });
  }
  function hue(s) { var h = 0; s = String(s || ""); for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360; return h; }
  function tile(name) {
    var h = hue(name), w = String(name || "?").trim().replace(/^(\([^)]*\)\s*)+/, "").replace(/^[^A-Za-z\u0621-\u064A0-9]+/, "").replace(/^ال/, "");
    return { bg: "linear-gradient(135deg,hsl(" + h + " 72% 58%),hsl(" + ((h + 38) % 360) + " 70% 42%))", ch: esc((w[0] || "?").toUpperCase()) };
  }
  /* صورة الصنف من «صور الأصناف» في ANOUER — وإلا حرف أول على تدرّج لوني */
  function imgOf(pid, im) { return im ? BASE + "/img?k=" + encodeURIComponent(K) + "&id=" + pid + "&v=" + im : ""; }
  function pic(name, pid, im, cls, extra) {
    var t = tile(name), u = imgOf(pid, im);
    return '<span class="ph ' + (cls || "") + (u ? " hasim" : "") + '" style="background:' + t.bg + '">' + t.ch + (extra || "") +
      (u ? '<img src="' + u + '" alt="" loading="lazy" decoding="async" onerror="this.parentNode.classList.remove(\'hasim\');this.remove()">' : "") + "</span>";
  }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  function buzz(ms) { if (S.vib) try { navigator.vibrate && navigator.vibrate(ms || 18); } catch (e) { } }
  var AC = null;
  function beep(ok) {
    if (!S.snd) return;
    try {
      AC = AC || new (window.AudioContext || window.webkitAudioContext)();
      var o = AC.createOscillator(), g = AC.createGain(); o.type = "sine"; o.frequency.value = ok === false ? 320 : 1760;
      g.gain.setValueAtTime(.16, AC.currentTime); g.gain.exponentialRampToValueAtTime(.001, AC.currentTime + (ok === false ? .3 : .12));
      o.connect(g); g.connect(AC.destination); o.start(); o.stop(AC.currentTime + .32);
    } catch (e) { }
  }
  function toast(msg, kind) {
    var t = document.createElement("div"); t.className = "toast " + (kind || "");
    t.innerHTML = "<i>" + ic(kind === "bad" ? "x" : kind === "warn" ? "clock" : "check") + "</i><span>" + esc(msg) + "</span>";
    var box = $("#toasts"); box.appendChild(t); while (box.children.length > 3) box.removeChild(box.firstChild);
    setTimeout(function () { t.classList.add("out"); setTimeout(function () { t.remove(); }, 260); }, kind === "bad" ? 3600 : 2200);
  }
  function vt(fn) { if (document.startViewTransition) document.startViewTransition(fn); else fn(); }

  /* ------------------------------------------------------------ الاتصال */
  function api(path, body, opt) {
    opt = opt || {};
    var viaLan = !!ALT;   /* بدون إنترنت داخل المحل: الطلب يذهب للجهاز مباشرة عبر الواي فاي */
    var url = (viaLan ? ALT : BASE) + path + (path.indexOf("?") < 0 ? "?" : "&") + "k=" + encodeURIComponent(viaLan ? ALTK : K);
    var ctl = window.AbortController ? new AbortController() : null, to = setTimeout(function () { ctl && ctl.abort(); }, opt.timeout || 15000);
    return fetch(url, {
      method: body ? "POST" : "GET", cache: "no-store", signal: ctl ? ctl.signal : undefined,
      headers: { "X-S": S.sid || "", "Content-Type": "text/plain;charset=utf-8" }, body: body ? JSON.stringify(body) : undefined
    }).then(function (r) {
      clearTimeout(to);
      if (r.status === 403) { var e = new Error("denied"); e.denied = !viaLan; throw e; }
      return r.json();
    }).then(function (d) {
      setNet("ok"); if (viaLan) setPc(true); else if (CLOUD && d && typeof d.pc === "boolean") setPc(d.pc);
      if (d && d.auth === false) { logout(true); var e = new Error(d.error || "auth"); e.auth = true; throw e; }
      return d;
    }, function (e) {
      clearTimeout(to);
      if (e && (e.denied || e.auth)) { if (e.denied) denied(); throw e; }
      if (viaLan && ALT) { ALT = ""; }                 /* انقطع واي فاي المحل ← نرجع لطريق الإنترنت */
      setNet("off"); if (!viaLan) lanAuto(); var x = new Error("net"); x.net = true; throw x;
    });
  }
  function setNet(s) {
    if (S.net === s) return; S.net = s;
    var a = $(".top-r .av"); if (a) a.className = avCls();
    var sm = $("#netl"); if (sm) sm.textContent = netLabel();
    paintLan();
    if (s === "ok") { flush(); imgSync(); }
  }
  function netLabel() {
    if (S.net === "off") return CLOUD ? "بدون إنترنت — البيع يُحفظ في الهاتف ويُرسل وحده" : "غير متصل بالبرنامج — تحقق من الواي فاي";
    if (ALT) return S.queue.length ? S.queue.length + " بيع في الانتظار" : "📶 واي فاي المحل — مباشر مع ANOUER بدون إنترنت";
    if (S.queue.length) return S.queue.length + " بيع في الانتظار";
    if (CLOUD && S.pc === false) return "☁ الجهاز مقفول — البيع يُحفظ في السحابة";
    return (CLOUD ? "☁ متصل عبر الإنترنت · " : "متصل · ") + esc(S.name || S.user);
  }
  function avCls() { return "av" + (S.net === "off" ? " off" : S.queue.length ? " wait" : ALT ? " lan" : CLOUD && S.pc === false ? " cl" : ""); }
  /* حالة الجهاز (البرنامج) في وضع الإنترنت */
  function setPc(v) {
    if (S.pc === v) return; var was = S.pc; S.pc = v; LS.set("pc", v);
    document.documentElement.classList.toggle("pcoff", v === false);
    var sm = $("#netl"); if (sm) sm.textContent = netLabel();
    var a = $(".top-r .av"); if (a) a.className = avCls();
    if (was === false && v === true) { toast("✓ الجهاز شغّال — مباشر مع ANOUER"); if (S.tab === "sales") renderSales(); }
    else if (was !== null && v === false && S.sid) toast("☁ الجهاز مقفول — واصل البيع، السحابة تحفظ", "warn");
  }
  function denied() {
    $("#root").innerHTML = '<div class="login"><div class="login-hd"><svg viewBox="0 0 64 64"><use href="#i-logo"/></svg><h1>الرابط <em>غير صالح</em></h1><p>تم تجديد رمز الربط في البرنامج.<br>افتح في ANOUER: «ملف ← ربط البرنامج بالموبايل» وامسح رمز QR من جديد.</p></div></div>';
    hideBoot();
  }

  /* ------------------------------------------------------------ تسجيل الدخول */
  function loginView() {
    hideBoot();
    $("#root").innerHTML =
      '<div class="login"><div class="login-hd"><svg viewBox="0 0 64 64"><use href="#i-logo"/></svg>' +
      '<h1>بِع من هاتفك<br><em>بلمسة واحدة.</em></h1><p>كل فاتورة تُسجَّل مباشرة في ANOUER: المخزون والخزينة وحساب العميل.</p>' +
      '<span class="login-co" id="lco"><i></i><span>جارٍ الاتصال بالبرنامج …</span></span></div>' +
      '<form id="lf" autocomplete="on">' +
      '<label class="fld">' + ic("user") + '<input id="lu" name="username" autocomplete="username" placeholder="اسم المستخدم" value="' + esc(LS.get("lastUser", "")) + '" autocapitalize="off" spellcheck="false"></label>' +
      '<label class="fld">' + ic("tag") + '<input id="lp" name="password" type="password" autocomplete="current-password" placeholder="الرقم السري"><button type="button" class="eye" id="eye">إظهار</button></label>' +
      '<div class="err" id="lerr"></div>' +
      '<button class="btn pri" id="lb">دخول</button>' +
      '<small class="ft">نفس اسم المستخدم والرقم السري في برنامج ANOUER</small></form></div>';
    api("/api/ping").then(function (d) { var c = $("#lco"); c.querySelector("span").textContent = !CLOUD ? "متصل بالبرنامج على شبكة المحل" : d.pc ? "☁ متصل بالبرنامج عبر الإنترنت" : "☁ السحابة متصلة — أول دخول يحتاج الجهاز شغّالاً"; if (CLOUD && !d.pc) c.classList.add("warn"); }, function () { var c = $("#lco"); c.classList.add("off"); c.querySelector("span").textContent = "تعذّر الوصول للبرنامج — نفس الواي فاي؟"; });
    $("#eye").onclick = function () { var p = $("#lp"); p.type = p.type === "password" ? "text" : "password"; this.textContent = p.type === "password" ? "إظهار" : "إخفاء"; };
    $("#lf").onsubmit = function (e) {
      e.preventDefault();
      var u = $("#lu").value.trim(), p = $("#lp").value, b = $("#lb");
      if (!u || !p) { $("#lerr").textContent = "أدخل اسم المستخدم والرقم السري"; return; }
      b.disabled = true; b.innerHTML = '<i class="spin"></i>';
      api("/api/login", { u: u, p: p }).then(function (d) {
        if (!d.ok) throw new Error(d.error || "تعذّر الدخول");
        S.sid = d.sid; S.user = d.user; S.name = d.name; LS.set("sid", d.sid); LS.set("user", d.user); LS.set("name", d.name); LS.set("lastUser", u);
        buzz(30); start();
      }).catch(function (e) {
        b.disabled = false; b.textContent = "دخول"; buzz([30, 40, 30]);
        $("#lerr").textContent = e.net ? "لا يوجد اتصال بالبرنامج" : e.message;
      });
    };
  }
  function logout(silent) {
    if (!silent) api("/api/logout", {}).catch(function () { });
    S.sid = ""; LS.del("sid"); loginView();
  }
  function hideBoot() { var b = $("#boot"); if (b) { b.classList.add("out"); setTimeout(function () { b.remove(); }, 400); } }

  /* ------------------------------------------------------------ البيانات */
  function boot() {
    return api("/api/boot").then(function (d) {
      if (!d.ok) throw new Error(d.error);
      S.company = d.company || "ANOUER"; S.tr = d.treasuries || []; S.name = d.name || S.name;
      S.buy = !!d.buy; LS.set("buy", S.buy); if (!S.buy && BUY()) setMode("sale", true); paintMode();
      if (!S.tr.some(function (t) { return t.id === S.trId; })) S.trId = S.tr.length ? S.tr[0].id : 0;
      LS.set("company", S.company); LS.set("tr", S.tr); LS.set("trId", S.trId);
      /* عنوان الجهاز على واي فاي المحل — يُستعمل حين ينقطع الإنترنت */
      if (CLOUD) { if (d.lan) LS.set("lan", d.lan); else if (!ALT) api("/api/lan").then(function (x) { if (x && x.ok && x.lan) LS.set("lan", x.lan); }, function () { }); }
    });
  }
  function setCatalog(items) {
    S.cat = items || []; S.idx = {};
    S.cat.forEach(function (p) {
      p._f = fold(p.n + " " + (p.c || ""));
      (p.u || []).forEach(function (u) { (u.b || []).forEach(function (b) { b = String(b).trim().toUpperCase().replace(/\s+/g, ""); if (b) put(b, p, u); }); });
      if (p.c) put("#" + String(p.c).trim().toUpperCase().replace(/\s+/g, ""), p, defUnit(p));
    });
  }
  function loadCatalog(force) {
    var rb = $("#rf"); rb && rb.classList.add("sp");
    return api("/api/catalog", null, { timeout: 40000 }).then(function (d) {
      if (!d.ok) throw new Error(d.error);
      setCatalog(d.items); S.catAt = d.at; LS.set("catAt", d.at); STK.at = Date.now();
      saveCat(d.items); imgSync();
      rb && rb.classList.remove("sp"); if (force) toast("تم تحديث الأصناف (" + S.cat.length + ")");
      if (S.tab === "pos") renderGrid(); renderCats();
    }, function (e) { rb && rb.classList.remove("sp"); if (force && !e.auth) toast("تعذّر تحديث الأصناف", "bad"); });
  }
  /* ✦ أرصدة المخزون حيّة: نفس أرقام البرنامج بلا ما تعاود تفتح التطبيق
     كل دقيقة (والتطبيق ظاهر) ، كي ترجع للتطبيق ، وبعد كل بيع/شراء — تتبدّل الأرقام في مكانها بلا ما يتحرّك الشاشة */
  var STK = { at: 0, busy: false };
  function stkTxt(el, s) { s = +s || 0; el.className = "st" + (s <= 0 ? " no" : s < 5 ? " lo" : ""); el.textContent = s <= 0 ? "نفد" : fq(s); }
  function refreshStock(delay) {
    if (delay) { setTimeout(function () { refreshStock(0); }, delay); return; }
    if (STK.busy || !S.sid || !S.cat || !S.cat.length) return; STK.busy = true; STK.at = Date.now();
    api("/api/catalog", null, { timeout: 40000 }).then(function (d) {
      STK.busy = false; if (!d || !d.ok || !d.items) return;
      var m = {}; d.items.forEach(function (x) { m[x.i] = x; });
      var same = d.items.length === S.cat.length && S.cat.every(function (p) { return m[p.i]; });
      /* اسم / سعر / وحدة / باركود تبدّل في البرنامج ← الشبكة تُعاد كاملة (الأسعار والبحث والباركود) */
      var chg = same && S.cat.some(function (p) { var x = m[p.i]; return x.n !== p.n || x.c !== p.c || x.g !== p.g || JSON.stringify(x.u) !== JSON.stringify(p.u); });
      if (!same || chg) { var sy = ($("#vw") || {}).scrollTop || 0; setCatalog(d.items); if (S.tab === "pos" && !$(".sheet")) { renderGrid(); var vv = $("#vw"); if (vv) vv.scrollTop = sy; } renderCats(); }
      else S.cat.forEach(function (p) {
        var x = m[p.i], old = +p.s || 0, oim = p.im; for (var k in x) if (k !== "_f" && k !== "_t" && k !== "_k") p[k] = x[k];
        /* صورة أُضيفت / تغيّرت في البرنامج ← تظهر في مكانها فوراً بلا إعادة فتح التطبيق */
        if (p.im !== oim) $$('.pc[data-i="' + p.i + '"] > .ph').forEach(function (el) { var w = document.createElement("span"); w.innerHTML = pic(p.n, p.i, p.im, "", p.g ? "<small>" + esc(p.g) + "</small>" : ""); if (w.firstChild) el.parentNode.replaceChild(w.firstChild, el); });
        if ((+p.s || 0) !== old) $$('.pc[data-i="' + p.i + '"] .st').forEach(function (el) { stkTxt(el, p.s); el.classList.add("upd"); setTimeout(function () { el.classList.remove("upd"); }, 1200); });
      });
      S.catAt = d.at; LS.set("catAt", d.at); saveCat(d.items); imgSync();
    }, function () { STK.busy = false; });
  }
  setInterval(function () { if (!document.hidden) refreshStock(0); }, 60000);
  document.addEventListener("visibilitychange", function () { if (!document.hidden && Date.now() - STK.at > 15000) refreshStock(400); });
  /* نفس الباركود قد يكون مسجّلاً لأكثر من صنف: نحتفظ بكل الأصناف ونسأل البائع */
  function put(k, p, u) { var a = S.idx[k] || (S.idx[k] = []); if (!a.some(function (x) { return x.p === p; })) a.push({ p: p, u: u }); }
  function defUnit(p) { var us = p.u || []; return (BUY() && us.filter(function (u) { return u.dp; })[0]) || us.filter(function (u) { return u.d; })[0] || us.filter(function (u) { return u.bs; })[0] || us[0]; }
  function priceOf(u) { if (BUY()) return +u.c || 0; var v = u[S.pk]; return v != null && +v > 0 ? +v : +u.p || 0; }
  function byCode(code) {
    code = String(code || "").trim().toUpperCase().replace(/\s+/g, ""); if (!code) return null;
    return S.idx[code] || (code.length === 12 && S.idx["0" + code]) || (code.length === 13 && code[0] === "0" && S.idx[code.slice(1)]) || S.idx["#" + code] || null;
  }
  /* إضافة صنف من باركود: إن تطابق أكثر من صنف تظهر قائمة للاختيار */
  function addCode(code, el, done) {
    var hs = byCode(code); if (!hs) return false;
    if (hs.length === 1) { var h = hs[0]; add(h.p, h.u, 1, null, el); beep(); if (!BUY()) toast("أُضيف: " + h.p.n + " · " + h.u.n); done && done(h); return true; }
    beep(); buzz(30);
    var sh = sheet("باركود مكرر", '<bdi class="n">' + esc(code) + "</bdi> مسجّل لـ " + hs.length + " أصناف — اختر الصنف الصحيح",
      hs.map(function (h, i) { return '<button class="cl" data-h="' + i + '">' + pic(h.p.n, h.p.i, h.p.im, "ci", "") + '<span class="tx"><b>' + esc(h.p.n) + "</b><small>" + esc(h.u.n) + (h.p.c ? " · " + esc(h.p.c) : "") + '</small></span><span class="bl">' + N(priceOf(h.u)) + "</span></button>"; }).join("") +
      '<p style="font-size:12px;color:var(--mu);text-align:center;margin-top:12px">💡 صحّح الباركود في بطاقة الصنف داخل ANOUER حتى لا يتكرر السؤال</p>');
    $$(".cl", sh).forEach(function (b) { b.onclick = function () { var h = hs[+b.dataset.h]; closeSheet(); add(h.p, h.u, 1, null, null); toast("أُضيف: " + h.p.n + " · " + h.u.n); done && done(h); }; });
    return true;
  }

  /* ------------------------------------------------------------ السلة */
  function saveCart() { LS.set(BUY() ? "pcart" : "cart", S.cart); LS.set(BUY() ? "psup" : "cust", S.cust); }
  function cartCount() { return S.cart.reduce(function (s, l) { return s + 1; }, 0); }
  function totals() {
    var sub = 0, ld = 0; S.cart.forEach(function (l) { sub += l.q * l.pr; ld += +l.d || 0; });
    return { sub: r2(sub), ld: r2(ld), disc: r2(S.disc), total: r2(sub - ld - S.disc) };
  }
  function add(p, u, q, pr, from, quiet) {
    u = u || defUnit(p); if (!u) return;
    q = q || 1;
    if (pr == null && BUY()) pr = buyPrice(p, u);
    var l = S.cart.filter(function (x) { return x.puid === u.id && (pr == null || x.pr === pr); })[0], nl = null;
    if (l) l.q = r2(l.q + q);
    else S.cart.unshift(nl = { pid: p.i, puid: u.id, n: p.n, un: u.n, f: +u.f || 1, pr: pr != null ? pr : priceOf(u), q: q, d: 0, im: p.im || 0 });
    saveCart(); buzz(); if (from) flyFrom(from); updateDock(true); paintQty(p.i);
    if (BUY() && !quiet) advise(p, u);
    if (!BUY() && nl && pr == null) guardLine(p, u, nl, quiet);
  }

  /* ------------------------------------------------------------ حارس البيع (FIFO)
     الدفعة اللي تتباع الآن اشتريتها بـ 825 وسعر البيع 810 ← يرجع السطر لآخر سعر بيع مربح (850) حتى تكمل الدفعة الغالية */
  var GC = {};
  function guardOf(pid) {
    var c = GC[pid]; if (c && Date.now() - c.t < 15000) return c.p;
    var pr = api("/api/guard?pid=" + pid, null, { timeout: 8000 }).then(function (d) { return d && d.ok ? d.g : null; }, function () { delete GC[pid]; return null; });
    GC[pid] = { t: Date.now(), p: pr }; return pr;
  }
  function guardLine(p, u, l, quiet) {
    var base = l.pr;
    guardOf(p.i).then(function (g) {
      if (!g || !g.loss || S.cart.indexOf(l) < 0 || BUY()) return;
      var x = (g.units || []).filter(function (z) { return z.puid === u.id; })[0]; if (!x) return;
      l.sg = { prot: +x.prot || 0, mc: +x.maxCost || 0, left: +x.left || 0, sale: +x.sale || 0, no: x.no || "", src: x.src || "" };
      var auto = l.sg.prot > 0 && Math.abs(l.pr - base) < .004 && l.pr < l.sg.mc - .004;
      if (auto) { l.sgOld = l.pr; l.pr = l.sg.prot; l.sgOn = true; }
      saveCart(); updateDock(); if (S.tab === "cart") renderCart();
      if (!quiet) guardCard(l, auto);
    });
  }
  function sgSafe(l) { return !l.sg || l.pr >= l.sg.mc - .004; }
  function sgTag(l) {
    if (!l.sg) return "";
    return sgSafe(l) ? ' <em class="hb sg">' + ic("shield") + "محمي</em>" : ' <em class="hb sgx">' + ic("shx") + "خسارة</em>";
  }
  function guardCard(l, auto) {
    hideAdv(true);
    var g = l.sg, safe = sgSafe(l), sug = g.prot > 0 ? g.prot : Math.ceil(g.mc / 10) * 10;
    var el = document.createElement("div"); el.className = "adv sgc" + (safe ? " ok" : " bad");
    el.innerHTML = '<span class="ai' + (safe ? " ok" : " bad") + '">' + ic(safe ? "shield" : "shx") + '</span><div class="tx"><small>' + esc(l.n) + " · " + esc(l.un) + "</small>" +
      (safe ? "<b>" + (auto ? "سعر محمي " : "يتباع بـ ") + '<bdi class="n">' + N(l.pr) + "</bdi></b><span>دفعة بتكلفة " + N(g.mc) + " · باقي " + fq(g.left) + " — بعدها يرجع " + N(g.sale) + "</span>"
        : "<b>تبيع بخسارة!</b><span>تكلفة الدفعة " + N(g.mc) + " أكبر من " + N(l.pr) + " · باقي " + fq(g.left) + "</span>") + "</div>" +
      (safe ? (l.sgOn && l.sgOld != null ? '<button class="go gh" data-a="old">بيع<small>' + fm(l.sgOld) + "</small></button>" : "")
        : '<button class="go" data-a="set">حط<small>' + fm(sug) + "</small></button>") +
      '<button class="x" data-a="x" aria-label="إغلاق">' + ic("x") + '</button><i class="tm"></i>';
    document.body.appendChild(el);
    el.onclick = function (e) {
      var a = e.target.closest("[data-a]"); if (!a) return; hideAdv();
      if (a.dataset.a === "old" && l.sgOld != null) { l.pr = l.sgOld; l.sgOn = false; toast("رجع " + fm(l.pr) + " — راك تبيع بخسارة", "warn"); }
      else if (a.dataset.a === "set") { if (l.sgOld == null) l.sgOld = l.pr; l.pr = sug; l.sgOn = true; toast("السعر الآن " + fm(sug)); }
      else return;
      saveCart(); updateDock(true); if (S.tab === "cart") renderCart();
    };
    if (!safe) { beep(false); buzz([30, 40, 30]); }
    ADV = setTimeout(hideAdv, safe ? 6500 : 9000);
  }
  function qtyOf(pid) { return S.cart.reduce(function (s, l) { return s + (l.pid === pid ? l.q : 0); }, 0); }
  function paintQty(pid) {
    var c = $('.pc[data-i="' + pid + '"]'); if (!c) return;
    var q = qtyOf(pid), b = c.querySelector(".q");
    if (!q) { b && b.remove(); return; }
    if (!b) { b = document.createElement("span"); b.className = "q"; c.appendChild(b); }
    else { b.style.animation = "none"; void b.offsetWidth; b.style.animation = ""; }
    b.textContent = fq(q);
  }
  function flyFrom(el) {
    var bar = $(".cartbar .cn") || $('.tab[data-t="cart"]'); if (!bar || !el) return;
    var a = el.getBoundingClientRect(), b = bar.getBoundingClientRect();
    var d = document.createElement("i"); d.className = "fly"; d.style.left = (a.left + a.width / 2 - 8) + "px"; d.style.top = (a.top + a.height / 3) + "px";
    document.body.appendChild(d);
    var dx = b.left + b.width / 2 - (a.left + a.width / 2), dy = b.top + b.height / 2 - (a.top + a.height / 3);
    if (d.animate) d.animate([{ transform: "translate(0,0) scale(1)", opacity: 1 }, { transform: "translate(" + dx * .5 + "px," + (dy * .5 - 90) + "px) scale(1.2)", opacity: 1, offset: .5 }, { transform: "translate(" + dx + "px," + dy + "px) scale(.4)", opacity: .2 }], { duration: 520, easing: "cubic-bezier(.4,0,.2,1)" }).onfinish = function () { d.remove(); };
    else setTimeout(function () { d.remove(); }, 50);
  }
  function updateDock(bump) {
    var bar = $(".cartbar"); if (!bar) return;
    var t = totals(), n = S.cart.length;
    bar.classList.toggle("hide", !n || S.tab !== "pos");
    bar.querySelector(".cn").textContent = n;
    bar.querySelector(".tx b").innerHTML = N(t.total) + ' <small style="font-size:12px;opacity:.8">' + CUR + "</small>";
    bar.querySelector(".tx small").textContent = n + (n === 1 ? " صنف" : " أصناف") + (S.cust ? " · " + S.cust.n : "");
    if (bump) { bar.classList.remove("bump"); void bar.offsetWidth; bar.classList.add("bump"); }
    var tb = $('.tab[data-t="cart"] .bd'); if (tb) { tb.textContent = n; tb.hidden = !n; }
  }

  /* ------------------------------------------------------------ الإطار */
  function start() {
    $("#root").innerHTML =
      '<div class="app"><div id="vw" class="view"></div></div>' +
      '<div class="dock"><div class="cartbar hide" id="cb"><button class="cbs" id="cbs" aria-label="فتح السلة"><span class="cn">0</span><span class="tx"><small></small><b></b></span></button>' +
      '<button class="pz pzc" id="pzc">' + ic("clock") + "<span>آجل</span></button>" + '<button class="pz pzk" id="pzk">' + ic("cash") + "<span>كاش</span></button></div>" +
      '<nav class="tabs">' +
      tabB("pos", "grid", "البيع") + tabB("cart", "bag", "السلة", true) + tabB("sales", "receipt", "مبيعاتي") + tabB("more", "more", "حسابي") +
      "</nav></div>";
    $$(".tab").forEach(function (b) { b.onclick = function () { go(b.dataset.t); }; });
    $("#cbs").onclick = function () { go("cart"); };
    /* دفع مباشر من شاشة البيع: كاش أو آجل (الآجل يطلب العميل إن لم يُختر) */
    $("#pzk").onclick = function () { buzz(10); paySheet("cash"); };
    $("#pzc").onclick = function () { buzz(10); paySheet("credit"); };
    var cached = null; try { cached = JSON.parse(localStorage.getItem("anp.cat") || "null"); } catch (e) { }
    if (cached) setCatalog(cached);
    else { CATWAIT = true; kvGet("cat").then(function (c) { CATWAIT = false; if (c && c.length && !S.cat.length) { setCatalog(c); renderCats(); imgSync(); } if (S.tab === "pos") renderGrid(); }); }
    applyMode(); go("pos"); hideBoot();
    boot().then(function () { if (S.tab === "pos") { var t = $(".top-r .tt b"); if (t) t.textContent = S.company; } }).catch(function () { });
    loadCatalog(false); flush(); if (BUY()) loadBest();
  }
  function tabB(t, i, l, bd) { return '<button class="tab" data-t="' + t + '">' + ic(i) + "<span>" + l + "</span>" + (bd ? '<span class="bd" hidden>0</span>' : "") + "</button>"; }
  function go(t) {
    vt(function () {
      S.tab = t; hideAdv(); $$(".tab").forEach(function (b) { b.classList.toggle("on", b.dataset.t === t); });
      var app = $(".app"), v = $("#vw"); var top = $(".top"); top && top.remove(); var ch = $(".chips"); ch && ch.remove();
      v.className = "view v-" + t; v.scrollTop = 0;
      if (t === "pos") { app.insertAdjacentHTML("afterbegin", topHTML()); bindTop(); renderCats(); renderGrid(); }
      else if (t === "cart") renderCart();
      else if (t === "sales") renderSales();
      else renderMore();
      updateDock();
    });
  }

  /* ------------------------------------------------------------ صفحة البيع */
  function topHTML() {
    return '<header class="top"><div class="top-r"><span class="' + avCls() + '">' + esc((S.name || "A").trim()[0] || "A") + "</span>" +
      '<span class="tt"><b>' + esc(S.company) + '</b><small id="netl">' + netLabel() + "</small></span>" +
      (S.buy ? '<div class="mode" id="md" role="tablist" data-m="' + S.mode + '"><i></i><button data-m="sale"' + (BUY() ? "" : ' class="on"') + '>بيع</button><button data-m="buy"' + (BUY() ? ' class="on"' : "") + ">شراء</button></div>" : "") +
      '<button class="ib" id="rf" aria-label="تحديث">' + ic("sync") + (S.queue.length ? '<span class="bd">' + S.queue.length + "</span>" : "") + "</button></div>" +
      '<div class="srch"><label class="fld">' + ic("search") + '<input id="q" type="search" enterkeyhint="search" placeholder="ابحث بالاسم أو الكود أو الباركود" value="' + esc(S.q) + '" autocomplete="off"><button class="clr" id="qc"' + (S.q ? "" : " hidden") + ">" + ic("x") + '</button><button type="button" class="mic" id="mc" aria-label="بحث بالصوت">' + MIC + "<i></i></button></label>" +
      '<button class="scan" id="sc" aria-label="مسح باركود">' + ic("scan") + "</button></div>" + (BUY() ? supBar() : ctxBar()) + "</header>" +
      '<div class="chips" id="chips"></div>';
  }
  function bindTop() {
    bindCtx();
    var q = $("#q"), t = 0;
    q.oninput = function () { clearTimeout(t); $("#qc").hidden = !q.value; t = setTimeout(function () { S.q = q.value; S.shown = 60; renderGrid(); }, 120); };
    q.onkeydown = function (e) {
      if (e.key !== "Enter") return; e.preventDefault();
      if (addCode(q.value, q)) { q.value = ""; S.q = ""; $("#qc").hidden = true; renderGrid(); return; }
      q.blur();
    };
    $("#qc").onclick = function (e) { e.preventDefault(); q.value = ""; S.q = ""; this.hidden = true; renderGrid(); q.focus(); };
    $("#sc").onclick = scan;
    $("#mc").onclick = function (e) { e.preventDefault(); e.stopPropagation(); voice(); };
    paintLan();
    $("#rf").onclick = function () { boot().catch(function () { }); loadCatalog(true); flush(); if (BUY()) loadBest(true); };
    $$("#md button").forEach(function (b) { b.onclick = function () { if (b.dataset.m !== S.mode) setMode(b.dataset.m); }; });
    var sb = $("#sbar"); if (sb) sb.onclick = function () { custSheet(); };
  }
  function renderCats() {
    var box = $("#chips"); if (!box) return;
    var m = {}; S.cat.forEach(function (p) { if (p.g) m[p.g] = (m[p.g] || 0) + 1; });
    var gs = Object.keys(m).sort(function (a, b) { return m[b] - m[a]; }).slice(0, 24);
    box.hidden = !gs.length;
    box.hidden = !gs.length && !BUY();
    box.innerHTML = '<button class="chip' + (S.g ? "" : " on") + '" data-g="">الكل</button>' +
      (BUY() ? '<button class="chip low' + (S.g === "\u0001low" ? " on" : "") + '" data-g="\u0001low">⚠️ النواقص</button><button class="chip win' + (S.g === "\u0001best" ? " on" : "") + '" data-g="\u0001best">🏆 أرخص عند موردي</button>' : "") + gs.map(function (g) { return '<button class="chip' + (S.g === g ? " on" : "") + '" data-g="' + esc(g) + '">' + esc(g) + "</button>"; }).join("");
    $$(".chip", box).forEach(function (c) { c.onclick = function () { S.g = c.dataset.g; S.shown = 60; $$(".chip", box).forEach(function (x) { x.classList.toggle("on", x === c); }); renderGrid(); buzz(8); }; });
  }
  function filtered() {
    var w = fold(S.q).trim().split(/\s+/).filter(Boolean);
    return S.cat.filter(function (p) {
      if (S.g === "\u0001low") { if (!BUY() || (+p.s || 0) >= 5) return false; }
      else if (S.g === "\u0001best") { var b0 = best(p); if (!BUY() || !S.cust || !b0 || b0[0] !== S.cust.id) return false; }
      else if (S.g && p.g !== S.g) return false;
      for (var i = 0; i < w.length; i++) if (p._f.indexOf(w[i]) < 0) return false;
      return true;
    });
  }
  function renderGrid() {
    var v = $("#vw"); if (!v || S.tab !== "pos") return;
    if (!S.cat.length) {
      v.innerHTML = S.catAt && !CATWAIT ? empty("grid", "لا توجد أصناف", "أضف أصنافاً في البرنامج ثم اضغط تحديث") : '<div class="grid">' + Array(6).join('<div class="sk"></div>') + "</div>";
      return;
    }
    var list = filtered();
    if (!list.length) {
      /* لا تطابق تام ← أقرب الأصناف نطقاً (عربي ↔ لاتيني ، خطأ حرف) */
      var near = S.q.trim() && !S.g ? vFind(vWords(S.q), 30).map(function (x) { return x.p; }) : [];
      if (near.length) { v.innerHTML = '<div class="near">' + ic("search") + "<span>لا تطابق تام — أقرب النتائج لـ «" + esc(S.q.trim()) + '»</span></div><div class="grid">' + near.map(card).join("") + "</div>"; bindCards(v, near); return; }
      v.innerHTML = empty("search", "لا نتائج", "جرّب كلمة أخرى أو امسح الباركود"); return;
    }
    var part = list.slice(0, S.shown);
    v.innerHTML = '<div class="grid">' + part.map(card).join("") + "</div>" + (list.length > S.shown ? '<button class="more-btn" id="mb">عرض المزيد (' + (list.length - S.shown) + ")</button>" : "");
    var mb = $("#mb"); if (mb) mb.onclick = function () { S.shown += 60; renderGrid(); };
    bindCards(v, list);
  }
  function card(p, i) {
    var u = defUnit(p), t = tile(p.n), q = qtyOf(p.i), s = +p.s || 0;
    var st = s <= 0 ? '<span class="st no">نفد</span>' : '<span class="st' + (s < 5 ? " lo" : "") + '">' + fq(s) + "</span>";
    return '<button class="pc" data-i="' + p.i + '" style="animation-delay:' + Math.min(i, 12) * 22 + 'ms">' +
      pic(p.n, p.i, p.im, "", p.g ? "<small>" + esc(p.g) + "</small>" : "") +
      ((p.u || []).length > 1 ? '<span class="mo">⋯</span>' : "") + (q ? '<span class="q">' + fq(q) + "</span>" : "") +
      '<span class="nm">' + esc(p.n) + "</span>" +
      '<span class="pr"><b>' + N(u ? (BUY() ? buyPrice(p, u) : priceOf(u)) : 0) + "<small>" + esc(u ? u.n : "") + "</small></b>" + '<span class="stw"><small>رصيد الصنف</small>' + st + "</span></span>" + (BUY() ? bestStrip(p, u) : "") + "</button>";
  }
  function bindCards(v, list) {
    var map = {}; list.forEach(function (p) { map[p.i] = p; });
    $$(".pc", v).forEach(function (c) {
      var p = map[c.dataset.i], tm = 0, long = false, sx = 0, sy = 0;
      c.addEventListener("pointerdown", function (e) { long = false; sx = e.clientX; sy = e.clientY; tm = setTimeout(function () { long = true; buzz(25); productSheet(p); }, 480); });
      c.addEventListener("pointermove", function (e) { if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) > 10) clearTimeout(tm); });
      ["pointerup", "pointercancel", "pointerleave"].forEach(function (ev) { c.addEventListener(ev, function () { clearTimeout(tm); }); });
      c.addEventListener("contextmenu", function (e) { e.preventDefault(); });
      c.onclick = function (e) {
        if (long) return;
        if (e.target.closest(".mo")) { productSheet(p); return; }
        add(p, null, 1, null, c.querySelector(".ph"));
      };
    });
  }
  function empty(i, t, s) { return '<div class="empty"><div class="em">' + ic(i) + "</div><b>" + t + "</b><p>" + s + "</p></div>"; }

  /* ------------------------------------------------------------ الورقة السفلية */
  function sheet(title, sub, body, foot) {
    var had = sheet._h; closeSheet(true, true);
    var ov = document.createElement("div"); ov.className = "ov";
    var sh = document.createElement("div"); sh.className = "sheet"; sh.setAttribute("role", "dialog");
    sh.innerHTML = '<div class="hd"><div class="r"><h3>' + title + '</h3><button class="ib" data-x>' + ic("x") + "</button></div>" + (sub ? "<small>" + sub + "</small>" : "") + "</div>" +
      '<div class="bd">' + body + "</div>" + (foot ? '<div class="ft">' + foot + "</div>" : "");
    document.body.appendChild(ov); document.body.appendChild(sh);
    ov.onclick = function () { closeSheet(); };
    sh.querySelector("[data-x]").onclick = function () { closeSheet(); };
    /* سحب للأسفل للإغلاق */
    var hd = sh.querySelector(".hd"), y0 = 0, dy = 0;
    hd.addEventListener("touchstart", function (e) { y0 = e.touches[0].clientY; dy = 0; sh.style.transition = "none"; }, { passive: true });
    hd.addEventListener("touchmove", function (e) { dy = Math.max(0, e.touches[0].clientY - y0); sh.style.transform = "translateY(" + dy + "px)"; }, { passive: true });
    hd.addEventListener("touchend", function () { sh.style.transition = "transform .25s"; if (dy > 110) closeSheet(); else sh.style.transform = ""; });
    if (!had) history.pushState({ sh: 1 }, ""); sheet._h = true;
    return sh;
  }
  function closeSheet(now, keepHist) {
    var sh = $(".sheet"), ov = $(".ov"); if (!sh) return;
    if (sheet._onClose) { var f = sheet._onClose; sheet._onClose = null; try { f(); } catch (e) { } }
    if (now) { sh.remove(); ov && ov.remove(); }
    else { sh.classList.add("out"); ov && ov.classList.add("out"); setTimeout(function () { sh.remove(); ov && ov.remove(); }, 240); }
    if (keepHist) return;
    if (sheet._h) { sheet._h = false; try { if (history.state && history.state.sh) history.back(); } catch (e) { } }
  }
  window.addEventListener("popstate", function () { if ($(".sheet")) { sheet._h = false; closeSheet(); } else if ($(".done")) newSale(); });

  function stepper(val, id) { return '<div class="stp lg"><button data-s="-1">' + ic("minus") + '</button><input class="n" id="' + id + '" inputmode="decimal" value="' + fq(val) + '"><button data-s="1">' + ic("plus") + "</button></div>"; }
  function bindStepper(sh, id, onCh) {
    var inp = $("#" + id, sh);
    $$(".stp.lg button", sh).forEach(function (b) { b.onclick = function () { var v = Math.max(0, r2((parseFloat(inp.value) || 0) + +b.dataset.s)); inp.value = fq(v); buzz(8); onCh && onCh(); }; });
    inp.oninput = function () { onCh && onCh(); };
    inp.onfocus = function () { inp.select(); };
  }
  function productSheet(p) {
    if (BUY()) { compareSheet(p); return; }
    var us = p.u || [], u = defUnit(p), t = tile(p.n);
    var sh = sheet(esc(p.n), (p.c ? "كود " + esc(p.c) + " · " : "") + "المخزون " + fq(p.s),
      (p.im ? '<div class="pbig">' + pic(p.n, p.i, p.im, "", "") + "</div>" : "") + '<span class="lbl">الوحدة</span><div class="units">' + us.map(function (x) { return '<button class="unit' + (x === u ? " on" : "") + '" data-u="' + x.id + '"><b>' + esc(x.n) + "</b><small>" + N(priceOf(x)) + "</small></button>"; }).join("") + "</div>" +
      '<div class="row2"><div><span class="lbl">الكمية</span>' + stepper(1, "pq") + '</div><div><span class="lbl">السعر</span><input class="inp n" id="pp" inputmode="decimal" value="' + r2(priceOf(u)) + '"></div></div>',
      '<button class="btn pri" id="pa" style="width:100%">' + ic("plus") + ' <span>أضف للسلة — <bdi class="n" id="pt"></bdi></span></button>');
    function upd() { $("#pt", sh).textContent = fm((parseFloat($("#pq", sh).value) || 0) * (parseFloat($("#pp", sh).value) || 0)) + " " + CUR; }
    bindStepper(sh, "pq", upd); $("#pp", sh).oninput = upd; upd();
    $$(".unit", sh).forEach(function (b) { b.onclick = function () { u = us.filter(function (x) { return x.id == b.dataset.u; })[0]; $$(".unit", sh).forEach(function (x) { x.classList.toggle("on", x === b); }); $("#pp", sh).value = r2(priceOf(u)); upd(); buzz(8); }; });
    $("#pa", sh).onclick = function () {
      var q = parseFloat($("#pq", sh).value) || 0, pr = parseFloat($("#pp", sh).value); if (q <= 0) return;
      add(p, u, q, isNaN(pr) ? null : r2(pr), $('.pc[data-i="' + p.i + '"] .ph')); closeSheet(); toast("أُضيف: " + p.n);
    };
  }


  /* ============================================================ الشراء + «مستشار الشراء» (أرخص مورد لكل صنف) */
  var THEME = { sale: "#ea580c", buy: "#0f766e" };
  function applyMode() {
    var r = document.documentElement; if (BUY()) r.dataset.mode = "buy"; else delete r.dataset.mode;
    var m = document.querySelector('meta[name="theme-color"]'); if (m) m.content = THEME[S.mode];
    $$(".tab").forEach(function (b) {
      var k = b.dataset.t, sp = b.querySelector("span");
      if (k === "pos") { sp.textContent = BUY() ? "الشراء" : "البيع"; b.querySelector("use").setAttribute("href", "#i-" + (BUY() ? "truck" : "grid")); }
      if (k === "sales") sp.textContent = BUY() ? "مشترياتي" : "مبيعاتي";
    });
    paintMode();
  }
  function paintMode() {
    var md = $("#md");
    if (!md) { if (S.buy && S.tab === "pos" && $(".top")) go("pos"); return; }
    md.dataset.m = S.mode; $$("button", md).forEach(function (b) { b.classList.toggle("on", b.dataset.m === S.mode); });
  }
  function setMode(m, silent) {
    if (m === "buy" && !S.buy) { toast("حسابك لا يملك صلاحية الشراء", "bad"); return; }
    saveCart(); S.mode = m; LS.set("mode", m);
    S.cart = LS.get(m === "buy" ? "pcart" : "cart", []); S.cust = LS.get(m === "buy" ? "psup" : "cust", null); S.disc = 0; S.note = ""; S.g = "";
    buzz(14); hideAdv(); applyMode();
    if (!silent) { go(S.tab === "more" ? "more" : S.tab); toast(m === "buy" ? "وضع الشراء — يظهر لك أرخص مورد لكل صنف" : "وضع البيع"); }
    if (m === "buy") loadBest();
  }
  var bestBusy = false;
  function loadBest(force) {
    if (bestBusy) return; bestBusy = true;
    api("/api/pbest", null, { timeout: 40000 }).then(function (d) {
      bestBusy = false; if (!d.ok) throw new Error(d.error);
      S.pb = d.p || {}; S.sup = d.sup || {}; S.pbAt = d.at || ""; LS.set("pb", { p: S.pb, sup: S.sup, at: S.pbAt });
      if (force) toast("تم تحديث أسعار الموردين");
      if (!BUY()) return;
      if (S.tab === "pos") { renderGrid(); var at = $("#sbar .at"); if (at) at.lastChild.textContent = "أسعار " + S.pbAt; } else if (S.tab === "cart") renderCart();
    }, function (e) { bestBusy = false; if (force && !e.auth) toast("تعذّر تحديث أسعار الموردين", "bad"); });
  }
  function offers(pid) { return (S.pb && S.pb[pid]) || []; }
  function best(p) { return offers(p.i)[0] || null; }
  function supOf(pid, sid) { return offers(pid).filter(function (o) { return o[0] === sid; })[0] || null; }
  function supName(id) { var x = S.sup[id]; return x ? x[0] : (S.cust && S.cust.id === id ? S.cust.n : "مورد"); }
  function supPhone(id) { var x = S.sup[id]; return x ? x[1] : (S.cust && S.cust.id === id ? S.cust.ph || "" : ""); }
  function oPrice(o, f) { return r2(o[1] * (+f || 1)); }
  /* سعر الشراء المقترح: آخر سعر عند المورد المختار ، وإلا آخر سعر شراء مسجّل في بطاقة الصنف */
  function buyPrice(p, u) { var o = S.cust && supOf(p.i, S.cust.id); return o ? oPrice(o, u.f) : r2(+u.c || 0); }
  function agoD(d) {
    if (!d) return ""; var n = Math.round((new Date(new Date().toISOString().slice(0, 10)) - new Date(d)) / 864e5);
    return n <= 0 ? "اليوم" : n === 1 ? "أمس" : n < 30 ? "منذ " + n + " يوم" : n < 365 ? "منذ " + Math.round(n / 30) + " شهر" : "منذ " + Math.round(n / 365) + " سنة";
  }
  function bestStrip(p, u) {
    var o = offers(p.i); if (!o.length) return '<span class="bst none">' + ic("tag") + "أول شراء</span>";
    var b = o[0];
    if (S.cust && b[0] === S.cust.id) return '<span class="bst me">' + ic("check") + "<em>موردك هو الأرخص</em></span>";
    return '<span class="bst">' + ic("trophy") + "<em>" + esc(supName(b[0])) + "</em>" + N(oPrice(b, u.f)) + "</span>";
  }
  /* عاجي كريستال: الزبون + قائمة الأسعار تحت البحث (وضع البيع) */
  var PKL = [["p", "سعر البيع"], ["w", "الجملة"], ["r", "التجزئة"], ["ps", "عابر سبيل"]];
  function ctxBar() {
    var c = S.cust;
    return '<div class="ctx" id="ctx"><button class="cx" id="cxc">' + ic("user") + '<span class="tx"><small>الزبون</small><b>' + esc(c ? c.n : "تعامل نقدي") + "</b></span>" + '<span class="dn"></span></button>' +
      '<label class="cx">' + ic("tag") + '<span class="tx"><small>قائمة السعر</small><b id="cxpl">' + esc((PKL.filter(function (x) { return x[0] === S.pk; })[0] || PKL[0])[1]) + '</b></span><span class="dn"></span>' +
      '<select id="cxp" aria-label="قائمة السعر">' + PKL.map(function (x) { return '<option value="' + x[0] + '"' + (S.pk === x[0] ? " selected" : "") + ">" + x[1] + "</option>"; }).join("") + "</select></label></div>";
  }
  function bindCtx() {
    var b = $("#cxc"); if (b) b.onclick = function () { custSheet(); };
    var p = $("#cxp"); if (p) p.onchange = function () { S.pk = this.value; LS.set("pk", S.pk); $("#cxpl").textContent = this.options[this.selectedIndex].text; renderGrid(); toast("قائمة الأسعار: " + this.options[this.selectedIndex].text); };
  }
  function refreshCtx() { var x = $("#ctx"); if (!x) return; x.outerHTML = ctxBar(); bindCtx(); }
  function supBar() {
    var s = S.cust;
    return '<button class="sbar" id="sbar">' + ic("truck") + '<span class="tx"><small>المورد</small><b>' + esc(s ? s.n : "اختر المورد — أو اشترِ نقداً") + "</b></span>" +
      (S.pbAt ? '<span class="at">' + ic("trophy") + "<span>أسعار " + esc(S.pbAt) + "</span></span>" : "") + '<span class="ar">' + ic("back") + "</span></button>";
  }
  /* تطبيق أسعار مورد على أسطر السلة (all = حتى الأسعار المعدّلة يدوياً) */
  function applySup(id, all) {
    var n = 0;
    S.cart.forEach(function (l) { if (!all && l.man) return; var o = supOf(l.pid, id); if (o) { var v = oPrice(o, l.f); if (Math.abs(v - l.pr) > .004) n++; l.pr = v; if (all) l.man = false; } });
    saveCart(); return n;
  }
  function useSupplier(id) {
    S.cust = { id: id, n: supName(id), ph: supPhone(id) }; var n = applySup(id, true); buzz(14);
    toast(n ? "طُبّقت أسعار " + S.cust.n + " على " + n + (n === 1 ? " صنف" : " أصناف") : "المورد: " + S.cust.n);
  }

  /* بطاقة «أرخص مورد» العائمة بعد إدخال الصنف */
  var ADV = 0;
  function hideAdv(now) { clearTimeout(ADV); $$(".adv").forEach(function (a) { if (now) a.remove(); else { a.classList.add("out"); setTimeout(function () { a.remove(); }, 260); } }); }
  function advise(p, u) {
    hideAdv(true);
    var o = offers(p.i), l = S.cart.filter(function (x) { return x.pid === p.i && x.puid === u.id; })[0], h, mine = false, diff = 0;
    if (!o.length) h = '<span class="ai nb">' + ic("tag") + '</span><div class="tx"><small>' + esc(p.n) + " · " + esc(u.n) + "</small><b>أول شراء لهذا الصنف</b><span>لا يوجد سعر سابق عند أي مورد — عدّل السعر من السلة</span></div>";
    else {
      var b = o[0], bp = oPrice(b, u.f), cur = l ? l.pr : bp; mine = !!(S.cust && b[0] === S.cust.id); diff = r2(cur - bp);
      var pc = cur > 0 ? Math.round(diff / cur * 100) : 0;
      h = '<span class="ai' + (mine ? " ok" : "") + '">' + ic(mine ? "check" : "trophy") + '</span><div class="tx"><small>' + esc(p.n) + " · " + esc(u.n) + "</small>" +
        (mine ? "<b>" + esc(S.cust.n) + " هو الأرخص</b><span>" + N(bp) + " " + CUR + " · " + agoD(b[2]) + (o.length > 1 ? " · من بين " + o.length + " موردين" : "") + "</span>"
          : "<b>أقل سعر عند " + esc(supName(b[0])) + "</b><span>" + N(bp) + " " + CUR + " · " + agoD(b[2]) + (diff > .004 ? " · <em>أرخص بـ " + fm(diff) + " (" + pc + "%)</em>" : "") + "</span>") + "</div>" +
        (o.length > 1 || diff > .004 ? '<button class="go" data-a="cmp">قارن<small>' + o.length + "</small></button>" : "");
    }
    var el = document.createElement("div"); el.className = "adv" + (mine ? " ok" : diff > .004 ? " hot" : "");
    el.innerHTML = h + '<button class="x" data-a="x" aria-label="إغلاق">' + ic("x") + '</button><i class="tm"></i>';
    document.body.appendChild(el);
    el.onclick = function (e) { var a = e.target.closest("[data-a]"); if (!a) return; hideAdv(); if (a.dataset.a === "cmp") { var i = S.cart.indexOf(l); compareSheet(p, u, i >= 0 ? i : null); } };
    ADV = setTimeout(hideAdv, 6500);
  }

  /* مقارنة الموردين للصنف + الكمية والسعر وهامش الربح */
  function compareSheet(p, u0, li) {
    var us = p.u || [], l = li != null ? S.cart[li] : null;
    var u = (l && us.filter(function (x) { return x.id === l.puid; })[0]) || u0 || defUnit(p);
    var sh = sheet(esc(p.n), (p.c ? "كود " + esc(p.c) + " · " : "") + "المخزون " + fq(p.s),
      (us.length > 1 ? '<span class="lbl">وحدة الشراء</span><div class="units">' + us.map(function (x) { return '<button class="unit' + (x === u ? " on" : "") + '" data-u="' + x.id + '"><b>' + esc(x.n) + "</b><small>" + N(buyPrice(p, x)) + "</small></button>"; }).join("") + "</div>" : "") +
      '<span class="lbl">مقارنة الموردين <em id="cmpn"></em></span><div class="cmp" id="cmp"></div>' +
      '<div class="row2"><div><span class="lbl">الكمية</span>' + stepper(l ? l.q : 1, "pq") + '</div><div><span class="lbl">سعر الشراء</span><input class="inp n" id="pp" inputmode="decimal"></div></div>' +
      '<div class="mg" id="mg"></div>',
      l ? '<div class="act" style="margin:0"><button class="btn ghost" id="ldel" aria-label="حذف" style="color:var(--bad)">' + ic("trash") + '</button><button class="btn pri" id="pa">' + ic("check") + ' <span>حفظ — <bdi class="n" id="pt"></bdi></span></button></div>'
        : '<button class="btn pri" id="pa" style="width:100%">' + ic("plus") + ' <span>أضف للشراء — <bdi class="n" id="pt"></bdi></span></button>');
    var pp = $("#pp", sh), man = l ? !!l.man : false;
    pp.value = r2(l ? l.pr : buyPrice(p, u));
    function rows() {
      var o = offers(p.i), box = $("#cmp", sh), cur = parseFloat(pp.value) || 0;
      $("#cmpn", sh).textContent = o.length ? "· " + o.length + (o.length === 1 ? " مورد" : " موردين") : "";
      if (!o.length) { box.innerHTML = '<div class="cmp-e">' + ic("tag") + "<span>لم يُشترَ هذا الصنف من أي مورد بعد.<br>آخر سعر شراء في بطاقة الصنف: <b>" + N(+u.c || 0) + "</b></span></div>"; return; }
      var min = oPrice(o[0], u.f), max = oPrice(o[o.length - 1], u.f);
      box.innerHTML = o.map(function (x, i) {
        var pr = oPrice(x, u.f), d = r2(pr - min), w = max > min ? Math.round(100 - (pr - min) / (max - min) * 62) : 100, me = S.cust && x[0] === S.cust.id, on = Math.abs(pr - cur) < .005;
        return '<button class="cr' + (i ? "" : " win") + (me ? " me" : "") + (on ? " on" : "") + '" data-i="' + i + '" style="animation-delay:' + i * 45 + 'ms"><span class="rk">' + (i ? i + 1 : ic("trophy")) + "</span>" +
          '<span class="tx"><b>' + esc(supName(x[0])) + (me ? ' <i class="tg">موردك</i>' : "") + "</b><small>" + agoD(x[2]) + " · " + x[3] + (x[3] === 1 ? " مرة" : x[3] < 11 ? " مرات" : " مرة") + '</small><span class="bar"><i style="width:' + w + '%"></i></span></span>' +
          '<span class="pv">' + N(pr) + "<small>" + (i ? '<bdi class="n">+' + fm(d) + " · +" + (min > 0 ? Math.round(d / min * 100) : 0) + "%</bdi>" : "الأرخص") + "</small></span></button>";
      }).join("");
      $$(".cr", box).forEach(function (b) {
        b.onclick = function () {
          var x = o[+b.dataset.i]; pp.value = oPrice(x, u.f); man = true; buzz(8); upd(); rows();
          if (!S.cust || (!S.cart.length && S.cust.id !== x[0])) { S.cust = { id: x[0], n: supName(x[0]), ph: supPhone(x[0]) }; saveCart(); toast("المورد: " + S.cust.n); }
          else if (S.cust.id !== x[0]) toast("سعر " + supName(x[0]) + " — مورد الفاتورة الحالي " + S.cust.n, "warn");
        };
      });
    }
    function upd() {
      var q = parseFloat($("#pq", sh).value) || 0, c = parseFloat(pp.value) || 0, sp = +u.p || 0, m = $("#mg", sh);
      $("#pt", sh).textContent = fm(q * c) + " " + CUR;
      if (sp > 0 && c > 0) {
        var mg = (sp - c) / sp * 100; m.className = "mg " + (mg < 0 ? "bad" : mg < 8 ? "lo" : "ok");
        m.innerHTML = ic("chart") + "<span>سعر البيع " + N(sp) + " · هامش الربح <b>" + (Math.round(mg * 10) / 10) + "%</b> <bdi class=\"n\">(" + fm(sp - c) + ")</bdi></span>";
      } else { m.className = "mg"; m.innerHTML = ""; }
      $$(".cr", sh).forEach(function (b) { b.classList.remove("on"); });
    }
    bindStepper(sh, "pq", upd); pp.oninput = function () { man = true; upd(); }; upd(); rows();
    $$(".unit", sh).forEach(function (b) {
      b.onclick = function () { u = us.filter(function (x) { return x.id == b.dataset.u; })[0]; $$(".unit", sh).forEach(function (x) { x.classList.toggle("on", x === b); }); pp.value = buyPrice(p, u); man = false; upd(); rows(); buzz(8); };
    });
    function after() { if (S.tab === "cart") renderCart(); else if (S.tab === "pos") paintQty(p.i); }
    var del = $("#ldel", sh); if (del) del.onclick = function () { S.cart.splice(li, 1); saveCart(); closeSheet(); after(); updateDock(); };
    $("#pa", sh).onclick = function () {
      var q = parseFloat($("#pq", sh).value) || 0, c = r2(parseFloat(pp.value) || 0); if (q <= 0) return;
      if (l) { l.q = r2(q); l.pr = c; l.puid = u.id; l.un = u.n; l.f = +u.f || 1; l.man = man; saveCart(); closeSheet(); after(); updateDock(true); return; }
      add(p, u, q, c, $('.pc[data-i="' + p.i + '"] .ph'), true); var nl = S.cart[0]; if (nl && nl.puid === u.id) { nl.man = man; saveCart(); }
      closeSheet(); toast("أُضيف للشراء: " + p.n);
    };
  }

  /* تحليل السلة: أرخص توليفة + مقارنة الموردين على السلة كاملة */
  function basket() {
    var cur = 0, mix = 0, bySup = {}, groups = {};
    S.cart.forEach(function (l, i) {
      var o = offers(l.pid), b = o[0]; cur += l.q * l.pr;
      mix += l.q * (b ? Math.min(oPrice(b, l.f), l.pr) : l.pr);
      o.forEach(function (x) { var s = bySup[x[0]] || (bySup[x[0]] = { id: x[0], cov: 0, tot: 0, win: 0 }); s.cov++; s.tot += l.q * oPrice(x, l.f); });
      if (b) { bySup[b[0]].win++; (groups[b[0]] = groups[b[0]] || []).push({ l: l, i: i, p: oPrice(b, l.f) }); }
    });
    var sups = Object.keys(bySup).map(function (k) { return bySup[k]; }).sort(function (a, b) { return b.win - a.win || b.cov - a.cov || a.tot - b.tot; });
    return { n: S.cart.length, cur: r2(cur), mix: r2(mix), save: r2(Math.max(0, cur - mix)), sups: sups, groups: groups };
  }
  function lineHint(l) {
    var o = offers(l.pid), b = o[0]; if (!b) return "";
    var bp = oPrice(b, l.f);
    if (S.cust && b[0] === S.cust.id && l.pr <= bp + .004) return ' <em class="hb ok">' + ic("check") + "الأرخص</em>";
    if (l.pr - bp > .004) return ' <em class="hb">' + ic("trophy") + esc(supName(b[0])) + " أرخص بـ " + fm(l.pr - bp) + "</em>";
    return "";
  }
  function advisorCard(bk) {
    if (!bk.sups.length) return "";
    return '<div class="card advc"><div class="ah"><span class="ai">' + ic("bolt") + "</span><div><small>مستشار الشراء</small><b>" +
      (bk.save > .004 ? 'يمكنك توفير <bdi class="n">' + fm(bk.save) + "</bdi> " + CUR : "أسعارك هي الأفضل ✓") + "</b></div></div>" +
      "<p>" + (bk.save > .004 ? "لو اشتريت كل صنف من المورد الأرخص له — اضغط مورداً لتطبيق أسعاره" : "كل صنف بسعر يساوي أو أقل من أرخص مورد معروف") + "</p>" +
      '<div class="sups">' + bk.sups.slice(0, 4).map(function (s) {
        return '<button class="sp' + (S.cust && S.cust.id === s.id ? " on" : "") + '" data-s="' + s.id + '"><b>' + esc(supName(s.id)) + "</b><small>" + (s.win ? "🏆 الأرخص في " + s.win + " · " : "") + "يغطي " + s.cov + "/" + bk.n + '</small><bdi class="n">' + fm(s.tot) + "</bdi></button>";
      }).join("") + "</div>" +
      '<button class="lk" id="plan">' + ic("receipt") + "<span>خطة الشراء الذكية — طلبية لكل مورد</span>" + ic("back") + "</button></div>";
  }
  function waNum(ph) { var d = String(ph || "").replace(/\D/g, ""); if (!d) return ""; if (d.indexOf("00") === 0) d = d.slice(2); else if (d[0] === "0") d = "213" + d.slice(1); return d; }
  function planSheet() {
    var bk = basket(), ids = Object.keys(bk.groups).sort(function (a, b) { return bk.groups[b].length - bk.groups[a].length; });
    var none = S.cart.filter(function (l) { return !offers(l.pid).length; });
    var body = '<div class="plan-h"><div><small>السلة الآن</small><b>' + N(bk.cur) + '</b></div><div><small>أفضل توليفة</small><b class="ok">' + N(bk.mix) + '</b></div><div class="sv"><small>التوفير</small><b>' + N(bk.save) + "</b></div></div>" +
      ids.map(function (id, gi) {
        var g = bk.groups[id], sum = g.reduce(function (a, x) { return a + x.l.q * x.p; }, 0), ph = supPhone(+id), t = tile(supName(+id));
        return '<div class="card pg" style="animation-delay:' + gi * 60 + 'ms"><div class="pgh"><span class="ci" style="background:' + t.bg + '">' + t.ch + '</span><div class="tx"><b>' + esc(supName(+id)) + "</b><small>" + g.length + (g.length === 1 ? " صنف" : " أصناف") + ' · <bdi class="n">' + fm(sum) + "</bdi> " + CUR + "</small></div>" +
          (ph ? '<a class="ib" href="tel:' + esc(ph) + '" aria-label="اتصال">' + ic("phone") + "</a>" : "") + "</div>" +
          g.map(function (x) { return '<div class="pl"><span>' + esc(x.l.n) + "<small>" + fq(x.l.q) + " " + esc(x.l.un) + " × " + fm(x.p) + "</small></span><b>" + N(x.l.q * x.p) + "</b></div>"; }).join("") +
          '<div class="pga"><button class="btn ghost" data-sh="' + id + '">' + ic("share") + '<span>أرسل الطلب</span></button><button class="btn pri" data-use="' + id + '">' + ic("check") + "<span>اشترِ منه</span></button></div></div>";
      }).join("") +
      (none.length ? '<div class="grp"><span>بدون سجل شراء سابق</span><span>' + none.length + '</span></div><div class="card pg">' + none.map(function (l) { return '<div class="pl"><span>' + esc(l.n) + "<small>" + fq(l.q) + " " + esc(l.un) + "</small></span><b>" + N(l.q * l.pr) + "</b></div>"; }).join("") + "</div>" : "");
    var sh = sheet("خطة الشراء الذكية", "كل صنف عند المورد الأرخص له — أرسل الطلبية لكل مورد بلمسة", body);
    $$("[data-sh]", sh).forEach(function (b) {
      b.onclick = function () {
        var id = +b.dataset.sh, g = bk.groups[id];
        var txt = ["السلام عليكم " + supName(id) + " 👋", "طلبية من " + S.company + ":", ""].concat(g.map(function (x) { return "• " + x.l.n + " — " + fq(x.l.q) + " " + x.l.un; })).concat(["", "شكراً 🌟"]).join("\n");
        var w = waNum(supPhone(id));
        if (w) location.href = "https://wa.me/" + w + "?text=" + encodeURIComponent(txt);
        else if (navigator.share) navigator.share({ text: txt }).catch(function () { });
        else location.href = "https://wa.me/?text=" + encodeURIComponent(txt);
      };
    });
    $$("[data-use]", sh).forEach(function (b) { b.onclick = function () { useSupplier(+b.dataset.use); closeSheet(); renderCart(); updateDock(true); }; });
  }

  /* الدفع للمورد */
  function buyPaySheet(m0) {
    if (!S.cart.length) return;
    var T = totals().total, bk = basket(), mode = typeof m0 === "string" ? m0 : "cash";
    var sh = sheet("الدفع للمورد", esc(S.cust ? S.cust.n : "مورد نقدي") + " · " + S.cart.length + " صنف",
      '<div class="pay-tot"><small>إجمالي فاتورة الشراء</small><b><bdi class="n">' + fm(T) + "</bdi><small>" + CUR + "</small></b>" +
      (bk.save > .004 ? '<span class="sv w">💡 كان يمكن توفير ' + fm(bk.save) + " " + CUR + "</span>" : bk.sups.length ? '<span class="sv">✓ بأفضل الأسعار المعروفة</span>' : "") + "</div>" +
      '<div class="seg" id="pm">' + [["cash", "cash", "نقدي"], ["part", "split", "جزئي"], ["credit", "clock", "آجل"]].map(function (x) { return "<button" + (mode === x[0] ? ' class="on"' : "") + ' data-m="' + x[0] + '">' + ic(x[1]) + x[2] + "</button>"; }).join("") + "</div>" +
      '<div id="pr"><span class="lbl">المبلغ المدفوع للمورد الآن</span><input class="inp n" id="rv" inputmode="decimal" placeholder="0.00"></div>' +
      '<div class="change" id="ch"><span id="chl"></span><b><bdi class="n" id="chv">0.00</bdi></b></div>' +
      (S.tr.length > 1 ? '<span class="lbl">الخزينة</span><select class="inp" id="tr" style="font-size:15px">' + S.tr.map(function (t) { return '<option value="' + t.id + '"' + (t.id === S.trId ? " selected" : "") + ">" + esc(t.n) + "</option>"; }).join("") + "</select>" : "") +
      '<span class="lbl">ملاحظة (اختياري)</span><textarea class="inp" id="nn" placeholder="مثال: رقم فاتورة المورد">' + esc(S.note) + "</textarea>",
      '<button class="btn ok" id="pok" style="width:100%">' + ic("check") + "<span>تأكيد الشراء</span></button>");
    var rv = $("#rv", sh);
    function paid() { return mode === "cash" ? T : mode === "credit" ? 0 : Math.min(T, Math.max(0, parseFloat(rv.value) || 0)); }
    function upd() {
      var pd = paid(), ch = $("#ch", sh); $("#pr", sh).hidden = mode !== "part";
      if (mode === "cash") { ch.className = "change"; $("#chl", sh).textContent = "يُدفع من الخزينة"; $("#chv", sh).textContent = fm(T); }
      else { ch.className = "change due"; $("#chl", sh).textContent = "يُسجَّل لحساب المورد"; $("#chv", sh).textContent = fm(T - pd); }
      var need = T - pd > .004 && !S.cust, b = $("#pok", sh);
      b.innerHTML = need ? ic("truck") + "<span>اختر المورد للشراء الآجل</span>" : ic("check") + "<span>تأكيد الشراء</span>"; b.className = need ? "btn pri" : "btn ok";
    }
    $$("#pm button", sh).forEach(function (b) { b.onclick = function () { mode = b.dataset.m; $$("#pm button", sh).forEach(function (x) { x.classList.toggle("on", x === b); }); buzz(8); rv.value = ""; upd(); if (mode === "part") setTimeout(function () { rv.focus(); }, 80); }; });
    rv.oninput = upd; upd();
    $("#pok", sh).onclick = function () {
      var pd = r2(paid());
      if (T - pd > .004 && !S.cust) { custSheet(function () { buyPaySheet(mode); }); return; }
      var tr = $("#tr", sh); if (tr) { S.trId = +tr.value; LS.set("trId", S.trId); }
      S.note = $("#nn", sh).value.trim();
      var b = this; b.disabled = true; b.innerHTML = '<i class="spin"></i>';
      var body = { items: S.cart.map(function (l) { return { pid: l.pid, puid: l.puid, q: l.q, f: l.f, p: l.pr, d: l.d || 0 }; }), supplierId: S.cust ? S.cust.id : 0, disc: S.disc, note: S.note, cid: uid(), paid: pd, treasuryId: S.trId, cname: S.cust ? S.cust.n : "" };
      var snap = { cart: JSON.parse(JSON.stringify(S.cart)), cust: S.cust, disc: S.disc, total: T, paid: pd, recv: pd, at: new Date(), buy: true };
      api("/api/purchase", body, { timeout: 25000 }).then(function (d) {
        if (!d.ok) throw new Error(d.error || "تعذّر الحفظ");
        closeSheet(true, true); beep(); buzz([20, 50, 30]); if (d.queued) done(snap, null, "cloud"); else { done(snap, d, false); loadBest(); } refreshStock(1500);
      }).catch(function (e) {
        if (e.net) { S.queue.push({ ep: "/api/purchase", body: body, snap: { total: T, paid: pd, cust: S.cust ? S.cust.n : "", n: S.cart.length, buy: true }, at: Date.now() }); LS.set("queue", S.queue); closeSheet(true, true); done(snap, null, true); return; }
        b.disabled = false; upd(); beep(false); buzz([40, 40, 40]); toast(e.message, "bad");
      });
    };
  }

  /* ------------------------------------------------------------ السلة */
  function renderCart() {
    var v = $("#vw"), t = totals();
    if (!S.cart.length) {
      v.innerHTML = '<div class="ph1"><h2>' + (BUY() ? "فاتورة شراء" : "السلة") + "</h2></div>" + (BUY() ? empty("truck", "لا توجد أصناف للشراء", "اختر الأصناف أو امسح الباركود — سيظهر لك أرخص مورد لكل صنف") : empty("bag", "السلة فارغة", "اختر الأصناف من صفحة البيع أو امسح الباركود")) +
        '<div class="act" style="max-width:320px;margin:0 auto"><button class="btn pri" id="gb">' + ic(BUY() ? "truck" : "grid") + "<span>" + (BUY() ? "ابدأ الشراء" : "ابدأ البيع") + "</span></button></div>";
      $("#gb").onclick = function () { go("pos"); }; return;
    }
    var BK = BUY() ? basket() : null;
    v.innerHTML = '<div class="ph1"><h2>' + (BUY() ? "فاتورة شراء" : "السلة") + '</h2><button class="ib" id="clr" aria-label="إفراغ">' + ic("trash") + "</button></div>" +
      '<button class="card cust" id="cu"><span class="ci">' + ic(BUY() ? "truck" : "user") + '</span><span class="tx"><small>' + (BUY() ? "المورد" : "العميل") + "</small><b>" + esc(S.cust ? S.cust.n : BUY() ? "مورد نقدي — اضغط لاختيار المورد" : "عميل نقدي") + "</b></span>" +
      (S.cust && S.cust.bal ? '<span class="bal">' + (BUY() ? "له " : "رصيد ") + N(S.cust.bal) + "</span>" : "") + '<span class="ar">' + ic("back") + "</span></button>" +
      '<div class="card" id="ls">' + S.cart.map(function (l, i) {
        var lt = l.q * l.pr - (+l.d || 0);
        return '<div class="line" data-k="' + i + '">' + pic(l.n, l.pid, l.im, "", "") +
          '<div class="lc"><button class="tx" data-e="' + i + '"><b>' + esc(l.n) + "</b><small>" + esc(l.un) + " × " + N(l.pr) + (l.d ? " · <em>خصم " + N(l.d) + "</em>" : "") + (BUY() ? lineHint(l) : sgTag(l)) + "</small></button>" +
          '<div class="lb"><div class="stp"><button data-m="' + i + '">' + ic(l.q <= 1 ? "trash" : "minus") + "</button><b>" + fq(l.q) + '</b><button data-p="' + i + '">' + ic("plus") + '</button></div><span class="tot">' + N(lt) + " <small>" + CUR + "</small></span></div></div></div>";
      }).join("") + "</div>" + (BK ? advisorCard(BK) : "") +
      '<div class="card sum"><div><span>المجموع</span><b>' + N(t.sub) + "</b></div>" +
      (t.ld ? "<div><span>خصم الأصناف</span><b>- " + N(t.ld) + "</b></div>" : "") +
      '<div><span>خصم الفاتورة</span><button class="lk" id="dc">' + (S.disc ? "- " + N(S.disc) : "إضافة خصم") + "</button></div>" +
      '<div class="big"><span>الإجمالي</span><b>' + N(t.total) + ' <small style="font-size:13px;color:var(--mu)">' + CUR + "</small></b></div></div>" +
      '<div class="act"><button class="btn pri" id="pay">' + ic("cash") + "<span>" + (BUY() ? "الدفع للمورد" : "الدفع") + "</span></button></div>";
    $("#cu").onclick = custSheet;
    $("#clr").onclick = function () { if (confirmTap(this)) { S.cart = []; S.cust = null; S.disc = 0; saveCart(); renderCart(); updateDock(); toast("تم إفراغ السلة"); } };
    $("#dc").onclick = discSheet;
    $("#pay").onclick = function () { paySheet(); };
    $$("[data-p]", v).forEach(function (b) { b.onclick = function () { var l = S.cart[+b.dataset.p]; l.q = r2(l.q + 1); saveCart(); buzz(8); renderCart(); updateDock(true); }; });
    $$("[data-m]", v).forEach(function (b) { b.onclick = function () { var i = +b.dataset.m, l = S.cart[i]; if (l.q <= 1) { S.cart.splice(i, 1); buzz(20); } else { l.q = r2(l.q - 1); buzz(8); } saveCart(); renderCart(); updateDock(); }; });
    $$("[data-e]", v).forEach(function (b) {
      b.onclick = function () {
        var i = +b.dataset.e, l = S.cart[i], p = l && S.cat.filter(function (x) { return x.i === l.pid; })[0];
        if (BUY() && p) compareSheet(p, null, i); else lineSheet(i);
      };
    });
    $$(".advc .sp", v).forEach(function (b) { b.onclick = function () { useSupplier(+b.dataset.s); renderCart(); updateDock(true); }; });
    var pl = $("#plan", v); if (pl) pl.onclick = planSheet;
    swipeDelete(v);
  }
  /* زر خطير: ضغطة أولى = تأكيد ، الثانية = تنفيذ */
  function confirmTap(b) {
    if (b._arm) { b._arm = false; b.style.background = ""; b.style.color = ""; return true; }
    b._arm = true; b.style.background = "var(--bad)"; b.style.color = "#fff"; buzz(20); toast("اضغط مرة أخرى للتأكيد", "warn");
    setTimeout(function () { b._arm = false; b.style.background = ""; b.style.color = ""; }, 2600); return false;
  }
  function swipeDelete(v) {
    $$(".line", v).forEach(function (row) {
      var x0 = 0, y0 = 0, dx = 0, on = false;
      row.addEventListener("touchstart", function (e) { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; dx = 0; on = true; row.style.transition = "none"; }, { passive: true });
      row.addEventListener("touchmove", function (e) {
        if (!on) return; var mx = e.touches[0].clientX - x0, my = e.touches[0].clientY - y0;
        if (Math.abs(my) > Math.abs(mx) && Math.abs(dx) < 8) { on = false; row.style.transform = ""; return; }
        dx = mx; row.style.transform = "translateX(" + dx + "px)"; row.style.opacity = String(Math.max(.3, 1 - Math.abs(dx) / 260));
      }, { passive: true });
      row.addEventListener("touchend", function () {
        row.style.transition = "transform .25s,opacity .25s";
        if (on && Math.abs(dx) > 120) { row.style.transform = "translateX(" + (dx > 0 ? 120 : -120) + "%)"; row.style.opacity = "0"; buzz(25); setTimeout(function () { S.cart.splice(+row.dataset.k, 1); saveCart(); renderCart(); updateDock(); }, 220); }
        else { row.style.transform = ""; row.style.opacity = ""; } on = false;
      });
    });
  }
  function lineSheet(i) {
    var l = S.cart[i]; if (!l) return;
    var p = S.cat.filter(function (x) { return x.i === l.pid; })[0], us = p ? p.u : [];
    var sh = sheet(esc(l.n), "عدّل الكمية أو السعر أو الخصم",
      (us.length > 1 ? '<span class="lbl">الوحدة</span><div class="units">' + us.map(function (x) { return '<button class="unit' + (x.id === l.puid ? " on" : "") + '" data-u="' + x.id + '"><b>' + esc(x.n) + "</b><small>" + N(priceOf(x)) + "</small></button>"; }).join("") + "</div>" : "") +
      '<span class="lbl">الكمية</span>' + stepper(l.q, "lq") +
      '<div class="row2"><div><span class="lbl">السعر</span><input class="inp n" id="lpr" inputmode="decimal" value="' + r2(l.pr) + '"></div>' +
      '<div><span class="lbl">خصم على السطر</span><input class="inp n" id="ld" inputmode="decimal" value="' + (l.d ? r2(l.d) : "") + '" placeholder="0.00"></div></div>',
      '<div class="act" style="margin:0"><button class="btn ghost" id="ldel" aria-label="حذف" style="color:var(--bad)">' + ic("trash") + '</button><button class="btn pri" id="lok">حفظ — <bdi class="n" id="lt"></bdi></button></div>');
    var nu = null;
    function upd() { $("#lt", sh).textContent = fm((parseFloat($("#lq", sh).value) || 0) * (parseFloat($("#lpr", sh).value) || 0) - (parseFloat($("#ld", sh).value) || 0)); }
    bindStepper(sh, "lq", upd); $("#lpr", sh).oninput = upd; $("#ld", sh).oninput = upd; upd();
    $$(".unit", sh).forEach(function (b) { b.onclick = function () { nu = us.filter(function (x) { return x.id == b.dataset.u; })[0]; $$(".unit", sh).forEach(function (x) { x.classList.toggle("on", x === b); }); $("#lpr", sh).value = r2(priceOf(nu)); upd(); }; });
    $("#ldel", sh).onclick = function () { S.cart.splice(i, 1); saveCart(); closeSheet(); renderCart(); updateDock(); };
    $("#lok", sh).onclick = function () {
      var q = parseFloat($("#lq", sh).value) || 0; if (q <= 0) { S.cart.splice(i, 1); }
      else { l.q = r2(q); l.pr = r2(parseFloat($("#lpr", sh).value) || 0); l.d = r2(Math.max(0, parseFloat($("#ld", sh).value) || 0)); if (nu && nu.id !== l.puid) { l.puid = nu.id; l.un = nu.n; l.f = +nu.f || 1; l.sg = null; l.sgOn = false; l.sgOld = null; } }
      saveCart(); closeSheet(); renderCart(); updateDock(true);
    };
  }
  function discSheet() {
    var t = totals();
    var sh = sheet("خصم على الفاتورة", "المجموع بعد خصم الأصناف " + fm(t.sub - t.ld) + " " + CUR,
      '<div class="seg" id="dm"><button class="on" data-m="a">مبلغ</button><button data-m="p">نسبة %</button></div><span class="lbl">القيمة</span><input class="inp n" id="dv" inputmode="decimal" value="' + (S.disc ? r2(S.disc) : "") + '" placeholder="0">' +
      '<div class="notes">' + [5, 10, 15, 20].map(function (x) { return '<button class="note" data-pc="' + x + '">' + x + "%</button>"; }).join("") + "</div>",
      '<div class="act" style="margin:0"><button class="btn ghost" id="d0" style="flex:0 0 auto;padding:0 18px">إلغاء الخصم</button><button class="btn pri" id="dok">تطبيق</button></div>');
    var mode = "a";
    $$("#dm button", sh).forEach(function (b) { b.onclick = function () { mode = b.dataset.m; $$("#dm button", sh).forEach(function (x) { x.classList.toggle("on", x === b); }); }; });
    $$("[data-pc]", sh).forEach(function (b) { b.onclick = function () { mode = "p"; $$("#dm button", sh).forEach(function (x) { x.classList.toggle("on", x.dataset.m === "p"); }); $("#dv", sh).value = b.dataset.pc; }; });
    $("#d0", sh).onclick = function () { S.disc = 0; closeSheet(); renderCart(); updateDock(); };
    $("#dok", sh).onclick = function () {
      var v = parseFloat($("#dv", sh).value) || 0, base = t.sub - t.ld;
      S.disc = r2(Math.min(base, Math.max(0, mode === "p" ? base * v / 100 : v))); closeSheet(); renderCart(); updateDock(true);
    };
    setTimeout(function () { $("#dv", sh).focus(); }, 350);
  }
  function custSheet(after) {
    var B = BUY(), bk = B ? basket() : null, bs = {}; if (bk) bk.sups.forEach(function (x, i) { x.rank = i; bs[x.id] = x; });
    var sh = sheet(B ? "اختر المورد" : "اختر العميل", B && S.cart.length ? "🏆 يظهر عند كل مورد عدد أصناف سلتك التي يبيعها بأرخص سعر" : "ابحث بالاسم أو الهاتف",
      '<label class="fld" style="height:52px;box-shadow:none">' + ic("search") + '<input id="cq" type="search" placeholder="' + (B ? "اسم المورد أو الهاتف" : "اسم العميل أو الهاتف") + '" autocomplete="off"></label><div id="cl" style="margin-top:8px"></div>');
    var box = $("#cl", sh), t = 0;
    function row(c) {
      var tl = tile(c.n), x = bs[c.id];
      return '<button class="cl' + (S.cust && S.cust.id === c.id ? " on" : "") + '" data-c="' + c.id + '"><span class="ci" style="background:' + tl.bg + '">' + tl.ch + '</span><span class="tx"><b>' + esc(c.n) + "</b><small>" + esc(c.ph || "") +
        (x ? '</small><small class="cv">' + (x.win ? "🏆 الأرخص في " + x.win + " · " : "") + "يبيع " + x.cov + " من " + bk.n + " أصناف" + (x.rank === 0 && x.win ? ' <i class="tg">الأنسب</i>' : "") : "") + "</small></span>" +
        (!B && c.bal < -.004 ? '<span class="bl dbt"><small>عليه</small>' + N(-c.bal) + '<i data-col="' + c.id + '">سداد</i></span>' : B && c.bal > .004 ? '<span class="bl dbt sup"><small>له</small>' + N(c.bal) + '<i data-col="' + c.id + '">دفع</i></span>' : c.bal ? '<span class="bl" style="color:' + (c.bal > 0 ? "var(--warn)" : "var(--ok)") + '">' + N(c.bal) + "</span>" : "") + "</button>";
    }
    function load(q) {
      box.innerHTML = '<div class="sk" style="height:60px;margin:6px 0"></div><div class="sk" style="height:60px"></div>';
      api((B ? "/api/suppliers?q=" : "/api/customers?q=") + encodeURIComponent(q || "")).then(function (d) {
        var items = d.items || [];
        if (B && bk) items.sort(function (a, b) { var x = bs[a.id], y = bs[b.id]; return (x ? x.rank : 999) - (y ? y.rank : 999); });
        box.innerHTML = '<button class="cl' + (S.cust ? "" : " on") + '" data-c="0"><span class="ci" style="background:var(--tx)">' + ic("cash") + '</span><span class="tx"><b>' + (B ? "مورد نقدي" : "عميل نقدي") + "</b><small>بدون حساب — دفع فوري</small></span></button>" + items.map(row).join("") +
          (items.length ? "" : '<p style="text-align:center;color:var(--mu);font-size:13px">' + (B ? "لا يوجد مورد بهذا الاسم" : "لا يوجد عميل بهذا الاسم") + "</p>");
        $$("[data-col]", box).forEach(function (x) { x.onclick = function (e) { e.stopPropagation(); var id = +x.dataset.col, c = items.filter(function (y) { return y.id === id; })[0]; if (c) { buzz(10); if (B) paySupSheet({ id: c.id, n: c.n, ph: c.ph, bal: -c.bal, lim: 0 }); else collectSheet(c); } }; });
        $$(".cl", box).forEach(function (b) {
          b.onclick = function () {
            var id = +b.dataset.c; S.cust = id ? items.filter(function (c) { return c.id === id; })[0] : null; buzz(10);
            if (B && S.cust) { var n = applySup(id, false); if (n) toast("طُبّقت أسعار " + S.cust.n + " على " + n + (n === 1 ? " صنف" : " أصناف")); }
            saveCart();
            if (S.tab === "cart") renderCart(); else if (!B && S.tab === "pos") refreshCtx(); else if (B && S.tab === "pos") { var sb = $("#sbar"); if (sb) { sb.outerHTML = supBar(); $("#sbar").onclick = function () { custSheet(); }; } renderGrid(); }
            updateDock();
            if (typeof after === "function") { closeSheet(true, true); after(); } else closeSheet();
          };
        });
      }).catch(function () { box.innerHTML = '<p style="text-align:center;color:var(--bad)">تعذّر الاتصال بالبرنامج</p>'; });
    }
    $("#cq", sh).oninput = function () { var v = this.value; clearTimeout(t); t = setTimeout(function () { load(v); }, 260); };
    load("");
  }

  /* ------------------------------------------------------------ الدفع */
  function payload() {
    return {
      items: S.cart.map(function (l) { return { pid: l.pid, puid: l.puid, q: l.q, f: l.f, p: l.pr, d: l.d || 0, n: l.n }; }),
      customerId: S.cust ? S.cust.id : 0, disc: S.disc, note: S.note
    };
  }
  function paySheet(m0) {
    if (BUY()) { buyPaySheet(m0); return; }
    if (!S.cart.length) return;
    var loc = totals(), T = loc.total, verified = false, mode = typeof m0 === "string" ? m0 : "cash", recv = T;
    var sh = sheet("الدفع", esc(S.cust ? S.cust.n : "عميل نقدي") + " · " + S.cart.length + " صنف",
      '<div class="pay-tot"><small>المطلوب</small><b><bdi class="n" id="pT">' + fm(T) + "</bdi><small>" + CUR + '</small></b><span class="sv w" id="pv">جارٍ التحقق من الأسعار والخصومات …</span></div>' +
      '<div class="seg" id="pm">' + [["cash", "cash", "نقدي"], ["part", "split", "جزئي"], ["credit", "clock", "آجل"]].map(function (x) { return '<button' + (mode === x[0] ? ' class="on"' : "") + ' data-m="' + x[0] + '">' + ic(x[1]) + x[2] + "</button>"; }).join("") + "</div>" +
      '<div id="pr"><span class="lbl" id="rl">المبلغ المستلم من الزبون</span><input class="inp n" id="rv" inputmode="decimal"><div class="notes" id="nt"></div></div>' +
      '<div class="change" id="ch"><span id="chl">الباقي للزبون</span><b><bdi class="n" id="chv">0.00</bdi></b></div>' +
      (S.tr.length > 1 ? '<span class="lbl">الخزينة</span><select class="inp" id="tr" style="font-size:15px">' + S.tr.map(function (t) { return '<option value="' + t.id + '"' + (t.id === S.trId ? " selected" : "") + ">" + esc(t.n) + "</option>"; }).join("") + "</select>" : "") +
      '<span class="lbl">ملاحظة (اختياري)</span><textarea class="inp" id="nn" placeholder="مثال: توصيل للمنزل">' + esc(S.note) + "</textarea>",
      '<button class="btn ok" id="pok" style="width:100%">' + ic("check") + "<span>تأكيد البيع</span></button>");
    var rv = $("#rv", sh);
    function notes() {
      var set = [T]; [100, 200, 500, 1000, 2000, 5000].forEach(function (n) { var x = Math.ceil(T / n) * n; if (x > T && set.indexOf(x) < 0 && set.length < 5) set.push(x); });
      $("#nt", sh).innerHTML = set.map(function (x, i) { return '<button class="note' + (i ? "" : " ex") + '" data-v="' + x + '">' + (i ? fm(x, 0) : "المبلغ بالضبط") + "</button>"; }).join("");
      $$("#nt .note", sh).forEach(function (b) { b.onclick = function () { rv.value = r2(+b.dataset.v); buzz(8); upd(); }; });
    }
    function upd() {
      var v = parseFloat(rv.value); if (isNaN(v)) v = mode === "cash" ? T : 0; recv = Math.max(0, v);
      var ch = $("#ch", sh), paid = mode === "credit" ? 0 : Math.min(recv, T);
      $("#pr", sh).hidden = mode === "credit";
      $("#rl", sh).textContent = mode === "part" ? "المبلغ المدفوع الآن" : "المبلغ المستلم من الزبون";
      if (mode === "cash" && recv >= T) { ch.className = "change"; $("#chl", sh).textContent = "الباقي للزبون"; $("#chv", sh).textContent = fm(recv - T); }
      else { ch.className = "change due"; $("#chl", sh).textContent = "يُسجَّل على حساب العميل"; $("#chv", sh).textContent = fm(T - paid); }
      var need = T - paid > .004 && !S.cust, b = $("#pok", sh);
      b.innerHTML = need ? ic("user") + "<span>اختر العميل للبيع الآجل</span>" : ic("check") + "<span>تأكيد البيع</span>";
      b.className = need ? "btn pri" : "btn ok";
    }
    $$("#pm button", sh).forEach(function (b) {
      b.onclick = function () {
        mode = b.dataset.m; $$("#pm button", sh).forEach(function (x) { x.classList.toggle("on", x === b); }); buzz(8);
        rv.value = mode === "cash" ? "" : mode === "part" ? "" : ""; rv.placeholder = mode === "cash" ? fm(T) : "0.00"; upd();
        if (mode === "part") setTimeout(function () { rv.focus(); }, 80);
      };
    });
    rv.placeholder = fm(T); rv.oninput = upd; notes(); upd();
    /* المجموع الحقيقي من البرنامج (خصومات الكميات … ) */
    api("/api/calc", payload(), { timeout: 8000 }).then(function (d) {
      if (!d.ok) throw new Error(d.error);
      T = r2(d.total); verified = true; $("#pT", sh).textContent = fm(T);
      var pv = $("#pv", sh); pv.className = "sv"; pv.textContent = Math.abs(T - loc.total) > .004 ? "طُبّقت خصومات البرنامج: " + fm(loc.total - T) + " " + CUR : "✓ مطابق لأسعار البرنامج";
      if (Math.abs(T - loc.total) > .004 && d.lines) d.lines.forEach(function (x, i) { if (S.cart[i] && x.d > (S.cart[i].d || 0)) S.cart[i].d = r2(x.d); });
      rv.placeholder = fm(T); notes(); upd();
    }).catch(function (e) { var pv = $("#pv", sh); if (pv) { pv.textContent = e.net ? "بدون اتصال — سيُرسل البيع عند عودة الاتصال" : (e.message || "تعذّر التحقق"); } });
    $("#pok", sh).onclick = function () {
      var paid = mode === "credit" ? 0 : Math.min(recv, T);
      if (T - paid > .004 && !S.cust) { custSheet(function () { paySheet(mode); }); return; }
      var tr = $("#tr", sh); if (tr) { S.trId = +tr.value; LS.set("trId", S.trId); }
      S.note = $("#nn", sh).value.trim();
      var b = this; b.disabled = true; b.innerHTML = '<i class="spin"></i>';
      var body = payload(); body.cid = uid(); body.paid = r2(paid); body.treasuryId = S.trId; body.cname = S.cust ? S.cust.n : "";
      var snap = { cart: JSON.parse(JSON.stringify(S.cart)), cust: S.cust, disc: S.disc, total: T, paid: paid, recv: mode === "cash" ? recv : paid, at: new Date() };
      api("/api/sale", body, { timeout: 20000 }).then(function (d) {
        if (!d.ok) throw new Error(d.error || "تعذّر الحفظ");
        closeSheet(true, true); beep(); buzz([20, 50, 30]); if (d.queued) done(snap, null, "cloud"); else done(snap, d, false); refreshStock(1500);
      }).catch(function (e) {
        if (e.net) { S.queue.push({ body: body, snap: { total: T, paid: paid, cust: S.cust ? S.cust.n : "", n: S.cart.length }, at: Date.now() }); LS.set("queue", S.queue); closeSheet(true, true); done(snap, null, true); return; }
        b.disabled = false; upd(); beep(false); buzz([40, 40, 40]); toast(e.message, "bad");
      });
    };
  }
  function done(snap, d, pending) {
    var B = !!snap.buy;
    S.cart = []; S.cust = null; S.disc = 0; S.note = ""; saveCart(); updateDock();
    var el = document.createElement("div"); el.className = "done";
    var rec = '<div class="rcpt"><div class="h"><b>' + esc(S.company) + "</b><small>" + (B ? "شراء" + (snap.cust ? " من " + esc(snap.cust.n) : "") + " · " : "") + (d ? "فاتورة رقم <bdi class=n>" + esc(d.no) + "</bdi> · " : "") + '<bdi class="n">' + snap.at.toLocaleDateString("en-GB") + " " + snap.at.toTimeString().slice(0, 5) + "</bdi></small></div>" +
      snap.cart.map(function (l, i) { var sv = d && d.lines && d.lines[i]; if (sv) { l.n = sv.n; l.un = sv.u; } return '<div class="l"><span>' + esc(l.n) + "<small>" + fq(l.q) + " " + esc(l.un) + " × " + fm(l.pr) + "</small></span><b>" + N(l.q * l.pr - (l.d || 0)) + "</b></div>"; }).join("") +
      '<div class="t">' + (snap.disc ? "<div><span>خصم</span><b>- " + N(snap.disc) + "</b></div>" : "") +
      '<div class="g"><span>الإجمالي</span><b>' + N(d ? d.total : snap.total) + " " + CUR + "</b></div>" +
      "<div><span>المدفوع</span><b>" + N(d ? d.paid : snap.paid) + "</b></div>" +
      (!B && snap.recv > snap.paid ? "<div><span>الباقي للزبون</span><b>" + N(snap.recv - snap.paid) + "</b></div>" : "") +
      ((d ? d.remaining : snap.total - snap.paid) > .004 ? "<div><span>" + (B ? "لحساب المورد " : "على حساب ") + esc(snap.cust ? snap.cust.n : "") + "</span><b>" + N(d ? d.remaining : snap.total - snap.paid) + "</b></div>" : "") + "</div></div>";
    var CLP = pending === "cloud";
    el.innerHTML = '<div class="ck' + (CLP ? " pn cld" : pending ? " pn" : "") + '">' + ic(CLP ? "cloud" : pending ? "clock" : "check") + "</div>" +
      "<h2>" + (CLP ? "محفوظ في السحابة" : pending ? "محفوظ في الانتظار" : B ? "تم الشراء بنجاح" : "تم البيع بنجاح") + '</h2><p class="s">' + (CLP ? "الجهاز مقفول الآن — تُسجَّل الفاتورة في ANOUER وحدها عند تشغيله (المخزون والخزينة وحساب " + (B ? "المورد" : "العميل") + ")" : pending ? (CLOUD ? "لا يوجد إنترنت الآن — يُرسل تلقائياً عند عودة الاتصال" : "لا يوجد اتصال الآن — سيُرسل للبرنامج تلقائياً عند عودة الواي فاي") : B ? "سُجّلت فاتورة الشراء في ANOUER: المخزون والتكلفة وحساب المورد" : "سُجّلت الفاتورة في ANOUER: المخزون والخزينة") + "</p>" + rec +
      '<div class="act"><button class="btn ghost" id="shr">' + ic("share") + "<span>مشاركة</span></button><button class=\"btn pri\" id=\"nw\">" + ic("plus") + "<span>" + (B ? "شراء جديد" : "بيع جديد") + "</span></button></div>";
    document.body.appendChild(el);
    if (sheet._h) { sheet._h = false; history.replaceState({ done: 1 }, ""); } else history.pushState({ done: 1 }, "");
    $("#nw", el).onclick = function () { history.back(); };
    $("#shr", el).onclick = function () {
      var lines = [S.company, B ? "فاتورة شراء" + (snap.cust ? " — " + snap.cust.n : "") : "", d ? "فاتورة رقم " + d.no : "", snap.at.toLocaleString("en-GB"), "—————"].concat(snap.cart.map(function (l) { return l.n + "  " + fq(l.q) + " × " + fm(l.pr) + " = " + fm(l.q * l.pr - (l.d || 0)); }))
        .concat(["—————", "الإجمالي: " + fm(d ? d.total : snap.total) + " " + CUR, "المدفوع: " + fm(d ? d.paid : snap.paid), B ? "" : "شكراً لزيارتكم 🌟"]).filter(Boolean).join("\n");
      if (navigator.share) navigator.share({ text: lines }).catch(function () { });
      else location.href = "https://wa.me/?text=" + encodeURIComponent(lines);
    };
    if (pending) { var a = $(".top-r .av"); if (a) a.className = "av wait"; }
  }
  function newSale() { var d = $(".done"); if (d) { d.remove(); go("pos"); } }

  /* طابور البيع بدون اتصال */
  var flushing = false;
  function flush() {
    if (flushing || !S.queue.length || !S.sid) return; flushing = true;
    var it = S.queue[0];
    api(it.ep || "/api/sale", it.body, { timeout: 20000 }).then(function (d) {
      flushing = false; var w = it.ep === "/api/purchase" ? "شراء" : it.ep === "/api/collect" ? "تحصيل" : it.ep === "/api/paysup" ? "دفع لمورد" : "بيع";
      if (!d.ok) { it.err = d.error; LS.set("queue", S.queue); toast(w + " في الانتظار رُفض: " + d.error, "bad"); return; }
      S.queue.shift(); LS.set("queue", S.queue); toast(d.queued ? "☁ " + w + " الانتظار وصل للسحابة — يُسجَّل عند تشغيل الجهاز" : "أُرسل " + w + " الانتظار — " + (it.ep === "/api/collect" || it.ep === "/api/paysup" ? "سند " : "فاتورة ") + d.no);
      var a = $(".top-r .av"); if (a) a.className = avCls(); var sm = $("#netl"); if (sm) sm.textContent = netLabel();
      if (S.tab === "sales") renderSales();
      flush();
    }, function () { flushing = false; });
  }
  setInterval(function () { if (S.sid && !document.hidden) api("/api/ping", null, { timeout: 5000 }).then(flush, function () { }); }, 20000);
  window.addEventListener("online", function () { setTimeout(flush, 800); });
  if (CLOUD && "serviceWorker" in navigator) window.addEventListener("load", function () { navigator.serviceWorker.register(BASE + "/sw.js", { scope: BASE + "/" }).catch(function () { }); });
  if (CLOUD && S.pc === false) document.documentElement.classList.add("pcoff");
  document.addEventListener("visibilitychange", function () { if (!document.hidden && S.sid) api("/api/ping", null, { timeout: 5000 }).then(flush, function () { }); });

  /* ------------------------------------------------------------ تحصيل الديون (سند «استلام نقدية» في ANOUER) */
  function debtOf(c) { return Math.max(0, -(+(c && c.bal) || 0)); }
  function ageCls(d) { return d == null || d < 0 ? "" : d <= 30 ? "a1" : d <= 60 ? "a2" : "a3"; }
  function ageTxt(d) { return d == null || d < 0 ? "" : d === 0 ? "اليوم" : d === 1 ? "منذ يوم" : d === 2 ? "منذ يومين" : d <= 10 ? "منذ " + d + " أيام" : "منذ " + d + " يوم"; }
  function debtorsSheet() {
    var sh = sheet("تحصيل دين", "العملاء الذين عليهم ديون — الأكبر أولاً",
      '<div id="dsum" class="dsum"><div class="sk" style="height:84px;border-radius:20px"></div></div>' +
      '<label class="fld" style="height:52px;box-shadow:none;margin-top:12px">' + ic("search") + '<input id="dq" type="search" placeholder="اسم العميل أو الهاتف" autocomplete="off"></label><div id="dl" style="margin-top:8px"></div>');
    var box = $("#dl", sh), t = 0;
    function load(q) {
      box.innerHTML = '<div class="sk" style="height:66px;margin:6px 0"></div><div class="sk" style="height:66px"></div>';
      api("/api/debtors?q=" + encodeURIComponent(q || "")).then(function (d) {
        if (!d.ok) throw new Error(d.error);
        var items = d.items || [], mx = items.reduce(function (a, c) { return Math.max(a, debtOf(c)); }, 0) || 1;
        if (!q) $("#dsum", sh).innerHTML = '<div class="dsum-c"><div><small>إجمالي الديون عند العملاء</small><b><bdi class="n">' + fm(d.total || 0) + "</bdi> <small>" + CUR + '</small></b></div><span class="dsum-n"><b>' + (d.n || 0) + "</b><small>عميل</small></span></div>" + (d.pc === false ? '<p class="dsum-off">' + ic("cloud") + "الجهاز مقفول — الأرصدة من آخر نسخة ، والتحصيل يُسجَّل عند تشغيله</p>" : "");
        box.innerHTML = items.length ? items.map(function (c, i) {
          var tl = tile(c.n), db = debtOf(c), over = c.lim > 0 && db > c.lim;
          return '<button class="dbr" data-i="' + i + '" style="animation-delay:' + Math.min(i, 12) * 30 + 'ms"><span class="ci" style="background:' + tl.bg + '">' + tl.ch + '</span><span class="tx"><b>' + esc(c.n) + "</b><small>" +
            (c.days >= 0 ? '<i class="ag ' + ageCls(c.days) + '">' + ageTxt(c.days) + "</i>" : "") + (c.inv ? c.inv + (c.inv === 1 ? " فاتورة" : " فواتير") : "") + (c.ph ? ' · <bdi>' + esc(c.ph) + "</bdi>" : "") + (over ? ' · <i class="ag a3">فوق السقف</i>' : "") +
            '</small><span class="bar"><i style="width:' + Math.max(4, Math.round(db / mx * 100)) + '%"></i></span></span><span class="am"><b>' + N(db) + "</b><small>عليه</small></span></button>";
        }).join("") : empty("check", q ? "لا يوجد عميل مدين بهذا الاسم" : "لا توجد ديون 🎉", q ? "جرّب اسماً آخر أو رقم الهاتف" : "كل العملاء مسدّدون");
        $$(".dbr", box).forEach(function (b) { b.onclick = function () { buzz(10); collectSheet(items[+b.dataset.i]); }; });
      }).catch(function (e) { box.innerHTML = '<p style="text-align:center;color:var(--bad);font-size:13px">' + (e.net ? (CLOUD ? "لا يوجد إنترنت" : "تعذّر الاتصال بالبرنامج") : esc(e.message)) + "</p>"; });
    }
    $("#dq", sh).oninput = function () { var v = this.value; clearTimeout(t); t = setTimeout(function () { load(v); }, 260); };
    load("");
  }

  function collectSheet(c) {
    var D0 = debtOf(c), dues = null, amt = 0, disc = 0, busy = false, C = 2 * Math.PI * 52;
    var tl = tile(c.n);
    var sh = sheet("تحصيل دين", '<span class="clc-who"><span class="ci" style="background:' + tl.bg + '">' + tl.ch + "</span>" + esc(c.n) + (c.ph ? ' · <bdi>' + esc(c.ph) + "</bdi>" : "") + "</span>",
      '<div class="clc-hero"><div class="ring"><svg viewBox="0 0 120 120"><circle class="tr" cx="60" cy="60" r="52"/><circle class="pr" id="rg" cx="60" cy="60" r="52" style="stroke-dasharray:' + C + ";stroke-dashoffset:" + C + '"/></svg>' +
      '<div class="rv"><small id="rl">عليه الآن</small><b><bdi class="n" id="rb">' + fm(D0) + '</bdi></b><small id="rs">' + CUR + "</small></div></div>" +
      '<div class="clc-side"><div><small>الدين</small><b><bdi class="n">' + fm(D0) + '</bdi></b></div><div class="pd"><small>يدفع الآن</small><b><bdi class="n" id="sp">0.00</bdi></b></div><div class="rm"><small>يبقى عليه</small><b><bdi class="n" id="sr">' + fm(D0) + "</bdi></b></div></div></div>" +
      '<span class="lbl">المبلغ المستلم</span><input class="inp n clc-in" id="ca" inputmode="decimal" placeholder="0.00" autocomplete="off"><div class="notes" id="cq"></div>' +
      '<div class="clc-x" id="cx"></div>' +
      '<button class="clc-dt" id="dtg" type="button">' + ic("tag") + "<span>خصم / مسامحة (اختياري)</span></button>" +
      '<div id="dw" hidden><input class="inp n" id="cdi" inputmode="decimal" placeholder="مبلغ يُسامَح فيه — بدون دخول الخزينة"></div>' +
      '<div class="grp"><span>الفواتير المفتوحة · الأقدم يُسدَّد أولاً</span><span id="dn"></span></div><div class="card dues" id="du"><div class="sk" style="height:56px;border-radius:0"></div><div class="sk" style="height:56px;border-radius:0"></div></div>' +
      (S.tr.length > 1 ? '<span class="lbl">الخزينة</span><select class="inp" id="ctr" style="font-size:15px">' + S.tr.map(function (t) { return '<option value="' + t.id + '"' + (t.id === S.trId ? " selected" : "") + ">" + esc(t.n) + "</option>"; }).join("") + "</select>" : "") +
      '<span class="lbl">ملاحظة (اختياري)</span><textarea class="inp" id="cnn" placeholder="مثال: دفعة على الحساب"></textarea>',
      '<button class="btn ok" id="cok" style="width:100%" disabled>' + ic("check") + "<span>أدخل المبلغ</span></button>");
    var inp = $("#ca", sh);
    function chips() {
      var set = [["الدين كاملاً", D0, "ex"]];
      if (dues && dues.length > 1 && dues[0].rem < D0 - .004) set.push(["الفاتورة الأقدم", +dues[0].rem]);
      if (D0 >= 400) set.push(["النصف", Math.round(D0 / 2)]);
      [500, 1000, 2000, 5000, 10000, 20000].forEach(function (n) { if (n < D0 * .85 && set.length < 5 && !set.some(function (x) { return Math.abs(x[1] - n) < 1; })) set.push([fm(n, 0), n]); });
      $("#cq", sh).innerHTML = D0 > 0 ? set.map(function (x) { return '<button class="note' + (x[2] ? " ex" : "") + '" data-v="' + x[1] + '">' + x[0] + "</button>"; }).join("") : "";
      $$("#cq .note", sh).forEach(function (b) { b.onclick = function () { inp.value = r2(+b.dataset.v); buzz(8); upd(); }; });
    }
    function plan() {   /* نفس تسوية البرنامج: الأقدم أولاً */
      var left = amt + disc;
      return (dues || []).map(function (d) { var a = Math.max(0, Math.min(+d.rem, left)); left -= a; return { d: d, a: r2(a), full: a >= d.rem - .004 && a > 0 }; });
    }
    function paintDues() {
      var box = $("#du", sh); if (!dues) return;
      $("#dn", sh).textContent = dues.length ? dues.length : "";
      if (!dues.length) { box.innerHTML = '<div class="due none">' + ic("receipt") + "<span>" + (D0 > 0 ? "الدين رصيد سابق أو افتتاحي — بدون فواتير مفتوحة" : "لا توجد فواتير مفتوحة") + "</span></div>"; return; }
      box.innerHTML = plan().map(function (x) {
        var d = x.d, st = x.full ? " full" : x.a > 0 ? " part" : "";
        return '<div class="due' + st + '"><span class="ck">' + ic(x.full ? "check" : "receipt") + '</span><span class="tx"><b>فاتورة <bdi class="n">' + esc(d.no) + "</bdi></b><small><bdi class=\"n\">" + esc(d.date) + "</bdi> · " + '<i class="ag ' + ageCls(d.days) + '">' + ageTxt(d.days) + "</i></small>" +
          (x.a > 0 && !x.full ? '<span class="bar"><i style="width:' + Math.round(x.a / d.rem * 100) + '%"></i></span>' : "") + '</span><span class="am"><b>' + N(d.rem) + "</b>" +
          (x.full ? "<small>تُسدَّد ✓</small>" : x.a > 0 ? "<small>−" + fm(x.a) + "</small>" : "<small>من " + fm(d.total) + "</small>") + "</span></div>";
      }).join("");
    }
    function upd() {
      var v = parseFloat(String(inp.value).replace(",", ".")); amt = isNaN(v) ? 0 : r2(Math.max(0, v));
      var dv = parseFloat(String(($("#cdi", sh) || {}).value || "").replace(",", ".")); disc = isNaN(dv) ? 0 : r2(Math.max(0, dv));
      var paid = amt + disc, after = D0 - paid, p = D0 > 0 ? Math.min(1, paid / D0) : (paid > 0 ? 1 : 0);
      $("#rg", sh).style.strokeDashoffset = C * (1 - p);
      sh.querySelector(".clc-hero").classList.toggle("zero", paid > 0 && after <= .004);
      $("#rl", sh).textContent = paid > 0 ? (after <= .004 ? (after < -.004 ? "رصيد له" : "سُدّد بالكامل") : "يبقى عليه") : "عليه الآن";
      $("#rb", sh).textContent = fm(paid > 0 ? Math.abs(after) : D0);
      $("#rs", sh).textContent = paid > 0 && after <= .004 && after >= -.004 ? "🎉" : CUR;
      $("#sp", sh).textContent = fm(amt); $("#sr", sh).textContent = fm(Math.max(0, after));
      var x = $("#cx", sh);
      x.className = "clc-x" + (after < -.004 ? " warn" : disc > 0 && paid > 0 ? " info" : "");
      x.innerHTML = after < -.004 ? ic("clock") + "<span>المبلغ أكبر من الدين بـ <b>" + fm(-after) + "</b> — يُسجَّل رصيداً للعميل (له)</span>" : disc > 0 && paid > 0 ? ic("tag") + "<span>خصم <b>" + fm(disc) + "</b> يُنقص الدين بدون دخول الخزينة</span>" : "";
      paintDues();
      var b = $("#cok", sh);
      b.disabled = busy || paid <= 0;
      b.innerHTML = paid <= 0 ? ic("check") + "<span>أدخل المبلغ</span>" : ic("check") + '<span>تأكيد استلام <bdi class="n">' + fm(amt) + "</bdi> " + CUR + "</span>";
    }
    inp.oninput = upd;
    $("#dtg", sh).onclick = function () { var w = $("#dw", sh); w.hidden = !w.hidden; this.classList.toggle("on", !w.hidden); if (!w.hidden) setTimeout(function () { $("#cdi", sh).focus(); }, 60); else { $("#cdi", sh).value = ""; upd(); } };
    $("#cdi", sh).oninput = upd;
    chips(); upd(); setTimeout(function () { inp.focus(); }, 320);
    api("/api/dues?id=" + c.id).then(function (d) {
      if (!d.ok) throw new Error(d.error);
      dues = d.items || [];
      if (typeof d.bal === "number" && d.pc !== false) { D0 = Math.max(0, -d.bal); sh.querySelector(".clc-side b bdi").textContent = fm(D0); }
      chips(); upd();
    }).catch(function (e) { dues = []; $("#du", sh).innerHTML = '<div class="due none">' + ic("cloud") + "<span>" + (e.net ? "بدون اتصال — تُسوّى الفواتير عند التسجيل في ANOUER" : esc(e.message)) + "</span></div>"; });
    $("#cok", sh).onclick = function () {
      if (busy || amt + disc <= 0) return;
      var tr = $("#ctr", sh); if (tr) { S.trId = +tr.value; LS.set("trId", S.trId); }
      busy = true; var b = this; b.disabled = true; b.innerHTML = '<i class="spin"></i>';
      var body = { customerId: c.id, amount: amt, disc: disc, treasuryId: S.trId, note: $("#cnn", sh).value.trim(), cid: uid(), cname: c.n };
      var snap = { c: c, before: D0, amount: amt, disc: disc, plan: plan(), at: new Date() };
      api("/api/collect", body, { timeout: 20000 }).then(function (d) {
        if (!d.ok) throw new Error(d.error || "تعذّر التسجيل");
        closeSheet(true, true); beep(); buzz([20, 50, 30]); collectDone(snap, d.queued ? null : d, d.queued ? "cloud" : false);
      }).catch(function (e) {
        if (e.net) { S.queue.push({ ep: "/api/collect", body: body, snap: { total: amt, paid: amt, cust: c.n, n: 0, col: true }, at: Date.now() }); LS.set("queue", S.queue); closeSheet(true, true); collectDone(snap, null, true); return; }
        busy = false; upd(); beep(false); buzz([40, 40, 40]); toast(e.message, "bad");
      });
    };
  }

  function collectDone(snap, d, pending) {
    var CLP = pending === "cloud", c = snap.c, after = d ? d.after : Math.max(0, snap.before - snap.amount - snap.disc), credit = d ? d.credit : Math.max(0, snap.amount + snap.disc - snap.before);
    var al = d && d.alloc ? d.alloc.map(function (a) { return { no: a.no, a: +a.amt, full: !!a.full }; }) : snap.plan.filter(function (x) { return x.a > 0; }).map(function (x) { return { no: x.d.no, a: x.a, full: x.full }; });
    var el = document.createElement("div"); el.className = "done col";
    var rec = '<div class="rcpt"><div class="h"><b>' + esc(S.company) + "</b><small>وصل استلام نقدية" + (d && d.no ? ' رقم <bdi class="n">' + esc(d.no) + "</bdi>" : "") + ' · <bdi class="n">' + snap.at.toLocaleDateString("en-GB") + " " + snap.at.toTimeString().slice(0, 5) + "</bdi></small></div>" +
      '<div class="l"><span>استلمنا من<small>' + esc(c.ph || "") + "</small></span><b>" + esc(c.n) + "</b></div>" +
      '<div class="t"><div><span>الدين قبل</span><b>' + N(snap.before) + "</b></div>" +
      '<div class="g"><span>المبلغ المستلم</span><b>' + N(snap.amount) + " " + CUR + "</b></div>" +
      (snap.disc ? "<div><span>خصم / مسامحة</span><b>" + N(snap.disc) + "</b></div>" : "") +
      (credit > .004 ? '<div class="ok"><span>رصيد للعميل (له)</span><b>' + N(credit) + "</b></div>" : '<div class="' + (after <= .004 ? "ok" : "") + '"><span>' + (after <= .004 ? "الحساب مسدّد بالكامل ✓" : "يبقى عليه") + "</span><b>" + N(after) + "</b></div>") + "</div>" +
      (al.length ? '<div class="al">' + al.map(function (a) { return '<span class="' + (a.full ? "f" : "") + '">' + (a.full ? "✓ " : "") + "فاتورة " + esc(a.no) + " · " + fm(a.a) + "</span>"; }).join("") + "</div>" : "") + "</div>";
    el.innerHTML = '<div class="ck' + (CLP ? " pn cld" : pending ? " pn" : " col") + '">' + ic(CLP ? "cloud" : pending ? "clock" : "cash") + "</div>" +
      "<h2>" + (CLP ? "محفوظ في السحابة" : pending ? "محفوظ في الانتظار" : after <= .004 && credit <= .004 ? "سُدّد الدين بالكامل 🎉" : "تم التحصيل بنجاح") + '</h2><p class="s">' +
      (CLP ? "الجهاز مقفول — يُسجَّل السند في ANOUER وحده عند تشغيله" : pending ? (CLOUD ? "لا يوجد إنترنت الآن — يُرسل تلقائياً عند عودة الاتصال" : "لا يوجد اتصال الآن — يُرسل للبرنامج عند عودة الواي فاي") : "سُجّل سند استلام نقدية في ANOUER: الخزينة وحساب العميل والفواتير") + "</p>" + rec +
      '<div class="act">' + (c.ph ? '<button class="btn wa" id="cwa">' + ic("share") + "<span>واتساب للعميل</span></button>" : '<button class="btn ghost" id="cwa">' + ic("share") + "<span>مشاركة الوصل</span></button>") + '<button class="btn pri" id="cnw">' + ic("check") + "<span>تم</span></button></div>";
    document.body.appendChild(el);
    if (sheet._h) { sheet._h = false; history.replaceState({ done: 1 }, ""); } else history.pushState({ done: 1 }, "");
    $("#cnw", el).onclick = function () { history.back(); };
    $("#cwa", el).onclick = function () {
      var txt = ["السلام عليكم " + c.n + " 👋", "شكراً على تسديدك — " + S.company, "", "🧾 وصل استلام" + (d && d.no ? " رقم " + d.no : ""), "📅 " + snap.at.toLocaleString("en-GB").slice(0, 17),
        "💵 المبلغ المستلم: " + fm(snap.amount) + " " + CUR].concat(snap.disc ? ["🎁 خصم: " + fm(snap.disc) + " " + CUR] : [])
        .concat([credit > .004 ? "✅ رصيدك عندنا: " + fm(credit) + " " + CUR : after <= .004 ? "✅ حسابك مسدّد بالكامل" : "📌 المتبقي عليك: " + fm(after) + " " + CUR, "", "نتشرف بخدمتك دائماً 🌟"]).join("\n");
      var w = waNum(c.ph);
      if (w) location.href = "https://wa.me/" + w + "?text=" + encodeURIComponent(txt);
      else if (navigator.share) navigator.share({ text: txt }).catch(function () { });
      else location.href = "https://wa.me/?text=" + encodeURIComponent(txt);
    };
    if (pending) { var a = $(".top-r .av"); if (a) a.className = avCls(); }
  }

  /* ------------------------------------------------------------ دفع مستحقات الموردين (سند «دفع نقدية» في ANOUER) — نفس واجهة التحصيل */
  function creditorsSheet() {
    var sh = sheet("دفع لمورد", "الموردون الذين لهم مستحقات عندك — الأكبر أولاً",
      '<div id="dsum" class="dsum"><div class="sk" style="height:84px;border-radius:20px"></div></div>' +
      '<label class="fld" style="height:52px;box-shadow:none;margin-top:12px">' + ic("search") + '<input id="dq" type="search" placeholder="اسم المورد أو الهاتف" autocomplete="off"></label><div id="dl" style="margin-top:8px"></div>');
    var box = $("#dl", sh), t = 0; sh.classList.add("sup");
    function load(q) {
      box.innerHTML = '<div class="sk" style="height:66px;margin:6px 0"></div><div class="sk" style="height:66px"></div>';
      api("/api/creditors?q=" + encodeURIComponent(q || "")).then(function (d) {
        if (!d.ok) throw new Error(d.error);
        var items = d.items || [], mx = items.reduce(function (a, c) { return Math.max(a, debtOf(c)); }, 0) || 1;
        if (!q) $("#dsum", sh).innerHTML = '<div class="dsum-c"><div><small>إجمالي المستحقات للموردين</small><b><bdi class="n">' + fm(d.total || 0) + "</bdi> <small>" + CUR + '</small></b></div><span class="dsum-n"><b>' + (d.n || 0) + "</b><small>مورد</small></span></div>" + (d.pc === false ? '<p class="dsum-off">' + ic("cloud") + "الجهاز مقفول — الأرصدة من آخر نسخة ، والدفع يُسجَّل عند تشغيله</p>" : "");
        box.innerHTML = items.length ? items.map(function (c, i) {
          var tl = tile(c.n), db = debtOf(c), over = c.lim > 0 && db > c.lim;
          return '<button class="dbr" data-i="' + i + '" style="animation-delay:' + Math.min(i, 12) * 30 + 'ms"><span class="ci" style="background:' + tl.bg + '">' + tl.ch + '</span><span class="tx"><b>' + esc(c.n) + "</b><small>" +
            (c.days >= 0 ? '<i class="ag ' + ageCls(c.days) + '">' + ageTxt(c.days) + "</i>" : "") + (c.inv ? c.inv + (c.inv === 1 ? " فاتورة" : " فواتير") : "") + (c.ph ? ' · <bdi>' + esc(c.ph) + "</bdi>" : "") + (over ? ' · <i class="ag a3">فوق السقف</i>' : "") +
            '</small><span class="bar"><i style="width:' + Math.max(4, Math.round(db / mx * 100)) + '%"></i></span></span><span class="am"><b>' + N(db) + "</b><small>له</small></span></button>";
        }).join("") : empty("check", q ? "لا يوجد مورد بهذا الاسم" : "لا توجد مستحقات للموردين 🎉", q ? "جرّب اسماً آخر أو رقم الهاتف" : "كل الموردين مسدّدون");
        $$(".dbr", box).forEach(function (b) { b.onclick = function () { buzz(10); paySupSheet(items[+b.dataset.i]); }; });
      }).catch(function (e) { box.innerHTML = '<p style="text-align:center;color:var(--bad);font-size:13px">' + (e.net ? (CLOUD ? "لا يوجد إنترنت" : "تعذّر الاتصال بالبرنامج") : esc(e.message)) + "</p>"; });
    }
    $("#dq", sh).oninput = function () { var v = this.value; clearTimeout(t); t = setTimeout(function () { load(v); }, 260); };
    load("");
  }

  function paySupSheet(c) {
    var D0 = debtOf(c), dues = null, amt = 0, disc = 0, busy = false, C = 2 * Math.PI * 52;
    var tl = tile(c.n);
    var sh = sheet("دفع لمورد", '<span class="clc-who"><span class="ci" style="background:' + tl.bg + '">' + tl.ch + "</span>" + esc(c.n) + (c.ph ? ' · <bdi>' + esc(c.ph) + "</bdi>" : "") + "</span>",
      '<div class="clc-hero"><div class="ring"><svg viewBox="0 0 120 120"><circle class="tr" cx="60" cy="60" r="52"/><circle class="pr" id="rg" cx="60" cy="60" r="52" style="stroke-dasharray:' + C + ";stroke-dashoffset:" + C + '"/></svg>' +
      '<div class="rv"><small id="rl">له الآن</small><b><bdi class="n" id="rb">' + fm(D0) + '</bdi></b><small id="rs">' + CUR + "</small></div></div>" +
      '<div class="clc-side"><div><small>المستحق</small><b><bdi class="n">' + fm(D0) + '</bdi></b></div><div class="pd"><small>تدفع الآن</small><b><bdi class="n" id="sp">0.00</bdi></b></div><div class="rm"><small>يبقى له</small><b><bdi class="n" id="sr">' + fm(D0) + "</bdi></b></div></div></div>" +
      '<span class="lbl">المبلغ المدفوع للمورد</span><input class="inp n clc-in" id="ca" inputmode="decimal" placeholder="0.00" autocomplete="off"><div class="notes" id="cq"></div>' +
      '<div class="clc-x" id="cx"></div>' +
      '<button class="clc-dt" id="dtg" type="button">' + ic("tag") + "<span>خصم / مسامحة (اختياري)</span></button>" +
      '<div id="dw" hidden><input class="inp n" id="cdi" inputmode="decimal" placeholder="مبلغ يُسامَح فيه — بدون دخول الخزينة"></div>' +
      '<div class="grp"><span>الفواتير المفتوحة · الأقدم يُسدَّد أولاً</span><span id="dn"></span></div><div class="card dues" id="du"><div class="sk" style="height:56px;border-radius:0"></div><div class="sk" style="height:56px;border-radius:0"></div></div>' +
      (S.tr.length > 1 ? '<span class="lbl">الخزينة</span><select class="inp" id="ctr" style="font-size:15px">' + S.tr.map(function (t) { return '<option value="' + t.id + '"' + (t.id === S.trId ? " selected" : "") + ">" + esc(t.n) + "</option>"; }).join("") + "</select>" : "") +
      '<span class="lbl">ملاحظة (اختياري)</span><textarea class="inp" id="cnn" placeholder="مثال: دفعة على الحساب"></textarea>',
      '<button class="btn ok" id="cok" style="width:100%" disabled>' + ic("check") + "<span>أدخل المبلغ</span></button>");
    var inp = $("#ca", sh); sh.classList.add("sup");
    function chips() {
      var set = [["المستحق كاملاً", D0, "ex"]];
      if (dues && dues.length > 1 && dues[0].rem < D0 - .004) set.push(["الفاتورة الأقدم", +dues[0].rem]);
      if (D0 >= 400) set.push(["النصف", Math.round(D0 / 2)]);
      [500, 1000, 2000, 5000, 10000, 20000].forEach(function (n) { if (n < D0 * .85 && set.length < 5 && !set.some(function (x) { return Math.abs(x[1] - n) < 1; })) set.push([fm(n, 0), n]); });
      $("#cq", sh).innerHTML = D0 > 0 ? set.map(function (x) { return '<button class="note' + (x[2] ? " ex" : "") + '" data-v="' + x[1] + '">' + x[0] + "</button>"; }).join("") : "";
      $$("#cq .note", sh).forEach(function (b) { b.onclick = function () { inp.value = r2(+b.dataset.v); buzz(8); upd(); }; });
    }
    function plan() {   /* نفس تسوية البرنامج: الأقدم أولاً */
      var left = amt + disc;
      return (dues || []).map(function (d) { var a = Math.max(0, Math.min(+d.rem, left)); left -= a; return { d: d, a: r2(a), full: a >= d.rem - .004 && a > 0 }; });
    }
    function paintDues() {
      var box = $("#du", sh); if (!dues) return;
      $("#dn", sh).textContent = dues.length ? dues.length : "";
      if (!dues.length) { box.innerHTML = '<div class="due none">' + ic("receipt") + "<span>" + (D0 > 0 ? "المستحق رصيد سابق أو افتتاحي — بدون فواتير مشتريات مفتوحة" : "لا توجد فواتير مفتوحة") + "</span></div>"; return; }
      box.innerHTML = plan().map(function (x) {
        var d = x.d, st = x.full ? " full" : x.a > 0 ? " part" : "";
        return '<div class="due' + st + '"><span class="ck">' + ic(x.full ? "check" : "receipt") + '</span><span class="tx"><b>فاتورة <bdi class="n">' + esc(d.no) + "</bdi></b><small><bdi class=\"n\">" + esc(d.date) + "</bdi> · " + '<i class="ag ' + ageCls(d.days) + '">' + ageTxt(d.days) + "</i></small>" +
          (x.a > 0 && !x.full ? '<span class="bar"><i style="width:' + Math.round(x.a / d.rem * 100) + '%"></i></span>' : "") + '</span><span class="am"><b>' + N(d.rem) + "</b>" +
          (x.full ? "<small>تُسدَّد ✓</small>" : x.a > 0 ? "<small>−" + fm(x.a) + "</small>" : "<small>من " + fm(d.total) + "</small>") + "</span></div>";
      }).join("");
    }
    function upd() {
      var v = parseFloat(String(inp.value).replace(",", ".")); amt = isNaN(v) ? 0 : r2(Math.max(0, v));
      var dv = parseFloat(String(($("#cdi", sh) || {}).value || "").replace(",", ".")); disc = isNaN(dv) ? 0 : r2(Math.max(0, dv));
      var paid = amt + disc, after = D0 - paid, p = D0 > 0 ? Math.min(1, paid / D0) : (paid > 0 ? 1 : 0);
      $("#rg", sh).style.strokeDashoffset = C * (1 - p);
      sh.querySelector(".clc-hero").classList.toggle("zero", paid > 0 && after <= .004);
      $("#rl", sh).textContent = paid > 0 ? (after <= .004 ? (after < -.004 ? "دفعة مقدّمة" : "سُدّد بالكامل") : "يبقى له") : "له الآن";
      $("#rb", sh).textContent = fm(paid > 0 ? Math.abs(after) : D0);
      $("#rs", sh).textContent = paid > 0 && after <= .004 && after >= -.004 ? "🎉" : CUR;
      $("#sp", sh).textContent = fm(amt); $("#sr", sh).textContent = fm(Math.max(0, after));
      var x = $("#cx", sh);
      x.className = "clc-x" + (after < -.004 ? " warn" : disc > 0 && paid > 0 ? " info" : "");
      x.innerHTML = after < -.004 ? ic("clock") + "<span>المبلغ أكبر من المستحق بـ <b>" + fm(-after) + "</b> — يُسجَّل دفعة مقدّمة عند المورد</span>" : disc > 0 && paid > 0 ? ic("tag") + "<span>خصم <b>" + fm(disc) + "</b> يُنقص المستحق بدون خروج من الخزينة</span>" : "";
      paintDues();
      var b = $("#cok", sh);
      b.disabled = busy || paid <= 0;
      b.innerHTML = paid <= 0 ? ic("check") + "<span>أدخل المبلغ</span>" : ic("check") + '<span>تأكيد دفع <bdi class="n">' + fm(amt) + "</bdi> " + CUR + "</span>";
    }
    inp.oninput = upd;
    $("#dtg", sh).onclick = function () { var w = $("#dw", sh); w.hidden = !w.hidden; this.classList.toggle("on", !w.hidden); if (!w.hidden) setTimeout(function () { $("#cdi", sh).focus(); }, 60); else { $("#cdi", sh).value = ""; upd(); } };
    $("#cdi", sh).oninput = upd;
    chips(); upd(); setTimeout(function () { inp.focus(); }, 320);
    api("/api/sdues?id=" + c.id).then(function (d) {
      if (!d.ok) throw new Error(d.error);
      dues = d.items || [];
      if (typeof d.bal === "number" && d.pc !== false) { D0 = Math.max(0, -d.bal); sh.querySelector(".clc-side b bdi").textContent = fm(D0); }
      chips(); upd();
    }).catch(function (e) { dues = []; $("#du", sh).innerHTML = '<div class="due none">' + ic("cloud") + "<span>" + (e.net ? "بدون اتصال — تُسوّى الفواتير عند التسجيل في ANOUER" : esc(e.message)) + "</span></div>"; });
    $("#cok", sh).onclick = function () {
      if (busy || amt + disc <= 0) return;
      var tr = $("#ctr", sh); if (tr) { S.trId = +tr.value; LS.set("trId", S.trId); }
      busy = true; var b = this; b.disabled = true; b.innerHTML = '<i class="spin"></i>';
      var body = { supplierId: c.id, amount: amt, disc: disc, treasuryId: S.trId, note: $("#cnn", sh).value.trim(), cid: uid(), cname: c.n };
      var snap = { c: c, before: D0, amount: amt, disc: disc, plan: plan(), at: new Date() };
      api("/api/paysup", body, { timeout: 20000 }).then(function (d) {
        if (!d.ok) throw new Error(d.error || "تعذّر التسجيل");
        closeSheet(true, true); beep(); buzz([20, 50, 30]); paySupDone(snap, d.queued ? null : d, d.queued ? "cloud" : false);
      }).catch(function (e) {
        if (e.net) { S.queue.push({ ep: "/api/paysup", body: body, snap: { total: amt, paid: amt, cust: c.n, n: 0, col: true, pay: true }, at: Date.now() }); LS.set("queue", S.queue); closeSheet(true, true); paySupDone(snap, null, true); return; }
        busy = false; upd(); beep(false); buzz([40, 40, 40]); toast(e.message, "bad");
      });
    };
  }

  function paySupDone(snap, d, pending) {
    var CLP = pending === "cloud", c = snap.c, after = d ? d.after : Math.max(0, snap.before - snap.amount - snap.disc), credit = d ? d.credit : Math.max(0, snap.amount + snap.disc - snap.before);
    var al = d && d.alloc ? d.alloc.map(function (a) { return { no: a.no, a: +a.amt, full: !!a.full }; }) : snap.plan.filter(function (x) { return x.a > 0; }).map(function (x) { return { no: x.d.no, a: x.a, full: x.full }; });
    var el = document.createElement("div"); el.className = "done col sup";
    var rec = '<div class="rcpt"><div class="h"><b>' + esc(S.company) + "</b><small>وصل دفع نقدية" + (d && d.no ? ' رقم <bdi class="n">' + esc(d.no) + "</bdi>" : "") + ' · <bdi class="n">' + snap.at.toLocaleDateString("en-GB") + " " + snap.at.toTimeString().slice(0, 5) + "</bdi></small></div>" +
      '<div class="l"><span>دفعنا إلى<small>' + esc(c.ph || "") + "</small></span><b>" + esc(c.n) + "</b></div>" +
      '<div class="t"><div><span>المستحق قبل</span><b>' + N(snap.before) + "</b></div>" +
      '<div class="g"><span>المبلغ المدفوع</span><b>' + N(snap.amount) + " " + CUR + "</b></div>" +
      (snap.disc ? "<div><span>خصم / مسامحة</span><b>" + N(snap.disc) + "</b></div>" : "") +
      (credit > .004 ? '<div class="ok"><span>دفعة مقدّمة عند المورد</span><b>' + N(credit) + "</b></div>" : '<div class="' + (after <= .004 ? "ok" : "") + '"><span>' + (after <= .004 ? "الحساب مسدّد بالكامل ✓" : "يبقى له") + "</span><b>" + N(after) + "</b></div>") + "</div>" +
      (al.length ? '<div class="al">' + al.map(function (a) { return '<span class="' + (a.full ? "f" : "") + '">' + (a.full ? "✓ " : "") + "فاتورة " + esc(a.no) + " · " + fm(a.a) + "</span>"; }).join("") + "</div>" : "") + "</div>";
    el.innerHTML = '<div class="ck' + (CLP ? " pn cld" : pending ? " pn" : " col") + '">' + ic(CLP ? "cloud" : pending ? "clock" : "cash") + "</div>" +
      "<h2>" + (CLP ? "محفوظ في السحابة" : pending ? "محفوظ في الانتظار" : after <= .004 && credit <= .004 ? "سُدّد المورد بالكامل 🎉" : "تم الدفع بنجاح") + '</h2><p class="s">' +
      (CLP ? "الجهاز مقفول — يُسجَّل السند في ANOUER وحده عند تشغيله" : pending ? (CLOUD ? "لا يوجد إنترنت الآن — يُرسل تلقائياً عند عودة الاتصال" : "لا يوجد اتصال الآن — يُرسل للبرنامج عند عودة الواي فاي") : "سُجّل سند دفع نقدية في ANOUER: الخزينة وحساب المورد وفواتير المشتريات") + "</p>" + rec +
      '<div class="act">' + (c.ph ? '<button class="btn wa" id="cwa">' + ic("share") + "<span>واتساب للمورد</span></button>" : '<button class="btn ghost" id="cwa">' + ic("share") + "<span>مشاركة الوصل</span></button>") + '<button class="btn pri" id="cnw">' + ic("check") + "<span>تم</span></button></div>";
    document.body.appendChild(el);
    if (sheet._h) { sheet._h = false; history.replaceState({ done: 1 }, ""); } else history.pushState({ done: 1 }, "");
    $("#cnw", el).onclick = function () { history.back(); };
    $("#cwa", el).onclick = function () {
      var txt = ["السلام عليكم " + c.n + " 👋", "تم الدفع من " + S.company, "", "🧾 وصل دفع" + (d && d.no ? " رقم " + d.no : ""), "📅 " + snap.at.toLocaleString("en-GB").slice(0, 17),
        "💵 المبلغ المدفوع: " + fm(snap.amount) + " " + CUR].concat(snap.disc ? ["🎁 خصم: " + fm(snap.disc) + " " + CUR] : [])
        .concat([credit > .004 ? "✅ دفعة مقدّمة لكم: " + fm(credit) + " " + CUR : after <= .004 ? "✅ حسابك مسدّد بالكامل" : "📌 المتبقي لكم: " + fm(after) + " " + CUR, "", "شكراً على تعاملكم 🌟"]).join("\n");
      var w = waNum(c.ph);
      if (w) location.href = "https://wa.me/" + w + "?text=" + encodeURIComponent(txt);
      else if (navigator.share) navigator.share({ text: txt }).catch(function () { });
      else location.href = "https://wa.me/?text=" + encodeURIComponent(txt);
    };
    if (pending) { var a = $(".top-r .av"); if (a) a.className = avCls(); }
  }

  /* ------------------------------------------------------------ مبيعاتي */
  function renderSales() {
    var v = $("#vw");
    var B = BUY(), H = B ? "مشترياتي" : "مبيعاتي";
    v.innerHTML = '<div class="ph1"><h2>' + H + '</h2><button class="ib" id="sr">' + ic("sync") + '</button></div><div class="kpi"><small>' + H + ' اليوم</small><b>…</b><div class="row"><span>' + ic("receipt") + "…</span></div></div>" +
      '<div class="card"><div class="sk" style="height:64px;border-radius:0"></div><div class="sk" style="height:64px;border-radius:0"></div></div>';
    $("#sr").onclick = function () { this.classList.add("sp"); renderSales(); };
    api("/api/recent" + (B ? "?t=buy" : "")).then(function (d) {
      if (S.tab !== "sales" || BUY() !== B) return;
      var items = d.items || [], days = {};
      items.forEach(function (x) { (days[x.d] = days[x.d] || []).push(x); });
      var today = new Date().toISOString().slice(0, 10);
      var q = S.queue.length ? '<div class="grp"><span>في الانتظار</span><span>' + S.queue.length + '</span></div><div class="card">' + S.queue.map(function (x) {
        return '<div class="sale"><span class="ic pn">' + ic(x.snap.col ? "cash" : x.snap.buy ? "truck" : "clock") + '</span><span class="tx"><b>' + esc(x.snap.cust || (x.snap.buy ? "مورد نقدي" : "عميل نقدي")) + "</b><small>" + (x.snap.pay ? "دفع لمورد" : x.snap.col ? "تحصيل دين" : x.snap.n + " صنف") + (x.err ? " · " + esc(x.err) : " · سيُرسل تلقائياً") + '</small></span><span class="am">' + N(x.snap.total) + "</span></div>";
      }).join("") + "</div>" : "";
      /* تحصيل الديون: زر + تحصيلات آخر 7 أيام */
      var CO = d.col || null;
      var colB = B ? '<button class="colb sup" id="colb"><span class="ci">' + ic("truck") + '</span><span class="tx"><b>دفع مستحقات مورد</b><small>' + (CO && CO.today.count ? "دفعت اليوم " + fm(CO.today.total) + " " + CUR + " · " + CO.today.count + (CO.today.count === 1 ? " سند" : " سندات") : "سند دفع نقدية يُسجَّل في ANOUER مباشرة") + '</small></span><span class="go">' + ic("back") + "</span></button>" +
        (CO && CO.items.length ? '<div class="grp"><span>مدفوعاتي للموردين</span><span>' + N(CO.items.reduce(function (a, x) { return a + x.g; }, 0)) + '</span></div><div class="card">' + CO.items.slice(0, 6).map(function (x) {
          return '<div class="sale"><span class="ic col sup">' + ic("truck") + '</span><span class="tx"><b>' + esc(x.c) + '</b><small>سند دفع <bdi class="n">' + esc(x.no) + '</bdi> · <bdi class="n">' + (x.d === today ? x.t : x.d) + '</bdi></small></span><span class="am">' + N(x.g) + "</span></div>";
        }).join("") + "</div>" : "") : '<button class="colb" id="colb"><span class="ci">' + ic("cash") + '</span><span class="tx"><b>تحصيل دين من عميل</b><small>' + (CO && CO.today.count ? "حصّلت اليوم " + fm(CO.today.total) + " " + CUR + " · " + CO.today.count + (CO.today.count === 1 ? " سند" : " سندات") : "سند استلام نقدية يُسجَّل في ANOUER مباشرة") + '</small></span><span class="go">' + ic("back") + "</span></button>" +
        (CO && CO.items.length ? '<div class="grp"><span>تحصيلاتي</span><span>' + N(CO.items.reduce(function (a, x) { return a + x.g; }, 0)) + '</span></div><div class="card">' + CO.items.slice(0, 6).map(function (x) {
          return '<div class="sale"><span class="ic col">' + ic("cash") + '</span><span class="tx"><b>' + esc(x.c) + '</b><small>سند <bdi class="n">' + esc(x.no) + '</bdi> · <bdi class="n">' + (x.d === today ? x.t : x.d) + '</bdi></small></span><span class="am">' + N(x.g) + "</span></div>";
        }).join("") + "</div>" : "");
      v.innerHTML = '<div class="ph1"><h2>' + H + '</h2><button class="ib" id="sr">' + ic("sync") + "</button></div>" +
        '<div class="kpi"><small>' + H + " اليوم · " + esc(S.name) + "</small><b>" + N(d.today.total) + ' <small style="font-size:15px;opacity:.8">' + CUR + '</small></b><div class="row"><span>' + ic("receipt") + d.today.count + " فاتورة</span><span>" + ic("chart") + "متوسط " + fm(d.today.count ? d.today.total / d.today.count : 0, 0) + "</span></div></div>" +
        colB + q + (items.length ? Object.keys(days).map(function (k) {
          var s = days[k].reduce(function (a, x) { return a + x.g; }, 0);
          return '<div class="grp"><span>' + (k === today ? "اليوم" : '<bdi class="n">' + k + "</bdi>") + "</span><span>" + N(s) + '</span></div><div class="card">' + days[k].map(function (x) {
            var cr = x.g - x.p > .004;
            if (x.wait) return '<div class="sale"><span class="ic pn cld">' + ic("cloud") + '</span><span class="tx"><b>' + esc(x.c || (B ? "مورد نقدي" : "عميل نقدي")) + '</b><small>في السحابة · <bdi class="n">' + x.t + "</bdi> · " + x.l + ' صنف · تُسجَّل عند تشغيل الجهاز</small></span><span class="am">' + N(x.g) + "</span></div>";
            return '<div class="sale"><span class="ic' + (cr ? " cr" : "") + '">' + ic(cr ? "clock" : "check") + '</span><span class="tx"><b>' + esc(x.c || (B ? "مورد نقدي" : "عميل نقدي")) + '</b><small>فاتورة <bdi class="n">' + esc(x.no) + '</bdi> · <bdi class="n">' + x.t + "</bdi> · " + x.l + ' صنف</small></span><span class="am">' + N(x.g) + (cr ? "<small>آجل " + fm(x.g - x.p) + "</small>" : "") + "</span></div>";
          }).join("") + "</div>";
        }).join("") : B ? empty("truck", "لا توجد مشتريات بعد", "مشترياتك من الهاتف خلال آخر 7 أيام تظهر هنا") : empty("receipt", "لا توجد مبيعات بعد", "مبيعاتك من الهاتف خلال آخر 7 أيام تظهر هنا"));
      $("#sr").onclick = function () { this.classList.add("sp"); renderSales(); };
      var cb = $("#colb"); if (cb) cb.onclick = function () { buzz(10); if (B) creditorsSheet(); else debtorsSheet(); };
    }).catch(function (e) { if (S.tab === "sales") v.insertAdjacentHTML("beforeend", '<p style="text-align:center;color:var(--bad);font-size:13px">' + (e.net ? (CLOUD ? "لا يوجد إنترنت" : "تعذّر الاتصال بالبرنامج") : esc(e.message)) + "</p>"); });
  }

  /* ------------------------------------------------------------ حسابي / الإعدادات */
  function renderMore() {
    var v = $("#vw"), th = LS.get("theme", "auto");
    var base = location.origin, standalone = matchMedia("(display-mode: standalone)").matches || navigator.standalone;
    v.innerHTML = '<div class="ph1"><h2>حسابي</h2></div>' +
      '<div class="card me"><span class="av">' + esc((S.name || "A").trim()[0]) + "</span><div><b>" + esc(S.name) + "</b><small>@" + esc(S.user) + " · " + esc(S.company) + "</small></div></div>" +
      '<div class="grp"><span>البيع</span></div><div class="card">' +
      '<div class="set"><span class="si">' + ic("tag") + '</span><span class="tx"><b>قائمة الأسعار</b><small>السعر المستعمل عند الإضافة</small></span><select id="pk">' +
      [["p", "سعر البيع"], ["w", "الجملة"], ["r", "التجزئة"], ["ps", "عابر سبيل"]].map(function (x) { return '<option value="' + x[0] + '"' + (S.pk === x[0] ? " selected" : "") + ">" + x[1] + "</option>"; }).join("") + "</select></div>" +
      (S.tr.length ? '<div class="set"><span class="si">' + ic("cash") + '</span><span class="tx"><b>الخزينة الافتراضية</b><small>تدخلها نقدية المبيعات</small></span><select id="tr2">' + S.tr.map(function (t) { return '<option value="' + t.id + '"' + (t.id === S.trId ? " selected" : "") + ">" + esc(t.n) + "</option>"; }).join("") + "</select></div>" : "") +
      '<button class="set" id="rc"><span class="si">' + ic("sync") + '</span><span class="tx"><b>تحديث الأصناف</b><small>' + S.cat.length + " صنف" + (S.catAt ? " · آخر تحديث " + esc(S.catAt) : "") + "</small></span></button></div>" +
      (S.buy ? '<div class="grp"><span>الشراء</span></div><div class="card">' +
        '<button class="set" id="mdset"><span class="si">' + ic("truck") + '</span><span class="tx"><b>' + (BUY() ? "أنت في وضع الشراء" : "وضع الشراء") + "</b><small>" + (BUY() ? "اضغط للرجوع إلى البيع" : "اشترِ من الموردين مع مقارنة الأسعار") + '</small></span><span class="sw' + (BUY() ? " on" : "") + '"></span></button>' +
        '<button class="set" id="pbr"><span class="si">' + ic("trophy") + '</span><span class="tx"><b>تحديث أسعار الموردين</b><small>' + (S.pbAt ? "آخر تحديث " + esc(S.pbAt) + " · " : "") + Object.keys(S.sup || {}).length + " مورد</small></span></button></div>" : "") +
      '<div class="grp"><span>التطبيق</span></div><div class="card">' +
      '<div class="set"><span class="si">' + ic("moon") + '</span><span class="tx"><b>المظهر</b></span><div class="seg" id="th" style="width:190px">' + [["auto", "تلقائي"], ["light", "فاتح"], ["dark", "داكن"]].map(function (x) { return '<button data-t="' + x[0] + '"' + (th === x[0] ? ' class="on"' : "") + ">" + x[1] + "</button>"; }).join("") + "</div></div>" +
      '<button class="set" data-sw="snd"><span class="si">' + ic("bolt") + '</span><span class="tx"><b>صوت المسح</b></span><span class="sw' + (S.snd ? " on" : "") + '"></span></button>' +
      '<button class="set" data-sw="vib"><span class="si">' + ic("phone") + '</span><span class="tx"><b>الاهتزاز</b></span><span class="sw' + (S.vib ? " on" : "") + '"></span></button>' +
      (window.caches && window.isSecureContext ? '<button class="set" data-sw="offimg"><span class="si">' + ic("cloud") + '</span><span class="tx"><b>صور الأصناف بدون إنترنت</b><small id="imsl">' + imsLabel() + '</small></span><span class="sw' + (S.offimg ? " on" : "") + '"></span></button>' : "") +
      (CLOUD ? '<div class="set"><span class="si">' + ic("cloud") + '</span><span class="tx"><b>وضع الإنترنت</b><small>' + (S.pc === false ? "الجهاز مقفول — المبيعات تُحفظ في السحابة وتُسجَّل عند تشغيله" : "مباشر مع ANOUER من أي مكان") + '</small></span><span class="pill' + (S.pc === false ? " off" : "") + '">' + (S.pc === false ? "السحابة" : "مباشر") + "</span></div></div>"
        : '<a class="set" href="/dash?k=' + encodeURIComponent(K) + '" style="color:inherit;text-decoration:none"><span class="si">' + ic("chart") + '</span><span class="tx"><b>لوحة متابعة المحل</b><small>مبيعات اليوم · الخزينة · النواقص</small></span></a></div>') +
      (standalone ? "" : CLOUD ? '<div class="grp"><span>ثبّت التطبيق على الشاشة الرئيسية</span></div><div class="card tip"><b>Android (Chrome):</b> القائمة ⋮ ← «تثبيت التطبيق».<br><b>iPhone (Safari):</b> زر المشاركة ← «إضافة إلى الشاشة الرئيسية».<br><br>✓ الكاميرا والمسح المباشر يعملان (رابط آمن https) ، والتطبيق يفتح حتى بدون إنترنت.</div>' : '<div class="grp"><span>ثبّت التطبيق على الشاشة الرئيسية</span></div><div class="card tip">' +
        "<b>Android (Chrome):</b> القائمة ⋮ ← «إضافة إلى الشاشة الرئيسية».<br><b>iPhone (Safari):</b> زر المشاركة ← «إضافة إلى الشاشة الرئيسية».<br><br>" +
        "💡 لتفعيل <b>المسح المباشر بالكاميرا</b> وفتح التطبيق بدون شريط المتصفح على Android: افتح في Chrome <code>chrome://flags/#unsafely-treat-insecure-origin-as-secure</code> وأضف <code>" + esc(base) + "</code> ثم Enable وأعد التشغيل.</div>") +
      '<div class="grp"><span></span></div><div class="card"><button class="set red" id="lo"><span class="si">' + ic("out") + '</span><span class="tx"><b>تسجيل الخروج</b></span></button></div>' +
      '<div class="ver">ANOUER POS ' + VER + " · " + esc(location.host) + "</div>";
    $("#pk").onchange = function () { S.pk = this.value; LS.set("pk", S.pk); toast("قائمة الأسعار: " + this.options[this.selectedIndex].text); };
    var t2 = $("#tr2"); if (t2) t2.onchange = function () { S.trId = +this.value; LS.set("trId", S.trId); };
    $("#rc").onclick = function () { loadCatalog(true); };
    var ms = $("#mdset"); if (ms) ms.onclick = function () { setMode(BUY() ? "sale" : "buy"); };
    var pb = $("#pbr"); if (pb) pb.onclick = function () { loadBest(true); };
    $$("#th button").forEach(function (b) {
      b.onclick = function () {
        var t = b.dataset.t; LS.set("theme", t); vt(function () { if (t === "auto") delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = t; $$("#th button").forEach(function (x) { x.classList.toggle("on", x === b); }); });
      };
    });
    $$("[data-sw]").forEach(function (b) { b.onclick = function () { var k = b.dataset.sw; S[k] = !S[k]; LS.set(k, S[k]); b.querySelector(".sw").classList.toggle("on", S[k]); buzz(10); if (k === "offimg") { if (S[k]) imgSync(); paintIms(); } }; });
    $("#lo").onclick = function () { if (confirmTap(this)) logout(); };
  }

  /* ------------------------------------------------------------ ✦ صور الأصناف بدون إنترنت
     كل الصور تُنزَّل في الخلفية إلى ذاكرة الهاتف (لا التي مرّت على الشاشة فقط) ، والنسخة القديمة من صورة تغيّرت تُمسح */
  var IMS = { run: false, again: false, done: 0, total: 0 };
  function imgKey(u) { try { return new URL(u, location.href).href; } catch (e) { return u; } }
  function imsLabel() { return !S.offimg ? "متوقف — تظهر الصور التي فُتحت فقط" : IMS.total ? (IMS.done >= IMS.total ? "✓ " + IMS.total + " صورة محفوظة في الهاتف" : "جارٍ التنزيل " + IMS.done + " / " + IMS.total) : "تُحفظ في الهاتف تلقائياً"; }
  function paintIms() { var e = $("#imsl"); if (e) e.textContent = imsLabel(); }
  function imgGet(p) {
    if (ALT) return lanFetch(ALT + "/img?k=" + encodeURIComponent(ALTK) + "&id=" + p.i + "&v=" + p.im, 15000);
    return fetch(imgOf(p.i, p.im));
  }
  /* صورة وصلت للذاكرة ← تظهر في مكانها إن كانت بطاقتها على الشاشة بلا صورة */
  function imgShow(p) {
    $$('.pc[data-i="' + p.i + '"] > .ph:not(.hasim)').forEach(function (el) { var w = document.createElement("span"); w.innerHTML = pic(p.n, p.i, p.im, "", p.g ? "<small>" + esc(p.g) + "</small>" : ""); if (w.firstChild) el.parentNode.replaceChild(w.firstChild, el); });
  }
  function imgSync() {
    if (!window.caches || !window.isSecureContext || !S.sid || !S.offimg || !S.cat.length || S.net === "off") return;
    if (IMS.run) { IMS.again = true; return; }
    try { if (navigator.connection && navigator.connection.saveData) return; } catch (e) { }
    var sig = S.cat.length + ":" + S.cat.reduce(function (a, p) { return (a + (+p.im || 0) % 1000003) % 2147483647; }, 0);
    if (IMS.sig === sig && IMS.done >= IMS.total) return;       /* كل الصور محفوظة ولم يتغيّر شيء */
    IMS.sig = sig;
    IMS.run = true; IMS.again = false;
    var want = {}, list = [];
    S.cat.forEach(function (p) { if (p.im) want[imgKey(imgOf(p.i, p.im))] = p; });
    caches.open("anp-img-v1").then(function (c) {
      return c.keys().then(function (ks) {
        var have = {};
        ks.forEach(function (r) { if (want[r.url]) have[r.url] = 1; else if (/\/img\?/.test(r.url)) c.delete(r); });
        Object.keys(want).forEach(function (u) { if (!have[u]) list.push(u); });
        IMS.total = Object.keys(want).length; IMS.done = IMS.total - list.length; paintIms();
        var i = 0, fails = 0;
        function next() {
          if (i >= list.length || S.net === "off" || fails > 8 || IMS.again || !S.offimg) return Promise.resolve();
          var u = list[i++], p = want[u];
          return imgGet(p).then(function (res) {
            if (!res || !res.ok) { fails++; return; }
            return c.put(u, res).then(function () { IMS.done++; fails = 0; imgShow(p); if (IMS.done % 10 === 0) paintIms(); });
          }, function () { fails++; }).then(function () { return new Promise(function (ok) { setTimeout(ok, document.hidden ? 500 : 70); }); }).then(next);
        }
        return Promise.all([next(), next(), next()]);
      });
    }).catch(function () { }).then(function () { IMS.run = false; paintIms(); if (IMS.again) setTimeout(imgSync, 300); });
  }

  /* ------------------------------------------------------------ ✦ بدون إنترنت داخل المحل
     تطبيق الإنترنت (https) يتصل بالجهاز مباشرة عبر واي فاي المحل حين ينقطع الإنترنت: الأصناف والأرصدة والبيع مباشرة مع ANOUER.
     يعتمد على إذن «الأجهزة على الشبكة المحلية» في المتصفح (Local Network Access) — وإلا يعرض رابط «نسخة المحل». */
  var ALT = "", ALTK = "", LAN = { busy: false, at: 0 };
  var WIFI = '<svg class="i" viewBox="0 0 24 24"><path d="M2.5 9.5a14 14 0 0 1 19 0M5.8 13a9.3 9.3 0 0 1 12.4 0M9 16.4a4.6 4.6 0 0 1 6 0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="19.4" r="1.4" fill="currentColor"/></svg>';
  function lanInfo() { var L = LS.get("lan", null); return CLOUD && L && L.on && L.k && L.port && L.ips && L.ips.length ? L : null; }
  function lanPerm() {
    if (!navigator.permissions || !navigator.permissions.query) return Promise.resolve("unknown");
    var q = function (n) { return navigator.permissions.query({ name: n }).then(function (r) { return r.state; }); };
    return q("local-network-access").catch(function () { return q("local-network"); }).catch(function () { return "unknown"; });
  }
  function lanFetch(url, ms, opt) {
    var ctl = window.AbortController ? new AbortController() : null, to = setTimeout(function () { ctl && ctl.abort(); }, ms || 4000), o = opt || {};
    o.cache = "no-store"; if (ctl) o.signal = ctl.signal;
    return fetch(url, o).then(function (r) { clearTimeout(to); return r; }, function (e) { clearTimeout(to); throw e; });
  }
  function lanTry(byUser) {
    var L = lanInfo(); if (!L || LAN.busy) return Promise.resolve(false);
    if (ALT) return Promise.resolve(true);
    LAN.busy = true; LAN.at = Date.now(); paintLan();
    return new Promise(function (done) {
      var left = L.ips.length, won = false;
      L.ips.forEach(function (ip) {
        var b = "http://" + ip + ":" + L.port;
        lanFetch(b + "/api/ping?k=" + encodeURIComponent(L.k), 3500).then(function (r) { return r.ok ? r.json() : null; })
          .then(function (d) { if (d && d.ok && !won) { won = true; done(b); } }, function () { })
          .then(function () { if (--left === 0 && !won) done(""); });
      });
    }).then(function (b) {
      LAN.busy = false;
      if (!b) { paintLan(); if (byUser) lanHelp(L); return false; }
      ALT = b; ALTK = L.k; S.net = "lan?"; setNet("ok");
      toast("📶 متصل بالجهاز عبر واي فاي المحل — بدون إنترنت"); buzz(20);
      boot().catch(function () { }); loadCatalog(false);
      return true;
    });
  }
  /* تلقائياً فقط إذا سبق وأُعطي الإذن — وإلا يظهر زر (الإذن يحتاج لمسة من المستخدم) */
  function lanAuto() {
    if (!lanInfo() || ALT || LAN.busy || Date.now() - LAN.at < 15000) return;
    lanPerm().then(function (s) { if (s === "granted") lanTry(false); else paintLan(); });
  }
  function paintLan() {
    var t = $(".top"), b = $("#lanb");
    var show = !!(t && CLOUD && S.sid && S.net === "off" && !ALT && lanInfo());
    if (!show) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement("button"); b.type = "button"; b.id = "lanb"; b.className = "lanb"; t.appendChild(b); b.onclick = function () { buzz(10); lanTry(true); }; }
    b.classList.toggle("busy", LAN.busy);
    b.innerHTML = "<i>" + WIFI + "</i><span><b>" + (LAN.busy ? "جارٍ البحث عن الجهاز على الواي فاي …" : "بدون إنترنت؟ اتصل بالجهاز عبر واي فاي المحل") + "</b><small>الأصناف والأرصدة والبيع مباشرة مع ANOUER</small></span>";
  }
  function lanHelp(L) {
    var u = "http://" + L.ips[0] + ":" + L.port + "/?k=" + encodeURIComponent(L.k);
    sheet("لم أصل إلى الجهاز", "تأكد من هذه النقاط ثم أعد المحاولة",
      '<div class="lanh"><p>① الهاتف موصول بنفس <b>واي فاي المحل</b> (وليس بيانات الهاتف).</p><p>② برنامج ANOUER مفتوح على الجهاز و«ربط البرنامج بالموبايل» شغّال.</p><p>③ اسمح للتطبيق بـ «الأجهزة على الشبكة المحلية» إذا سألك المتصفح.</p>' +
      '<p class="mu">إن لم يسمح متصفحك بذلك، افتح «نسخة المحل» — تعمل على الواي فاي بدون أي إنترنت:</p>' +
      '<a class="btn pri" href="' + esc(u) + '" target="_blank" rel="noopener">' + WIFI + "<span>افتح نسخة المحل (واي فاي)</span></a></div>",
      '<button class="btn ghost" id="lnr" style="width:100%">أعد المحاولة</button>');
    $("#lnr").onclick = function () { closeSheet(); setTimeout(function () { lanTry(true); }, 300); };
  }
  /* رجع الإنترنت ← نرجع لطريق السحابة (يعمل من أي مكان) */
  setInterval(function () {
    if (!ALT || document.hidden) return;
    fetch(BASE + "/api/ping?k=" + encodeURIComponent(K), { cache: "no-store" }).then(function (r) { return r.ok ? r.json() : null; }).then(function (d) {
      if (!d || !d.ok || !ALT) return; ALT = ""; var sm = $("#netl"); if (sm) sm.textContent = netLabel(); var a = $(".top-r .av"); if (a) a.className = avCls();
      toast("☁ رجع الإنترنت — متصل عبر السحابة");
    }, function () { });
  }, 45000);
  window.addEventListener("offline", function () { if (CLOUD && S.sid) api("/api/ping", null, { timeout: 4000 }).catch(function () { }); });

  /* ------------------------------------------------------------ ✦ البحث بالصوت
     «زوج حليب وثلاثة خبز» ← يفهم الكمية والصنف ويضيف وحده · يطابق النطق العربي مع الأسماء اللاتينية (كوكا كولا = COCA COLA)
     إملاء متواصل: صنف بعد صنف حتى تقول «خلاص» · «تراجع» يحذف آخر إضافة */
  var MIC = '<svg class="i" viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  var NUMW = { "واحد": 1, "واحده": 1, "وحده": 1, "وحد": 1, "زوج": 2, "جوج": 2, "اثنين": 2, "اثنان": 2, "ثنين": 2, "اتنين": 2, "ثلاثه": 3, "ثلاث": 3, "تلاته": 3, "تلات": 3, "ثلاته": 3, "اربعه": 4, "اربع": 4, "ربعه": 4,
    "خمسه": 5, "خمس": 5, "سته": 6, "ست": 6, "سبعه": 7, "سبع": 7, "ثمانيه": 8, "ثماني": 8, "ثمان": 8, "تمنيه": 8, "تمانيه": 8, "تسعه": 9, "تسع": 9, "عشره": 10, "عشر": 10, "حداش": 11, "احدعشر": 11, "طناش": 12, "اثناعشر": 12, "اثنعش": 12,
    "خمسطاش": 15, "عشرين": 20, "عشرون": 20, "ثلاثين": 30, "خمسين": 50, "ميه": 100, "مائه": 100, "نص": .5, "نصف": .5, "ربع": .25,
    "un": 1, "une": 1, "deux": 2, "trois": 3, "quatre": 4, "cinq": 5, "six": 6, "sept": 7, "huit": 8, "neuf": 9, "dix": 10, "douze": 12, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5 };
  var FILLW = {}; "اعطيني عطيني اعطني هات هاتلي جيب جيبلي زيد زيدلي زيدني نحب بغيت ابغي اريد حط حطلي ضيف اضف اضيف ضف من تاع نتاع متاع ديال في الى على و ثم كذلك ايضا زياده حبه حبات علبه علب قطعه قطع لي ليا s'il vous plait donne ajoute de du des le la les et".split(" ").forEach(function (w) { FILLW[w] = 1; });
  function numOf(w) { if (/^\d+([.,]\d+)?$/.test(w)) return parseFloat(w.replace(",", ".")); return NUMW.hasOwnProperty(w) ? NUMW[w] : null; }
  function ntok(t) { return t.replace(/^(ال|لل)(?=.{3,})/, ""); }
  /* هيكل النطق: نفس الناتج للكلمة بالعربي أو باللاتيني (حروف العلة تسقط) */
  var AR2K = { "ب": "b", "پ": "b", "ت": "t", "ط": "t", "ث": "t", "ج": "j", "ح": "h", "ه": "h", "خ": "h", "د": "d", "ض": "d", "ذ": "z", "ز": "z", "ظ": "z", "ر": "r", "س": "s", "ص": "s", "ش": "x", "غ": "g", "گ": "g", "ف": "f", "ڤ": "f", "ق": "k", "ك": "k", "ل": "l", "م": "m", "ن": "n" };
  var SKC = {};
  function skel(w) {
    if (SKC.hasOwnProperty(w)) return SKC[w];
    var s = w, o = "";
    if (/[a-z]/.test(s)) {
      s = s.replace(/(.)\1+/g, "$1").replace(/ch|sh/g, "x").replace(/kh/g, "h").replace(/gh/g, "g").replace(/ph/g, "f").replace(/th/g, "t").replace(/qu|ck/g, "k").replace(/c(?=[eiy])/g, "s").replace(/g(?=[eiy])/g, "j")
        .replace(/[cq]/g, "k").replace(/p/g, "b").replace(/v/g, "f").replace(/x/g, "ks").replace(/[aeiouyw]/g, "");
      o = s;
    } else {
      s = s.replace(/ه$/, "");
      for (var i = 0; i < s.length; i++) { var c = s[i]; o += AR2K[c] != null ? AR2K[c] : /[0-9]/.test(c) ? c : ""; }
    }
    return (SKC[w] = o);
  }
  /* نطق تقريبي مع حروف العلة — للأسماء القصيرة الغنية بالحركات (OMO = أومو ، ELIO = إيليو) */
  var AR2V = { "ا": "a", "و": "o", "ي": "i", "ع": "a" }, VWC = {};
  function vow(w) {
    if (VWC.hasOwnProperty(w)) return VWC[w];
    var s = w, o = "";
    if (/[a-z]/.test(s)) {
      o = s.replace(/(.)\1+/g, "$1").replace(/ch|sh/g, "x").replace(/kh/g, "h").replace(/gh/g, "g").replace(/ph/g, "f").replace(/th/g, "t").replace(/qu|ck/g, "k").replace(/c(?=[eiy])/g, "s").replace(/g(?=[eiy])/g, "j")
        .replace(/[cq]/g, "k").replace(/p/g, "b").replace(/v/g, "f").replace(/x/g, "ks").replace(/ou|au|eau/g, "o").replace(/ai|ei|ee/g, "i").replace(/[ey]/g, "i").replace(/[uw]/g, "o").replace(/(.)\1+/g, "$1");
    } else {
      s = s.replace(/ه$/, "a");
      for (var i = 0; i < s.length; i++) { var c = s[i]; o += AR2K[c] != null ? AR2K[c] : AR2V[c] != null ? AR2V[c] : /[0-9a]/.test(c) ? c : ""; }
      o = o.replace(/(.)\1+/g, "$1");
    }
    return (VWC[w] = o);
  }
  function isLat(w) { return /[a-z]/.test(w); }
  function vowEq(a, b) { if (a === b) return true; if (lev1(a, b)) return true; /* همزة/ألف زائدة في أول الكلمة العربية */ return a.length > 3 && b.length > 2 && (a.slice(1) === b || b.slice(1) === a); }
  function lev1(a, b) {   /* فرق حرف واحد على الأكثر (إبدال / زيادة / نقص) */
    if (a === b) return true; var la = a.length, lb = b.length; if (Math.abs(la - lb) > 1) return false;
    var i = 0, j = 0, d = 0;
    while (i < la && j < lb) { if (a[i] === b[j]) { i++; j++; continue; } if (++d > 1) return false; if (la > lb) i++; else if (lb > la) j++; else { i++; j++; } }
    return d + (la - i) + (lb - j) <= 1;
  }
  function ptok(p) {
    if (!p._t) { p._t = (p._f || fold(p.n + " " + (p.c || ""))).split(/[^a-z0-9ء-ي]+/).filter(Boolean).map(ntok); p._k = p._t.map(skel); }
    return p;
  }
  function tokScore(q, qk, t, tk) {
    if (t === q) return 3;
    if (q.length >= 2 && t.indexOf(q) === 0) return 2.6;
    if (q.length >= 3 && t.indexOf(q) > 0) return 2.1;
    var cross = q.length >= 3 && t.length >= 3 && isLat(q) !== isLat(t), a, b;
    if (cross) { a = vow(q); b = vow(t); if (a.length >= 3 && a === b) return 2.3; }
    if (qk.length >= 2 && tk === qk) return qk.length >= 3 ? 2.2 : 1.8;
    if (qk.length >= 3 && tk.indexOf(qk) === 0) return 1.7;
    if (q.length >= 4 && lev1(q, t)) return 1.6;
    if (qk.length >= 4 && lev1(qk, tk)) return 1.3;
    if (cross && a.length >= 3 && b.length >= 3 && vowEq(a, b)) return 1.6;
    return 0;
  }
  function vToks(text) { return fold(text).replace(/[^a-z0-9ء-ي.,]+/g, " ").split(/\s+/).map(function (w) { return /^\d+[.,]\d+$/.test(w) ? w : w.replace(/[.,]/g, ""); }).filter(Boolean); }
  function vWords(text) { return vToks(text).filter(function (w) { return !FILLW[w]; }).map(ntok); }
  function vFind(words, limit) {
    var n = words.length; if (!n || !S.cat.length) return [];
    var qk = words.map(skel), need = n >= 2 ? n - 1 : n, out = [];
    for (var a = 0; a < S.cat.length; a++) {
      var p = ptok(S.cat[a]), sum = 0, hit = 0;
      for (var i = 0; i < n; i++) {
        var best = 0;
        for (var j = 0; j < p._t.length && best < 3; j++) { var sc = tokScore(words[i], qk[i], p._t[j], p._k[j]); if (sc > best) best = sc; }
        if (best) { hit++; sum += best; } else if (n - i - 1 + hit < need) break;
      }
      if (hit < need) continue;
      out.push({ p: p, sc: sum / (3 * n) + .04 * Math.min(1, n / p._t.length) + ((+p.s || 0) > 0 ? .01 : 0) });
    }
    out.sort(function (x, y) { return y.sc - x.sc; });
    return out.slice(0, limit || 6);
  }
  /* «زوج حليب وثلاثة خبز» ← [{q:2,w:[حليب]},{q:3,w:[خبز]}] — الكمية قبل الصنف أو بعده */
  function vSegs(text) {
    var toks = vToks(text), segs = [], cur = null;
    toks.forEach(function (w) {
      var w0 = w.length > 2 ? w.replace(/^و/, "") : w, v = numOf(w); if (v == null && w0 !== w) v = numOf(w0);
      if (v != null) {
        if (cur && cur.w.length) { segs.push(cur); cur = null; }
        if (!cur) cur = { q: v, w: [], qs: true }; else cur.q = v < 1 ? cur.q + v : v;
        return;
      }
      if (FILLW[w]) return;
      if (!cur) cur = { q: 1, w: [], qs: false };
      cur.w.push(ntok(w));
    });
    if (cur) { if (cur.w.length) segs.push(cur); else if (segs.length && !segs[segs.length - 1].qs) { segs[segs.length - 1].q = cur.q; segs[segs.length - 1].qs = true; } }
    return segs;
  }
  var VS = { sh: null, rec: null, lang: LS.get("vlang", "ar-DZ"), local: false, idle: 0, log: [], pend: null, last: "", err: "" };
  function vEl(s) { return VS.sh ? $(s, VS.sh) : null; }
  function vState(k, msg) { if (k === "ok" || k === "miss") VS.hold = Date.now() + 2200; var o = vEl(".vorb"); if (o) o.className = "vorb " + k; var m = vEl(".vmsg"); if (m && msg != null) m.innerHTML = msg; var b = vEl("#vgo"); if (b) b.innerHTML = MIC + "<span>" + (k === "on" || k === "hear" ? "إيقاف" : "تكلّم") + "</span>"; }
  function vLive(t) { var e = vEl(".vtxt"); if (e) { e.textContent = t ? "«" + t + "»" : ""; e.classList.toggle("has", !!t); } }
  function voice() {
    if (!SR || !window.isSecureContext) {
      toast("هنا استعمل ميكروفون لوحة المفاتيح 🎤 — البحث يفهم النطق التقريبي", "warn"); var q = $("#q"); if (q) q.focus(); return;
    }
    buzz(15); var q0 = $("#q"); if (q0) q0.blur();
    VS.log = []; VS.pend = null; VS.idle = 0; VS.last = ""; VS.err = "";
    var sh = sheet("البحث بالصوت", "قل الكمية واسم الصنف — يُضاف للسلة وحده",
      '<div class="vox"><div class="vorb idle"><span></span><span></span><span></span><b>' + MIC + '</b></div><div class="vmsg">جارٍ تشغيل الميكروفون …</div><div class="vtxt"></div>' +
      '<div class="vres"></div><div class="vlog"></div>' +
      '<div class="vhint"><em>جرّب:</em><i>زوج حليب</i><i>ثلاثة قهوة وواحد سكر</i><i>تراجع</i><i>خلاص</i></div></div>',
      '<div class="act2"><button class="btn ghost" id="vgo">' + MIC + '<span>تكلّم</span></button><button class="btn pri" id="vok">' + ic("check") + "<span>تم</span></button></div>");
    VS.sh = sh; sh.classList.add("vsheet");
    sheet._onClose = vStop;
    $("#vok", sh).onclick = function () { var n = VS.log.length; closeSheet(); if (n && S.tab === "pos") updateDock(true); };
    $("#vgo", sh).onclick = function () { buzz(10); if (VS.rec) { VS.idle = 9; try { VS.rec.stop(); } catch (e) { } vState("idle", "متوقف — اضغط «تكلّم» للمتابعة"); } else { VS.idle = 0; VS.pend = null; vRes(""); vListen(); } };
    vListen();
  }
  function vStop() {
    var r = VS.rec; VS.sh = null; VS.rec = null; VS.pend = null; if (r) try { r.abort(); } catch (e) { }
    /* لم يُضف شيء ← آخر ما قيل يُكتب في خانة البحث (البحث التقريبي يعرض أقرب الأصناف) */
    if (!VS.log.length && VS.last) { S.q = VS.last; S.shown = 60; var q = $("#q"); if (q) { q.value = S.q; var c = $("#qc"); if (c) c.hidden = false; } if (S.tab === "pos") renderGrid(); }
  }
  function vListen() {
    if (!VS.sh || VS.rec) return;
    var r; try { r = new SR(); } catch (e) { vState("err", "تعذّر تشغيل الميكروفون"); return; }
    VS.rec = r; r.lang = VS.lang; r.interimResults = true; r.maxAlternatives = 4; r.continuous = false;
    if (VS.local) try { r.processLocally = true; } catch (e) { }
    var got = false;
    r.onstart = function () {
      var keep = Date.now() < (VS.hold || 0); vState("on", keep ? null : "أسمعك … قل اسم الصنف");   /* رسالة «أُضيف / لم أجد» تبقى لحظة */
      if (keep) setTimeout(function () { if (VS.rec === r && !VS.pend) { var m = vEl(".vmsg"); if (m) m.textContent = "أسمعك … قل الصنف التالي"; vLive(""); } }, 2300);
    };
    r.onspeechstart = function () { if (VS.rec === r) vState("hear", null); };
    r.onresult = function (e) {
      var res = e.results[e.results.length - 1], alts = []; for (var i = 0; i < res.length; i++) if (res[i].transcript) alts.push(res[i].transcript.trim());
      if (!alts.length) return; vLive(alts[0]);
      if (res.isFinal && !got) { got = true; try { vHandle(alts); } catch (x) { vState("err", "حدث خطأ — أعد المحاولة"); } }
    };
    r.onerror = function (e) { VS.err = e.error || "error"; };
    r.onend = function () {
      if (VS.rec !== r) return; VS.rec = null; if (!VS.sh) return;
      var er = VS.err; VS.err = "";
      if (er === "not-allowed" || er === "service-not-allowed") { vState("err", "اسمح للتطبيق باستعمال <b>الميكروفون</b> من إعدادات المتصفح ثم اضغط «تكلّم»"); return; }
      if (er === "audio-capture") { vState("err", "لم أجد ميكروفوناً في هذا الجهاز"); return; }
      if (er === "language-not-supported" && VS.lang !== "ar-SA") { VS.lang = "ar-SA"; vListen(); return; }
      if (er === "network") { vOffline(); return; }
      if (VS.pend) { vState("pick", "اختر الصنف الصحيح 👇"); return; }
      if (!got) { if (++VS.idle >= 3) { vState("idle", "لم أسمع شيئاً — اضغط «تكلّم»"); return; } } else VS.idle = 0;
      setTimeout(function () { if (VS.sh && !VS.rec && !VS.pend) vListen(); }, 260);
    };
    try { r.start(); } catch (e) { VS.rec = null; vState("err", "تعذّر تشغيل الميكروفون"); }
  }
  /* بدون إنترنت: التعرّف داخل الهاتف إن كان متاحاً في المتصفح — وإلا ميكروفون لوحة المفاتيح */
  function vOffline() {
    var kb = "بدون إنترنت استعمل ميكروفون لوحة المفاتيح 🎤 داخل خانة البحث";
    if (VS.local || !SR.available) { vState("err", "البحث بالصوت يحتاج إنترنت — " + kb); return; }
    var op = { langs: [VS.lang], processLocally: true };
    SR.available(op).then(function (s) {
      if (!VS.sh) return;
      if (s === "available") { VS.local = true; vListen(); return; }
      if (s === "downloadable" || s === "downloading") {
        vState("err", "التعرّف الصوتي بدون إنترنت متاح للتنزيل مرة واحدة");
        vRes('<button class="btn ghost" id="vdl" style="width:100%">تنزيل التعرّف الصوتي داخل الهاتف</button>');
        var b = vEl("#vdl"); if (b) b.onclick = function () { b.disabled = true; b.innerHTML = '<i class="spin"></i>'; SR.install(op).then(function (ok) { vRes(""); if (ok) { VS.local = true; vListen(); } else vState("err", "تعذّر التنزيل — " + kb); }, function () { vRes(""); vState("err", "تعذّر التنزيل — " + kb); }); };
        return;
      }
      vState("err", "البحث بالصوت يحتاج إنترنت — " + kb);
    }, function () { vState("err", "البحث بالصوت يحتاج إنترنت — " + kb); });
  }
  function vRes(html) { var e = vEl(".vres"); if (e) e.innerHTML = html; }
  function vHandle(alts) {
    var f = fold(alts[0]).replace(/[^a-zء-ي ]+/g, " ").trim();
    if (/^(خلاص|صافي|كفي|يكفي|تم|توقف|قف|اغلق|سكر|شكرا|stop|fin|termine|c est bon)$/.test(f)) { closeSheet(); return; }
    if (/^(تراجع|الغي|الغاء|الغ|امسح|نحي|نحيه|احذف|رجع|annuler|annule)( .*)?$/.test(f)) { vUndo(); return; }
    var best = null;
    alts.forEach(function (a, ai) {
      var segs = vSegs(a); if (!segs.length) return; var tot = 0;
      segs.forEach(function (s) { s.r = vFind(s.w, 6); tot += s.r.length ? s.r[0].sc : 0; }); tot = tot / segs.length - ai * .01;
      if (!best || tot > best.tot) best = { tot: tot, segs: segs, text: a };
    });
    if (!best) { vMiss(alts[0]); return; }
    VS.last = best.segs.map(function (s) { return s.w.join(" "); }).join(" "); vLive(best.text);
    var amb = null, added = 0, missed = [];
    best.segs.forEach(function (s) {
      if (!s.r.length) { missed.push(s.w.join(" ")); return; }
      var sure = s.r[0].sc >= .74 && (s.r.length === 1 || s.r[0].sc - s.r[1].sc >= .1);
      if (sure) { vAdd(s.r[0].p, s.q); added++; } else if (!amb) amb = s; else missed.push(s.w.join(" "));
    });
    if (amb) vPick(amb);
    else if (!added) { vMiss(best.text); return; }
    else vState("ok", "✓ أُضيف — قل الصنف التالي أو «خلاص»");
    if (missed.length) toast("لم أجد: " + missed.join("، "), "warn");
  }
  function vMiss(t) { VS.last = VS.last || vWords(t).join(" "); beep(false); buzz([30, 40, 30]); vState("miss", "لم أجد صنفاً بهذا الاسم — أعد بصوت أوضح"); }
  function vAdd(p, q) {
    var u = defUnit(p); if (!u) return; q = q > 0 ? q : 1;
    add(p, u, q, null, null, false); beep();
    VS.log.unshift({ p: p, u: u, q: q }); vLog();
  }
  function vLog() {
    var e = vEl(".vlog"); if (!e) return;
    e.innerHTML = VS.log.slice(0, 6).map(function (x, i) {
      return '<div class="vl' + (i ? "" : " new") + '">' + pic(x.p.n, x.p.i, x.p.im, "ci", "") + '<span class="tx"><b>' + esc(x.p.n) + "</b><small>" + fq(x.q) + " × " + esc(x.u.n) + " · " + fm(priceOf(x.u)) + '</small></span><span class="vq">+' + fq(x.q) + '</span><button data-u="' + i + '" aria-label="تراجع">' + ic("x") + "</button></div>";
    }).join("") + (VS.log.length > 6 ? '<small class="vmore">و ' + (VS.log.length - 6) + " أخرى في السلة</small>" : "");
    $$("[data-u]", e).forEach(function (b) { b.onclick = function () { vUndo(+b.dataset.u); }; });
  }
  function vUndo(i) {
    i = i || 0; var x = VS.log[i]; if (!x) { vState("miss", "لا شيء للتراجع عنه"); return; }
    VS.log.splice(i, 1);
    var l = S.cart.filter(function (c) { return c.puid === x.u.id; })[0];
    if (l) { l.q = r2(l.q - x.q); if (l.q <= 0) S.cart.splice(S.cart.indexOf(l), 1); saveCart(); updateDock(true); paintQty(x.p.i); }
    buzz(20); vLog(); vState("ok", "↩ تم التراجع عن «" + esc(x.p.n) + "»");
  }
  function vPick(seg) {
    VS.pend = seg; beep(); buzz(20); vState("pick", "أي واحد تقصد؟ 👇");
    vRes('<div class="vpk"><small>' + fq(seg.q) + " × «" + esc(seg.w.join(" ")) + "»</small>" + seg.r.map(function (x, i) {
      var u = defUnit(x.p), s = +x.p.s || 0;
      return '<button class="cl" data-h="' + i + '">' + pic(x.p.n, x.p.i, x.p.im, "ci", "") + '<span class="tx"><b>' + esc(x.p.n) + "</b><small>" + esc(u ? u.n : "") + " · رصيد " + (s <= 0 ? "نفد" : fq(s)) + '</small></span><span class="bl">' + N(u ? priceOf(u) : 0) + "</span></button>";
    }).join("") + '<button class="vno" id="vno">لا شيء منها</button></div>');
    $$(".vpk .cl", VS.sh).forEach(function (b) { b.onclick = function () { var x = seg.r[+b.dataset.h]; VS.pend = null; vRes(""); vAdd(x.p, seg.q); vState("ok", "✓ أُضيف — قل الصنف التالي أو «خلاص»"); VS.idle = 0; setTimeout(vListen, 200); }; });
    var no = vEl("#vno"); if (no) no.onclick = function () { VS.pend = null; vRes(""); VS.idle = 0; vListen(); };
    if (VS.rec) try { VS.rec.stop(); } catch (e) { }
  }

  /* ------------------------------------------------------------ قارئ الباركود */
  var ZX = null, ZR = null, BD = null, STREAM = null, LOOP = 0;
  function zx() {
    if (ZX) return ZX;
    ZX = new Promise(function (ok, no) { var s = document.createElement("script"); s.src = BASE + "/m/zxing.js"; s.onload = function () { window.ZXing ? ok(window.ZXing) : no(); }; s.onerror = no; document.head.appendChild(s); })
      .then(function (Z) { var h = new Map(), F = Z.BarcodeFormat; h.set(Z.DecodeHintType.POSSIBLE_FORMATS, [F.EAN_13, F.EAN_8, F.UPC_A, F.UPC_E, F.CODE_128, F.CODE_39, F.ITF, F.QR_CODE]); h.set(Z.DecodeHintType.TRY_HARDER, true); ZR = new Z.MultiFormatReader(); ZR.setHints(h); return Z; });
    ZX.catch(function () { ZX = null; }); return ZX;
  }
  function detector() {
    if (BD !== null) return Promise.resolve(BD);
    try {
      if (!("BarcodeDetector" in window)) { BD = false; return Promise.resolve(false); }
      return BarcodeDetector.getSupportedFormats().then(function (s) { var f = ["ean_13", "ean_8", "upc_a", "upc_e", "code_128", "code_39", "itf", "qr_code"].filter(function (x) { return s.indexOf(x) >= 0; }); BD = f.length ? new BarcodeDetector({ formats: f }) : false; return BD; }, function () { BD = false; return false; });
    } catch (e) { BD = false; return Promise.resolve(false); }
  }
  function decodeCanvas(cv) {
    return detector().then(function (d) {
      if (d) return d.detect(cv).then(function (r) { return r && r[0] ? r[0].rawValue : null; }, function () { return null; });
      return null;
    }).then(function (r) {
      if (r) return r;
      return zx().then(function (Z) { try { return ZR.decode(new Z.BinaryBitmap(new Z.HybridBinarizer(new Z.HTMLCanvasElementLuminanceSource(cv)))).getText(); } catch (e) { return null; } }, function () { return null; });
    });
  }
  function decodeImage(file) {
    return new Promise(function (ok, no) { var u = URL.createObjectURL(file), im = new Image(); im.onload = function () { ok(im); }; im.onerror = no; im.src = u; }).then(function (img) {
      var tries = []; [1400, 900, 2000].forEach(function (W) { [0, 90].forEach(function (rot) { tries.push([W, rot]); }); });
      function next(i) {
        if (i >= tries.length) return Promise.resolve(null);
        var W = tries[i][0], rot = tries[i][1], s = Math.min(1, W / Math.max(img.naturalWidth, img.naturalHeight)), w = Math.round(img.naturalWidth * s), h = Math.round(img.naturalHeight * s);
        var cv = document.createElement("canvas"); cv.width = rot ? h : w; cv.height = rot ? w : h; var x = cv.getContext("2d");
        if (rot) { x.translate(h, 0); x.rotate(Math.PI / 2); } x.drawImage(img, 0, 0, w, h);
        return decodeCanvas(cv).then(function (r) { return r || next(i + 1); });
      }
      return next(0);
    });
  }
  function onCode(code, silent) {
    var live = $(".scan-last");
    if (byCode(code) && byCode(code).length > 1 && live) { stopLive(); closeSheet(true, true); }
    if (addCode(code, null, function (h) { var l = $(".scan-last"); if (l) l.innerHTML = "✓ <b>" + esc(h.p.n) + "</b> — في السلة " + fq(qtyOf(h.p.i)); })) return true;
    beep(false); buzz([40, 40, 40]); toast("باركود غير معروف: " + code, "bad"); return false;
  }
  function scan() {
    zx();
    if (window.isSecureContext && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) { liveScan(); return; }
    var f = $("#cam"); f.value = ""; f.click();
  }
  $("#cam").onchange = function () {
    var file = this.files && this.files[0]; if (!file) return;
    toast("جارٍ قراءة الباركود …", "warn");
    decodeImage(file).then(function (c) { if (c) onCode(c); else { beep(false); toast("لم يُقرأ الباركود — قرّب الكاميرا وأعد المحاولة", "bad"); } }, function () { toast("تعذّر فتح الصورة", "bad"); });
  };
  function liveScan() {
    var sh = sheet("مسح الباركود", "وجّه الكاميرا نحو الباركود — يُضاف تلقائياً", '<div class="scanv"><video playsinline muted></video><div class="fr"><i></i><i></i><i></i><i></i></div></div><div class="scan-last"></div>',
      '<button class="btn ghost" id="sdone" style="width:100%">تم</button>');
    var v = $("video", sh), last = "", lastAt = 0, cv = document.createElement("canvas");
    sheet._onClose = stopLive;
    $("#sdone", sh).onclick = function () { closeSheet(); go(S.cart.length ? "cart" : S.tab); };
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false }).then(function (st) {
      STREAM = st; v.srcObject = st; v.play().catch(function () { });
      (function tick() {
        if (!STREAM) return;
        if (v.videoWidth) {
          var w = v.videoWidth, h = v.videoHeight, cw = Math.round(w * .84), ch = Math.round(h * .6);
          cv.width = cw; cv.height = ch; cv.getContext("2d").drawImage(v, (w - cw) / 2, (h - ch) / 2, cw, ch, 0, 0, cw, ch);
          decodeCanvas(cv).then(function (r) { if (r && (r !== last || Date.now() - lastAt > 2500)) { last = r; lastAt = Date.now(); onCode(r); } LOOP = setTimeout(tick, 200); });
        } else LOOP = setTimeout(tick, 200);
      })();
    }, function () { closeSheet(true); var f = $("#cam"); f.value = ""; f.click(); });
  }
  function stopLive() { clearTimeout(LOOP); if (STREAM) { STREAM.getTracks().forEach(function (t) { t.stop(); }); STREAM = null; } }

  /* قارئ باركود بلوتوث/USB (لوحة مفاتيح): أحرف سريعة تنتهي بـ Enter */
  var kb = "", kbT = 0;
  document.addEventListener("keydown", function (e) {
    var a = document.activeElement; if (a && /INPUT|TEXTAREA|SELECT/.test(a.tagName)) return;
    if (!S.sid) return;
    var now = Date.now(); if (now - kbT > 60) kb = ""; kbT = now;
    if (e.key === "Enter") { if (kb.length >= 4) { e.preventDefault(); onCode(kb); } kb = ""; return; }
    if (e.key.length === 1) kb += e.key;
  });

  /* ------------------------------------------------------------ تشغيل */
  if (!K) { denied(); return; }
  if (S.sid) start(); else loginView();
  window.__ANP = { S: S, go: go, setCatalog: setCatalog, refresh: refreshStock, vow: vow, vFind: vFind, vSegs: vSegs, vWords: vWords, skel: skel, voice: voice, vHandle: vHandle, imgSync: imgSync, lanTry: lanTry };
})();
