/* ANOUER POS — عامل الخدمة (وضع الإنترنت فقط: /pos/)
   التطبيق يفتح حتى بدون إنترنت: الواجهة من الذاكرة ، البيانات من الهاتف (الأصناف المحفوظة + طابور البيع). */
var C = "anp-shell-v10", IMG = "anp-img-v1";
var SHELL = ["./", "m/app.css?v=13", "m/app.js?v=14", "m/icon.svg", "m/icon-192.png"];
self.addEventListener("install", function (e) {
  e.waitUntil(caches.open(C).then(function (c) { return Promise.all(SHELL.map(function (u) { return c.add(new Request(u, { cache: "reload" })).catch(function () { }); })); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener("activate", function (e) {
  e.waitUntil(caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return k !== C && k !== IMG; }).map(function (k) { return caches.delete(k); })); }).then(function () { return self.clients.claim(); }));
});
function timeout(p, ms) { return new Promise(function (ok, no) { var t = setTimeout(no, ms); p.then(function (r) { clearTimeout(t); ok(r); }, function (x) { clearTimeout(t); no(x); }); }); }
self.addEventListener("fetch", function (e) {
  var r = e.request; if (r.method !== "GET") return;
  var u = new URL(r.url); if (u.origin !== location.origin) return;
  var scope = new URL(self.registration.scope).pathname;          /* /pos/ */
  if (u.pathname.indexOf(scope) !== 0) return;
  var rest = u.pathname.slice(scope.length);
  if (rest.indexOf("api/") === 0) return;                          /* البيانات: التطبيق يتكفّل بها */
  if (rest === "img") {                                            /* صور الأصناف: من الذاكرة أولاً */
    e.respondWith(caches.open(IMG).then(function (c) { return c.match(r).then(function (hit) { return hit || fetch(r).then(function (res) { if (res.ok) c.put(r, res.clone()); return res; }); }); }));
    return;
  }
  if (r.mode === "navigate" || rest === "" || rest === "index.html") {   /* الصفحة: الشبكة أولاً (4 ث) ثم الذاكرة */
    e.respondWith(timeout(fetch(r), 4000).then(function (res) { if (res.ok) caches.open(C).then(function (c) { c.put("./", res.clone()); }); return res; })
      .catch(function () { return caches.open(C).then(function (c) { return c.match("./"); }).then(function (h) { return h || new Response("offline", { status: 503 }); }); }));
    return;
  }
  /* ملفات التطبيق: من الذاكرة فوراً ، وتُحدَّث في الخلفية */
  e.respondWith(caches.open(C).then(function (c) {
    return c.match(r).then(function (hit) {
      var net = fetch(r).then(function (res) { if (res.ok) c.put(r, res.clone()); return res; });
      return hit ? (net.catch(function () { }), hit) : net.catch(function () { return c.match(r, { ignoreSearch: true }); });
    });
  }));
});
