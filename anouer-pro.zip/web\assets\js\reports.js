/* ANOUER — «التقارير» مطابقة DEXEF ONE:
   الواجهة الرئيسية (بحث عن تقرير + 10 أقسام بوصفها)، صفحة القسم (المجموعات بأعمدة كما في DEXEF + الفرع + الفترة + اللوحة الجانبية:
   عام / نظرة عامة / ميزان الأستاذ العام / ميزان النقدية / ميزان البنوك / ميزان بطاقات الائتمان / ميزان العهد)،
   نوافذ معايير التقرير (البرتقالية) والتقارير كمستندات A4 بمعاينة DEXEF (طباعة، PDF، Excel، بحث، تكبير، صفحات)،
   والمقارنات (Pivot يومي/أسبوعي/شهري/ربع سنوي/سنوي + رسم بياني).
   البيانات: fm.rep.data (الفواتير وأسطرها وسندات الخزينة في الفترة) + العملاء/الموردين/الأصناف/الخزائن/مستندات الحسابات. */
(function () {
  "use strict";
  const H = window.__FH, RV = window.__RV, CAT = window.ANOUER_RPCAT;
  if (!H || !RV || !CAT) { console.warn("reports: __FH/__RV/الكتالوج غير متاح"); return; }
  const { esc, fmt, r2, num, say, today, tabOpen, tabClose, mkView, Dlg, ctxMenu, lsGet, lsSet, norm } = H;
  const HOST = () => !!(window.Anouer && Anouer.available && Anouer.call);
  const call = (a, p) => Anouer.call(a, p || {});
  const isUnknown = e => /غير معروف|Unknown|not supported|mock:/i.test(String(e && e.message || e));
  const A = () => window.__AC;
  const nf = v => { v = r2(+v || 0); return v < 0 ? "[" + fmt(-v) + "]" : fmt(v); };
  const pad = n => String(n).padStart(2, "0");
  const ymd = d => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  const dmy = s => { s = String(s || "").slice(0, 10); const p = s.split("-"); return p.length === 3 ? p[2] + "-" + p[1] + "-" + p[0] : s; };
  const MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
  const daysBetween = (a, b) => Math.round((new Date(String(b).slice(0, 10) + "T12:00:00") - new Date(String(a).slice(0, 10) + "T12:00:00")) / 864e5);

  /* ================================================================== الكتالوج */
  const TILES = CAT.tiles.map(t => ({ id: t[0], name: t[1], desc: t[2] }));
  const ROWS = CAT.rows.map(r => ({ id: r[0], cat: r[1], grp: r[2], go: r[3], vi: r[4], type: r[5], tags: r[6], frm: r[7], name: String(r[8]).replace(/\s+/g, " ").trim(), img: r[9], tbl: r[10], ent: r[11], perm: r[12] }));
  const byId = id => ROWS.find(r => r.id === id);

  /* ================================================================== أيقونات (بنفس رسم DEXEF) */
  const B = "#2b8ae6";
  const IC = {
    c2: `<svg viewBox="0 0 40 40" fill="none" stroke="${B}" stroke-width="2.2" stroke-linecap="round"><path d="M6 34h28"/><rect x="9" y="22" width="4" height="10"/><rect x="17" y="16" width="4" height="16"/><rect x="25" y="19" width="4" height="13"/></svg>`,
    c3: `<svg viewBox="0 0 40 40" fill="none" stroke="${B}" stroke-width="2.2" stroke-linejoin="round"><path d="M7 8h26v18H17l-7 6v-6H7z"/><path d="M12 14h16M12 19h11"/></svg>`,
    c4: `<svg viewBox="0 0 40 40" fill="none" stroke="${B}" stroke-width="2.2"><ellipse cx="20" cy="10" rx="10" ry="4"/><path d="M10 10v6c0 2.2 4.5 4 10 4s10-1.8 10-4v-6M10 16v6c0 2.2 4.5 4 10 4s10-1.8 10-4v-6M10 22v6c0 2.2 4.5 4 10 4s10-1.8 10-4v-6"/></svg>`,
    c5: `<svg viewBox="0 0 40 40" fill="none" stroke="${B}" stroke-width="2.2"><ellipse cx="18" cy="9" rx="11" ry="4"/><path d="M7 9v18c0 2.2 4.9 4 11 4M29 9v8M7 15c0 2.2 4.9 4 11 4s11-1.8 11-4M7 21c0 2.2 4.9 4 11 4"/><circle cx="29" cy="28" r="5"/><path d="M29 21v2M29 33v2M22 28h2M34 28h2"/></svg>`,
    c6: `<svg viewBox="0 0 40 40" fill="none" stroke="${B}" stroke-width="2.4"><circle cx="20" cy="13" r="7"/><path d="M7 35c1-8 6.5-12 13-12s12 4 13 12"/></svg>`,
    c7: `<svg viewBox="0 0 40 40" fill="none" stroke="${B}" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"><path d="M4 7h5l4 18h17l4-13H11"/><circle cx="15" cy="32" r="2"/><circle cx="28" cy="32" r="2"/><circle cx="30" cy="25" r="6" fill="#fff"/><path d="M27.5 25l2 2 3.5-4"/></svg>`,
    c8: `<svg viewBox="0 0 40 40" fill="none" stroke="${B}" stroke-width="2.2"><rect x="5" y="9" width="30" height="22" rx="2"/><circle cx="14" cy="18" r="3"/><path d="M9 26c.8-3 2.6-4.5 5-4.5s4.2 1.5 5 4.5M23 16h8M23 21h8M23 26h5"/></svg>`,
    c9: `<svg viewBox="0 0 40 40" fill="none" stroke="${B}" stroke-width="2.2" stroke-linejoin="round"><path d="M8 13h24l-2 21H10z"/><path d="M14 16v-5a6 6 0 0 1 12 0v5"/></svg>`,
    c10: `<svg viewBox="0 0 40 40" fill="none" stroke="${B}" stroke-width="2.2" stroke-linecap="round"><circle cx="20" cy="7" r="3.2"/><path d="M20 11v8M14 14l6 5 6-5"/><ellipse cx="12" cy="27" rx="6" ry="2.4"/><path d="M6 27v4c0 1.3 2.7 2.4 6 2.4s6-1.1 6-2.4v-4"/><ellipse cx="28" cy="27" rx="6" ry="2.4"/><path d="M22 27v4c0 1.3 2.7 2.4 6 2.4s6-1.1 6-2.4v-4"/></svg>`,
    c14: `<svg viewBox="0 0 40 40" fill="none" stroke="${B}" stroke-width="2.4" stroke-linecap="round"><path d="M33 20a13 13 0 1 1-4-9.4" stroke-dasharray="3 3"/><path d="M13 20l5 5 10-10"/></svg>`,
    invoice: `<svg viewBox="0 0 32 32" fill="none" stroke="${B}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><rect x="4" y="4" width="24" height="24" rx="3"/><path d="M8 22l5-6 4 3 7-9"/><circle cx="24" cy="10" r="1.6" fill="${B}"/></svg>`,
    rpt: `<svg viewBox="0 0 32 32"><g fill="none" stroke="${B}" stroke-width="2"><rect x="3" y="15" width="12" height="6" rx="1"/><rect x="17" y="15" width="12" height="6" rx="1"/><rect x="3" y="23" width="12" height="6" rx="1"/><rect x="17" y="23" width="12" height="6" rx="1"/></g><path d="M14 4l10 3-9 5" fill="none" stroke="${B}" stroke-width="2" stroke-linejoin="round"/></svg>`,
    sum: `<svg viewBox="0 0 32 32" fill="${B}"><rect x="5" y="15" width="3" height="12"/><rect x="10" y="8" width="3" height="19"/><rect x="15" y="12" width="3" height="15"/><rect x="20" y="6" width="3" height="21"/><rect x="25" y="14" width="3" height="13"/><g fill="#fff"><rect x="5" y="19" width="3" height="1.3"/><rect x="10" y="14" width="3" height="1.3"/><rect x="15" y="18" width="3" height="1.3"/><rect x="20" y="12" width="3" height="1.3"/><rect x="25" y="20" width="3" height="1.3"/></g></svg>`,
    sumwith: `<svg viewBox="0 0 32 32" fill="none" stroke="${B}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 10l7 16L26 5"/><path d="M19 9c3 1 5 3 6 5" stroke-width="1.8"/></svg>`,
    accounting: `<svg viewBox="0 0 32 32" fill="none" stroke="${B}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><path d="M3 24c4-1 7 2 11 2h9c2 0 2-3 0-3h-6"/><path d="M3 29c5-1 7 1 11 1h9l6-5"/><rect x="11" y="9" width="3" height="10"/><rect x="16" y="5" width="3" height="14"/><rect x="21" y="11" width="3" height="8"/></svg>`,
    chart: `<svg viewBox="0 0 32 32" fill="none" stroke="${B}" stroke-width="2.4" stroke-linejoin="round"><path d="M8 5l18 11L8 27z"/><path d="M8 5v22" stroke-width="3.4"/></svg>`,
    book: `<svg viewBox="0 0 32 32" fill="none" stroke="${B}" stroke-width="2" stroke-linejoin="round"><path d="M3 7h11a2 2 0 0 1 2 2v18a2 2 0 0 0-2-2H3zM29 7H18a2 2 0 0 0-2 2v18a2 2 0 0 1 2-2h11z"/><path d="M6 12h6M6 16h6M20 12h6M20 16h6M20 20h4"/></svg>`,
    list: `<svg viewBox="0 0 32 32" fill="none" stroke="${B}" stroke-width="2.2" stroke-linecap="round"><path d="M11 8h17M11 16h17M11 24h17"/><circle cx="5" cy="8" r="1.6" fill="${B}"/><circle cx="5" cy="16" r="1.6" fill="${B}"/><circle cx="5" cy="24" r="1.6" fill="${B}"/></svg>`,
    loss: `<svg viewBox="0 0 32 32" fill="none" stroke="#d84b4b" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8l8 8 5-5 11 11"/><path d="M22 22h6v-6"/></svg>`,
    back: `<svg viewBox="0 0 24 24" fill="none" stroke="#1f7ad8" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M10 7l5 5-5 5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    s_gen: `<svg viewBox="0 0 28 28"><rect x="6" y="4" width="16" height="20" rx="1.5" fill="#fff" stroke="#c9cfd6"/><path d="M9 9h10M9 13h10M9 17h10M9 21h6" stroke="#7c8794" stroke-width="1.6"/></svg>`,
    s_ov: `<svg viewBox="0 0 28 28"><rect x="5" y="15" width="4" height="9" fill="#f2a10f"/><rect x="11" y="9" width="4" height="15" fill="#2e8b57"/><rect x="17" y="5" width="4" height="19" fill="#e2402b"/><rect x="23" y="12" width="3" height="12" fill="#1f7ad8"/></svg>`,
    /* أيقونات قسم المخازن (مثل DEXEF ONE) */
    w_gen: `<svg viewBox="0 0 28 28"><rect x="6" y="4" width="16" height="20" rx="2" fill="#f97316"/><path d="M10 10h8M10 14h8M10 18h5" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>`,
    w_ov: `<svg viewBox="0 0 28 28"><rect x="4" y="16" width="4" height="8" rx="1" fill="#9db7d8"/><rect x="10" y="11" width="4" height="13" rx="1" fill="#9db7d8"/><rect x="16" y="6" width="4" height="18" rx="1" fill="#9db7d8"/><rect x="22" y="13" width="3" height="11" rx="1" fill="#9db7d8"/></svg>`,
    w_mv: `<svg viewBox="0 0 28 28"><rect x="3" y="5" width="18" height="3.5" rx="1" fill="#1f6fd6"/><rect x="3" y="10.5" width="7" height="3" fill="#9db7d8"/><rect x="11.5" y="10.5" width="9.5" height="3" fill="#9db7d8"/><rect x="3" y="15.5" width="7" height="3" fill="#9db7d8"/><path d="M19 15h7l-4 4.5 4 4.5h-7" fill="none" stroke="#1f6fd6" stroke-width="2" stroke-linejoin="round"/></svg>`,
    w_bal: `<svg viewBox="0 0 28 28"><rect x="3" y="13" width="4" height="9" fill="#1f6fd6"/><rect x="9" y="8" width="4" height="14" fill="#1f6fd6"/><rect x="15" y="4" width="4" height="8" fill="#1f6fd6"/><path d="M17 15h8l-4.5 4.5L25 24h-8" fill="none" stroke="#f97316" stroke-width="2" stroke-linejoin="round"/></svg>`,
    w_np: `<svg viewBox="0 0 28 28"><path d="M5 9l8-4 8 4v9l-8 4-8-4z" fill="#3b6fd0"/><path d="M5 9l8 4 8-4M13 13v9" stroke="#fff" stroke-width="1.2" fill="none" opacity=".7"/><circle cx="21" cy="20" r="5" fill="#16a34a"/><path d="M18.6 20l1.7 1.7 3.2-3.4" stroke="#fff" stroke-width="1.8" fill="none" stroke-linecap="round"/></svg>`,
    w_ns: `<svg viewBox="0 0 28 28"><rect x="5" y="3" width="15" height="19" rx="1.5" fill="#fff" stroke="#334155" stroke-width="1.6"/><path d="M8 8h9M8 11.5h9M8 15h6" stroke="#334155" stroke-width="1.4"/><path d="M14 25l4-5 3 2 5-6" fill="none" stroke="#16a34a" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    w_cmp: `<svg viewBox="0 0 28 28"><rect x="6" y="3" width="12" height="4" rx="1" fill="#22a06b"/><rect x="10" y="9" width="14" height="4" rx="1" fill="#f97316"/><rect x="4" y="15" width="12" height="4" rx="1" fill="#22a06b"/><rect x="9" y="21" width="9" height="4" rx="1" fill="#f97316"/></svg>`,
    w_fix: `<svg viewBox="0 0 28 28"><rect x="4" y="4" width="18" height="18" rx="2" fill="#fff" stroke="#1f6fd6" stroke-width="1.8"/><g fill="#1f6fd6"><rect x="8" y="8" width="3" height="3"/><rect x="12.5" y="8" width="3" height="3"/><rect x="17" y="8" width="3" height="3" opacity=".5"/><rect x="8" y="12.5" width="3" height="3"/><rect x="12.5" y="12.5" width="3" height="3"/><rect x="8" y="17" width="3" height="3" opacity=".5"/></g><path d="M21 18v7m0 0l-2.5-2.5M21 25l2.5-2.5" stroke="#1f6fd6" stroke-width="1.8" fill="none" stroke-linecap="round"/></svg>`,
    w_short: `<svg viewBox="0 0 28 28"><path d="M6 11l9-6 7 5-9 6z" fill="#c4cad3"/><path d="M6 11l7 5v8l-7-5z" fill="#9aa3af"/><path d="M13 16l9-6v8l-9 6z" fill="#b5bcc6"/><path d="M20 19c0 2 1.5 3 1.5 4.5a1.5 1.5 0 01-3 0C18.5 22 20 21 20 19z" fill="#e2402b"/></svg>`,
    s_gl: `<svg viewBox="0 0 28 28"><rect x="4" y="5" width="20" height="3" fill="#1f7ad8"/><rect x="4" y="10" width="20" height="3" fill="#2e8b57"/><rect x="4" y="15" width="20" height="3" fill="#1f7ad8"/><rect x="4" y="20" width="20" height="3" fill="#2e8b57"/></svg>`,
    s_cash: `<svg viewBox="0 0 28 28"><rect x="5" y="4" width="16" height="20" rx="1" fill="#fff" stroke="#333" stroke-width="1.6"/><path d="M8 9h10M8 13h10M8 17h6" stroke="#333" stroke-width="1.4"/><path d="M14 24l10-8v8z" fill="#2e8b57"/></svg>`,
    s_bank: `<svg viewBox="0 0 28 28"><ellipse cx="14" cy="7" rx="8" ry="3" fill="#f2a10f"/><path d="M6 7v12c0 1.7 3.6 3 8 3s8-1.3 8-3V7" fill="#f6b84a"/><path d="M6 12c0 1.7 3.6 3 8 3s8-1.3 8-3M6 16c0 1.7 3.6 3 8 3s8-1.3 8-3" fill="none" stroke="#e27c0c" stroke-width="1.2"/><rect x="5" y="22" width="18" height="3" fill="#2e8b57"/></svg>`,
    s_visa: `<svg viewBox="0 0 28 28"><g fill="#1f7ad8"><rect x="3" y="6" width="6" height="4"/><rect x="11" y="6" width="6" height="4"/><rect x="19" y="6" width="6" height="4"/><rect x="3" y="12" width="6" height="4"/><rect x="11" y="12" width="6" height="4"/><rect x="3" y="18" width="6" height="4"/></g><text x="21" y="24" font-size="11" font-weight="700" fill="#1f7ad8" font-family="Arial">Σ</text></svg>`,
    s_emp: `<svg viewBox="0 0 28 28"><rect x="4" y="5" width="18" height="18" rx="1.5" fill="none" stroke="#1f7ad8" stroke-width="1.8"/><g fill="#1f7ad8"><rect x="7" y="9" width="3" height="3"/><rect x="12" y="9" width="3" height="3"/><rect x="17" y="9" width="3" height="3"/><rect x="7" y="14" width="3" height="3"/><rect x="12" y="14" width="3" height="3"/></g><path d="M21 17v8M17 21l4 4 4-4" fill="none" stroke="#1f7ad8" stroke-width="1.8"/></svg>`,
    print: '<svg viewBox="0 0 18 18"><rect x="5" y="2" width="8" height="4" fill="#7d8da3"/><rect x="1.5" y="6" width="15" height="7" rx="1.5" fill="#5c6b80"/><rect x="5" y="11" width="8" height="5" fill="#fff" stroke="#5c6b80"/></svg>',
    qprint: '<svg viewBox="0 0 18 18"><rect x="1.5" y="6" width="15" height="7" rx="1.5" fill="#5c6b80"/><rect x="5" y="11" width="8" height="5" fill="#fff" stroke="#5c6b80"/><path d="M9 1l-3 4h6z" fill="#e2402b"/></svg>',
    pdf: '<svg viewBox="0 0 18 18"><path d="M4 1h7l4 4v12H4z" fill="#fff" stroke="#c0392b"/><rect x="2" y="9" width="11" height="5" rx="1" fill="#c0392b"/><text x="7.5" y="13" font-size="4.2" text-anchor="middle" fill="#fff" font-family="Arial" font-weight="700">PDF</text></svg>',
    xls: '<svg viewBox="0 0 18 18"><rect x="7" y="2" width="10" height="14" rx="1" fill="#1d7a46"/><rect x="1" y="4" width="9" height="10" rx="1" fill="#21a366"/><path d="M3 6.5l4.5 5M7.5 6.5L3 11.5" stroke="#fff" stroke-width="1.5"/></svg>',
    find: '<svg viewBox="0 0 18 18"><circle cx="7.5" cy="7.5" r="5" fill="none" stroke="#33414f" stroke-width="1.8"/><path d="M11.5 11.5l5 5" stroke="#33414f" stroke-width="2.2" stroke-linecap="round"/></svg>',
    thumbs: '<svg viewBox="0 0 18 18" fill="none" stroke="#33414f" stroke-width="1.4"><rect x="2" y="2" width="6" height="6"/><rect x="10" y="2" width="6" height="6"/><rect x="2" y="10" width="6" height="6"/><rect x="10" y="10" width="6" height="6"/></svg>',
    zin: '<svg viewBox="0 0 18 18"><circle cx="7.5" cy="7.5" r="5" fill="none" stroke="#33414f" stroke-width="1.6"/><path d="M5 7.5h5M7.5 5v5" stroke="#33414f" stroke-width="1.6"/><path d="M11.5 11.5l5 5" stroke="#33414f" stroke-width="2"/></svg>',
    zout: '<svg viewBox="0 0 18 18"><circle cx="7.5" cy="7.5" r="5" fill="none" stroke="#33414f" stroke-width="1.6"/><path d="M5 7.5h5" stroke="#33414f" stroke-width="1.6"/><path d="M11.5 11.5l5 5" stroke="#33414f" stroke-width="2"/></svg>',
    first: '<svg viewBox="0 0 16 16"><path d="M11 3L6 8l5 5zM4 3h1.6v10H4z" fill="#1f7ad8"/></svg>',
    prev: '<svg viewBox="0 0 16 16"><path d="M10 3L5 8l5 5z" fill="#1f7ad8"/></svg>',
    next: '<svg viewBox="0 0 16 16"><path d="M6 3l5 5-5 5z" fill="#1f7ad8"/></svg>',
    last: '<svg viewBox="0 0 16 16"><path d="M5 3l5 5-5 5zM10.4 3H12v10h-1.6z" fill="#1f7ad8"/></svg>',
    close: '<svg viewBox="0 0 18 18"><circle cx="9" cy="9" r="8" fill="#e2402b"/><path d="M6 6l6 6M12 6l-6 6" stroke="#fff" stroke-width="1.8"/></svg>',
    gear: '<svg viewBox="0 0 18 18"><circle cx="9" cy="9" r="3" fill="none" stroke="#1f7ad8" stroke-width="2"/><path d="M9 1.5v3M9 13.5v3M1.5 9h3M13.5 9h3M3.7 3.7l2.1 2.1M12.2 12.2l2.1 2.1M3.7 14.3l2.1-2.1M12.2 5.8l2.1-2.1" stroke="#1f7ad8" stroke-width="2" stroke-linecap="round"/></svg>',
    wa: '<svg viewBox="0 0 18 18"><circle cx="9" cy="9" r="8" fill="#25d366"/><path d="M5 13.5l.7-2.4A4.3 4.3 0 1 1 7.7 13z" fill="none" stroke="#fff" stroke-width="1.2"/></svg>'
  };
  const imgIcon = r => IC[r.img] || (r.frm === "FrmBillPivot" ? IC.invoice : IC.sum);

  /* ================================================================== الفترات (CtlTopSearch) */
  const PERS = ["اليوم", "أمس", "الأسبوع الحالى", "الأسبوع السابق", "الشهر الحالى", "الشهر السابق", "الثلاث شهور السابقة", "السنة الحالية", "العام السابق الى الان", "الكل", "فترة محددة"];
  function perRange(i, custom) {
    const t = new Date(today() + "T12:00:00"), d = new Date(t);
    const S = x => ymd(x);
    switch (PERS[i]) {
      case "اليوم": return [S(t), S(t)];
      case "أمس": d.setDate(d.getDate() - 1); return [S(d), S(d)];
      case "الأسبوع الحالى": d.setDate(d.getDate() - ((d.getDay() + 1) % 7)); return [S(d), S(t)];   // يبدأ السبت
      case "الأسبوع السابق": { d.setDate(d.getDate() - ((d.getDay() + 1) % 7) - 7); const e = new Date(d); e.setDate(e.getDate() + 6); return [S(d), S(e)]; }
      case "الشهر الحالى": d.setDate(1); return [S(d), S(t)];
      case "الشهر السابق": { d.setDate(1); d.setMonth(d.getMonth() - 1); const e = new Date(d.getFullYear(), d.getMonth() + 1, 0, 12); return [S(d), S(e)]; }
      case "الثلاث شهور السابقة": d.setDate(1); d.setMonth(d.getMonth() - 3); return [S(d), S(t)];
      case "السنة الحالية": return [t.getFullYear() + "-01-01", S(t)];
      case "العام السابق الى الان": return [(t.getFullYear() - 1) + "-01-01", S(t)];
      case "الكل": return ["2000-01-01", S(t)];
      default: return custom || [S(t), S(t)];
    }
  }
  const PKEY = "rp.per";
  let PRESET = null;   // فترة شاشة المراجعة (عدسة «عدد التعاملات» …) تُطبّق على أول نافذة معايير
  const PER0 = () => { const s = lsGet(PKEY, null); return s && typeof s.i === "number" ? Object.assign({ ft: T0, tt: T1 }, s) : { i: 6, ft: T0, tt: T1 }; };
  function hijri(d) { try { const p = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura-nu-latn", { day: "numeric", month: "numeric", year: "numeric" }).formatToParts(new Date(d + "T12:00:00")); const g = k => (p.find(x => x.type === k) || {}).value || ""; return [g("day"), g("month"), g("year").replace(/\D/g, "")]; } catch (e) { return ["", "", ""]; } }
  /* الوقت داخل الفترة (مثل DEXEF: من 12:00 ص الى 11:59 م) */
  const T0 = "00:00", T1 = "23:59";
  const hm12 = t => { const [h, m] = String(t || T0).split(":").map(Number); return (h % 12 || 12) + ":" + pad(m || 0) + " " + (h < 12 ? "ص" : "م"); };
  let TW = null;   // نافذة الوقت للتقرير الجاري: {from,to,ft,tt}
  /* منتقي الفترة بنمط DEXEF: قائمة «فترة العرض» تفتح لوحة: فترة العرض + من التاريخ / الى التاريخ (+ هجري) + موافق */
  function perPicker(host, o) {
    o = o || {}; const st = Object.assign({}, PER0(), o.init || (PRESET != null ? { i: PRESET, r: null } : {}));
    if (!o.init && PRESET != null) PRESET = null;
    if (!st.r) st.r = perRange(st.i, st.c);
    host.innerHTML = `<span class="rp-per"><button type="button" class="rp-perb"><span>${esc(PERS[st.i])}</span><i>▾</i></button></span>`;
    const btn = host.querySelector("button");
    if (!st.ft) st.ft = T0; if (!st.tt) st.tt = T1;
    const lbl = () => PERS[st.i] + (st.ft !== T0 || st.tt !== T1 ? " · " + hm12(st.ft) + " ← " + hm12(st.tt) : "");
    btn.querySelector("span").textContent = lbl();
    const P = { get: () => ({ i: st.i, from: st.r[0], to: st.r[1], ft: st.ft, tt: st.tt, label: PERS[st.i] }), set(i, r, ft, tt) { st.i = i; st.r = r || perRange(i); st.ft = ft || T0; st.tt = tt || T1; btn.querySelector("span").textContent = lbl(); } };
    let pop = null;
    const close = () => { if (pop) { pop.remove(); pop = null; document.removeEventListener("mousedown", out, true); } };
    const out = e => { if (pop && !pop.contains(e.target) && !host.contains(e.target)) close(); };
    btn.addEventListener("click", () => {
      if (pop) { close(); return; }
      pop = document.createElement("div"); pop.className = "rp-perpop";
      const hj = d => hijri(d).map((x, i) => `<input readonly value="${x}" class="${i === 2 ? "y" : ""}">`).join("");
      pop.innerHTML = `<div class="r"><span class="lb">فترة العرض</span><select>${PERS.map((p, i) => `<option value="${i}"${i === st.i ? " selected" : ""}>${esc(p)}</option>`).join("")}</select></div>
        <div class="hh"><span></span><span>الساعة</span><span>هجري</span></div>
        <div class="r"><span class="lb">من التاريخ</span><input type="date" data-k="f" value="${st.r[0]}"><span class="tm"><input type="time" data-k="ft" value="${st.ft}" step="60" aria-label="من الساعة"></span><span class="hj" data-h="f">${hj(st.r[0])}</span></div>
        <div class="r"><span class="lb">الى التاريخ</span><input type="date" data-k="t" value="${st.r[1]}"><span class="tm"><input type="time" data-k="tt" value="${st.tt}" step="60" aria-label="الى الساعة"></span><span class="hj" data-h="t">${hj(st.r[1])}</span></div>
        <div class="tmh"><button type="button" data-tm="day">اليوم كاملاً 12:00 ص ← 11:59 م</button><button type="button" data-tm="night" title="يوم عمل يمتد بعد منتصف الليل: من 6 صباحاً إلى 5:59 صباح اليوم التالي">يوم عمل حتى بعد منتصف الليل</button></div>
        <div class="ft"><button type="button" class="rp-ok">موافق</button><button type="button" class="rp-x" title="مسح">✕</button></div>`;
      document.body.appendChild(pop);
      const r = btn.getBoundingClientRect(), w = pop.offsetWidth;
      pop.style.left = Math.max(4, Math.min(innerWidth - w - 4, r.left)) + "px"; pop.style.top = (r.bottom + 2) + "px";
      const sel = pop.querySelector("select"), f = pop.querySelector('[data-k="f"]'), t = pop.querySelector('[data-k="t"]'), fT = pop.querySelector('[data-k="ft"]'), tT = pop.querySelector('[data-k="tt"]');
      const nextDay = d => { const x = new Date(d + "T12:00:00"); x.setDate(x.getDate() + 1); return ymd(x); };
      const prevDay = d => { const x = new Date(d + "T12:00:00"); x.setDate(x.getDate() - 1); return ymd(x); };
      const isNight = () => fT.value === "06:00" && tT.value === "05:59";
      /* اليوم كاملاً: 12:00 ص ← 11:59 م (يرجع «الى» يوماً إن كان على يوم العمل الليلي) */
      pop.querySelector('[data-tm="day"]').addEventListener("click", () => { if (isNight() && t.value > f.value) t.value = prevDay(t.value); fT.value = T0; tT.value = T1; upH(); });
      /* يوم عمل يتجاوز منتصف الليل: من 6:00 ص يوم «من» إلى 5:59 ص بعد آخر يوم في الفترة */
      pop.querySelector('[data-tm="night"]').addEventListener("click", () => { if (!isNight()) t.value = nextDay(t.value || f.value); fT.value = "06:00"; tT.value = "05:59"; sel.value = String(PERS.length - 1); upH(); });
      const upH = () => { pop.querySelector('[data-h="f"]').innerHTML = hj(f.value); pop.querySelector('[data-h="t"]').innerHTML = hj(t.value); };
      sel.addEventListener("change", () => { const rr = perRange(+sel.value, [f.value, t.value]); f.value = rr[0]; t.value = rr[1]; fT.value = T0; tT.value = T1; upH(); });
      [f, t].forEach(x => x.addEventListener("change", () => { sel.value = String(PERS.length - 1); upH(); }));
      pop.querySelector(".rp-ok").addEventListener("click", () => {
        const a = f.value || today(), b = t.value || today(), fa = fT.value || T0, tb = tT.value || T1;
        if (a + " " + fa > b + " " + tb) { say("«من» بعد «الى» — صحّح التاريخ أو الساعة", "w"); return; }
        P.set(+sel.value, [a, b], fa, tb); if (!o.noSave) lsSet(PKEY, { i: st.i, c: st.r, ft: st.ft, tt: st.tt }); close(); if (o.onChange) o.onChange(P.get()); });
      pop.querySelector(".rp-x").addEventListener("click", () => { sel.value = "6"; sel.dispatchEvent(new Event("change")); });
      [fT, tT].forEach(x => x.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); pop.querySelector(".rp-ok").click(); } }));
      setTimeout(() => document.addEventListener("mousedown", out, true), 0);
    });
    return P;
  }
  /* الفروع والمخازن */
  let BRS = null;
  function branches() {
    if (BRS) return Promise.resolve(BRS);
    const p = HOST() ? call("fm.branches.list").then(l => (l || []).filter(b => b.IsActive !== false).map(b => b.Name)).catch(() => null) : Promise.resolve(null);
    return p.then(l => (BRS = l && l.length ? l : (RV.BR || ["الفرع الرئيسي"]).slice(0, 1)));
  }
  const brSel = (v) => `<select data-k="br">${(BRS || ["الفرع الرئيسي"]).map(b => `<option${b === v ? " selected" : ""}>${esc(b)}</option>`).join("")}</select>`;
  function stores() {
    const W = window.ANOUER_WH; const l = W && W.list ? W.list.filter(x => x.active !== false) : [];
    return l.length ? l.map(x => ({ id: x.id, name: x.name, main: W.isMain ? W.isMain(x.id) : false })) : [{ id: 0, name: "المخزن الرئيسي", main: true }];
  }
  const storeName = id => { const s = stores().find(x => String(x.id) === String(id) || (!id && x.main)); return s ? s.name : "المخزن الرئيسي"; };

  /* ================================================================== البيانات */
  const DC = {};
  let REP_NEW = true;
  const TYPE = { Sale: "مبيعات", SaleReturn: "مرتجع مبيعات", Purchase: "مشتريات", PurchaseReturn: "مرتجع مشتريات", PurchaseOrder: "طلبية شراء", SaleOrder: "أمر بيع", Quotation: "عرض سعر", SupplyOrder: "أمر توريد", StockIn: "إذن استلام", StockOut: "إذن صرف", Transfer: "تحويلات المخازن", Opening: "مخزون أول المدة", Waste: "هالك المخزون", Charity: "صدقات", Adjust: "التسويات الجردية", Reserve: "حجز بضاعة" };
  const SIGN = { Sale: -1, SaleReturn: 1, Purchase: 1, PurchaseReturn: -1, StockIn: 1, StockOut: -1, Opening: 1, Waste: -1, Charity: -1, Adjust: 1 };   // أثر المخزون
  function normData(d) {
    const inv = (d.inv || []).map(x => ({ id: x[0], no: x[1], t: x[2], dt: x[3], date: String(x[3]).slice(0, 10), time: String(x[3]).slice(11, 16), pk: x[4], pid: x[5], pname: x[6] || (x[4] ? "" : "تعامل نقدى"), user: x[7] || "", br: x[8] || "", wh: x[9] || 0, gross: +x[10] || 0, disc: +x[11] || 0, extra: +x[12] || 0, tax: +x[13] || 0, total: +x[14] || 0, paid: +x[15] || 0, due: x[16] || "", ref: x[17] || "", notes: x[18] || "", pcode: x[19] || "", towh: x[20] || 0, lines: [] }));
    const byI = {}; inv.forEach(v => byI[v.id] = v);
    const ln = (d.ln || []).map(x => ({ iid: x[0], pid: x[1], code: x[2], name: x[3], cat: x[4] || "", unit: x[5] || "", fac: +x[6] || 1, qty: +x[7] || 0, price: +x[8] || 0, disc: +x[9] || 0, tax: +x[10] || 0, total: +x[11] || 0, cost: +x[12] || 0, bc: x[13] || "" }));
    ln.forEach(l => { const v = byI[l.iid]; if (v) { l.inv = v; v.lines.push(l); } });
    const cv = (d.cv || []).map(x => ({ id: x[0], no: x[1], type: x[2], tr: x[3] || "", cid: x[4], party: x[5] || "", amt: +x[6] || 0, dt: x[7], date: String(x[7]).slice(0, 10), time: String(x[7]).slice(11, 16), notes: x[8] || "", user: x[9] || "", trid: x[10] }));
    return { from: d.from, to: d.to, inv, ln, cv, lines: d.lines !== false };
  }
  /* المعاينة / مضيف قديم: من بيانات الصفحة */
  function localData(from, to) {
    const S = (window.SALES_DATA || []).filter(s => s.date >= from && s.date <= to);
    const inv = S.map((s, i) => [s.id || i + 1, String(s.no), s.ret ? "SaleReturn" : "Sale", s.date + " " + (s.time24 || "10:00"), s.name && s.name !== "تعامل نقدى" ? "c" : "", 0, s.name || "", s.user || "", "", 0, +s.before || +s.total || 0, +s.disc || 0, 0, +s.tax || 0, +s.total || 0, +s.paid || 0, "", "", "", "", 0]);
    return { from, to, inv, ln: [], cv: [], lines: false };
  }
  /* مضيف قبل إعادة البناء (بدون fm.rep.data): رؤوس الفواتير من invoices.list + أسطرها من invoices.detail على دفعات متوازية */
  let DPROG = null;
  /* تاريخ المضيف (JavaScriptSerializer يرسل "/Date(ms)/") ← "yyyy-MM-dd HH:mm" */
  const hd = v => { const m = /\/Date\((-?\d+)/.exec(String(v || "")); if (m) { const d = new Date(+m[1]); return ymd(d) + " " + pad(d.getHours()) + ":" + pad(d.getMinutes()); } return String(v || "").replace("T", " ").slice(0, 16); };
  function legacyData(from, to) {
    return call("invoices.list", { from, to, top: 20000 }).then(l => {
      l = l || [];
      const P = (H.prods && H.prods()) || [], byCode = {}, byPid = {}; P.forEach(p => { byCode[p.code] = p; byPid[p.id] = p; });
      return Promise.all([parties("cu").catch(() => []), parties("su").catch(() => [])]).then(([cu, su]) => {
        const cuN = {}, suN = {}; cu.forEach(c => cuN[c.name] = c); su.forEach(x => suN[x.name] = x);
        const inv = l.map(r => { const t = r.TypeCode || (r.Direction > 0 ? "SaleReturn" : "Sale"), pur = /^Purchase/.test(t), nm = r.PartyName || "", pp = pur ? suN[nm] : cuN[nm];
          return [r.InvoiceId, r.InvoiceNo, t, hd(r.InvoiceDate), pp ? (pur ? "s" : "c") : "", pp ? pp.id : 0, nm, "", "", 0, +r.TotalBeforeDiscount || 0, +r.DiscountTotal || 0, 0, +r.TaxTotal || 0, +r.GrandTotal || 0, +r.PaidTotal || 0, "", "", "", pp ? pp.no : "", 0]; });
        const ln = [], ids = l.filter(r => r.ItemCount !== 0).map(r => r.InvoiceId).slice(0, 5000); let i = 0, done = 0;
        const one = () => { if (i >= ids.length) return Promise.resolve(); const id = ids[i++];
          return call("invoices.detail", { id }).then(d => { ((d && d.Lines) || []).forEach(x => {
              const p = byPid[x.ProductId] || byCode[x.ProductCode], u = p && (p._u || []).find(z => z.name === x.UnitName), fac = u ? (+u.factor || 1) : 1, qty = +x.Qty || 0;
              const tot = x.LineTotal != null ? +x.LineTotal : qty * (+x.UnitPrice || 0) - (+x.LineDiscount || 0);
              ln.push([id, x.ProductId, x.ProductCode || "", x.ProductName || "", p ? p.cat || "" : "", x.UnitName || "", fac, qty, +x.UnitPrice || 0, +x.LineDiscount || 0, +x.LineTax || 0, tot, r2((p ? +p.cost || 0 : 0) * fac * qty), ""]); }); })
            .catch(() => { }).then(() => { done++; if (DPROG) DPROG(done, ids.length); return one(); }); };
        /* سندات الخزينة (treasury.vouchers لكل خزينة) */
        const cvP = (A() ? A().accounts("tr", true).catch(() => []) : Promise.resolve([])).then(trs => Promise.all(trs.map(t => call("treasury.vouchers", { treasuryId: t.id, from, to, type: "" }).then(res => ((res && res.Items) || []).map(c => [c.VoucherId, c.VoucherNo, c.Type, t.name, c.CustomerId || 0, c.PartyName || c.CustomerName || "", +c.Amount || 0, hd(c.VoucherDate), c.Notes || "", "", t.id])).catch(() => [])))).then(ls => [].concat(...ls)).catch(() => []);
        return Promise.all([Promise.all(Array.from({ length: 8 }, one)), cvP]).then(([, cv]) => ({ from, to, lines: true, legacy: true, inv, ln, cv }));
      });
    });
  }
  /* الفترة بالساعة: يُبقي الفواتير والسندات بين «من التاريخ + الساعة» و«الى التاريخ + الساعة» بالدقيقة */
  function withTime(p, from, to) {
    const w = TW; if (!w || w.from !== from || w.to !== to) return p;
    const lo = from + " " + w.ft, hi = to + " " + w.tt, inW = dt => { const s = String(dt || "").replace("T", " ").slice(0, 16); return s.length < 16 || (s >= lo && s <= hi); };
    return p.then(D => { const inv = D.inv.filter(x => inW(x.dt)), keep = new Set(inv.map(x => x.id));
      return Object.assign({}, D, { inv, ln: D.ln.filter(l => keep.has(l.iid)), cv: D.cv.filter(c => inW(c.dt)), ft: w.ft, tt: w.tt }); });
  }
  function data(from, to) {
    const k = from + "|" + to;
    if (DC[k] && Date.now() - DC[k].at < 90000) return withTime(DC[k].p, from, to);
    let p;
    if (HOST() && REP_NEW) p = call("fm.rep.data", { from, to, lines: true }).catch(e => {
      if (!isUnknown(e)) throw e; REP_NEW = false;
      return legacyData(from, to).catch(() => localData(from, to));
    });
    else if (HOST()) p = legacyData(from, to).catch(() => localData(from, to));
    else p = Promise.resolve(localData(from, to));
    p = p.then(normData);
    DC[k] = { at: Date.now(), p };
    p.catch(() => delete DC[k]);
    return withTime(p, from, to);
  }
  function parties(side) { const AC = A(); return AC ? AC.parties(side, true) : Promise.resolve([]); }
  /* الأصناف الحالية (نفس قائمة شاشة المبيعات/الفهرس — products) */
  function products() {
    const P = (H.prods && H.prods()) || [];
    return Promise.resolve(P.map(p => ({ id: p.id, code: p.code || "", name: p.name || "", cat: p.cat || p.category || p.group || "", unit: (p._d && p._d.name) || p.unit || "قطعة", stock: +p.stock || 0, cost: +p.cost || 0, price: +p.price || 0, min: +p.min || +p.reorder || 0, max: +p.max || 0, active: p.active !== false, units: p._u || [], type: p.type || p.itemType || "مخزني", added: p.created || p.createdAt || "", supplier: p.supplier || p.vendor || "" })));
  }
  const filt = (o, inv) => (!o.br || !inv.br || inv.br === o.br) && (o.wh == null || o.wh === "*" || String(inv.wh || 0) === String(o.wh) || (!inv.wh && stores().some(s => s.main && String(s.id) === String(o.wh))));
  const typesOf = (r) => {
    if (r.types && r.types.length) return r.types.slice();   // تقارير شاشات المراجعة (عروض الأسعار، أوامر التوريد، طلبات الشراء …)
    const n = r.name, t = r.tags;
    const pur = /مشتري|شراء|Purchase/.test(n + t + r.tbl), ret = /مرتجع|ReSale|RePurchase/.test(n + t + r.tbl), net = /صافي|صافى|Net/.test(n + t);
    if (pur) return net ? ["Purchase", "PurchaseReturn"] : ret ? ["PurchaseReturn"] : ["Purchase"];
    return net ? ["Sale", "SaleReturn"] : ret ? ["SaleReturn"] : ["Sale"];
  };
  const isRet = t => t === "SaleReturn" || t === "PurchaseReturn";
  const sg = v => isRet(v.t) ? -1 : 1;
  /* أبعاد التصفية / الترتيب (CtlBillFilterBy / CtlBillOrderBy) */
  const FIELDS = [["pname", "الاسم"], ["no", "الرقم"], ["user", "المستخدم"], ["date", "التاريخ"], ["total", "الصافي"], ["gross", "الاجمالي"], ["disc", "الخصم"], ["paid", "المدفوع"], ["rem", "الباقي"], ["notes", "الملاحظات"], ["ref", "رقم المرجع"]];
  const LFIELDS = [["name", "اسم الصنف"], ["code", "الكود"], ["cat", "المجموعة"], ["qty", "الكمية"], ["val", "القيمة"]];
  function applyOF(list, o, fields) {
    let l = list;
    if (o.fk && o.fv) { const q = norm(o.fv); l = l.filter(x => norm(String(x[o.fk] == null ? "" : x[o.fk])).includes(q)); }
    if (o.ok) { const k = o.ok, d = o.od === "desc" ? -1 : 1; l = l.slice().sort((a, b) => { const x = a[k], y = b[k]; return (typeof x === "number" && typeof y === "number" ? x - y : String(x || "").localeCompare(String(y || ""), "ar")) * d; }); }
    return l;
  }

  /* ================================================================== المستند (صفحات A4 بنمط تقارير DEXEF) */
  const PG = { w: 210, h: 297, ml: 13, mr: 13, mt: 9, mb: 12 };
  let CO = null;
  function company() { if (CO) return Promise.resolve(CO); const R = window.ANOUER_RD; return (R && R.company ? R.company() : Promise.resolve({})).then(c => (CO = c || {})).catch(() => (CO = {})); }
  /* m: {title, chips:[[lbl,val]...], boxes:[[lbl,val]], cols:[{t,k,w,n,f,c,b}], bands:[{t,span,c}], groups:[{title, rows}], rows, totals:{k:v}|true, hideIdx, foot} */
  function docRes(m, co) {
    const PW = m.land ? 297 : PG.w, PH = m.land ? 210 : PG.h;
    const W = PW - PG.ml - PG.mr, cols = m.cols, tw = cols.reduce((s, c) => s + (c.w || 20), 0) + (m.hideIdx ? 0 : 9), sc = W / tw;
    const cw = c => ((c.w || 20) * sc).toFixed(2) + "mm";
    const iw = (9 * sc).toFixed(2) + "mm";
    const RH = 7.4, HH = 8.4, BH = 6.6, GH = 7.2, TH = 8.2;
    const nm = co["Company Name"] || "ANOUER";
    const b2n = m.bx2 ? Math.max(...m.bx2.map(c => c.length)) : 0;
    const headH = 58 + (m.boxes && m.boxes.length ? 10 : 0) + (m.chips && m.chips.length ? 11 : 0) + (b2n ? b2n * 8.2 + 3 : 0);
    const hdr = () => `<div class="rpd-h"><div class="co"><div class="nm">${esc(nm)}</div><div class="tx">الرقم الضريبي <b>${esc(co.NIF || "")}</b></div></div>${co["Company Logo"] ? `<img class="lg" src="${esc(co["Company Logo"])}">` : `<div class="lg ph"></div>`}</div>
      <div class="rpd-s"><span class="ad">${esc(co["Company Address"] || "الجزائر")}</span><span class="t">ت</span><span>${esc(co["Company Phone"] || "")}</span><span>${esc(co["Company Mobile"] || "")}</span><span class="t">س ت</span><span>${esc(co.RC || "")}</span></div>
      <div class="rpd-t">${esc(m.title)}</div>
      ${m.chips && m.chips.length ? `<div class="rpd-c">${m.chips.map(c => `<span class="l">${esc(c[0])}</span><span class="v">${esc(c[1])}</span>`).join("")}</div>` : ""}
      ${m.boxes && m.boxes.length ? `<div class="rpd-b">${m.boxes.map(b => `<span class="bx"><b>${esc(b[0])}</b><i>${esc(b[1])}</i></span>`).join("")}</div>` : ""}
      ${b2n ? `<div class="rpd-b2">${m.bx2.map(c => `<div class="cl">${c.map(b => `<span class="bx"><b>${esc(b[0])}</b><i class="${b[3] || ""}">${esc(b[1])}</i>${b[2] ? `<u>${esc(b[2])}</u>` : ""}</span>`).join("")}</div>`).join("")}</div>` : ""}`;
    const th = () => `${m.bands ? `<div class="rpd-r bd" style="height:${BH}mm">${m.hideIdx ? "" : `<span style="width:${iw}"></span>`}${m.bands.map(b => `<span style="width:${(b.span.reduce((s, i) => s + (cols[i].w || 20), 0) * sc).toFixed(2)}mm;${b.c ? "background:" + b.c : "background:transparent"}">${esc(b.t || "")}</span>`).join("")}</div>` : ""}
      <div class="rpd-r hd" style="height:${HH}mm">${m.hideIdx ? "" : `<span class="ix" style="width:${iw}">م</span>`}${cols.map(c => `<span style="width:${cw(c)};${c.hc ? "background:" + c.hc : ""}">${esc(c.t)}${c.nosort ? "" : " <i>▲</i>"}</span>`).join("")}</div>`;
    const cellV = (c, r) => { const v = c.f ? c.f(r) : r[c.k]; return c.n ? (v === "" || v == null ? "" : nf(v)) : (v == null ? "" : String(v)); };
    /* ✦ فتح ملف السطر (doc-open.js): فاتورة / مستند / سند / كارت الصنف — يُحفظ المرجع في res.refs */
    const refs = [], OPN = window.ANOUER_OPEN;
    const refOf = r => { if (!OPN || !r || r._noref) return null;
      const x = r._doc || r._x || (r.t && TYPE[r.t] && (r.id != null || r.no != null) && !r._sub ? r : null);
      if (x && x.t) return { t: x.t, id: x.id, no: x.no, date: x.date, time: x.time, pname: x.pname, total: x.total, paid: x.paid, gross: x.gross, disc: x.disc, tax: x.tax, lines: x.lines };
      if (x && x.k) return x;
      if (r.kind === "doc" && r._id) return { k: r._dk || "recv", id: r._id, no: r.no };
      if (r.kind && r._id && /^(cop|cadj|cbad|cdn|recv|pay|exp|rev|je|xfer|taxp|taxs)$/.test(r.kind)) return { k: r.kind, id: r._id, no: r.no };
      if (r._pid != null && r._pid !== "") return { item: r._pid };
      if (r._party) return { party: r._party };
      return null; };
    const refAt = r => { const f = refOf(r); if (!f || !OPN.canOpen(f)) return ""; refs.push(f); return ` data-ref="${refs.length - 1}" title="${esc("انقر مرتين لفتح " + OPN.label(f))}"`; };
    const rowH = (r, i) => `<div class="rpd-r${r._cls ? " " + r._cls : ""}"${r._pid ? ` data-pid="${esc(r._pid)}"` : ""}${r._inv ? ` data-inv="${esc(r._inv)}"` : ""}${refAt(r)} style="height:${RH}mm">${m.hideIdx ? "" : `<span class="ix" style="width:${iw}">${i}</span>`}${cols.map(c => `<span class="${c.n ? "n" : ""}${c.cls ? " " + c.cls : ""}" style="width:${cw(c)}" title="${esc(cellV(c, r))}">${esc(cellV(c, r))}</span>`).join("")}</div>`;
    const totH = (t) => `<div class="rpd-r tt" style="height:${TH}mm">${m.hideIdx ? "" : `<span class="ix" style="width:${iw};background:transparent"></span>`}${cols.map(c => { const v = t[c.k]; return `<span class="${v == null || v === "" ? "e" : "n"}" style="width:${cw(c)}">${v == null || v === "" ? "" : (typeof v === "number" ? nf(v) : esc(v))}</span>`; }).join("")}</div>`;
    const sumOf = rows => { const t = {}; cols.forEach(c => { if (c.sum) t[c.k] = r2(rows.reduce((s, r) => s + (+(c.f ? c.f(r) : r[c.k]) || 0), 0)); }); return t; };
    const groups = m.groups || [{ title: null, rows: m.rows || [] }];
    // تسلسل العناصر (رأس مجموعة/سطر/إجمالي مجموعة/إجمالي عام) ثم تقسيمها على الصفحات
    const items = []; let n = 0;
    groups.forEach(g => { if (g.title != null) items.push({ k: "g", h: GH, html: `<div class="rpd-r gh${g.cls ? " " + g.cls : ""}" style="height:${GH}mm"><span>${esc(g.title)}</span></div>` });
      g.rows.forEach(r => { n++; items.push({ k: "r", h: RH, html: rowH(r, n), r }); });
      if (g.title != null && m.groupTotals !== false && cols.some(c => c.sum)) items.push({ k: "s", h: TH, html: totH(sumOf(g.rows)).replace("rpd-r tt", "rpd-r st") }); });
    if (m.totals !== false && cols.some(c => c.sum)) items.push({ k: "t", h: TH + 2, html: totH(Object.assign(sumOf(groups.reduce((a, g) => a.concat(g.rows), [])), m.totExtra || {})).replace("rpd-r tt", m.totPlain ? "rpd-r tt tp" : "rpd-r tt") });
    if (m.extraHtml) items.push({ k: "x", h: m.extraH || 30, html: m.extraHtml });
    const tH = (m.bands ? BH : 0) + HH;
    const pages = []; let cur = [], left = PH - PG.mt - PG.mb - headH - tH;
    items.forEach(it => { if (it.h > left && cur.length) { pages.push(cur); cur = []; left = PH - PG.mt - PG.mb - tH; } cur.push(it); left -= it.h; });
    if (cur.length || !pages.length) pages.push(cur);
    const N = pages.length, stamp = new Date(), by = (window.ANOUER_RD && ANOUER_RD.userName ? ANOUER_RD.userName() : "") || (window.__USER_NAME || "");
    const out = pages.map((p, i) => ({ w: PW, h: PH, html: `<div class="rdp rpd" dir="rtl" style="position:relative;width:${PW}mm;height:${PH}mm;background:#fff;overflow:hidden;font-family:Tahoma,Arial;color:#111"><style>${DOC_CSS}</style>
      <div style="position:absolute;top:${PG.mt}mm;left:${PG.ml}mm;right:${PG.mr}mm;bottom:${PG.mb}mm">${i === 0 ? hdr() : ""}<div class="rpd-g">${th()}${p.map(x => x.html).join("")}${!p.length && i === 0 ? `<div class="rpd-e">لا توجد بيانات في هذه الفترة</div>` : ""}</div></div>
      <div class="rpd-f" style="position:absolute;left:${PG.ml}mm;right:${PG.mr}mm;bottom:4mm"><span>صفحة ${i + 1} من ${N}</span><span>${esc(by)}</span><span>${ymd(stamp)} ${pad(stamp.getHours())}:${pad(stamp.getMinutes())}</span></div></div>` }));
    return { w: PW, h: PH, pages: out, model: m, count: n, refs };
  }
  const DOC_CSS = `.rpd *{box-sizing:border-box}.rpd-h{display:flex;justify-content:space-between;align-items:flex-start;height:24mm}.rpd-h .nm{font:700 22pt/1 Tahoma,Arial;color:#c8551a;letter-spacing:.5px;direction:ltr;text-align:right}.rpd-h .tx{font-size:8pt;margin-top:4mm;color:#222}.rpd-h .lg{max-width:46mm;max-height:22mm;object-fit:contain}.rpd-h .lg.ph{width:40mm}
    .rpd-s{display:flex;border:.3mm solid #111;height:6mm;font-size:7.5pt;align-items:center;margin-top:1mm}.rpd-s span{padding:0 2mm;border-left:.3mm solid #111;height:100%;display:flex;align-items:center}.rpd-s .ad{flex:1}.rpd-s span:last-child{border-left:0}.rpd-s .t{font-weight:700}
    .rpd-t{text-align:center;font:700 18pt/1.2 Tahoma,Arial;padding:2mm 0 2.6mm;border-bottom:.3mm solid #d9a3a3}
    .rpd-c{display:flex;justify-content:center;margin:3mm 0 1mm;height:7.4mm}.rpd-c span{display:flex;align-items:center;justify-content:center;font-size:10.5pt;padding:0 4mm;border:.3mm solid #c8551a}.rpd-c .l{background:#ff8a00;color:#fff;font-weight:700;border-color:#ff8a00}.rpd-c .v{min-width:30mm;background:#fff}
    .rpd-b{display:flex;gap:4mm;margin:2mm 0 2mm;justify-content:flex-start}.rpd-b .bx{display:flex;align-items:stretch;border-bottom:.35mm solid #3c9cf4;height:7mm}.rpd-b b{background:#eef1f5;border:.3mm solid #cfd6df;padding:0 3mm;display:flex;align-items:center;font-size:9pt}.rpd-b i{font-style:normal;font-weight:700;padding:0 4mm;display:flex;align-items:center;font-size:9pt;min-width:40mm}
    .rpd-b2{display:flex;justify-content:space-between;gap:10mm;margin:2mm 0 1mm}.rpd-b2 .cl{display:flex;flex-direction:column;gap:1.2mm;min-width:70mm}.rpd-b2 .bx{display:flex;align-items:stretch;height:7mm;border-bottom:.35mm solid #3c9cf4}.rpd-b2 b{width:26mm;flex-shrink:0;background:#eef1f5;border:.3mm solid #cfd6df;padding:0 2mm;display:flex;align-items:center;font-size:8.6pt}.rpd-b2 i{flex:1;font-style:normal;font-weight:700;padding:0 3mm;display:flex;align-items:center;font-size:9pt;min-width:36mm}.rpd-b2 i.n{direction:ltr;justify-content:flex-end}.rpd-b2 u{text-decoration:none;background:#7a1f2b;color:#fff;font-size:7.5pt;font-weight:700;display:flex;align-items:center;padding:0 2mm}
    .rpd-r.bd span.e{background:transparent!important}
    .rpd-g{margin-top:3mm}.rpd-r{display:flex;align-items:stretch;border-bottom:.25mm solid #d3d9e1;font-size:8.6pt}.rpd-r span{display:flex;align-items:center;justify-content:center;padding:0 1mm;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;border-left:.25mm solid #e3e7ec}.rpd-r span.n{direction:ltr}.rpd-r span.l{justify-content:flex-start}
    .rpd-r.hd{border:0}.rpd-r.hd span{background:#3c9cf4;color:#fff;font-weight:700;border-left:.4mm solid #fff;font-size:8.4pt;white-space:normal;text-align:center;line-height:1.05}.rpd-r.hd span i{font-style:normal;font-size:5pt;margin-right:1mm;opacity:.9}
    .rpd-r.bd{border:0}.rpd-r.bd span{color:#fff;font-weight:700;border-left:.4mm solid #fff;font-size:8.4pt}
    .rpd-r span.ix{background:#ff8a00;color:#fff;border-left:.4mm solid #fff}.rpd-r.hd span.ix{background:#3c9cf4}
    .rpd-r.gh{border:0;margin-top:1.5mm}.rpd-r.gh span{flex:1;justify-content:flex-start;background:#eef0f2;font-weight:700;font-size:9pt;padding:0 3mm}
    .rpd-r.tt{border:0;margin-top:1mm}.rpd-r.tt span{background:#ff8a00;color:#fff;font-weight:700;border-left:.4mm solid #fff;white-space:normal;line-height:1.05;text-align:center}.rpd-r.tt span.e{background:transparent}
    .rpd-r.st span{background:#fdebd5;font-weight:700}.rpd-r.st span.e{background:transparent}
    .rpd-r.tt.tp{border-top:.3mm solid #8aa9c9}.rpd-r.tt.tp span{background:transparent;color:#111;border-left:0}.rpd-r.tt.tp span.n{text-decoration:underline;text-underline-offset:1mm}
    .rpd-r.it span{font-size:7.8pt;color:#3a4654;background:#fbfcfe}.rpd-r.it span.ix{background:#ffc380}
    .rpd-r.neg span:not(.ix){color:#b0281f}.rpd-r.bn span:not(.ix){color:#17663a;background:#effaf2;font-weight:700}.rpd-r.bn span.ix{background:#3fb56a}.rpd-r.gh.bg span{background:linear-gradient(90deg,#eef0f2,#e3f4e8);color:#1d3b2a;border-right:1.2mm solid #2e8b57}.rpd-k{display:flex;gap:2mm;margin-top:2.5mm}.rpd-k>div{flex:1;border:.3mm solid #d6dde6;border-top:1mm solid #2e8b57;border-radius:1.2mm;padding:1.4mm 2mm;background:#fbfdfc}.rpd-k b{display:block;font-size:12pt;color:#17663a;direction:ltr;text-align:right}.rpd-k i{font-style:normal;font-size:7.4pt;color:#5b6675}.rpd-r.sub span{background:#f6f8fb;font-weight:700}
    .rpd-e{text-align:center;padding:10mm;color:#777;font-size:11pt}.rpd-f{display:flex;justify-content:space-between;font-size:7pt;color:#666;border-top:.2mm solid #ccc;padding-top:1mm}`;
  function fullHTML(res, title) { return `<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>${esc(title || "ANOUER")}</title><style>@page{size:${res.w || 210}mm ${res.h || 297}mm;margin:0}html,body{margin:0;padding:0;background:#fff}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}.rdp{page-break-after:always;break-after:page}.rdp:last-child{page-break-after:auto}${DOC_CSS}</style></head><body>${res.pages.map(p => p.html).join("")}</body></html>`; }

  /* ================================================================== المعاينة (شريط أدوات DEXEF Print Preview) */
  function viewer(host, res, title) {
    let zoom = lsGet("rp.zoom", 1.2), page = 0, thumbs = false;
    host.innerHTML = `<div class="rp-vtb">
      <button type="button" data-a="close" title="إغلاق المعاينة">${IC.close}</button><span class="sep"></span>
      <button type="button" data-a="zout" title="تصغير">${IC.zout}</button><button type="button" data-a="zin" title="تكبير">${IC.zin}</button><select data-a="zsel">${[.5, .75, 1, 1.2, 1.5, 2].map(z => `<option value="${z}">${Math.round(z * 100)}%</option>`).join("")}<option value="fit">عرض الصفحة</option></select><span class="sep"></span>
      <button type="button" data-a="last" title="الصفحة الأخيرة (Ctrl+End)">${IC.last}</button><button type="button" data-a="next" title="الصفحة التالية">${IC.next}</button><button type="button" data-a="prev" title="الصفحة السابقة">${IC.prev}</button><button type="button" data-a="first" title="الصفحة الأولى (Ctrl+Home)">${IC.first}</button><span class="sep"></span>
      <button type="button" data-a="thumbs" class="tx">${IC.thumbs}<span>Thumbnails</span></button><button type="button" data-a="find" class="tx">${IC.find}<span>Find</span></button><span class="sep"></span>
      <button type="button" data-a="xls" class="tx" title="تصدير إلى Excel">${IC.xls}<span>Excel</span></button><button type="button" data-a="pdf" class="tx" title="تصدير PDF">${IC.pdf}<span>PDF</span></button><button type="button" data-a="wa" title="إرسال واتساب (PDF)">${IC.wa}</button><span class="sep"></span>
      <button type="button" data-a="qprint" class="tx" title="طباعة سريعة على الطابعة الافتراضية">${IC.qprint}<span>Quick Print</span></button><button type="button" data-a="print" class="tx" title="طباعة (Ctrl+P)">${IC.print}<span>Print</span></button></div>
      <div class="rp-vb"><div class="rp-th" hidden></div><div class="rp-pages"></div></div>
      <div class="rp-vst"><span class="zl"><input type="range" min="30" max="250" step="5" data-a="zr"><b data-k="zp"></b></span><span class="sp"></span><span data-k="pg"></span></div>
      <div class="rp-find" hidden><input placeholder="بحث في التقرير..."><b data-k="fc"></b><button type="button" data-a="fprev">▲</button><button type="button" data-a="fnext">▼</button><button type="button" data-a="fx">✕</button></div>`;
    const Q = s => host.querySelector(s), pagesEl = Q(".rp-pages");
    const st = document.createElement("style"); st.textContent = DOC_CSS; host.appendChild(st);
    pagesEl.innerHTML = res.pages.map((p, i) => `<div class="rp-pw" data-p="${i}"><div class="rp-pi">${p.html}</div></div>`).join("");
    Q(".rp-th").innerHTML = res.pages.map((p, i) => `<div class="t" data-p="${i}"><div class="m" style="height:${Math.round(120 * p.h / p.w)}px"><div style="transform:scale(${(120 / (p.w * 3.7795)).toFixed(4)});transform-origin:top left;position:absolute;top:0;left:0">${p.html}</div></div><b>${i + 1}</b></div>`).join("");
    function apply() {
      const z = zoom === "fit" ? Math.max(.3, (pagesEl.clientWidth - 40) / (res.w * 3.7795)) : zoom;
      pagesEl.querySelectorAll(".rp-pw").forEach(w => { const pi = w.firstElementChild; pi.style.transform = `scale(${z})`; w.style.width = (res.w * 3.7795 * z) + "px"; w.style.height = (res.h * 3.7795 * z) + "px"; });
      Q('[data-a="zsel"]').value = String(zoom); Q('[data-a="zr"]').value = Math.round(z * 100); Q('[data-k="zp"]').textContent = Math.round(z * 100) + "%";
      try { lsSet("rp.zoom", zoom); } catch (e) { }
    }
    function goto(i) { page = Math.max(0, Math.min(res.pages.length - 1, i)); const w = pagesEl.querySelector(`[data-p="${page}"]`); if (w) w.scrollIntoView({ block: "start", behavior: "smooth" }); upd(); }
    function upd() { Q('[data-k="pg"]').textContent = `Page ${page + 1} of ${res.pages.length}`; Q(".rp-th").querySelectorAll(".t").forEach(t => t.classList.toggle("on", +t.dataset.p === page)); }
    pagesEl.addEventListener("scroll", () => { const ws = [...pagesEl.querySelectorAll(".rp-pw")]; const top = pagesEl.getBoundingClientRect().top; let k = 0; ws.forEach((w, i) => { if (w.getBoundingClientRect().top - top < pagesEl.clientHeight / 2) k = i; }); if (k !== page) { page = k; upd(); } }, { passive: true });
    pagesEl.addEventListener("wheel", e => { if (!e.ctrlKey) return; e.preventDefault(); const z = typeof zoom === "number" ? zoom : 1; zoom = Math.max(.3, Math.min(2.5, r2(z + (e.deltaY < 0 ? .1 : -.1)))); apply(); }, { passive: false });
    let fhits = [], fi = -1;
    function find(q) {
      pagesEl.querySelectorAll(".rp-hit").forEach(x => x.classList.remove("rp-hit", "on")); fhits = []; fi = -1;
      if (q) { const nq = norm(q); pagesEl.querySelectorAll(".rpd-r span").forEach(s => { if (norm(s.textContent).includes(nq)) { s.classList.add("rp-hit"); fhits.push(s); } }); }
      Q('[data-k="fc"]').textContent = q ? fhits.length + " نتيجة" : ""; step(1);
    }
    function step(d) { if (!fhits.length) return; if (fi >= 0) fhits[fi].classList.remove("on"); fi = (fi + d + fhits.length) % fhits.length; fhits[fi].classList.add("on"); fhits[fi].scrollIntoView({ block: "center", behavior: "smooth" }); }
    function csv() {
      const m = res.model, cs = m.cols, q = v => { v = String(v == null ? "" : v); return /[",\n;]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
      const lines = [[m.hideIdx ? null : "م"].concat(cs.map(c => c.t)).filter(x => x != null).map(q).join(",")]; let n = 0;
      (m.groups || [{ rows: m.rows || [] }]).forEach(g => { if (g.title != null) lines.push(q(g.title)); g.rows.forEach(r => { n++; lines.push([m.hideIdx ? null : n].concat(cs.map(c => { const v = c.f ? c.f(r) : r[c.k]; return v; })).filter((x, i) => !(m.hideIdx && i === 0 && x == null)).map(q).join(",")); }); });
      const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["﻿" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" })); a.download = (title || "تقرير") + ".csv"; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 400); say("تم التصدير إلى Excel (" + n + " سطر)", "s");
    }
    function printIt(quick) {
      const R = window.ANOUER_RD;
      if (HOST() && R && R.printResult) { R.printResult(Object.assign({}, res, { pages: res.pages.map(p => ({ w: p.w, h: p.h, html: p.html.replace('class="rdp rpd"', 'class="rdp rpd"') })) }), { title, dialog: !quick, css: DOC_CSS }).catch(() => { }); return; }
      const w = window.open("", "_blank"); if (!w) { say("تعذّر فتح نافذة الطباعة", "w"); return; }
      w.document.write(fullHTML(res, title)); w.document.close(); w.focus(); setTimeout(() => w.print(), 300);
    }
    function pdf() {
      if (HOST()) { call("print.pdf", { html: fullHTML(res, title), w: res.w, h: res.h, fileName: (title || "تقرير").replace(/[\\/:*?"<>|]/g, "_") }).then(r => { if (r && r.ok) say("تم حفظ PDF في: " + r.path, "s"); else say("تعذّر إنشاء PDF", "e"); }).catch(e => { if (isUnknown(e)) printIt(); else say("تعذّر إنشاء PDF: " + e.message, "e"); }); return; }
      printIt();
    }
    host.querySelector(".rp-vtb").addEventListener("click", e => {
      const b = e.target.closest("button"); if (!b) return; const a = b.dataset.a;
      if (a === "zin" || a === "zout") { const z = typeof zoom === "number" ? zoom : 1; zoom = Math.max(.3, Math.min(2.5, r2(z + (a === "zin" ? .1 : -.1)))); apply(); }
      else if (a === "first") goto(0); else if (a === "last") goto(res.pages.length - 1); else if (a === "next") goto(page + 1); else if (a === "prev") goto(page - 1);
      else if (a === "thumbs") { thumbs = !thumbs; Q(".rp-th").hidden = !thumbs; b.classList.toggle("on", thumbs); apply(); }
      else if (a === "find") { const f = Q(".rp-find"); f.hidden = !f.hidden; if (!f.hidden) setTimeout(() => f.querySelector("input").focus(), 20); }
      else if (a === "xls") csv(); else if (a === "pdf") pdf(); else if (a === "print") printIt(false); else if (a === "qprint") printIt(true);
      else if (a === "wa") { if (window.ANOUER_WA && ANOUER_WA.open) ANOUER_WA.open({ text: title }); else pdf(); }
      else if (a === "close") { if (host._onClose) host._onClose(); }
    });
    Q('[data-a="zsel"]').addEventListener("change", e => { zoom = e.target.value === "fit" ? "fit" : +e.target.value; apply(); });
    Q('[data-a="zr"]').addEventListener("input", e => { zoom = +e.target.value / 100; apply(); });
    Q(".rp-th").addEventListener("click", e => { const t = e.target.closest(".t"); if (t) goto(+t.dataset.p); });
    const fin = Q(".rp-find input"); fin.addEventListener("input", () => find(fin.value.trim()));
    fin.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); step(e.shiftKey ? -1 : 1); } else if (e.key === "Escape") { Q(".rp-find").hidden = true; find(""); } });
    Q('[data-a="fnext"]').onclick = () => step(1); Q('[data-a="fprev"]').onclick = () => step(-1); Q('[data-a="fx"]').onclick = () => { Q(".rp-find").hidden = true; find(""); };
    /* ✦ الانتقال من سطر التقرير إلى ملفه: فاتورة / مستند / سند / كارت الصنف (doc-open.js) */
    if (window.ANOUER_OPEN && res.refs && res.refs.length) { host.classList.add("od-on"); ANOUER_OPEN.wireViewer(pagesEl, res.refs, host); }
    else {
      pagesEl.addEventListener("dblclick", e => { const rw = e.target.closest(".rpd-r[data-pid]"); if (rw && window.__FH_ITEMCARD) window.__FH_ITEMCARD(+rw.dataset.pid || rw.dataset.pid); });
      pagesEl.addEventListener("click", e => { const rw = e.target.closest(".rpd-r[data-pid]"); pagesEl.querySelectorAll(".rpd-r.rsel").forEach(x => x.classList.remove("rsel")); if (rw) rw.classList.add("rsel"); });
    }
    host.tabIndex = -1;
    host.addEventListener("keydown", e => {
      if (e.ctrlKey && (e.key === "p" || e.key === "P")) { e.preventDefault(); printIt(false); }
      else if (e.ctrlKey && e.key === "End") { e.preventDefault(); goto(res.pages.length - 1); } else if (e.ctrlKey && e.key === "Home") { e.preventDefault(); goto(0); }
      else if (e.ctrlKey && (e.key === "f" || e.key === "F")) { e.preventDefault(); Q(".rp-find").hidden = false; fin.focus(); }
    });
    apply(); upd();
    requestAnimationFrame(() => pagesEl.querySelectorAll(".rp-pw").forEach((w, i) => w.style.animationDelay = Math.min(i, 6) * 45 + "ms"));
    return { res, print: printIt, csv, pdf };
  }

  /* ================================================================== تبويب نتيجة التقرير */
  let SEQ = 1;
  const VIEWS = {};
  /* نافذة عائمة (مثل DEXEF عند الضغط على عدسة «عدد التعاملات»): نفس محتوى تبويب التقرير داخل نافذة فوق شاشة المراجعة */
  function resultWin(r, side) {
    const key = "rpw_" + (SEQ++), ov = document.createElement("div"); ov.className = "rp-wov"; ov.dataset.k = key;
    ov.innerHTML = `<div class="rp-win" role="dialog" aria-modal="true" aria-label="${esc(r.name)}"><div class="rp-wt"><span class="ic"><svg viewBox="0 0 16 16"><rect x="1.5" y="1.5" width="13" height="13" rx="2.5" fill="#1f78d6"/><path d="M4.5 11V8M8 11V5M11.5 11V7" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/></svg></span><b>${esc(r.name)}</b><span class="sp"></span><button type="button" class="x" title="إغلاق (Esc)">✕</button></div>
      <div class="rp-res rp-wb"><div class="rp-rv"></div>${side ? `<aside class="rp-side"><button type="button" class="rp-col" title="طي">‹</button><div class="rp-sh">${esc(r.name)}</div><div class="rp-sb"></div><label class="rp-chk nw"><input type="checkbox" data-k="newtab"><i></i>فتح التقرير فى صفحة جديدة</label><button type="button" class="rp-show">عرض</button></aside>` : ""}</div></div>`;
    document.body.appendChild(ov);
    const el = ov.querySelector(".rp-wb");
    VIEWS[key] = { el, r, win: ov };
    const close = () => { ov.classList.add("out"); setTimeout(() => ov.remove(), 160); delete VIEWS[key]; window.removeEventListener("keydown", kd, true); };
    const kd = e => { if (e.key === "Escape" && document.body.lastElementChild === ov) { e.preventDefault(); e.stopImmediatePropagation(); close(); } };
    window.addEventListener("keydown", kd, true);
    ov.querySelector(".rp-wt .x").onclick = close;
    ov.addEventListener("mousedown", e => { if (e.target === ov) { const w = ov.querySelector(".rp-win"); w.classList.remove("shk"); void w.offsetWidth; w.classList.add("shk"); } });
    { const t = ov.querySelector(".rp-wt"), w = ov.querySelector(".rp-win"); t.addEventListener("pointerdown", e => { if (e.target.closest("button")) return; const b = w.getBoundingClientRect(), dx = e.clientX - b.left, dy = e.clientY - b.top; t.setPointerCapture(e.pointerId);
      const mv = ev => { w.style.position = "fixed"; w.style.margin = "0"; w.style.left = Math.max(0, Math.min(innerWidth - 80, ev.clientX - dx)) + "px"; w.style.top = Math.max(0, Math.min(innerHeight - 40, ev.clientY - dy)) + "px"; };
      const up = () => { t.removeEventListener("pointermove", mv); t.removeEventListener("pointerup", up); }; t.addEventListener("pointermove", mv); t.addEventListener("pointerup", up); }); }
    el.querySelector(".rp-col") && el.querySelector(".rp-col").addEventListener("click", () => el.classList.toggle("rp-folded"));
    ov.__close = close;
    return { key, el, host: el.querySelector(".rp-rv"), side: el.querySelector(".rp-sb") };
  }
  function resultTab(r, side) {
    if (r && r.modal) return resultWin(r, side);
    const key = "rpv_" + (SEQ++), el = mkView(key, r.name);
    el.classList.add("rp-res");
    el.innerHTML = `<div class="rp-rv"></div>${side ? `<aside class="rp-side"><button type="button" class="rp-col" title="طي">‹</button><div class="rp-sh">${esc(r.name)}</div><div class="rp-sb"></div><label class="rp-chk nw"><input type="checkbox" data-k="newtab"><i></i>فتح التقرير فى صفحة جديدة</label><button type="button" class="rp-show">عرض</button></aside>` : ""}`;
    VIEWS[key] = { el, r };
    RV.VIEW_SHOW[key] = () => { };
    tabOpen(key, r.name, key);
    el.querySelector(".rp-col") && el.querySelector(".rp-col").addEventListener("click", () => el.classList.toggle("rp-folded"));
    return { key, el, host: el.querySelector(".rp-rv"), side: el.querySelector(".rp-sb") };
  }
  function busy(host, on) {
    if (!host) return; let b = host.querySelector(".rp-busy");
    if (on) { if (!b) { b = document.createElement("div"); b.className = "rp-busy"; b.innerHTML = '<div><i></i><b>Please Wait</b><span>Loading ...</span></div>'; host.appendChild(b); }
      DPROG = (d, n) => { const sp = b.querySelector("span"); if (sp) sp.textContent = "تحميل أسطر الفواتير " + d + " / " + n; }; }
    else { if (b) b.remove(); DPROG = null; } }
  function showDoc(host, m, title) {
    busy(host, true);
    return company().then(co => { const res = docRes(m, co); busy(host, false); const V = viewer(host, res, title); host._onClose = () => { const k = Object.keys(VIEWS).find(k => VIEWS[k].el.contains(host)); if (!k) return; if (VIEWS[k].win && VIEWS[k].win.__close) VIEWS[k].win.__close(); else tabClose(k); }; return V; });
  }

  /* ================================================================== نافذة المعايير (برتقالية بنمط DEXEF) */
  /* o: {types:[...], type, fields:{br,wh,per,of,party,...}, extra:html, onShow(vals,dlg)} */
  function paramDlg(r, o) {
    const ov = document.createElement("div"); ov.className = "rp-pov";
    const T = o.types || [];
    ov.innerHTML = `<div class="rp-pd" role="dialog" aria-modal="true"><button type="button" class="x" title="إغلاق">✕</button><div class="tl">${esc(r.name)}</div>
      <div class="bd">${T.length ? `<div class="rt"><span class="lb">${esc(o.typeLabel || "نوع التقرير")}</span><div class="lst${o.multi ? " mul" : ""}">${T.map((t, i) => `<button type="button" data-i="${i}" class="${o.multi ? ((o.sel || []).includes(i) ? "on" : "") : i === (o.type || 0) ? "on" : ""}">${esc(t)}</button>`).join("")}</div></div>` : ""}
      <div class="fl">${o.fields || ""}</div></div>
      <div class="ft"><button type="button" class="ok">عرض</button><button type="button" class="cn">إغلاق</button></div></div>`;
    document.body.appendChild(ov);
    const dlg = ov.querySelector(".rp-pd"); let ti = o.type || 0;
    const msel = () => [...ov.querySelectorAll(".rt button.on")].map(b => +b.dataset.i);
    ov.querySelectorAll(".rt button").forEach(b => b.addEventListener("click", () => {
      if (o.multi) { b.classList.toggle("on"); if (o.onType) o.onType(msel(), ov); return; }
      ti = +b.dataset.i; ov.querySelectorAll(".rt button").forEach(x => x.classList.toggle("on", x === b)); if (o.onType) o.onType(ti, ov); }));
    const close = () => { ov.classList.add("out"); setTimeout(() => ov.remove(), 180); window.__viewKey = prevK; };
    ov.querySelector(".x").onclick = close; ov.querySelector(".cn").onclick = close;
    ov.querySelector(".ok").onclick = () => { const v = vals(ov); v.type = ti; v.typeName = T[ti] || ""; if (o.multi) v.sel = msel(); if (o.check && o.check(v, ov) === false) return; close(); o.onShow(v, ov); };
    ov.addEventListener("mousedown", e => { if (e.target === ov) { dlg.classList.remove("shake"); void dlg.offsetWidth; dlg.classList.add("shake"); } });
    const prevK = window.__viewKey;
    window.__viewKey = e => { if (e.key === "Escape") { close(); return true; } if (e.key === "Enter" && !e.target.closest("select")) { ov.querySelector(".ok").click(); return true; } if (/^F\d+$/.test(e.key)) return true; e.stopImmediatePropagation(); return false; };
    // مكونات
    ov.querySelectorAll("[data-per]").forEach(h => { h._P = perPicker(h, { init: h.dataset.per ? JSON.parse(h.dataset.per) : null }); });
    if (o.onInit) o.onInit(ov);
    setTimeout(() => { const b = ov.querySelector(".rt button.on") || ov.querySelector(".ok"); b.focus(); }, 40);
    return ov;
  }
  function vals(root) {
    const v = {};
    root.querySelectorAll("[data-k]").forEach(x => { if (x.type === "checkbox") v[x.dataset.k] = x.checked; else if (x.tagName === "SELECT" || x.tagName === "INPUT") v[x.dataset.k] = x.value; });
    const ph = root.querySelector("[data-per]"); if (ph && ph._P) Object.assign(v, ph._P.get());
    TW = v.from && (v.ft && v.ft !== T0 || v.tt && v.tt !== T1) ? { from: v.from, to: v.to, ft: v.ft || T0, tt: v.tt || T1 } : null;
    return v;
  }
  const F = {
    br: (l = "اسم الفرع") => `<label class="rp-f"><span>${l}</span>${brSel()}<i class="req">*</i></label>`,
    wh: (l = "المخازن") => `<label class="rp-f"><span>${l}</span><select data-k="wh">${stores().map(s => `<option value="${s.id}"${s.main ? " selected" : ""}>${esc(s.name)}</option>`).join("")}<option value="*">${esc(stores().map(s => s.name).join("، "))}</option></select><i class="req">*</i></label>`,
    per: (l = "الفترة") => `<div class="rp-f"><span>${l}</span><span data-per=""></span></div>`,
    of: (r, fields) => r.type === 1 ? `<div class="rp-f"><span>ترتيب النتائج بواسطة</span><span class="rp-ofr"><select data-k="ok">${(fields || FIELDS).map(f => `<option value="${f[0]}">${esc(f[1])}</option>`).join("")}</select><select data-k="od" class="od"><option value="asc">تصاعدي ↑</option><option value="desc">تنازلي ↓</option></select></span></div>`
      : r.type === 2 ? `<div class="rp-f"><span>تصفية النتائج بواسطة</span><span class="rp-ofr"><select data-k="fk">${(fields || FIELDS).map(f => `<option value="${f[0]}">${esc(f[1])}</option>`).join("")}</select><input data-k="fv" placeholder="القيمة..." autocomplete="off"></span></div>` : "",
    chk: (k, l, on) => `<label class="rp-chk"><input type="checkbox" data-k="${k}"${on ? " checked" : ""}><i></i>${esc(l)}</label>`,
    sel: (k, l, opts) => `<label class="rp-f"><span>${l}</span><select data-k="${k}">${opts.map(o => Array.isArray(o) ? `<option value="${esc(o[0])}">${esc(o[1])}</option>` : `<option>${esc(o)}</option>`).join("")}</select></label>`
  };
  const chipsOf = v => (v.ft && v.ft !== T0) || (v.tt && v.tt !== T1) ? [["في الفترة من", dmy(v.from) + "  " + hm12(v.ft)], ["الى", dmy(v.to) + "  " + hm12(v.tt)]] : [["في الفترة من", dmy(v.from)], ["الى", dmy(v.to)]];
  /* أيقونات «بدون / تغيير الترتيب / تصفية النتائج» واتجاه الترتيب (مثل DEXEF) */
  const OFI = ['<svg viewBox="0 0 14 14" width="13" height="13"><rect x="1" y="1" width="12" height="12" fill="none" stroke="#8a95a5"/><path d="M1 7h12M7 1v12" stroke="#8a95a5"/></svg>',
    '<svg viewBox="0 0 14 14" width="13" height="13"><g fill="#5b7fb5"><rect x="1" y="2" width="12" height="2"/><rect x="1" y="6" width="9" height="2"/><rect x="1" y="10" width="6" height="2"/></g></svg>',
    '<svg viewBox="0 0 14 14" width="13" height="13"><g fill="#2b6fd6"><rect x="1" y="2" width="12" height="2"/><rect x="3" y="6" width="10" height="2"/><rect x="5" y="10" width="8" height="2"/></g></svg>'];
  const OD_IC = { asc: '<svg viewBox="0 0 18 18" width="16" height="16"><path d="M5 3v12M2 12l3 3 3-3" fill="none" stroke="#2b8a3e" stroke-width="1.6"/><text x="10" y="8" font-size="6" font-family="Arial" fill="#c0392b" font-weight="700">A</text><text x="10" y="15" font-size="6" font-family="Arial" fill="#1f5fa8" font-weight="700">Z</text></svg>',
    desc: '<svg viewBox="0 0 18 18" width="16" height="16"><path d="M5 15V3M2 6l3-3 3 3" fill="none" stroke="#c0392b" stroke-width="1.6"/><text x="10" y="8" font-size="6" font-family="Arial" fill="#1f5fa8" font-weight="700">Z</text><text x="10" y="15" font-size="6" font-family="Arial" fill="#c0392b" font-weight="700">A</text></svg>' };
  /* «موضحاً الحركة مع ..» + «الاسم» (تصفية النتائج — مطابقة DEXEF): نوع الحساب ثم اختيار الاسم من القائمة */
  const MVT = [["cp", "العملاء و الموردين", "👤"], ["rep", "مندوب مبيعات", "👤"], ["gl", "حساب استاذ", "📊"], ["tr", "الخزينة", "💰"], ["bank", "البنوك", "🏦"], ["visa", "الفيزا", "💳"],
    ["cc", "مراكز التكلفة", "≣"], ["user", "المستخدمين", "👥"], ["shift", "ورديات العمل", "⏱"], ["cur", "العملات", "💱"], ["pledge", "عهد الموظفين", "🗂"], ["tax", "الضرائب", "％"]];
  const MV = {
    html: () => `<div class="rp-mvrow"><div class="rp-f v"><span class="lb">موضحاً الحركة مع ..</span><span class="rp-mvk"><select data-k="mvk">${MVT.map(t => `<option value="${t[0]}">${t[2]}  ${esc(t[1])}</option>`).join("")}</select></span></div>
      <div class="rp-f v"><span class="lb">الاسم<i class="req">*</i></span><span data-mvl="1"></span><input type="hidden" data-k="mvn"></div></div>`,
    items: k => {
      if (k === "cp") return Promise.all([parties("cu").catch(() => []), parties("su").catch(() => [])]).then(([c, s]) => c.map(x => ({ id: "c" + x.id, code: x.no || x.code || "", name: x.name })).concat(s.map(x => ({ id: "s" + x.id, code: x.no || x.code || "", name: x.name }))));
      if (k === "user") return data(ymd(new Date(Date.now() - 365 * 864e5)), today()).then(D => [...new Set(D.inv.map(x => x.user).filter(Boolean))].map((u, i) => ({ id: "u" + i, code: "", name: u }))).catch(() => []);
      if (k === "cur") return Promise.resolve([{ id: "DZD", code: "DZD", name: "DZD" }]);
      if (k === "tr" || k === "bank" || k === "visa" || k === "pledge") return (A() ? A().accounts(k === "tr" ? "tr" : k === "bank" ? "bk" : k === "visa" ? "vs" : "pl", true).catch(() => []) : Promise.resolve([])).then(l => (l || []).map(x => ({ id: x.id, code: x.no || "", name: x.name })));
      return Promise.resolve([]);
    },
    wire: root => {
      const sel = root.querySelector('[data-k="mvk"]'), host = root.querySelector("[data-mvl]"), hid = root.querySelector('[data-k="mvn"]');
      const L = lookup(host, { items: [], cols: [["code", "الكود", 80], ["name", "الاسم"]], key: "name", ph: "", onPick: it => { hid.value = it ? it.name : ""; } });
      const load = () => { hid.value = ""; L.set(null, true); MV.items(sel.value).then(l => L.setItems(l)); };
      sel.onchange = load; load();
    },
    label: v => (MVT.find(t => t[0] === v.mvk) || MVT[0])[1],
    /* المطابقة: العملاء/الموردين بالاسم، المستخدم، العملة (كل الفواتير بالدينار)، الخزينة (المدفوع نقداً) — والباقي غير مرتبط بالفواتير في ANOUER */
    pass: (v, x) => { const n = norm(v.mvn || ""); if (!n) return true;
      if (v.mvk === "cp") return norm(x.pname || "تعامل نقدى") === n;
      if (v.mvk === "user") return norm(x.user || "") === n;
      if (v.mvk === "cur") return n === "dzd";
      if (v.mvk === "tr") return (+x.paid || 0) > 0;
      return false; }
  };

  /* ================================================================== مكونات اللوحة الجانبية بنمط DEXEF ONE */
  const REQ_MSG = "يجب ادخال جميع الحقول التى بجوارها نجمة حمراء";
  /* رسالة DEXEF: مربع أبيض + أيقونة «!» زرقاء + زر «موافق» أخضر */
  function alertDlg(msg, after) {
    const ov = document.createElement("div"); ov.className = "rp-aov";
    ov.innerHTML = `<div class="rp-al" role="alertdialog" aria-modal="true"><div class="b"><span class="ic">!</span><p>${esc(msg)}</p></div><div class="f"><button type="button">موافق</button></div></div>`;
    document.body.appendChild(ov);
    const prevK = window.__viewKey;
    const close = () => { if (ov._c) return; ov._c = 1; ov.classList.add("out"); setTimeout(() => ov.remove(), 170); window.__viewKey = prevK; if (after) after(); };
    ov.querySelector("button").onclick = close;
    ov.addEventListener("mousedown", e => { if (e.target === ov) { const d = ov.firstElementChild; d.classList.remove("shake"); void d.offsetWidth; d.classList.add("shake"); } });
    window.__viewKey = e => { if (e.key === "Enter" || e.key === "Escape" || e.key === " ") { e.preventDefault(); close(); return true; } e.stopImmediatePropagation(); return false; };
    setTimeout(() => ov.querySelector("button").focus(), 30);
  }
  /* حقل بحث DEXEF (اسم الصنف / اسم الحساب): كتابة ← قائمة منسدلة بأعمدة (الكود | الاسم) مع تمييز المطابقة بالأصفر،
     أسهم/Enter للاختيار، ✕ للمسح، ▾ لعرض الكل. o: {items, cols:[[k,title,width]], key, ph, onPick, by} */
  function lookup(host, o) {
    host.classList.add("rp-lk");
    host.innerHTML = `<input autocomplete="off" spellcheck="false" placeholder="${esc(o.ph || "")}"><button type="button" class="cx" tabindex="-1" title="مسح">✕</button><button type="button" class="dd" tabindex="-1" title="عرض الكل">▾</button>`;
    const inp = host.querySelector("input"); let pop = null, sel = null, hi = 0, list = [], by = o.by || null;
    const txt = it => String(it[o.key || "name"] == null ? "" : it[o.key || "name"]);
    const close = () => { if (pop) { pop.classList.add("out"); const p = pop; setTimeout(() => p.remove(), 120); pop = null; } host.classList.remove("open"); };
    const draw = all => {
      const q = all ? "" : norm(inp.value.trim()), keys = by ? [by] : o.cols.map(c => c[0]);
      list = (q ? o.items.filter(it => keys.some(k => norm(String(it[k] == null ? "" : it[k])).includes(q))) : o.items).slice(0, 300);
      if (q) list.sort((a, b) => { const x = norm(txt(a)).indexOf(q), y = norm(txt(b)).indexOf(q); return (x < 0 ? 99 : x) - (y < 0 ? 99 : y); });
      if (!pop) { pop = document.createElement("div"); pop.className = "rp-lkp"; document.body.appendChild(pop);
        pop.addEventListener("mousedown", e => e.preventDefault());
        pop.addEventListener("click", e => { const tr = e.target.closest("tr[data-i]"); if (tr) pick(list[+tr.dataset.i]); }); }
      host.classList.add("open");
      const rc = host.getBoundingClientRect(), w = Math.max(rc.width, o.pw || 330);
      pop.style.top = Math.min(rc.bottom + 2, innerHeight - 120) + "px"; pop.style.left = Math.max(4, rc.right - w) + "px"; pop.style.width = w + "px";
      hi = Math.max(0, Math.min(hi, list.length - 1)); const hq = all ? "" : inp.value.trim();
      pop.innerHTML = `<table><thead><tr>${o.cols.map(c => `<th style="${c[2] ? "width:" + c[2] + "px" : ""}">${esc(c[1])}</th>`).join("")}</tr></thead><tbody>${list.map((it, i) => `<tr data-i="${i}" class="${i === hi ? "hi" : ""}${sel === it ? " on" : ""}">${o.cols.map(c => `<td class="${c[3] || ""}">${c[3] === "n" ? esc(nf(it[c[0]])) : hl(String(it[c[0]] == null ? "" : it[c[0]]), hq)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${o.cols.length}" class="e">لا توجد نتائج</td></tr>`}</tbody></table>${o.items.length > list.length && !q ? `<div class="mr">${list.length} من ${o.items.length} — اكتب للبحث</div>` : ""}`;
    };
    const mark = () => { if (!pop) return; pop.querySelectorAll("tr[data-i]").forEach(t => t.classList.toggle("hi", +t.dataset.i === hi)); const t = pop.querySelector("tr.hi"); if (t) t.scrollIntoView({ block: "nearest" }); };
    function pick(it, silent) { sel = it || null; inp.value = it ? txt(it) : ""; host.classList.toggle("has", !!it); host.classList.remove("bad"); close(); if (!silent && o.onPick) o.onPick(sel); }
    inp.addEventListener("input", () => { sel = null; host.classList.toggle("has", !!inp.value); hi = 0; draw(); if (o.onPick) o.onPick(null, true); });
    inp.addEventListener("keydown", e => {
      const stop = () => { e.preventDefault(); e.stopPropagation(); };
      if (e.key === "ArrowDown" || e.key === "ArrowUp") { stop(); if (!pop) { draw(!inp.value); return; } hi = Math.max(0, Math.min(list.length - 1, hi + (e.key === "ArrowDown" ? 1 : -1))); mark(); }
      else if (e.key === "Enter") { if (pop && list[hi]) { stop(); pick(list[hi]); } }
      else if (e.key === "Escape") { if (pop) { stop(); close(); } }
      else if (e.key === "F4") { stop(); pop ? close() : draw(true); }
      else if (e.key.length === 1 || e.key === "Backspace" || e.key === "Delete") e.stopPropagation(); });
    inp.addEventListener("blur", () => setTimeout(() => { if (document.activeElement === inp) return; close();
      if (!sel && inp.value.trim()) { const q = norm(inp.value.trim()), ex = o.items.filter(it => o.cols.some(c => norm(String(it[c[0]] || "")) === q)); if (ex.length === 1) pick(ex[0]); } }, 140));
    host.querySelector(".dd").onclick = () => { if (pop) close(); else { inp.focus(); draw(true); } };
    host.querySelector(".cx").onclick = () => { pick(null); inp.focus(); };
    window.addEventListener("resize", close); host.closest(".rp-sb") && host.closest(".rp-sb").addEventListener("scroll", close, { passive: true });
    return { get: () => sel, set: (v, silent) => { const it = typeof v === "object" ? v : o.items.find(x => String(x.id) === String(v) || String(x.code) === String(v)); pick(it || null, silent); return it; },
      setBy: k => { by = k; }, setItems: l => { o.items = l; }, focus: () => inp.focus(), el: inp, bad: () => { host.classList.add("bad"); inp.focus(); } };
  }
  /* «نوع التقرير»: قائمة رمادية والمحدد أزرق (DEXEF)؛ cols=2 لعمودين */
  function typeList(host, types, o) {
    o = o || {}; let ti = o.i || 0;
    host.innerHTML = `<div class="rp-lst${o.cols === 2 ? " c2" : ""}">${types.map((t, i) => `<button type="button" data-i="${i}" class="${i === ti ? "on" : ""}">${esc(t)}</button>`).join("")}</div>`;
    host.querySelectorAll("button").forEach(b => b.onclick = () => { ti = +b.dataset.i; host.querySelectorAll("button").forEach(x => x.classList.toggle("on", x === b)); if (o.onChange) o.onChange(ti); });
    host.querySelector(".rp-lst").addEventListener("keydown", e => { if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return; e.preventDefault(); e.stopPropagation(); const n = Math.max(0, Math.min(types.length - 1, ti + (e.key === "ArrowDown" ? 1 : -1))); host.querySelectorAll("button")[n].click(); host.querySelectorAll("button")[n].focus(); });
    return { get: () => ti, set: i => host.querySelectorAll("button")[i] && host.querySelectorAll("button")[i].click() };
  }
  /* الحقول العمودية (العنوان فوق الحقل + نجمة حمراء) */
  const V = {
    f: (l, inner, req, cls) => `<div class="rp-f v${cls ? " " + cls : ""}"><span class="lb">${esc(l)}${req ? '<i class="req">*</i>' : ""}</span>${inner}</div>`,
    br: () => V.f("اسم الفرع", brSel(), 1),
    wh: () => V.f("المخزن", `<select data-k="wh">${stores().map(s => `<option value="${s.id}"${s.main ? " selected" : ""}>${esc(s.name)}</option>`).join("")}<option value="*">كل المخازن</option></select>`, 1),
    per: () => V.f("الفترة", '<span data-per=""></span>', 1)
  };
  /* «بدون ▾» (بدون / تغيير الترتيب / تصفية النتائج) + «بحث متقدم» */
  function advRow(host, r, fields) {
    host.innerHTML = `<div class="rp-adv"><select data-k="ofm"><option value="0">بدون</option><option value="1">تغيير الترتيب</option><option value="2">تصفية النتائج</option></select><span class="sq"><input data-k="adv" placeholder="بحث متقدم" autocomplete="off" spellcheck="false"><i>${IC.find}</i></span></div><div class="rp-ofx"></div>`;
    const sel = host.querySelector("select"), ofx = host.querySelector(".rp-ofx");
    sel.value = String(r.type || 0);
    const draw = () => { ofx.innerHTML = F.of({ type: +sel.value }, fields); ofx.classList.toggle("on", +sel.value > 0); };
    sel.onchange = draw; draw();
  }
  /* البحث المتقدم: كلمات متعددة في أي عمود (مع الإبقاء على سطر «رصيد سابق») */
  function applyAdv(rows, v) {
    const q = norm(String(v.adv || "").trim()); if (!q) return rows;
    const ws = q.split(/\s+/);
    return rows.filter(x => x._keep || ws.every(w => Object.keys(x).some(k => k[0] !== "_" && norm(String(x[k] == null ? "" : x[k])).includes(w))));
  }
  /* لوحة جانبية: آخر قيم مستخدمة لكل تقرير */
  const memK = r => "rp.last." + r.frm + "." + (r.tags || "");

  /* ================================================================== المحركات */
  const BUCKETS = ["يومي", "أسبوعي", "شهري", "ربع سنوي", "سنوي"];
  function bucketOf(date, k) {
    const d = new Date(date + "T12:00:00"), y = d.getFullYear();
    if (k === 0) return [date, dmy(date)];
    if (k === 1) { const s = new Date(d); s.setDate(d.getDate() - ((d.getDay() + 1) % 7)); const kk = ymd(s); return [kk, "أسبوع " + dmy(kk)]; }
    if (k === 2) return [y + "-" + pad(d.getMonth() + 1), MONTHS[d.getMonth()] + "," + y];
    if (k === 3) { const q = Math.floor(d.getMonth() / 3) + 1; return [y + "-Q" + q, "ربع " + q + "," + y]; }
    return [String(y), String(y)];
  }
  /* --- حركة المبيعات / المشتريات (FrmBillRpt) — لوحة جانبية --- */
  function billRpt(r) {
    const T = resultTab(r, true), types = typesOf(r), pur = types[0].startsWith("Purchase");
    branches().then(() => {
      T.side.innerHTML = F.br() + F.wh() + F.per() + `<div class="rp-f top"><span>نوع التقرير</span><div class="rp-lst">${["عام", "موضحاً الأصناف", "موضحاً القيود", "مفصل"].map((t, i) => `<button type="button" data-i="${i}" class="${i ? "" : "on"}">${t}</button>`).join("")}</div></div>
        ${F.chk("onlyp", pur ? "الموردين فقط" : "العملاء فقط")}
        <div class="rp-adv2"><span class="gi">${OFI[r.type || 0]}</span><select data-k="ofm"><option value="0">بدون</option><option value="1"${r.type === 1 ? " selected" : ""}>تغيير الترتيب</option><option value="2"${r.type === 2 ? " selected" : ""}>تصفية النتائج</option></select><span class="sq"><input data-k="adv" placeholder="بحث متقدم" autocomplete="off" spellcheck="false"><i>${IC.find || "⌕"}</i></span></div><div class="rp-ofx"></div>`;
      T.side.querySelectorAll("[data-per]").forEach(h => h._P = perPicker(h));
      let ti = 0;
      T.side.querySelectorAll(".rp-lst button").forEach(b => b.onclick = () => { ti = +b.dataset.i; T.side.querySelectorAll(".rp-lst button").forEach(x => x.classList.toggle("on", x === b)); });
      const ofx = T.side.querySelector(".rp-ofx"), ofm = T.side.querySelector('[data-k="ofm"]');
      /* مثل DEXEF: «تغيير الترتيب» ← طريقة الترتيب (حقل + اتجاه) ، «تصفية النتائج» ← موضحاً الحركة مع .. + الاسم */
      const drawOF = () => { const k = +ofm.value; ofx.classList.toggle("on", k > 0); T.side.querySelector(".rp-adv2 .gi").innerHTML = OFI[k];
        ofx.innerHTML = k === 1 ? `<div class="rp-ofbox"><span class="lb">طريقة الترتيب</span><span class="rw"><select data-k="ok">${FIELDS.map(f => `<option value="${f[0]}">${esc(f[1])}</option>`).join("")}</select><input type="hidden" data-k="od" value="asc"><button type="button" class="odb" title="تصاعدي / تنازلي">${OD_IC.asc}</button></span></div>`
          : k === 2 ? `<div class="rp-ofbox">${MV.html()}</div>` : "";
        if (k === 1) { const bt = ofx.querySelector(".odb"), hd = ofx.querySelector('[data-k="od"]'); bt.onclick = () => { hd.value = hd.value === "asc" ? "desc" : "asc"; bt.innerHTML = OD_IC[hd.value]; }; }
        if (k === 2) MV.wire(ofx); };
      ofm.onchange = drawOF; drawOF();
      const run = () => {
        const v = vals(T.el.querySelector(".rp-side")); v.type = ti;
        if (+v.ofm === 2 && !v.mvn) { alertDlg(REQ_MSG); return; }
        if (v.newtab) { const r2_ = Object.assign({}, r, { modal: false }); billRpt(r2_); return; }
        busy(T.host, true);
        data(v.from, v.to).then(D => {
          let L = D.inv.filter(x => types.includes(x.t) && filt({ br: v.br, wh: v.wh }, x) && (!v.onlyp || x.pk));
          L = L.slice().sort((a, b) => String(a.dt).localeCompare(String(b.dt)) || String(a.no).localeCompare(String(b.no), "en", { numeric: true }));
          L = L.map(x => Object.assign({}, x, { rem: r2(x.total - x.paid), _cls: isRet(x.t) ? "neg" : "" }));
          if (/مستحقة/.test(r.name)) L = L.filter(x => x.rem > .009);   // الفواتير مستحقة التحصيل / السداد
          /* ✦ «موضحا البونص» (مطابقة DEXEF): الفواتير التي بها بونص فقط + عمود البونص (أسطر السعر صفر) */
          if (r.bonus) { if (!D.lines) say("أسطر الفواتير غير متاحة — أعد بناء البرنامج لعرض البونص", "w"); L = L.map(x => Object.assign(x, { bon: r2(x.lines.filter(isBon).reduce((s, l) => s + (+l.qty || 0), 0)), bonv: r2(x.lines.filter(isBon).reduce((s, l) => s + (+l.qty || 0) * bonPrice(x, l), 0)) })).filter(x => x.bon > 0); }
          if (+v.ofm === 2) L = L.filter(x => MV.pass(v, x));
          if (+v.ofm !== 1) { v.ok = ""; } if (+v.ofm !== 2) { v.fk = ""; }
          L = applyAdv(applyOF(L, v, FIELDS), v);
          const head = [{ t: "التاريخ", k: "date", w: 22, f: x => dmy(x.date) }, { t: "الرقم", k: "no", w: 17 }, { t: "الاسم", k: "pname", w: 38, cls: "l" }, { t: "", k: "cur", w: 9, f: () => "DZD", nosort: 1 }, { t: "الاجمالي", k: "gross", w: 19, n: 1, sum: 1 }, { t: "الخصم", k: "disc", w: 15, n: 1, sum: 1 }, { t: "الضريبة", k: "tax", w: 15, n: 1, sum: 1 }, { t: "الاضافي", k: "extra", w: 14, n: 1, sum: 1 }, { t: "الصافي", k: "total", w: 20, n: 1, sum: 1 }];
          if (r.bonus) head.push({ t: "البونص", k: "bon", w: 15, n: 1, sum: 1, hc: "#2e8b57" }, { t: "قيمة البونص", k: "bonv", w: 19, n: 1, sum: 1, hc: "#2e8b57" });
          let m;
          if (ti === 0) m = { title: r.name, chips: chipsOf(v), boxes: [["اسم الفرع", v.br]], cols: head, rows: L };
          if (ti === 0 && r.bonus) { m.boxes.push(["المخزن", v.wh === "*" ? "كل المخازن" : storeName(v.wh)]); }
          else if (ti === 1 || ti === 3) {
            // موضحاً الأصناف / مفصل: سطر لكل فاتورة ثم أصنافها
            const rows = []; L.forEach(x => { rows.push(Object.assign({ _cls: "sub" }, x)); if (!D.lines) return; x.lines.forEach(l => rows.push({ date: "", no: "", pname: "   " + (r.bonus && isBon(l) ? "🎁 " : "") + l.name, cur: "", gross: ti === 3 ? "" : "", disc: "", tax: "", extra: "", total: "", _l: l, _cls: r.bonus && isBon(l) ? "bn" : "" })); });
            const cols = ti === 1 ? [{ t: "التاريخ", k: "date", w: 20, f: x => x._l ? "" : dmy(x.date) }, { t: "الرقم", k: "no", w: 15 }, { t: "الاسم / الصنف", k: "pname", w: 46, cls: "l" }, { t: "الوحدة", k: "u", w: 14, f: x => x._l ? x._l.unit : "" }, { t: "الكمية", k: "q", w: 12, n: 1, f: x => x._l ? x._l.qty : "" }, { t: "السعر", k: "p", w: 15, n: 1, f: x => x._l ? x._l.price : "" }, { t: "الخصم", k: "disc", w: 13, n: 1, f: x => x._l ? x._l.disc : x.disc }, { t: "الصافي", k: "total", w: 20, n: 1, f: x => x._l ? x._l.total : x.total }]
              : [{ t: "التاريخ", k: "date", w: 18, f: x => x._l ? "" : dmy(x.date) }, { t: "الوقت", k: "time", w: 11, f: x => x._l ? "" : x.time }, { t: "الرقم", k: "no", w: 14 }, { t: "الاسم / الصنف", k: "pname", w: 40, cls: "l" }, { t: "الكود", k: "c", w: 22, f: x => x._l ? x._l.code : x.pcode }, { t: "الوحدة", k: "u", w: 12, f: x => x._l ? x._l.unit : "" }, { t: "الكمية", k: "q", w: 11, n: 1, f: x => x._l ? x._l.qty : "" }, { t: "السعر", k: "p", w: 14, n: 1, f: x => x._l ? x._l.price : "" }, { t: "الصافي", k: "total", w: 18, n: 1, f: x => x._l ? x._l.total : x.total }, { t: "المدفوع", k: "paid", w: 16, n: 1, f: x => x._l ? "" : x.paid }, { t: "المستخدم", k: "user", w: 16, f: x => x._l ? "" : x.user }];
            if (r.bonus) { cols.forEach((c, i) => { if (["q", "p", "disc", "total"].includes(c.k)) { const of = c.f || (x => x[c.k]); cols[i] = Object.assign({}, c, { f: x => x._l && isBon(x._l) ? "" : of(x) }); } });
              const qi = cols.findIndex(c => c.k === "q");
              cols.splice(qi + 1, 0, { t: "البونص", k: "bq", w: 12, n: 1, hc: "#2e8b57", f: x => x._l ? (isBon(x._l) ? x._l.qty : "") : x.bon }); }
            m = { title: r.name + (ti === 1 ? " موضحاً الأصناف" : " مفصل"), chips: chipsOf(v), boxes: [["اسم الفرع", v.br]], cols, rows, totals: false, extraHtml: totalsLine(L, r.bonus), extraH: 12 };
          } else {
            // موضحاً القيود: كل فاتورة بقيدها (الطرف / المبيعات / الخزينة)
            const rows = []; L.forEach(x => { const dr = isRet(x.t) !== pur; const acc = pur ? "المشتريات" : "المبيعات";
              rows.push(Object.assign({ _cls: "sub" }, x, { acc: (x.t === "Sale" || x.t === "Purchase" ? "فاتورة " : "") + TYPE[x.t] + " رقم " + x.no, dr: "", cr: "" }));
              const party = x.pname || "تعامل نقدى";
              const a1 = dr ? [acc, 0, x.total] : [acc, x.total, 0], a2 = dr ? [party, x.total, 0] : [party, 0, x.total];
              [a2, a1].forEach(a => rows.push({ date: "", no: "", acc: "     " + a[0], dr: a[1] || "", cr: a[2] || "" }));
              if (x.paid) { const t1 = dr ? ["الخزينة", x.paid, 0] : ["الخزينة", 0, x.paid], t2 = dr ? [party, 0, x.paid] : [party, x.paid, 0]; [t1, t2].forEach(a => rows.push({ date: "", no: "", acc: "     " + a[0], dr: a[1] || "", cr: a[2] || "" })); } });
            m = { title: r.name + " موضحاً القيود", chips: chipsOf(v), boxes: [["اسم الفرع", v.br]], cols: [{ t: "التاريخ", k: "date", w: 22, f: x => x.date ? dmy(x.date) : "" }, { t: "الرقم", k: "no", w: 16 }, { t: "البيان / الحساب", k: "acc", w: 70, cls: "l" }, { t: "مدين", k: "dr", w: 26, n: 1, sum: 1 }, { t: "دائن", k: "cr", w: 26, n: 1, sum: 1 }], rows };
          }
          busy(T.host, false);
          return showDoc(T.host, m, r.name);
        }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
      };
      T.el.querySelector(".rp-show").onclick = run;
    });
  }
  function totalsLine(L, bon) {
    const s = k => r2(L.reduce((a, x) => a + (isRet(x.t) ? -1 : 1) * (+x[k] || 0), 0));
    return `<div class="rpd-r tt" style="height:9mm;margin-top:2mm"><span style="flex:1">عدد الفواتير ${L.length}</span><span style="flex:1">الاجمالي ${nf(s("gross"))}</span><span style="flex:1">الخصم ${nf(s("disc"))}</span><span style="flex:1">الصافي ${nf(s("total"))}</span>${bon ? `<span style="flex:1;background:#2e8b57">البونص ${nf(r2(L.reduce((a, x) => a + (+x.bon || 0), 0)))}</span>` : `<span style="flex:1">المدفوع ${nf(s("paid"))}</span>`}</div>`;
  }
  /* ================================================================== تقارير البونص (الإضافات ← البونص ← التقارير) — مطابقة DEXEF ONE
     البونص = سطر بسعر صفر لنفس الصنف داخل الفاتورة. وارد: مشتريات / مرتجع مبيعات — صادر: مبيعات / مرتجع مشتريات.
     ✦ لمستي: «قيمة البونص» (الكمية × سعر نفس الصنف في الفاتورة)، بطاقات ملخص أعلى الجدول، أسطر البونص بالأخضر، رأس تعامل ملوّن في «مفصل». */
  const isBon = l => !(+l.price) && !!(+l.qty);
  const B_T = ["Sale", "SaleReturn", "Purchase", "PurchaseReturn"], B_IN = { Purchase: 1, SaleReturn: 1 };
  const B_SORT = [["deal", "التعامل"], ["user", "المستخدم"], ["cur", "العملة"]];
  function bonPrice(x, l) {
    const pl = x.lines.find(z => !isBon(z) && String(z.pid) === String(l.pid) && z.unit === l.unit) || x.lines.find(z => !isBon(z) && String(z.pid) === String(l.pid));
    if (pl) return (+pl.price || 0) * ((+l.fac || 1) / (+pl.fac || 1));
    const p = ((H.prods && H.prods()) || []).find(z => String(z.id) === String(l.pid)); return p ? (+p.price || 0) * (+l.fac || 1) : 0;
  }
  const bkpi = (L) => `<div class="rpd-k">${L.map(k => `<div><b>${esc(k[1])}</b><i>${esc(k[0])}</i></div>`).join("")}</div>`;
  function bonusMove(r) {
    const k = r.k, item = k === "item", sort = k === "sort", wth = k === "with";
    Promise.all([branches(), products()]).then(([, P]) => {
      let LK = null, codeEl = null;
      const findCode = c => { c = String(c || "").trim(); if (!c) return null; return P.find(p => String(p.code) === c) || P.find(p => (p.units || []).some(u => String(u.bc || "") === c)) || null; };
      const fields = (item ? `<div class="rp-f"><span>اسم الصنف</span><span data-lk=""></span><i class="req">*</i></div><label class="rp-f"><span>الكود</span><input data-k="code" autocomplete="off" spellcheck="false" placeholder="الكود / الباركود"></label>` : "")
        + F.br() + F.wh("اسم المخزن") + F.per()
        + (sort ? F.sel("sb", "طريقة الترتيب", B_SORT) : "")
        + (item ? F.chk("onlyb", "التعاملات التي بها بونص فقط") : F.chk("val", "إظهار قيمة البونص", true))
        + (wth ? MV.html() : "");
      paramDlg(r, { types: ["عام", "مفصل"], fields,
        onInit: ov => {
          if (wth) { const row = ov.querySelector(".rp-mvrow"), bd = ov.querySelector(".rp-pd .bd"); if (row && bd) bd.after(row); MV.wire(ov); }
          if (item) { codeEl = ov.querySelector('[data-k="code"]');
            LK = lookup(ov.querySelector("[data-lk]"), { items: P, cols: [["code", "الكود", 104], ["name", "الاسم"], ["stock", "الرصيد", 64, "n"]], ph: "اكتب اسم الصنف...", pw: 380, onPick: p => { codeEl.value = p ? p.code : ""; } });
            if (r.pid) { const p0 = P.find(p => String(p.id) === String(r.pid)); if (p0) LK.set(p0); }
            codeEl.addEventListener("keydown", e => { if (e.key.length === 1 || e.key === "Backspace") e.stopPropagation(); if (e.key === "Enter") { const p = findCode(codeEl.value); if (p) LK.set(p, true); else if (codeEl.value.trim()) { e.preventDefault(); e.stopPropagation(); say("الكود غير موجود", "w"); codeEl.select(); } } });
            codeEl.addEventListener("change", () => { const p = findCode(codeEl.value); if (p) LK.set(p, true); });
            setTimeout(() => { if (!LK.get()) LK.focus(); }, 60); } },
        check: v => { if (item && !(LK.get() || findCode(v.code))) { alertDlg(REQ_MSG, () => LK.bad()); return false; } if (wth && !v.mvn) { alertDlg(REQ_MSG); return false; } return true; },
        onShow: v => {
          const p = item ? (LK.get() || findCode(v.code)) : null, det = v.type === 1;
          const T = resultTab(r, false); busy(T.host, true);
          data(v.from, v.to).then(D => {
            if (!D.lines) say("أسطر الفواتير غير متاحة — أعد بناء البرنامج لعرض البونص", "w");
            const X = D.inv.filter(x => B_T.includes(x.t) && filt({ br: v.br, wh: v.wh }, x) && (!wth || MV.pass(v, x)))
              .sort((a, b) => String(a.dt).localeCompare(String(b.dt)) || String(a.no).localeCompare(String(b.no), "en", { numeric: true }));
            const deal = x => TYPE[x.t] || x.t, keyOf = x => v.sb === "user" ? (x.user || "بدون مستخدم") : v.sb === "cur" ? "DZD" : deal(x);
            let bal = 0, tin = 0, tout = 0, tval = 0, rows = [], groups = null, cols, land = false, cnt = 0;
            const byItem = {};
            const wname = v.wh === "*" ? "كل المخازن" : storeName(v.wh);
            if (item) {
              X.forEach(x => { const ls = x.lines.filter(l => String(l.pid) === String(p.id)); if (!ls.length) return;
                const bl = ls.filter(isBon), pl = ls.filter(l => !isBon(l)); if (v.onlyb && !bl.length) return;
                const q = r2(bl.reduce((s, l) => s + l.qty * l.fac, 0)), inn = B_IN[x.t] ? q : 0, out = B_IN[x.t] ? 0 : q; bal = r2(bal + inn - out); tin += inn; tout += out; if (bl.length) cnt++;
                const bv = r2(bl.reduce((s, l) => s + l.qty * bonPrice(x, l), 0)); tval += bv;
                rows.push({ date: dmy(x.date), no: x.no, deal: deal(x), pname: x.pname || "تعامل نقدى", user: x.user, qty: r2(pl.reduce((s, l) => s + l.qty, 0)), unit: (pl[0] || ls[0]).unit, price: pl.length ? pl[0].price : "", inq: inn, outq: out, bal, bv, _cls: q ? "bn" : "", _doc: x }); });
              cols = det ? [{ t: "التاريخ", k: "date", w: 20 }, { t: "رقم التعامل", k: "no", w: 16 }, { t: "التعامل", k: "deal", w: 22 }, { t: "الاسم", k: "pname", w: 38, cls: "l" }, { t: "المستخدم", k: "user", w: 18 }, { t: "الكمية", k: "qty", w: 13, n: 1 }, { t: "الوحدة", k: "unit", w: 14 }, { t: "السعر", k: "price", w: 15, n: 1 }, { t: "وارد", k: "inq", w: 14, n: 1, sum: 1, hc: "#2e8b57" }, { t: "صادر", k: "outq", w: 14, n: 1, sum: 1, hc: "#c0392b" }, { t: "الرصيد", k: "bal", w: 15, n: 1 }, { t: "قيمة البونص", k: "bv", w: 18, n: 1, sum: 1 }]
                : [{ t: "التاريخ", k: "date", w: 22 }, { t: "رقم التعامل", k: "no", w: 19 }, { t: "التعامل", k: "deal", w: 62, cls: "l" }, { t: "وارد", k: "inq", w: 20, n: 1, sum: 1 }, { t: "صادر", k: "outq", w: 20, n: 1, sum: 1 }, { t: "الرصيد", k: "bal", w: 22, n: 1 }];
              land = det;
            } else {
              X.forEach(x => { const bl = x.lines.filter(isBon); if (!bl.length) return; cnt++;
                if (!det) bl.forEach(l => { const q = r2(l.qty * l.fac), inn = B_IN[x.t] ? q : 0, out = B_IN[x.t] ? 0 : q, bv = r2(l.qty * bonPrice(x, l)); bal = r2(bal + inn - out); tin += inn; tout += out; tval += bv;
                  (byItem[l.name] = (byItem[l.name] || 0) + out);
                  rows.push({ date: dmy(x.date), no: x.no, name: l.name, deal: deal(x), inq: inn, outq: out, bal, bv, _g: keyOf(x), _doc: x }); });
                else {
                  const m = {}; x.lines.forEach(l => { const kk = l.pid + "|" + l.unit, z = m[kk] || (m[kk] = { code: l.code, name: l.name, unit: l.unit, qty: 0, bonus: 0, price: "", total: 0, bv: 0 });
                    if (isBon(l)) { z.bonus = r2(z.bonus + l.qty); z.bv = r2(z.bv + l.qty * bonPrice(x, l)); const q = r2(l.qty * l.fac); if (B_IN[x.t]) tin += q; else { tout += q; byItem[l.name] = (byItem[l.name] || 0) + q; } }
                    else { z.qty = r2(z.qty + l.qty); z.price = l.price; z.total = r2(z.total + l.total); } });
                  const lr = Object.values(m).map(z => Object.assign(z, { _cls: z.bonus ? "bn" : "", bonus: z.bonus || "", bv: z.bv || "" })); tval += lr.reduce((s, z) => s + (+z.bv || 0), 0);
                  (groups = groups || []).push({ _k: keyOf(x), title: `${dmy(x.date)}  ${x.time || ""}   ▸   ${deal(x)} رقم ${x.no}   ▸   ${x.pname || "تعامل نقدى"}   ▸   المستخدم: ${x.user || "—"}`, rows: lr }); } });
              if (!det) {
                const vcol = v.val ? [{ t: "قيمة البونص", k: "bv", w: 19, n: 1, sum: 1, hc: "#2e8b57" }] : [];
                cols = [{ t: "التاريخ", k: "date", w: 20 }, { t: "رقم التعامل", k: "no", w: 17 }, { t: "اسم الصنف", k: "name", w: 56, cls: "l" }, { t: "التعامل", k: "deal", w: 24 }, { t: "وارد", k: "inq", w: 15, n: 1, sum: 1 }, { t: "صادر", k: "outq", w: 15, n: 1, sum: 1 }, { t: "الرصيد", k: "bal", w: 17, n: 1 }].concat(vcol);
                if (sort) { const g = {}; rows.forEach(x => (g[x._g] = g[x._g] || []).push(x)); groups = Object.keys(g).sort((a, b) => a.localeCompare(b, "ar")).map(t => ({ title: t, rows: g[t] })); }
              } else {
                cols = [{ t: "الكود", k: "code", w: 24 }, { t: "الصنف", k: "name", w: 58, cls: "l" }, { t: "الكمية", k: "qty", w: 14, n: 1, sum: 1 }, { t: "البونص", k: "bonus", w: 14, n: 1, sum: 1, hc: "#2e8b57" }, { t: "الوحدة", k: "unit", w: 15 }, { t: "السعر", k: "price", w: 17, n: 1 }, { t: "الاجمالي", k: "total", w: 21, n: 1, sum: 1 }].concat(v.val ? [{ t: "قيمة البونص", k: "bv", w: 19, n: 1, sum: 1, hc: "#2e8b57" }] : []);
                groups = groups || [];
                if (sort) groups.sort((a, b) => String(a._k).localeCompare(String(b._k), "ar"));
                groups.forEach(g => g.cls = "bg");
              }
            }
            const top = Object.keys(byItem).sort((a, b) => byItem[b] - byItem[a])[0];
            const kp = bkpi([["عدد التعاملات بها بونص", String(cnt)], ["إجمالي البونص الصادر", nf(r2(tout))], ["إجمالي البونص الوارد", nf(r2(tin))], ["قيمة البونص (DZD)", nf(r2(tval))]].concat(top ? [["الصنف الأكثر بونصاً", top]] : []));
            let ttl = r.name; if (det) ttl += " مفصل"; if (sort) ttl = r.name.replace(/\s*بـ?$/, "") + " بـ " + (B_SORT.find(s => s[0] === v.sb) || B_SORT[0])[1]; if (wth) ttl = "حركة البونص مع " + MV.label(v);
            const m = { title: ttl, chips: chipsOf(v), cols, land, totExtra: item ? { bal: r2(bal) } : !det ? { bal: r2(bal) } : {}, extraHtml: kp, extraH: 16 };
            if (item) m.bx2 = [[["اسم الفرع", v.br], ["الرقم", p.code], ["الاسم", p.name]], [["المخزن", wname]]];
            else m.boxes = [["اسم الفرع", v.br], ["المخزن", wname]].concat(wth ? [[MV.label(v), v.mvn]] : []);
            if (groups) { m.groups = groups; if (!det) m.groupTotals = true; } else m.rows = rows;
            busy(T.host, false);
            return showDoc(T.host, m, ttl);
          }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
        } });
    });
  }
  /* فتح تقرير بونص من لوحة البونص: id = item | all | sort | with | <Type>:<all|sort|with> */
  function bonusReport(id, title, pid) {
    const m = String(id || "").split(":");
    if (m.length > 1) return billRpt({ name: title, types: [m[0]], type: { all: 0, sort: 1, with: 2 }[m[1]] || 0, bonus: true });
    return bonusMove({ name: title, k: m[0], pid });
  }
  /* --- صافي / إجمالي المبيعات (FrmBillSumRpt) --- */
  function billSum(r) {
    const types = typesOf(r);
    branches().then(() => paramDlg(r, { types: ["يومي", "أسبوعي", "شهري", "سنوي"], fields: F.br() + F.per() + F.of(r, [["date", "التاريخ"], ["deal", "التعامل"], ["cnt", "العدد"], ["total", "الصافي"]]), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      const bk = [0, 1, 2, 4][v.type];
      data(v.from, v.to).then(D => {
        const L = D.inv.filter(x => types.includes(x.t) && filt({ br: v.br }, x)), m = {};
        L.forEach(x => { const b = bucketOf(x.date, bk), k = b[0] + "|" + x.t, s = sg(x); const g = m[k] || (m[k] = { _k: b[0], date: b[1], deal: TYPE[x.t], cnt: 0, gross: 0, extra: 0, tax: 0, disc: 0, total: 0, paid: 0, rem: 0, _cls: s < 0 ? "neg" : "" });
          g.cnt++; g.gross += s * x.gross; g.extra += s * x.extra; g.tax += s * x.tax; g.disc += s * x.disc; g.total += s * x.total; g.paid += s * x.paid; g.rem += s * (x.total - x.paid); });
        let rows = Object.values(m).sort((a, b) => a._k.localeCompare(b._k) || a.deal.localeCompare(b.deal, "ar"));
        rows = applyOF(rows, v);
        busy(T.host, false);
        showDoc(T.host, { title: r.name, chips: chipsOf(v), groups: [{ title: v.br, rows }], groupTotals: false, cols: [{ t: "التاريخ", k: "date", w: 22 }, { t: "التعامل", k: "deal", w: 22 }, { t: "العدد", k: "cnt", w: 12, n: 1, sum: 1 }, { t: "قيمة الفواتير", k: "gross", w: 21, n: 1, sum: 1 }, { t: "الاضافي", k: "extra", w: 13, n: 1, sum: 1 }, { t: "الضريبة", k: "tax", w: 14, n: 1, sum: 1 }, { t: "الخصم", k: "disc", w: 15, n: 1, sum: 1 }, { t: "الصافي", k: "total", w: 20, n: 1, sum: 1 }, { t: "المدفوع", k: "paid", w: 20, n: 1, sum: 1 }, { t: "الباقي", k: "rem", w: 18, n: 1, sum: 1 }] }, r.name);
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }
  /* --- إجمالي مبيعات / مشتريات الأصناف (FrmItemSales) --- */
  function itemSales(r) {
    const RT = r.types && r.types.length ? r.types : null;
    const pur = RT ? /^Purchase/.test(RT[0]) : /Purchase|مشتري/.test(r.tags + r.name), main = RT ? RT[0] : pur ? "Purchase" : "Sale", ret = RT ? (RT[1] || "") : pur ? "PurchaseReturn" : "SaleReturn";
    const TT = ["بالأرصدة فقط", "بالأرصدة موضحاً الوحدات", "بالأرصدة و القيمة", "بالأرصدة و القيمة موضحاً الوحدات", "بالأرصدة موضحاً تاريخ الصلاحية", "بالأرصدة موضحاً البونص"];
    branches().then(() => paramDlg(r, { types: TT, type: r.dtype != null ? r.dtype : 2, fields: F.br() + F.wh() + F.per() + `<label class="rp-f"><span>فلتر البحث</span><input data-k="q" placeholder="اسم الصنف / الكود / المجموعة" autocomplete="off"></label>` + `<div class="rp-f"><span>ترتيب النتائج بواسطة</span><span class="rp-ofr"><select data-k="ok"><option value="name">اسم الصنف</option><option value="code">الكود</option><option value="nq">الكمية</option><option value="nv">القيمة</option></select><select data-k="od" class="od"><option value="asc">↑</option><option value="desc">↓</option></select></span></div>` + (r.type === 2 ? MV.html() : ""), onInit: ov => { if (r.type === 2) { const row = ov.querySelector(".rp-mvrow"), bd = ov.querySelector(".rp-pd .bd"); if (row && bd) bd.after(row); MV.wire(ov); } }, check: v => r.type === 2 && !v.mvn ? (alertDlg(REQ_MSG), false) : true, onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      data(v.from, v.to).then(D => {
        if (!D.lines) { busy(T.host, false); return showDoc(T.host, { title: r.name, chips: chipsOf(v), cols: [{ t: "ملاحظة", k: "x", w: 100 }], rows: [{ x: "أسطر الفواتير غير متاحة — أعد بناء Anouer.exe" }] }, r.name); }
        const unit = v.type === 1 || v.type === 3, val = v.type === 2 || v.type === 3, q = norm(v.q || "");
        const m = {};
        D.inv.forEach(x => { if ((x.t !== main && x.t !== ret) || !filt({ br: v.br, wh: v.wh }, x) || (r.type === 2 && !MV.pass(v, x))) return;
          x.lines.forEach(l => { if (q && !norm(l.name + " " + l.code + " " + l.cat).includes(q)) return;
            const k = l.pid + (unit ? "|" + l.unit : ""), g = m[k] || (m[k] = { name: l.name, code: l.code, unit: unit ? l.unit : "", q1: 0, v1: 0, q2: 0, v2: 0 });
            const qq = unit ? l.qty : l.qty * l.fac;
            if (x.t === main) { g.q1 += qq; g.v1 += l.total; } else { g.q2 += qq; g.v2 += l.total; } }); });
        let rows = Object.values(m).map(g => Object.assign(g, { nq: r2(g.q1 - g.q2), nv: r2(g.v1 - g.v2) }));
        rows = applyOF(rows, v);
        const cols = [{ t: "اسم الصنف", k: "name", w: 50, cls: "l" }].concat(unit ? [{ t: "الوحدة", k: "unit", w: 14 }] : [])
          .concat([{ t: "كمية", k: "q1", w: 13, n: 1, sum: 1, hc: "#2e8b57" }]).concat(val ? [{ t: "قيمة", k: "v1", w: 16, n: 1, sum: 1, hc: "#2e8b57" }] : [])
          .concat([{ t: "كمية", k: "q2", w: 13, n: 1, sum: 1, hc: "#7b3b3b" }]).concat(val ? [{ t: "قيمة", k: "v2", w: 16, n: 1, sum: 1, hc: "#7b3b3b" }] : [])
          .concat([{ t: "كمية", k: "nq", w: 13, n: 1, sum: 1 }]).concat(val ? [{ t: "قيمة", k: "nv", w: 16, n: 1, sum: 1 }] : []);
        const i0 = unit ? 2 : 1, per = val ? 2 : 1;
        if (!ret) {   // نوع واحد بلا مرتجعات (عروض الأسعار / أوامر التوريد / طلبات الشراء): الكمية والقيمة فقط
          const c1 = cols.slice(0, i0 + per).map(c => Object.assign({}, c, { hc: undefined, t: c.k === "q1" ? "الكمية" : c.k === "v1" ? "القيمة" : c.t }));
          busy(T.host, false);
          return showDoc(T.host, { title: r.name, chips: chipsOf(v), boxes: [["اسم الفرع", v.wh === "*" ? stores().map(s => s.name).join("، ") : storeName(v.wh)]].concat(r.type === 2 ? [[MV.label(v), v.mvn]] : []), cols: c1, rows }, r.name);
        }
        const bands = [{ t: "", span: unit ? [0, 1] : [0], c: "" }, { t: "التعامل", span: Array.from({ length: per }, (_, i) => i0 + i), c: "#2e8b57" }, { t: "المرتجعات", span: Array.from({ length: per }, (_, i) => i0 + per + i), c: "#7b3b3b" }, { t: "الصافي", span: Array.from({ length: per }, (_, i) => i0 + 2 * per + i), c: "#3c9cf4" }];
        busy(T.host, false);
        showDoc(T.host, { title: r.name, chips: chipsOf(v), boxes: [["اسم الفرع", v.wh === "*" ? stores().map(s => s.name).join("، ") : storeName(v.wh)]].concat(r.type === 2 ? [[MV.label(v), v.mvn]] : []), cols, bands, rows, note: v.type >= 4 ? "تواريخ الصلاحية/البونص غير مسجلة في ANOUER" : "" }, r.name);
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }
  /* --- المقارنات (FrmBillPivot) — شبكة + رسم بياني --- */
  function pivot(r) {
    const types = r.types && r.types.length ? r.types.slice() : /مرتجع/.test(r.name) ? typesOf(r).filter(isRet).concat(/مشتري|شراء/.test(r.name) ? ["PurchaseReturn"] : ["SaleReturn"]).slice(0, 1) : typesOf(r).filter(t => !isRet(t));
    branches().then(() => paramDlg(r, { types: BUCKETS, type: 2, fields: F.br("خلال الفروع") + F.per(), onInit: ov => { const h = ov.querySelector("[data-per]"); h._P.set(8); }, onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      data(v.from, v.to).then(D => {
        const tg = r.tags, L = D.inv.filter(x => types.includes(x.t) && filt({ br: v.br }, x));
        const dimInv = { Branches: x => x.br || v.br, SalesCust: x => x.pname || "تعامل نقدى", SaleUsers: x => x.user || "—", SaleCurrency: () => "DZD", SaleClass: x => TYPE[x.t], RepMan: () => "بدون مندوب", CustArea: () => "بدون منطقة", CustGroup: () => "بدون مجموعة" };
        const dimLn = { ItemQtySales: l => l.name, ItemCostSales: l => l.name, SaleItemGroup: l => l.cat || "بدون مجموعة", SaleItemType: () => "مخزني", SaleItemExtraField: () => "—" };
        const cells = {}, cols = {}, rowsT = {};
        const add = (rk, b, v_) => { const c = cells[rk] || (cells[rk] = {}); c[b[0]] = (c[b[0]] || 0) + v_; cols[b[0]] = b[1]; rowsT[rk] = (rowsT[rk] || 0) + v_; };
        L.forEach(x => { const b = bucketOf(x.date, v.type);
          if (dimInv[tg]) add(dimInv[tg](x), b, x.total);
          else if (dimLn[tg]) x.lines.forEach(l => add(dimLn[tg](l), b, tg === "ItemQtySales" ? l.qty * l.fac : l.total));
          else add(x.br || v.br, b, x.total); });
        const ck = Object.keys(cols).sort(), rk = Object.keys(rowsT).sort((a, b) => rowsT[b] - rowsT[a]);
        busy(T.host, false);
        pivotView(T, r, v, { ck, cols, rk, cells, rowsT, qty: tg === "ItemQtySales" });
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }
  function pivotView(T, r, v, P) {
    const W = 120;
    T.host.innerHTML = `<div class="rp-ptb"><button type="button" data-a="prv" class="tx">${IC.print}<span>عرض للطباعة</span></button><button type="button" data-a="xls" class="tx">${IC.xls}<span>تصدير</span></button><span class="sp"></span><span class="rp-pinfo">${esc(BUCKETS[v.type])} • ${dmy(v.from)} ← ${dmy(v.to)} • ${esc(v.br)}</span></div>
      <div class="rp-pg"><table><thead><tr><th class="rk">${esc(P.qty ? "الصنف" : r.tags === "SalesCust" ? "الاسم" : "البيان")}</th>${P.ck.map(k => `<th>${esc(P.cols[k])}</th>`).join("")}<th class="tt">الإجمالي</th></tr></thead>
      <tbody>${P.rk.map((k, i) => `<tr data-r="${i}"><td class="rk">${esc(k)}</td>${P.ck.map(c => `<td>${P.cells[k][c] ? nf(P.cells[k][c]) : ""}</td>`).join("")}<td class="tt">${nf(P.rowsT[k])}</td></tr>`).join("") || `<tr><td class="e" colspan="${P.ck.length + 2}">لا توجد بيانات</td></tr>`}</tbody>
      <tfoot><tr><td class="rk">الإجمالي</td>${P.ck.map(c => `<td>${nf(P.rk.reduce((s, k) => s + (P.cells[k][c] || 0), 0))}</td>`).join("")}<td class="tt">${nf(P.rk.reduce((s, k) => s + P.rowsT[k], 0))}</td></tr></tfoot></table></div>
      <div class="rp-ch"><div class="hd"><b data-k="ct">${esc(r.name)}</b><span class="sp"></span><button type="button" data-m="rows" class="on">حسب ${esc(P.qty ? "الصنف" : "البيان")}</button><button type="button" data-m="time">حسب الفترة</button></div><div class="cv" data-k="cv"></div></div>`;
    let mode = "rows", selR = null;
    const draw = () => {
      const cv = T.host.querySelector('[data-k="cv"]'), Wd = Math.max(400, cv.clientWidth || 900), Hh = 210;
      let items;
      if (mode === "rows") items = P.rk.slice(0, 24).map(k => [k, P.rowsT[k]]);
      else items = P.ck.map(c => [P.cols[c], selR != null ? (P.cells[P.rk[selR]][c] || 0) : P.rk.reduce((s, k) => s + (P.cells[k][c] || 0), 0)]);
      const mx = Math.max(1, ...items.map(x => Math.abs(x[1]))), bw = (Wd - 70) / Math.max(1, items.length), nice = v => { const p = Math.pow(10, Math.floor(Math.log10(v))); return Math.ceil(v / p) * p; }, top = nice(mx);
      cv.innerHTML = `<svg viewBox="0 0 ${Wd} ${Hh + 40}" width="100%" height="${Hh + 40}"><g font-size="10" fill="#555" font-family="Tahoma">${[0, .25, .5, .75, 1].map(f => `<line x1="62" x2="${Wd - 6}" y1="${Hh - f * Hh + 6}" y2="${Hh - f * Hh + 6}" stroke="#e5e9ee"/><text x="56" y="${Hh - f * Hh + 10}" text-anchor="end">${fmt(Math.round(top * f))}</text>`).join("")}</g>
        <g>${items.map((x, i) => { const h = Math.abs(x[1]) / top * Hh, bwW = Math.min(90, Math.max(2, bw * .72)), X = 64 + i * bw + (bw - bwW) / 2; return `<rect class="rp-bar" style="animation-delay:${i * 25}ms" x="${X}" y="${Hh - h + 6}" width="${bwW}" height="${h}" rx="2" fill="${x[1] < 0 ? "#d9534f" : "#2a9fc8"}"><title>${esc(x[0])}: ${nf(x[1])}</title></rect>`; }).join("")}</g>
        <g font-size="10" fill="#333" font-family="Tahoma">${items.map((x, i) => i % Math.ceil(items.length / 16) === 0 ? `<text x="${64 + i * bw + bw / 2}" y="${Hh + 22}" text-anchor="middle">${esc(String(x[0]).slice(0, 18))}</text>` : "").join("")}</g></svg>`;
    };
    T.host.querySelectorAll(".rp-ch [data-m]").forEach(b => b.onclick = () => { mode = b.dataset.m; T.host.querySelectorAll(".rp-ch [data-m]").forEach(x => x.classList.toggle("on", x === b)); draw(); });
    T.host.querySelector("tbody").addEventListener("click", e => { const tr = e.target.closest("tr[data-r]"); if (!tr) return; selR = +tr.dataset.r; T.host.querySelectorAll("tbody tr").forEach(x => x.classList.toggle("on", x === tr)); mode = "time"; T.host.querySelectorAll(".rp-ch [data-m]").forEach(x => x.classList.toggle("on", x.dataset.m === "time")); T.host.querySelector('[data-k="ct"]').textContent = r.name + " — " + P.rk[selR]; draw(); });
    const model = () => ({ title: r.name, chips: chipsOf(v), boxes: [["الفترات", BUCKETS[v.type]]], cols: [{ t: "البيان", k: "k", w: 40, cls: "l" }].concat(P.ck.slice(-10).map(c => ({ t: P.cols[c], k: c, w: 15, n: 1, sum: 1 }))).concat([{ t: "الإجمالي", k: "_t", w: 18, n: 1, sum: 1 }]), rows: P.rk.map(k => Object.assign({ k, _t: P.rowsT[k] }, P.cells[k])) });
    T.host.querySelector(".rp-ptb").addEventListener("click", e => { const b = e.target.closest("button"); if (!b) return;
      if (b.dataset.a === "prv") { const T2 = resultTab({ name: r.name + " (معاينة)" }, false); showDoc(T2.host, model(), r.name); }
      else if (b.dataset.a === "xls") { const q = x => /[",\n]/.test(String(x)) ? '"' + String(x).replace(/"/g, '""') + '"' : String(x); const t = [["البيان"].concat(P.ck.map(c => P.cols[c])).concat(["الإجمالي"]).map(q).join(",")].concat(P.rk.map(k => [k].concat(P.ck.map(c => r2(P.cells[k][c] || 0))).concat([r2(P.rowsT[k])]).map(q).join(","))).join("\r\n"); const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["﻿" + t], { type: "text/csv;charset=utf-8" })); a.download = r.name + ".csv"; document.body.appendChild(a); a.click(); setTimeout(() => a.remove(), 300); } });
    requestAnimationFrame(draw);
    if (window.ResizeObserver) new ResizeObserver(() => draw()).observe(T.host.querySelector('[data-k="cv"]'));
  }
  /* --- أرصدة / ميزان مراجعة العملاء والموردين والخزن (FrmGlIndex) --- */
  function balances(r) {
    const side = /Vendor|مورد/.test(r.tags + r.name) ? "su" : /Storage|خزن/.test(r.tags + r.name) ? "tr" : /Bank|بنوك/.test(r.tags) ? "bk" : /Visa/.test(r.tags) ? "pos" : /Pledge|العهد/.test(r.tags + r.name) ? "emp" : "cu";
    const rev = /Revision|ميزان/.test(r.tags + r.name);
    const slot = (i, h) => `<div class="rp-slot" data-s="${i}" hidden>${h}</div>`;
    branches().then(() => paramDlg(r, { typeLabel: "تصفية النتائج بواسطة", types: ["كود الحساب", "الفرع", "الفترة", "اختيار حسابات", "المجموعة"], multi: true, sel: [],
      fields: `<div class="rp-slots">${slot(0, `<label class="rp-f"><span>كود الحساب</span><input data-k="code" placeholder="من - إلى" autocomplete="off"></label>`) + slot(1, F.br()) + slot(2, F.per()) + slot(3, `<label class="rp-f"><span>الحسابات</span><input data-k="names" placeholder="اكتب جزءاً من الاسم" autocomplete="off"></label>`) + slot(4, `<label class="rp-f"><span>المجموعة</span><select data-k="grp"><option value="">الكل</option></select></label>`)}</div>` + F.chk("zero", "ظهور الحسابات المساوية للصفر") + (side === "cu" || side === "su" ? F.chk("merge", "دمج العملاء والموردين") : "") + F.sel("cur", "عملة التقرير", ["عملة الحساب"]),
      onType: (sel, ov) => ov.querySelectorAll(".rp-slot").forEach(s => { const on = sel.includes(+s.dataset.s), was = !s.hidden; s.hidden = !on; if (on && !was) { s.classList.remove("in"); void s.offsetWidth; s.classList.add("in"); } }),
      onShow: v => {
        const T = resultTab(r, false); busy(T.host, true);
        const last = {};
        const lastP = side === "cu" || side === "su" ? data(perRange(9)[0], today()).then(D => D.inv.forEach(x => { if (x.pk === (side === "cu" ? "c" : "s")) { const k = x.pid; if (!last[k] || last[k] < x.date) last[k] = x.date; } })).catch(() => { }) : Promise.resolve();
        const accP = side === "cu" || side === "su" ? Promise.all([parties(side), v.merge ? parties(side === "cu" ? "su" : "cu") : Promise.resolve([])]).then(([a, b]) => a.map(p => Object.assign({ side }, p)).concat(b.map(p => Object.assign({ side: side === "cu" ? "su" : "cu" }, p))))
          : (A() ? Promise.all([A().accounts(side, true), A().ledger(true)]).then(([l]) => l.map(a => ({ id: a.id, no: a.no || a.id, name: a.name, bal: A().accBal(side, a), side }))) : Promise.resolve([]));
        Promise.all([accP, lastP]).then(([L]) => {
          let rows = L.map(p => { const debt = p.side === "cu" ? -(+p.bal || 0) : p.side === "su" ? -(+p.bal || 0) : (+p.bal || 0); return { code: p.no, name: p.name, dr: debt > 0 ? r2(debt) : 0, cr: debt < 0 ? r2(-debt) : 0, last: last[p.id] ? dmy(last[p.id]) : "", days: last[p.id] ? daysBetween(last[p.id], today()) : "" }; });
          if (!v.zero) rows = rows.filter(x => x.dr || x.cr);
          if (v.sel.includes(0) && v.code) { const [a, b] = v.code.split("-").map(s => s.trim()); rows = rows.filter(x => String(x.code) >= a && (!b || String(x.code) <= b)); }
          if (v.sel.includes(3) && v.names) { const q = norm(v.names); rows = rows.filter(x => norm(x.name).includes(q)); }
          rows.sort((a, b) => String(a.code).localeCompare(String(b.code), "en", { numeric: true }));
          const cols = rev ? [{ t: "الكود", k: "code", w: 18 }, { t: "الاسم", k: "name", w: 50, cls: "l" }, { t: "", k: "c", w: 9, f: () => "DZD", nosort: 1 }, { t: "مدين", k: "dr", w: 24, n: 1, sum: 1 }, { t: "دائن", k: "cr", w: 24, n: 1, sum: 1 }, { t: "الرصيد", k: "b", w: 24, n: 1, sum: 1, f: x => r2(x.dr - x.cr) }]
            : [{ t: "الكود", k: "code", w: 18 }, { t: "الاسم", k: "name", w: 50, cls: "l" }, { t: "", k: "c", w: 9, f: () => "DZD", nosort: 1 }, { t: "مدين", k: "dr", w: 22, n: 1, sum: 1 }, { t: "دائن", k: "cr", w: 22, n: 1, sum: 1 }].concat(side === "cu" || side === "su" ? [{ t: "اخر تعامل", k: "last", w: 20 }, { t: "المدة بالايام", k: "days", w: 18 }] : []);
          busy(T.host, false);
          showDoc(T.host, { title: r.name, chips: [["حتى", dmy(v.sel && v.sel.includes(2) ? v.to : today())]], cols, rows }, r.name);
        }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
      } }));
  }
  /* --- حركة عميل / مورد (FrmCustTransaction) — لوحة DEXEF: الفرع، الفترة، البحث بـ + اسم الحساب، 7 أنواع بعمودين، بدون/بحث متقدم --- */
  const PM_TYPES = ["عام", "مفصل", "موضحاً الأصناف", "موضحاً القيود", "موضحاً تواريخ السداد", "موضحاً العملة", "موضحاً الاوراق المالية"];
  const userName = () => (window.ANOUER_RD && ANOUER_RD.userName ? ANOUER_RD.userName() : "") || window.__USER_NAME || "";
  const PDOCS = ["cop", "cadj", "cbad", "cdn"];
  /* كل حركات حساب عميل/مورد (بمنظور مدين موجب): الفواتير، المدفوع فيها، سندات الاستلام/الدفع، مستندات العملاء والموردين، سندات الخزينة المرتبطة */
  function partyMoves(side, pid, D, docs) {
    /* «تعامل نقدي» (مثل «عميل نقدي» في DEXEF): كل فواتير الطرف بلا حساب — pid = "__cash" */
    const pk = side === "cu" ? "c" : "s", mv = [], invPaid = {}, cash = pid === "__cash", cashT = side === "cu" ? /^Sale/ : /^Purchase/;
    const all = [].concat(...Object.values(docs));
    all.forEach(d => ((d.data && d.data.fx) || []).forEach(f => { if (f.t === "inv") invPaid[f.id] = (invPaid[f.id] || 0) + (+f.d || 0); }));
    D.inv.forEach(x => {
      if (cash ? (x.pk || !cashT.test(x.t)) : (x.pk !== pk || String(x.pid) !== String(pid))) return;
      if (!/^(Sale|SaleReturn|Purchase|PurchaseReturn)$/.test(x.t)) return;
      const drSide = x.t === "Sale" || x.t === "PurchaseReturn", ttl = (x.t === "Sale" || x.t === "Purchase" ? "فاتورة " : "") + TYPE[x.t] + " رقم " + x.no;
      mv.push({ dt: x.dt, date: x.date, time: x.time, no: x.no, stmt: ttl, dr: drSide ? x.total : 0, cr: drSide ? 0 : x.total, gross: x.gross, disc: x.disc, tax: x.tax, user: x.user, due: x.due, _x: x, _inv: x.id, kind: "inv" });
      const paid = r2(x.paid - (invPaid[x.id] || 0));
      if (paid > 0.004) mv.push({ dt: x.dt + "~", date: x.date, time: x.time, no: x.no, stmt: (drSide ? (side === "cu" ? "تحصيل نقدية" : "استلام نقدية") : (side === "cu" ? "سداد نقدية" : "سداد نقدية")) + " - " + TYPE[x.t] + " رقم " + x.no, dr: drSide ? 0 : paid, cr: drSide ? paid : 0, user: x.user, kind: "pay", _x: x });
    });
    if (!cash) (docs.recv || []).concat(docs.pay || []).forEach(d => { const x = d.data || {}; if ((x.side || "cu") !== side || String(x.pid) !== String(pid)) return;
      const recv = (docs.recv || []).includes(d), amt = r2((+x.amt || 0) + (+x.disc || 0));
      mv.push({ dt: (x.date || "") + " " + (x.time || ""), date: x.date, time: x.time || "", no: d.no, stmt: (recv ? "استلام نقدية" : "دفع نقدية") + (x.notes ? " - " + x.notes : ""), dr: recv ? 0 : amt, cr: recv ? amt : 0, user: x.user || "", kind: "doc", acc: (x.acc || {}).name || "الخزينة", _id: d.id, _dk: recv ? "recv" : "pay" }); });
    if (!cash) PDOCS.forEach(k => (docs[k] || []).forEach(d => { const x = d.data || {}; if ((x.side || "cu") !== side || String(x.pid) !== String(pid)) return;
      (x.st || []).forEach(l => mv.push({ dt: (l.date || x.date) + " " + (x.time || ""), date: l.date || x.date, time: x.time || "", no: l.no || d.no, stmt: l.type, dr: +l.dr || 0, cr: +l.cr || 0, user: x.user || "", kind: k, _id: d.id, acc: k === "cop" ? "الأرصدة الإفتتاحية" : k === "cbad" ? "ديون معدومة" : k === "cdn" ? "خصم مسموح به" : "فروق تسويات مالية" })); }));
    if (side === "cu" && !cash) (D.cv || []).filter(c => String(c.cid) === String(pid) && c.cid).forEach(c => mv.push({ dt: c.dt, date: c.date, time: c.time, no: c.no, stmt: (c.type === "Receipt" ? "قبض نقدية" : "صرف نقدية") + (c.notes ? " - " + c.notes : ""), dr: c.type === "Receipt" ? 0 : c.amt, cr: c.type === "Receipt" ? c.amt : 0, user: c.user, kind: "cv", acc: c.tr, _id: c.id, _cv: c }));
    mv.sort((a, b) => String(a.dt).localeCompare(String(b.dt)));
    return mv;
  }
  function partyMove(r, pre) {
    const side = /Vendor|مورد/.test(r.tags + r.name) ? "su" : "cu", T = resultTab(r, true), sideEl = T.el.querySelector(".rp-side"); sideEl.classList.add("v");
    branches().then(() => parties(side).then(PL => {
      const items = PL.map(p => Object.assign({}, p, { dbal: r2(-(+p.bal || 0)) }));
      T.side.innerHTML = V.br() + V.per() + `<div class="rp-f v"><span class="lb">البحث بـ<i class="req">*</i></span><span class="rp-by"><select data-k="by" title="البحث بـ"><option value="name">الاسم</option><option value="no">الكود</option></select><span data-lk=""></span></span></div>`
        + V.f("نوع التقرير", '<span data-tl=""></span>', 0, "top") + `<div data-adv=""></div>`;
      T.side.querySelectorAll("[data-per]").forEach(h => h._P = perPicker(h));
      const LK = lookup(T.side.querySelector("[data-lk]"), { items, cols: [["no", "الكود", 86], ["name", "اسم الحساب"], ["dbal", "الرصيد", 84, "n"]], ph: "اسم الحساب", pw: 400 });
      const by = T.side.querySelector('[data-k="by"]'); by.onchange = () => { LK.setBy(by.value); LK.el.placeholder = by.value === "no" ? "كود الحساب" : "اسم الحساب"; LK.focus(); };
      const TL = typeList(T.side.querySelector("[data-tl]"), PM_TYPES, { cols: 2 });
      advRow(T.side.querySelector("[data-adv]"), r, [["date", "التاريخ"], ["no", "الرقم"], ["stmt", "البيان"], ["dr", "مدين"], ["cr", "دائن"]]);
      const go = () => {
        const v = vals(sideEl); v.type = TL.get();
        const p = LK.get(); if (!p) { alertDlg(REQ_MSG, () => LK.bad()); return; }
        if (v.newtab) { partyMove(r, { v, p: p.id, t: v.type }); return; }
        busy(T.host, true);
        const ks = ["recv", "pay"].concat(PDOCS);
        Promise.all([data(v.from, today()), parties(side, true).catch(() => PL)].concat(ks.map(k => A() ? A().docs(k, true).catch(() => []) : []))).then(([D, PL2, ...dl]) => {
          const docs = {}; ks.forEach((k, i) => docs[k] = dl[i] || []);
          const pp = PL2.find(x => String(x.id) === String(p.id)) || p, cur = r2(-(+pp.bal || 0));
          const mv = partyMoves(side, p.id, D, docs).filter(m => m.date >= v.from && filt({ br: v.br }, m._x || {}));
          const prev = r2(cur - mv.reduce((t, m) => t + m.dr - m.cr, 0));
          let bal = prev; const ti = v.type, rows = [];
          mv.filter(m => m.date <= v.to).forEach(m => {
            bal = r2(bal + m.dr - m.cr);
            const row = Object.assign({}, m, { date: dmy(m.date), bal, dr: m.dr || "", cr: m.cr || "", cur: "DZD", rate: 1, fdr: m.dr || "", fcr: m.cr || "" });
            if (ti === 4) { row.dued = m.due ? dmy(m.due) : ""; row.late = m.kind === "inv" && m.due && m._x && m._x.total - m._x.paid > 0.004 ? Math.max(0, daysBetween(m.due, today())) : ""; row.rem = m.kind === "inv" && m._x ? r2(m._x.total - m._x.paid) : ""; }
            rows.push(row);
            if (ti === 2 && m.kind === "inv" && m._x) m._x.lines.forEach(l => rows.push({ date: "", no: "", stmt: "      " + l.name + (l.unit ? " (" + l.unit + ")" : ""), qty: l.qty, price: l.price, val: l.total, dr: "", cr: "", bal: "", _pid: l.pid, _cls: "it", _keep: 1 }));
            if (ti === 3) { const party = p.name, acc = m.kind === "inv" ? (side === "cu" ? "المبيعات" : "المشتريات") : (m.acc || "الخزينة"), amt = m.dr || m.cr;
              const L = m.dr ? [[party, amt, ""], [acc, "", amt]] : [[acc, amt, ""], [party, "", amt]];
              L.forEach(a => rows.push({ date: "", no: "", stmt: "      " + a[0], jdr: a[1], jcr: a[2], dr: "", cr: "", bal: "", _cls: "it", _keep: 1 })); }
          });
          let R = applyAdv(applyOF(rows, v), v);
          const base = [{ t: "التاريخ", k: "date", w: 19 }, { t: "الرقم", k: "no", w: 15 }];
          const money = [{ t: "مدين", k: "dr", w: 21, n: 1, sum: 1 }, { t: "دائن", k: "cr", w: 21, n: 1, sum: 1 }, { t: "الرصيد", k: "bal", w: 22, n: 1 }];
          let cols, land = false, sfx = "";
          if (ti === 0) cols = base.concat([{ t: "البيان", k: "stmt", w: 70, cls: "l" }], money);
          else if (ti === 1) { land = true; sfx = " مفصل"; cols = base.concat([{ t: "الوقت", k: "time", w: 11 }, { t: "البيان", k: "stmt", w: 66, cls: "l" }, { t: "الاجمالي", k: "gross", w: 19, n: 1 }, { t: "الخصم", k: "disc", w: 15, n: 1 }, { t: "الضريبة", k: "tax", w: 15, n: 1 }], money, [{ t: "المستخدم", k: "user", w: 22 }]); }
          else if (ti === 2) { sfx = " موضحاً الأصناف"; cols = base.concat([{ t: "البيان", k: "stmt", w: 54, cls: "l" }, { t: "الكمية", k: "qty", w: 12, n: 1 }, { t: "السعر", k: "price", w: 15, n: 1 }, { t: "القيمة", k: "val", w: 17, n: 1 }], money); }
          else if (ti === 3) { sfx = " موضحاً القيود"; cols = base.concat([{ t: "البيان / الحساب", k: "stmt", w: 52, cls: "l" }, { t: "مدين القيد", k: "jdr", w: 18, n: 1 }, { t: "دائن القيد", k: "jcr", w: 18, n: 1 }], money); }
          else if (ti === 4) { land = true; sfx = " موضحاً تواريخ السداد"; cols = base.concat([{ t: "البيان", k: "stmt", w: 62, cls: "l" }], money, [{ t: "تاريخ الاستحقاق", k: "dued", w: 22 }, { t: "المتبقي", k: "rem", w: 20, n: 1 }, { t: "أيام التأخير", k: "late", w: 17, n: 1 }]); }
          else if (ti === 5) { land = true; sfx = " موضحاً العملة"; cols = base.concat([{ t: "البيان", k: "stmt", w: 62, cls: "l" }, { t: "العملة", k: "cur", w: 12, nosort: 1 }, { t: "معامل", k: "rate", w: 11, n: 1 }, { t: "مدين بالعملة", k: "fdr", w: 21, n: 1, sum: 1 }, { t: "دائن بالعملة", k: "fcr", w: 21, n: 1, sum: 1 }], money); }
          else { sfx = " موضحاً الاوراق المالية"; cols = base.concat([{ t: "البيان", k: "stmt", w: 56, cls: "l" }, { t: "الورقة المالية", k: "chq", w: 22, f: () => "" }], money); }
          const ttl = (side === "su" ? "حركة مورد" : "حركة عميل") + sfx;
          const bx2 = [[["الرقم", pp.no || ""], ["الاسم", pp.name], ["الفرع", v.br]], [["الرصيد الحالي", nf(cur), "DZD", "n"], ["طبع بواسطة", userName()], ["رصيد سابق", nf(prev), "", "n"]]];
          busy(T.host, false);
          showDoc(T.host, { title: ttl, chips: chipsOf(v), bx2, cols, rows: R, land, totPlain: true, totExtra: { bal } }, ttl);
        }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
      };
      T.el.querySelector(".rp-show").onclick = go;
      sideEl.addEventListener("keydown", e => { if (e.key === "F2" || (e.key === "Enter" && e.ctrlKey)) { e.preventDefault(); go(); } });
      if (pre) { restore(sideEl, pre.v); TL.set(pre.t || 0); LK.set(pre.p, true); setTimeout(go, 30); } else setTimeout(() => LK.focus(), 80);
    }));
  }
  /* --- اجمالي تعاملات عميل/مورد ومسحوبات العملاء (FrmAccountSum للعملاء) --- */
  function partySum(r) {
    const side = /Vendor|مورد/.test(r.tags + r.name) ? "su" : "cu", pk = side === "cu" ? "c" : "s";
    branches().then(() => paramDlg(r, { types: ["يومي", "أسبوعي", "شهري", "سنوي", "لكل حساب"], type: 4, fields: F.br() + F.per() + F.of(r, [["name", "الاسم"], ["total", "الصافي"], ["cnt", "العدد"]]), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      data(v.from, v.to).then(D => {
        const m = {}, bk = [0, 1, 2, 4][v.type];
        D.inv.forEach(x => { if (x.pk !== pk || !filt({ br: v.br }, x)) return; if (!/^(Sale|SaleReturn|Purchase|PurchaseReturn)$/.test(x.t)) return;
          const key = v.type === 4 ? x.pid : bucketOf(x.date, bk)[0], name = v.type === 4 ? x.pname : bucketOf(x.date, bk)[1], s = sg(x);
          const g = m[key] || (m[key] = { name, cnt: 0, gross: 0, disc: 0, total: 0, paid: 0, rem: 0, _k: String(key) }); g.cnt++; g.gross += s * x.gross; g.disc += s * x.disc; g.total += s * x.total; g.paid += s * x.paid; g.rem += s * (x.total - x.paid); });
        let rows = Object.values(m).sort((a, b) => v.type === 4 ? b.total - a.total : a._k.localeCompare(b._k)); rows = applyOF(rows, v);
        busy(T.host, false);
        showDoc(T.host, { title: r.name, chips: chipsOf(v), boxes: [["اسم الفرع", v.br]], cols: [{ t: v.type === 4 ? "الاسم" : "الفترة", k: "name", w: 50, cls: "l" }, { t: "العدد", k: "cnt", w: 12, n: 1, sum: 1 }, { t: "الاجمالي", k: "gross", w: 22, n: 1, sum: 1 }, { t: "الخصم", k: "disc", w: 18, n: 1, sum: 1 }, { t: "الصافي", k: "total", w: 22, n: 1, sum: 1 }, { t: "المدفوع", k: "paid", w: 22, n: 1, sum: 1 }, { t: "الباقي", k: "rem", w: 22, n: 1, sum: 1 }], rows }, r.name);
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }
  /* --- ملف العملاء / الموردين (FrmCustomerFile): ترتيب الحسابات بالمسحوبات + رسم بياني --- */
  function partyFile(r) {
    const side = /Vendor|مورد/.test(r.tags + r.name) ? "su" : "cu", pk = side === "cu" ? "c" : "s";
    branches().then(() => paramDlg(r, { types: ["شهري", "ربع سنوي", "سنوي"], fields: F.br() + F.per(), onInit: ov => ov.querySelector("[data-per]")._P.set(8), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      data(v.from, v.to).then(D => {
        const cells = {}, cols = {}, rowsT = {}, bk = [2, 3, 4][v.type];
        D.inv.forEach(x => { if (x.pk !== pk || !filt({ br: v.br }, x) || !/^(Sale|SaleReturn|Purchase|PurchaseReturn)$/.test(x.t)) return; const b = bucketOf(x.date, bk), k = x.pname, s = sg(x); const c = cells[k] || (cells[k] = {}); c[b[0]] = (c[b[0]] || 0) + s * x.total; cols[b[0]] = b[1]; rowsT[k] = (rowsT[k] || 0) + s * x.total; });
        busy(T.host, false);
        pivotView(T, r, Object.assign(v, { type: [2, 3, 4][v.type] }), { ck: Object.keys(cols).sort(), cols, rk: Object.keys(rowsT).sort((a, b) => rowsT[b] - rowsT[a]), cells, rowsT });
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }

  /* --- المخازن: جرد / حركة / نواقص / مجموعات / تنبيهات / فهرس --- */
  function stockCount(r) {
    const cost = /Cost|التكلفة/.test(r.tags + r.name), move = /Move|حركة/.test(r.tags + r.name), unite = /Unite|الوحدات/.test(r.tags + r.name);
    paramDlg(r, { types: move ? ["حسب الكمية"] : ["الكل", "الأرصدة الموجبة فقط", "الأرصدة السالبة فقط", "الأرصدة الصفرية"], fields: F.wh() + (move ? F.per() : "") + `<label class="rp-f"><span>فلتر البحث</span><input data-k="q" placeholder="اسم الصنف / الكود / المجموعة" autocomplete="off"></label>` + F.sel("ok", "ترتيب النتائج بواسطة", [["name", "اسم الصنف"], ["code", "الكود"], ["cat", "المجموعة"], ["stock", "الرصيد"]]), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      Promise.all([products(), move ? data(v.from, v.to) : Promise.resolve(null)]).then(([P, D]) => {
        const W = window.ANOUER_WH, q = norm(v.q || "");
        const qty = p => (W && v.wh !== "*" && W.qty && v.wh !== "" && !(W.isMain && W.isMain(+v.wh))) ? W.qty(p.id, +v.wh) : p.stock;
        let rows = P.filter(p => p.active && (!q || norm(p.name + " " + p.code + " " + p.cat).includes(q))).map(p => ({ code: p.code, name: p.name, cat: p.cat, unit: p.unit, stock: r2(qty(p)), cost: p.cost, val: r2(qty(p) * p.cost), price: p.price, sval: r2(qty(p) * p.price), _p: p }));
        if (move && D) {
          const mv = {}; D.inv.forEach(x => { if (!filt({ wh: v.wh }, x)) return; const s = SIGN[x.t]; if (!s) return; x.lines.forEach(l => { const g = mv[l.pid] || (mv[l.pid] = { in: 0, out: 0 }); const qq = l.qty * l.fac; if (s > 0) g.in += qq; else g.out += qq; }); });
          rows.forEach(x => { const g = mv[x._p.id] || { in: 0, out: 0 }; x.inq = r2(g.in); x.outq = r2(g.out); x.open = r2(x.stock - g.in + g.out); });
          rows = rows.filter(x => x.inq || x.outq || x.open);
        } else if (v.type === 1) rows = rows.filter(x => x.stock > 0); else if (v.type === 2) rows = rows.filter(x => x.stock < 0); else if (v.type === 3) rows = rows.filter(x => !x.stock);
        rows = applyOF(rows, { ok: v.ok, od: "asc" });
        const cols = move ? [{ t: "الكود", k: "code", w: 26 }, { t: "اسم الصنف", k: "name", w: 52, cls: "l" }, { t: "رصيد أول الفترة", k: "open", w: 20, n: 1, sum: 1 }, { t: "وارد", k: "inq", w: 16, n: 1, sum: 1, hc: "#2e8b57" }, { t: "منصرف", k: "outq", w: 16, n: 1, sum: 1, hc: "#7b3b3b" }, { t: "الرصيد", k: "stock", w: 18, n: 1, sum: 1 }].concat(cost ? [{ t: "التكلفة", k: "cost", w: 16, n: 1 }, { t: "قيمة الرصيد", k: "val", w: 22, n: 1, sum: 1 }] : [])
          : [{ t: "الكود", k: "code", w: 26 }, { t: "اسم الصنف", k: "name", w: 56, cls: "l" }, { t: "المجموعة", k: "cat", w: 22 }, { t: "الوحدة", k: "unit", w: 14 }, { t: "الرصيد", k: "stock", w: 17, n: 1, sum: 1 }].concat(cost ? [{ t: "التكلفة", k: "cost", w: 16, n: 1 }, { t: "قيمة التكلفة", k: "val", w: 22, n: 1, sum: 1 }] : unite ? [] : [{ t: "سعر البيع", k: "price", w: 16, n: 1 }, { t: "قيمة البيع", k: "sval", w: 22, n: 1, sum: 1 }]);
        busy(T.host, false);
        showDoc(T.host, { title: r.name, chips: move ? chipsOf(v) : [["حتى", dmy(today())]], boxes: [["المخزن", v.wh === "*" ? "كل المخازن" : storeName(v.wh)]], cols, rows }, r.name);
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } });
  }
  function groupBal(r) {
    const cost = /Cost|القيمة|التكلفة/.test(r.tags + r.name), move = /Move|حركة/.test(r.tags + r.name);
    paramDlg(r, { types: ["كل المجموعات"], fields: F.wh() + (move ? F.per() : ""), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      Promise.all([products(), move ? data(v.from, v.to) : Promise.resolve(null)]).then(([P, D]) => {
        const m = {};
        P.filter(p => p.active).forEach(p => { const k = p.cat || "بدون مجموعة", g = m[k] || (m[k] = { cat: k, n: 0, stock: 0, val: 0, inq: 0, outq: 0 }); g.n++; g.stock += p.stock; g.val += p.stock * p.cost; });
        if (D) { const byP = {}; P.forEach(p => byP[p.id] = p); D.inv.forEach(x => { const s = SIGN[x.t]; if (!s) return; x.lines.forEach(l => { const k = (byP[l.pid] && byP[l.pid].cat) || l.cat || "بدون مجموعة", g = m[k] || (m[k] = { cat: k, n: 0, stock: 0, val: 0, inq: 0, outq: 0 }); if (s > 0) g.inq += l.qty * l.fac; else g.outq += l.qty * l.fac; }); }); }
        const rows = Object.values(m).sort((a, b) => a.cat.localeCompare(b.cat, "ar"));
        busy(T.host, false);
        showDoc(T.host, { title: r.name, chips: move ? chipsOf(v) : [["حتى", dmy(today())]], cols: [{ t: "المجموعة", k: "cat", w: 60, cls: "l" }, { t: "عدد الأصناف", k: "n", w: 18, n: 1, sum: 1 }].concat(move ? [{ t: "وارد", k: "inq", w: 20, n: 1, sum: 1 }, { t: "منصرف", k: "outq", w: 20, n: 1, sum: 1 }] : []).concat([{ t: "الرصيد", k: "stock", w: 22, n: 1, sum: 1 }]).concat(cost ? [{ t: "قيمة التكلفة", k: "val", w: 26, n: 1, sum: 1 }] : []), rows }, r.name);
      });
    } });
  }
  function shortage(r) {
    paramDlg(r, { types: ["أقل من حد الطلب", "الأرصدة السالبة والصفرية"], fields: F.wh(), onShow: v => {
      const T = resultTab(r, false);
      products().then(P => {
        const rows = P.filter(p => p.active && (v.type === 0 ? p.stock <= (p.min || 0) : p.stock <= 0)).map(p => ({ code: p.code, name: p.name, cat: p.cat, stock: p.stock, min: p.min, need: r2(Math.max(0, (p.min || 0) - p.stock)) }));
        showDoc(T.host, { title: r.name, chips: [["حتى", dmy(today())]], cols: [{ t: "الكود", k: "code", w: 26 }, { t: "اسم الصنف", k: "name", w: 60, cls: "l" }, { t: "المجموعة", k: "cat", w: 24 }, { t: "الرصيد", k: "stock", w: 18, n: 1 }, { t: "حد الطلب", k: "min", w: 18, n: 1 }, { t: "المطلوب", k: "need", w: 18, n: 1, sum: 1 }], rows }, r.name);
      });
    } });
  }
  function alerts(r) {
    paramDlg(r, { types: [r.name], fields: F.wh() + (/Fixed|الراكدة/.test(r.tags + r.name) ? F.per() : ""), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      const fixed = /Fixed|الراكدة/.test(r.tags + r.name);
      Promise.all([products(), fixed ? data(v.from, v.to) : Promise.resolve(null)]).then(([P, D]) => {
        let rows;
        if (fixed) { const sold = new Set(); D.inv.forEach(x => { if (x.t === "Sale") x.lines.forEach(l => sold.add(l.pid)); }); rows = P.filter(p => p.active && p.stock > 0 && !sold.has(p.id)); }
        else if (/Negative|السالبة/.test(r.tags + r.name)) rows = P.filter(p => p.active && p.stock < 0);
        else if (/Minimum|الأدني|الأدنى/.test(r.tags + r.name)) rows = P.filter(p => p.active && p.min && p.stock < p.min);
        else rows = P.filter(p => p.active && p.max && p.stock > p.max);
        rows = rows.map(p => ({ code: p.code, name: p.name, cat: p.cat, stock: p.stock, min: p.min, max: p.max, val: r2(p.stock * p.cost) }));
        busy(T.host, false);
        showDoc(T.host, { title: r.name, chips: fixed ? chipsOf(v) : [["حتى", dmy(today())]], cols: [{ t: "الكود", k: "code", w: 26 }, { t: "اسم الصنف", k: "name", w: 60, cls: "l" }, { t: "المجموعة", k: "cat", w: 24 }, { t: "الرصيد", k: "stock", w: 18, n: 1, sum: 1 }, { t: "الحد الأدنى", k: "min", w: 16, n: 1 }, { t: "الحد الأقصى", k: "max", w: 16, n: 1 }, { t: "قيمة التكلفة", k: "val", w: 22, n: 1, sum: 1 }], rows }, r.name);
      });
    } });
  }
  /* بيانات إضافية للأصناف: النوع، آخر مورد، الضريبة/الخصم من كارت الصنف (fm.items.review) */
  let IMETA = null;
  const TYN = { stock: "مخزون", group: "مجموعة", made: "منتج تام", service: "خدمة", serial: "مخزون بسيريال", expiry: "مخزون بصلاحية", consign: "بضاعة أمانة", apparel: "ملابس و أحذية" };
  function itemMeta() {
    if (IMETA) return IMETA;
    const px = s => { if (!s) return {}; if (typeof s === "object") return s; try { return JSON.parse(s) || {}; } catch (e) { return {}; } };
    const fv = (f, re) => { const k = Object.keys(f || {}).find(k => re.test(k)); return k ? f[k] : ""; };
    IMETA = (HOST() ? call("fm.items.review").then(r => { const m = {}; ((r && r.items) || []).forEach(it => { const x = px(it.extra), f = x.f || {}; m[it.id] = { type: it.type || "stock", sup: it.sup || (x.supplier && (x.supplier.name || x.supplier)) || "", min: +it.min || 0, tax: fv(f, /\|نسبة الضريبة\|0$/) || "", disc: fv(f, /نسبة الخصم|\|الخصم\|/) || "" }; }); return m; })
      : Promise.reject(0)).catch(() => { const m = {}, T = window.__ITYPE || {}; Object.keys(T).forEach(id => m[id] = { type: T[id] }); return m; });
    IMETA.catch(() => (IMETA = null));
    return IMETA;
  }
  /* --- فهرس الأصناف / قوائم الأسعار (FrmItemListRpt) — «تصفية النتائج بواسطة» بأزرار متعددة الاختيار (المحدد برتقالي) --- */
  const IL_FLT = ["كود الصنف", "نوع الصنف", "المجموعة", "المورد المفضل", "أصناف مضافه حديثاً"];
  function itemList(r) {
    const price = /Price|أسعار/.test(r.tags + r.name), unit = /Unite|بالوحدات/.test(r.tags + r.name);
    Promise.all([branches(), products(), itemMeta(), parties("su").catch(() => [])]).then(([, P, M, SU]) => {
      const cats = [...new Set(P.map(p => p.cat).filter(Boolean))].sort((a, b) => a.localeCompare(b, "ar"));
      const sups = [...new Set(Object.values(M).map(x => x.sup).filter(Boolean).concat(SU.map(s => s.name)))].sort((a, b) => a.localeCompare(b, "ar"));
      const types = [...new Set(P.map(p => (M[p.id] || {}).type || "stock"))];
      const slot = (i, h) => `<div class="rp-slot" data-s="${i}" hidden>${h}</div>`;
      const fields = `<div class="rp-slots">${slot(0, `<div class="rp-f"><span>كود الصنف</span><span class="rp-opr"><select data-k="cop" title="المعامل"><option value="eq">=</option><option value="sw">يبدأ بـ</option><option value="ct">يحتوي على</option><option value="rg">من - إلى</option></select><span data-lkc=""></span></span></div>`)
        + slot(1, `<label class="rp-f"><span>نوع الصنف</span><select data-k="ity">${types.map(t => `<option value="${esc(t)}">${esc(TYN[t] || t)}</option>`).join("")}</select></label>`)
        + slot(2, `<label class="rp-f"><span>المجموعة</span><select data-k="grp">${cats.map(c => `<option>${esc(c)}</option>`).join("") || "<option value=''>بدون مجموعات</option>"}</select></label>`)
        + slot(3, `<label class="rp-f"><span>المورد المفضل</span><select data-k="sup">${sups.map(c => `<option>${esc(c)}</option>`).join("") || "<option value=''>لا يوجد موردين</option>"}</select></label>`)
        + slot(4, `<label class="rp-f"><span>آخر أصناف مضافة</span><input data-k="newn" type="number" min="1" value="50"></label>`)}</div>` + F.br();
      let LKC = null;
      paramDlg(r, { typeLabel: "تصفية النتائج بواسطة", types: IL_FLT, multi: true, sel: [], fields,
        onInit: ov => { LKC = lookup(ov.querySelector("[data-lkc]"), { items: P, cols: [["code", "الكود", 110], ["name", "الاسم"]], key: "code", ph: "الكود", pw: 360 }); },
        onType: (sel, ov) => { ov.querySelectorAll(".rp-slot").forEach(s => { const on = sel.includes(+s.dataset.s), was = !s.hidden; s.hidden = !on; if (on && !was) { s.classList.remove("in"); void s.offsetWidth; s.classList.add("in"); } }); },
        check: v => { if (v.sel.includes(0) && !LKC.el.value.trim()) { alertDlg(REQ_MSG, () => LKC.bad()); return false; } },
        onShow: v => {
          const T = resultTab(r, false);
          const has = i => v.sel.includes(i), cq = String(LKC.el.value || "").trim();
          let L = P.filter(p => p.active);
          if (has(0) && cq) { const op = v.cop, c = norm(cq);
            if (op === "eq") L = L.filter(p => norm(p.code) === c); else if (op === "sw") L = L.filter(p => norm(p.code).startsWith(c)); else if (op === "ct") L = L.filter(p => norm(p.code).includes(c));
            else { const [a, b] = cq.split("-").map(x => x.trim()); L = L.filter(p => String(p.code).localeCompare(a, "en", { numeric: true }) >= 0 && (!b || String(p.code).localeCompare(b, "en", { numeric: true }) <= 0)); } }
          if (has(1)) L = L.filter(p => ((M[p.id] || {}).type || "stock") === v.ity);
          if (has(2)) L = L.filter(p => p.cat === v.grp);
          if (has(3)) L = L.filter(p => (M[p.id] || {}).sup === v.sup);
          if (has(4)) L = L.slice().sort((a, b) => (+b.id || 0) - (+a.id || 0)).slice(0, Math.max(1, +v.newn || 50));
          L = L.slice().sort((a, b) => String(a.code).localeCompare(String(b.code), "en", { numeric: true }));
          let rows = [];
          L.forEach(p => { const mt = M[p.id] || {};
            if (unit && p.units.length) p.units.slice().sort((a, b) => (+a.factor || 1) - (+b.factor || 1)).forEach(u => rows.push({ code: u.bc || p.code, name: p.name, unit: u.name, fac: +u.factor || 1, price: +u.price || 0, whole: +u.wp || +u.p5 || "", _pid: p.id }));
            else rows.push({ code: p.code, name: p.name, unit: p.unit, price: p.price, tax: mt.tax !== "" && mt.tax != null ? mt.tax : 0, disc: mt.disc !== "" && mt.disc != null ? mt.disc : 0, cat: p.cat, cost: p.cost, whole: (p.units.find(u => u.def) || p.units[0] || {}).wp || "", _pid: p.id }); });
          const cols = unit ? [{ t: "الكود", k: "code", w: 30 }, { t: "الاسم", k: "name", w: 66, cls: "l" }, { t: "الوحدة", k: "unit", w: 18 }, { t: "معامل", k: "fac", w: 13, n: 1 }, { t: "سعر البيع", k: "price", w: 20, n: 1 }, { t: "سعر الجملة", k: "whole", w: 20, n: 1 }]
            : price ? [{ t: "الكود", k: "code", w: 30 }, { t: "الاسم", k: "name", w: 72, cls: "l" }, { t: "الوحدة", k: "unit", w: 18 }, { t: "المجموعة", k: "cat", w: 28 }, { t: "سعر البيع", k: "price", w: 22, n: 1 }]
            : [{ t: "الكود", k: "code", w: 30 }, { t: "الاسم", k: "name", w: 70, cls: "l" }, { t: "الوحدة", k: "unit", w: 18 }, { t: "سعر البيع", k: "price", w: 20, n: 1 }, { t: "الضريبة %", k: "tax", w: 16, n: 1 }, { t: "الخصم", k: "disc", w: 15, n: 1 }];
          const chips = []; if (has(1)) chips.push(["نوع الصنف", TYN[v.ity] || v.ity]); if (has(2)) chips.push(["المجموعة", v.grp]); if (has(3)) chips.push(["المورد", v.sup]);
          showDoc(T.host, { title: r.name, chips: chips.slice(0, 2), boxes: [["اسم الفرع", v.br]], cols, rows, totals: false }, r.name);
        } });
    }).catch(e => say("تعذّر فتح التقرير: " + (e.message || e), "e"));
  }
  /* تعبئة لوحة جانبية بقيم سابقة («فتح التقرير فى صفحة جديدة») */
  function restore(side, v) {
    if (!v) return;
    side.querySelectorAll("[data-k]").forEach(x => { const k = x.dataset.k; if (!(k in v) || k === "newtab") return; if (x.type === "checkbox") x.checked = !!v[k]; else { x.value = v[k]; if (k === "ofm") x.dispatchEvent(new Event("change")); } });
    const ph = side.querySelector("[data-per]"); if (ph && ph._P && v.from) ph._P.set(v.i != null ? v.i : PERS.length - 1, [v.from, v.to]);
    side.querySelectorAll("[data-k]").forEach(x => { const k = x.dataset.k; if (k in v && x.closest(".rp-ofx") && x.type !== "checkbox") x.value = v[k]; });
  }
  /* تقسيم الكمية على وحدات الصنف (عرض بالوحدات الغير متجانسة): 2 كرتونة + 3 قطعة */
  function unitSplit(q, p) {
    const us = ((p && p.units) || []).filter(u => (+u.factor || 1) > 1).sort((a, b) => (+b.factor || 1) - (+a.factor || 1));
    const base = ((p && p.units) || []).find(u => (+u.factor || 1) === 1), bn = (base && base.name) || (p && p.unit) || "";
    const neg = q < 0; let x = Math.abs(r2(q)); const parts = [];
    us.forEach(u => { const f = +u.factor, n = Math.floor(x / f + 1e-9); if (n) { parts.push(n + " " + u.name); x = r2(x - n * f); } });
    if (x || !parts.length) parts.push(fmt(x) + (bn ? " " + bn : ""));
    const s = parts.join(" + "); return neg ? "[" + s + "]" : s;
  }
  /* --- حركة صنف (FrmItemMove) — لوحة DEXEF: الفرع، المخزن، الفترة، اسم الصنف + الكود، نوع التقرير (4)، الوحدات الغير متجانسة، بدون/بحث متقدم --- */
  const IM_TYPES = ["عام", "موضحاً الأسعار", "موضحاً التكلفة", "مفصل"];
  function itemMove(r, pre) {
    const T = resultTab(r, true), side = T.el.querySelector(".rp-side"); side.classList.add("v");
    branches().then(() => products().then(P => {
      T.side.innerHTML = V.br() + V.wh() + V.per() + V.f("اسم الصنف", '<span data-lk=""></span>', 1) + V.f("الكود", '<input data-k="code" autocomplete="off" spellcheck="false" placeholder="الكود / الباركود">', 0, "code")
        + V.f("نوع التقرير", '<span data-tl=""></span>', 0, "top") + `<div class="rp-f v">${F.chk("units", "عرض بالوحدات الغير متجانسة")}</div><div data-adv=""></div>`;
      T.side.querySelectorAll("[data-per]").forEach(h => h._P = perPicker(h));
      const codeEl = T.side.querySelector('[data-k="code"]');
      const LK = lookup(T.side.querySelector("[data-lk]"), { items: P, cols: [["code", "الكود", 104], ["name", "الاسم"], ["stock", "الرصيد", 64, "n"]], ph: "اكتب اسم الصنف...", pw: 380, onPick: p => { codeEl.value = p ? p.code : ""; if (p) codeEl.focus(); } });
      const findCode = c => { c = String(c || "").trim(); if (!c) return null; return P.find(p => String(p.code) === c) || P.find(p => (p.units || []).some(u => String(u.bc || "") === c)) || null; };
      codeEl.addEventListener("keydown", e => { if (e.key.length === 1 || e.key === "Backspace") e.stopPropagation(); if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); const p = findCode(codeEl.value); if (p) { LK.set(p, true); T.el.querySelector(".rp-show").focus(); } else if (codeEl.value.trim()) { say("الكود غير موجود", "w"); codeEl.select(); } } });
      codeEl.addEventListener("change", () => { const p = findCode(codeEl.value); if (p) LK.set(p, true); });
      const TL = typeList(T.side.querySelector("[data-tl]"), IM_TYPES);
      advRow(T.side.querySelector("[data-adv]"), r, [["date", "التاريخ"], ["no", "رقم التعامل"], ["deal", "التعامل"], ["inq", "وارد"], ["outq", "صادر"], ["bal", "الرصيد"]]);
      const go = () => {
        const v = vals(side); v.type = TL.get();
        const p = LK.get() || findCode(v.code);
        if (!p) { alertDlg(REQ_MSG, () => LK.bad()); return; }
        if (v.newtab) { itemMove(r, { v, p: p.id, t: v.type }); return; }
        busy(T.host, true);
        data(v.from, today()).then(D => {
          const W = window.ANOUER_WH, all = v.wh === "*";
          const cur = (W && !all && W.qty && v.wh !== "" && !(W.isMain && W.isMain(+v.wh))) ? +W.qty(p.id, +v.wh) || 0 : p.stock;
          const mv = [];
          D.inv.forEach(x => {
            if (!filt({ br: v.br }, x)) return;
            let s = SIGN[x.t] || 0;
            if (x.t === "Transfer") { if (all) return; s = String(x.towh) === String(v.wh) ? 1 : (filt({ wh: v.wh }, x) ? -1 : 0); }
            else if (!filt({ wh: v.wh }, x)) return;
            if (!s) return;
            x.lines.forEach(l => { if (String(l.pid) !== String(p.id)) return; const q = r2(l.qty * l.fac);
              const cpp = q ? (x.t === "Purchase" || x.t === "Opening" ? (l.total / q) : (l.cost / q)) : 0;
              mv.push({ dt: x.dt, date: x.date, no: x.no, deal: (TYPE[x.t] || x.t) + " - " + (x.pname || "تعامل نقدى"), s, q, inq: s > 0 ? q : 0, outq: s < 0 ? q : 0, bonus: 0, price: l.price, total: l.total, unit: l.unit, qty: l.qty, fac: l.fac, disc: l.disc, extra: 0, cpp: r2(cpp), _inv: x.id, _x: x }); });
          });
          mv.sort((a, b) => String(a.dt).localeCompare(String(b.dt)) || String(a.no).localeCompare(String(b.no), "en", { numeric: true }));
          const prev = r2(cur - mv.reduce((t, m) => t + m.s * m.q, 0));
          let bal = prev, avg = +p.cost || 0;
          let rows = mv.filter(m => m.date <= v.to).map(m => {
            if (m.s > 0 && (m.deal.startsWith("مشتريات") || m.deal.startsWith(TYPE.Opening)) && m.cpp > 0) avg = bal + m.q > 0 ? r2((Math.max(0, bal) * avg + m.q * m.cpp) / (Math.max(0, bal) + m.q)) : m.cpp;
            bal = r2(bal + m.s * m.q);
            return Object.assign({}, m, { date: dmy(m.date), bal, inc: m.s > 0 ? (m.cpp || avg) : "", outc: m.s < 0 ? (m.cpp || avg) : "", balc: r2(bal * avg), inq: m.inq || "", outq: m.outq || "", _cls: m.s < 0 ? "" : "", _pid: null });
          });
          rows = applyAdv(applyOF(rows, v), v);
          const split = !!v.units, qf = k => x => x[k] === "" || x[k] == null ? "" : unitSplit(+x[k], p);
          const qc = (t, k, w, sum) => split ? { t, k, w: w + 10, f: qf(k), sum } : { t, k, w, n: 1, sum };
          const tin = r2(mv.filter(m => m.date <= v.to).reduce((t, m) => t + m.inq, 0)), tout = r2(mv.filter(m => m.date <= v.to).reduce((t, m) => t + m.outq, 0));
          const tot = split ? { inq: tin ? unitSplit(tin, p) : "", outq: tout ? unitSplit(tout, p) : "", bal: unitSplit(bal, p) } : { bal };
          const base = [{ t: "التاريخ", k: "date", w: 20 }, { t: "رقم التعامل", k: "no", w: 17 }];
          let cols, bands = null, land = false, ttl = r.name.replace(/ (مرتبة بــ|مع)$/, "");
          const ti = v.type;
          if (ti === 0) cols = base.concat([{ t: "التعامل", k: "deal", w: 66, cls: "l" }, qc("وارد", "inq", 18, 1), qc("صادر", "outq", 18, 1), qc("الرصيد", "bal", 20)]);
          else if (ti === 1) { cols = base.concat([{ t: "التعامل", k: "deal", w: 50, cls: "l" }, qc("وارد", "inq", 15, 1), qc("صادر", "outq", 15, 1), { t: "بونص", k: "bonus", w: 12, n: 1, sum: 1 }, { t: "السعر (DZD)", k: "price", w: 17, n: 1 }, { t: "الاجمالي", k: "total", w: 20, n: 1, sum: 1 }, qc("الرصيد", "bal", 17)]); ttl += " موضحاً الأسعار"; }
          else if (ti === 2) { cols = base.concat([{ t: "التعامل", k: "deal", w: 46, cls: "l" }, qc("الكمية", "inq", 14, 1), { t: "تكلفة القطعة", k: "inc", w: 16, n: 1 }, qc("الكمية", "outq", 14, 1), { t: "تكلفة القطعة", k: "outc", w: 16, n: 1 }, qc("الرصيد", "bal", 15), { t: "التكلفة", k: "balc", w: 19, n: 1 }]);
            bands = [{ t: "", span: [0, 1, 2] }, { t: "وارد", span: [3, 4], c: "#6b8e23" }, { t: "منصرف", span: [5, 6], c: "#f08a24" }, { t: "الرصيد", span: [7, 8], c: "#3c9cf4" }]; ttl += " موضحاً التكلفة";
            if (!split) tot.balc = r2(bal * avg); }
          else { land = true; ttl += " مفصل";
            rows.forEach(x => { x.qtyS = x.qty; });
            cols = base.concat([{ t: "التعامل", k: "deal", w: 56, cls: "l" }, { t: "الكمية", k: "qtyS", w: 14, n: 1 }, { t: "البونص", k: "bonus", w: 12, n: 1 }, { t: "الوحدة", k: "unit", w: 16 }, { t: "السعر", k: "price", w: 16, n: 1 }, { t: "عملة", k: "cur", w: 11, f: () => "DZD", nosort: 1 }, { t: "معامل", k: "fac", w: 11, n: 1 }, { t: "خصم", k: "disc", w: 13, n: 1, sum: 1 }, { t: "اضافي", k: "extra", w: 13, n: 1, sum: 1 }, { t: "اجمالي", k: "total", w: 19, n: 1, sum: 1 }, qc("الرصيد", "bal", 18)]); }
          const bx2 = [[["الرقم", p.code], ["الاسم", p.name], ["اسم الفرع", v.br]], [["الرصيد الحالي", split ? unitSplit(cur, p) : nf(cur), "", "n"], ["المخزن", all ? "كل المخازن" : storeName(v.wh)], ["رصيد سابق", split ? unitSplit(prev, p) : nf(prev), "", "n"]]];
          busy(T.host, false);
          showDoc(T.host, { title: ttl, chips: chipsOf(v), bx2, cols, bands, rows, land, totExtra: tot }, ttl);
        }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
      };
      T.el.querySelector(".rp-show").onclick = go;
      side.addEventListener("keydown", e => { if (e.key === "F2" || (e.key === "Enter" && e.ctrlKey)) { e.preventDefault(); go(); } });
      if (pre) { restore(side, pre.v); TL.set(pre.t || 0); LK.set(pre.p, true); const pp = P.find(x => String(x.id) === String(pre.p)); if (pp) codeEl.value = pp.code; setTimeout(go, 30); }
      else setTimeout(() => LK.focus(), 80);
    }));
  }

  /* --- الأرباح: أرباح الأصناف/العملاء/الفواتير وقائمة الدخل --- */
  function profitRows(D, v, by) {
    const m = {};
    D.inv.forEach(x => { if ((x.t !== "Sale" && x.t !== "SaleReturn") || !filt({ br: v.br, wh: v.wh }, x)) return; const s = sg(x);
      const invDiscShare = x.gross ? (x.disc - x.lines.reduce((a, l) => a + l.disc, 0)) / x.gross : 0;
      x.lines.forEach(l => { const k = by(x, l), g = m[k.k] || (m[k.k] = Object.assign({ qty: 0, sales: 0, cost: 0 }, k.o)); const net = l.total - l.total * Math.max(0, invDiscShare);
        g.qty += s * l.qty * l.fac; g.sales += s * net; g.cost += s * l.cost; }); });
    return Object.values(m).map(g => Object.assign(g, { qty: r2(g.qty), sales: r2(g.sales), cost: r2(g.cost), profit: r2(g.sales - g.cost), pct: g.sales ? r2((g.sales - g.cost) / g.sales * 100) : 0 }));
  }
  function profitRpt(r) {
    const tg = r.tags;
    const isItem = /Item|Store|Group/.test(tg), loss = /Loss|Less/.test(tg), grp = /Group/.test(tg), store = /Store/.test(tg);
    branches().then(() => paramDlg(r, { types: [isItem ? (grp ? "بالمجموعات" : store ? "بالمخزن" : "بالأصناف") : "بالعملاء"], fields: F.br() + (isItem ? F.wh() : "") + F.per() + F.sel("ok", "ترتيب النتائج بواسطة", [["profit", "الربح"], ["sales", "المبيعات"], ["name", "الاسم"], ["pct", "نسبة الربح"]]), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      data(v.from, v.to).then(D => {
        let rows = profitRows(D, v, isItem ? (grp ? (x, l) => ({ k: l.cat || "بدون مجموعة", o: { name: l.cat || "بدون مجموعة" } }) : store ? (x) => ({ k: "w" + (x.wh || 0), o: { name: storeName(x.wh) } }) : (x, l) => ({ k: l.pid, o: { name: l.name, code: l.code } })) : (x) => ({ k: x.pid || x.pname, o: { name: x.pname || "تعامل نقدى", code: x.pcode } }));
        if (loss) rows = rows.filter(g => g.profit < 0);
        rows = applyOF(rows, { ok: v.ok, od: v.ok === "name" ? "asc" : (loss ? "asc" : "desc") });
        rows.forEach(g => { if (g.profit < 0) g._cls = "neg"; });
        busy(T.host, false);
        showDoc(T.host, { title: r.name, chips: chipsOf(v), boxes: [["اسم الفرع", v.br]], cols: [{ t: isItem && !grp && !store ? "اسم الصنف" : isItem ? "البيان" : "الاسم", k: "name", w: 56, cls: "l" }].concat(isItem && !grp && !store ? [{ t: "الكمية", k: "qty", w: 15, n: 1, sum: 1 }] : []).concat([{ t: "صافي المبيعات", k: "sales", w: 24, n: 1, sum: 1 }, { t: "التكلفة", k: "cost", w: 24, n: 1, sum: 1 }, { t: "مجمل الربح", k: "profit", w: 24, n: 1, sum: 1 }, { t: "نسبة الربح %", k: "pct", w: 16, n: 1 }]), rows }, r.name);
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }
  function profitPivot(r) {
    const item = r.frm === "PivotItemProfit", bk = { Month: 2, Quarter: 3, Year: 4, Week: 1 }[r.tags] || 2;
    branches().then(() => paramDlg(r, { types: [BUCKETS[bk]], fields: F.br() + F.per(), onInit: ov => ov.querySelector("[data-per]")._P.set(8), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      data(v.from, v.to).then(D => {
        const cells = {}, cols = {}, rowsT = {};
        D.inv.forEach(x => { if (x.t !== "Sale" && x.t !== "SaleReturn" || !filt({ br: v.br }, x)) return; const b = bucketOf(x.date, bk), s = sg(x);
          x.lines.forEach(l => { const k = item ? l.name : (x.pname || "تعامل نقدى"), pr = s * (l.total - l.cost); const c = cells[k] || (cells[k] = {}); c[b[0]] = (c[b[0]] || 0) + pr; cols[b[0]] = b[1]; rowsT[k] = (rowsT[k] || 0) + pr; }); });
        busy(T.host, false);
        pivotView(T, r, Object.assign(v, { type: bk }), { ck: Object.keys(cols).sort(), cols, rk: Object.keys(rowsT).sort((a, b) => rowsT[b] - rowsT[a]), cells, rowsT });
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }
  function invoiceProfit(r) {
    const det = /Detail|مفصلة/.test(r.tags + r.name);
    branches().then(() => paramDlg(r, { types: [det ? "مفصلة بالأصناف" : "إجمالي لكل فاتورة"], fields: F.br() + F.per(), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      data(v.from, v.to).then(D => {
        const rows = [];
        D.inv.filter(x => (x.t === "Sale" || x.t === "SaleReturn") && filt({ br: v.br }, x)).forEach(x => { const s = sg(x), cost = r2(x.lines.reduce((a, l) => a + l.cost, 0));
          rows.push({ _x: x, date: dmy(x.date), no: x.no, name: x.pname, sales: r2(s * x.total), cost: r2(s * cost), profit: r2(s * (x.total - cost)), pct: x.total ? r2((x.total - cost) / x.total * 100) : 0, _cls: det ? "sub" : (x.total - cost < 0 ? "neg" : "") });
          if (det) x.lines.forEach(l => rows.push({ date: "", no: "", name: "   " + l.name + " × " + r2(l.qty), sales: r2(s * l.total), cost: r2(s * l.cost), profit: r2(s * (l.total - l.cost)), pct: l.total ? r2((l.total - l.cost) / l.total * 100) : 0, _sub: 1 })); });
        busy(T.host, false);
        const sumF = k => x => x._sub ? "" : x[k];
        showDoc(T.host, { title: r.name, chips: chipsOf(v), boxes: [["اسم الفرع", v.br]], cols: [{ t: "التاريخ", k: "date", w: 20 }, { t: "الرقم", k: "no", w: 16 }, { t: "الاسم / الصنف", k: "name", w: 50, cls: "l" }, { t: "الصافي", k: "sales", w: 22, n: 1, sum: 1, f: det ? sumF("sales") : null }, { t: "التكلفة", k: "cost", w: 22, n: 1, sum: 1, f: det ? sumF("cost") : null }, { t: "الربح", k: "profit", w: 22, n: 1, sum: 1, f: det ? sumF("profit") : null }, { t: "%", k: "pct", w: 12, n: 1 }].map(c => { if (!c.f) delete c.f; return c; }), rows }, r.name);
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }
  /* قائمة الدخل (مختصر/تفاصيل) من المبيعات والمرتجعات وتكلفة المبيعات والمصروفات والإيرادات الأخرى */
  function incomeStmt(r) {
    const det = /Detail|تفاصيل/.test(r.tags + r.name);
    branches().then(() => paramDlg(r, { types: ["مقارنة بالفترة"], fields: F.br() + F.per(), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      const HR = window.ANOUER_HR;
      Promise.all([data(v.from, v.to), A() ? A().docs("exp", true).catch(() => []) : [], A() ? A().docs("rev", true).catch(() => []) : [], HR ? HR.cost(v.from, v.to, { br: v.br }).catch(() => null) : null]).then(([D, ex, rv, HRC]) => {
        const L = D.inv.filter(x => filt({ br: v.br }, x)), sum = (t, f) => r2(L.filter(x => x.t === t).reduce((a, x) => a + f(x), 0));
        const sales = sum("Sale", x => x.gross), ret = sum("SaleReturn", x => x.gross), disc = r2(sum("Sale", x => x.disc) - sum("SaleReturn", x => x.disc)), net = r2(sales - ret - disc);
        const cogs = r2(sum("Sale", x => x.lines.reduce((a, l) => a + l.cost, 0)) - sum("SaleReturn", x => x.lines.reduce((a, l) => a + l.cost, 0)));
        const inP = d => d.data && d.data.date >= v.from && d.data.date <= v.to;
        const exps = {}; ex.filter(inP).forEach(d => (d.data.rows || [{ name: d.data.stmt || "مصروفات", total: d.data.total }]).forEach(rw => { const k = rw.name || rw.item || "مصروفات"; exps[k] = (exps[k] || 0) + (+rw.total || +rw.amt || +rw.value || 0); }));
        const revs = {}; rv.filter(inP).forEach(d => (d.data.rows || [{ name: d.data.stmt || "إيرادات", total: d.data.total }]).forEach(rw => { const k = rw.name || rw.item || "إيرادات"; revs[k] = (revs[k] || 0) + (+rw.total || +rw.amt || +rw.value || 0); }));
        /* «الموظفين و الرواتب»: أجور أيام العمل الفعلية مصروف يومي — بنود الرواتب اليدوية تُستبعد لمنع الازدواج */
        let hrExcl = 0; const hrOn = !!(HRC && HRC.on && (HRC.total || HRC.emps.length));
        if (hrOn && HRC.dedupe) Object.keys(exps).forEach(k => { if (HRC.re.test(k)) { hrExcl += exps[k]; delete exps[k]; } });
        if (hrOn && HRC.total) exps["رواتب وأجور الموظفين (أيام العمل الفعلية)"] = HRC.total;
        const tE = r2(Object.values(exps).reduce((a, b) => a + b, 0)), tR = r2(Object.values(revs).reduce((a, b) => a + b, 0)), gross = r2(net - cogs), np = r2(gross + tR - tE);
        const R = (name, a, b, cls) => ({ name, a: a === "" ? "" : a, b: b === "" ? "" : b, _cls: cls || "" });
        const rows = [R("المبيعات", sales, ""), R("(-) مرتجع المبيعات", -ret, ""), R("(-) الخصم المسموح به", -disc, ""), R("صافي المبيعات", "", net, "sub"), R("(-) تكلفة البضاعة المباعة", "", -cogs), R("مجمل الربح", "", gross, "sub")];
        if (det || r.tags !== "ProfitLossShort") { rows.push(R("الإيرادات الأخرى", "", "", "sub")); Object.keys(revs).forEach(k => rows.push(R("   " + k, r2(revs[k]), ""))); rows.push(R("إجمالي الإيرادات الأخرى", "", tR)); rows.push(R("المصروفات", "", "", "sub")); Object.keys(exps).forEach(k => { rows.push(R("   " + k, r2(-exps[k]), "")); if (hrOn && det && /^رواتب وأجور الموظفين/.test(k)) HRC.emps.filter(g => g.amt).forEach(g => rows.push(R("        " + g.name + " — " + g.days + " يوم" + (g.half ? " + " + g.half + " نصف" : "") + (g.bonus ? " + مكافأة" : "") + (g.ded ? " − خصم" : ""), r2(-g.amt), "", "it"))); });
          if (hrExcl) rows.push(R("   (مستبعد لمنع الازدواج: رواتب مسجّلة يدوياً " + nf(r2(hrExcl)) + ")", "", "", "it")); rows.push(R("إجمالي المصروفات", "", -tE)); }
        rows.push(R(np >= 0 ? "صافي الربح" : "صافي الخسارة", "", np, np >= 0 ? "sub" : "neg"));
        busy(T.host, false);
        showDoc(T.host, { title: r.name, chips: chipsOf(v), boxes: [["اسم الفرع", v.br]], cols: [{ t: "البيان", k: "name", w: 100, cls: "l", nosort: 1 }, { t: "جزئي", k: "a", w: 40, n: 1, nosort: 1 }, { t: "كلي", k: "b", w: 40, n: 1, nosort: 1 }], rows, totals: false, hideIdx: true }, r.name);
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }

  /* --- القبض والصرف: التحصيلات / المدفوعات / المصروفات / الإيرادات --- */
  function cashRpt(r, sum) {
    const kind = /Recieve|التحصيلات/.test(r.tags + r.name) ? "recv" : /PayMoeny|المدفوعات/.test(r.tags + r.name) ? "pay" : /Expenses/.test(r.tags) ? "exp" : "rev";
    branches().then(() => paramDlg(r, { types: sum ? ["يومي", "أسبوعي", "شهري", "سنوي", "لكل حساب"] : ["عام"], type: sum ? 4 : 0, fields: F.br() + F.per() + F.of(r, [["pname", "الاسم"], ["no", "الرقم"], ["amt", "المبلغ"], ["date", "التاريخ"], ["notes", "البيان"]]), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      Promise.all([A() ? A().docs(kind, true).catch(() => []) : [], (kind === "recv" || kind === "pay") ? data(v.from, v.to).catch(() => ({ cv: [] })) : { cv: [] }]).then(([ds, D]) => {
        let L = ds.filter(d => d.data && d.data.date >= v.from && d.data.date <= v.to && (!d.data.br || d.data.br === v.br)).map(d => ({ date: d.data.date, time: d.data.time || "", no: d.no, pname: d.data.pname || d.data.stmt || ((d.data.rows || [])[0] || {}).name || "", amt: r2(+d.data.amt || +d.data.total || 0), disc: r2(+d.data.disc || 0), acc: (d.data.acc || {}).name || "", notes: d.data.notes || d.data.stmt || "", user: d.data.user || "" }));
        // سندات الخزينة من المضيف (القبض/الصرف المباشر) غير المكررة
        if (kind === "recv" || kind === "pay") (D.cv || []).filter(c => c.type === (kind === "recv" ? "Receipt" : "Payment") && !/^ورد-/.test(c.no) && !L.some(x => String(x.no) === String(c.no))).forEach(c => L.push({ date: c.date, time: c.time, no: c.no, pname: c.party, amt: r2(c.amt), disc: 0, acc: c.tr, notes: c.notes, user: c.user }));
        L.sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
        let m;
        if (!sum) { L = applyOF(L, v); m = { title: r.name, chips: chipsOf(v), boxes: [["اسم الفرع", v.br]], cols: [{ t: "التاريخ", k: "date", w: 20, f: x => dmy(x.date) }, { t: "الرقم", k: "no", w: 14 }, { t: "الاسم / البيان", k: "pname", w: 44, cls: "l" }, { t: "الحساب", k: "acc", w: 28 }, { t: "المبلغ", k: "amt", w: 22, n: 1, sum: 1 }].concat(kind === "recv" || kind === "pay" ? [{ t: "الخصم", k: "disc", w: 16, n: 1, sum: 1 }] : []).concat([{ t: "الملاحظات", k: "notes", w: 34, cls: "l" }, { t: "المستخدم", k: "user", w: 18 }]), rows: L }; }
        else { const g = {}, bk = [0, 1, 2, 4][v.type]; L.forEach(x => { const k = v.type === 4 ? x.pname : bucketOf(x.date, bk)[0], nm = v.type === 4 ? x.pname : bucketOf(x.date, bk)[1]; const o = g[k] || (g[k] = { name: nm, cnt: 0, amt: 0, disc: 0, _k: k }); o.cnt++; o.amt += x.amt; o.disc += x.disc; });
          let rows = Object.values(g).sort((a, b) => v.type === 4 ? b.amt - a.amt : String(a._k).localeCompare(String(b._k))); rows = applyOF(rows, v);
          m = { title: r.name, chips: chipsOf(v), boxes: [["اسم الفرع", v.br]], cols: [{ t: v.type === 4 ? "الاسم" : "الفترة", k: "name", w: 70, cls: "l" }, { t: "العدد", k: "cnt", w: 16, n: 1, sum: 1 }, { t: "المبلغ", k: "amt", w: 28, n: 1, sum: 1 }, { t: "الخصم", k: "disc", w: 22, n: 1, sum: 1 }], rows }; }
        busy(T.host, false);
        showDoc(T.host, m, r.name);
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }
  /* --- النقدية: أرصدة النقدية / حركة الخزينة / اجمالي تعاملات الخزينة / حركة مستخدم --- */
  function cashBalances(r) {
    paramDlg(r, { types: ["الخزائن", "الخزائن و البنوك و الماكينات و العهد"], fields: "", onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      const AC = A(); if (!AC) { busy(T.host, false); return; }
      const ks = v.type === 0 ? ["tr"] : ["tr", "bk", "pos", "emp"], nm = { tr: "الخزائن", bk: "البنوك", pos: "ماكينات نقاط البيع", emp: "العهد" };
      Promise.all([AC.ledger(true)].concat(ks.map(k => AC.accounts(k, true)))).then(([, ...ls]) => {
        const groups = ks.map((k, i) => ({ title: nm[k], rows: (ls[i] || []).map(a => ({ name: a.name, bal: r2(AC.accBal(k, a)) })) }));
        busy(T.host, false);
        showDoc(T.host, { title: r.name, chips: [["حتى", dmy(today())]], groups, cols: [{ t: "الحساب", k: "name", w: 100, cls: "l" }, { t: "", k: "c", w: 12, f: () => "DZD", nosort: 1 }, { t: "الرصيد", k: "bal", w: 40, n: 1, sum: 1 }] }, r.name);
      });
    } });
  }
  /* --- حركة الخزينة / البنك / الماكينة / العهدة (FrmAccountMove) + اجمالي التعاملات (FrmAccountSum/FrmGlChart) ---
     لوحة DEXEF: الفرع، الفترة، البحث بـ (الكود | اسم الحساب)، نوع التقرير (عام / مفصل / موضحاً القيود / موضحاً العملة)، بدون/بحث متقدم، زر عرض أزرق */
  const TM_TYPES = ["عام", "مفصل", "موضحاً القيود", "موضحاً العملة"];
  function treasuryMove(r, sum, pre) {
    const k = /Bank/.test(r.tags) ? "bk" : /Visa/.test(r.tags) ? "pos" : /Pledge/.test(r.tags) ? "emp" : "tr";
    const T = resultTab(r, true), sideEl = T.el.querySelector(".rp-side"); sideEl.classList.add("v"); T.el.querySelector(".rp-show").classList.add("blue");
    const AC = A(); if (!AC) { T.side.innerHTML = '<div class="e">وحدة الحسابات غير محمّلة</div>'; return; }
    branches().then(() => Promise.all([AC.accounts(k, true), AC.ledger(true)]).then(([accs]) => {
      const items = accs.map(a => ({ id: a.id, no: a.no || String(a.id), name: a.name, bal: r2(AC.accBal(k, a)), _a: a }));
      T.side.innerHTML = V.br() + V.per() + `<div class="rp-f v"><span class="lb">البحث بـ<i class="req">*</i></span><span class="rp-by"><select data-k="by" title="البحث بـ"><option value="name">الاسم</option><option value="no">الكود</option></select><span data-lk=""></span></span></div>`
        + V.f("نوع التقرير", '<span data-tl=""></span>', 0, "top") + `<div data-adv=""></div>`;
      T.side.querySelectorAll("[data-per]").forEach(h => h._P = perPicker(h));
      const LK = lookup(T.side.querySelector("[data-lk]"), { items, cols: [["no", "الكود", 70], ["name", "اسم الحساب"], ["bal", "الرصيد", 96, "n"]], ph: "اسم الحساب", pw: 360 });
      if (items.length === 1) LK.set(items[0], true);
      const by = T.side.querySelector('[data-k="by"]'); by.onchange = () => { LK.setBy(by.value); LK.el.placeholder = by.value === "no" ? "الكود" : "اسم الحساب"; LK.focus(); };
      const TL = typeList(T.side.querySelector("[data-tl]"), sum ? ["يومي", "أسبوعي", "شهري", "سنوي"] : TM_TYPES);
      advRow(T.side.querySelector("[data-adv]"), r, [["date", "التاريخ"], ["deal", "التعامل"], ["party", "الاسم"], ["dr", "مدين"], ["cr", "دائن"]]);
      const go = () => {
        const v = vals(sideEl); v.type = TL.get();
        if (!items.length) { alertDlg("لا توجد حسابات مسجلة من هذا النوع — أضفها من قائمة الحسابات أولاً"); return; }
        const it = LK.get(); if (!it) { alertDlg(REQ_MSG, () => LK.bad()); return; }
        if (v.newtab) { treasuryMove(r, sum, { v, p: it.id, t: v.type }); return; }
        const acc = it._a; busy(T.host, true);
        Promise.all([k === "tr" && HOST() ? data(v.from, today()) : Promise.resolve({ cv: [] }), AC.ledger(true), k === "tr" ? AC.accounts("tr", true) : Promise.resolve(null)]).then(([D, LG, trs]) => {
          let mv = [];
          if (k === "tr" && HOST()) (D.cv || []).filter(c => String(c.trid) === String(acc.id)).forEach(c => mv.push({ dt: c.dt, date: c.date, time: c.time, deal: c.type === "Receipt" ? "قبض نقدية" : "صرف نقدية", no: c.no, party: c.party, dr: c.type === "Receipt" ? c.amt : 0, cr: c.type === "Payment" ? c.amt : 0, notes: c.notes, user: c.user }));
          else (LG.lines || []).filter(l => l.t === k && String(l.id) === String(acc.id) && l.date >= v.from).forEach(l => mv.push({ dt: l.date, date: l.date, time: "", deal: (AC.TITLE[l.k] || l.k), no: l.no, party: l.party || "", dr: l.d > 0 ? +l.d : 0, cr: l.d < 0 ? -l.d : 0, notes: l.what || l.notes || "", user: "", _doc: l.docId ? { k: l.k, id: l.docId, no: l.no } : null }));
          mv.sort((a, b) => String(a.dt).localeCompare(String(b.dt)));
          const cur0 = trs ? (trs.find(t => String(t.id) === String(acc.id)) || acc) : acc, cur = r2(AC.accBal(k, cur0));
          const prev = r2(cur - mv.reduce((s, m) => s + m.dr - m.cr, 0));
          let bal = prev; const inP = mv.filter(m => m.date <= v.to), ti = v.type;
          let rows, cols, land = false, sfx = "", tot = {};
          if (!sum) {
            rows = [];
            inP.forEach(m => { bal = r2(bal + m.dr - m.cr); rows.push(Object.assign({}, m, { date: dmy(m.date), bal, stmt: m.deal + (m.party ? " - " + m.party : "") + (m.notes ? " - " + m.notes : ""), dr: m.dr || "", cr: m.cr || "", cur: "DZD", rate: 1, fdr: m.dr || "", fcr: m.cr || "" }));
              if (ti === 2) { const o = m.party || (m.dr ? "الإيرادات" : "المصروفات"); (m.dr ? [[acc.name, m.dr, ""], [o, "", m.dr]] : [[o, m.cr, ""], [acc.name, "", m.cr]]).forEach(a => rows.push({ date: "", no: "", stmt: "      " + a[0], jdr: a[1], jcr: a[2], dr: "", cr: "", bal: "", _cls: "it", _keep: 1 })); } });
            rows = applyAdv(applyOF(rows, v), v);
            const base = [{ t: "التاريخ", k: "date", w: 19 }, { t: "الرقم", k: "no", w: 15 }], money = [{ t: "مدين", k: "dr", w: 21, n: 1, sum: 1 }, { t: "دائن", k: "cr", w: 21, n: 1, sum: 1 }, { t: "الرصيد", k: "bal", w: 22, n: 1 }];
            if (ti === 0) cols = base.concat([{ t: "البيان", k: "stmt", w: 72, cls: "l" }], money);
            else if (ti === 1) { land = true; sfx = " مفصل"; cols = base.concat([{ t: "الوقت", k: "time", w: 11 }, { t: "التعامل", k: "deal", w: 26 }, { t: "الاسم", k: "party", w: 40, cls: "l" }, { t: "البيان", k: "notes", w: 46, cls: "l" }], money, [{ t: "المستخدم", k: "user", w: 22 }]); }
            else if (ti === 2) { sfx = " موضحاً القيود"; cols = base.concat([{ t: "البيان / الحساب", k: "stmt", w: 52, cls: "l" }, { t: "مدين القيد", k: "jdr", w: 18, n: 1 }, { t: "دائن القيد", k: "jcr", w: 18, n: 1 }], money); }
            else { land = true; sfx = " موضحاً العملة"; cols = base.concat([{ t: "البيان", k: "stmt", w: 66, cls: "l" }, { t: "العملة", k: "cur", w: 12, nosort: 1 }, { t: "معامل", k: "rate", w: 11, n: 1 }, { t: "مدين بالعملة", k: "fdr", w: 21, n: 1, sum: 1 }, { t: "دائن بالعملة", k: "fcr", w: 21, n: 1, sum: 1 }], money); }
            tot = { bal };
          } else {
            const g = {}, bk = [0, 1, 2, 4][ti] || 0; inP.forEach(m => { const b = bucketOf(m.date, bk), o = g[b[0]] || (g[b[0]] = { name: b[1], cnt: 0, dr: 0, cr: 0, _k: b[0] }); o.cnt++; o.dr += m.dr; o.cr += m.cr; });
            let run = prev; rows = Object.values(g).sort((a, b) => a._k.localeCompare(b._k)).map(o => { run = r2(run + o.dr - o.cr); return Object.assign(o, { dr: r2(o.dr), cr: r2(o.cr), net: r2(o.dr - o.cr), bal: run }); });
            rows = applyAdv(applyOF(rows, v), v); sfx = " " + ["يومي", "أسبوعي", "شهري", "سنوي"][ti];
            cols = [{ t: "الفترة", k: "name", w: 46, cls: "l" }, { t: "العدد", k: "cnt", w: 14, n: 1, sum: 1 }, { t: "مدين", k: "dr", w: 26, n: 1, sum: 1 }, { t: "دائن", k: "cr", w: 26, n: 1, sum: 1 }, { t: "الصافي", k: "net", w: 24, n: 1, sum: 1 }, { t: "الرصيد", k: "bal", w: 26, n: 1 }];
            tot = { bal: run };
          }
          const ttl = r.name.replace(/ (مرتبة بــ|مرتبة بـ|مع)$/, "").replace(/\s+/g, " ").trim() + sfx;
          const bx2 = [[["الكود", it.no], ["اسم الحساب", acc.name], ["اسم الفرع", v.br]], [["الرصيد الحالي", nf(cur), "DZD", "n"], ["طبع بواسطة", userName()], ["رصيد سابق", nf(prev), "", "n"]]];
          busy(T.host, false);
          showDoc(T.host, { title: ttl, chips: chipsOf(v), bx2, cols, rows, land, totPlain: !sum, totExtra: tot }, ttl);
        }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
      };
      T.el.querySelector(".rp-show").onclick = go;
      sideEl.addEventListener("keydown", e => { if (e.key === "F2" || (e.key === "Enter" && e.ctrlKey)) { e.preventDefault(); go(); } });
      if (pre) { restore(sideEl, pre.v); TL.set(pre.t || 0); LK.set(pre.p, true); setTimeout(go, 30); } else setTimeout(() => LK.focus(), 80);
    }));
  }
  /* --- يومية المستخدمين / حركة مستخدم / صافي الأعمال --- */
  function byUser(r) {
    branches().then(() => paramDlg(r, { types: ["عام"], fields: F.br() + F.per(), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      data(v.from, v.to).then(D => {
        const m = {}; D.inv.filter(x => filt({ br: v.br }, x)).forEach(x => { const u = x.user || "—", g = m[u] || (m[u] = { user: u, s: 0, sr: 0, p: 0, pr: 0, paid: 0, cnt: 0 }); g.cnt++; if (x.t === "Sale") { g.s += x.total; g.paid += x.paid; } else if (x.t === "SaleReturn") { g.sr += x.total; g.paid -= x.paid; } else if (x.t === "Purchase") g.p += x.total; else if (x.t === "PurchaseReturn") g.pr += x.total; });
        (D.cv || []).forEach(c => { const u = c.user || "—", g = m[u] || (m[u] = { user: u, s: 0, sr: 0, p: 0, pr: 0, paid: 0, cnt: 0 }); g.rc = (g.rc || 0) + (c.type === "Receipt" ? c.amt : 0); g.py = (g.py || 0) + (c.type === "Payment" ? c.amt : 0); });
        const rows = Object.values(m).map(g => Object.assign(g, { net: r2(g.s - g.sr), rc: r2(g.rc || 0), py: r2(g.py || 0) }));
        busy(T.host, false);
        showDoc(T.host, { title: r.name, chips: chipsOf(v), boxes: [["اسم الفرع", v.br]], cols: [{ t: "المستخدم", k: "user", w: 34, cls: "l" }, { t: "عدد التعاملات", k: "cnt", w: 16, n: 1, sum: 1 }, { t: "المبيعات", k: "s", w: 22, n: 1, sum: 1 }, { t: "مرتجع المبيعات", k: "sr", w: 22, n: 1, sum: 1 }, { t: "صافي المبيعات", k: "net", w: 22, n: 1, sum: 1 }, { t: "المحصل", k: "paid", w: 22, n: 1, sum: 1 }, { t: "المشتريات", k: "p", w: 20, n: 1, sum: 1 }, { t: "قبض", k: "rc", w: 18, n: 1, sum: 1 }, { t: "صرف", k: "py", w: 18, n: 1, sum: 1 }], rows }, r.name);
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }
  function netBusiness(r) {
    branches().then(() => paramDlg(r, { types: ["يومي", "شهري", "سنوي"], fields: F.br() + F.per(), onShow: v => {
      const T = resultTab(r, false); busy(T.host, true);
      Promise.all([data(v.from, v.to), A() ? A().docs("exp", true).catch(() => []) : []]).then(([D, ex]) => {
        const bk = [0, 2, 4][v.type], m = {};
        const g = d => { const b = bucketOf(d, bk); return m[b[0]] || (m[b[0]] = { name: b[1], _k: b[0], s: 0, sr: 0, p: 0, pr: 0, e: 0, cost: 0 }); };
        D.inv.filter(x => filt({ br: v.br }, x)).forEach(x => { const o = g(x.date), c = x.lines.reduce((a, l) => a + l.cost, 0); if (x.t === "Sale") { o.s += x.total; o.cost += c; } else if (x.t === "SaleReturn") { o.sr += x.total; o.cost -= c; } else if (x.t === "Purchase") o.p += x.total; else if (x.t === "PurchaseReturn") o.pr += x.total; });
        ex.filter(d => d.data && d.data.date >= v.from && d.data.date <= v.to).forEach(d => { g(d.data.date).e += +d.data.total || +d.data.amt || 0; });
        const rows = Object.values(m).sort((a, b) => a._k.localeCompare(b._k)).map(o => Object.assign(o, { ns: r2(o.s - o.sr), np: r2(o.p - o.pr), gp: r2(o.s - o.sr - o.cost), net: r2(o.s - o.sr - o.cost - o.e) }));
        busy(T.host, false);
        showDoc(T.host, { title: r.name, chips: chipsOf(v), boxes: [["اسم الفرع", v.br]], cols: [{ t: "الفترة", k: "name", w: 26 }, { t: "صافي المبيعات", k: "ns", w: 24, n: 1, sum: 1 }, { t: "تكلفة المبيعات", k: "cost", w: 24, n: 1, sum: 1 }, { t: "مجمل الربح", k: "gp", w: 24, n: 1, sum: 1 }, { t: "المصروفات", k: "e", w: 22, n: 1, sum: 1 }, { t: "صافي الأعمال", k: "net", w: 24, n: 1, sum: 1 }, { t: "صافي المشتريات", k: "np", w: 24, n: 1, sum: 1 }], rows }, r.name);
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    } }));
  }
  /* تقرير غير متوفر في ANOUER بعد: نفس نافذة المعايير + مستند يوضح السبب */
  /* ================================================================== «ضريبة القيمة المضافة» (VatGulf) و«نموذج 10» (TaxesModel10)
     نفس أسطر إقرار DEXEF ONE (1 → 16) مكيّفة للجزائر: النسبة العادية 19% والمخفضة 9% بالدينار DZD
     المبلغ / التعديلات (المرتجعات) / قيمة الضريبة — والتسويات الضريبية + المسدد من شاشة «سداد الضرائب» + آخر أجل لتصريح G50 */
  const VAT_RT = [19, 9];
  function vatSplit(x) {
    /* يوزّع الفاتورة على: 19% / 9% / بدون ضريبة — من أسطرها إن وُجدت، وإلا من إجمالي الفاتورة */
    const o = { b19: 0, t19: 0, b9: 0, t9: 0, b0: 0 };
    const put = (base, tax) => { base = +base || 0; tax = +tax || 0;
      if (Math.abs(tax) < 0.005) { o.b0 += base; return; }
      const rt = base ? tax / base * 100 : 19, k = Math.abs(rt - 9) < Math.abs(rt - 19) ? 9 : 19; o["b" + k] += base; o["t" + k] += tax; };
    const L = x.lines || [];
    if (L.length) { L.forEach(l => { const g = (+l.qty || 0) * (+l.price || 0) - (+l.disc || 0); const base = g > 0 ? g : Math.max(0, (+l.total || 0) - (+l.tax || 0)); put(base, l.tax); });
      const lt = L.reduce((a, l) => a + (+l.tax || 0), 0), dt = (+x.tax || 0) - lt; if (Math.abs(dt) > 0.01) put(dt / 0.19, dt); /* ضريبة على مستوى الفاتورة */
      const ld = (+x.disc || 0); if (ld > 0.005 && !L.some(l => +l.disc)) { const tb = o.b19 + o.b9 + o.b0 || 1; ["b19", "b9", "b0"].forEach(k => o[k] -= ld * o[k] / tb); } }
    else put(Math.max(0, (+x.gross || 0) - (+x.disc || 0)), x.tax);
    return o;
  }
  const g50Due = to => { const d = new Date(to + "T00:00:00"); const n = new Date(d.getFullYear(), d.getMonth() + 1, 20); return dmy(ymd(n)); };
  function vatBuild(v, detail) {
    const Ac = A();
    return Promise.all([data(v.from, v.to), Ac ? Ac.docs("taxp", true).catch(() => []) : [], Ac ? Ac.docs("taxs", true).catch(() => []) : []]).then(([D, P, S]) => {
      const L = D.inv.filter(x => filt({ br: v.br }, x));
      const acc = { Sale: { b19: 0, t19: 0, b9: 0, t9: 0, b0: 0 }, SaleReturn: { b19: 0, t19: 0, b9: 0, t9: 0, b0: 0 }, Purchase: { b19: 0, t19: 0, b9: 0, t9: 0, b0: 0 }, PurchaseReturn: { b19: 0, t19: 0, b9: 0, t9: 0, b0: 0 } };
      const det = [];
      L.forEach(x => { const a = acc[x.t]; if (!a) return; const o = vatSplit(x); Object.keys(o).forEach(k => a[k] += o[k]); if (detail) det.push({ x, o }); });
      const isVat = d => d.data && !(d.data.f2 < v.from || d.data.f1 > v.to) && String(d.data.taccNo || "2132") === "2132" && (!v.br || !d.data.br || d.data.br === v.br);
      const paid = r2(P.filter(isVat).reduce((a, d) => a + (+d.data.amt || 0), 0));
      const adj = r2(S.filter(isVat).reduce((a, d) => a + (d.data.dc === "cr" ? 1 : -1) * (+d.data.amt || 0), 0));
      const S0 = acc.Sale, SR = acc.SaleReturn, P0 = acc.Purchase, PR = acc.PurchaseReturn;
      const row = (no, name, a, b, c, cls) => ({ no, name, a: a === "" ? "" : r2(a), b: b === "" ? "" : r2(b), c: c === "" ? "" : r2(c), _cls: cls || "" });
      const s19 = row(1, "المبيعات المحلية الخاضعة للنسبة العادية (19%)", S0.b19, -SR.b19, S0.t19 - SR.t19);
      const s9 = row(2, "المبيعات الخاضعة للنسبة المخفضة (9%)", S0.b9, -SR.b9, S0.t9 - SR.t9);
      const s0 = row(3, "المبيعات الخاضعة للنسبة الصفرية", 0, 0, 0);
      const sx = row(4, "الصادرات", 0, 0, 0);
      const se = row(5, "المبيعات المعفاة / غير الخاضعة", S0.b0, -SR.b0, 0);
      const sT = row(6, "إجمالي المبيعات", S0.b19 + S0.b9 + S0.b0, -(SR.b19 + SR.b9 + SR.b0), s19.c + s9.c, "sub");
      const p19 = row(7, "المشتريات الخاضعة للنسبة العادية (19%)", P0.b19, -PR.b19, P0.t19 - PR.t19);
      const p9 = row(8, "المشتريات الخاضعة للنسبة المخفضة (9%)", P0.b9, -PR.b9, P0.t9 - PR.t9);
      const pim = row(9, "الاستيرادات الخاضعة للضريبة المسددة في الجمارك", 0, 0, 0);
      const p0 = row(10, "المشتريات الخاضعة للنسبة الصفرية", 0, 0, 0);
      const pe = row(11, "المشتريات المعفاة / غير الخاضعة", P0.b0, -PR.b0, 0);
      const pT = row(12, "إجمالي المشتريات", P0.b19 + P0.b9 + P0.b0, -(PR.b19 + PR.b9 + PR.b0), p19.c + p9.c, "sub");
      const due = r2(sT.c - pT.c);
      const t13 = row(13, "إجمالي الضريبة المستحقة عن الفترة الحالية", "", "", due, "sub");
      const t14 = row(14, "تصحيحات من فترات سابقة (تسويات الضرائب)", "", "", adj);
      const t15 = row(15, "المسدد عن الفترة (سداد الضرائب)", "", "", -paid);
      const net = r2(due + adj - paid);
      const t16 = row(16, net >= 0 ? "صافي الضريبة المستحقة" : "صافي الضريبة المستردة (رصيد دائن)", "", "", net, net >= 0 ? "sub" : "neg");
      return { rows: [s19, s9, s0, sx, se, sT, p19, p9, pim, p0, pe, pT, t13, t14, t15, t16], net, due, paid, adj, det, n: L.length };
    });
  }
  function vatRpt(r, preset) {
    const m10 = r.tags === "TaxesModel10";
    const go = v => {
      const T = resultTab(r, false); busy(T.host, true);
      vatBuild(v, m10).then(B => {
        busy(T.host, false);
        const boxes = [["اسم الفرع", v.br || "كل الفروع"], ["العملة", "DZD"], ["أجل G50", g50Due(v.to)]];
        if (!m10) return showDoc(T.host, { title: r.name, chips: chipsOf(v), boxes, cols: [{ t: "#", k: "no", w: 8, nosort: 1 }, { t: "البيان", k: "name", w: 92, cls: "l", nosort: 1 }, { t: "المبلغ (DZD)", k: "a", w: 34, n: 1, nosort: 1 }, { t: "التعديلات (DZD)", k: "b", w: 34, n: 1, nosort: 1 }, { t: "قيمة الضريبة (DZD)", k: "c", w: 34, n: 1, nosort: 1 }], rows: B.rows, totals: false, hideIdx: true }, r.name);
        const TN = { Sale: "مبيعات", SaleReturn: "مرتجع مبيعات", Purchase: "مشتريات", PurchaseReturn: "مرتجع مشتريات" }, sg = t => /Return/.test(t) ? -1 : 1;
        const rows = B.det.map(({ x, o }) => ({ date: dmy(x.date), no: x.no, t: TN[x.t], pname: x.pname, b19: r2(sg(x.t) * o.b19), t19: r2(sg(x.t) * o.t19), b9: r2(sg(x.t) * o.b9), t9: r2(sg(x.t) * o.t9), b0: r2(sg(x.t) * o.b0), _cls: /^Purchase/.test(x.t) ? "pur" : "", _inv: x.id }));
        showDoc(T.host, { title: r.name, chips: chipsOf(v), boxes, cols: [{ t: "التاريخ", k: "date", w: 20 }, { t: "الرقم", k: "no", w: 14 }, { t: "التعامل", k: "t", w: 22 }, { t: "الاسم", k: "pname", w: 40, cls: "l" }, { t: "الوعاء 19%", k: "b19", w: 24, n: 1 }, { t: "ضريبة 19%", k: "t19", w: 22, n: 1 }, { t: "الوعاء 9%", k: "b9", w: 22, n: 1 }, { t: "ضريبة 9%", k: "t9", w: 20, n: 1 }, { t: "بدون ضريبة", k: "b0", w: 22, n: 1 }], rows, totals: true }, r.name);
      }).catch(e => { busy(T.host, false); say("تعذّر إنشاء التقرير: " + (e.message || e), "e"); });
    };
    if (preset && preset.from && preset.to) return branches().then(() => go({ br: "", from: preset.from, to: preset.to }));
    branches().then(() => paramDlg(r, { types: [m10 ? "مفصل بالفواتير" : "إقرار الفترة"], fields: F.br() + F.per(), onInit: ov => { const h = ov.querySelector("[data-per]"); if (h && h._P && PRESET == null) try { h._P.set(8); } catch (e) { } }, onShow: go }));
  }
  function unavailable(r) {
    branches().then(() => paramDlg(r, { types: [], fields: F.br() + F.per(), onShow: v => {
      const T = resultTab(r, false);
      showDoc(T.host, { title: r.name, chips: chipsOf(v), cols: [{ t: "ملاحظة", k: "x", w: 100, cls: "l", nosort: 1 }], rows: [{ x: "هذا التقرير يعتمد على " + (/Cheque|شيك/.test(r.tags + r.name) ? "دورة الشيكات" : /Serial|تسلسل/.test(r.tags + r.name) ? "الأرقام التسلسلية" : /Expr|صلاحية/.test(r.tags + r.name) ? "تواريخ الصلاحية" : /Consign|الأمانة/.test(r.tags + r.name) ? "بضاعة الأمانة" : /CostCenter|مركز/.test(r.tags + r.name) ? "مراكز التكلفة" : /Vat|Tax|ضريبة/.test(r.tags + r.name) ? "الإقرارات الضريبية" : "القيود المحاسبية (شجرة الحسابات)") + " — غير مسجلة بالكامل في ANOUER بعد." }], totals: false, hideIdx: true }, r.name);
    } }));
  }
  /* توجيه التقرير حسب نموذج DEXEF (Frm) */
  function run(r) {
    try {
      if (!r) return;
      PRESET = r.perI != null ? r.perI : null;
      markLast(r.id);
      const f = r.frm, t = r.tags, n = r.name;
      if (f === "FrmBillRpt") return billRpt(r);
      if (f === "FrmBillSumRpt") return billSum(r);
      if (f === "FrmItemSales") return itemSales(r);
      if (f === "FrmBillPivot") return pivot(r);
      if (f === "FrmGlIndex" && /Cust|Vendor|Storage|Bank|Visa|Pledge/.test(t)) return balances(r);
      if (f === "FrmCustTransaction") return partyMove(r);
      if (f === "FrmAccountSum" && /Cust|Vendor/.test(t)) return partySum(r);
      if (f === "FrmAccountSum" && /Storage|Bank|Visa|Pledges/.test(t)) return treasuryMove(r, true);
      if (f === "FrmAccountMove" && /Storage|Bank|Visa|Pledges/.test(t)) return treasuryMove(r, false);
      if (f === "FrmGlChart" && /storage|Storage|Bank|Visa|Pledges/.test(t)) return treasuryMove(r, true);
      if (f === "FrmGlIndexSum" && t === "VendorBalanceMonthly") return partyFile(r);
      if (f === "FrmCustomerFile") return partyFile(r);
      if (f === "FrmCustAging") { if (window.ANOUER_CUSTOPS) return ANOUER_CUSTOPS.aging("need"); return unavailable(r); }
      if (f === "FrmStoreMove" && !/Consign/.test(t)) return stockCount(r);
      if (f === "FrmItemsRequired") return shortage(r);
      if (f === "FrmItemGroupBalance") return groupBal(r);
      if (f === "FrmItemMove") return itemMove(r);
      if (f === "FrmItemListRpt" && t !== "ItemListAssembly") return itemList(r);
      if (f === "FrmRptTitle") return alerts(r);
      if (f === "FrmRptBranchListDT" && /^(TotalItemProfit|TotalItemLoss|TotalCustProfit|TotalCustProfitLess)$/.test(t)) return profitRpt(r);
      if ((f === "FrmRptBranchStore" && /Profit/.test(t))) return profitRpt(r);
      if (f === "FrmRptBranchListDT" && /^ProfitLoss/.test(t)) return incomeStmt(r);
      if (t === "VatGulf" || t === "TaxesModel10") return vatRpt(r);
      if (f === "PivotItemProfit" || f === "PivotCustProfit") return profitPivot(r);
      if (f === "FrmInvoiceProfit") return invoiceProfit(r);
      if (f === "FrmItemStoreDT" && t === "ItemProfit") return profitRpt(Object.assign({}, r, { tags: "TotalItemProfit" }));
      if (f === "FrmCustomerMove" && t === "CustProfit") return profitRpt(Object.assign({}, r, { tags: "TotalCustProfit" }));
      if (f === "FrmExpenesesRpt") return cashRpt(r, false);
      if (f === "FrmExpenesesSumRpt") return cashRpt(r, true);
      if (f === "FrmTotalCashRPT") return cashBalances(r);
      if (f === "FrmTransactionByUser" || f === "FrmCashPeriod") return byUser(r);
      if (f === "FrmTransactionFinal") return netBusiness(r);
      if (f === "FrmCustomersTransactions") return partySum(Object.assign({}, r, { name: r.name }));
      return unavailable(r);
    } catch (e) { console.error(e); say("تعذّر فتح التقرير: " + (e.message || e), "e"); }
  }

  /* ================================================================== الصفحة الرئيسية للتقارير + صفحة القسم */
  const SIDE = [["عام", "s_gen"], ["نظرة عامة", "s_ov"], ["ميزان الأستاذ العام", "s_gl"], ["ميزان النقدية", "s_cash"], ["ميزان البنوك", "s_bank"], ["ميزان بطاقات الائتمان", "s_visa"], ["ميزان العهد", "s_emp"]];
  const ST = { cat: null, side: 0, focus: 0 };
  let HUB = null;
  function hub() {
    const el = mkView("rphub", "التقارير");
    if (!HUB) {
      HUB = el; el.classList.add("rp-hubv");
      el.innerHTML = `<div class="rp-home"><div class="rp-sr"><input placeholder="بحث عن تقرير" autocomplete="off" spellcheck="false"><div class="rp-sres" hidden></div></div>
        <div class="rp-tiles">${TILES.map((t, i) => `<button type="button" class="rp-tile" data-c="${t.id}" style="--d:${i * 35}ms"><b>${esc(t.name)}</b><span class="ic">${IC["c" + t.id] || IC.c2}</span><p>${esc(t.desc)}</p></button>`).join("")}</div></div>
        <div class="rp-catv" hidden><div class="rp-ctop"><button type="button" class="rp-back" title="رجوع (Backspace)">${IC.back}</button><h2 data-k="ct"></h2><span class="sp"></span><span class="rp-flt"><span class="rp-whh" hidden></span><span class="rp-brh"></span><span data-perh=""></span></span></div>
          <div class="rp-cbody"><div class="rp-cmain"></div><aside class="rp-cside"></aside></div></div>`;
      const sr = el.querySelector(".rp-sr input"), res = el.querySelector(".rp-sres");
      const showRes = () => {
        const q = norm(sr.value.trim()); if (!q) { res.hidden = true; return; }
        const l = ROWS.filter(r => norm(r.name).includes(q)).slice(0, 15);
        res.innerHTML = l.map((r, i) => `<div class="o${i ? "" : " hi"}" data-id="${r.id}"><span class="ic">${imgIcon(r)}</span><b>${hl(r.name, sr.value.trim())}</b><small>${esc((TILES.find(t => t.id === r.cat) || {}).name || "")}${r.grp ? " › " + esc(r.grp) : ""}</small></div>`).join("") || '<div class="e">لا توجد تقارير مطابقة</div>';
        res.hidden = false;
      };
      sr.addEventListener("input", showRes); sr.addEventListener("focus", showRes);
      sr.addEventListener("keydown", e => { const os = [...res.querySelectorAll(".o")]; let i = os.findIndex(o => o.classList.contains("hi"));
        if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); i = Math.max(0, Math.min(os.length - 1, i + (e.key === "ArrowDown" ? 1 : -1))); os.forEach((o, j) => o.classList.toggle("hi", j === i)); if (os[i]) os[i].scrollIntoView({ block: "nearest" }); }
        else if (e.key === "Enter" && os[i]) { e.preventDefault(); res.hidden = true; run(byId(+os[i].dataset.id)); } else if (e.key === "Escape") { res.hidden = true; sr.value = ""; } });
      res.addEventListener("mousedown", e => e.preventDefault());
      res.addEventListener("click", e => { const o = e.target.closest(".o"); if (o) { res.hidden = true; run(byId(+o.dataset.id)); } });
      document.addEventListener("mousedown", e => { if (!el.querySelector(".rp-sr").contains(e.target)) res.hidden = true; });
      el.querySelector(".rp-tiles").addEventListener("click", e => { const t = e.target.closest(".rp-tile"); if (t) openCat(+t.dataset.c); });
      el.querySelector(".rp-back").addEventListener("click", () => openCat(null));
      el.querySelector(".rp-cside").addEventListener("click", e => { const b = e.target.closest(".si"); if (b) sidePane(+b.dataset.s); else if (e.target.closest(".col")) el.querySelector(".rp-cside").classList.toggle("fold"); });
      el.querySelector(".rp-cmain").addEventListener("click", e => { const t = e.target.closest(".rp-rt"); if (t) { focusTile(+t.dataset.i); run(byId(+t.dataset.id)); } });
      el.addEventListener("keydown", e => {
        if (el.querySelector(".rp-catv").hidden || ST.side) return; if (e.target.closest("input,select")) return;
        const ts = [...el.querySelectorAll(".rp-rt")]; if (!ts.length) return; let i = ST.focus;
        const col = t => +t.dataset.col, row = t => +t.dataset.row;
        if (e.key === "ArrowDown") i = Math.min(ts.length - 1, i + 1); else if (e.key === "ArrowUp") i = Math.max(0, i - 1);
        else if (e.key === "ArrowLeft" || e.key === "ArrowRight") { const c = col(ts[i]) + (e.key === "ArrowLeft" ? 1 : -1), rr = row(ts[i]); const t = ts.find(x => col(x) === c && row(x) === rr) || ts.filter(x => col(x) === c).pop(); if (t) i = ts.indexOf(t); }
        else if (e.key === "Enter") { e.preventDefault(); run(byId(+ts[i].dataset.id)); return; } else if (e.key === "Backspace") { e.preventDefault(); openCat(null); return; } else return;
        e.preventDefault(); focusTile(i);
      });
      el.tabIndex = -1;
    }
    tabOpen("rphub", "التقارير", "rphub");
    openCat(ST.cat);
    setTimeout(() => { if (!ST.cat) el.querySelector(".rp-sr input").focus(); }, 60);
  }
  const hl = (s, q) => { const i = norm(s).indexOf(norm(q)); if (i < 0 || !q) return esc(s); return esc(s.slice(0, i)) + "<mark>" + esc(s.slice(i, i + q.length)) + "</mark>" + esc(s.slice(i + q.length)); };
  const LAST = () => lsGet("rp.lastrep", {}) || {};
  function markLast(rid) { const r = byId(rid); if (!r) return; const m = LAST(); m[r.cat] = rid; try { lsSet("rp.lastrep", m); } catch (e) { } if (HUB) HUB.querySelectorAll(".rp-rt").forEach(t => t.classList.toggle("sel", +t.dataset.id === rid)); }
  function focusTile(i) { ST.focus = i; HUB.querySelectorAll(".rp-rt").forEach((t, j) => t.classList.toggle("foc", j === i)); const t = HUB.querySelectorAll(".rp-rt")[i]; if (t) t.scrollIntoView({ block: "nearest", inline: "nearest" }); }
  function openCat(id) {
    ST.cat = id; const home = HUB.querySelector(".rp-home"), cv = HUB.querySelector(".rp-catv");
    home.hidden = !!id; cv.hidden = !id;
    if (!id) { HUB.querySelectorAll(".rp-tile").forEach(t => { t.style.animation = "none"; void t.offsetWidth; t.style.animation = ""; }); return; }
    const t = TILES.find(x => x.id === id); HUB.querySelector('[data-k="ct"]').textContent = t ? t.name : "";
    const ph = HUB.querySelector("[data-perh]"); if (!ph._P) ph._P = perPicker(ph, { onChange: () => { if (ST.side) sidePane(ST.side); } });
    branches().then(() => { const b = HUB.querySelector(".rp-brh"); if (!b.firstChild) { b.innerHTML = brSel(); b.querySelector("select").addEventListener("change", () => { if (ST.side) sidePane(ST.side); }); } });
    const wh = HUB.querySelector(".rp-whh"); wh.hidden = id !== 5;
    if (id === 5 && !wh.firstChild) { wh.innerHTML = `<select title="المخزن">${stores().map(s => `<option value="${s.id}"${s.main ? " selected" : ""}>${esc(s.name)}</option>`).join("")}<option value="*">كل المخازن</option></select>`; wh.querySelector("select").addEventListener("change", () => { if (ST.side) sidePane(ST.side); }); }
    drawSide();
    const rows = ROWS.filter(r => r.cat === id), gs = []; rows.forEach(r => { let g = gs.find(x => x.name === r.grp && x.go === r.go); if (!g) gs.push(g = { name: r.grp, go: r.go, rows: [] }); g.rows.push(r); });
    gs.sort((a, b) => a.go - b.go); gs.forEach(g => g.rows.sort((a, b) => a.vi - b.vi || a.id - b.id));
    let ci = 0, idx = 0; const PER = 8;
    HUB.querySelector(".rp-cmain").innerHTML = `<div class="rp-cols">${gs.map(g => { const chunks = []; for (let i = 0; i < g.rows.length; i += PER) chunks.push(g.rows.slice(i, i + PER));
      return chunks.map((ch, k) => `<div class="rp-col" style="--d:${ci * 40}ms"><div class="gh">${k === 0 ? esc(g.name) : "&nbsp;"}</div>${ch.map((r, rr) => `<button type="button" class="rp-rt${r.id === LAST()[id] ? " sel" : ""}${idx === 0 ? " foc" : ""}" data-id="${r.id}" data-i="${idx++}" data-col="${ci}" data-row="${rr}" title="${esc(r.name)}"><span class="ic">${imgIcon(r)}</span><span class="nm">${esc(r.name)}</span></button>`).join("")}</div>`).join("") + (ci++, ""); }).join("")}</div>`;
    // ترقيم الأعمدة الحقيقي
    HUB.querySelectorAll(".rp-col").forEach((c, i) => c.querySelectorAll(".rp-rt").forEach(t => t.dataset.col = i));
    ST.focus = 0; const li = [...HUB.querySelectorAll(".rp-rt")].findIndex(t => +t.dataset.id === LAST()[id]); if (li > 0) focusTile(li); sidePane(0);
    setTimeout(() => HUB.focus(), 30);
  }
  /* اللوحة الجانبية: عام / نظرة عامة / الموازين — وقوائم خاصة بقسمي المخازن والأرباح (DEXEF) */
  const SIDE_BY = {
    5: [["عام", "w_gen", "gen"], ["نظرة عامة", "w_ov", "sov"], ["تعاملات المخزون", "w_mv", "smv"], ["ميزان مراجعة المخزون", "w_bal", "sbal"], ["صافي المشتريات", "w_np", "snp"], ["صافي المبيعات", "w_ns", "sns"], ["مقارنة المخازن", "w_cmp", "scmp"], ["الأصناف الراكدة", "w_fix", "sfix"], ["نواقص الأصناف", "w_short", "sshort"]],
    3: [["عام", "s_gen", "gen"], ["نظرة عامة", "s_ov", "pov"], ["أرباح الأصناف", "s_gl", "pit"], ["أرباح العملاء", "s_gl", "pcu"], ["أرباح الموردين", "s_gl", "psu"], ["المصروفات", "s_gen", "pexp"], ["عملاء تسبب خسائر", "s_gen", "pcuL"], ["أصناف تسبب خسائر", "s_gen", "pitL"]]
  };
  const SKEY = ["gen", "ov", "gl", "tr", "bk", "pos", "emp"];
  const SL = () => SIDE_BY[ST.cat] || SIDE.map((s, i) => [s[0], s[1], SKEY[i]]);
  function drawSide() {
    const as = HUB.querySelector(".rp-cside");
    as.innerHTML = `<button type="button" class="col" title="طي">‹</button>` + SL().map((s, i) => `<button type="button" class="si${i ? "" : " on"}" data-s="${i}" style="--d:${i * 30}ms">${IC[s[1]]}<span>${esc(s[0])}</span></button>`).join("");
  }
  const hubWh = () => { const s = HUB.querySelector(".rp-whh select"); return s ? s.value : ""; };
  function sidePane(i) {
    ST.side = i; HUB.querySelectorAll(".rp-cside .si").forEach(b => b.classList.toggle("on", +b.dataset.s === i));
    const main = HUB.querySelector(".rp-cmain"), cols = main.querySelector(".rp-cols"); let pane = main.querySelector(".rp-pane");
    const key = (SL()[i] || [])[2] || "gen";
    if (key === "gen") { if (cols) cols.hidden = false; if (pane) pane.remove(); return; }
    if (cols) cols.hidden = true; if (!pane) { pane = document.createElement("div"); pane.className = "rp-pane"; main.appendChild(pane); }
    pane.innerHTML = '<div class="rp-spin"><i></i></div>';
    const AC = A(); const P = HUB.querySelector("[data-perh]")._P.get(); P.br = (HUB.querySelector(".rp-brh select") || {}).value || ""; P.wh = hubWh();
    const fail = e => { pane.innerHTML = '<div class="e">تعذّر التحميل: ' + esc((e && e.message) || e) + "</div>"; };
    try {
      if (/^s/.test(key)) return stockPane(pane, key, P, SL()[i][0]).catch(fail);
      if (/^p/.test(key)) return profitPane(pane, key, P, SL()[i][0]).catch(fail);
    } catch (e) { return fail(e); }
    if (!AC) { pane.innerHTML = '<div class="e">وحدة الحسابات غير محمّلة</div>'; return; }
    if (key === "ov") return overview(pane, P);
    if (key === "gl") return glBalance(pane, P);
    const k = key;
    Promise.all([AC.accounts(k, true), AC.ledger(true)]).then(([l]) => {
      const rows = l.map(a => ({ name: a.name, bal: r2(AC.accBal(k, a)) }));
      pane.innerHTML = `<div class="rp-bal"><div class="hd"><b>${esc(SL()[i][0])}</b><span class="sp"></span><span class="rp-chip">DZD</span></div><table><thead><tr><th>#</th><th>الحساب</th><th>الرصيد</th></tr></thead><tbody>${rows.map((x, j) => `<tr style="--d:${j * 30}ms"><td>${j + 1}</td><td>${esc(x.name)}</td><td class="n">${nf(x.bal)}</td></tr>`).join("") || '<tr><td colspan="3" class="e">لا توجد حسابات</td></tr>'}</tbody><tfoot><tr><td></td><td>الإجمالي</td><td class="n">${nf(rows.reduce((s, x) => s + x.bal, 0))}</td></tr></tfoot></table></div>`;
    }).catch(fail);
  }
  /* جدول لوحة: cols [[k, title, numeric?]], rows (r._pid ← كارت الصنف), sum: مفاتيح الإجمالي */
  function tblPane(pane, o) {
    const cols = o.cols, rows = o.rows.slice(0, o.max || 500), sums = o.sum || [];
    pane.innerHTML = `<div class="rp-bal rp-sp">${o.cards ? `<div class="rp-kp">${o.cards.map((c, j) => `<div class="k" style="--d:${j * 50}ms;--c:${c[2] || "#1f7ad8"}"><small>${esc(c[0])}</small><b data-v="${c[1]}">${typeof c[1] === "number" ? nf(c[1]) : esc(c[1])}</b>${c[3] ? `<i>${esc(c[3])}</i>` : ""}</div>`).join("")}</div>` : ""}
      ${o.chart ? `<div class="rp-hb2">${o.chart}</div>` : ""}
      <div class="hd"><b>${esc(o.title)}</b><span class="sp"></span>${o.note ? `<span class="rp-chip g">${esc(o.note)}</span>` : ""}<span class="rp-chip">${dmy(o.P.from)} ← ${dmy(o.P.to)}</span>${o.open ? `<button type="button" class="pr" title="فتح التقرير الكامل">${IC.print}</button>` : ""}</div>
      ${cols.length ? `<table><thead><tr><th>#</th>${cols.map(c => `<th>${esc(c[1])}</th>`).join("")}</tr></thead><tbody>${rows.map((x, j) => `<tr style="--d:${Math.min(j, 30) * 22}ms"${x._pid ? ` data-pid="${esc(x._pid)}" class="lk"` : ""}><td>${j + 1}</td>${cols.map(c => `<td class="${c[2] ? "n" : ""}${c[3] ? " " + c[3] : ""}">${c[2] ? nf(x[c[0]]) : esc(x[c[0]] == null ? "" : x[c[0]])}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${cols.length + 1}" class="e">لا توجد بيانات في هذه الفترة</td></tr>`}</tbody>
      ${sums.length && rows.length ? `<tfoot><tr><td></td>${cols.map(c => `<td class="n">${sums.includes(c[0]) ? nf(o.rows.reduce((s, x) => s + (+x[c[0]] || 0), 0)) : ""}</td>`).join("")}</tr></tfoot>` : ""}</table>` : ""}
      ${o.rows.length > rows.length ? `<p class="nt">يعرض أول ${rows.length} من ${o.rows.length} — افتح التقرير الكامل للباقي.</p>` : ""}</div>`;
    pane.querySelectorAll("tr[data-pid]").forEach(t => t.addEventListener("dblclick", () => window.__FH_ITEMCARD && window.__FH_ITEMCARD(+t.dataset.pid || t.dataset.pid)));
    const pr = pane.querySelector(".pr"); if (pr && o.open) pr.onclick = () => { const r = ROWS.find(o.open); if (r) run(r); };
    pane.querySelectorAll(".rp-kp b[data-v]").forEach(b => { const v = +b.dataset.v; if (!isFinite(v) || !v) return; const t0 = performance.now(); const tick = t => { const k = Math.min(1, (t - t0) / 600), e = 1 - Math.pow(1 - k, 3); b.textContent = nf(v * e); if (k < 1) requestAnimationFrame(tick); }; requestAnimationFrame(tick); });
  }
  const bars = (l, fmtV) => { const mx = Math.max(1, ...l.map(x => Math.abs(x[1]))); return l.map(([k, v], j) => `<div class="b${v < 0 ? " ng" : ""}"><span title="${esc(k)}">${esc(k)}</span><i style="--w:${(Math.abs(v) / mx * 100).toFixed(1)}%;--d:${j * 45}ms"></i><b>${fmtV ? fmtV(v) : nf(v)}</b></div>`).join(""); };
  /* لوحات قسم المخازن */
  function stockPane(pane, key, P, title) {
    const W = window.ANOUER_WH, wh = P.wh || "", all = !wh || wh === "*";
    const qtyOf = p => (W && !all && W.qty && !(W.isMain && W.isMain(+wh))) ? +W.qty(p.id, +wh) || 0 : p.stock;
    const need = key !== "sshort" && key !== "scmp";
    if (key === "sov" && window.__FH_OV) return Promise.all([products(), data(P.from, P.to), itemMeta().catch(() => ({}))]).then(([PR, D, M]) => stockOverview(pane, P, PR, D, M, qtyOf, all, wh));
    return Promise.all([products(), need ? data(P.from, P.to) : Promise.resolve(null), key === "sshort" ? itemMeta() : Promise.resolve({})]).then(([PR, D, M]) => {
      const act = PR.filter(p => p.active), byP = {}; act.forEach(p => byP[p.id] = p);
      const mv = {}; if (D) D.inv.forEach(x => { if (!filt({ br: P.br, wh: all ? "*" : wh }, x)) return; const s = SIGN[x.t]; if (!s) return;
        x.lines.forEach(l => { const g = mv[l.pid] || (mv[l.pid] = { in: 0, out: 0, s: 0, sv: 0, sr: 0, srv: 0, p: 0, pv: 0, pr: 0, prv: 0, name: l.name, code: l.code }); const q = l.qty * l.fac; if (s > 0) g.in += q; else g.out += q;
          if (x.t === "Sale") { g.s += q; g.sv += l.total; } else if (x.t === "SaleReturn") { g.sr += q; g.srv += l.total; } else if (x.t === "Purchase") { g.p += q; g.pv += l.total; } else if (x.t === "PurchaseReturn") { g.pr += q; g.prv += l.total; } }); });
      const OPEN = f => o => o.frm === f;
      if (key === "sov") {
        const val = r2(act.reduce((s, p) => s + qtyOf(p) * p.cost, 0)), sval = r2(act.reduce((s, p) => s + qtyOf(p) * p.price, 0)), neg = act.filter(p => qtyOf(p) < 0).length, zero = act.filter(p => !qtyOf(p)).length;
        const top = Object.entries(mv).map(([id, g]) => [(byP[id] || g).name, r2(g.out)]).filter(x => x[1]).sort((a, b) => b[1] - a[1]).slice(0, 10);
        const byT = {}; D.inv.forEach(x => { if (SIGN[x.t] && filt({ br: P.br, wh: all ? "*" : wh }, x)) byT[TYPE[x.t]] = (byT[TYPE[x.t]] || 0) + 1; });
        return tblPane(pane, { title: "الأصناف الأكثر حركة (منصرف)", P, cards: [["عدد الأصناف", act.length, "#1f7ad8"], ["قيمة المخزون بالتكلفة", val, "#2e8b57", "DZD"], ["قيمة المخزون بسعر البيع", sval, "#f08a24", "DZD"], ["أرصدة سالبة", neg, "#e2402b"], ["أرصدة صفرية", zero, "#7c8794"]],
          chart: `<div class="t">عدد التعاملات بالنوع</div>${bars(Object.entries(byT).sort((a, b) => b[1] - a[1]), v => String(v))}`, cols: [["name", "الصنف"], ["out", "الكمية المنصرفة", 1]], rows: top.map(t => ({ name: t[0], out: t[1] })), open: OPEN("FrmStoreMove") });
      }
      if (key === "smv") { const byT = {}; D.inv.forEach(x => { const s = SIGN[x.t]; if (!s || !filt({ br: P.br, wh: all ? "*" : wh }, x)) return; const g = byT[x.t] || (byT[x.t] = { name: TYPE[x.t], n: 0, in: 0, out: 0, v: 0 }); g.n++; g.v += x.total; x.lines.forEach(l => { if (s > 0) g.in += l.qty * l.fac; else g.out += l.qty * l.fac; }); });
        return tblPane(pane, { title, P, cols: [["name", "التعامل"], ["n", "العدد", 1], ["in", "وارد", 1], ["out", "منصرف", 1], ["v", "القيمة", 1]], rows: Object.values(byT).sort((a, b) => b.n - a.n), sum: ["n", "in", "out", "v"], open: OPEN("FrmStoreMove") }); }
      if (key === "sbal") { const rows = act.map(p => { const g = mv[p.id] || { in: 0, out: 0 }, end = qtyOf(p); return { code: p.code, name: p.name, open: r2(end - g.in + g.out), in: r2(g.in), out: r2(g.out), end: r2(end), val: r2(end * p.cost), _pid: p.id }; }).filter(x => x.in || x.out || x.end);
        return tblPane(pane, { title, P, cols: [["code", "الكود"], ["name", "الصنف", 0, "l"], ["open", "رصيد أول الفترة", 1], ["in", "وارد", 1], ["out", "منصرف", 1], ["end", "الرصيد", 1], ["val", "قيمة التكلفة", 1]], rows, sum: ["in", "out", "val"], open: o => o.frm === "FrmStoreMove" && /Move/.test(o.tags) }); }
      if (key === "snp" || key === "sns") { const s = key === "sns"; const rows = Object.entries(mv).map(([id, g]) => ({ code: (byP[id] || g).code, name: (byP[id] || g).name, q: r2(s ? g.s : g.p), rq: r2(s ? g.sr : g.pr), nq: r2(s ? g.s - g.sr : g.p - g.pr), nv: r2(s ? g.sv - g.srv : g.pv - g.prv), _pid: id })).filter(x => x.q || x.rq).sort((a, b) => b.nv - a.nv);
        return tblPane(pane, { title, P, cols: [["code", "الكود"], ["name", "الصنف", 0, "l"], ["q", s ? "المبيعات" : "المشتريات", 1], ["rq", "المرتجع", 1], ["nq", "صافي الكمية", 1], ["nv", "صافي القيمة", 1]], rows, sum: ["q", "rq", "nq", "nv"], open: o => o.frm === "FrmItemSales" && (s ? !/Purchase|مشتري/.test(o.tags + o.name) : /Purchase|مشتري/.test(o.tags + o.name)) }); }
      if (key === "scmp") { const S = stores(); const rows = act.map(p => { const o = { code: p.code, name: p.name, _pid: p.id }; S.forEach((s, j) => o["w" + j] = W && W.qty && !(W.isMain && W.isMain(+s.id)) ? +W.qty(p.id, +s.id) || 0 : (s.main ? p.stock : 0)); o.tot = r2(S.reduce((t, s, j) => t + o["w" + j], 0)); return o; }).filter(o => o.tot);
        return tblPane(pane, { title, P, note: S.length + " مخزن", cols: [["code", "الكود"], ["name", "الصنف", 0, "l"]].concat(S.map((s, j) => ["w" + j, s.name, 1])).concat([["tot", "الإجمالي", 1]]), rows, sum: S.map((s, j) => "w" + j).concat(["tot"]) }); }
      if (key === "sfix") { const rows = act.filter(p => qtyOf(p) > 0 && !(mv[p.id] && mv[p.id].s)).map(p => ({ code: p.code, name: p.name, cat: p.cat, q: r2(qtyOf(p)), val: r2(qtyOf(p) * p.cost), _pid: p.id })).sort((a, b) => b.val - a.val);
        return tblPane(pane, { title, P, note: "لم تُبع خلال الفترة", cols: [["code", "الكود"], ["name", "الصنف", 0, "l"], ["cat", "المجموعة"], ["q", "الرصيد", 1], ["val", "قيمة التكلفة", 1]], rows, sum: ["q", "val"], open: o => o.frm === "FrmRptTitle" && /Fixed|الراكدة/.test(o.tags + o.name) }); }
      if (key === "sshort") { const rows = act.map(p => ({ p, min: +(M[p.id] || {}).min || p.min || 0, q: qtyOf(p) })).filter(x => x.q <= x.min).map(x => ({ code: x.p.code, name: x.p.name, q: r2(x.q), min: x.min, need: r2(Math.max(0, x.min - x.q)), _pid: x.p.id })).sort((a, b) => a.q - b.q);
        return tblPane(pane, { title, P, note: "الرصيد ≤ حد الطلب", cols: [["code", "الكود"], ["name", "الصنف", 0, "l"], ["q", "الرصيد", 1], ["min", "حد الطلب", 1], ["need", "المطلوب", 1]], rows, sum: ["need"], open: OPEN("FrmItemsRequired") }); }
    });
  }
  /* «المخازن › نظرة عامة» — مطابقة DEXEF ONE (أكثر الأصناف مبيعاً، حركة المخزون اليومية، احصائيات، 6 مربعات) + لمسات 2026
     الأرقام من حركات الفواتير الفعلية للفترة/الفرع/المخزن المختار؛ حد الطلب/الحد الأقصى/الصلاحية من محرك التنبيهات. */
  function stockOverview(pane, P, PR, D, M, qtyOf, all, wh) {
    const O = window.__FH_OV, act = PR.filter(p => p.active), byP = {}; act.forEach(p => byP[p.id] = p);
    const keep = x => filt({ br: P.br, wh: all ? "*" : wh }, x);
    const day = {}, sold = {}, docs = {}, inQ = { v: 0 }, outQ = { v: 0 };
    D.inv.forEach(x => {
      if (!keep(x)) return; const sg0 = SIGN[x.t]; if (sg0 == null && !TYPE[x.t]) return;
      docs[x.t] = (docs[x.t] || 0) + 1;
      if (!sg0) return;
      const seen = new Set();
      x.lines.forEach(l => { const q = l.qty * (l.fac || 1); day[x.date] = (day[x.date] || 0) + sg0 * q; if (sg0 > 0) inQ.v += q; else outQ.v += q;
        if (x.t === "Sale" || x.t === "SaleReturn") { const g = sold[l.pid] || (sold[l.pid] = { pid: l.pid, name: l.name, code: l.code, q: 0, n: 0, v: 0 }); const k = x.t === "Sale" ? 1 : -1; g.q += k * q; g.v += k * l.total; if (x.t === "Sale" && !seen.has(l.pid)) { g.n++; seen.add(l.pid); } } });
    });
    const total = act.reduce((t, p) => t + qtyOf(p), 0), cost = act.reduce((t, p) => t + Math.max(0, qtyOf(p)) * (+p.cost || 0), 0), sell = act.reduce((t, p) => t + Math.max(0, qtyOf(p)) * (+p.price || 0), 0);
    const daily = Object.keys(day).sort().map(d => ({ d, q: day[d] }));
    const top = Object.values(sold).filter(g => g.n > 0).sort((a, b) => b.n - a.n || b.q - a.q).slice(0, 25), topMax = Math.max(1, ...top.map(g => g.q));
    const parts = [["رصيد افتتاحي", docs.Opening || 0, "#22b8cf"], ["مشتريات", docs.Purchase || 0, "#ef4444"], ["مرتجع مبيعات", docs.SaleReturn || 0, "#f97316"], ["مبيعات", docs.Sale || 0, "#3b5bdb"], ["تسوية جردية", docs.Adjust || 0, "#7950f2"], ["هالك المخزون", docs.Waste || 0, "#a61e4d"]]
      .concat([["مرتجع مشتريات", "PurchaseReturn", "#0ca678"], ["إذن استلام", "StockIn", "#74b816"], ["إذن صرف", "StockOut", "#f59f00"], ["تحويلات المخازن", "Transfer", "#868e96"], ["صدقات", "Charity", "#e64980"]].filter(x => docs[x[1]]).map(x => [x[0], docs[x[1]], x[2]]));
    /* المربعات */
    const NT = window.ANOUER_NOTIFY && ANOUER_NOTIFY.data, ntN = k => NT && NT.out && NT.out[k] ? new Set(NT.out[k].map(a => a.p && a.p.id)).size : null;
    const short = act.filter(p => qtyOf(p) <= 0 && sold[p.id] && sold[p.id].q > 0).length, stag = act.filter(p => qtyOf(p) > 0 && !(sold[p.id] && sold[p.id].n)).length, neg = act.filter(p => qtyOf(p) < 0).length;
    const lowCalc = act.filter(p => { const m = +(M[p.id] || {}).min || +p.min || 0; return m > 0 && qtyOf(p) < m; }).length;
    const low = ntN("min") != null && all ? ntN("min") : lowCalc, mx = ntN("max") || act.filter(p => +p.max > 0 && qtyOf(p) > +p.max).length, ex = (ntN("exps") || 0) + (ntN("expd") || 0);
    const sideIdx = k => SL().findIndex(x => x[2] === k);
    const kpi = (cls, ic, t, n, sub) => `<div class="ov-k ${cls}"><span class="ic">${ic}</span><div><small>${t}</small><b class="ov-cnt" data-n="${n}">0</b>${sub ? `<em>${sub}</em>` : ""}</div></div>`;
    const tile = (t, n, ic, go, sev, sub) => `<div class="fh-cd tile ov-t s-${sev}" data-go="${go}" tabindex="0" title="عرض الأصناف"><h5>${t}</h5><div class="tv"><span class="ov-ti">${O.TILE_IC[ic]}</span><b class="ov-cnt" data-n="${n}">0</b><small>${sub}</small></div></div>`;
    const modes = [["bar", "أعمدة", '<svg viewBox="0 0 16 16"><rect x="2" y="7" width="3" height="7" rx="1"/><rect x="6.5" y="3" width="3" height="11" rx="1"/><rect x="11" y="5" width="3" height="9" rx="1"/></svg>'], ["line", "خطوط", '<svg viewBox="0 0 16 16"><rect x="2" y="6" width="1.4" height="8"/><rect x="5" y="3" width="1.4" height="11"/><rect x="8" y="7" width="1.4" height="7"/><rect x="11" y="4" width="1.4" height="10"/><rect x="14" y="8" width="1.4" height="6"/></svg>'], ["area", "منحنى", '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M1 12l4-5 3 3 4-6 3 3"/></svg>']];
    const whName = all ? "كل المخازن" : ((stores().find(x => String(x.id) === String(wh)) || {}).name || "");
    pane.innerHTML = `<div class="fh-ovw ov26 rp-sov">
      <div class="ov-kpis">${kpi("k1", O.OVI.box, "عدد الأصناف", act.length, fmt(r2(total)) + " قطعة" + (whName ? " · " + esc(whName) : ""))}${kpi("k2", O.OVI.val, "قيمة المخزون (بالتكلفة)", Math.round(cost), "دج")}${kpi("k3", O.OVI.up, "قيمة المخزون (بسعر البيع)", Math.round(sell), cost ? "ربح متوقع " + fmt(Math.round(sell - cost)) + " دج" : "دج")}${kpi("k4", O.OVI.in, "حركة الفترة", Math.round(inQ.v + outQ.v), "وارد " + fmt(r2(inQ.v)) + " · منصرف " + fmt(r2(outQ.v)))}</div>
      <div class="fh-cd ov-c" style="grid-column:3/7;grid-row:2/4"><h5>حركة المخزون اليومية <small class="ov-sub">${dmy(P.from)} ← ${dmy(P.to)}</small><span class="ov-mode" role="tablist">${modes.map(m => `<button type="button" data-cm="${m[0]}" class="${O.CHM() === m[0] ? "on" : ""}" title="${m[1]}">${m[2]}<span>${m[1]}</span></button>`).join("")}</span><span class="zm" data-z="ch" title="تكبير">${O.ZOOM}</span></h5>${O.barsPro(daily, total, { to: P.to })}</div>
      <div class="fh-cd ov-c" style="grid-column:1/3;grid-row:2/4"><h5>أكثر الأصناف مبيعاً <small class="ov-sub">${top.length ? "أعلى " + top.length : ""}</small><span class="zm" data-z="top" title="صافي المبيعات">${O.ZOOM}</span></h5><div class="fh-mini ov-top"><table><thead><tr><th>#</th><th>الصنف</th><th>عدد التعاملات</th><th>الكمية</th><th></th></tr></thead><tbody>${top.map((g, i) => `<tr style="--d:${Math.min(i, 15) * 30}ms"><td><span class="rk r${i < 3 ? i + 1 : 0}">${i + 1}</span></td><td class="t" title="${esc(g.name)}">${esc((byP[g.pid] || g).name)}<i class="sh" style="--w:${Math.round(Math.max(0, g.q) / topMax * 100)}%"></i></td><td>${g.n}</td><td><b>${fmt(r2(g.q))}</b></td><td data-pid="${esc(g.pid)}" title="بيانات الصنف">${O.ZB}</td></tr>`).join("") || '<tr><td colspan="5" class="ov-none">لا توجد مبيعات في الفترة</td></tr>'}</tbody></table></div></div>
      <div class="fh-cd ov-c" style="grid-column:1/4;grid-row:4/6"><h5>احصائيات <small class="ov-sub">عدد التعاملات حسب النوع</small><span class="zm" data-z="tot" title="تعاملات المخزون">${O.ZOOM}</span></h5>${O.donutPro(parts)}</div>
      ${tile("نواقص الأصناف", short, "short", "s:sshort", "o", "نفد رصيدها وتُباع")}${tile("أصناف راكدة", stag, "stag", "s:sfix", "b", "لم تُبع في الفترة")}${tile("الأرصدة السالبة", neg, "neg", "n:neg", "r", "رصيد أقل من صفر")}
      ${tile("أقل من حد الطلب", low, "low", "n:min", "o", "حسب حد الطلب")}${tile("صلاحية أوشكت على الإنتهاء", ex, "exp", "n:exps", "r", "منتهية أو قريبة")}${tile("أصناف تعدت الحد الأقصى", mx, "max", "n:max", "p", "فوق الحد الأقصى")}</div>`;
    O.countUp(pane);
    pane.querySelectorAll("[data-go]").forEach(t => { const go = () => { const v = t.dataset.go; if (/^s:/.test(v)) { const i = sideIdx(v.slice(2)); if (i >= 0) sidePane(i); } else if (window.ANOUER_NOTIFY) ANOUER_NOTIFY.open(v.slice(2)); }; t.addEventListener("click", go); t.addEventListener("keydown", e => { if (e.key === "Enter") go(); }); });
    pane.querySelector(".rp-sov").addEventListener("click", e => {
      const z = e.target.closest("[data-pid]"); if (z && window.__FH_ITEMCARD) { window.__FH_ITEMCARD(+z.dataset.pid || z.dataset.pid); return; }
      const zm = e.target.closest("[data-z]"); if (!zm) return; const v = zm.dataset.z;
      if (v === "ch") zm.closest(".fh-cd").classList.toggle("ov-max"); else { const i = sideIdx(v === "top" ? "sns" : "smv"); if (i >= 0) sidePane(i); }
    });
    const ch = pane.querySelector(".ov-chart"); if (ch) O.chartHover(ch);
    pane.querySelectorAll("[data-cm]").forEach(bt => bt.addEventListener("click", () => { try { localStorage.setItem("ov.chart", bt.dataset.cm); } catch (e) { } pane.querySelectorAll("[data-cm]").forEach(x => x.classList.toggle("on", x === bt));
      const c = pane.querySelector(".ov-chart"); if (!c) return; c.className = "ov-chart m-" + bt.dataset.cm; c.querySelector("svg").outerHTML = O.chartSVG(JSON.parse(c.dataset.pts), bt.dataset.cm); }));
    const dn = pane.querySelector(".ov-dn"); if (dn) dn.addEventListener("mouseover", e => { const k = (e.target.closest("[data-k]") || {}).dataset; dn.querySelectorAll("[data-k]").forEach(x => x.classList.toggle("hi", !!k && x.dataset.k === k.k)); });
    if (!NT && window.ANOUER_NOTIFY && !pane.__ntTry) { pane.__ntTry = 1; ANOUER_NOTIFY.refresh().then(d => { if (d && pane.isConnected && ST.side === sideIdx("sov")) stockOverview(pane, P, PR, D, M, qtyOf, all, wh); }).catch(() => { }); }
  }
  /* لوحات قسم الأرباح و الخسائر */
  function profitPane(pane, key, P, title) {
    const HR = key === "pov" && window.ANOUER_HR ? ANOUER_HR.cost(P.from, P.to, { br: P.br }).catch(() => null) : Promise.resolve(null);
    return Promise.all([data(P.from, P.to), key === "psu" ? itemMeta() : Promise.resolve({}), key === "pov" || key === "pexp" ? (A() ? A().docs("exp", true).catch(() => []) : Promise.resolve([])) : Promise.resolve([]), HR]).then(([D, M, EX, HRC]) => {
      const v = { br: P.br, wh: "*" };
      const it = () => profitRows(D, v, (x, l) => ({ k: l.pid, o: { code: l.code, name: l.name, _pid: l.pid } }));
      const cu = () => profitRows(D, v, x => ({ k: x.pid || ("n:" + x.pname), o: { name: x.pname || "تعامل نقدى" } }));
      const cols = [["sales", "صافي المبيعات", 1], ["cost", "التكلفة", 1], ["profit", "الربح", 1], ["pct", "النسبة %", 1]];
      const ex = EX.filter(d => d.data && d.data.date >= P.from && d.data.date <= P.to);
      if (key === "pov") { const L = it(), S = r2(L.reduce((s, x) => s + x.sales, 0)), C = r2(L.reduce((s, x) => s + x.cost, 0));
        /* أجور الموظفين (أيام العمل الفعلية) — والمصروفات اليدوية المسماة رواتب تُستبعد لمنع الازدواج */
        const hrOn = !!(HRC && HRC.on && HRC.total), W = hrOn ? HRC.total : 0;
        const E = r2(ex.reduce((s, d) => { if (hrOn && HRC.dedupe) { const rs = d.data.rows || []; if (rs.length) return s + rs.reduce((a, rw) => a + (HRC.re.test(rw.name || rw.item || "") ? 0 : (+rw.total || +rw.amt || +rw.value || 0)), 0); if (HRC.re.test((d.data.acc && d.data.acc.name) || d.data.stmt || "")) return s; } return s + (+d.data.total || +d.data.amt || 0); }, 0) + W);
        const days = {}; D.inv.forEach(x => { if (x.t !== "Sale" && x.t !== "SaleReturn") return; const s = sg(x), c = x.lines.reduce((a, l) => a + l.cost, 0); days[x.date] = (days[x.date] || 0) + s * (x.total - c); });
        if (hrOn) Object.keys(HRC.days).forEach(d => { days[d] = (days[d] || 0) - HRC.days[d]; });
        const dl = Object.entries(days).sort((a, b) => a[0].localeCompare(b[0])).slice(-14).map(([d, p]) => [dmy(d), r2(p)]);
        return tblPane(pane, { title: "أعلى الأصناف ربحاً", P, cards: [["صافي المبيعات", S, "#1f7ad8", "DZD"], ["تكلفة المبيعات", C, "#f08a24", "DZD"], ["مجمل الربح", r2(S - C), "#2e8b57", S ? r2((S - C) / S * 100) + "%" : ""], ["المصروفات", E, "#e2402b", hrOn ? "منها أجور " + nf(W) : "DZD"], ["صافي الربح", r2(S - C - E), S - C - E >= 0 ? "#2e8b57" : "#e2402b", "DZD"]],
          chart: `<div class="t">الربح اليومي (آخر 14 يوم)${hrOn ? " — بعد أجور الموظفين" : ""}</div>${bars(dl)}`, cols: [["name", "الصنف", 0, "l"]].concat(cols), rows: L.sort((a, b) => b.profit - a.profit).slice(0, 10), open: o => o.frm === "FrmRptBranchListDT" && /^ProfitLoss/.test(o.tags) }); }
      if (key === "pit" || key === "pitL") { let L = it(); if (key === "pitL") L = L.filter(x => x.profit < 0).sort((a, b) => a.profit - b.profit); else L.sort((a, b) => b.profit - a.profit);
        return tblPane(pane, { title, P, cols: [["code", "الكود"], ["name", "الصنف", 0, "l"], ["qty", "الكمية", 1]].concat(cols), rows: L, sum: ["qty", "sales", "cost", "profit"], open: o => o.frm === "FrmRptBranchListDT" && o.tags === (key === "pitL" ? "TotalItemLoss" : "TotalItemProfit") }); }
      if (key === "pcu" || key === "pcuL") { let L = cu(); if (key === "pcuL") L = L.filter(x => x.profit < 0).sort((a, b) => a.profit - b.profit); else L.sort((a, b) => b.profit - a.profit);
        return tblPane(pane, { title, P, cols: [["name", "العميل", 0, "l"]].concat(cols), rows: L, sum: ["sales", "cost", "profit"], open: o => o.frm === "FrmRptBranchListDT" && o.tags === (key === "pcuL" ? "TotalCustProfitLess" : "TotalCustProfit") }); }
      if (key === "psu") { const L = profitRows(D, v, (x, l) => { const s = (M[l.pid] || {}).sup || "بدون مورد"; return { k: s, o: { name: s } }; }).sort((a, b) => b.profit - a.profit);
        return tblPane(pane, { title, P, note: "حسب آخر مورد للصنف", cols: [["name", "المورد", 0, "l"]].concat(cols), rows: L, sum: ["sales", "cost", "profit"] }); }
      if (key === "pexp") { const g = {}; ex.forEach(d => { const n = (d.data.acc && d.data.acc.name) || ((d.data.rows || [])[0] || {}).name || d.data.stmt || "مصروفات"; const o = g[n] || (g[n] = { name: n, n: 0, amt: 0 }); o.n++; o.amt += +d.data.total || +d.data.amt || 0; });
        const L = Object.values(g).map(o => Object.assign(o, { amt: r2(o.amt) })).sort((a, b) => b.amt - a.amt);
        return tblPane(pane, { title, P, chart: L.length ? bars(L.slice(0, 8).map(x => [x.name, x.amt])) : "", cols: [["name", "البند", 0, "l"], ["n", "العدد", 1], ["amt", "المبلغ", 1]], rows: L, sum: ["n", "amt"], open: o => o.frm === "FrmExpenesesRpt" }); }
    });
  }
  /* «نظرة عامة»: الرصيد الحالي + إجمالي التعاملات بالخزائن + عدد التعاملات + إجمالي التعاملات بالنوع */
  function overview(pane, P) {
    const AC = A();
    Promise.all([AC.accounts("tr", true), AC.ledger(true), data(P.from, P.to).catch(() => ({ cv: [], inv: [] }))]).then(([trs, , D]) => {
      const rows = trs.map(t => { const mv = (D.cv || []).filter(c => String(c.trid) === String(t.id)); const dr = r2(mv.filter(c => c.type === "Receipt").reduce((s, c) => s + c.amt, 0)), cr = r2(mv.filter(c => c.type === "Payment").reduce((s, c) => s + c.amt, 0)); const end = r2(t.bal); return { name: t.name, prev: r2(end - dr + cr), dr, cr, end }; });
      const cur = r2(rows.reduce((s, x) => s + x.end, 0));
      const byT = {}; (D.inv || []).forEach(x => { const k = TYPE[x.t] || x.t, g = byT[k] || (byT[k] = { n: 0, in: 0, out: 0 }); g.n++; if (x.t === "Sale" || x.t === "PurchaseReturn") g.in += x.paid; else if (x.t === "Purchase" || x.t === "SaleReturn") g.out += x.paid; });
      (D.cv || []).forEach(c => { const k = c.type === "Receipt" ? "قبض نقدية" : "صرف نقدية", g = byT[k] || (byT[k] = { n: 0, in: 0, out: 0 }); g.n++; if (c.type === "Receipt") g.in += c.amt; else g.out += c.amt; });
      const tl = Object.keys(byT).map(k => [k, byT[k]]).sort((a, b) => b[1].n - a[1].n), mx = Math.max(1, ...tl.map(x => x[1].n));
      pane.innerHTML = `<div class="rp-ov"><div class="r1"><div class="rp-tb2"><div class="hd"><button type="button" class="pr" title="طباعة">${IC.print}</button><b>إجمالي التعاملات بـ <small>(DZD)</small></b></div>
        <table><thead><tr><th></th><th>الإسم</th><th>رصيد سابق</th><th>مدين</th><th>دائن</th><th>رصيد نهاية الفترة</th><th></th></tr></thead><tbody>${rows.map((x, j) => `<tr style="--d:${j * 40}ms"><td>${j ? "" : "←"}</td><td>${esc(x.name)}</td><td class="n">${nf(x.prev)}</td><td class="n">${nf(x.dr)}</td><td class="n">${nf(x.cr)}</td><td class="n">${nf(x.end)}</td><td><button type="button" class="mg" data-t="${esc(x.name)}" title="حركة الخزينة">${IC.find}</button></td></tr>`).join("")}</tbody>
        <tfoot><tr><td></td><td></td><td class="n">${nf(rows.reduce((s, x) => s + x.prev, 0))}</td><td class="n">${nf(rows.reduce((s, x) => s + x.dr, 0))}</td><td class="n">${nf(rows.reduce((s, x) => s + x.cr, 0))}</td><td></td><td></td></tr></tfoot></table></div>
        <div class="rp-cur"><b>الرصيد الحالي</b><div class="cd"><small>DZD</small><span class="v" data-v="${cur}">${nf(cur)}</span><span class="ic">💵</span></div></div></div>
        <div class="r2"><div class="rp-tb2"><div class="hd"><button type="button" class="pr">${IC.print}</button><b>إجمالي التعاملات بـ <small>(DZD)</small></b></div><table><thead><tr><th>التعامل</th><th>عدد التعاملات</th><th>الإيرادات</th><th>المصروفات</th></tr></thead><tbody>${tl.map(([k, g], j) => `<tr style="--d:${j * 30}ms"><td>${esc(k)}</td><td class="n">${g.n}</td><td class="n">${nf(g.in)}</td><td class="n">${nf(g.out)}</td></tr>`).join("") || '<tr><td colspan="4" class="e">لا توجد تعاملات</td></tr>'}</tbody></table></div>
        <div class="rp-tb2"><div class="hd"><button type="button" class="pr">${IC.print}</button><b>عدد التعاملات بـ <small>(DZD)</small></b></div><div class="hb">${tl.map(([k, g], j) => `<div class="b"><span>${esc(k)}</span><i style="--w:${(g.n / mx * 100).toFixed(1)}%;--d:${j * 50}ms"></i><b>${g.n}</b></div>`).join("") || '<div class="e">لا توجد تعاملات</div>'}</div></div></div></div>`;
      pane.querySelectorAll(".mg").forEach(b => b.onclick = () => run(ROWS.find(r => r.frm === "FrmAccountMove" && r.tags === "Storage" && r.type === 0)));
      pane.querySelectorAll(".pr").forEach(b => b.onclick = () => run(ROWS.find(r => r.frm === "FrmTotalCashRPT")));
    }).catch(e => { pane.innerHTML = '<div class="e">تعذّر التحميل: ' + esc(e.message || e) + "</div>"; });
  }
  /* «ميزان الأستاذ العام» (تقريبي من أرصدة ANOUER): الخزائن، البنوك، العملاء، الموردين، المخزون، المبيعات، المشتريات، المصروفات */
  function glBalance(pane, P) {
    const AC = A();
    Promise.all([AC.ledger(true), AC.accounts("tr", true), AC.accounts("bk", true), AC.parties("cu", true), AC.parties("su", true), products(), data(P.from, P.to).catch(() => ({ inv: [] })), AC.docs("exp", true).catch(() => [])]).then(([, tr, bk, cu, su, pr, D, ex]) => {
      const sum = (t, f) => r2((D.inv || []).filter(x => x.t === t).reduce((a, x) => a + f(x), 0));
      const cuDr = r2(cu.reduce((s, c) => s + Math.max(0, -c.bal), 0)), cuCr = r2(cu.reduce((s, c) => s + Math.max(0, c.bal), 0)), suCr = r2(su.reduce((s, c) => s + Math.max(0, c.bal), 0)), suDr = r2(su.reduce((s, c) => s + Math.max(0, -c.bal), 0));
      const inv = r2(pr.reduce((s, p) => s + p.stock * p.cost, 0)), ns = r2(sum("Sale", x => x.total) - sum("SaleReturn", x => x.total)), np = r2(sum("Purchase", x => x.total) - sum("PurchaseReturn", x => x.total));
      const te = r2(ex.filter(d => d.data && d.data.date >= P.from && d.data.date <= P.to).reduce((s, d) => s + (+d.data.total || 0), 0));
      const L = [["1211", "الخزينة", r2(tr.reduce((s, t) => s + (+t.bal || 0), 0)), 0], ["1212", "البنوك", r2(bk.reduce((s, b) => s + AC.accBal("bk", b), 0)), 0], ["1221", "مخزن البضاعة", inv, 0], ["1231", "العملاء", cuDr, cuCr], ["2111", "موردون", suDr, suCr], ["41", "صافي المبيعات", 0, ns], ["31", "صافي المشتريات", np, 0], ["32", "المصروفات", te, 0]];
      pane.innerHTML = `<div class="rp-bal gl"><div class="hd"><b>ميزان مراجعة الأستاذ العام</b><span class="sp"></span><span class="rp-chip">${dmy(P.from)} ← ${dmy(P.to)}</span></div><table><thead><tr><th>الرقم</th><th>الحساب</th><th>مدين</th><th>دائن</th><th>الرصيد</th></tr></thead><tbody>${L.map((x, j) => `<tr style="--d:${j * 35}ms"><td>${x[0]}</td><td>${esc(x[1])}</td><td class="n">${nf(x[2])}</td><td class="n">${nf(x[3])}</td><td class="n">${nf(r2(x[2] - x[3]))}</td></tr>`).join("")}</tbody></table><p class="nt">ميزان تقريبي من أرصدة ANOUER الحالية (شجرة الحسابات والقيود الكاملة غير مفعّلة بعد).</p></div>`;
    }).catch(e => { pane.innerHTML = '<div class="e">تعذّر التحميل: ' + esc(e.message || e) + "</div>"; });
  }
  RV.VIEW_SHOW.rphub = () => { };

  /* ================================================================== ربط القائمة «التقارير» */
  function wire() {
    const a = [...document.querySelectorAll(".navlinks>a")].find(x => x.textContent.trim() === "التقارير");
    if (!a) return false;
    a.setAttribute("role", "button"); a.tabIndex = 0;
    a.addEventListener("click", e => { e.preventDefault(); e.stopImmediatePropagation(); hub(); }, true);
    a.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); hub(); } });
    /* مربع «التقارير» في الرئيسية */
    const prev = window.__homeAcc;
    window.__homeAcc = (k, sub) => { if (k === "reports") { hub(); return true; } return prev ? prev(k, sub) : false; };
    return true;
  }
  if (!wire()) document.addEventListener("DOMContentLoaded", wire);
  /* دفتر حساب طرف (عميل/مورد) لبطاقة العميل/المورد (party-card.js): الحركات بالرصيد الجاري + الفواتير وأسطرها */
  function ledger(side, pid, from) {
    from = from || "2000-01-01";
    const ks = ["recv", "pay"].concat(PDOCS);
    return Promise.all([data(from, today()), parties(side).catch(() => [])].concat(ks.map(k => A() ? A().docs(k, true).catch(() => []) : []))).then(([D, PL, ...dl]) => {
      const docs = {}; ks.forEach((k, i) => docs[k] = dl[i] || []);
      const pp = (PL || []).find(x => String(x.id) === String(pid)) || null, cur = pp ? r2(-(+pp.bal || 0)) : null;
      const mv = partyMoves(side, pid, D, docs).filter(m => m.date >= from);
      const sum = mv.reduce((t, m) => t + m.dr - m.cr, 0), c0 = cur == null ? r2(sum) : cur, prev = r2(c0 - sum);
      let bal = prev; mv.forEach(m => { bal = r2(bal + m.dr - m.cr); m.bal = bal; });
      return { party: pp, parties: PL || [], cur: c0, prev, mv, D, docs };
    });
  }
  window.ANOUER_REPORTS = { bonus: bonusReport, docTab: (name, m) => { const T = resultTab({ name }, false); return showDoc(T.host, Object.assign({ title: name }, m), name); }, vat: (f1, f2) => { const r = ROWS.find(x => x.tags === "VatGulf"); if (r) vatRpt(r, f1 && f2 ? { from: f1, to: f2 } : null); }, vatBuild, ledger, TYPE, open: hub, run: id => run(typeof id === "number" ? byId(id) : id), rows: ROWS, tiles: TILES, data, docRes, viewer, openCat: id => { hub(); openCat(id); } };
})();
